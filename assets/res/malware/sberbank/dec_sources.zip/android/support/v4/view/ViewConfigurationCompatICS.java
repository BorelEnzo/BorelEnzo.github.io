package android.support.v4.view;

import android.view.ViewConfiguration;

class ViewConfigurationCompatICS
{
  static boolean hasPermanentMenuKey(ViewConfiguration paramViewConfiguration)
  {
    return paramViewConfiguration.hasPermanentMenuKey();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/krep/classes-dex2jar.jar!/android/support/v4/view/ViewConfigurationCompatICS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */