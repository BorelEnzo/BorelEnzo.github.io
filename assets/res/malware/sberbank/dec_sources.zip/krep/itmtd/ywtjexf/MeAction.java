package krep.itmtd.ywtjexf;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MeAction
{
  Context mContext;
  
  MeAction(Context paramContext)
  {
    this.mContext = paramContext;
  }
  
  public void Del(String paramString1, String paramString2)
  {
    paramString2 = this.mContext.getSharedPreferences(paramString2, 0).edit();
    paramString2.remove(paramString1);
    paramString2.commit();
  }
  
  public String Get(String paramString1, String paramString2, String paramString3)
  {
    return this.mContext.getSharedPreferences(paramString3, 0).getString(paramString1, paramString2);
  }
  
  public String List(String paramString)
    throws JSONException
  {
    Object localObject = this.mContext.getSharedPreferences(paramString, 0);
    paramString = new JSONObject();
    JSONArray localJSONArray = new JSONArray();
    localObject = ((SharedPreferences)localObject).getAll();
    Iterator localIterator;
    if (((Map)localObject).size() > 0) {
      localIterator = ((Map)localObject).keySet().iterator();
    }
    for (;;)
    {
      if (!localIterator.hasNext())
      {
        paramString.put("result", localJSONArray);
        return paramString.toString();
      }
      String str = (String)localIterator.next();
      JSONObject localJSONObject = new JSONObject();
      localJSONObject.put(str, ((Map)localObject).get(str));
      localJSONArray.put(localJSONObject);
    }
  }
  
  public String ListBoot()
    throws JSONException
  {
    return List("Boot_conf");
  }
  
  public String ListCall()
    throws JSONException
  {
    return List("Call_conf");
  }
  
  public String ListCmd()
    throws JSONException
  {
    return List("Cmd_conf");
  }
  
  public String ListNetwork()
    throws JSONException
  {
    return List("Network_conf");
  }
  
  public String ListPower()
    throws JSONException
  {
    return List("Power_conf");
  }
  
  public String ListSMS()
    throws JSONException
  {
    return List("SMS_conf");
  }
  
  public String ListStart()
    throws JSONException
  {
    return List("Start_conf");
  }
  
  public String ListTimeout()
    throws JSONException
  {
    return List("Timeout_conf");
  }
  
  public String ListTimers()
    throws JSONException
  {
    return List("Timers_conf");
  }
  
  public void Set(String paramString1, String paramString2, String paramString3)
  {
    paramString3 = this.mContext.getSharedPreferences(paramString3, 0).edit();
    paramString3.putString(paramString1, paramString2);
    paramString3.commit();
  }
  
  public void SetBoot(String paramString)
  {
    Set(paramString, "1", "Boot_conf");
  }
  
  public void SetCall(String paramString)
  {
    Set(paramString, "1", "Call_conf");
  }
  
  public void SetCmd(String paramString1, String paramString2)
  {
    Set(paramString1, paramString2, "Cmd_conf");
  }
  
  public void SetNetwork(String paramString)
  {
    Set(paramString, "1", "Network_conf");
  }
  
  public void SetPower(String paramString)
  {
    Set(paramString, "1", "Power_conf");
  }
  
  public void SetSMS(String paramString)
  {
    Set(paramString, "1", "SMS_conf");
  }
  
  public void SetStart(String paramString1, String paramString2)
  {
    Set(paramString1, paramString2, "Start_conf");
  }
  
  public void SetTimeout(String paramString1, String paramString2)
  {
    Set(paramString1, paramString2, "Timeout_conf");
  }
  
  public void SetTimer(String paramString1, String paramString2)
  {
    Set(paramString1, paramString2, "Timers_conf");
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/krep/classes-dex2jar.jar!/krep/itmtd/ywtjexf/MeAction.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */