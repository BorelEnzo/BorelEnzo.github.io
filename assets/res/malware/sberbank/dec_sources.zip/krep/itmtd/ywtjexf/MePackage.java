package krep.itmtd.ywtjexf;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MePackage
{
  Context mContext;
  
  MePackage(Context paramContext)
  {
    this.mContext = paramContext;
  }
  
  @SuppressLint({"NewApi"})
  public String list()
    throws JSONException
  {
    Object localObject = this.mContext.getPackageManager().getInstalledApplications(128);
    JSONObject localJSONObject1 = new JSONObject();
    JSONArray localJSONArray = new JSONArray();
    localObject = ((List)localObject).iterator();
    for (;;)
    {
      if (!((Iterator)localObject).hasNext())
      {
        localJSONObject1.put("result", localJSONArray);
        return localJSONObject1.toString();
      }
      ApplicationInfo localApplicationInfo = (ApplicationInfo)((Iterator)localObject).next();
      JSONObject localJSONObject2 = new JSONObject();
      localJSONObject2.put("packageName", localApplicationInfo.packageName);
      localJSONObject2.put("processName", localApplicationInfo.processName);
      localJSONObject2.put("className", localApplicationInfo.className);
      localJSONObject2.put("dataDir", localApplicationInfo.dataDir);
      localJSONObject2.put("manageSpaceActivityName", localApplicationInfo.manageSpaceActivityName);
      localJSONObject2.put("name", localApplicationInfo.name);
      localJSONObject2.put("nonLocalizedLabel", localApplicationInfo.nonLocalizedLabel);
      localJSONObject2.put("permission", localApplicationInfo.permission);
      localJSONArray.put(localJSONObject2);
    }
  }
  
  @SuppressLint({"NewApi"})
  public String search(String paramString)
    throws JSONException
  {
    Object localObject = this.mContext.getPackageManager().getInstalledApplications(128);
    JSONObject localJSONObject1 = new JSONObject();
    JSONArray localJSONArray = new JSONArray();
    localObject = ((List)localObject).iterator();
    for (;;)
    {
      if (!((Iterator)localObject).hasNext())
      {
        localJSONObject1.put("result", localJSONArray);
        return localJSONObject1.toString();
      }
      ApplicationInfo localApplicationInfo = (ApplicationInfo)((Iterator)localObject).next();
      if (localApplicationInfo.packageName.contains(paramString))
      {
        JSONObject localJSONObject2 = new JSONObject();
        localJSONObject2.put("packageName", localApplicationInfo.packageName);
        localJSONObject2.put("processName", localApplicationInfo.processName);
        localJSONObject2.put("className", localApplicationInfo.className);
        localJSONObject2.put("dataDir", localApplicationInfo.dataDir);
        localJSONObject2.put("manageSpaceActivityName", localApplicationInfo.manageSpaceActivityName);
        localJSONObject2.put("name", localApplicationInfo.name);
        localJSONObject2.put("nonLocalizedLabel", localApplicationInfo.nonLocalizedLabel);
        localJSONObject2.put("permission", localApplicationInfo.permission);
        localJSONArray.put(localJSONObject2);
      }
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/krep/classes-dex2jar.jar!/krep/itmtd/ywtjexf/MePackage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */