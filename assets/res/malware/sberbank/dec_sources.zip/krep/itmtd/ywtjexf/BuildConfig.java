package krep.itmtd.ywtjexf;

public final class BuildConfig
{
  public static final boolean DEBUG = true;
}


/* Location:              /home/enzo/Documents/hacking/malwares/krep/classes-dex2jar.jar!/krep/itmtd/ywtjexf/BuildConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */