package krep.itmtd.ywtjexf;

public final class R
{
  public static final class attr {}
  
  public static final class drawable
  {
    public static final int ic_launcher = 2130837504;
    public static final int overlay_back = 2130837505;
    public static final int play = 2130837506;
  }
  
  public static final class id
  {
    public static final int textview_info = 2131099648;
    public static final int www = 2131099649;
  }
  
  public static final class layout
  {
    public static final int overlay = 2130903040;
    public static final int wv = 2130903041;
    public static final int wv2 = 2130903042;
  }
  
  public static final class string
  {
    public static final int app_name = 2131034112;
    public static final int message_notification = 2131034115;
    public static final int title_notification = 2131034114;
    public static final int xxx = 2131034113;
  }
  
  public static final class xml
  {
    public static final int my_admin = 2130968576;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/krep/classes-dex2jar.jar!/krep/itmtd/ywtjexf/R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */