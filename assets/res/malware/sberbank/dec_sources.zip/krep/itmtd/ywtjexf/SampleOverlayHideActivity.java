package krep.itmtd.ywtjexf;

import android.app.Activity;
import android.os.Bundle;

public class SampleOverlayHideActivity
  extends Activity
{
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    OverlayService.stop();
    finish();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/krep/classes-dex2jar.jar!/krep/itmtd/ywtjexf/SampleOverlayHideActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */