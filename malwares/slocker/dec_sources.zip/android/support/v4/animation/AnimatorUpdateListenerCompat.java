package android.support.v4.animation;

public abstract interface AnimatorUpdateListenerCompat
{
  public abstract void onAnimationUpdate(ValueAnimatorCompat paramValueAnimatorCompat);
}


/* Location:              /home/enzo/Documents/hacking/malwares/slocker/classes-dex2jar.jar!/android/support/v4/animation/AnimatorUpdateListenerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */