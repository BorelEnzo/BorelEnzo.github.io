package android.support.v4.media;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import android.support.v4.os.ResultReceiver;

public abstract interface IMediaBrowserServiceCompat
  extends IInterface
{
  public abstract void addSubscription(String paramString, IMediaBrowserServiceCompatCallbacks paramIMediaBrowserServiceCompatCallbacks)
    throws RemoteException;
  
  public abstract void connect(String paramString, Bundle paramBundle, IMediaBrowserServiceCompatCallbacks paramIMediaBrowserServiceCompatCallbacks)
    throws RemoteException;
  
  public abstract void disconnect(IMediaBrowserServiceCompatCallbacks paramIMediaBrowserServiceCompatCallbacks)
    throws RemoteException;
  
  public abstract void getMediaItem(String paramString, ResultReceiver paramResultReceiver)
    throws RemoteException;
  
  public abstract void removeSubscription(String paramString, IMediaBrowserServiceCompatCallbacks paramIMediaBrowserServiceCompatCallbacks)
    throws RemoteException;
  
  public static abstract class Stub
    extends Binder
    implements IMediaBrowserServiceCompat
  {
    private static final String DESCRIPTOR = "android.support.v4.media.IMediaBrowserServiceCompat";
    static final int TRANSACTION_addSubscription = 3;
    static final int TRANSACTION_connect = 1;
    static final int TRANSACTION_disconnect = 2;
    static final int TRANSACTION_getMediaItem = 5;
    static final int TRANSACTION_removeSubscription = 4;
    
    public Stub()
    {
      attachInterface(this, "android.support.v4.media.IMediaBrowserServiceCompat");
    }
    
    public static IMediaBrowserServiceCompat asInterface(IBinder paramIBinder)
    {
      if (paramIBinder == null) {
        return null;
      }
      IInterface localIInterface = paramIBinder.queryLocalInterface("android.support.v4.media.IMediaBrowserServiceCompat");
      if ((localIInterface != null) && ((localIInterface instanceof IMediaBrowserServiceCompat))) {
        return (IMediaBrowserServiceCompat)localIInterface;
      }
      return new Proxy(paramIBinder);
    }
    
    public IBinder asBinder()
    {
      return this;
    }
    
    public boolean onTransact(int paramInt1, Parcel paramParcel1, Parcel paramParcel2, int paramInt2)
      throws RemoteException
    {
      switch (paramInt1)
      {
      default: 
        return super.onTransact(paramInt1, paramParcel1, paramParcel2, paramInt2);
      case 1598968902: 
        paramParcel2.writeString("android.support.v4.media.IMediaBrowserServiceCompat");
        return true;
      case 1: 
        paramParcel1.enforceInterface("android.support.v4.media.IMediaBrowserServiceCompat");
        String str = paramParcel1.readString();
        if (paramParcel1.readInt() != 0) {}
        for (paramParcel2 = (Bundle)Bundle.CREATOR.createFromParcel(paramParcel1);; paramParcel2 = null)
        {
          connect(str, paramParcel2, IMediaBrowserServiceCompatCallbacks.Stub.asInterface(paramParcel1.readStrongBinder()));
          return true;
        }
      case 2: 
        paramParcel1.enforceInterface("android.support.v4.media.IMediaBrowserServiceCompat");
        disconnect(IMediaBrowserServiceCompatCallbacks.Stub.asInterface(paramParcel1.readStrongBinder()));
        return true;
      case 3: 
        paramParcel1.enforceInterface("android.support.v4.media.IMediaBrowserServiceCompat");
        addSubscription(paramParcel1.readString(), IMediaBrowserServiceCompatCallbacks.Stub.asInterface(paramParcel1.readStrongBinder()));
        return true;
      case 4: 
        paramParcel1.enforceInterface("android.support.v4.media.IMediaBrowserServiceCompat");
        removeSubscription(paramParcel1.readString(), IMediaBrowserServiceCompatCallbacks.Stub.asInterface(paramParcel1.readStrongBinder()));
        return true;
      }
      paramParcel1.enforceInterface("android.support.v4.media.IMediaBrowserServiceCompat");
      paramParcel2 = paramParcel1.readString();
      if (paramParcel1.readInt() != 0) {}
      for (paramParcel1 = (ResultReceiver)ResultReceiver.CREATOR.createFromParcel(paramParcel1);; paramParcel1 = null)
      {
        getMediaItem(paramParcel2, paramParcel1);
        return true;
      }
    }
    
    private static class Proxy
      implements IMediaBrowserServiceCompat
    {
      private IBinder mRemote;
      
      Proxy(IBinder paramIBinder)
      {
        this.mRemote = paramIBinder;
      }
      
      /* Error */
      public void addSubscription(String paramString, IMediaBrowserServiceCompatCallbacks paramIMediaBrowserServiceCompatCallbacks)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 30	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: aload_3
        //   5: ldc 32
        //   7: invokevirtual 36	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   10: aload_3
        //   11: aload_1
        //   12: invokevirtual 39	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   15: aload_2
        //   16: ifnull +34 -> 50
        //   19: aload_2
        //   20: invokeinterface 45 1 0
        //   25: astore_1
        //   26: aload_3
        //   27: aload_1
        //   28: invokevirtual 48	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   31: aload_0
        //   32: getfield 19	android/support/v4/media/IMediaBrowserServiceCompat$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   35: iconst_3
        //   36: aload_3
        //   37: aconst_null
        //   38: iconst_1
        //   39: invokeinterface 54 5 0
        //   44: pop
        //   45: aload_3
        //   46: invokevirtual 57	android/os/Parcel:recycle	()V
        //   49: return
        //   50: aconst_null
        //   51: astore_1
        //   52: goto -26 -> 26
        //   55: astore_1
        //   56: aload_3
        //   57: invokevirtual 57	android/os/Parcel:recycle	()V
        //   60: aload_1
        //   61: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	62	0	this	Proxy
        //   0	62	1	paramString	String
        //   0	62	2	paramIMediaBrowserServiceCompatCallbacks	IMediaBrowserServiceCompatCallbacks
        //   3	54	3	localParcel	Parcel
        // Exception table:
        //   from	to	target	type
        //   4	15	55	finally
        //   19	26	55	finally
        //   26	45	55	finally
      }
      
      public IBinder asBinder()
      {
        return this.mRemote;
      }
      
      public void connect(String paramString, Bundle paramBundle, IMediaBrowserServiceCompatCallbacks paramIMediaBrowserServiceCompatCallbacks)
        throws RemoteException
      {
        Parcel localParcel = Parcel.obtain();
        for (;;)
        {
          try
          {
            localParcel.writeInterfaceToken("android.support.v4.media.IMediaBrowserServiceCompat");
            localParcel.writeString(paramString);
            if (paramBundle != null)
            {
              localParcel.writeInt(1);
              paramBundle.writeToParcel(localParcel, 0);
              if (paramIMediaBrowserServiceCompatCallbacks != null)
              {
                paramString = paramIMediaBrowserServiceCompatCallbacks.asBinder();
                localParcel.writeStrongBinder(paramString);
                this.mRemote.transact(1, localParcel, null, 1);
              }
            }
            else
            {
              localParcel.writeInt(0);
              continue;
            }
            paramString = null;
          }
          finally
          {
            localParcel.recycle();
          }
        }
      }
      
      /* Error */
      public void disconnect(IMediaBrowserServiceCompatCallbacks paramIMediaBrowserServiceCompatCallbacks)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 30	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_2
        //   4: aload_2
        //   5: ldc 32
        //   7: invokevirtual 36	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   10: aload_1
        //   11: ifnull +34 -> 45
        //   14: aload_1
        //   15: invokeinterface 45 1 0
        //   20: astore_1
        //   21: aload_2
        //   22: aload_1
        //   23: invokevirtual 48	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   26: aload_0
        //   27: getfield 19	android/support/v4/media/IMediaBrowserServiceCompat$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   30: iconst_2
        //   31: aload_2
        //   32: aconst_null
        //   33: iconst_1
        //   34: invokeinterface 54 5 0
        //   39: pop
        //   40: aload_2
        //   41: invokevirtual 57	android/os/Parcel:recycle	()V
        //   44: return
        //   45: aconst_null
        //   46: astore_1
        //   47: goto -26 -> 21
        //   50: astore_1
        //   51: aload_2
        //   52: invokevirtual 57	android/os/Parcel:recycle	()V
        //   55: aload_1
        //   56: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	57	0	this	Proxy
        //   0	57	1	paramIMediaBrowserServiceCompatCallbacks	IMediaBrowserServiceCompatCallbacks
        //   3	49	2	localParcel	Parcel
        // Exception table:
        //   from	to	target	type
        //   4	10	50	finally
        //   14	21	50	finally
        //   21	40	50	finally
      }
      
      public String getInterfaceDescriptor()
      {
        return "android.support.v4.media.IMediaBrowserServiceCompat";
      }
      
      /* Error */
      public void getMediaItem(String paramString, ResultReceiver paramResultReceiver)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 30	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: aload_3
        //   5: ldc 32
        //   7: invokevirtual 36	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   10: aload_3
        //   11: aload_1
        //   12: invokevirtual 39	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   15: aload_2
        //   16: ifnull +33 -> 49
        //   19: aload_3
        //   20: iconst_1
        //   21: invokevirtual 64	android/os/Parcel:writeInt	(I)V
        //   24: aload_2
        //   25: aload_3
        //   26: iconst_0
        //   27: invokevirtual 79	android/support/v4/os/ResultReceiver:writeToParcel	(Landroid/os/Parcel;I)V
        //   30: aload_0
        //   31: getfield 19	android/support/v4/media/IMediaBrowserServiceCompat$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   34: iconst_5
        //   35: aload_3
        //   36: aconst_null
        //   37: iconst_1
        //   38: invokeinterface 54 5 0
        //   43: pop
        //   44: aload_3
        //   45: invokevirtual 57	android/os/Parcel:recycle	()V
        //   48: return
        //   49: aload_3
        //   50: iconst_0
        //   51: invokevirtual 64	android/os/Parcel:writeInt	(I)V
        //   54: goto -24 -> 30
        //   57: astore_1
        //   58: aload_3
        //   59: invokevirtual 57	android/os/Parcel:recycle	()V
        //   62: aload_1
        //   63: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	64	0	this	Proxy
        //   0	64	1	paramString	String
        //   0	64	2	paramResultReceiver	ResultReceiver
        //   3	56	3	localParcel	Parcel
        // Exception table:
        //   from	to	target	type
        //   4	15	57	finally
        //   19	30	57	finally
        //   30	44	57	finally
        //   49	54	57	finally
      }
      
      /* Error */
      public void removeSubscription(String paramString, IMediaBrowserServiceCompatCallbacks paramIMediaBrowserServiceCompatCallbacks)
        throws RemoteException
      {
        // Byte code:
        //   0: invokestatic 30	android/os/Parcel:obtain	()Landroid/os/Parcel;
        //   3: astore_3
        //   4: aload_3
        //   5: ldc 32
        //   7: invokevirtual 36	android/os/Parcel:writeInterfaceToken	(Ljava/lang/String;)V
        //   10: aload_3
        //   11: aload_1
        //   12: invokevirtual 39	android/os/Parcel:writeString	(Ljava/lang/String;)V
        //   15: aload_2
        //   16: ifnull +34 -> 50
        //   19: aload_2
        //   20: invokeinterface 45 1 0
        //   25: astore_1
        //   26: aload_3
        //   27: aload_1
        //   28: invokevirtual 48	android/os/Parcel:writeStrongBinder	(Landroid/os/IBinder;)V
        //   31: aload_0
        //   32: getfield 19	android/support/v4/media/IMediaBrowserServiceCompat$Stub$Proxy:mRemote	Landroid/os/IBinder;
        //   35: iconst_4
        //   36: aload_3
        //   37: aconst_null
        //   38: iconst_1
        //   39: invokeinterface 54 5 0
        //   44: pop
        //   45: aload_3
        //   46: invokevirtual 57	android/os/Parcel:recycle	()V
        //   49: return
        //   50: aconst_null
        //   51: astore_1
        //   52: goto -26 -> 26
        //   55: astore_1
        //   56: aload_3
        //   57: invokevirtual 57	android/os/Parcel:recycle	()V
        //   60: aload_1
        //   61: athrow
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	62	0	this	Proxy
        //   0	62	1	paramString	String
        //   0	62	2	paramIMediaBrowserServiceCompatCallbacks	IMediaBrowserServiceCompatCallbacks
        //   3	54	3	localParcel	Parcel
        // Exception table:
        //   from	to	target	type
        //   4	15	55	finally
        //   19	26	55	finally
        //   26	45	55	finally
      }
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/slocker/classes-dex2jar.jar!/android/support/v4/media/IMediaBrowserServiceCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */