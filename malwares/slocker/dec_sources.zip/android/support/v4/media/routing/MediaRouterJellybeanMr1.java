package android.support.v4.media.routing;

import android.content.Context;
import android.hardware.display.DisplayManager;
import android.media.MediaRouter;
import android.media.MediaRouter.RouteInfo;
import android.os.Build.VERSION;
import android.os.Handler;
import android.util.Log;
import android.view.Display;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

class MediaRouterJellybeanMr1
  extends MediaRouterJellybean
{
  private static final String TAG = "MediaRouterJellybeanMr1";
  
  public static Object createCallback(Callback paramCallback)
  {
    return new CallbackProxy(paramCallback);
  }
  
  public static final class ActiveScanWorkaround
    implements Runnable
  {
    private static final int WIFI_DISPLAY_SCAN_INTERVAL = 15000;
    private boolean mActivelyScanningWifiDisplays;
    private final DisplayManager mDisplayManager;
    private final Handler mHandler;
    private Method mScanWifiDisplaysMethod;
    
    public ActiveScanWorkaround(Context paramContext, Handler paramHandler)
    {
      if (Build.VERSION.SDK_INT != 17) {
        throw new UnsupportedOperationException();
      }
      this.mDisplayManager = ((DisplayManager)paramContext.getSystemService("display"));
      this.mHandler = paramHandler;
      try
      {
        this.mScanWifiDisplaysMethod = DisplayManager.class.getMethod("scanWifiDisplays", new Class[0]);
        return;
      }
      catch (NoSuchMethodException paramContext) {}
    }
    
    public void run()
    {
      if (this.mActivelyScanningWifiDisplays) {}
      try
      {
        this.mScanWifiDisplaysMethod.invoke(this.mDisplayManager, new Object[0]);
        this.mHandler.postDelayed(this, 15000L);
        return;
      }
      catch (IllegalAccessException localIllegalAccessException)
      {
        for (;;)
        {
          Log.w("MediaRouterJellybeanMr1", "Cannot scan for wifi displays.", localIllegalAccessException);
        }
      }
      catch (InvocationTargetException localInvocationTargetException)
      {
        for (;;)
        {
          Log.w("MediaRouterJellybeanMr1", "Cannot scan for wifi displays.", localInvocationTargetException);
        }
      }
    }
    
    public void setActiveScanRouteTypes(int paramInt)
    {
      if ((paramInt & 0x2) != 0) {
        if (!this.mActivelyScanningWifiDisplays)
        {
          if (this.mScanWifiDisplaysMethod == null) {
            break label35;
          }
          this.mActivelyScanningWifiDisplays = true;
          this.mHandler.post(this);
        }
      }
      label35:
      while (!this.mActivelyScanningWifiDisplays)
      {
        return;
        Log.w("MediaRouterJellybeanMr1", "Cannot scan for wifi displays because the DisplayManager.scanWifiDisplays() method is not available on this device.");
        return;
      }
      this.mActivelyScanningWifiDisplays = false;
      this.mHandler.removeCallbacks(this);
    }
  }
  
  public static abstract interface Callback
    extends MediaRouterJellybean.Callback
  {
    public abstract void onRoutePresentationDisplayChanged(Object paramObject);
  }
  
  static class CallbackProxy<T extends MediaRouterJellybeanMr1.Callback>
    extends MediaRouterJellybean.CallbackProxy<T>
  {
    public CallbackProxy(T paramT)
    {
      super();
    }
    
    public void onRoutePresentationDisplayChanged(MediaRouter paramMediaRouter, MediaRouter.RouteInfo paramRouteInfo)
    {
      ((MediaRouterJellybeanMr1.Callback)this.mCallback).onRoutePresentationDisplayChanged(paramRouteInfo);
    }
  }
  
  public static final class IsConnectingWorkaround
  {
    private Method mGetStatusCodeMethod;
    private int mStatusConnecting;
    
    public IsConnectingWorkaround()
    {
      if (Build.VERSION.SDK_INT != 17) {
        throw new UnsupportedOperationException();
      }
      try
      {
        this.mStatusConnecting = MediaRouter.RouteInfo.class.getField("STATUS_CONNECTING").getInt(null);
        this.mGetStatusCodeMethod = MediaRouter.RouteInfo.class.getMethod("getStatusCode", new Class[0]);
        return;
      }
      catch (NoSuchFieldException localNoSuchFieldException) {}catch (NoSuchMethodException localNoSuchMethodException) {}catch (IllegalAccessException localIllegalAccessException) {}
    }
    
    /* Error */
    public boolean isConnecting(Object paramObject)
    {
      // Byte code:
      //   0: aload_1
      //   1: checkcast 31	android/media/MediaRouter$RouteInfo
      //   4: astore_1
      //   5: aload_0
      //   6: getfield 55	android/support/v4/media/routing/MediaRouterJellybeanMr1$IsConnectingWorkaround:mGetStatusCodeMethod	Ljava/lang/reflect/Method;
      //   9: ifnull +45 -> 54
      //   12: aload_0
      //   13: getfield 55	android/support/v4/media/routing/MediaRouterJellybeanMr1$IsConnectingWorkaround:mGetStatusCodeMethod	Ljava/lang/reflect/Method;
      //   16: aload_1
      //   17: iconst_0
      //   18: anewarray 4	java/lang/Object
      //   21: invokevirtual 66	java/lang/reflect/Method:invoke	(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
      //   24: checkcast 68	java/lang/Integer
      //   27: invokevirtual 72	java/lang/Integer:intValue	()I
      //   30: istore_2
      //   31: aload_0
      //   32: getfield 47	android/support/v4/media/routing/MediaRouterJellybeanMr1$IsConnectingWorkaround:mStatusConnecting	I
      //   35: istore_3
      //   36: iload_2
      //   37: iload_3
      //   38: if_icmpne +9 -> 47
      //   41: iconst_1
      //   42: istore 4
      //   44: iload 4
      //   46: ireturn
      //   47: iconst_0
      //   48: istore 4
      //   50: goto -6 -> 44
      //   53: astore_1
      //   54: iconst_0
      //   55: ireturn
      //   56: astore_1
      //   57: goto -3 -> 54
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	60	0	this	IsConnectingWorkaround
      //   0	60	1	paramObject	Object
      //   30	9	2	i	int
      //   35	4	3	j	int
      //   42	7	4	bool	boolean
      // Exception table:
      //   from	to	target	type
      //   12	36	53	java/lang/IllegalAccessException
      //   12	36	56	java/lang/reflect/InvocationTargetException
    }
  }
  
  public static final class RouteInfo
  {
    public static Display getPresentationDisplay(Object paramObject)
    {
      return ((MediaRouter.RouteInfo)paramObject).getPresentationDisplay();
    }
    
    public static boolean isEnabled(Object paramObject)
    {
      return ((MediaRouter.RouteInfo)paramObject).isEnabled();
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/slocker/classes-dex2jar.jar!/android/support/v4/media/routing/MediaRouterJellybeanMr1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */