package android.support.v4.app;

class NotificationManagerCompatIceCreamSandwich
{
  static final int SIDE_CHANNEL_BIND_FLAGS = 33;
}


/* Location:              /home/enzo/Documents/hacking/malwares/slocker/classes-dex2jar.jar!/android/support/v4/app/NotificationManagerCompatIceCreamSandwich.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */