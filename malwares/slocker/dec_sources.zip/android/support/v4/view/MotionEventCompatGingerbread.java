package android.support.v4.view;

import android.view.MotionEvent;

class MotionEventCompatGingerbread
{
  public static int getSource(MotionEvent paramMotionEvent)
  {
    return paramMotionEvent.getSource();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/slocker/classes-dex2jar.jar!/android/support/v4/view/MotionEventCompatGingerbread.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */