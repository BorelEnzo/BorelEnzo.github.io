package android.support.v4.widget;

abstract interface DrawerLayoutImpl
{
  public abstract void setChildInsets(Object paramObject, boolean paramBoolean);
}


/* Location:              /home/enzo/Documents/hacking/malwares/slocker/classes-dex2jar.jar!/android/support/v4/widget/DrawerLayoutImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */