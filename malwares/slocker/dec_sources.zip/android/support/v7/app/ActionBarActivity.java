package android.support.v7.app;

@Deprecated
public class ActionBarActivity
  extends AppCompatActivity
{}


/* Location:              /home/enzo/Documents/hacking/malwares/slocker/classes-dex2jar.jar!/android/support/v7/app/ActionBarActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */