package android.support.design.widget;

class MathUtils
{
  static float constrain(float paramFloat1, float paramFloat2, float paramFloat3)
  {
    if (paramFloat1 < paramFloat2) {
      paramFloat1 = paramFloat2;
    }
    for (;;)
    {
      return paramFloat1;
      if (paramFloat1 > paramFloat3) {
        paramFloat1 = paramFloat3;
      }
    }
  }
  
  static int constrain(int paramInt1, int paramInt2, int paramInt3)
  {
    if (paramInt1 < paramInt2) {
      paramInt1 = paramInt2;
    }
    for (;;)
    {
      return paramInt1;
      if (paramInt1 > paramInt3) {
        paramInt1 = paramInt3;
      }
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/slocker/classes-dex2jar.jar!/android/support/design/widget/MathUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */