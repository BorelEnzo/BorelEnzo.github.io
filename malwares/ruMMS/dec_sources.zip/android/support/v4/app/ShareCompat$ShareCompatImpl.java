package android.support.v4.app;

import android.view.MenuItem;

abstract interface ShareCompat$ShareCompatImpl
{
  public abstract void configureMenuItem(MenuItem paramMenuItem, ShareCompat.IntentBuilder paramIntentBuilder);
  
  public abstract String escapeHtml(CharSequence paramCharSequence);
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/ShareCompat$ShareCompatImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */