package android.support.v4.app;

import java.util.ArrayList;

final class BackStackRecord$Op
{
  int cmd;
  int enterAnim;
  int exitAnim;
  Fragment fragment;
  Op next;
  int popEnterAnim;
  int popExitAnim;
  Op prev;
  ArrayList removed;
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/BackStackRecord$Op.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */