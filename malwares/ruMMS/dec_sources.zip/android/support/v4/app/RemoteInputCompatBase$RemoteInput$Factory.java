package android.support.v4.app;

import android.os.Bundle;

public abstract interface RemoteInputCompatBase$RemoteInput$Factory
{
  public abstract RemoteInputCompatBase.RemoteInput build(String paramString, CharSequence paramCharSequence, CharSequence[] paramArrayOfCharSequence, boolean paramBoolean, Bundle paramBundle);
  
  public abstract RemoteInputCompatBase.RemoteInput[] newArray(int paramInt);
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/RemoteInputCompatBase$RemoteInput$Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */