package android.support.v4.app;

import android.content.Intent;
import android.os.Bundle;

abstract interface RemoteInput$Impl
{
  public abstract void addResultsToIntent(RemoteInput[] paramArrayOfRemoteInput, Intent paramIntent, Bundle paramBundle);
  
  public abstract Bundle getResultsFromIntent(Intent paramIntent);
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/RemoteInput$Impl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */