package android.support.v4.app;

import android.view.View;

class BackStackRecord$1
  implements FragmentTransitionCompat21.ViewRetriever
{
  BackStackRecord$1(BackStackRecord paramBackStackRecord, Fragment paramFragment) {}
  
  public View getView()
  {
    return this.val$inFragment.getView();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/BackStackRecord$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */