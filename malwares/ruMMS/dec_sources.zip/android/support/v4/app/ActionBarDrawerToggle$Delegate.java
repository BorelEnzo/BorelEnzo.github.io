package android.support.v4.app;

import android.graphics.drawable.Drawable;

public abstract interface ActionBarDrawerToggle$Delegate
{
  public abstract Drawable getThemeUpIndicator();
  
  public abstract void setActionBarDescription(int paramInt);
  
  public abstract void setActionBarUpIndicator(Drawable paramDrawable, int paramInt);
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/ActionBarDrawerToggle$Delegate.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */