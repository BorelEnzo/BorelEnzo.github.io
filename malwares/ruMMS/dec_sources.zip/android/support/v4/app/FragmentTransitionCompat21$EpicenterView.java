package android.support.v4.app;

import android.view.View;

public class FragmentTransitionCompat21$EpicenterView
{
  public View epicenter;
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/FragmentTransitionCompat21$EpicenterView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */