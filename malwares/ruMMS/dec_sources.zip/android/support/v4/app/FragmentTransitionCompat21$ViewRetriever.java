package android.support.v4.app;

import android.view.View;

public abstract interface FragmentTransitionCompat21$ViewRetriever
{
  public abstract View getView();
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/FragmentTransitionCompat21$ViewRetriever.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */