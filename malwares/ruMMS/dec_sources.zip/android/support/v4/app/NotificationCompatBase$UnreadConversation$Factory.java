package android.support.v4.app;

import android.app.PendingIntent;

public abstract interface NotificationCompatBase$UnreadConversation$Factory
{
  public abstract NotificationCompatBase.UnreadConversation build(String[] paramArrayOfString1, RemoteInputCompatBase.RemoteInput paramRemoteInput, PendingIntent paramPendingIntent1, PendingIntent paramPendingIntent2, String[] paramArrayOfString2, long paramLong);
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/NotificationCompatBase$UnreadConversation$Factory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */