package android.support.v4.app;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.SOURCE)
@interface FragmentTransaction$Transit {}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/FragmentTransaction$Transit.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */