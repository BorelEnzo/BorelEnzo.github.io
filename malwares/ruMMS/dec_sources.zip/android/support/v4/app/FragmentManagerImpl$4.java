package android.support.v4.app;

class FragmentManagerImpl$4
  implements Runnable
{
  FragmentManagerImpl$4(FragmentManagerImpl paramFragmentManagerImpl, int paramInt1, int paramInt2) {}
  
  public void run()
  {
    this.this$0.popBackStackState(this.this$0.mHost.getHandler(), null, this.val$id, this.val$flags);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/FragmentManagerImpl$4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */