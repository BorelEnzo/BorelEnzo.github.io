package android.support.v4.app;

public abstract interface ActivityCompatApi23$RequestPermissionsRequestCodeValidator
{
  public abstract void validateRequestPermissionsRequestCode(int paramInt);
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/ActivityCompatApi23$RequestPermissionsRequestCodeValidator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */