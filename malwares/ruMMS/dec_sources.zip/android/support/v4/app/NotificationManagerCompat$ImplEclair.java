package android.support.v4.app;

import android.app.Notification;
import android.app.NotificationManager;

class NotificationManagerCompat$ImplEclair
  extends NotificationManagerCompat.ImplBase
{
  public void cancelNotification(NotificationManager paramNotificationManager, String paramString, int paramInt)
  {
    NotificationManagerCompatEclair.cancelNotification(paramNotificationManager, paramString, paramInt);
  }
  
  public void postNotification(NotificationManager paramNotificationManager, String paramString, int paramInt, Notification paramNotification)
  {
    NotificationManagerCompatEclair.postNotification(paramNotificationManager, paramString, paramInt, paramNotification);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/NotificationManagerCompat$ImplEclair.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */