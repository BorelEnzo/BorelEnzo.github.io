package android.support.v4.app;

import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;

class FragmentManagerImpl$AnimateOnHWLayerIfNeededListener
  implements Animation.AnimationListener
{
  private Animation.AnimationListener mOrignalListener = null;
  private boolean mShouldRunOnHWLayer = false;
  private View mView = null;
  
  public FragmentManagerImpl$AnimateOnHWLayerIfNeededListener(View paramView, Animation paramAnimation)
  {
    if ((paramView == null) || (paramAnimation == null)) {
      return;
    }
    this.mView = paramView;
  }
  
  public FragmentManagerImpl$AnimateOnHWLayerIfNeededListener(View paramView, Animation paramAnimation, Animation.AnimationListener paramAnimationListener)
  {
    if ((paramView == null) || (paramAnimation == null)) {
      return;
    }
    this.mOrignalListener = paramAnimationListener;
    this.mView = paramView;
  }
  
  public void onAnimationEnd(Animation paramAnimation)
  {
    if ((this.mView != null) && (this.mShouldRunOnHWLayer)) {
      this.mView.post(new FragmentManagerImpl.AnimateOnHWLayerIfNeededListener.2(this));
    }
    if (this.mOrignalListener != null) {
      this.mOrignalListener.onAnimationEnd(paramAnimation);
    }
  }
  
  public void onAnimationRepeat(Animation paramAnimation)
  {
    if (this.mOrignalListener != null) {
      this.mOrignalListener.onAnimationRepeat(paramAnimation);
    }
  }
  
  public void onAnimationStart(Animation paramAnimation)
  {
    if (this.mView != null)
    {
      this.mShouldRunOnHWLayer = FragmentManagerImpl.shouldRunOnHWLayer(this.mView, paramAnimation);
      if (this.mShouldRunOnHWLayer) {
        this.mView.post(new FragmentManagerImpl.AnimateOnHWLayerIfNeededListener.1(this));
      }
    }
    if (this.mOrignalListener != null) {
      this.mOrignalListener.onAnimationStart(paramAnimation);
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/FragmentManagerImpl$AnimateOnHWLayerIfNeededListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */