package android.support.v4.app;

import android.os.Bundle;

final class FragmentTabHost$TabInfo
{
  private final Bundle args;
  private final Class clss;
  private Fragment fragment;
  private final String tag;
  
  FragmentTabHost$TabInfo(String paramString, Class paramClass, Bundle paramBundle)
  {
    this.tag = paramString;
    this.clss = paramClass;
    this.args = paramBundle;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/FragmentTabHost$TabInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */