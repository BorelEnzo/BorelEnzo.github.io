package android.support.v4.app;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

abstract interface TaskStackBuilder$TaskStackBuilderImpl
{
  public abstract PendingIntent getPendingIntent(Context paramContext, Intent[] paramArrayOfIntent, int paramInt1, int paramInt2, Bundle paramBundle);
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/TaskStackBuilder$TaskStackBuilderImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */