package android.support.v4.app;

import android.support.v4.util.ArrayMap;
import android.view.View;
import java.util.ArrayList;

public class BackStackRecord$TransitionState
{
  public FragmentTransitionCompat21.EpicenterView enteringEpicenterView = new FragmentTransitionCompat21.EpicenterView();
  public ArrayList hiddenFragmentViews = new ArrayList();
  public ArrayMap nameOverrides = new ArrayMap();
  public View nonExistentView;
  
  public BackStackRecord$TransitionState(BackStackRecord paramBackStackRecord) {}
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/BackStackRecord$TransitionState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */