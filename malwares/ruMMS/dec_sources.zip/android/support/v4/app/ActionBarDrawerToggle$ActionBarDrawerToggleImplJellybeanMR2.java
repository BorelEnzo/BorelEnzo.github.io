package android.support.v4.app;

import android.app.Activity;
import android.graphics.drawable.Drawable;

class ActionBarDrawerToggle$ActionBarDrawerToggleImplJellybeanMR2
  implements ActionBarDrawerToggle.ActionBarDrawerToggleImpl
{
  public Drawable getThemeUpIndicator(Activity paramActivity)
  {
    return ActionBarDrawerToggleJellybeanMR2.getThemeUpIndicator(paramActivity);
  }
  
  public Object setActionBarDescription(Object paramObject, Activity paramActivity, int paramInt)
  {
    return ActionBarDrawerToggleJellybeanMR2.setActionBarDescription(paramObject, paramActivity, paramInt);
  }
  
  public Object setActionBarUpIndicator(Object paramObject, Activity paramActivity, Drawable paramDrawable, int paramInt)
  {
    return ActionBarDrawerToggleJellybeanMR2.setActionBarUpIndicator(paramObject, paramActivity, paramDrawable, paramInt);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/ActionBarDrawerToggle$ActionBarDrawerToggleImplJellybeanMR2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */