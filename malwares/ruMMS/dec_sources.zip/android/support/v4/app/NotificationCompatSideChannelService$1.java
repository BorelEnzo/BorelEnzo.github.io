package android.support.v4.app;

class NotificationCompatSideChannelService$1 {}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/NotificationCompatSideChannelService$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */