package android.support.v4.app;

import android.support.v4.view.ViewCompat;

class FragmentManagerImpl$AnimateOnHWLayerIfNeededListener$2
  implements Runnable
{
  FragmentManagerImpl$AnimateOnHWLayerIfNeededListener$2(FragmentManagerImpl.AnimateOnHWLayerIfNeededListener paramAnimateOnHWLayerIfNeededListener) {}
  
  public void run()
  {
    ViewCompat.setLayerType(FragmentManagerImpl.AnimateOnHWLayerIfNeededListener.access$000(this.this$0), 0, null);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/FragmentManagerImpl$AnimateOnHWLayerIfNeededListener$2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */