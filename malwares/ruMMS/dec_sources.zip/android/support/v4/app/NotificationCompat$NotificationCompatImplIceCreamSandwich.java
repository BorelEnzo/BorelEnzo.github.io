package android.support.v4.app;

import android.app.Notification;

class NotificationCompat$NotificationCompatImplIceCreamSandwich
  extends NotificationCompat.NotificationCompatImplBase
{
  public Notification build(NotificationCompat.Builder paramBuilder, NotificationCompat.BuilderExtender paramBuilderExtender)
  {
    return paramBuilderExtender.build(paramBuilder, new NotificationCompatIceCreamSandwich.Builder(paramBuilder.mContext, paramBuilder.mNotification, paramBuilder.mContentTitle, paramBuilder.mContentText, paramBuilder.mContentInfo, paramBuilder.mTickerView, paramBuilder.mNumber, paramBuilder.mContentIntent, paramBuilder.mFullScreenIntent, paramBuilder.mLargeIcon, paramBuilder.mProgressMax, paramBuilder.mProgress, paramBuilder.mProgressIndeterminate));
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/NotificationCompat$NotificationCompatImplIceCreamSandwich.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */