package android.support.v4.app;

import android.content.Intent;

public abstract interface TaskStackBuilder$SupportParentable
{
  public abstract Intent getSupportParentActivityIntent();
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/TaskStackBuilder$SupportParentable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */