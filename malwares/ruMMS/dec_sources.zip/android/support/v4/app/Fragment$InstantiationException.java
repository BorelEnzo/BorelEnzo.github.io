package android.support.v4.app;

public class Fragment$InstantiationException
  extends RuntimeException
{
  public Fragment$InstantiationException(String paramString, Exception paramException)
  {
    super(paramString, paramException);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/Fragment$InstantiationException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */