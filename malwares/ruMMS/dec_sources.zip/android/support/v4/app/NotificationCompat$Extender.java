package android.support.v4.app;

public abstract interface NotificationCompat$Extender
{
  public abstract NotificationCompat.Builder extend(NotificationCompat.Builder paramBuilder);
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/NotificationCompat$Extender.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */