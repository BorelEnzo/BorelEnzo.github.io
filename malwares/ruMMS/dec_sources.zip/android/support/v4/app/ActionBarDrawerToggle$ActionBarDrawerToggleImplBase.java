package android.support.v4.app;

import android.app.Activity;
import android.graphics.drawable.Drawable;

class ActionBarDrawerToggle$ActionBarDrawerToggleImplBase
  implements ActionBarDrawerToggle.ActionBarDrawerToggleImpl
{
  public Drawable getThemeUpIndicator(Activity paramActivity)
  {
    return null;
  }
  
  public Object setActionBarDescription(Object paramObject, Activity paramActivity, int paramInt)
  {
    return paramObject;
  }
  
  public Object setActionBarUpIndicator(Object paramObject, Activity paramActivity, Drawable paramDrawable, int paramInt)
  {
    return paramObject;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/ActionBarDrawerToggle$ActionBarDrawerToggleImplBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */