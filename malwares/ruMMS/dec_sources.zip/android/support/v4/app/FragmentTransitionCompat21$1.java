package android.support.v4.app;

import android.graphics.Rect;
import android.transition.Transition;
import android.transition.Transition.EpicenterCallback;

final class FragmentTransitionCompat21$1
  extends Transition.EpicenterCallback
{
  FragmentTransitionCompat21$1(Rect paramRect) {}
  
  public Rect onGetEpicenter(Transition paramTransition)
  {
    return this.val$epicenter;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/FragmentTransitionCompat21$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */