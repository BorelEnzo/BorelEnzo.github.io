package android.support.v4.app;

import android.support.v4.util.SimpleArrayMap;
import java.util.List;

final class FragmentActivity$NonConfigurationInstances
{
  Object custom;
  List fragments;
  SimpleArrayMap loaders;
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/FragmentActivity$NonConfigurationInstances.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */