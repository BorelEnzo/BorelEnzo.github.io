package android.support.v4.app;

class FragmentManagerImpl$FragmentTag
{
  public static final int[] Fragment = { 16842755, 16842960, 16842961 };
  public static final int Fragment_id = 1;
  public static final int Fragment_name = 0;
  public static final int Fragment_tag = 2;
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/FragmentManagerImpl$FragmentTag.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */