package android.support.v4.app;

import android.content.Context;

class AppOpsManagerCompat$AppOpsManagerImpl
{
  public int noteOp(Context paramContext, String paramString1, int paramInt, String paramString2)
  {
    return 1;
  }
  
  public int noteProxyOp(Context paramContext, String paramString1, String paramString2)
  {
    return 1;
  }
  
  public String permissionToOp(String paramString)
  {
    return null;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/app/AppOpsManagerCompat$AppOpsManagerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */