package android.support.v4.hardware.fingerprint;

public abstract class FingerprintManagerCompatApi23$AuthenticationCallback
{
  public void onAuthenticationError(int paramInt, CharSequence paramCharSequence) {}
  
  public void onAuthenticationFailed() {}
  
  public void onAuthenticationHelp(int paramInt, CharSequence paramCharSequence) {}
  
  public void onAuthenticationSucceeded(FingerprintManagerCompatApi23.AuthenticationResultInternal paramAuthenticationResultInternal) {}
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/hardware/fingerprint/FingerprintManagerCompatApi23$AuthenticationCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */