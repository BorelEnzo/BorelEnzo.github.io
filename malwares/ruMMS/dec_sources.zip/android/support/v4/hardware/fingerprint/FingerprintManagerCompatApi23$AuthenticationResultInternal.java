package android.support.v4.hardware.fingerprint;

public final class FingerprintManagerCompatApi23$AuthenticationResultInternal
{
  private FingerprintManagerCompatApi23.CryptoObject mCryptoObject;
  
  public FingerprintManagerCompatApi23$AuthenticationResultInternal(FingerprintManagerCompatApi23.CryptoObject paramCryptoObject)
  {
    this.mCryptoObject = paramCryptoObject;
  }
  
  public FingerprintManagerCompatApi23.CryptoObject getCryptoObject()
  {
    return this.mCryptoObject;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/hardware/fingerprint/FingerprintManagerCompatApi23$AuthenticationResultInternal.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */