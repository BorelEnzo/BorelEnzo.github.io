package android.support.v4.media;

import android.support.v4.os.ResultReceiver;

class MediaBrowserServiceCompat$ServiceBinder$5
  implements Runnable
{
  MediaBrowserServiceCompat$ServiceBinder$5(MediaBrowserServiceCompat.ServiceBinder paramServiceBinder, String paramString, ResultReceiver paramResultReceiver) {}
  
  public void run()
  {
    MediaBrowserServiceCompat.access$500(this.this$1.this$0, this.val$mediaId, this.val$receiver);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/MediaBrowserServiceCompat$ServiceBinder$5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */