package android.support.v4.media.session;

import android.net.Uri;
import android.os.Bundle;

class MediaSessionCompat$Callback$StubApi23
  extends MediaSessionCompat.Callback.StubApi21
  implements MediaSessionCompatApi23.Callback
{
  private MediaSessionCompat$Callback$StubApi23(MediaSessionCompat.Callback paramCallback)
  {
    super(paramCallback, null);
  }
  
  public void onPlayFromUri(Uri paramUri, Bundle paramBundle)
  {
    this.this$0.onPlayFromUri(paramUri, paramBundle);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/session/MediaSessionCompat$Callback$StubApi23.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */