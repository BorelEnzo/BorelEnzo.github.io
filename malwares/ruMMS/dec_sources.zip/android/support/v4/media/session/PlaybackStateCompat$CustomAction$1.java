package android.support.v4.media.session;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class PlaybackStateCompat$CustomAction$1
  implements Parcelable.Creator
{
  public PlaybackStateCompat.CustomAction createFromParcel(Parcel paramParcel)
  {
    return new PlaybackStateCompat.CustomAction(paramParcel, null);
  }
  
  public PlaybackStateCompat.CustomAction[] newArray(int paramInt)
  {
    return new PlaybackStateCompat.CustomAction[paramInt];
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/session/PlaybackStateCompat$CustomAction$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */