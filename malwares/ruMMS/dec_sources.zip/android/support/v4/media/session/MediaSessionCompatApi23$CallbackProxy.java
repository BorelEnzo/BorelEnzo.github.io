package android.support.v4.media.session;

import android.net.Uri;
import android.os.Bundle;

class MediaSessionCompatApi23$CallbackProxy
  extends MediaSessionCompatApi21.CallbackProxy
{
  public MediaSessionCompatApi23$CallbackProxy(MediaSessionCompatApi23.Callback paramCallback)
  {
    super(paramCallback);
  }
  
  public void onPlayFromUri(Uri paramUri, Bundle paramBundle)
  {
    ((MediaSessionCompatApi23.Callback)this.mCallback).onPlayFromUri(paramUri, paramBundle);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/session/MediaSessionCompatApi23$CallbackProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */