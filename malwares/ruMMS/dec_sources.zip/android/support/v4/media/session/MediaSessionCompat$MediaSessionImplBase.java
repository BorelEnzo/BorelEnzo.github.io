package android.support.v4.media.session;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.media.AudioManager;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.os.SystemClock;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.VolumeProviderCompat;
import android.support.v4.media.VolumeProviderCompat.Callback;
import java.util.List;

class MediaSessionCompat$MediaSessionImplBase
  implements MediaSessionCompat.MediaSessionImpl
{
  private final AudioManager mAudioManager;
  private MediaSessionCompat.Callback mCallback;
  private final ComponentName mComponentName;
  private final Context mContext;
  private final RemoteCallbackList mControllerCallbacks = new RemoteCallbackList();
  private boolean mDestroyed = false;
  private Bundle mExtras;
  private int mFlags;
  private final MediaSessionCompat.MediaSessionImplBase.MessageHandler mHandler;
  private boolean mIsActive = false;
  private boolean mIsMbrRegistered = false;
  private boolean mIsRccRegistered = false;
  private int mLocalStream;
  private final Object mLock = new Object();
  private final PendingIntent mMediaButtonEventReceiver;
  private MediaMetadataCompat mMetadata;
  private final String mPackageName;
  private List mQueue;
  private CharSequence mQueueTitle;
  private int mRatingType;
  private final Object mRccObj;
  private PendingIntent mSessionActivity;
  private PlaybackStateCompat mState;
  private final MediaSessionCompat.MediaSessionImplBase.MediaSessionStub mStub;
  private final String mTag;
  private final MediaSessionCompat.Token mToken;
  private VolumeProviderCompat.Callback mVolumeCallback = new MediaSessionCompat.MediaSessionImplBase.1(this);
  private VolumeProviderCompat mVolumeProvider;
  private int mVolumeType;
  
  public MediaSessionCompat$MediaSessionImplBase(Context paramContext, String paramString, ComponentName paramComponentName, PendingIntent paramPendingIntent)
  {
    if (paramComponentName == null) {
      throw new IllegalArgumentException("MediaButtonReceiver component may not be null.");
    }
    this.mContext = paramContext;
    this.mPackageName = paramContext.getPackageName();
    this.mAudioManager = ((AudioManager)paramContext.getSystemService("audio"));
    this.mTag = paramString;
    this.mComponentName = paramComponentName;
    this.mMediaButtonEventReceiver = paramPendingIntent;
    this.mStub = new MediaSessionCompat.MediaSessionImplBase.MediaSessionStub(this);
    this.mToken = new MediaSessionCompat.Token(this.mStub);
    this.mHandler = new MediaSessionCompat.MediaSessionImplBase.MessageHandler(this, Looper.myLooper());
    this.mRatingType = 0;
    this.mVolumeType = 1;
    this.mLocalStream = 3;
    if (Build.VERSION.SDK_INT >= 14)
    {
      this.mRccObj = MediaSessionCompatApi14.createRemoteControlClient(paramPendingIntent);
      return;
    }
    this.mRccObj = null;
  }
  
  private void adjustVolume(int paramInt1, int paramInt2)
  {
    if (this.mVolumeType == 2)
    {
      if (this.mVolumeProvider != null) {
        this.mVolumeProvider.onAdjustVolume(paramInt1);
      }
      return;
    }
    this.mAudioManager.adjustStreamVolume(this.mLocalStream, paramInt1, paramInt2);
  }
  
  private PlaybackStateCompat getStateWithUpdatedPosition()
  {
    long l2 = -1L;
    for (;;)
    {
      long l1;
      synchronized (this.mLock)
      {
        PlaybackStateCompat localPlaybackStateCompat = this.mState;
        l1 = l2;
        if (this.mMetadata != null)
        {
          l1 = l2;
          if (this.mMetadata.containsKey("android.media.metadata.DURATION")) {
            l1 = this.mMetadata.getLong("android.media.metadata.DURATION");
          }
        }
        if ((localPlaybackStateCompat == null) || ((localPlaybackStateCompat.getState() != 3) && (localPlaybackStateCompat.getState() != 4) && (localPlaybackStateCompat.getState() != 5))) {
          break label212;
        }
        l2 = localPlaybackStateCompat.getLastPositionUpdateTime();
        long l3 = SystemClock.elapsedRealtime();
        if (l2 <= 0L) {
          break label212;
        }
        l2 = (localPlaybackStateCompat.getPlaybackSpeed() * (float)(l3 - l2)) + localPlaybackStateCompat.getPosition();
        if ((l1 >= 0L) && (l2 > l1))
        {
          ??? = new PlaybackStateCompat.Builder(localPlaybackStateCompat);
          ((PlaybackStateCompat.Builder)???).setState(localPlaybackStateCompat.getState(), l1, localPlaybackStateCompat.getPlaybackSpeed(), l3);
          ??? = ((PlaybackStateCompat.Builder)???).build();
          Object localObject2 = ???;
          if (??? == null) {
            localObject2 = localPlaybackStateCompat;
          }
          return (PlaybackStateCompat)localObject2;
        }
      }
      if (l2 < 0L)
      {
        l1 = 0L;
      }
      else
      {
        l1 = l2;
        continue;
        label212:
        ??? = null;
      }
    }
  }
  
  private void sendEvent(String paramString, Bundle paramBundle)
  {
    int i = this.mControllerCallbacks.beginBroadcast() - 1;
    for (;;)
    {
      IMediaControllerCallback localIMediaControllerCallback;
      if (i >= 0) {
        localIMediaControllerCallback = (IMediaControllerCallback)this.mControllerCallbacks.getBroadcastItem(i);
      }
      try
      {
        localIMediaControllerCallback.onEvent(paramString, paramBundle);
        i -= 1;
        continue;
        this.mControllerCallbacks.finishBroadcast();
        return;
      }
      catch (RemoteException localRemoteException)
      {
        for (;;) {}
      }
    }
  }
  
  private void sendMetadata(MediaMetadataCompat paramMediaMetadataCompat)
  {
    int i = this.mControllerCallbacks.beginBroadcast() - 1;
    for (;;)
    {
      IMediaControllerCallback localIMediaControllerCallback;
      if (i >= 0) {
        localIMediaControllerCallback = (IMediaControllerCallback)this.mControllerCallbacks.getBroadcastItem(i);
      }
      try
      {
        localIMediaControllerCallback.onMetadataChanged(paramMediaMetadataCompat);
        i -= 1;
        continue;
        this.mControllerCallbacks.finishBroadcast();
        return;
      }
      catch (RemoteException localRemoteException)
      {
        for (;;) {}
      }
    }
  }
  
  private void sendQueue(List paramList)
  {
    int i = this.mControllerCallbacks.beginBroadcast() - 1;
    for (;;)
    {
      IMediaControllerCallback localIMediaControllerCallback;
      if (i >= 0) {
        localIMediaControllerCallback = (IMediaControllerCallback)this.mControllerCallbacks.getBroadcastItem(i);
      }
      try
      {
        localIMediaControllerCallback.onQueueChanged(paramList);
        i -= 1;
        continue;
        this.mControllerCallbacks.finishBroadcast();
        return;
      }
      catch (RemoteException localRemoteException)
      {
        for (;;) {}
      }
    }
  }
  
  private void sendQueueTitle(CharSequence paramCharSequence)
  {
    int i = this.mControllerCallbacks.beginBroadcast() - 1;
    for (;;)
    {
      IMediaControllerCallback localIMediaControllerCallback;
      if (i >= 0) {
        localIMediaControllerCallback = (IMediaControllerCallback)this.mControllerCallbacks.getBroadcastItem(i);
      }
      try
      {
        localIMediaControllerCallback.onQueueTitleChanged(paramCharSequence);
        i -= 1;
        continue;
        this.mControllerCallbacks.finishBroadcast();
        return;
      }
      catch (RemoteException localRemoteException)
      {
        for (;;) {}
      }
    }
  }
  
  private void sendSessionDestroyed()
  {
    int i = this.mControllerCallbacks.beginBroadcast() - 1;
    for (;;)
    {
      IMediaControllerCallback localIMediaControllerCallback;
      if (i >= 0) {
        localIMediaControllerCallback = (IMediaControllerCallback)this.mControllerCallbacks.getBroadcastItem(i);
      }
      try
      {
        localIMediaControllerCallback.onSessionDestroyed();
        i -= 1;
        continue;
        this.mControllerCallbacks.finishBroadcast();
        this.mControllerCallbacks.kill();
        return;
      }
      catch (RemoteException localRemoteException)
      {
        for (;;) {}
      }
    }
  }
  
  private void sendState(PlaybackStateCompat paramPlaybackStateCompat)
  {
    int i = this.mControllerCallbacks.beginBroadcast() - 1;
    for (;;)
    {
      IMediaControllerCallback localIMediaControllerCallback;
      if (i >= 0) {
        localIMediaControllerCallback = (IMediaControllerCallback)this.mControllerCallbacks.getBroadcastItem(i);
      }
      try
      {
        localIMediaControllerCallback.onPlaybackStateChanged(paramPlaybackStateCompat);
        i -= 1;
        continue;
        this.mControllerCallbacks.finishBroadcast();
        return;
      }
      catch (RemoteException localRemoteException)
      {
        for (;;) {}
      }
    }
  }
  
  private void sendVolumeInfoChanged(ParcelableVolumeInfo paramParcelableVolumeInfo)
  {
    int i = this.mControllerCallbacks.beginBroadcast() - 1;
    for (;;)
    {
      IMediaControllerCallback localIMediaControllerCallback;
      if (i >= 0) {
        localIMediaControllerCallback = (IMediaControllerCallback)this.mControllerCallbacks.getBroadcastItem(i);
      }
      try
      {
        localIMediaControllerCallback.onVolumeInfoChanged(paramParcelableVolumeInfo);
        i -= 1;
        continue;
        this.mControllerCallbacks.finishBroadcast();
        return;
      }
      catch (RemoteException localRemoteException)
      {
        for (;;) {}
      }
    }
  }
  
  private void setVolumeTo(int paramInt1, int paramInt2)
  {
    if (this.mVolumeType == 2)
    {
      if (this.mVolumeProvider != null) {
        this.mVolumeProvider.onSetVolumeTo(paramInt1);
      }
      return;
    }
    this.mAudioManager.setStreamVolume(this.mLocalStream, paramInt1, paramInt2);
  }
  
  private boolean update()
  {
    if (this.mIsActive)
    {
      if (Build.VERSION.SDK_INT >= 8)
      {
        if ((this.mIsMbrRegistered) || ((this.mFlags & 0x1) == 0)) {
          break label115;
        }
        if (Build.VERSION.SDK_INT < 18) {
          break label101;
        }
        MediaSessionCompatApi18.registerMediaButtonEventReceiver(this.mContext, this.mMediaButtonEventReceiver, this.mComponentName);
        this.mIsMbrRegistered = true;
      }
      label101:
      label115:
      while ((!this.mIsMbrRegistered) || ((this.mFlags & 0x1) != 0)) {
        for (;;)
        {
          if (Build.VERSION.SDK_INT < 14) {
            break label284;
          }
          if ((this.mIsRccRegistered) || ((this.mFlags & 0x2) == 0)) {
            break;
          }
          MediaSessionCompatApi14.registerRemoteControlClient(this.mContext, this.mRccObj);
          this.mIsRccRegistered = true;
          return true;
          MediaSessionCompatApi8.registerMediaButtonEventReceiver(this.mContext, this.mComponentName);
        }
      }
      if (Build.VERSION.SDK_INT >= 18) {
        MediaSessionCompatApi18.unregisterMediaButtonEventReceiver(this.mContext, this.mMediaButtonEventReceiver, this.mComponentName);
      }
      for (;;)
      {
        this.mIsMbrRegistered = false;
        break;
        MediaSessionCompatApi8.unregisterMediaButtonEventReceiver(this.mContext, this.mComponentName);
      }
      if ((this.mIsRccRegistered) && ((this.mFlags & 0x2) == 0))
      {
        MediaSessionCompatApi14.setState(this.mRccObj, 0);
        MediaSessionCompatApi14.unregisterRemoteControlClient(this.mContext, this.mRccObj);
        this.mIsRccRegistered = false;
        return false;
      }
    }
    else if (this.mIsMbrRegistered)
    {
      if (Build.VERSION.SDK_INT < 18) {
        break label286;
      }
      MediaSessionCompatApi18.unregisterMediaButtonEventReceiver(this.mContext, this.mMediaButtonEventReceiver, this.mComponentName);
    }
    for (;;)
    {
      this.mIsMbrRegistered = false;
      if (this.mIsRccRegistered)
      {
        MediaSessionCompatApi14.setState(this.mRccObj, 0);
        MediaSessionCompatApi14.unregisterRemoteControlClient(this.mContext, this.mRccObj);
        this.mIsRccRegistered = false;
      }
      label284:
      return false;
      label286:
      MediaSessionCompatApi8.unregisterMediaButtonEventReceiver(this.mContext, this.mComponentName);
    }
  }
  
  public Object getMediaSession()
  {
    return null;
  }
  
  public Object getRemoteControlClient()
  {
    return this.mRccObj;
  }
  
  public MediaSessionCompat.Token getSessionToken()
  {
    return this.mToken;
  }
  
  public boolean isActive()
  {
    return this.mIsActive;
  }
  
  public void release()
  {
    this.mIsActive = false;
    this.mDestroyed = true;
    update();
    sendSessionDestroyed();
  }
  
  public void sendSessionEvent(String paramString, Bundle paramBundle)
  {
    sendEvent(paramString, paramBundle);
  }
  
  public void setActive(boolean paramBoolean)
  {
    if (paramBoolean == this.mIsActive) {}
    do
    {
      return;
      this.mIsActive = paramBoolean;
    } while (!update());
    setMetadata(this.mMetadata);
    setPlaybackState(this.mState);
  }
  
  public void setCallback(MediaSessionCompat.Callback paramCallback, Handler paramHandler)
  {
    if (paramCallback == this.mCallback) {
      return;
    }
    if ((paramCallback == null) || (Build.VERSION.SDK_INT < 18))
    {
      if (Build.VERSION.SDK_INT >= 18) {
        MediaSessionCompatApi18.setOnPlaybackPositionUpdateListener(this.mRccObj, null);
      }
      if (Build.VERSION.SDK_INT >= 19) {
        MediaSessionCompatApi19.setOnMetadataUpdateListener(this.mRccObj, null);
      }
    }
    for (;;)
    {
      this.mCallback = paramCallback;
      return;
      if (paramHandler == null) {
        new Handler();
      }
      paramHandler = new MediaSessionCompat.MediaSessionImplBase.2(this, paramCallback);
      if (Build.VERSION.SDK_INT >= 18)
      {
        Object localObject = MediaSessionCompatApi18.createPlaybackPositionUpdateListener(paramHandler);
        MediaSessionCompatApi18.setOnPlaybackPositionUpdateListener(this.mRccObj, localObject);
      }
      if (Build.VERSION.SDK_INT >= 19)
      {
        paramHandler = MediaSessionCompatApi19.createMetadataUpdateListener(paramHandler);
        MediaSessionCompatApi19.setOnMetadataUpdateListener(this.mRccObj, paramHandler);
      }
    }
  }
  
  public void setExtras(Bundle paramBundle)
  {
    this.mExtras = paramBundle;
  }
  
  public void setFlags(int paramInt)
  {
    synchronized (this.mLock)
    {
      this.mFlags = paramInt;
      update();
      return;
    }
  }
  
  public void setMediaButtonReceiver(PendingIntent paramPendingIntent) {}
  
  public void setMetadata(MediaMetadataCompat paramMediaMetadataCompat)
  {
    Object localObject2 = null;
    Object localObject1 = null;
    label88:
    do
    {
      synchronized (this.mLock)
      {
        this.mMetadata = paramMediaMetadataCompat;
        sendMetadata(paramMediaMetadataCompat);
        if (!this.mIsActive) {
          return;
        }
      }
      if (Build.VERSION.SDK_INT >= 19)
      {
        localObject2 = this.mRccObj;
        if (paramMediaMetadataCompat == null)
        {
          paramMediaMetadataCompat = (MediaMetadataCompat)localObject1;
          if (this.mState != null) {
            break label88;
          }
        }
        for (long l = 0L;; l = this.mState.getActions())
        {
          MediaSessionCompatApi19.setMetadata(localObject2, paramMediaMetadataCompat, l);
          return;
          paramMediaMetadataCompat = paramMediaMetadataCompat.getBundle();
          break;
        }
      }
    } while (Build.VERSION.SDK_INT < 14);
    localObject1 = this.mRccObj;
    if (paramMediaMetadataCompat == null) {}
    for (paramMediaMetadataCompat = (MediaMetadataCompat)localObject2;; paramMediaMetadataCompat = paramMediaMetadataCompat.getBundle())
    {
      MediaSessionCompatApi14.setMetadata(localObject1, paramMediaMetadataCompat);
      return;
    }
  }
  
  public void setPlaybackState(PlaybackStateCompat paramPlaybackStateCompat)
  {
    do
    {
      do
      {
        synchronized (this.mLock)
        {
          this.mState = paramPlaybackStateCompat;
          sendState(paramPlaybackStateCompat);
          if (!this.mIsActive) {
            return;
          }
        }
        if (paramPlaybackStateCompat != null) {
          break;
        }
      } while (Build.VERSION.SDK_INT < 14);
      MediaSessionCompatApi14.setState(this.mRccObj, 0);
      MediaSessionCompatApi14.setTransportControlFlags(this.mRccObj, 0L);
      return;
      if (Build.VERSION.SDK_INT >= 18) {
        MediaSessionCompatApi18.setState(this.mRccObj, paramPlaybackStateCompat.getState(), paramPlaybackStateCompat.getPosition(), paramPlaybackStateCompat.getPlaybackSpeed(), paramPlaybackStateCompat.getLastPositionUpdateTime());
      }
      while (Build.VERSION.SDK_INT >= 19)
      {
        MediaSessionCompatApi19.setTransportControlFlags(this.mRccObj, paramPlaybackStateCompat.getActions());
        return;
        if (Build.VERSION.SDK_INT >= 14) {
          MediaSessionCompatApi14.setState(this.mRccObj, paramPlaybackStateCompat.getState());
        }
      }
      if (Build.VERSION.SDK_INT >= 18)
      {
        MediaSessionCompatApi18.setTransportControlFlags(this.mRccObj, paramPlaybackStateCompat.getActions());
        return;
      }
    } while (Build.VERSION.SDK_INT < 14);
    MediaSessionCompatApi14.setTransportControlFlags(this.mRccObj, paramPlaybackStateCompat.getActions());
  }
  
  public void setPlaybackToLocal(int paramInt)
  {
    if (this.mVolumeProvider != null) {
      this.mVolumeProvider.setCallback(null);
    }
    this.mVolumeType = 1;
    sendVolumeInfoChanged(new ParcelableVolumeInfo(this.mVolumeType, this.mLocalStream, 2, this.mAudioManager.getStreamMaxVolume(this.mLocalStream), this.mAudioManager.getStreamVolume(this.mLocalStream)));
  }
  
  public void setPlaybackToRemote(VolumeProviderCompat paramVolumeProviderCompat)
  {
    if (paramVolumeProviderCompat == null) {
      throw new IllegalArgumentException("volumeProvider may not be null");
    }
    if (this.mVolumeProvider != null) {
      this.mVolumeProvider.setCallback(null);
    }
    this.mVolumeType = 2;
    this.mVolumeProvider = paramVolumeProviderCompat;
    sendVolumeInfoChanged(new ParcelableVolumeInfo(this.mVolumeType, this.mLocalStream, this.mVolumeProvider.getVolumeControl(), this.mVolumeProvider.getMaxVolume(), this.mVolumeProvider.getCurrentVolume()));
    paramVolumeProviderCompat.setCallback(this.mVolumeCallback);
  }
  
  public void setQueue(List paramList)
  {
    this.mQueue = paramList;
    sendQueue(paramList);
  }
  
  public void setQueueTitle(CharSequence paramCharSequence)
  {
    this.mQueueTitle = paramCharSequence;
    sendQueueTitle(paramCharSequence);
  }
  
  public void setRatingType(int paramInt)
  {
    this.mRatingType = paramInt;
  }
  
  public void setSessionActivity(PendingIntent paramPendingIntent)
  {
    synchronized (this.mLock)
    {
      this.mSessionActivity = paramPendingIntent;
      return;
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/session/MediaSessionCompat$MediaSessionImplBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */