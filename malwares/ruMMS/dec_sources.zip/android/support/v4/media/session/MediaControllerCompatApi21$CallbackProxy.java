package android.support.v4.media.session;

import android.media.MediaMetadata;
import android.media.session.MediaController.Callback;
import android.media.session.PlaybackState;
import android.os.Bundle;

class MediaControllerCompatApi21$CallbackProxy
  extends MediaController.Callback
{
  protected final MediaControllerCompatApi21.Callback mCallback;
  
  public MediaControllerCompatApi21$CallbackProxy(MediaControllerCompatApi21.Callback paramCallback)
  {
    this.mCallback = paramCallback;
  }
  
  public void onMetadataChanged(MediaMetadata paramMediaMetadata)
  {
    this.mCallback.onMetadataChanged(paramMediaMetadata);
  }
  
  public void onPlaybackStateChanged(PlaybackState paramPlaybackState)
  {
    this.mCallback.onPlaybackStateChanged(paramPlaybackState);
  }
  
  public void onSessionDestroyed()
  {
    this.mCallback.onSessionDestroyed();
  }
  
  public void onSessionEvent(String paramString, Bundle paramBundle)
  {
    this.mCallback.onSessionEvent(paramString, paramBundle);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/session/MediaControllerCompatApi21$CallbackProxy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */