package android.support.v4.media.session;

import android.os.Parcel;
import android.os.Parcelable.Creator;

final class ParcelableVolumeInfo$1
  implements Parcelable.Creator
{
  public ParcelableVolumeInfo createFromParcel(Parcel paramParcel)
  {
    return new ParcelableVolumeInfo(paramParcel);
  }
  
  public ParcelableVolumeInfo[] newArray(int paramInt)
  {
    return new ParcelableVolumeInfo[paramInt];
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/session/ParcelableVolumeInfo$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */