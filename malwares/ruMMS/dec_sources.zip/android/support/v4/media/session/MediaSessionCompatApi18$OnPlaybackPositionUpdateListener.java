package android.support.v4.media.session;

import android.media.RemoteControlClient.OnPlaybackPositionUpdateListener;

class MediaSessionCompatApi18$OnPlaybackPositionUpdateListener
  implements RemoteControlClient.OnPlaybackPositionUpdateListener
{
  protected final MediaSessionCompatApi14.Callback mCallback;
  
  public MediaSessionCompatApi18$OnPlaybackPositionUpdateListener(MediaSessionCompatApi14.Callback paramCallback)
  {
    this.mCallback = paramCallback;
  }
  
  public void onPlaybackPositionUpdate(long paramLong)
  {
    this.mCallback.onSeekTo(paramLong);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/session/MediaSessionCompatApi18$OnPlaybackPositionUpdateListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */