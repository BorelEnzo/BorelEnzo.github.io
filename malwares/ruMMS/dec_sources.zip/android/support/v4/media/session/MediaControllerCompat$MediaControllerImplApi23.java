package android.support.v4.media.session;

import android.content.Context;

class MediaControllerCompat$MediaControllerImplApi23
  extends MediaControllerCompat.MediaControllerImplApi21
{
  public MediaControllerCompat$MediaControllerImplApi23(Context paramContext, MediaSessionCompat.Token paramToken)
  {
    super(paramContext, paramToken);
  }
  
  public MediaControllerCompat$MediaControllerImplApi23(Context paramContext, MediaSessionCompat paramMediaSessionCompat)
  {
    super(paramContext, paramMediaSessionCompat);
  }
  
  public MediaControllerCompat.TransportControls getTransportControls()
  {
    Object localObject = MediaControllerCompatApi21.getTransportControls(this.mControllerObj);
    if (localObject != null) {
      return new MediaControllerCompat.TransportControlsApi23(localObject);
    }
    return null;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/session/MediaControllerCompat$MediaControllerImplApi23.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */