package android.support.v4.media;

import android.support.v4.util.ArrayMap;
import java.util.Collections;
import java.util.List;

class MediaBrowserCompat$MediaBrowserImplBase$7
  implements Runnable
{
  MediaBrowserCompat$MediaBrowserImplBase$7(MediaBrowserCompat.MediaBrowserImplBase paramMediaBrowserImplBase, IMediaBrowserServiceCompatCallbacks paramIMediaBrowserServiceCompatCallbacks, List paramList, String paramString) {}
  
  public void run()
  {
    if (!MediaBrowserCompat.MediaBrowserImplBase.access$500(this.this$0, this.val$callback, "onLoadChildren")) {
      return;
    }
    List localList = this.val$list;
    if (localList == null) {
      localList = Collections.emptyList();
    }
    for (;;)
    {
      MediaBrowserCompat.MediaBrowserImplBase.Subscription localSubscription = (MediaBrowserCompat.MediaBrowserImplBase.Subscription)MediaBrowserCompat.MediaBrowserImplBase.access$1100(this.this$0).get(this.val$parentId);
      if (localSubscription == null) {
        break;
      }
      localSubscription.callback.onChildrenLoaded(this.val$parentId, localList);
      return;
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/MediaBrowserCompat$MediaBrowserImplBase$7.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */