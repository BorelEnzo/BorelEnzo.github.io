package android.support.v4.media.routing;

import android.media.MediaRouter.RouteInfo;

public final class MediaRouterJellybeanMr2$RouteInfo
{
  public static CharSequence getDescription(Object paramObject)
  {
    return ((MediaRouter.RouteInfo)paramObject).getDescription();
  }
  
  public static boolean isConnecting(Object paramObject)
  {
    return ((MediaRouter.RouteInfo)paramObject).isConnecting();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/routing/MediaRouterJellybeanMr2$RouteInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */