package android.support.v4.media.routing;

import android.media.MediaRouter.RouteGroup;
import java.util.ArrayList;
import java.util.List;

public final class MediaRouterJellybean$RouteGroup
{
  public static List getGroupedRoutes(Object paramObject)
  {
    paramObject = (MediaRouter.RouteGroup)paramObject;
    int j = ((MediaRouter.RouteGroup)paramObject).getRouteCount();
    ArrayList localArrayList = new ArrayList(j);
    int i = 0;
    while (i < j)
    {
      localArrayList.add(((MediaRouter.RouteGroup)paramObject).getRouteAt(i));
      i += 1;
    }
    return localArrayList;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/routing/MediaRouterJellybean$RouteGroup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */