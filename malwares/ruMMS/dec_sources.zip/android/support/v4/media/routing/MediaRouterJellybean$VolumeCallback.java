package android.support.v4.media.routing;

public abstract interface MediaRouterJellybean$VolumeCallback
{
  public abstract void onVolumeSetRequest(Object paramObject, int paramInt);
  
  public abstract void onVolumeUpdateRequest(Object paramObject, int paramInt);
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/routing/MediaRouterJellybean$VolumeCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */