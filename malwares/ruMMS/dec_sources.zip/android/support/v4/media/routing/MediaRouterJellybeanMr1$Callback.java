package android.support.v4.media.routing;

public abstract interface MediaRouterJellybeanMr1$Callback
  extends MediaRouterJellybean.Callback
{
  public abstract void onRoutePresentationDisplayChanged(Object paramObject);
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/routing/MediaRouterJellybeanMr1$Callback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */