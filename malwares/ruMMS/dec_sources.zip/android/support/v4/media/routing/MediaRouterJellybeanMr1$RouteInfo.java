package android.support.v4.media.routing;

import android.media.MediaRouter.RouteInfo;
import android.view.Display;

public final class MediaRouterJellybeanMr1$RouteInfo
{
  public static Display getPresentationDisplay(Object paramObject)
  {
    return ((MediaRouter.RouteInfo)paramObject).getPresentationDisplay();
  }
  
  public static boolean isEnabled(Object paramObject)
  {
    return ((MediaRouter.RouteInfo)paramObject).isEnabled();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/routing/MediaRouterJellybeanMr1$RouteInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */