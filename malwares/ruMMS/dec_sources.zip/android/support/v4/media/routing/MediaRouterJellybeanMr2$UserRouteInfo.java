package android.support.v4.media.routing;

import android.media.MediaRouter.UserRouteInfo;

public final class MediaRouterJellybeanMr2$UserRouteInfo
{
  public static void setDescription(Object paramObject, CharSequence paramCharSequence)
  {
    ((MediaRouter.UserRouteInfo)paramObject).setDescription(paramCharSequence);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/routing/MediaRouterJellybeanMr2$UserRouteInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */