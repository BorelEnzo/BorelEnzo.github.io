package android.support.v4.media;

import android.os.RemoteException;
import android.support.v4.util.ArrayMap;
import android.util.Log;
import java.util.List;

class MediaBrowserServiceCompat$3
  extends MediaBrowserServiceCompat.Result
{
  MediaBrowserServiceCompat$3(MediaBrowserServiceCompat paramMediaBrowserServiceCompat, Object paramObject, String paramString, MediaBrowserServiceCompat.ConnectionRecord paramConnectionRecord)
  {
    super(paramMediaBrowserServiceCompat, paramObject);
  }
  
  void onResultSent(List paramList)
  {
    if (paramList == null) {
      throw new IllegalStateException("onLoadChildren sent null list for id " + this.val$parentId);
    }
    if (MediaBrowserServiceCompat.access$100(this.this$0).get(this.val$connection.callbacks.asBinder()) != this.val$connection) {
      return;
    }
    try
    {
      this.val$connection.callbacks.onLoadChildren(this.val$parentId, paramList);
      return;
    }
    catch (RemoteException paramList)
    {
      Log.w("MediaBrowserServiceCompat", "Calling onLoadChildren() failed for id=" + this.val$parentId + " package=" + this.val$connection.pkg);
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/MediaBrowserServiceCompat$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */