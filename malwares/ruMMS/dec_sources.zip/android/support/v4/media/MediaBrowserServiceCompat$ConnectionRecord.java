package android.support.v4.media;

import android.os.Bundle;
import java.util.HashSet;

class MediaBrowserServiceCompat$ConnectionRecord
{
  IMediaBrowserServiceCompatCallbacks callbacks;
  String pkg;
  MediaBrowserServiceCompat.BrowserRoot root;
  Bundle rootHints;
  HashSet subscriptions = new HashSet();
  
  private MediaBrowserServiceCompat$ConnectionRecord(MediaBrowserServiceCompat paramMediaBrowserServiceCompat) {}
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/MediaBrowserServiceCompat$ConnectionRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */