package android.support.v4.media;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.SOURCE)
public @interface MediaMetadataCompat$LongKey {}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/MediaMetadataCompat$LongKey.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */