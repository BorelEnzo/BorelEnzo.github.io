package android.support.v4.media;

import android.os.Bundle;
import android.os.Handler;
import android.support.v4.os.ResultReceiver;

class MediaBrowserCompat$MediaBrowserImplBase$3
  extends ResultReceiver
{
  MediaBrowserCompat$MediaBrowserImplBase$3(MediaBrowserCompat.MediaBrowserImplBase paramMediaBrowserImplBase, Handler paramHandler, MediaBrowserCompat.ItemCallback paramItemCallback, String paramString)
  {
    super(paramHandler);
  }
  
  protected void onReceiveResult(int paramInt, Bundle paramBundle)
  {
    if ((paramInt != 0) || (paramBundle == null) || (!paramBundle.containsKey("media_item")))
    {
      this.val$cb.onError(this.val$mediaId);
      return;
    }
    paramBundle = paramBundle.getParcelable("media_item");
    if (!(paramBundle instanceof MediaBrowserCompat.MediaItem))
    {
      this.val$cb.onError(this.val$mediaId);
      return;
    }
    this.val$cb.onItemLoaded((MediaBrowserCompat.MediaItem)paramBundle);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/MediaBrowserCompat$MediaBrowserImplBase$3.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */