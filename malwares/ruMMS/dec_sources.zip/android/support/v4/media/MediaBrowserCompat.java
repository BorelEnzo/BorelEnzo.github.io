package android.support.v4.media;

import android.content.ComponentName;
import android.content.Context;
import android.os.Bundle;
import android.support.v4.media.session.MediaSessionCompat.Token;

public final class MediaBrowserCompat
{
  private final MediaBrowserCompat.MediaBrowserImplBase mImpl;
  
  public MediaBrowserCompat(Context paramContext, ComponentName paramComponentName, MediaBrowserCompat.ConnectionCallback paramConnectionCallback, Bundle paramBundle)
  {
    this.mImpl = new MediaBrowserCompat.MediaBrowserImplBase(paramContext, paramComponentName, paramConnectionCallback, paramBundle);
  }
  
  public void connect()
  {
    this.mImpl.connect();
  }
  
  public void disconnect()
  {
    this.mImpl.disconnect();
  }
  
  public Bundle getExtras()
  {
    return this.mImpl.getExtras();
  }
  
  public void getItem(String paramString, MediaBrowserCompat.ItemCallback paramItemCallback)
  {
    this.mImpl.getItem(paramString, paramItemCallback);
  }
  
  public String getRoot()
  {
    return this.mImpl.getRoot();
  }
  
  public ComponentName getServiceComponent()
  {
    return this.mImpl.getServiceComponent();
  }
  
  public MediaSessionCompat.Token getSessionToken()
  {
    return this.mImpl.getSessionToken();
  }
  
  public boolean isConnected()
  {
    return this.mImpl.isConnected();
  }
  
  public void subscribe(String paramString, MediaBrowserCompat.SubscriptionCallback paramSubscriptionCallback)
  {
    this.mImpl.subscribe(paramString, paramSubscriptionCallback);
  }
  
  public void unsubscribe(String paramString)
  {
    this.mImpl.unsubscribe(paramString);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/MediaBrowserCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */