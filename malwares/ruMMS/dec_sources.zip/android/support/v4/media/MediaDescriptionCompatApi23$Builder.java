package android.support.v4.media;

import android.media.MediaDescription.Builder;
import android.net.Uri;

class MediaDescriptionCompatApi23$Builder
  extends MediaDescriptionCompatApi21.Builder
{
  public static void setMediaUri(Object paramObject, Uri paramUri)
  {
    ((MediaDescription.Builder)paramObject).setMediaUri(paramUri);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/MediaDescriptionCompatApi23$Builder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */