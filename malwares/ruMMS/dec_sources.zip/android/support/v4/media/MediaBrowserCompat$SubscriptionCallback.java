package android.support.v4.media;

import java.util.List;

public abstract class MediaBrowserCompat$SubscriptionCallback
{
  public void onChildrenLoaded(String paramString, List paramList) {}
  
  public void onError(String paramString) {}
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/MediaBrowserCompat$SubscriptionCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */