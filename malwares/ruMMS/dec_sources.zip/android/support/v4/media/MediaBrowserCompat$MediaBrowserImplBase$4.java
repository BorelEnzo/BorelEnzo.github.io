package android.support.v4.media;

class MediaBrowserCompat$MediaBrowserImplBase$4
  implements Runnable
{
  MediaBrowserCompat$MediaBrowserImplBase$4(MediaBrowserCompat.MediaBrowserImplBase paramMediaBrowserImplBase, MediaBrowserCompat.ItemCallback paramItemCallback, String paramString) {}
  
  public void run()
  {
    this.val$cb.onError(this.val$mediaId);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/MediaBrowserCompat$MediaBrowserImplBase$4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */