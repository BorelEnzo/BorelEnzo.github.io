package android.support.v4.media;

class MediaBrowserCompat$MediaBrowserImplBase$Subscription
{
  MediaBrowserCompat.SubscriptionCallback callback;
  final String id;
  
  MediaBrowserCompat$MediaBrowserImplBase$Subscription(String paramString)
  {
    this.id = paramString;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/MediaBrowserCompat$MediaBrowserImplBase$Subscription.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */