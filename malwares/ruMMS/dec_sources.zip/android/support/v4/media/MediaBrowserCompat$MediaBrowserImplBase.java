package android.support.v4.media;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.RemoteException;
import android.support.v4.media.session.MediaSessionCompat.Token;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;
import android.util.Log;
import java.util.List;

class MediaBrowserCompat$MediaBrowserImplBase
{
  private static final int CONNECT_STATE_CONNECTED = 2;
  private static final int CONNECT_STATE_CONNECTING = 1;
  private static final int CONNECT_STATE_DISCONNECTED = 0;
  private static final int CONNECT_STATE_SUSPENDED = 3;
  private static final boolean DBG = false;
  private static final String TAG = "MediaBrowserCompat";
  private final MediaBrowserCompat.ConnectionCallback mCallback;
  private final Context mContext;
  private Bundle mExtras;
  private final Handler mHandler = new Handler();
  private MediaSessionCompat.Token mMediaSessionToken;
  private final Bundle mRootHints;
  private String mRootId;
  private IMediaBrowserServiceCompat mServiceBinder;
  private IMediaBrowserServiceCompatCallbacks mServiceCallbacks;
  private final ComponentName mServiceComponent;
  private MediaBrowserCompat.MediaBrowserImplBase.MediaServiceConnection mServiceConnection;
  private int mState = 0;
  private final ArrayMap mSubscriptions = new ArrayMap();
  
  public MediaBrowserCompat$MediaBrowserImplBase(Context paramContext, ComponentName paramComponentName, MediaBrowserCompat.ConnectionCallback paramConnectionCallback, Bundle paramBundle)
  {
    if (paramContext == null) {
      throw new IllegalArgumentException("context must not be null");
    }
    if (paramComponentName == null) {
      throw new IllegalArgumentException("service component must not be null");
    }
    if (paramConnectionCallback == null) {
      throw new IllegalArgumentException("connection callback must not be null");
    }
    this.mContext = paramContext;
    this.mServiceComponent = paramComponentName;
    this.mCallback = paramConnectionCallback;
    this.mRootHints = paramBundle;
  }
  
  private void forceCloseConnection()
  {
    if (this.mServiceConnection != null) {
      this.mContext.unbindService(this.mServiceConnection);
    }
    this.mState = 0;
    this.mServiceConnection = null;
    this.mServiceBinder = null;
    this.mServiceCallbacks = null;
    this.mRootId = null;
    this.mMediaSessionToken = null;
  }
  
  private MediaBrowserCompat.MediaBrowserImplBase.ServiceCallbacks getNewServiceCallbacks()
  {
    return new MediaBrowserCompat.MediaBrowserImplBase.ServiceCallbacks(this);
  }
  
  private static String getStateLabel(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return "UNKNOWN/" + paramInt;
    case 0: 
      return "CONNECT_STATE_DISCONNECTED";
    case 1: 
      return "CONNECT_STATE_CONNECTING";
    case 2: 
      return "CONNECT_STATE_CONNECTED";
    }
    return "CONNECT_STATE_SUSPENDED";
  }
  
  private boolean isCurrent(IMediaBrowserServiceCompatCallbacks paramIMediaBrowserServiceCompatCallbacks, String paramString)
  {
    if (this.mServiceCallbacks != paramIMediaBrowserServiceCompatCallbacks)
    {
      if (this.mState != 0) {
        Log.i("MediaBrowserCompat", paramString + " for " + this.mServiceComponent + " with mServiceConnection=" + this.mServiceCallbacks + " this=" + this);
      }
      return false;
    }
    return true;
  }
  
  private final void onConnectionFailed(IMediaBrowserServiceCompatCallbacks paramIMediaBrowserServiceCompatCallbacks)
  {
    this.mHandler.post(new MediaBrowserCompat.MediaBrowserImplBase.6(this, paramIMediaBrowserServiceCompatCallbacks));
  }
  
  private final void onLoadChildren(IMediaBrowserServiceCompatCallbacks paramIMediaBrowserServiceCompatCallbacks, String paramString, List paramList)
  {
    this.mHandler.post(new MediaBrowserCompat.MediaBrowserImplBase.7(this, paramIMediaBrowserServiceCompatCallbacks, paramList, paramString));
  }
  
  private final void onServiceConnected(IMediaBrowserServiceCompatCallbacks paramIMediaBrowserServiceCompatCallbacks, String paramString, MediaSessionCompat.Token paramToken, Bundle paramBundle)
  {
    this.mHandler.post(new MediaBrowserCompat.MediaBrowserImplBase.5(this, paramIMediaBrowserServiceCompatCallbacks, paramString, paramToken, paramBundle));
  }
  
  public void connect()
  {
    if (this.mState != 0) {
      throw new IllegalStateException("connect() called while not disconnected (state=" + getStateLabel(this.mState) + ")");
    }
    if (this.mServiceBinder != null) {
      throw new RuntimeException("mServiceBinder should be null. Instead it is " + this.mServiceBinder);
    }
    if (this.mServiceCallbacks != null) {
      throw new RuntimeException("mServiceCallbacks should be null. Instead it is " + this.mServiceCallbacks);
    }
    this.mState = 1;
    Intent localIntent = new Intent("android.media.browse.MediaBrowserServiceCompat");
    localIntent.setComponent(this.mServiceComponent);
    MediaBrowserCompat.MediaBrowserImplBase.MediaServiceConnection localMediaServiceConnection = new MediaBrowserCompat.MediaBrowserImplBase.MediaServiceConnection(this, null);
    this.mServiceConnection = localMediaServiceConnection;
    int i = 0;
    try
    {
      boolean bool = this.mContext.bindService(localIntent, this.mServiceConnection, 1);
      i = bool;
    }
    catch (Exception localException)
    {
      for (;;)
      {
        Log.e("MediaBrowserCompat", "Failed binding to service " + this.mServiceComponent);
      }
    }
    if (i == 0) {
      this.mHandler.post(new MediaBrowserCompat.MediaBrowserImplBase.1(this, localMediaServiceConnection));
    }
  }
  
  public void disconnect()
  {
    if (this.mServiceCallbacks != null) {}
    try
    {
      this.mServiceBinder.disconnect(this.mServiceCallbacks);
      forceCloseConnection();
      return;
    }
    catch (RemoteException localRemoteException)
    {
      for (;;)
      {
        Log.w("MediaBrowserCompat", "RemoteException during connect for " + this.mServiceComponent);
      }
    }
  }
  
  void dump()
  {
    Log.d("MediaBrowserCompat", "MediaBrowserCompat...");
    Log.d("MediaBrowserCompat", "  mServiceComponent=" + this.mServiceComponent);
    Log.d("MediaBrowserCompat", "  mCallback=" + this.mCallback);
    Log.d("MediaBrowserCompat", "  mRootHints=" + this.mRootHints);
    Log.d("MediaBrowserCompat", "  mState=" + getStateLabel(this.mState));
    Log.d("MediaBrowserCompat", "  mServiceConnection=" + this.mServiceConnection);
    Log.d("MediaBrowserCompat", "  mServiceBinder=" + this.mServiceBinder);
    Log.d("MediaBrowserCompat", "  mServiceCallbacks=" + this.mServiceCallbacks);
    Log.d("MediaBrowserCompat", "  mRootId=" + this.mRootId);
    Log.d("MediaBrowserCompat", "  mMediaSessionToken=" + this.mMediaSessionToken);
  }
  
  public Bundle getExtras()
  {
    if (!isConnected()) {
      throw new IllegalStateException("getExtras() called while not connected (state=" + getStateLabel(this.mState) + ")");
    }
    return this.mExtras;
  }
  
  public void getItem(String paramString, MediaBrowserCompat.ItemCallback paramItemCallback)
  {
    if (TextUtils.isEmpty(paramString)) {
      throw new IllegalArgumentException("mediaId is empty.");
    }
    if (paramItemCallback == null) {
      throw new IllegalArgumentException("cb is null.");
    }
    if (this.mState != 2)
    {
      Log.i("MediaBrowserCompat", "Not connected, unable to retrieve the MediaItem.");
      this.mHandler.post(new MediaBrowserCompat.MediaBrowserImplBase.2(this, paramItemCallback, paramString));
      return;
    }
    MediaBrowserCompat.MediaBrowserImplBase.3 local3 = new MediaBrowserCompat.MediaBrowserImplBase.3(this, this.mHandler, paramItemCallback, paramString);
    try
    {
      this.mServiceBinder.getMediaItem(paramString, local3);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.i("MediaBrowserCompat", "Remote error getting media item.");
      this.mHandler.post(new MediaBrowserCompat.MediaBrowserImplBase.4(this, paramItemCallback, paramString));
    }
  }
  
  public String getRoot()
  {
    if (!isConnected()) {
      throw new IllegalStateException("getSessionToken() called while not connected(state=" + getStateLabel(this.mState) + ")");
    }
    return this.mRootId;
  }
  
  public ComponentName getServiceComponent()
  {
    if (!isConnected()) {
      throw new IllegalStateException("getServiceComponent() called while not connected (state=" + this.mState + ")");
    }
    return this.mServiceComponent;
  }
  
  public MediaSessionCompat.Token getSessionToken()
  {
    if (!isConnected()) {
      throw new IllegalStateException("getSessionToken() called while not connected(state=" + this.mState + ")");
    }
    return this.mMediaSessionToken;
  }
  
  public boolean isConnected()
  {
    return this.mState == 2;
  }
  
  public void subscribe(String paramString, MediaBrowserCompat.SubscriptionCallback paramSubscriptionCallback)
  {
    if (paramString == null) {
      throw new IllegalArgumentException("parentId is null");
    }
    if (paramSubscriptionCallback == null) {
      throw new IllegalArgumentException("callback is null");
    }
    MediaBrowserCompat.MediaBrowserImplBase.Subscription localSubscription = (MediaBrowserCompat.MediaBrowserImplBase.Subscription)this.mSubscriptions.get(paramString);
    if (localSubscription == null) {}
    for (int i = 1;; i = 0)
    {
      if (i != 0)
      {
        localSubscription = new MediaBrowserCompat.MediaBrowserImplBase.Subscription(paramString);
        this.mSubscriptions.put(paramString, localSubscription);
      }
      localSubscription.callback = paramSubscriptionCallback;
      if (this.mState == 2) {}
      try
      {
        this.mServiceBinder.addSubscription(paramString, this.mServiceCallbacks);
        return;
      }
      catch (RemoteException paramSubscriptionCallback)
      {
        Log.d("MediaBrowserCompat", "addSubscription failed with RemoteException parentId=" + paramString);
      }
    }
  }
  
  public void unsubscribe(String paramString)
  {
    if (TextUtils.isEmpty(paramString)) {
      throw new IllegalArgumentException("parentId is empty.");
    }
    MediaBrowserCompat.MediaBrowserImplBase.Subscription localSubscription = (MediaBrowserCompat.MediaBrowserImplBase.Subscription)this.mSubscriptions.remove(paramString);
    if ((this.mState == 2) && (localSubscription != null)) {}
    try
    {
      this.mServiceBinder.removeSubscription(paramString, this.mServiceCallbacks);
      return;
    }
    catch (RemoteException localRemoteException)
    {
      Log.d("MediaBrowserCompat", "removeSubscription failed with RemoteException parentId=" + paramString);
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/MediaBrowserCompat$MediaBrowserImplBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */