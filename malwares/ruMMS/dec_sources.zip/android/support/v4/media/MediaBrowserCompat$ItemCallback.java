package android.support.v4.media;

public abstract class MediaBrowserCompat$ItemCallback
{
  public void onError(String paramString) {}
  
  public void onItemLoaded(MediaBrowserCompat.MediaItem paramMediaItem) {}
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/MediaBrowserCompat$ItemCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */