package android.support.v4.media;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;

public class MediaBrowserCompat$MediaItem
  implements Parcelable
{
  public static final Parcelable.Creator CREATOR = new MediaBrowserCompat.MediaItem.1();
  public static final int FLAG_BROWSABLE = 1;
  public static final int FLAG_PLAYABLE = 2;
  private final MediaDescriptionCompat mDescription;
  private final int mFlags;
  
  private MediaBrowserCompat$MediaItem(Parcel paramParcel)
  {
    this.mFlags = paramParcel.readInt();
    this.mDescription = ((MediaDescriptionCompat)MediaDescriptionCompat.CREATOR.createFromParcel(paramParcel));
  }
  
  public MediaBrowserCompat$MediaItem(MediaDescriptionCompat paramMediaDescriptionCompat, int paramInt)
  {
    if (paramMediaDescriptionCompat == null) {
      throw new IllegalArgumentException("description cannot be null");
    }
    if (TextUtils.isEmpty(paramMediaDescriptionCompat.getMediaId())) {
      throw new IllegalArgumentException("description must have a non-empty media id");
    }
    this.mFlags = paramInt;
    this.mDescription = paramMediaDescriptionCompat;
  }
  
  public int describeContents()
  {
    return 0;
  }
  
  public MediaDescriptionCompat getDescription()
  {
    return this.mDescription;
  }
  
  public int getFlags()
  {
    return this.mFlags;
  }
  
  public String getMediaId()
  {
    return this.mDescription.getMediaId();
  }
  
  public boolean isBrowsable()
  {
    return (this.mFlags & 0x1) != 0;
  }
  
  public boolean isPlayable()
  {
    return (this.mFlags & 0x2) != 0;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder("MediaItem{");
    localStringBuilder.append("mFlags=").append(this.mFlags);
    localStringBuilder.append(", mDescription=").append(this.mDescription);
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeInt(this.mFlags);
    this.mDescription.writeToParcel(paramParcel, paramInt);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/MediaBrowserCompat$MediaItem.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */