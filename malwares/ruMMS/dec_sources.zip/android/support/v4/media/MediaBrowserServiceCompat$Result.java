package android.support.v4.media;

public class MediaBrowserServiceCompat$Result
{
  private Object mDebug;
  private boolean mDetachCalled;
  private boolean mSendResultCalled;
  
  MediaBrowserServiceCompat$Result(MediaBrowserServiceCompat paramMediaBrowserServiceCompat, Object paramObject)
  {
    this.mDebug = paramObject;
  }
  
  public void detach()
  {
    if (this.mDetachCalled) {
      throw new IllegalStateException("detach() called when detach() had already been called for: " + this.mDebug);
    }
    if (this.mSendResultCalled) {
      throw new IllegalStateException("detach() called when sendResult() had already been called for: " + this.mDebug);
    }
    this.mDetachCalled = true;
  }
  
  boolean isDone()
  {
    return (this.mDetachCalled) || (this.mSendResultCalled);
  }
  
  void onResultSent(Object paramObject) {}
  
  public void sendResult(Object paramObject)
  {
    if (this.mSendResultCalled) {
      throw new IllegalStateException("sendResult() called twice for: " + this.mDebug);
    }
    this.mSendResultCalled = true;
    onResultSent(paramObject);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/MediaBrowserServiceCompat$Result.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */