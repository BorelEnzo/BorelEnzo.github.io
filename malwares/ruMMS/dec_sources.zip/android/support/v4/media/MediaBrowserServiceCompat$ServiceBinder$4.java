package android.support.v4.media;

import android.support.v4.util.ArrayMap;
import android.util.Log;
import java.util.HashSet;

class MediaBrowserServiceCompat$ServiceBinder$4
  implements Runnable
{
  MediaBrowserServiceCompat$ServiceBinder$4(MediaBrowserServiceCompat.ServiceBinder paramServiceBinder, IMediaBrowserServiceCompatCallbacks paramIMediaBrowserServiceCompatCallbacks, String paramString) {}
  
  public void run()
  {
    Object localObject = this.val$callbacks.asBinder();
    localObject = (MediaBrowserServiceCompat.ConnectionRecord)MediaBrowserServiceCompat.access$100(this.this$1.this$0).get(localObject);
    if (localObject == null) {
      Log.w("MediaBrowserServiceCompat", "removeSubscription for callback that isn't registered id=" + this.val$id);
    }
    while (((MediaBrowserServiceCompat.ConnectionRecord)localObject).subscriptions.remove(this.val$id)) {
      return;
    }
    Log.w("MediaBrowserServiceCompat", "removeSubscription called for " + this.val$id + " which is not subscribed");
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/MediaBrowserServiceCompat$ServiceBinder$4.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */