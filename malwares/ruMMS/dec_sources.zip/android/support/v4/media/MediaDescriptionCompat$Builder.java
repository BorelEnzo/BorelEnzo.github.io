package android.support.v4.media;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;

public final class MediaDescriptionCompat$Builder
{
  private CharSequence mDescription;
  private Bundle mExtras;
  private Bitmap mIcon;
  private Uri mIconUri;
  private String mMediaId;
  private Uri mMediaUri;
  private CharSequence mSubtitle;
  private CharSequence mTitle;
  
  public MediaDescriptionCompat build()
  {
    return new MediaDescriptionCompat(this.mMediaId, this.mTitle, this.mSubtitle, this.mDescription, this.mIcon, this.mIconUri, this.mExtras, this.mMediaUri, null);
  }
  
  public Builder setDescription(CharSequence paramCharSequence)
  {
    this.mDescription = paramCharSequence;
    return this;
  }
  
  public Builder setExtras(Bundle paramBundle)
  {
    this.mExtras = paramBundle;
    return this;
  }
  
  public Builder setIconBitmap(Bitmap paramBitmap)
  {
    this.mIcon = paramBitmap;
    return this;
  }
  
  public Builder setIconUri(Uri paramUri)
  {
    this.mIconUri = paramUri;
    return this;
  }
  
  public Builder setMediaId(String paramString)
  {
    this.mMediaId = paramString;
    return this;
  }
  
  public Builder setMediaUri(Uri paramUri)
  {
    this.mMediaUri = paramUri;
    return this;
  }
  
  public Builder setSubtitle(CharSequence paramCharSequence)
  {
    this.mSubtitle = paramCharSequence;
    return this;
  }
  
  public Builder setTitle(CharSequence paramCharSequence)
  {
    this.mTitle = paramCharSequence;
    return this;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/MediaDescriptionCompat$Builder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */