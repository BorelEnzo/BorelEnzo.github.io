package android.support.v4.media;

import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.support.v4.media.session.MediaSessionCompat.Token;
import android.support.v4.os.ResultReceiver;
import android.support.v4.util.ArrayMap;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.HashSet;

public abstract class MediaBrowserServiceCompat
  extends Service
{
  private static final boolean DBG = false;
  public static final String KEY_MEDIA_ITEM = "media_item";
  public static final String SERVICE_INTERFACE = "android.media.browse.MediaBrowserServiceCompat";
  private static final String TAG = "MediaBrowserServiceCompat";
  private MediaBrowserServiceCompat.ServiceBinder mBinder;
  private final ArrayMap mConnections = new ArrayMap();
  private final Handler mHandler = new Handler();
  MediaSessionCompat.Token mSession;
  
  private void addSubscription(String paramString, MediaBrowserServiceCompat.ConnectionRecord paramConnectionRecord)
  {
    paramConnectionRecord.subscriptions.add(paramString);
    performLoadChildren(paramString, paramConnectionRecord);
  }
  
  private boolean isValidPackage(String paramString, int paramInt)
  {
    if (paramString == null) {}
    for (;;)
    {
      return false;
      String[] arrayOfString = getPackageManager().getPackagesForUid(paramInt);
      int i = arrayOfString.length;
      paramInt = 0;
      while (paramInt < i)
      {
        if (arrayOfString[paramInt].equals(paramString)) {
          return true;
        }
        paramInt += 1;
      }
    }
  }
  
  private void performLoadChildren(String paramString, MediaBrowserServiceCompat.ConnectionRecord paramConnectionRecord)
  {
    MediaBrowserServiceCompat.3 local3 = new MediaBrowserServiceCompat.3(this, paramString, paramString, paramConnectionRecord);
    onLoadChildren(paramString, local3);
    if (!local3.isDone()) {
      throw new IllegalStateException("onLoadChildren must call detach() or sendResult() before returning for package=" + paramConnectionRecord.pkg + " id=" + paramString);
    }
  }
  
  private void performLoadItem(String paramString, ResultReceiver paramResultReceiver)
  {
    paramResultReceiver = new MediaBrowserServiceCompat.4(this, paramString, paramResultReceiver);
    onLoadItem(paramString, paramResultReceiver);
    if (!paramResultReceiver.isDone()) {
      throw new IllegalStateException("onLoadItem must call detach() or sendResult() before returning for id=" + paramString);
    }
  }
  
  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {}
  
  public MediaSessionCompat.Token getSessionToken()
  {
    return this.mSession;
  }
  
  public void notifyChildrenChanged(String paramString)
  {
    if (paramString == null) {
      throw new IllegalArgumentException("parentId cannot be null in notifyChildrenChanged");
    }
    this.mHandler.post(new MediaBrowserServiceCompat.2(this, paramString));
  }
  
  public IBinder onBind(Intent paramIntent)
  {
    if ("android.media.browse.MediaBrowserServiceCompat".equals(paramIntent.getAction())) {
      return this.mBinder;
    }
    return null;
  }
  
  public void onCreate()
  {
    super.onCreate();
    this.mBinder = new MediaBrowserServiceCompat.ServiceBinder(this, null);
  }
  
  public abstract MediaBrowserServiceCompat.BrowserRoot onGetRoot(String paramString, int paramInt, Bundle paramBundle);
  
  public abstract void onLoadChildren(String paramString, MediaBrowserServiceCompat.Result paramResult);
  
  public void onLoadItem(String paramString, MediaBrowserServiceCompat.Result paramResult)
  {
    paramResult.sendResult(null);
  }
  
  public void setSessionToken(MediaSessionCompat.Token paramToken)
  {
    if (paramToken == null) {
      throw new IllegalArgumentException("Session token may not be null.");
    }
    if (this.mSession != null) {
      throw new IllegalStateException("The session token has already been set.");
    }
    this.mSession = paramToken;
    this.mHandler.post(new MediaBrowserServiceCompat.1(this, paramToken));
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/media/MediaBrowserServiceCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */