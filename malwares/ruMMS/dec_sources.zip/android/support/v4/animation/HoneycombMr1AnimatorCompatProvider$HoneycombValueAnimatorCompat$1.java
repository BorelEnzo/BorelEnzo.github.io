package android.support.v4.animation;

import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;

class HoneycombMr1AnimatorCompatProvider$HoneycombValueAnimatorCompat$1
  implements ValueAnimator.AnimatorUpdateListener
{
  HoneycombMr1AnimatorCompatProvider$HoneycombValueAnimatorCompat$1(HoneycombMr1AnimatorCompatProvider.HoneycombValueAnimatorCompat paramHoneycombValueAnimatorCompat, AnimatorUpdateListenerCompat paramAnimatorUpdateListenerCompat) {}
  
  public void onAnimationUpdate(ValueAnimator paramValueAnimator)
  {
    this.val$animatorUpdateListener.onAnimationUpdate(this.this$0);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/animation/HoneycombMr1AnimatorCompatProvider$HoneycombValueAnimatorCompat$1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */