package android.support.v4.graphics;

import android.graphics.Bitmap;

abstract interface BitmapCompat$BitmapImpl
{
  public abstract int getAllocationByteCount(Bitmap paramBitmap);
  
  public abstract boolean hasMipMap(Bitmap paramBitmap);
  
  public abstract void setHasMipMap(Bitmap paramBitmap, boolean paramBoolean);
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/graphics/BitmapCompat$BitmapImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */