package android.support.v4.graphics;

import android.graphics.Bitmap;

class BitmapCompat$KitKatBitmapCompatImpl
  extends BitmapCompat.JbMr2BitmapCompatImpl
{
  public int getAllocationByteCount(Bitmap paramBitmap)
  {
    return BitmapCompatKitKat.getAllocationByteCount(paramBitmap);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/graphics/BitmapCompat$KitKatBitmapCompatImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */