package android.support.v4.graphics.drawable;

import android.graphics.drawable.Drawable;

class DrawableCompat$MDrawableImpl
  extends DrawableCompat.LollipopMr1DrawableImpl
{
  public int getLayoutDirection(Drawable paramDrawable)
  {
    return DrawableCompatApi23.getLayoutDirection(paramDrawable);
  }
  
  public void setLayoutDirection(Drawable paramDrawable, int paramInt)
  {
    DrawableCompatApi23.setLayoutDirection(paramDrawable, paramInt);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/graphics/drawable/DrawableCompat$MDrawableImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */