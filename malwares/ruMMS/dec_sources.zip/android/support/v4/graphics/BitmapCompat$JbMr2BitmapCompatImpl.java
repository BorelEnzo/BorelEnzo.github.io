package android.support.v4.graphics;

import android.graphics.Bitmap;

class BitmapCompat$JbMr2BitmapCompatImpl
  extends BitmapCompat.HcMr1BitmapCompatImpl
{
  public boolean hasMipMap(Bitmap paramBitmap)
  {
    return BitmapCompatJellybeanMR2.hasMipMap(paramBitmap);
  }
  
  public void setHasMipMap(Bitmap paramBitmap, boolean paramBoolean)
  {
    BitmapCompatJellybeanMR2.setHasMipMap(paramBitmap, paramBoolean);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/graphics/BitmapCompat$JbMr2BitmapCompatImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */