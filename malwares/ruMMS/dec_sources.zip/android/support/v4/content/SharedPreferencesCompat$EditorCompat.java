package android.support.v4.content;

import android.content.SharedPreferences.Editor;
import android.os.Build.VERSION;

public class SharedPreferencesCompat$EditorCompat
{
  private static EditorCompat sInstance;
  private final SharedPreferencesCompat.EditorCompat.Helper mHelper;
  
  private SharedPreferencesCompat$EditorCompat()
  {
    if (Build.VERSION.SDK_INT >= 9)
    {
      this.mHelper = new SharedPreferencesCompat.EditorCompat.EditorHelperApi9Impl(null);
      return;
    }
    this.mHelper = new SharedPreferencesCompat.EditorCompat.EditorHelperBaseImpl(null);
  }
  
  public static EditorCompat getInstance()
  {
    if (sInstance == null) {
      sInstance = new EditorCompat();
    }
    return sInstance;
  }
  
  public void apply(SharedPreferences.Editor paramEditor)
  {
    this.mHelper.apply(paramEditor);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/content/SharedPreferencesCompat$EditorCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */