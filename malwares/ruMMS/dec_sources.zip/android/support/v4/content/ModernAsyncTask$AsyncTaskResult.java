package android.support.v4.content;

class ModernAsyncTask$AsyncTaskResult
{
  final Object[] mData;
  final ModernAsyncTask mTask;
  
  ModernAsyncTask$AsyncTaskResult(ModernAsyncTask paramModernAsyncTask, Object... paramVarArgs)
  {
    this.mTask = paramModernAsyncTask;
    this.mData = paramVarArgs;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/content/ModernAsyncTask$AsyncTaskResult.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */