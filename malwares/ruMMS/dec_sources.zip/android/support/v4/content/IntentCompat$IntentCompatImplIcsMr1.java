package android.support.v4.content;

import android.content.Intent;

class IntentCompat$IntentCompatImplIcsMr1
  extends IntentCompat.IntentCompatImplHC
{
  public Intent makeMainSelectorActivity(String paramString1, String paramString2)
  {
    return IntentCompatIcsMr1.makeMainSelectorActivity(paramString1, paramString2);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/content/IntentCompat$IntentCompatImplIcsMr1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */