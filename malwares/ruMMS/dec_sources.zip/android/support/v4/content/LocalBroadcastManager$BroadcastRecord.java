package android.support.v4.content;

import android.content.Intent;
import java.util.ArrayList;

class LocalBroadcastManager$BroadcastRecord
{
  final Intent intent;
  final ArrayList receivers;
  
  LocalBroadcastManager$BroadcastRecord(Intent paramIntent, ArrayList paramArrayList)
  {
    this.intent = paramIntent;
    this.receivers = paramArrayList;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/content/LocalBroadcastManager$BroadcastRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */