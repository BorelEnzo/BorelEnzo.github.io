package android.support.v4.content.pm;

public class ActivityInfoCompat
{
  public static final int CONFIG_UI_MODE = 512;
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/content/pm/ActivityInfoCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */