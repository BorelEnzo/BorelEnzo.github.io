package android.support.v4.content;

import android.content.SharedPreferences.Editor;

abstract interface SharedPreferencesCompat$EditorCompat$Helper
{
  public abstract void apply(SharedPreferences.Editor paramEditor);
}


/* Location:              /home/enzo/Documents/hacking/malwares/ruMMS/classes-dex2jar.jar!/android/support/v4/content/SharedPreferencesCompat$EditorCompat$Helper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */