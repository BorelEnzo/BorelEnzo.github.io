package android.support.v4.view;

import android.view.View;

public abstract interface ViewPropertyAnimatorListener
{
  public abstract void onAnimationCancel(View paramView);
  
  public abstract void onAnimationEnd(View paramView);
  
  public abstract void onAnimationStart(View paramView);
}


/* Location:              /home/enzo/Documents/hacking/malwares/viking-horde/classes.jar!/android/support/v4/view/ViewPropertyAnimatorListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */