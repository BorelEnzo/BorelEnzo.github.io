package android.support.v4.view;

import android.view.View;

class ViewCompatICSMr1
{
  public static boolean hasOnClickListeners(View paramView)
  {
    return paramView.hasOnClickListeners();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/viking-horde/classes.jar!/android/support/v4/view/ViewCompatICSMr1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */