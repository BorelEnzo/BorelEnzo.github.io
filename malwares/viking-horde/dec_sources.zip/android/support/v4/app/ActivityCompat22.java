package android.support.v4.app;

import android.app.Activity;
import android.net.Uri;

class ActivityCompat22
{
  public static Uri getReferrer(Activity paramActivity)
  {
    return paramActivity.getReferrer();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/viking-horde/classes.jar!/android/support/v4/app/ActivityCompat22.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */