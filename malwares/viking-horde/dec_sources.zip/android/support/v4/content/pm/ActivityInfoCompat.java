package android.support.v4.content.pm;

public final class ActivityInfoCompat
{
  public static final int CONFIG_UI_MODE = 512;
}


/* Location:              /home/enzo/Documents/hacking/malwares/viking-horde/classes.jar!/android/support/v4/content/pm/ActivityInfoCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */