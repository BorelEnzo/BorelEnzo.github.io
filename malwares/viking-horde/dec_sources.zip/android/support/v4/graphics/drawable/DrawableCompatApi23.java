package android.support.v4.graphics.drawable;

import android.graphics.drawable.Drawable;

class DrawableCompatApi23
{
  public static int getLayoutDirection(Drawable paramDrawable)
  {
    return paramDrawable.getLayoutDirection();
  }
  
  public static void setLayoutDirection(Drawable paramDrawable, int paramInt)
  {
    paramDrawable.setLayoutDirection(paramInt);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/viking-horde/classes.jar!/android/support/v4/graphics/drawable/DrawableCompatApi23.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */