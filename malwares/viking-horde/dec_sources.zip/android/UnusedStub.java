package android;

public final class UnusedStub {}


/* Location:              /home/enzo/Documents/hacking/malwares/viking-horde/classes.jar!/android/UnusedStub.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */