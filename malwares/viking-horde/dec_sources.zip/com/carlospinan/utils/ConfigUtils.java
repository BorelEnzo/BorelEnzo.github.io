package com.carlospinan.utils;

public class ConfigUtils
{
  public static final boolean AD_MOB_DEBUG = true;
  public static final boolean GOOGLE_PLAY_IN_CLOUD_SAVE = false;
  public static final boolean IS_OUYA_APP = false;
  public static final boolean USE_AD_MOB = true;
  public static final boolean USE_GOOGLE_PLAY_GAME_SERVICES = true;
}


/* Location:              /home/enzo/Documents/hacking/malwares/viking-horde/classes.jar!/com/carlospinan/utils/ConfigUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */