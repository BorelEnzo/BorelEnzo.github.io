package com.carlospinan.utils;

import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.res.Resources;
import android.util.Log;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.achievement.Achievements;
import com.google.android.gms.games.leaderboard.Leaderboards;

public class NativeUtils
{
  private static final int REQUEST_ACHIEVEMENTS = 10000;
  private static final int REQUEST_LEADERBOARD = 10002;
  private static final int REQUEST_LEADERBOARDS = 10001;
  private static final String TAG = "ANDROID_TAG";
  private static UtilActivity app = null;
  private static Context context;
  private static NativeUtils instance = null;
  
  public static void configure(Context paramContext)
  {
    context = paramContext;
    app = (UtilActivity)context;
  }
  
  public static void displayAlert(String paramString)
  {
    AlertDialog.Builder localBuilder = new AlertDialog.Builder(context);
    localBuilder.setMessage(paramString);
    localBuilder.setNeutralButton(context.getResources().getString(17039370), null);
    localBuilder.create().show();
  }
  
  public static void gameServicesSignIn()
  {
    app.runOnUiThread(new Runnable()
    {
      public void run()
      {
        if (!NativeUtils.isSignedIn()) {
          NativeUtils.app.signInGooglePlay();
        }
      }
    });
  }
  
  public static void gameServicesSignOut()
  {
    app.runOnUiThread(new Runnable()
    {
      public void run()
      {
        if (NativeUtils.isSignedIn()) {
          NativeUtils.app.signOutGooglePlay();
        }
      }
    });
  }
  
  public static void hideAd()
  {
    app.runOnUiThread(new Runnable()
    {
      public void run() {}
    });
  }
  
  public static void inCloudLoad(int paramInt) {}
  
  public static void inCloudSaveOrUpdate(int paramInt, byte[] paramArrayOfByte) {}
  
  public static void incrementAchievement(String paramString, final int paramInt)
  {
    app.runOnUiThread(new Runnable()
    {
      public void run()
      {
        if (NativeUtils.isSignedIn())
        {
          Games.Achievements.increment(NativeUtils.app.getCustomApiClient(), NativeUtils.this, paramInt);
          return;
        }
        NativeUtils.displayAlert(NativeUtils.context.getResources().getString(2131099701).replace("{achievementID}", NativeUtils.this).replace("{numSteps}", paramInt));
      }
    });
  }
  
  public static boolean isSignedIn()
  {
    return app.getSignedIn();
  }
  
  public static native void notifyInCloudLoad();
  
  public static native void notifyInCloudSavingOrUpdate();
  
  public static NativeUtils sharedInstance()
  {
    if (instance == null) {
      instance = new NativeUtils();
    }
    return instance;
  }
  
  public static void showAchievements()
  {
    app.runOnUiThread(new Runnable()
    {
      public void run()
      {
        if (NativeUtils.isSignedIn())
        {
          NativeUtils.app.startActivityForResult(Games.Achievements.getAchievementsIntent(NativeUtils.app.getCustomApiClient()), 10000);
          return;
        }
        NativeUtils.displayAlert(NativeUtils.context.getResources().getString(2131099702));
      }
    });
  }
  
  public static void showAd()
  {
    app.runOnUiThread(new Runnable()
    {
      public void run() {}
    });
  }
  
  public static void showLeaderboard(String paramString)
  {
    app.runOnUiThread(new Runnable()
    {
      public void run()
      {
        if (NativeUtils.isSignedIn())
        {
          NativeUtils.app.startActivityForResult(Games.Leaderboards.getLeaderboardIntent(NativeUtils.app.getCustomApiClient(), NativeUtils.this), 10002);
          return;
        }
        NativeUtils.displayAlert(NativeUtils.context.getResources().getString(2131099704).replace("{leaderboardID}", NativeUtils.this));
      }
    });
  }
  
  public static void showLeaderboards()
  {
    app.runOnUiThread(new Runnable()
    {
      public void run()
      {
        if (NativeUtils.isSignedIn())
        {
          NativeUtils.app.startActivityForResult(Games.Leaderboards.getAllLeaderboardsIntent(NativeUtils.app.getCustomApiClient()), 10001);
          return;
        }
        NativeUtils.displayAlert(NativeUtils.context.getResources().getString(2131099703));
      }
    });
  }
  
  public static void submitScore(String paramString, long paramLong)
  {
    app.runOnUiThread(new Runnable()
    {
      public void run()
      {
        if (NativeUtils.isSignedIn())
        {
          Log.d("ANDROID_TAG", "Submit score " + this.val$score + " to " + this.val$leaderboardID);
          Games.Leaderboards.submitScore(NativeUtils.app.getCustomApiClient(), this.val$leaderboardID, this.val$score);
          return;
        }
        NativeUtils.displayAlert(NativeUtils.context.getResources().getString(2131099699).replace("{score}", this.val$score).replace("{leaderboardID}", this.val$leaderboardID));
      }
    });
  }
  
  public static void unlockAchievement(String paramString)
  {
    app.runOnUiThread(new Runnable()
    {
      public void run()
      {
        if (NativeUtils.isSignedIn())
        {
          Log.d("ANDROID_TAG", "Try to unlock achievement " + NativeUtils.this);
          Games.Achievements.unlock(NativeUtils.app.getCustomApiClient(), NativeUtils.this);
          return;
        }
        NativeUtils.displayAlert(NativeUtils.context.getResources().getString(2131099700).replace("{achievementID}", NativeUtils.this));
      }
    });
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/viking-horde/classes.jar!/com/carlospinan/utils/NativeUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */