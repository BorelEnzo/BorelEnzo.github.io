package com.Jump.vikingJump;

public final class BuildConfig
{
  public static final boolean DEBUG = false;
}


/* Location:              /home/enzo/Documents/hacking/malwares/viking-horde/classes.jar!/com/Jump/vikingJump/BuildConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */