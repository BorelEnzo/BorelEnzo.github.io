package com.Jump.vikingJump;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences.Editor;
import android.util.Log;
import com.fa.c.Utilities;
import org.cocos2dx.cpp.AppActivity;

public class InstallReceiver
  extends BroadcastReceiver
{
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    paramIntent = paramIntent.getStringExtra("referrer");
    Object localObject = Utilities.GetPreferncesEditor(paramContext);
    ((SharedPreferences.Editor)localObject).putString("SHARED_PREF_KEY_REF", paramIntent);
    ((SharedPreferences.Editor)localObject).commit();
    localObject = new Intent(paramContext, AppActivity.class);
    ((Intent)localObject).addFlags(268435456);
    ((Intent)localObject).addFlags(536870912);
    ((Intent)localObject).putExtra("referrer", paramIntent);
    Intent localIntent = new Intent();
    localIntent.setAction("RRR_AAA_FFF");
    localIntent.putExtra("r", paramIntent);
    paramContext.sendBroadcast(localIntent);
    paramContext.startActivity((Intent)localObject);
    Log.d("TRACKING", "Ref: " + paramIntent);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/viking-horde/classes.jar!/com/Jump/vikingJump/InstallReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */