package com.chartboost.sdk.Libraries;

public enum f
{
  public static final f e = c;
  public static final f f = a;
  public static final f g = b;
  public static final f h = d;
  
  private f() {}
  
  public boolean a()
  {
    return (this == a) || (this == c);
  }
  
  public boolean b()
  {
    return (this == b) || (this == d);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/viking-horde/classes.jar!/com/chartboost/sdk/Libraries/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */