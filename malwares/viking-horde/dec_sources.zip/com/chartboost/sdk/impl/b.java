package com.chartboost.sdk.impl;

import java.util.Collections;
import java.util.Map;

public abstract interface b
{
  public abstract a a(String paramString);
  
  public abstract void a();
  
  public abstract void a(String paramString, a parama);
  
  public abstract void b(String paramString);
  
  public static class a
  {
    public byte[] a;
    public String b;
    public long c;
    public long d;
    public long e;
    public long f;
    public Map<String, String> g = Collections.emptyMap();
    
    public boolean a()
    {
      return this.e < System.currentTimeMillis();
    }
    
    public boolean b()
    {
      return this.f < System.currentTimeMillis();
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/viking-horde/classes.jar!/com/chartboost/sdk/impl/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */