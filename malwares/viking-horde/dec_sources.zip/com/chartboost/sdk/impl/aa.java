package com.chartboost.sdk.impl;

public class aa
  implements b
{
  public b.a a(String paramString)
  {
    return null;
  }
  
  public void a() {}
  
  public void a(String paramString, b.a parama) {}
  
  public void b(String paramString) {}
}


/* Location:              /home/enzo/Documents/hacking/malwares/viking-horde/classes.jar!/com/chartboost/sdk/impl/aa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */