package com.kbstar.kb.android.receiver;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;
import java.io.PrintStream;

public class LockReceiver
  extends DeviceAdminReceiver
{
  public void onDisabled(Context paramContext, Intent paramIntent)
  {
    System.out.println("111");
    super.onDisabled(paramContext, paramIntent);
  }
  
  public void onEnabled(Context paramContext, Intent paramIntent)
  {
    System.out.println("2222");
    super.onEnabled(paramContext, paramIntent);
  }
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    super.onReceive(paramContext, paramIntent);
    System.out.println("onreceiver");
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/receiver/LockReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */