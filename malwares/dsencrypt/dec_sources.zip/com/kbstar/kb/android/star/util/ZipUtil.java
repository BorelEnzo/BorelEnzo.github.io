package com.kbstar.kb.android.star.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public final class ZipUtil
{
  private static void ZipFiles(String paramString1, String paramString2, ZipOutputStream paramZipOutputStream)
    throws Exception
  {
    LogUtil.i("ZipFiles(String, String, ZipOutputStream)");
    if (paramZipOutputStream == null) {}
    for (;;)
    {
      return;
      Object localObject = new File(paramString1 + paramString2);
      if (((File)localObject).isFile())
      {
        paramString1 = new ZipEntry(paramString2);
        paramString2 = new FileInputStream((File)localObject);
        paramZipOutputStream.putNextEntry(paramString1);
        paramString1 = new byte['က'];
        for (;;)
        {
          i = paramString2.read(paramString1);
          if (i == -1)
          {
            paramZipOutputStream.closeEntry();
            paramString2.close();
            return;
          }
          paramZipOutputStream.write(paramString1, 0, i);
        }
      }
      localObject = ((File)localObject).list();
      if (localObject.length <= 0)
      {
        paramZipOutputStream.putNextEntry(new ZipEntry(paramString2 + File.separator));
        paramZipOutputStream.closeEntry();
      }
      int i = 0;
      while (i < localObject.length)
      {
        ZipFiles(paramString1, paramString2 + File.separator + localObject[i], paramZipOutputStream);
        i += 1;
      }
    }
  }
  
  public static void ZipFolder(String paramString1, String paramString2)
    throws Exception
  {
    LogUtil.i("ZipFolder(String, String)");
    paramString2 = new ZipOutputStream(new FileOutputStream(paramString2));
    paramString1 = new File(paramString1);
    ZipFiles(paramString1.getParent() + File.separator, paramString1.getName(), paramString2);
    paramString2.finish();
    paramString2.close();
  }
  
  public void finalize()
    throws Throwable
  {}
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/util/ZipUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */