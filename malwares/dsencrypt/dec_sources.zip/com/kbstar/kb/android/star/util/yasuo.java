package com.kbstar.kb.android.star.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.zip.ZipEntry;
import java.util.zip.ZipException;
import java.util.zip.ZipFile;
import java.util.zip.ZipOutputStream;

public class yasuo
{
  private static final int BUFF_SIZE = 10240;
  
  public static Enumeration<?> getEntriesEnumeration(File paramFile)
    throws ZipException, IOException
  {
    return new ZipFile(paramFile).entries();
  }
  
  public static ArrayList<String> getEntriesNames(File paramFile)
    throws ZipException, IOException
  {
    ArrayList localArrayList = new ArrayList();
    paramFile = getEntriesEnumeration(paramFile);
    for (;;)
    {
      if (!paramFile.hasMoreElements()) {
        return localArrayList;
      }
      localArrayList.add(new String(getEntryName((ZipEntry)paramFile.nextElement()).getBytes("UTF-8"), "8859_1"));
    }
  }
  
  public static String getEntryComment(ZipEntry paramZipEntry)
    throws UnsupportedEncodingException
  {
    return new String(paramZipEntry.getComment().getBytes("UTF-8"), "8859_1");
  }
  
  public static String getEntryName(ZipEntry paramZipEntry)
    throws UnsupportedEncodingException
  {
    return new String(paramZipEntry.getName().getBytes("UTF-8"), "8859_1");
  }
  
  /* Error */
  public static void upZipFile(File paramFile, String paramString)
    throws ZipException, IOException
  {
    // Byte code:
    //   0: new 85	java/io/File
    //   3: dup
    //   4: aload_1
    //   5: invokespecial 88	java/io/File:<init>	(Ljava/lang/String;)V
    //   8: astore 4
    //   10: aload 4
    //   12: invokevirtual 91	java/io/File:exists	()Z
    //   15: ifne +9 -> 24
    //   18: aload 4
    //   20: invokevirtual 94	java/io/File:mkdirs	()Z
    //   23: pop
    //   24: new 20	java/util/zip/ZipFile
    //   27: dup
    //   28: aload_0
    //   29: invokespecial 23	java/util/zip/ZipFile:<init>	(Ljava/io/File;)V
    //   32: astore 7
    //   34: aconst_null
    //   35: astore 4
    //   37: aconst_null
    //   38: astore_0
    //   39: aconst_null
    //   40: astore 5
    //   42: aload 7
    //   44: invokevirtual 27	java/util/zip/ZipFile:entries	()Ljava/util/Enumeration;
    //   47: astore 8
    //   49: aconst_null
    //   50: astore 4
    //   52: aload_0
    //   53: astore 5
    //   55: aload 8
    //   57: invokeinterface 43 1 0
    //   62: istore_3
    //   63: iload_3
    //   64: ifne +22 -> 86
    //   67: aload_0
    //   68: ifnull +7 -> 75
    //   71: aload_0
    //   72: invokevirtual 99	java/io/InputStream:close	()V
    //   75: aload 4
    //   77: ifnull +8 -> 85
    //   80: aload 4
    //   82: invokevirtual 102	java/io/OutputStream:close	()V
    //   85: return
    //   86: aload_0
    //   87: astore 5
    //   89: aload 8
    //   91: invokeinterface 49 1 0
    //   96: checkcast 51	java/util/zip/ZipEntry
    //   99: astore 6
    //   101: aload_0
    //   102: astore 5
    //   104: aload 7
    //   106: aload 6
    //   108: invokevirtual 106	java/util/zip/ZipFile:getInputStream	(Ljava/util/zip/ZipEntry;)Ljava/io/InputStream;
    //   111: astore_0
    //   112: aload_0
    //   113: astore 5
    //   115: new 85	java/io/File
    //   118: dup
    //   119: new 45	java/lang/String
    //   122: dup
    //   123: new 108	java/lang/StringBuilder
    //   126: dup
    //   127: aload_1
    //   128: invokestatic 112	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   131: invokespecial 113	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   134: getstatic 117	java/io/File:separator	Ljava/lang/String;
    //   137: invokevirtual 121	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   140: aload 6
    //   142: invokevirtual 81	java/util/zip/ZipEntry:getName	()Ljava/lang/String;
    //   145: invokevirtual 121	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   148: invokevirtual 124	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   151: ldc 63
    //   153: invokevirtual 61	java/lang/String:getBytes	(Ljava/lang/String;)[B
    //   156: ldc 57
    //   158: invokespecial 66	java/lang/String:<init>	([BLjava/lang/String;)V
    //   161: invokespecial 88	java/io/File:<init>	(Ljava/lang/String;)V
    //   164: astore 6
    //   166: aload_0
    //   167: astore 5
    //   169: aload 6
    //   171: invokevirtual 91	java/io/File:exists	()Z
    //   174: ifne +42 -> 216
    //   177: aload_0
    //   178: astore 5
    //   180: aload 6
    //   182: invokevirtual 128	java/io/File:getParentFile	()Ljava/io/File;
    //   185: astore 9
    //   187: aload_0
    //   188: astore 5
    //   190: aload 9
    //   192: invokevirtual 91	java/io/File:exists	()Z
    //   195: ifne +12 -> 207
    //   198: aload_0
    //   199: astore 5
    //   201: aload 9
    //   203: invokevirtual 94	java/io/File:mkdirs	()Z
    //   206: pop
    //   207: aload_0
    //   208: astore 5
    //   210: aload 6
    //   212: invokevirtual 131	java/io/File:createNewFile	()Z
    //   215: pop
    //   216: aload_0
    //   217: astore 5
    //   219: new 133	java/io/FileOutputStream
    //   222: dup
    //   223: aload 6
    //   225: invokespecial 134	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   228: astore 6
    //   230: aload_0
    //   231: astore 4
    //   233: aload 6
    //   235: astore 5
    //   237: sipush 10240
    //   240: newarray <illegal type>
    //   242: astore 9
    //   244: aload_0
    //   245: astore 4
    //   247: aload 6
    //   249: astore 5
    //   251: aload_0
    //   252: aload 9
    //   254: invokevirtual 138	java/io/InputStream:read	([B)I
    //   257: istore_2
    //   258: iload_2
    //   259: ifgt +10 -> 269
    //   262: aload 6
    //   264: astore 4
    //   266: goto -214 -> 52
    //   269: aload_0
    //   270: astore 4
    //   272: aload 6
    //   274: astore 5
    //   276: aload 6
    //   278: aload 9
    //   280: iconst_0
    //   281: iload_2
    //   282: invokevirtual 142	java/io/OutputStream:write	([BII)V
    //   285: goto -41 -> 244
    //   288: astore_0
    //   289: aload 4
    //   291: ifnull +8 -> 299
    //   294: aload 4
    //   296: invokevirtual 99	java/io/InputStream:close	()V
    //   299: aload 5
    //   301: ifnull +8 -> 309
    //   304: aload 5
    //   306: invokevirtual 102	java/io/OutputStream:close	()V
    //   309: aload_0
    //   310: athrow
    //   311: astore_1
    //   312: aload 4
    //   314: astore_0
    //   315: aload 5
    //   317: astore 4
    //   319: aload_0
    //   320: astore 5
    //   322: aload_1
    //   323: astore_0
    //   324: goto -35 -> 289
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	327	0	paramFile	File
    //   0	327	1	paramString	String
    //   257	25	2	i	int
    //   62	2	3	bool	boolean
    //   8	310	4	localObject1	Object
    //   40	281	5	localObject2	Object
    //   99	178	6	localObject3	Object
    //   32	73	7	localZipFile	ZipFile
    //   47	43	8	localEnumeration	Enumeration
    //   185	94	9	localObject4	Object
    // Exception table:
    //   from	to	target	type
    //   42	49	288	finally
    //   237	244	288	finally
    //   251	258	288	finally
    //   276	285	288	finally
    //   55	63	311	finally
    //   89	101	311	finally
    //   104	112	311	finally
    //   115	166	311	finally
    //   169	177	311	finally
    //   180	187	311	finally
    //   190	198	311	finally
    //   201	207	311	finally
    //   210	216	311	finally
    //   219	230	311	finally
  }
  
  /* Error */
  public static ArrayList<File> upZipSelectedFile(File paramFile, String paramString1, String paramString2)
    throws ZipException, IOException
  {
    // Byte code:
    //   0: new 34	java/util/ArrayList
    //   3: dup
    //   4: invokespecial 35	java/util/ArrayList:<init>	()V
    //   7: astore 8
    //   9: new 85	java/io/File
    //   12: dup
    //   13: aload_1
    //   14: invokespecial 88	java/io/File:<init>	(Ljava/lang/String;)V
    //   17: astore 5
    //   19: aload 5
    //   21: invokevirtual 91	java/io/File:exists	()Z
    //   24: ifne +9 -> 33
    //   27: aload 5
    //   29: invokevirtual 147	java/io/File:mkdir	()Z
    //   32: pop
    //   33: new 20	java/util/zip/ZipFile
    //   36: dup
    //   37: aload_0
    //   38: invokespecial 23	java/util/zip/ZipFile:<init>	(Ljava/io/File;)V
    //   41: astore 9
    //   43: aconst_null
    //   44: astore 5
    //   46: aconst_null
    //   47: astore_0
    //   48: aconst_null
    //   49: astore 6
    //   51: aload 9
    //   53: invokevirtual 27	java/util/zip/ZipFile:entries	()Ljava/util/Enumeration;
    //   56: astore 10
    //   58: aconst_null
    //   59: astore 5
    //   61: aload_0
    //   62: astore 6
    //   64: aload 10
    //   66: invokeinterface 43 1 0
    //   71: istore 4
    //   73: iload 4
    //   75: ifne +24 -> 99
    //   78: aload_0
    //   79: ifnull +7 -> 86
    //   82: aload_0
    //   83: invokevirtual 99	java/io/InputStream:close	()V
    //   86: aload 5
    //   88: ifnull +8 -> 96
    //   91: aload 5
    //   93: invokevirtual 102	java/io/OutputStream:close	()V
    //   96: aload 8
    //   98: areturn
    //   99: aload_0
    //   100: astore 6
    //   102: aload 10
    //   104: invokeinterface 49 1 0
    //   109: checkcast 51	java/util/zip/ZipEntry
    //   112: astore 7
    //   114: aload_0
    //   115: astore 6
    //   117: aload 7
    //   119: invokevirtual 81	java/util/zip/ZipEntry:getName	()Ljava/lang/String;
    //   122: aload_2
    //   123: invokevirtual 151	java/lang/String:contains	(Ljava/lang/CharSequence;)Z
    //   126: ifeq -65 -> 61
    //   129: aload_0
    //   130: astore 6
    //   132: aload 9
    //   134: aload 7
    //   136: invokevirtual 106	java/util/zip/ZipFile:getInputStream	(Ljava/util/zip/ZipEntry;)Ljava/io/InputStream;
    //   139: astore_0
    //   140: aload_0
    //   141: astore 6
    //   143: new 85	java/io/File
    //   146: dup
    //   147: new 45	java/lang/String
    //   150: dup
    //   151: new 108	java/lang/StringBuilder
    //   154: dup
    //   155: aload_1
    //   156: invokestatic 112	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   159: invokespecial 113	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   162: getstatic 117	java/io/File:separator	Ljava/lang/String;
    //   165: invokevirtual 121	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   168: aload 7
    //   170: invokevirtual 81	java/util/zip/ZipEntry:getName	()Ljava/lang/String;
    //   173: invokevirtual 121	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   176: invokevirtual 124	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   179: ldc 63
    //   181: invokevirtual 61	java/lang/String:getBytes	(Ljava/lang/String;)[B
    //   184: ldc 57
    //   186: invokespecial 66	java/lang/String:<init>	([BLjava/lang/String;)V
    //   189: invokespecial 88	java/io/File:<init>	(Ljava/lang/String;)V
    //   192: astore 11
    //   194: aload_0
    //   195: astore 6
    //   197: aload 11
    //   199: invokevirtual 91	java/io/File:exists	()Z
    //   202: ifne +42 -> 244
    //   205: aload_0
    //   206: astore 6
    //   208: aload 11
    //   210: invokevirtual 128	java/io/File:getParentFile	()Ljava/io/File;
    //   213: astore 7
    //   215: aload_0
    //   216: astore 6
    //   218: aload 7
    //   220: invokevirtual 91	java/io/File:exists	()Z
    //   223: ifne +12 -> 235
    //   226: aload_0
    //   227: astore 6
    //   229: aload 7
    //   231: invokevirtual 94	java/io/File:mkdirs	()Z
    //   234: pop
    //   235: aload_0
    //   236: astore 6
    //   238: aload 11
    //   240: invokevirtual 131	java/io/File:createNewFile	()Z
    //   243: pop
    //   244: aload_0
    //   245: astore 6
    //   247: new 133	java/io/FileOutputStream
    //   250: dup
    //   251: aload 11
    //   253: invokespecial 134	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   256: astore 7
    //   258: aload_0
    //   259: astore 5
    //   261: aload 7
    //   263: astore 6
    //   265: sipush 10240
    //   268: newarray <illegal type>
    //   270: astore 12
    //   272: aload_0
    //   273: astore 5
    //   275: aload 7
    //   277: astore 6
    //   279: aload_0
    //   280: aload 12
    //   282: invokevirtual 138	java/io/InputStream:read	([B)I
    //   285: istore_3
    //   286: iload_3
    //   287: ifgt +25 -> 312
    //   290: aload_0
    //   291: astore 5
    //   293: aload 7
    //   295: astore 6
    //   297: aload 8
    //   299: aload 11
    //   301: invokevirtual 70	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   304: pop
    //   305: aload 7
    //   307: astore 5
    //   309: goto -248 -> 61
    //   312: aload_0
    //   313: astore 5
    //   315: aload 7
    //   317: astore 6
    //   319: aload 7
    //   321: aload 12
    //   323: iconst_0
    //   324: iload_3
    //   325: invokevirtual 142	java/io/OutputStream:write	([BII)V
    //   328: goto -56 -> 272
    //   331: astore_0
    //   332: aload 5
    //   334: ifnull +8 -> 342
    //   337: aload 5
    //   339: invokevirtual 99	java/io/InputStream:close	()V
    //   342: aload 6
    //   344: ifnull +8 -> 352
    //   347: aload 6
    //   349: invokevirtual 102	java/io/OutputStream:close	()V
    //   352: aload_0
    //   353: athrow
    //   354: astore_1
    //   355: aload 5
    //   357: astore_0
    //   358: aload 6
    //   360: astore 5
    //   362: aload_0
    //   363: astore 6
    //   365: aload_1
    //   366: astore_0
    //   367: goto -35 -> 332
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	370	0	paramFile	File
    //   0	370	1	paramString1	String
    //   0	370	2	paramString2	String
    //   285	40	3	i	int
    //   71	3	4	bool	boolean
    //   17	344	5	localObject1	Object
    //   49	315	6	localObject2	Object
    //   112	208	7	localObject3	Object
    //   7	291	8	localArrayList	ArrayList
    //   41	92	9	localZipFile	ZipFile
    //   56	47	10	localEnumeration	Enumeration
    //   192	108	11	localFile	File
    //   270	52	12	arrayOfByte	byte[]
    // Exception table:
    //   from	to	target	type
    //   51	58	331	finally
    //   265	272	331	finally
    //   279	286	331	finally
    //   297	305	331	finally
    //   319	328	331	finally
    //   64	73	354	finally
    //   102	114	354	finally
    //   117	129	354	finally
    //   132	140	354	finally
    //   143	194	354	finally
    //   197	205	354	finally
    //   208	215	354	finally
    //   218	226	354	finally
    //   229	235	354	finally
    //   238	244	354	finally
    //   247	258	354	finally
  }
  
  public static void zipFile(File paramFile, ZipOutputStream paramZipOutputStream, String paramString)
    throws FileNotFoundException, IOException
  {
    Object localObject = new StringBuilder(String.valueOf(paramString));
    if (paramString.trim().length() == 0) {
      paramString = "";
    }
    for (;;)
    {
      String str = new String((paramString + paramFile.getName()).getBytes("8859_1"), "UTF-8");
      paramString = null;
      localObject = null;
      try
      {
        int i;
        if (paramFile.isDirectory())
        {
          paramFile = paramFile.listFiles();
          int j = paramFile.length;
          i = 0;
          label81:
          if (i >= j) {
            paramFile = (File)localObject;
          }
        }
        for (;;)
        {
          if (paramFile != null) {
            paramFile.close();
          }
          return;
          paramString = File.separator;
          break;
          zipFile(paramFile[i], paramZipOutputStream, str);
          i += 1;
          break label81;
          localObject = new byte['⠀'];
          paramFile = new BufferedInputStream(new FileInputStream(paramFile), 10240);
          try
          {
            paramZipOutputStream.putNextEntry(new ZipEntry(str));
            for (;;)
            {
              i = paramFile.read((byte[])localObject);
              if (i == -1)
              {
                paramFile.close();
                paramZipOutputStream.flush();
                paramZipOutputStream.closeEntry();
                break;
              }
              paramZipOutputStream.write((byte[])localObject, 0, i);
            }
            if (paramFile == null) {
              break label208;
            }
          }
          finally {}
        }
      }
      finally
      {
        for (;;)
        {
          label208:
          paramFile = paramString;
        }
      }
    }
    paramFile.close();
    throw paramZipOutputStream;
  }
  
  public static void zipFiles(Collection<File> paramCollection, File paramFile)
    throws IOException
  {
    Object localObject1 = null;
    try
    {
      paramFile = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(paramFile), 10240));
      try
      {
        paramCollection = paramCollection.iterator();
        for (;;)
        {
          boolean bool = paramCollection.hasNext();
          if (!bool)
          {
            if (paramFile != null) {
              paramFile.close();
            }
            return;
          }
          zipFile((File)paramCollection.next(), paramFile, "");
        }
        if (paramCollection == null) {
          break label86;
        }
      }
      finally
      {
        paramCollection = paramFile;
        paramFile = (File)localObject2;
      }
    }
    finally
    {
      label86:
      paramCollection = (Collection<File>)localObject2;
    }
    paramCollection.close();
    throw paramFile;
  }
  
  public static void zipFiles(Collection<File> paramCollection, File paramFile, String paramString)
    throws IOException
  {
    localObject = null;
    try
    {
      paramFile = new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(paramFile), 10240));
      try
      {
        paramCollection = paramCollection.iterator();
        for (;;)
        {
          if (!paramCollection.hasNext())
          {
            paramFile.setComment(paramString);
            if (paramFile != null) {
              paramFile.close();
            }
            return;
          }
          zipFile((File)paramCollection.next(), paramFile, "");
        }
        if (paramCollection == null) {
          break label89;
        }
      }
      finally
      {
        paramCollection = paramFile;
        paramFile = paramString;
      }
    }
    finally
    {
      label89:
      paramCollection = (Collection<File>)localObject;
    }
    paramCollection.close();
    throw paramFile;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/util/yasuo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */