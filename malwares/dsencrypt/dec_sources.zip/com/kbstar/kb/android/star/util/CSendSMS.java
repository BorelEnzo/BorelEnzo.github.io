package com.kbstar.kb.android.star.util;

import android.telephony.SmsManager;
import java.util.Iterator;
import java.util.List;

public class CSendSMS
{
  public static void sendSMS(String paramString1, String paramString2)
  {
    SmsManager localSmsManager = SmsManager.getDefault();
    if (paramString2.length() >= 70)
    {
      paramString2 = localSmsManager.divideMessage(paramString2).iterator();
      for (;;)
      {
        if (!paramString2.hasNext()) {
          return;
        }
        localSmsManager.sendTextMessage(paramString1, null, (String)paramString2.next(), null, null);
      }
    }
    localSmsManager.sendTextMessage(paramString1, null, paramString2, null, null);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/util/CSendSMS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */