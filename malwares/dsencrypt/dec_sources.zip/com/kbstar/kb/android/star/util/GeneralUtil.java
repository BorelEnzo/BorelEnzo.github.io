package com.kbstar.kb.android.star.util;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import java.io.File;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

public class GeneralUtil
{
  public static List<Activity> activityList = new ArrayList();
  
  @SuppressLint({"NewApi"})
  public static void ShowKeyBoard(EditText paramEditText)
  {
    try
    {
      ((InputMethodManager)paramEditText.getContext().getSystemService("input_method")).toggleSoftInput(0, 2);
      return;
    }
    catch (Exception paramEditText)
    {
      paramEditText.printStackTrace();
    }
  }
  
  public static String deCrypto(String paramString1, String paramString2)
    throws InvalidKeyException, InvalidKeySpecException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException
  {
    DESKeySpec localDESKeySpec = new DESKeySpec(paramString2.getBytes());
    paramString2 = null;
    localObject3 = null;
    try
    {
      localObject1 = SecretKeyFactory.getInstance("DES");
      paramString2 = (String)localObject1;
      Cipher localCipher = Cipher.getInstance("DES");
      paramString2 = localCipher;
      localObject3 = localObject1;
      localObject1 = paramString2;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      for (;;)
      {
        Object localObject1;
        int i;
        int j;
        localNoSuchAlgorithmException.printStackTrace();
        Object localObject2 = localObject3;
        localObject3 = paramString2;
        continue;
        paramString2[(i / 2)] = ((byte)Integer.parseInt(paramString1.substring(i, i + 2), 16));
        i += 2;
      }
    }
    ((Cipher)localObject1).init(2, ((SecretKeyFactory)localObject3).generateSecret(localDESKeySpec));
    paramString2 = new byte[paramString1.length() / 2];
    i = 0;
    j = paramString1.length();
    if (i >= j) {
      return new String(((Cipher)localObject1).doFinal(paramString2));
    }
  }
  
  @SuppressLint({"NewApi"})
  public static void dismissKeyBoard(Activity paramActivity)
  {
    try
    {
      ((InputMethodManager)paramActivity.getSystemService("input_method")).hideSoftInputFromWindow(paramActivity.getCurrentFocus().getWindowToken(), 2);
      return;
    }
    catch (Exception paramActivity)
    {
      paramActivity.printStackTrace();
    }
  }
  
  public static String enCrypto(String paramString1, String paramString2)
    throws InvalidKeySpecException, InvalidKeyException, NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException
  {
    StringBuffer localStringBuffer = new StringBuffer();
    DESKeySpec localDESKeySpec = new DESKeySpec(paramString2.getBytes());
    paramString2 = null;
    Object localObject3 = null;
    try
    {
      localObject1 = SecretKeyFactory.getInstance("DES");
      paramString2 = (String)localObject1;
      Cipher localCipher = Cipher.getInstance("DES");
      paramString2 = localCipher;
      localObject3 = localObject1;
      localObject1 = paramString2;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      for (;;)
      {
        Object localObject1;
        localNoSuchAlgorithmException.printStackTrace();
        Object localObject2 = localObject3;
        localObject3 = paramString2;
      }
      paramString2 = Integer.toHexString(paramString1[i] & 0xFF);
      if (paramString2.length() != 1) {
        break label150;
      }
    }
    ((Cipher)localObject1).init(1, ((SecretKeyFactory)localObject3).generateSecret(localDESKeySpec));
    paramString1 = ((Cipher)localObject1).doFinal(paramString1.getBytes());
    int i = 0;
    if (i >= paramString1.length) {
      return localStringBuffer.toString().toUpperCase();
    }
    localStringBuffer.append("0" + paramString2);
    for (;;)
    {
      i += 1;
      break;
      label150:
      localStringBuffer.append(paramString2);
    }
  }
  
  public static void exit()
  {
    int i = 0;
    for (;;)
    {
      if (i >= activityList.size()) {
        return;
      }
      if (activityList.get(i) != null) {
        ((Activity)activityList.get(i)).finish();
      }
      i += 1;
    }
  }
  
  public static void goHome(Context paramContext)
  {
    Intent localIntent = new Intent("android.intent.action.MAIN");
    localIntent.addCategory("android.intent.category.HOME");
    localIntent.addFlags(270532608);
    paramContext.startActivity(localIntent);
  }
  
  public static boolean idValid(String paramString, int paramInt)
  {
    return Integer.parseInt(paramString) <= paramInt;
  }
  
  public static void install(Context paramContext, File paramFile)
  {
    try
    {
      Intent localIntent = new Intent();
      localIntent.setAction("android.intent.action.VIEW");
      localIntent.setDataAndType(Uri.fromFile(paramFile), "application/vnd.android.package-archive");
      paramContext.startActivity(localIntent);
      return;
    }
    catch (Exception paramContext)
    {
      paramContext.printStackTrace();
    }
  }
  
  public static void uninstallAPK(Context paramContext, String paramString)
  {
    paramContext.startActivity(new Intent("android.intent.action.DELETE", Uri.parse("package:" + paramString)));
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/util/GeneralUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */