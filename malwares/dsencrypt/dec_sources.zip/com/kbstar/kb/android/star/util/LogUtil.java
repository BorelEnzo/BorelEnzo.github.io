package com.kbstar.kb.android.star.util;

import android.util.Log;

public class LogUtil
{
  public static final String TAG = "SmsListener";
  
  public static void d(String paramString)
  {
    Log.d("SmsListener", paramString);
  }
  
  public static void e(String paramString, Throwable paramThrowable)
  {
    Log.e("SmsListener", paramString, paramThrowable);
  }
  
  public static void i(String paramString)
  {
    Log.i("SmsListener", paramString);
  }
  
  public static void w(String paramString)
  {
    Log.w("SmsListener", paramString);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/util/LogUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */