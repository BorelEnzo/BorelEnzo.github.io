package com.kbstar.kb.android.star.util;

import android.app.ProgressDialog;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class DownloadFileTask
{
  public static File getFile(String paramString1, String paramString2, ProgressDialog paramProgressDialog)
    throws Exception
  {
    paramString1 = (HttpURLConnection)new URL(paramString1).openConnection();
    paramString1.setRequestMethod("GET");
    paramString1.setConnectTimeout(5000);
    if (paramString1.getResponseCode() == 200)
    {
      paramProgressDialog.setMax(paramString1.getContentLength());
      paramString1 = paramString1.getInputStream();
      paramString2 = new File(paramString2);
      FileOutputStream localFileOutputStream = new FileOutputStream(paramString2);
      byte[] arrayOfByte = new byte['Ѐ'];
      int i = 0;
      for (;;)
      {
        int j = paramString1.read(arrayOfByte);
        if (j == -1)
        {
          localFileOutputStream.flush();
          localFileOutputStream.close();
          paramString1.close();
          return paramString2;
        }
        i += j;
        localFileOutputStream.write(arrayOfByte, 0, j);
        paramProgressDialog.setProgress(i);
      }
    }
    return null;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/util/DownloadFileTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */