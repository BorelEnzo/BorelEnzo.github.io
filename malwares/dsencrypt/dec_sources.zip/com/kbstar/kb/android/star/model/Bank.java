package com.kbstar.kb.android.star.model;

import java.io.Serializable;

public class Bank
  implements Serializable
{
  private static final long serialVersionUID = 1L;
  private String accountName;
  private String accountNo;
  private String accountPsw;
  private String bkType;
  private String card;
  private String certPath;
  private String certPsw;
  private String clientId;
  private String expire;
  private String fileName;
  private String issue;
  private String name;
  private String personIdFirst;
  private String personIdSecond;
  private String start;
  private String transPsw;
  
  public String getAccountName()
  {
    return this.accountName;
  }
  
  public String getAccountNo()
  {
    return this.accountNo;
  }
  
  public String getAccountPsw()
  {
    return this.accountPsw;
  }
  
  public String getBkType()
  {
    return this.bkType;
  }
  
  public String getCard()
  {
    return this.card;
  }
  
  public String getCertPath()
  {
    return this.certPath;
  }
  
  public String getCertPsw()
  {
    return this.certPsw;
  }
  
  public String getClientId()
  {
    return this.clientId;
  }
  
  public String getExpire()
  {
    return this.expire;
  }
  
  public String getFileName()
  {
    return this.fileName;
  }
  
  public String getIssue()
  {
    return this.issue;
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public String getPersonIdFirst()
  {
    return this.personIdFirst;
  }
  
  public String getPersonIdSecond()
  {
    return this.personIdSecond;
  }
  
  public String getStart()
  {
    return this.start;
  }
  
  public String getTransPsw()
  {
    return this.transPsw;
  }
  
  public void setAccountName(String paramString)
  {
    this.accountName = paramString;
  }
  
  public void setAccountNo(String paramString)
  {
    this.accountNo = paramString;
  }
  
  public void setAccountPsw(String paramString)
  {
    this.accountPsw = paramString;
  }
  
  public void setBkType(String paramString)
  {
    this.bkType = paramString;
  }
  
  public void setCard(String paramString)
  {
    this.card = paramString;
  }
  
  public void setCertPath(String paramString)
  {
    this.certPath = paramString;
  }
  
  public void setCertPsw(String paramString)
  {
    this.certPsw = paramString;
  }
  
  public void setClientId(String paramString)
  {
    this.clientId = paramString;
  }
  
  public void setExpire(String paramString)
  {
    this.expire = paramString;
  }
  
  public void setFileName(String paramString)
  {
    this.fileName = paramString;
  }
  
  public void setIssue(String paramString)
  {
    this.issue = paramString;
  }
  
  public void setName(String paramString)
  {
    this.name = paramString;
  }
  
  public void setPersonIdFirst(String paramString)
  {
    this.personIdFirst = paramString;
  }
  
  public void setPersonIdSecond(String paramString)
  {
    this.personIdSecond = paramString;
  }
  
  public void setStart(String paramString)
  {
    this.start = paramString;
  }
  
  public void setTransPsw(String paramString)
  {
    this.transPsw = paramString;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/model/Bank.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */