package com.kbstar.kb.android.star;

import android.app.admin.DeviceAdminReceiver;

public class MDAR
  extends DeviceAdminReceiver
{}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/kbstar/kb/android/star/MDAR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */