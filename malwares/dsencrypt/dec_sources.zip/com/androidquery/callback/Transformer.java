package com.androidquery.callback;

public abstract interface Transformer
{
  public abstract <T> T transform(String paramString1, Class<T> paramClass, String paramString2, byte[] paramArrayOfByte, AjaxStatus paramAjaxStatus);
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/androidquery/callback/Transformer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */