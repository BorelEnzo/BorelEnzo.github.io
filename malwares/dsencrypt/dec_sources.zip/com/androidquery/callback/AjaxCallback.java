package com.androidquery.callback;

public class AjaxCallback<T>
  extends AbstractAjaxCallback<T, AjaxCallback<T>>
{}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/androidquery/callback/AjaxCallback.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */