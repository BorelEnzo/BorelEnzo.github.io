package com.androidquery.callback;

import android.graphics.Bitmap;

public class ImageOptions
{
  public float anchor = Float.MAX_VALUE;
  public int animation;
  public int fallback;
  public boolean fileCache = true;
  public boolean memCache = true;
  public int policy;
  public Bitmap preset;
  public float ratio;
  public int round;
  public int targetWidth;
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/androidquery/callback/ImageOptions.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */