package com.androidquery;

import android.app.Activity;
import android.content.Context;
import android.view.View;

public class AQuery
  extends AbstractAQuery<AQuery>
{
  public AQuery(Activity paramActivity)
  {
    super(paramActivity);
  }
  
  public AQuery(Activity paramActivity, View paramView)
  {
    super(paramActivity, paramView);
  }
  
  public AQuery(Context paramContext)
  {
    super(paramContext);
  }
  
  public AQuery(View paramView)
  {
    super(paramView);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/androidquery/AQuery.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */