package com.sun.mail.imap;

import com.sun.mail.imap.protocol.MessageSet;
import com.sun.mail.imap.protocol.UIDSet;
import java.util.Vector;
import javax.mail.Message;

public final class Utility
{
  public static MessageSet[] toMessageSet(Message[] paramArrayOfMessage, Condition paramCondition)
  {
    Vector localVector = new Vector(1);
    int i = 0;
    if (i >= paramArrayOfMessage.length)
    {
      if (localVector.isEmpty()) {
        return null;
      }
    }
    else
    {
      Object localObject = (IMAPMessage)paramArrayOfMessage[i];
      if (((IMAPMessage)localObject).isExpunged()) {
        j = i;
      }
      int k;
      do
      {
        i = j + 1;
        break;
        k = ((IMAPMessage)localObject).getSequenceNumber();
        if (paramCondition == null) {
          break label77;
        }
        j = i;
      } while (!paramCondition.test((IMAPMessage)localObject));
      label77:
      localObject = new MessageSet();
      ((MessageSet)localObject).start = k;
      i += 1;
      int j = k;
      if (i >= paramArrayOfMessage.length) {}
      for (;;)
      {
        ((MessageSet)localObject).end = j;
        localVector.addElement(localObject);
        j = i;
        break;
        IMAPMessage localIMAPMessage = (IMAPMessage)paramArrayOfMessage[i];
        if (localIMAPMessage.isExpunged()) {
          k = j;
        }
        for (;;)
        {
          i += 1;
          j = k;
          break;
          int m = localIMAPMessage.getSequenceNumber();
          if (paramCondition != null)
          {
            k = j;
            if (!paramCondition.test(localIMAPMessage)) {}
          }
          else
          {
            if (m != j + 1) {
              break label193;
            }
            k = m;
          }
        }
        label193:
        i -= 1;
      }
    }
    paramArrayOfMessage = new MessageSet[localVector.size()];
    localVector.copyInto(paramArrayOfMessage);
    return paramArrayOfMessage;
  }
  
  public static UIDSet[] toUIDSet(Message[] paramArrayOfMessage)
  {
    Vector localVector = new Vector(1);
    int i = 0;
    for (;;)
    {
      if (i >= paramArrayOfMessage.length)
      {
        if (!localVector.isEmpty()) {
          break label150;
        }
        return null;
      }
      localObject = (IMAPMessage)paramArrayOfMessage[i];
      if (!((IMAPMessage)localObject).isExpunged()) {
        break;
      }
      i += 1;
    }
    long l1 = ((IMAPMessage)localObject).getUID();
    Object localObject = new UIDSet();
    ((UIDSet)localObject).start = l1;
    i += 1;
    if (i >= paramArrayOfMessage.length) {}
    for (;;)
    {
      ((UIDSet)localObject).end = l1;
      localVector.addElement(localObject);
      break;
      IMAPMessage localIMAPMessage = (IMAPMessage)paramArrayOfMessage[i];
      if (localIMAPMessage.isExpunged()) {}
      for (;;)
      {
        i += 1;
        break;
        long l2 = localIMAPMessage.getUID();
        if (l2 != 1L + l1) {
          break label143;
        }
        l1 = l2;
      }
      label143:
      i -= 1;
    }
    label150:
    paramArrayOfMessage = new UIDSet[localVector.size()];
    localVector.copyInto(paramArrayOfMessage);
    return paramArrayOfMessage;
  }
  
  public static abstract interface Condition
  {
    public abstract boolean test(IMAPMessage paramIMAPMessage);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/Utility.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */