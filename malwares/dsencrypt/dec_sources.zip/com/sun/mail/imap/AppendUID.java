package com.sun.mail.imap;

public class AppendUID
{
  public long uid = -1L;
  public long uidvalidity = -1L;
  
  public AppendUID(long paramLong1, long paramLong2)
  {
    this.uidvalidity = paramLong1;
    this.uid = paramLong2;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/AppendUID.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */