package com.sun.mail.imap;

import java.util.Vector;

public class Rights
  implements Cloneable
{
  private boolean[] rights = new boolean[''];
  
  public Rights() {}
  
  public Rights(Right paramRight)
  {
    this.rights[paramRight.right] = true;
  }
  
  public Rights(Rights paramRights)
  {
    System.arraycopy(paramRights.rights, 0, this.rights, 0, this.rights.length);
  }
  
  public Rights(String paramString)
  {
    int i = 0;
    for (;;)
    {
      if (i >= paramString.length()) {
        return;
      }
      add(Right.getInstance(paramString.charAt(i)));
      i += 1;
    }
  }
  
  public void add(Right paramRight)
  {
    this.rights[paramRight.right] = true;
  }
  
  public void add(Rights paramRights)
  {
    int i = 0;
    for (;;)
    {
      if (i >= paramRights.rights.length) {
        return;
      }
      if (paramRights.rights[i] != 0) {
        this.rights[i] = true;
      }
      i += 1;
    }
  }
  
  public Object clone()
  {
    Object localObject = null;
    try
    {
      Rights localRights = (Rights)super.clone();
      localObject = localRights;
      localRights.rights = new boolean[''];
      localObject = localRights;
      System.arraycopy(this.rights, 0, localRights.rights, 0, this.rights.length);
      return localRights;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException) {}
    return localObject;
  }
  
  public boolean contains(Right paramRight)
  {
    return this.rights[paramRight.right];
  }
  
  public boolean contains(Rights paramRights)
  {
    int i = 0;
    for (;;)
    {
      if (i >= paramRights.rights.length) {
        return true;
      }
      if ((paramRights.rights[i] != 0) && (this.rights[i] == 0)) {
        return false;
      }
      i += 1;
    }
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof Rights)) {
      return false;
    }
    paramObject = (Rights)paramObject;
    int i = 0;
    for (;;)
    {
      if (i >= ((Rights)paramObject).rights.length) {
        return true;
      }
      if (paramObject.rights[i] != this.rights[i]) {
        break;
      }
      i += 1;
    }
  }
  
  public Right[] getRights()
  {
    Vector localVector = new Vector();
    int i = 0;
    for (;;)
    {
      if (i >= this.rights.length)
      {
        Right[] arrayOfRight = new Right[localVector.size()];
        localVector.copyInto(arrayOfRight);
        return arrayOfRight;
      }
      if (this.rights[i] != 0) {
        localVector.addElement(Right.getInstance((char)i));
      }
      i += 1;
    }
  }
  
  public int hashCode()
  {
    int j = 0;
    int i = 0;
    for (;;)
    {
      if (i >= this.rights.length) {
        return j;
      }
      int k = j;
      if (this.rights[i] != 0) {
        k = j + 1;
      }
      i += 1;
      j = k;
    }
  }
  
  public void remove(Right paramRight)
  {
    this.rights[paramRight.right] = false;
  }
  
  public void remove(Rights paramRights)
  {
    int i = 0;
    for (;;)
    {
      if (i >= paramRights.rights.length) {
        return;
      }
      if (paramRights.rights[i] != 0) {
        this.rights[i] = false;
      }
      i += 1;
    }
  }
  
  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    int i = 0;
    for (;;)
    {
      if (i >= this.rights.length) {
        return localStringBuffer.toString();
      }
      if (this.rights[i] != 0) {
        localStringBuffer.append((char)i);
      }
      i += 1;
    }
  }
  
  public static final class Right
  {
    public static final Right ADMINISTER = getInstance('a');
    public static final Right CREATE;
    public static final Right DELETE;
    public static final Right INSERT;
    public static final Right KEEP_SEEN;
    public static final Right LOOKUP;
    public static final Right POST;
    public static final Right READ;
    public static final Right WRITE;
    private static Right[] cache = new Right[''];
    char right;
    
    static
    {
      LOOKUP = getInstance('l');
      READ = getInstance('r');
      KEEP_SEEN = getInstance('s');
      WRITE = getInstance('w');
      INSERT = getInstance('i');
      POST = getInstance('p');
      CREATE = getInstance('c');
      DELETE = getInstance('d');
    }
    
    private Right(char paramChar)
    {
      if (paramChar >= '') {
        throw new IllegalArgumentException("Right must be ASCII");
      }
      this.right = paramChar;
    }
    
    public static Right getInstance(char paramChar)
    {
      if (paramChar >= '') {
        try
        {
          throw new IllegalArgumentException("Right must be ASCII");
        }
        finally {}
      }
      if (cache[paramChar] == null) {
        cache[paramChar] = new Right(paramChar);
      }
      Right localRight = cache[paramChar];
      return localRight;
    }
    
    public String toString()
    {
      return String.valueOf(this.right);
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/Rights.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */