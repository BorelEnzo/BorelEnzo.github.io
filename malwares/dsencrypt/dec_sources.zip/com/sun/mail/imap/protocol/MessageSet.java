package com.sun.mail.imap.protocol;

import java.util.Vector;

public class MessageSet
{
  public int end;
  public int start;
  
  public MessageSet() {}
  
  public MessageSet(int paramInt1, int paramInt2)
  {
    this.start = paramInt1;
    this.end = paramInt2;
  }
  
  public static MessageSet[] createMessageSets(int[] paramArrayOfInt)
  {
    Vector localVector = new Vector();
    int i = 0;
    if (i >= paramArrayOfInt.length)
    {
      paramArrayOfInt = new MessageSet[localVector.size()];
      localVector.copyInto(paramArrayOfInt);
      return paramArrayOfInt;
    }
    MessageSet localMessageSet = new MessageSet();
    localMessageSet.start = paramArrayOfInt[i];
    i += 1;
    for (;;)
    {
      if (i >= paramArrayOfInt.length) {}
      while (paramArrayOfInt[i] != paramArrayOfInt[(i - 1)] + 1)
      {
        localMessageSet.end = paramArrayOfInt[(i - 1)];
        localVector.addElement(localMessageSet);
        i = i - 1 + 1;
        break;
      }
      i += 1;
    }
  }
  
  public static int size(MessageSet[] paramArrayOfMessageSet)
  {
    int j = 0;
    if (paramArrayOfMessageSet == null) {
      return 0;
    }
    int i = 0;
    for (;;)
    {
      if (i >= paramArrayOfMessageSet.length) {
        return j;
      }
      j += paramArrayOfMessageSet[i].size();
      i += 1;
    }
  }
  
  public static String toString(MessageSet[] paramArrayOfMessageSet)
  {
    if ((paramArrayOfMessageSet == null) || (paramArrayOfMessageSet.length == 0)) {
      return null;
    }
    int i = 0;
    StringBuffer localStringBuffer = new StringBuffer();
    int j = paramArrayOfMessageSet.length;
    for (;;)
    {
      int k = paramArrayOfMessageSet[i].start;
      int m = paramArrayOfMessageSet[i].end;
      if (m > k) {
        localStringBuffer.append(k).append(':').append(m);
      }
      for (;;)
      {
        i += 1;
        if (i < j) {
          break;
        }
        return localStringBuffer.toString();
        localStringBuffer.append(k);
      }
      localStringBuffer.append(',');
    }
  }
  
  public int size()
  {
    return this.end - this.start + 1;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/protocol/MessageSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */