package com.sun.mail.imap.protocol;

import com.sun.mail.iap.ParsingException;
import com.sun.mail.iap.Response;
import java.util.Vector;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

class IMAPAddress
  extends InternetAddress
{
  private static final long serialVersionUID = -3835822029483122232L;
  private boolean group = false;
  private InternetAddress[] grouplist;
  private String groupname;
  
  IMAPAddress(Response paramResponse)
    throws ParsingException
  {
    paramResponse.skipSpaces();
    if (paramResponse.readByte() != 40) {
      throw new ParsingException("ADDRESS parse error");
    }
    this.encodedPersonal = paramResponse.readString();
    paramResponse.readString();
    Object localObject1 = paramResponse.readString();
    Object localObject2 = paramResponse.readString();
    if (paramResponse.readByte() != 41) {
      throw new ParsingException("ADDRESS parse error");
    }
    if (localObject2 == null)
    {
      this.group = true;
      this.groupname = ((String)localObject1);
      if (this.groupname == null) {
        return;
      }
      localObject1 = new StringBuffer();
      ((StringBuffer)localObject1).append(this.groupname).append(':');
      localObject2 = new Vector();
      for (;;)
      {
        if (paramResponse.peekByte() == 41) {}
        IMAPAddress localIMAPAddress;
        do
        {
          ((StringBuffer)localObject1).append(';');
          this.address = ((StringBuffer)localObject1).toString();
          this.grouplist = new IMAPAddress[((Vector)localObject2).size()];
          ((Vector)localObject2).copyInto(this.grouplist);
          return;
          localIMAPAddress = new IMAPAddress(paramResponse);
        } while (localIMAPAddress.isEndOfGroup());
        if (((Vector)localObject2).size() != 0) {
          ((StringBuffer)localObject1).append(',');
        }
        ((StringBuffer)localObject1).append(localIMAPAddress.toString());
        ((Vector)localObject2).addElement(localIMAPAddress);
      }
    }
    if ((localObject1 == null) || (((String)localObject1).length() == 0))
    {
      this.address = ((String)localObject2);
      return;
    }
    if (((String)localObject2).length() == 0)
    {
      this.address = ((String)localObject1);
      return;
    }
    this.address = (localObject1 + "@" + (String)localObject2);
  }
  
  public InternetAddress[] getGroup(boolean paramBoolean)
    throws AddressException
  {
    if (this.grouplist == null) {
      return null;
    }
    return (InternetAddress[])this.grouplist.clone();
  }
  
  boolean isEndOfGroup()
  {
    return (this.group) && (this.groupname == null);
  }
  
  public boolean isGroup()
  {
    return this.group;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/protocol/IMAPAddress.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */