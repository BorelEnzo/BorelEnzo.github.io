package com.sun.mail.imap.protocol;

import com.sun.mail.iap.ParsingException;

public class RFC822SIZE
  implements Item
{
  static final char[] name = { 82, 70, 67, 56, 50, 50, 46, 83, 73, 90, 69 };
  public int msgno;
  public int size;
  
  public RFC822SIZE(FetchResponse paramFetchResponse)
    throws ParsingException
  {
    this.msgno = paramFetchResponse.getNumber();
    paramFetchResponse.skipSpaces();
    this.size = paramFetchResponse.readNumber();
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/protocol/RFC822SIZE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */