package com.sun.mail.imap.protocol;

import com.sun.mail.iap.Argument;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import javax.mail.Address;
import javax.mail.Flags;
import javax.mail.Flags.Flag;
import javax.mail.Message.RecipientType;
import javax.mail.search.AddressTerm;
import javax.mail.search.AndTerm;
import javax.mail.search.BodyTerm;
import javax.mail.search.DateTerm;
import javax.mail.search.FlagTerm;
import javax.mail.search.FromStringTerm;
import javax.mail.search.FromTerm;
import javax.mail.search.HeaderTerm;
import javax.mail.search.MessageIDTerm;
import javax.mail.search.NotTerm;
import javax.mail.search.OrTerm;
import javax.mail.search.ReceivedDateTerm;
import javax.mail.search.RecipientStringTerm;
import javax.mail.search.RecipientTerm;
import javax.mail.search.SearchException;
import javax.mail.search.SearchTerm;
import javax.mail.search.SentDateTerm;
import javax.mail.search.SizeTerm;
import javax.mail.search.StringTerm;
import javax.mail.search.SubjectTerm;

class SearchSequence
{
  private static Calendar cal = new GregorianCalendar();
  private static String[] monthTable = { "Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
  
  private static Argument and(AndTerm paramAndTerm, String paramString)
    throws SearchException, IOException
  {
    paramAndTerm = paramAndTerm.getTerms();
    Argument localArgument = generateSequence(paramAndTerm[0], paramString);
    int i = 1;
    for (;;)
    {
      if (i >= paramAndTerm.length) {
        return localArgument;
      }
      localArgument.append(generateSequence(paramAndTerm[i], paramString));
      i += 1;
    }
  }
  
  private static Argument body(BodyTerm paramBodyTerm, String paramString)
    throws SearchException, IOException
  {
    Argument localArgument = new Argument();
    localArgument.writeAtom("BODY");
    localArgument.writeString(paramBodyTerm.getPattern(), paramString);
    return localArgument;
  }
  
  private static Argument flag(FlagTerm paramFlagTerm)
    throws SearchException
  {
    boolean bool = paramFlagTerm.getTestSet();
    Argument localArgument = new Argument();
    paramFlagTerm = paramFlagTerm.getFlags();
    Flags.Flag[] arrayOfFlag = paramFlagTerm.getSystemFlags();
    String[] arrayOfString = paramFlagTerm.getUserFlags();
    if ((arrayOfFlag.length == 0) && (arrayOfString.length == 0)) {
      throw new SearchException("Invalid FlagTerm");
    }
    int i = 0;
    if (i >= arrayOfFlag.length)
    {
      i = 0;
      if (i >= arrayOfString.length) {
        return localArgument;
      }
    }
    else
    {
      if (arrayOfFlag[i] == Flags.Flag.DELETED) {
        if (bool)
        {
          paramFlagTerm = "DELETED";
          label89:
          localArgument.writeAtom(paramFlagTerm);
        }
      }
      do
      {
        i += 1;
        break;
        paramFlagTerm = "UNDELETED";
        break label89;
        if (arrayOfFlag[i] == Flags.Flag.ANSWERED)
        {
          if (bool) {}
          for (paramFlagTerm = "ANSWERED";; paramFlagTerm = "UNANSWERED")
          {
            localArgument.writeAtom(paramFlagTerm);
            break;
          }
        }
        if (arrayOfFlag[i] == Flags.Flag.DRAFT)
        {
          if (bool) {}
          for (paramFlagTerm = "DRAFT";; paramFlagTerm = "UNDRAFT")
          {
            localArgument.writeAtom(paramFlagTerm);
            break;
          }
        }
        if (arrayOfFlag[i] == Flags.Flag.FLAGGED)
        {
          if (bool) {}
          for (paramFlagTerm = "FLAGGED";; paramFlagTerm = "UNFLAGGED")
          {
            localArgument.writeAtom(paramFlagTerm);
            break;
          }
        }
        if (arrayOfFlag[i] == Flags.Flag.RECENT)
        {
          if (bool) {}
          for (paramFlagTerm = "RECENT";; paramFlagTerm = "OLD")
          {
            localArgument.writeAtom(paramFlagTerm);
            break;
          }
        }
      } while (arrayOfFlag[i] != Flags.Flag.SEEN);
      if (bool) {}
      for (paramFlagTerm = "SEEN";; paramFlagTerm = "UNSEEN")
      {
        localArgument.writeAtom(paramFlagTerm);
        break;
      }
    }
    if (bool) {}
    for (paramFlagTerm = "KEYWORD";; paramFlagTerm = "UNKEYWORD")
    {
      localArgument.writeAtom(paramFlagTerm);
      localArgument.writeAtom(arrayOfString[i]);
      i += 1;
      break;
    }
  }
  
  private static Argument from(String paramString1, String paramString2)
    throws SearchException, IOException
  {
    Argument localArgument = new Argument();
    localArgument.writeAtom("FROM");
    localArgument.writeString(paramString1, paramString2);
    return localArgument;
  }
  
  static Argument generateSequence(SearchTerm paramSearchTerm, String paramString)
    throws SearchException, IOException
  {
    if ((paramSearchTerm instanceof AndTerm)) {
      return and((AndTerm)paramSearchTerm, paramString);
    }
    if ((paramSearchTerm instanceof OrTerm)) {
      return or((OrTerm)paramSearchTerm, paramString);
    }
    if ((paramSearchTerm instanceof NotTerm)) {
      return not((NotTerm)paramSearchTerm, paramString);
    }
    if ((paramSearchTerm instanceof HeaderTerm)) {
      return header((HeaderTerm)paramSearchTerm, paramString);
    }
    if ((paramSearchTerm instanceof FlagTerm)) {
      return flag((FlagTerm)paramSearchTerm);
    }
    if ((paramSearchTerm instanceof FromTerm)) {
      return from(((FromTerm)paramSearchTerm).getAddress().toString(), paramString);
    }
    if ((paramSearchTerm instanceof FromStringTerm)) {
      return from(((FromStringTerm)paramSearchTerm).getPattern(), paramString);
    }
    if ((paramSearchTerm instanceof RecipientTerm))
    {
      paramSearchTerm = (RecipientTerm)paramSearchTerm;
      return recipient(paramSearchTerm.getRecipientType(), paramSearchTerm.getAddress().toString(), paramString);
    }
    if ((paramSearchTerm instanceof RecipientStringTerm))
    {
      paramSearchTerm = (RecipientStringTerm)paramSearchTerm;
      return recipient(paramSearchTerm.getRecipientType(), paramSearchTerm.getPattern(), paramString);
    }
    if ((paramSearchTerm instanceof SubjectTerm)) {
      return subject((SubjectTerm)paramSearchTerm, paramString);
    }
    if ((paramSearchTerm instanceof BodyTerm)) {
      return body((BodyTerm)paramSearchTerm, paramString);
    }
    if ((paramSearchTerm instanceof SizeTerm)) {
      return size((SizeTerm)paramSearchTerm);
    }
    if ((paramSearchTerm instanceof SentDateTerm)) {
      return sentdate((SentDateTerm)paramSearchTerm);
    }
    if ((paramSearchTerm instanceof ReceivedDateTerm)) {
      return receiveddate((ReceivedDateTerm)paramSearchTerm);
    }
    if ((paramSearchTerm instanceof MessageIDTerm)) {
      return messageid((MessageIDTerm)paramSearchTerm, paramString);
    }
    throw new SearchException("Search too complex");
  }
  
  private static Argument header(HeaderTerm paramHeaderTerm, String paramString)
    throws SearchException, IOException
  {
    Argument localArgument = new Argument();
    localArgument.writeAtom("HEADER");
    localArgument.writeString(paramHeaderTerm.getHeaderName());
    localArgument.writeString(paramHeaderTerm.getPattern(), paramString);
    return localArgument;
  }
  
  private static boolean isAscii(String paramString)
  {
    int j = paramString.length();
    int i = 0;
    for (;;)
    {
      if (i >= j) {
        return true;
      }
      if (paramString.charAt(i) > '') {
        return false;
      }
      i += 1;
    }
  }
  
  static boolean isAscii(SearchTerm paramSearchTerm)
  {
    int i;
    if (((paramSearchTerm instanceof AndTerm)) || ((paramSearchTerm instanceof OrTerm))) {
      if ((paramSearchTerm instanceof AndTerm))
      {
        paramSearchTerm = ((AndTerm)paramSearchTerm).getTerms();
        i = 0;
        label31:
        if (i < paramSearchTerm.length) {
          break label50;
        }
      }
    }
    label50:
    do
    {
      return true;
      paramSearchTerm = ((OrTerm)paramSearchTerm).getTerms();
      break;
      if (!isAscii(paramSearchTerm[i])) {
        return false;
      }
      i += 1;
      break label31;
      if ((paramSearchTerm instanceof NotTerm)) {
        return isAscii(((NotTerm)paramSearchTerm).getTerm());
      }
      if ((paramSearchTerm instanceof StringTerm)) {
        return isAscii(((StringTerm)paramSearchTerm).getPattern());
      }
    } while (!(paramSearchTerm instanceof AddressTerm));
    return isAscii(((AddressTerm)paramSearchTerm).getAddress().toString());
  }
  
  private static Argument messageid(MessageIDTerm paramMessageIDTerm, String paramString)
    throws SearchException, IOException
  {
    Argument localArgument = new Argument();
    localArgument.writeAtom("HEADER");
    localArgument.writeString("Message-ID");
    localArgument.writeString(paramMessageIDTerm.getPattern(), paramString);
    return localArgument;
  }
  
  private static Argument not(NotTerm paramNotTerm, String paramString)
    throws SearchException, IOException
  {
    Argument localArgument = new Argument();
    localArgument.writeAtom("NOT");
    paramNotTerm = paramNotTerm.getTerm();
    if (((paramNotTerm instanceof AndTerm)) || ((paramNotTerm instanceof FlagTerm)))
    {
      localArgument.writeArgument(generateSequence(paramNotTerm, paramString));
      return localArgument;
    }
    localArgument.append(generateSequence(paramNotTerm, paramString));
    return localArgument;
  }
  
  private static Argument or(OrTerm paramOrTerm, String paramString)
    throws SearchException, IOException
  {
    Object localObject = paramOrTerm.getTerms();
    paramOrTerm = (OrTerm)localObject;
    int i;
    if (localObject.length > 2)
    {
      paramOrTerm = localObject[0];
      i = 1;
      if (i >= localObject.length) {
        paramOrTerm = ((OrTerm)paramOrTerm).getTerms();
      }
    }
    else
    {
      localObject = new Argument();
      if (paramOrTerm.length > 1) {
        ((Argument)localObject).writeAtom("OR");
      }
      if ((!(paramOrTerm[0] instanceof AndTerm)) && (!(paramOrTerm[0] instanceof FlagTerm))) {
        break label139;
      }
      ((Argument)localObject).writeArgument(generateSequence(paramOrTerm[0], paramString));
    }
    for (;;)
    {
      if (paramOrTerm.length > 1)
      {
        if ((!(paramOrTerm[1] instanceof AndTerm)) && (!(paramOrTerm[1] instanceof FlagTerm))) {
          break label153;
        }
        ((Argument)localObject).writeArgument(generateSequence(paramOrTerm[1], paramString));
      }
      return (Argument)localObject;
      paramOrTerm = new OrTerm(paramOrTerm, localObject[i]);
      i += 1;
      break;
      label139:
      ((Argument)localObject).append(generateSequence(paramOrTerm[0], paramString));
    }
    label153:
    ((Argument)localObject).append(generateSequence(paramOrTerm[1], paramString));
    return (Argument)localObject;
  }
  
  private static Argument receiveddate(DateTerm paramDateTerm)
    throws SearchException
  {
    Argument localArgument = new Argument();
    String str = toIMAPDate(paramDateTerm.getDate());
    switch (paramDateTerm.getComparison())
    {
    default: 
      throw new SearchException("Cannot handle Date Comparison");
    case 5: 
      localArgument.writeAtom("SINCE " + str);
      return localArgument;
    case 3: 
      localArgument.writeAtom("ON " + str);
      return localArgument;
    case 2: 
      localArgument.writeAtom("BEFORE " + str);
      return localArgument;
    case 6: 
      localArgument.writeAtom("OR SINCE " + str + " ON " + str);
      return localArgument;
    case 1: 
      localArgument.writeAtom("OR BEFORE " + str + " ON " + str);
      return localArgument;
    }
    localArgument.writeAtom("NOT ON " + str);
    return localArgument;
  }
  
  private static Argument recipient(Message.RecipientType paramRecipientType, String paramString1, String paramString2)
    throws SearchException, IOException
  {
    Argument localArgument = new Argument();
    if (paramRecipientType == Message.RecipientType.TO) {
      localArgument.writeAtom("TO");
    }
    for (;;)
    {
      localArgument.writeString(paramString1, paramString2);
      return localArgument;
      if (paramRecipientType == Message.RecipientType.CC)
      {
        localArgument.writeAtom("CC");
      }
      else
      {
        if (paramRecipientType != Message.RecipientType.BCC) {
          break;
        }
        localArgument.writeAtom("BCC");
      }
    }
    throw new SearchException("Illegal Recipient type");
  }
  
  private static Argument sentdate(DateTerm paramDateTerm)
    throws SearchException
  {
    Argument localArgument = new Argument();
    String str = toIMAPDate(paramDateTerm.getDate());
    switch (paramDateTerm.getComparison())
    {
    default: 
      throw new SearchException("Cannot handle Date Comparison");
    case 5: 
      localArgument.writeAtom("SENTSINCE " + str);
      return localArgument;
    case 3: 
      localArgument.writeAtom("SENTON " + str);
      return localArgument;
    case 2: 
      localArgument.writeAtom("SENTBEFORE " + str);
      return localArgument;
    case 6: 
      localArgument.writeAtom("OR SENTSINCE " + str + " SENTON " + str);
      return localArgument;
    case 1: 
      localArgument.writeAtom("OR SENTBEFORE " + str + " SENTON " + str);
      return localArgument;
    }
    localArgument.writeAtom("NOT SENTON " + str);
    return localArgument;
  }
  
  private static Argument size(SizeTerm paramSizeTerm)
    throws SearchException
  {
    Argument localArgument = new Argument();
    switch (paramSizeTerm.getComparison())
    {
    case 3: 
    case 4: 
    default: 
      throw new SearchException("Cannot handle Comparison");
    case 5: 
      localArgument.writeAtom("LARGER");
    }
    for (;;)
    {
      localArgument.writeNumber(paramSizeTerm.getNumber());
      return localArgument;
      localArgument.writeAtom("SMALLER");
    }
  }
  
  private static Argument subject(SubjectTerm paramSubjectTerm, String paramString)
    throws SearchException, IOException
  {
    Argument localArgument = new Argument();
    localArgument.writeAtom("SUBJECT");
    localArgument.writeString(paramSubjectTerm.getPattern(), paramString);
    return localArgument;
  }
  
  private static String toIMAPDate(Date paramDate)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    cal.setTime(paramDate);
    localStringBuffer.append(cal.get(5)).append("-");
    localStringBuffer.append(monthTable[cal.get(2)]).append('-');
    localStringBuffer.append(cal.get(1));
    return localStringBuffer.toString();
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/protocol/SearchSequence.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */