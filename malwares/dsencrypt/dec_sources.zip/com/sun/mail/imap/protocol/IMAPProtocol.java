package com.sun.mail.imap.protocol;

import com.sun.mail.iap.Argument;
import com.sun.mail.iap.BadCommandException;
import com.sun.mail.iap.ByteArray;
import com.sun.mail.iap.CommandFailedException;
import com.sun.mail.iap.ConnectionException;
import com.sun.mail.iap.Literal;
import com.sun.mail.iap.LiteralException;
import com.sun.mail.iap.ParsingException;
import com.sun.mail.iap.Protocol;
import com.sun.mail.iap.ProtocolException;
import com.sun.mail.iap.Response;
import com.sun.mail.imap.ACL;
import com.sun.mail.imap.AppendUID;
import com.sun.mail.imap.Rights;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Vector;
import javax.mail.Flags;
import javax.mail.Flags.Flag;
import javax.mail.Quota;
import javax.mail.Quota.Resource;
import javax.mail.internet.MimeUtility;
import javax.mail.search.SearchException;
import javax.mail.search.SearchTerm;

public class IMAPProtocol
  extends Protocol
{
  private static final byte[] CRLF = { 13, 10 };
  private static final byte[] DONE = { 68, 79, 78, 69, 13, 10 };
  private boolean authenticated;
  private List authmechs = null;
  private ByteArray ba;
  private Map capabilities = null;
  private boolean connected = false;
  private String idleTag;
  private String name;
  private boolean rev1 = false;
  private SaslAuthenticator saslAuthenticator;
  private String[] searchCharsets;
  
  public IMAPProtocol(String paramString1, String paramString2, int paramInt, boolean paramBoolean1, PrintStream paramPrintStream, Properties paramProperties, boolean paramBoolean2)
    throws IOException, ProtocolException
  {
    super(paramString2, paramInt, paramBoolean1, paramPrintStream, paramProperties, "mail." + paramString1, paramBoolean2);
    try
    {
      this.name = paramString1;
      if (this.capabilities == null) {
        capability();
      }
      if (hasCapability("IMAP4rev1")) {
        this.rev1 = true;
      }
      this.searchCharsets = new String[2];
      this.searchCharsets[0] = "UTF-8";
      this.searchCharsets[1] = MimeUtility.mimeCharset(MimeUtility.getDefaultJavaCharset());
      this.connected = true;
      return;
    }
    finally
    {
      if (!this.connected) {
        disconnect();
      }
    }
  }
  
  private void copy(String paramString1, String paramString2)
    throws ProtocolException
  {
    paramString2 = BASE64MailboxEncoder.encode(paramString2);
    Argument localArgument = new Argument();
    localArgument.writeAtom(paramString1);
    localArgument.writeString(paramString2);
    simpleCommand("COPY", localArgument);
  }
  
  private String createFlagList(Flags paramFlags)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("(");
    Flags.Flag[] arrayOfFlag = paramFlags.getSystemFlags();
    int i = 1;
    int j = 0;
    if (j >= arrayOfFlag.length)
    {
      paramFlags = paramFlags.getUserFlags();
      j = 0;
      if (j >= paramFlags.length)
      {
        localStringBuffer.append(")");
        return localStringBuffer.toString();
      }
    }
    else
    {
      Object localObject = arrayOfFlag[j];
      if (localObject == Flags.Flag.ANSWERED)
      {
        localObject = "\\Answered";
        label79:
        if (i == 0) {
          break label184;
        }
        i = 0;
      }
      for (;;)
      {
        localStringBuffer.append((String)localObject);
        int k = i;
        do
        {
          j += 1;
          i = k;
          break;
          if (localObject == Flags.Flag.DELETED)
          {
            localObject = "\\Deleted";
            break label79;
          }
          if (localObject == Flags.Flag.DRAFT)
          {
            localObject = "\\Draft";
            break label79;
          }
          if (localObject == Flags.Flag.FLAGGED)
          {
            localObject = "\\Flagged";
            break label79;
          }
          if (localObject == Flags.Flag.RECENT)
          {
            localObject = "\\Recent";
            break label79;
          }
          k = i;
        } while (localObject != Flags.Flag.SEEN);
        localObject = "\\Seen";
        break label79;
        label184:
        localStringBuffer.append(' ');
      }
    }
    if (i != 0) {
      i = 0;
    }
    for (;;)
    {
      localStringBuffer.append(paramFlags[j]);
      j += 1;
      break;
      localStringBuffer.append(' ');
    }
  }
  
  private ListInfo[] doList(String paramString1, String paramString2, String paramString3)
    throws ProtocolException
  {
    paramString2 = BASE64MailboxEncoder.encode(paramString2);
    paramString3 = BASE64MailboxEncoder.encode(paramString3);
    Object localObject = new Argument();
    ((Argument)localObject).writeString(paramString2);
    ((Argument)localObject).writeString(paramString3);
    localObject = command(paramString1, (Argument)localObject);
    paramString3 = (ListInfo[])null;
    Response localResponse = localObject[(localObject.length - 1)];
    paramString2 = paramString3;
    Vector localVector;
    int i;
    if (localResponse.isOK())
    {
      localVector = new Vector(1);
      i = 0;
      int j = localObject.length;
      if (i < j) {
        break label129;
      }
      paramString2 = paramString3;
      if (localVector.size() > 0)
      {
        paramString2 = new ListInfo[localVector.size()];
        localVector.copyInto(paramString2);
      }
    }
    notifyResponseHandlers((Response[])localObject);
    handleResult(localResponse);
    return paramString2;
    label129:
    if (!(localObject[i] instanceof IMAPResponse)) {}
    for (;;)
    {
      i += 1;
      break;
      paramString2 = (IMAPResponse)localObject[i];
      if (paramString2.keyEquals(paramString1))
      {
        localVector.addElement(new ListInfo(paramString2));
        localObject[i] = null;
      }
    }
  }
  
  private Response[] fetch(String paramString1, String paramString2, boolean paramBoolean)
    throws ProtocolException
  {
    if (paramBoolean) {
      return command("UID FETCH " + paramString1 + " (" + paramString2 + ")", null);
    }
    return command("FETCH " + paramString1 + " (" + paramString2 + ")", null);
  }
  
  private AppendUID getAppendUID(Response paramResponse)
  {
    if (!paramResponse.isOK()) {}
    int i;
    do
    {
      return null;
      do
      {
        i = paramResponse.readByte();
      } while ((i > 0) && (i != 91));
    } while ((i == 0) || (!paramResponse.readAtom().equalsIgnoreCase("APPENDUID")));
    return new AppendUID(paramResponse.readLong(), paramResponse.readLong());
  }
  
  private int[] issueSearch(String paramString1, SearchTerm paramSearchTerm, String paramString2)
    throws ProtocolException, SearchException, IOException
  {
    Object localObject;
    label32:
    int i;
    int j;
    if (paramString2 == null)
    {
      localObject = null;
      paramSearchTerm = SearchSequence.generateSequence(paramSearchTerm, (String)localObject);
      paramSearchTerm.writeAtom(paramString1);
      if (paramString2 != null) {
        break label117;
      }
      paramString1 = command("SEARCH", paramSearchTerm);
      paramString2 = paramString1[(paramString1.length - 1)];
      paramSearchTerm = (int[])null;
      if (paramString2.isOK())
      {
        localObject = new Vector();
        i = 0;
        j = paramString1.length;
        if (i < j) {
          break label143;
        }
        j = ((Vector)localObject).size();
        paramSearchTerm = new int[j];
        i = 0;
      }
    }
    for (;;)
    {
      if (i >= j)
      {
        notifyResponseHandlers(paramString1);
        handleResult(paramString2);
        return paramSearchTerm;
        localObject = MimeUtility.javaCharset(paramString2);
        break;
        label117:
        paramString1 = command("SEARCH CHARSET " + paramString2, paramSearchTerm);
        break label32;
        label143:
        if (!(paramString1[i] instanceof IMAPResponse)) {}
        do
        {
          i += 1;
          break;
          paramSearchTerm = (IMAPResponse)paramString1[i];
        } while (!paramSearchTerm.keyEquals("SEARCH"));
        for (;;)
        {
          int k = paramSearchTerm.readNumber();
          if (k == -1)
          {
            paramString1[i] = null;
            break;
          }
          ((Vector)localObject).addElement(new Integer(k));
        }
      }
      paramSearchTerm[i] = ((Integer)((Vector)localObject).elementAt(i)).intValue();
      i += 1;
    }
  }
  
  private Quota parseQuota(Response paramResponse)
    throws ParsingException
  {
    Quota localQuota = new Quota(paramResponse.readAtomString());
    paramResponse.skipSpaces();
    if (paramResponse.readByte() != 40) {
      throw new ParsingException("parse error in QUOTA");
    }
    Vector localVector = new Vector();
    for (;;)
    {
      if (paramResponse.peekByte() == 41)
      {
        paramResponse.readByte();
        localQuota.resources = new Quota.Resource[localVector.size()];
        localVector.copyInto(localQuota.resources);
        return localQuota;
      }
      String str = paramResponse.readAtom();
      if (str != null) {
        localVector.addElement(new Quota.Resource(str, paramResponse.readLong(), paramResponse.readLong()));
      }
    }
  }
  
  private int[] search(String paramString, SearchTerm paramSearchTerm)
    throws ProtocolException, SearchException
  {
    if (SearchSequence.isAscii(paramSearchTerm)) {
      try
      {
        int[] arrayOfInt1 = issueSearch(paramString, paramSearchTerm, null);
        return arrayOfInt1;
      }
      catch (IOException localIOException1) {}
    }
    int i = 0;
    if (i >= this.searchCharsets.length) {
      throw new SearchException("Search failed");
    }
    if (this.searchCharsets[i] == null) {}
    for (;;)
    {
      i += 1;
      break;
      try
      {
        int[] arrayOfInt2 = issueSearch(paramString, paramSearchTerm, this.searchCharsets[i]);
        return arrayOfInt2;
      }
      catch (CommandFailedException localCommandFailedException)
      {
        this.searchCharsets[i] = null;
      }
      catch (IOException localIOException2) {}catch (ProtocolException paramString)
      {
        throw paramString;
      }
      catch (SearchException paramString)
      {
        throw paramString;
      }
    }
  }
  
  private void storeFlags(String paramString, Flags paramFlags, boolean paramBoolean)
    throws ProtocolException
  {
    if (paramBoolean) {}
    for (paramString = command("STORE " + paramString + " +FLAGS " + createFlagList(paramFlags), null);; paramString = command("STORE " + paramString + " -FLAGS " + createFlagList(paramFlags), null))
    {
      notifyResponseHandlers(paramString);
      handleResult(paramString[(paramString.length - 1)]);
      return;
    }
  }
  
  public void append(String paramString, Flags paramFlags, Date paramDate, Literal paramLiteral)
    throws ProtocolException
  {
    appenduid(paramString, paramFlags, paramDate, paramLiteral, false);
  }
  
  public AppendUID appenduid(String paramString, Flags paramFlags, Date paramDate, Literal paramLiteral)
    throws ProtocolException
  {
    return appenduid(paramString, paramFlags, paramDate, paramLiteral, true);
  }
  
  public AppendUID appenduid(String paramString, Flags paramFlags, Date paramDate, Literal paramLiteral, boolean paramBoolean)
    throws ProtocolException
  {
    paramString = BASE64MailboxEncoder.encode(paramString);
    Argument localArgument = new Argument();
    localArgument.writeString(paramString);
    if (paramFlags != null)
    {
      paramString = paramFlags;
      if (paramFlags.contains(Flags.Flag.RECENT))
      {
        paramString = new Flags(paramFlags);
        paramString.remove(Flags.Flag.RECENT);
      }
      localArgument.writeAtom(createFlagList(paramString));
    }
    if (paramDate != null) {
      localArgument.writeString(INTERNALDATE.format(paramDate));
    }
    localArgument.writeBytes(paramLiteral);
    paramString = command("APPEND", localArgument);
    notifyResponseHandlers(paramString);
    handleResult(paramString[(paramString.length - 1)]);
    if (paramBoolean) {
      return getAppendUID(paramString[(paramString.length - 1)]);
    }
    return null;
  }
  
  /* Error */
  public void authlogin(String paramString1, String paramString2)
    throws ProtocolException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new 197	java/util/Vector
    //   5: dup
    //   6: invokespecial 276	java/util/Vector:<init>	()V
    //   9: astore 9
    //   11: aconst_null
    //   12: astore 7
    //   14: aconst_null
    //   15: astore 6
    //   17: iconst_0
    //   18: istore_3
    //   19: aload_0
    //   20: ldc_w 381
    //   23: aconst_null
    //   24: invokevirtual 385	com/sun/mail/imap/protocol/IMAPProtocol:writeCommand	(Ljava/lang/String;Lcom/sun/mail/iap/Argument;)Ljava/lang/String;
    //   27: astore 8
    //   29: aload 8
    //   31: astore 7
    //   33: aload_0
    //   34: invokevirtual 389	com/sun/mail/imap/protocol/IMAPProtocol:getOutputStream	()Ljava/io/OutputStream;
    //   37: astore 10
    //   39: new 391	java/io/ByteArrayOutputStream
    //   42: dup
    //   43: invokespecial 392	java/io/ByteArrayOutputStream:<init>	()V
    //   46: astore 11
    //   48: new 394	com/sun/mail/util/BASE64EncoderStream
    //   51: dup
    //   52: aload 11
    //   54: ldc_w 395
    //   57: invokespecial 398	com/sun/mail/util/BASE64EncoderStream:<init>	(Ljava/io/OutputStream;I)V
    //   60: astore 12
    //   62: iconst_1
    //   63: istore 4
    //   65: iload_3
    //   66: ifeq +57 -> 123
    //   69: aload 9
    //   71: invokevirtual 204	java/util/Vector:size	()I
    //   74: anewarray 191	com/sun/mail/iap/Response
    //   77: astore_1
    //   78: aload 9
    //   80: aload_1
    //   81: invokevirtual 210	java/util/Vector:copyInto	([Ljava/lang/Object;)V
    //   84: aload_0
    //   85: aload_1
    //   86: invokevirtual 214	com/sun/mail/imap/protocol/IMAPProtocol:notifyResponseHandlers	([Lcom/sun/mail/iap/Response;)V
    //   89: aload_0
    //   90: aload 6
    //   92: invokevirtual 218	com/sun/mail/imap/protocol/IMAPProtocol:handleResult	(Lcom/sun/mail/iap/Response;)V
    //   95: aload_0
    //   96: aload 6
    //   98: invokevirtual 401	com/sun/mail/imap/protocol/IMAPProtocol:setCapabilities	(Lcom/sun/mail/iap/Response;)V
    //   101: aload_0
    //   102: iconst_1
    //   103: putfield 403	com/sun/mail/imap/protocol/IMAPProtocol:authenticated	Z
    //   106: aload_0
    //   107: monitorexit
    //   108: return
    //   109: astore 6
    //   111: aload 6
    //   113: invokestatic 407	com/sun/mail/iap/Response:byeResponse	(Ljava/lang/Exception;)Lcom/sun/mail/iap/Response;
    //   116: astore 6
    //   118: iconst_1
    //   119: istore_3
    //   120: goto -87 -> 33
    //   123: iload 4
    //   125: istore 5
    //   127: aload_0
    //   128: invokevirtual 411	com/sun/mail/imap/protocol/IMAPProtocol:readResponse	()Lcom/sun/mail/iap/Response;
    //   131: astore 8
    //   133: iload 4
    //   135: istore 5
    //   137: aload 8
    //   139: invokevirtual 414	com/sun/mail/iap/Response:isContinuation	()Z
    //   142: ifeq +112 -> 254
    //   145: iload 4
    //   147: ifeq +101 -> 248
    //   150: aload_1
    //   151: astore 6
    //   153: iconst_0
    //   154: istore 4
    //   156: iload 4
    //   158: istore 5
    //   160: aload 12
    //   162: aload 6
    //   164: invokestatic 420	com/sun/mail/util/ASCIIUtility:getBytes	(Ljava/lang/String;)[B
    //   167: invokevirtual 426	java/io/OutputStream:write	([B)V
    //   170: iload 4
    //   172: istore 5
    //   174: aload 12
    //   176: invokevirtual 429	java/io/OutputStream:flush	()V
    //   179: iload 4
    //   181: istore 5
    //   183: aload 11
    //   185: getstatic 30	com/sun/mail/imap/protocol/IMAPProtocol:CRLF	[B
    //   188: invokevirtual 430	java/io/ByteArrayOutputStream:write	([B)V
    //   191: iload 4
    //   193: istore 5
    //   195: aload 10
    //   197: aload 11
    //   199: invokevirtual 434	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   202: invokevirtual 426	java/io/OutputStream:write	([B)V
    //   205: iload 4
    //   207: istore 5
    //   209: aload 10
    //   211: invokevirtual 429	java/io/OutputStream:flush	()V
    //   214: iload 4
    //   216: istore 5
    //   218: aload 11
    //   220: invokevirtual 437	java/io/ByteArrayOutputStream:reset	()V
    //   223: aload 8
    //   225: astore 6
    //   227: goto -162 -> 65
    //   230: astore 6
    //   232: aload 6
    //   234: invokestatic 407	com/sun/mail/iap/Response:byeResponse	(Ljava/lang/Exception;)Lcom/sun/mail/iap/Response;
    //   237: astore 6
    //   239: iconst_1
    //   240: istore_3
    //   241: iload 5
    //   243: istore 4
    //   245: goto -180 -> 65
    //   248: aload_2
    //   249: astore 6
    //   251: goto -95 -> 156
    //   254: iload 4
    //   256: istore 5
    //   258: aload 8
    //   260: invokevirtual 440	com/sun/mail/iap/Response:isTagged	()Z
    //   263: ifeq +29 -> 292
    //   266: iload 4
    //   268: istore 5
    //   270: aload 8
    //   272: invokevirtual 443	com/sun/mail/iap/Response:getTag	()Ljava/lang/String;
    //   275: aload 7
    //   277: invokevirtual 447	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   280: ifeq +12 -> 292
    //   283: iconst_1
    //   284: istore_3
    //   285: aload 8
    //   287: astore 6
    //   289: goto -224 -> 65
    //   292: iload 4
    //   294: istore 5
    //   296: aload 8
    //   298: invokevirtual 450	com/sun/mail/iap/Response:isBYE	()Z
    //   301: ifeq +12 -> 313
    //   304: iconst_1
    //   305: istore_3
    //   306: aload 8
    //   308: astore 6
    //   310: goto -245 -> 65
    //   313: iload 4
    //   315: istore 5
    //   317: aload 9
    //   319: aload 8
    //   321: invokevirtual 230	java/util/Vector:addElement	(Ljava/lang/Object;)V
    //   324: aload 8
    //   326: astore 6
    //   328: goto -263 -> 65
    //   331: astore_1
    //   332: aload_0
    //   333: monitorexit
    //   334: aload_1
    //   335: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	336	0	this	IMAPProtocol
    //   0	336	1	paramString1	String
    //   0	336	2	paramString2	String
    //   18	288	3	i	int
    //   63	251	4	j	int
    //   125	191	5	k	int
    //   15	82	6	localResponse	Response
    //   109	3	6	localException1	Exception
    //   116	110	6	localObject1	Object
    //   230	3	6	localException2	Exception
    //   237	90	6	localObject2	Object
    //   12	264	7	localObject3	Object
    //   27	298	8	localObject4	Object
    //   9	309	9	localVector	Vector
    //   37	173	10	localOutputStream	OutputStream
    //   46	173	11	localByteArrayOutputStream	java.io.ByteArrayOutputStream
    //   60	115	12	localBASE64EncoderStream	com.sun.mail.util.BASE64EncoderStream
    // Exception table:
    //   from	to	target	type
    //   19	29	109	java/lang/Exception
    //   127	133	230	java/lang/Exception
    //   137	145	230	java/lang/Exception
    //   160	170	230	java/lang/Exception
    //   174	179	230	java/lang/Exception
    //   183	191	230	java/lang/Exception
    //   195	205	230	java/lang/Exception
    //   209	214	230	java/lang/Exception
    //   218	223	230	java/lang/Exception
    //   258	266	230	java/lang/Exception
    //   270	283	230	java/lang/Exception
    //   296	304	230	java/lang/Exception
    //   317	324	230	java/lang/Exception
    //   2	11	331	finally
    //   19	29	331	finally
    //   33	62	331	finally
    //   69	106	331	finally
    //   111	118	331	finally
    //   127	133	331	finally
    //   137	145	331	finally
    //   160	170	331	finally
    //   174	179	331	finally
    //   183	191	331	finally
    //   195	205	331	finally
    //   209	214	331	finally
    //   218	223	331	finally
    //   232	239	331	finally
    //   258	266	331	finally
    //   270	283	331	finally
    //   296	304	331	finally
    //   317	324	331	finally
  }
  
  /* Error */
  public void authplain(String paramString1, String paramString2, String paramString3)
    throws ProtocolException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new 197	java/util/Vector
    //   5: dup
    //   6: invokespecial 276	java/util/Vector:<init>	()V
    //   9: astore 8
    //   11: aconst_null
    //   12: astore 6
    //   14: aconst_null
    //   15: astore 5
    //   17: iconst_0
    //   18: istore 4
    //   20: aload_0
    //   21: ldc_w 454
    //   24: aconst_null
    //   25: invokevirtual 385	com/sun/mail/imap/protocol/IMAPProtocol:writeCommand	(Ljava/lang/String;Lcom/sun/mail/iap/Argument;)Ljava/lang/String;
    //   28: astore 7
    //   30: aload 7
    //   32: astore 6
    //   34: aload_0
    //   35: invokevirtual 389	com/sun/mail/imap/protocol/IMAPProtocol:getOutputStream	()Ljava/io/OutputStream;
    //   38: astore 7
    //   40: new 391	java/io/ByteArrayOutputStream
    //   43: dup
    //   44: invokespecial 392	java/io/ByteArrayOutputStream:<init>	()V
    //   47: astore 9
    //   49: new 394	com/sun/mail/util/BASE64EncoderStream
    //   52: dup
    //   53: aload 9
    //   55: ldc_w 395
    //   58: invokespecial 398	com/sun/mail/util/BASE64EncoderStream:<init>	(Ljava/io/OutputStream;I)V
    //   61: astore 10
    //   63: iload 4
    //   65: ifeq +58 -> 123
    //   68: aload 8
    //   70: invokevirtual 204	java/util/Vector:size	()I
    //   73: anewarray 191	com/sun/mail/iap/Response
    //   76: astore_1
    //   77: aload 8
    //   79: aload_1
    //   80: invokevirtual 210	java/util/Vector:copyInto	([Ljava/lang/Object;)V
    //   83: aload_0
    //   84: aload_1
    //   85: invokevirtual 214	com/sun/mail/imap/protocol/IMAPProtocol:notifyResponseHandlers	([Lcom/sun/mail/iap/Response;)V
    //   88: aload_0
    //   89: aload 5
    //   91: invokevirtual 218	com/sun/mail/imap/protocol/IMAPProtocol:handleResult	(Lcom/sun/mail/iap/Response;)V
    //   94: aload_0
    //   95: aload 5
    //   97: invokevirtual 401	com/sun/mail/imap/protocol/IMAPProtocol:setCapabilities	(Lcom/sun/mail/iap/Response;)V
    //   100: aload_0
    //   101: iconst_1
    //   102: putfield 403	com/sun/mail/imap/protocol/IMAPProtocol:authenticated	Z
    //   105: aload_0
    //   106: monitorexit
    //   107: return
    //   108: astore 5
    //   110: aload 5
    //   112: invokestatic 407	com/sun/mail/iap/Response:byeResponse	(Ljava/lang/Exception;)Lcom/sun/mail/iap/Response;
    //   115: astore 5
    //   117: iconst_1
    //   118: istore 4
    //   120: goto -86 -> 34
    //   123: aload_0
    //   124: invokevirtual 411	com/sun/mail/imap/protocol/IMAPProtocol:readResponse	()Lcom/sun/mail/iap/Response;
    //   127: astore 5
    //   129: aload 5
    //   131: invokevirtual 414	com/sun/mail/iap/Response:isContinuation	()Z
    //   134: ifeq +96 -> 230
    //   137: aload 10
    //   139: new 45	java/lang/StringBuilder
    //   142: dup
    //   143: aload_1
    //   144: invokestatic 458	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   147: invokespecial 50	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   150: ldc_w 460
    //   153: invokevirtual 54	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   156: aload_2
    //   157: invokevirtual 54	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   160: ldc_w 460
    //   163: invokevirtual 54	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   166: aload_3
    //   167: invokevirtual 54	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   170: invokevirtual 58	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   173: invokestatic 420	com/sun/mail/util/ASCIIUtility:getBytes	(Ljava/lang/String;)[B
    //   176: invokevirtual 426	java/io/OutputStream:write	([B)V
    //   179: aload 10
    //   181: invokevirtual 429	java/io/OutputStream:flush	()V
    //   184: aload 9
    //   186: getstatic 30	com/sun/mail/imap/protocol/IMAPProtocol:CRLF	[B
    //   189: invokevirtual 430	java/io/ByteArrayOutputStream:write	([B)V
    //   192: aload 7
    //   194: aload 9
    //   196: invokevirtual 434	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   199: invokevirtual 426	java/io/OutputStream:write	([B)V
    //   202: aload 7
    //   204: invokevirtual 429	java/io/OutputStream:flush	()V
    //   207: aload 9
    //   209: invokevirtual 437	java/io/ByteArrayOutputStream:reset	()V
    //   212: goto -149 -> 63
    //   215: astore 5
    //   217: aload 5
    //   219: invokestatic 407	com/sun/mail/iap/Response:byeResponse	(Ljava/lang/Exception;)Lcom/sun/mail/iap/Response;
    //   222: astore 5
    //   224: iconst_1
    //   225: istore 4
    //   227: goto -164 -> 63
    //   230: aload 5
    //   232: invokevirtual 440	com/sun/mail/iap/Response:isTagged	()Z
    //   235: ifeq +22 -> 257
    //   238: aload 5
    //   240: invokevirtual 443	com/sun/mail/iap/Response:getTag	()Ljava/lang/String;
    //   243: aload 6
    //   245: invokevirtual 447	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   248: ifeq +9 -> 257
    //   251: iconst_1
    //   252: istore 4
    //   254: goto -191 -> 63
    //   257: aload 5
    //   259: invokevirtual 450	com/sun/mail/iap/Response:isBYE	()Z
    //   262: ifeq +9 -> 271
    //   265: iconst_1
    //   266: istore 4
    //   268: goto -205 -> 63
    //   271: aload 8
    //   273: aload 5
    //   275: invokevirtual 230	java/util/Vector:addElement	(Ljava/lang/Object;)V
    //   278: goto -215 -> 63
    //   281: astore_1
    //   282: aload_0
    //   283: monitorexit
    //   284: aload_1
    //   285: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	286	0	this	IMAPProtocol
    //   0	286	1	paramString1	String
    //   0	286	2	paramString2	String
    //   0	286	3	paramString3	String
    //   18	249	4	i	int
    //   15	81	5	localResponse1	Response
    //   108	3	5	localException1	Exception
    //   115	15	5	localResponse2	Response
    //   215	3	5	localException2	Exception
    //   222	52	5	localResponse3	Response
    //   12	232	6	localObject1	Object
    //   28	175	7	localObject2	Object
    //   9	263	8	localVector	Vector
    //   47	161	9	localByteArrayOutputStream	java.io.ByteArrayOutputStream
    //   61	119	10	localBASE64EncoderStream	com.sun.mail.util.BASE64EncoderStream
    // Exception table:
    //   from	to	target	type
    //   20	30	108	java/lang/Exception
    //   123	212	215	java/lang/Exception
    //   230	251	215	java/lang/Exception
    //   257	265	215	java/lang/Exception
    //   271	278	215	java/lang/Exception
    //   2	11	281	finally
    //   20	30	281	finally
    //   34	63	281	finally
    //   68	105	281	finally
    //   110	117	281	finally
    //   123	212	281	finally
    //   217	224	281	finally
    //   230	251	281	finally
    //   257	265	281	finally
    //   271	278	281	finally
  }
  
  public void capability()
    throws ProtocolException
  {
    Response[] arrayOfResponse = command("CAPABILITY", null);
    if (!arrayOfResponse[(arrayOfResponse.length - 1)].isOK()) {
      throw new ProtocolException(arrayOfResponse[(arrayOfResponse.length - 1)].toString());
    }
    this.capabilities = new HashMap(10);
    this.authmechs = new ArrayList(5);
    int i = 0;
    int j = arrayOfResponse.length;
    if (i >= j) {
      return;
    }
    if (!(arrayOfResponse[i] instanceof IMAPResponse)) {}
    for (;;)
    {
      i += 1;
      break;
      IMAPResponse localIMAPResponse = (IMAPResponse)arrayOfResponse[i];
      if (localIMAPResponse.keyEquals("CAPABILITY")) {
        parseCapabilities(localIMAPResponse);
      }
    }
  }
  
  public void check()
    throws ProtocolException
  {
    simpleCommand("CHECK", null);
  }
  
  public void close()
    throws ProtocolException
  {
    simpleCommand("CLOSE", null);
  }
  
  public void copy(int paramInt1, int paramInt2, String paramString)
    throws ProtocolException
  {
    copy(String.valueOf(paramInt1) + ":" + String.valueOf(paramInt2), paramString);
  }
  
  public void copy(MessageSet[] paramArrayOfMessageSet, String paramString)
    throws ProtocolException
  {
    copy(MessageSet.toString(paramArrayOfMessageSet), paramString);
  }
  
  public void create(String paramString)
    throws ProtocolException
  {
    paramString = BASE64MailboxEncoder.encode(paramString);
    Argument localArgument = new Argument();
    localArgument.writeString(paramString);
    simpleCommand("CREATE", localArgument);
  }
  
  public void delete(String paramString)
    throws ProtocolException
  {
    paramString = BASE64MailboxEncoder.encode(paramString);
    Argument localArgument = new Argument();
    localArgument.writeString(paramString);
    simpleCommand("DELETE", localArgument);
  }
  
  public void deleteACL(String paramString1, String paramString2)
    throws ProtocolException
  {
    if (!hasCapability("ACL")) {
      throw new BadCommandException("ACL not supported");
    }
    paramString1 = BASE64MailboxEncoder.encode(paramString1);
    Argument localArgument = new Argument();
    localArgument.writeString(paramString1);
    localArgument.writeString(paramString2);
    paramString1 = command("DELETEACL", localArgument);
    paramString2 = paramString1[(paramString1.length - 1)];
    notifyResponseHandlers(paramString1);
    handleResult(paramString2);
  }
  
  public void disconnect()
  {
    super.disconnect();
    this.authenticated = false;
  }
  
  public MailboxInfo examine(String paramString)
    throws ProtocolException
  {
    paramString = BASE64MailboxEncoder.encode(paramString);
    Object localObject = new Argument();
    ((Argument)localObject).writeString(paramString);
    paramString = command("EXAMINE", (Argument)localObject);
    localObject = new MailboxInfo(paramString);
    ((MailboxInfo)localObject).mode = 1;
    notifyResponseHandlers(paramString);
    handleResult(paramString[(paramString.length - 1)]);
    return (MailboxInfo)localObject;
  }
  
  public void expunge()
    throws ProtocolException
  {
    simpleCommand("EXPUNGE", null);
  }
  
  public Response[] fetch(int paramInt1, int paramInt2, String paramString)
    throws ProtocolException
  {
    return fetch(String.valueOf(paramInt1) + ":" + String.valueOf(paramInt2), paramString, false);
  }
  
  public Response[] fetch(int paramInt, String paramString)
    throws ProtocolException
  {
    return fetch(String.valueOf(paramInt), paramString, false);
  }
  
  public Response[] fetch(MessageSet[] paramArrayOfMessageSet, String paramString)
    throws ProtocolException
  {
    return fetch(MessageSet.toString(paramArrayOfMessageSet), paramString, false);
  }
  
  public BODY fetchBody(int paramInt, String paramString)
    throws ProtocolException
  {
    return fetchBody(paramInt, paramString, false);
  }
  
  public BODY fetchBody(int paramInt1, String paramString, int paramInt2, int paramInt3)
    throws ProtocolException
  {
    return fetchBody(paramInt1, paramString, paramInt2, paramInt3, false, null);
  }
  
  public BODY fetchBody(int paramInt1, String paramString, int paramInt2, int paramInt3, ByteArray paramByteArray)
    throws ProtocolException
  {
    return fetchBody(paramInt1, paramString, paramInt2, paramInt3, false, paramByteArray);
  }
  
  protected BODY fetchBody(int paramInt1, String paramString, int paramInt2, int paramInt3, boolean paramBoolean, ByteArray paramByteArray)
    throws ProtocolException
  {
    this.ba = paramByteArray;
    if (paramBoolean)
    {
      paramByteArray = "BODY.PEEK[";
      paramByteArray = new StringBuilder(String.valueOf(paramByteArray));
      if (paramString != null) {
        break label121;
      }
    }
    label121:
    for (paramString = "]<";; paramString = paramString + "]<")
    {
      paramString = fetch(paramInt1, paramString + String.valueOf(paramInt2) + "." + String.valueOf(paramInt3) + ">");
      notifyResponseHandlers(paramString);
      paramByteArray = paramString[(paramString.length - 1)];
      if (!paramByteArray.isOK()) {
        break label145;
      }
      return (BODY)FetchResponse.getItem(paramString, paramInt1, BODY.class);
      paramByteArray = "BODY[";
      break;
    }
    label145:
    if (paramByteArray.isNO()) {
      return null;
    }
    handleResult(paramByteArray);
    return null;
  }
  
  protected BODY fetchBody(int paramInt, String paramString, boolean paramBoolean)
    throws ProtocolException
  {
    if (paramBoolean)
    {
      localStringBuilder = new StringBuilder("BODY.PEEK[");
      if (paramString == null) {}
      for (paramString = "]";; paramString = paramString + "]")
      {
        paramString = fetch(paramInt, paramString);
        notifyResponseHandlers(paramString);
        localStringBuilder = paramString[(paramString.length - 1)];
        if (!localStringBuilder.isOK()) {
          break;
        }
        return (BODY)FetchResponse.getItem(paramString, paramInt, BODY.class);
      }
    }
    StringBuilder localStringBuilder = new StringBuilder("BODY[");
    if (paramString == null) {}
    for (paramString = "]";; paramString = paramString + "]")
    {
      paramString = fetch(paramInt, paramString);
      break;
    }
    if (localStringBuilder.isNO()) {
      return null;
    }
    handleResult(localStringBuilder);
    return null;
  }
  
  public BODYSTRUCTURE fetchBodyStructure(int paramInt)
    throws ProtocolException
  {
    BODYSTRUCTURE localBODYSTRUCTURE = null;
    Response[] arrayOfResponse = fetch(paramInt, "BODYSTRUCTURE");
    notifyResponseHandlers(arrayOfResponse);
    Response localResponse = arrayOfResponse[(arrayOfResponse.length - 1)];
    if (localResponse.isOK()) {
      localBODYSTRUCTURE = (BODYSTRUCTURE)FetchResponse.getItem(arrayOfResponse, paramInt, BODYSTRUCTURE.class);
    }
    while (localResponse.isNO()) {
      return localBODYSTRUCTURE;
    }
    handleResult(localResponse);
    return null;
  }
  
  public Flags fetchFlags(int paramInt)
    throws ProtocolException
  {
    Object localObject1 = null;
    Response[] arrayOfResponse = fetch(paramInt, "FLAGS");
    int i = 0;
    int j = arrayOfResponse.length;
    if (i >= j) {}
    for (;;)
    {
      notifyResponseHandlers(arrayOfResponse);
      handleResult(arrayOfResponse[(arrayOfResponse.length - 1)]);
      return (Flags)localObject1;
      Object localObject2 = localObject1;
      if (arrayOfResponse[i] != null)
      {
        localObject2 = localObject1;
        if ((arrayOfResponse[i] instanceof FetchResponse))
        {
          if (((FetchResponse)arrayOfResponse[i]).getNumber() == paramInt) {
            break label99;
          }
          localObject2 = localObject1;
        }
      }
      label99:
      do
      {
        i += 1;
        localObject1 = localObject2;
        break;
        localObject1 = (Flags)((FetchResponse)arrayOfResponse[i]).getItem(Flags.class);
        localObject2 = localObject1;
      } while (localObject1 == null);
      arrayOfResponse[i] = null;
    }
  }
  
  public RFC822DATA fetchRFC822(int paramInt, String paramString)
    throws ProtocolException
  {
    if (paramString == null) {}
    Response localResponse;
    for (paramString = "RFC822";; paramString = "RFC822." + paramString)
    {
      paramString = fetch(paramInt, paramString);
      notifyResponseHandlers(paramString);
      localResponse = paramString[(paramString.length - 1)];
      if (!localResponse.isOK()) {
        break;
      }
      return (RFC822DATA)FetchResponse.getItem(paramString, paramInt, RFC822DATA.class);
    }
    if (localResponse.isNO()) {
      return null;
    }
    handleResult(localResponse);
    return null;
  }
  
  public UID fetchSequenceNumber(long paramLong)
    throws ProtocolException
  {
    Object localObject2 = null;
    Response[] arrayOfResponse = fetch(String.valueOf(paramLong), "UID", true);
    int i = 0;
    int j = arrayOfResponse.length;
    if (i >= j)
    {
      localObject1 = localObject2;
      label34:
      notifyResponseHandlers(arrayOfResponse);
      handleResult(arrayOfResponse[(arrayOfResponse.length - 1)]);
      return (UID)localObject1;
    }
    Object localObject1 = localObject2;
    if (arrayOfResponse[i] != null)
    {
      if ((arrayOfResponse[i] instanceof FetchResponse)) {
        break label91;
      }
      localObject1 = localObject2;
    }
    for (;;)
    {
      i += 1;
      localObject2 = localObject1;
      break;
      label91:
      localObject2 = (UID)((FetchResponse)arrayOfResponse[i]).getItem(UID.class);
      localObject1 = localObject2;
      if (localObject2 != null)
      {
        localObject1 = localObject2;
        if (((UID)localObject2).uid == paramLong) {
          break label34;
        }
        localObject1 = null;
      }
    }
  }
  
  public UID[] fetchSequenceNumbers(long paramLong1, long paramLong2)
    throws ProtocolException
  {
    Object localObject2 = new StringBuilder(String.valueOf(String.valueOf(paramLong1))).append(":");
    if (paramLong2 == -1L) {}
    int i;
    for (Object localObject1 = "*";; localObject1 = String.valueOf(paramLong2))
    {
      localObject2 = fetch((String)localObject1, "UID", true);
      localObject1 = new Vector();
      i = 0;
      int j = localObject2.length;
      if (i < j) {
        break;
      }
      notifyResponseHandlers((Response[])localObject2);
      handleResult(localObject2[(localObject2.length - 1)]);
      localObject2 = new UID[((Vector)localObject1).size()];
      ((Vector)localObject1).copyInto((Object[])localObject2);
      return (UID[])localObject2;
    }
    if ((localObject2[i] == null) || (!(localObject2[i] instanceof FetchResponse))) {}
    for (;;)
    {
      i += 1;
      break;
      UID localUID = (UID)((FetchResponse)localObject2[i]).getItem(UID.class);
      if (localUID != null) {
        ((Vector)localObject1).addElement(localUID);
      }
    }
  }
  
  public UID[] fetchSequenceNumbers(long[] paramArrayOfLong)
    throws ProtocolException
  {
    Object localObject = new StringBuffer();
    int i = 0;
    for (;;)
    {
      if (i >= paramArrayOfLong.length)
      {
        localObject = fetch(((StringBuffer)localObject).toString(), "UID", true);
        paramArrayOfLong = new Vector();
        i = 0;
        int j = localObject.length;
        if (i < j) {
          break;
        }
        notifyResponseHandlers((Response[])localObject);
        handleResult(localObject[(localObject.length - 1)]);
        localObject = new UID[paramArrayOfLong.size()];
        paramArrayOfLong.copyInto((Object[])localObject);
        return (UID[])localObject;
      }
      if (i > 0) {
        ((StringBuffer)localObject).append(",");
      }
      ((StringBuffer)localObject).append(String.valueOf(paramArrayOfLong[i]));
      i += 1;
    }
    if ((localObject[i] == null) || (!(localObject[i] instanceof FetchResponse))) {}
    for (;;)
    {
      i += 1;
      break;
      UID localUID = (UID)((FetchResponse)localObject[i]).getItem(UID.class);
      if (localUID != null) {
        paramArrayOfLong.addElement(localUID);
      }
    }
  }
  
  public UID fetchUID(int paramInt)
    throws ProtocolException
  {
    UID localUID = null;
    Response[] arrayOfResponse = fetch(paramInt, "UID");
    notifyResponseHandlers(arrayOfResponse);
    Response localResponse = arrayOfResponse[(arrayOfResponse.length - 1)];
    if (localResponse.isOK()) {
      localUID = (UID)FetchResponse.getItem(arrayOfResponse, paramInt, UID.class);
    }
    while (localResponse.isNO()) {
      return localUID;
    }
    handleResult(localResponse);
    return null;
  }
  
  public ACL[] getACL(String paramString)
    throws ProtocolException
  {
    if (!hasCapability("ACL")) {
      throw new BadCommandException("ACL not supported");
    }
    paramString = BASE64MailboxEncoder.encode(paramString);
    Object localObject = new Argument();
    ((Argument)localObject).writeString(paramString);
    localObject = command("GETACL", (Argument)localObject);
    Response localResponse = localObject[(localObject.length - 1)];
    paramString = new Vector();
    int i;
    if (localResponse.isOK())
    {
      i = 0;
      int j = localObject.length;
      if (i < j) {}
    }
    else
    {
      notifyResponseHandlers((Response[])localObject);
      handleResult(localResponse);
      localObject = new ACL[paramString.size()];
      paramString.copyInto((Object[])localObject);
      return (ACL[])localObject;
    }
    if (!(localObject[i] instanceof IMAPResponse)) {}
    IMAPResponse localIMAPResponse;
    do
    {
      i += 1;
      break;
      localIMAPResponse = (IMAPResponse)localObject[i];
    } while (!localIMAPResponse.keyEquals("ACL"));
    localIMAPResponse.readAtomString();
    for (;;)
    {
      String str1 = localIMAPResponse.readAtomString();
      if (str1 == null) {}
      String str2;
      do
      {
        localObject[i] = null;
        break;
        str2 = localIMAPResponse.readAtomString();
      } while (str2 == null);
      paramString.addElement(new ACL(str1, new Rights(str2)));
    }
  }
  
  public Map getCapabilities()
  {
    return this.capabilities;
  }
  
  OutputStream getIMAPOutputStream()
  {
    return getOutputStream();
  }
  
  public Quota[] getQuota(String paramString)
    throws ProtocolException
  {
    if (!hasCapability("QUOTA")) {
      throw new BadCommandException("QUOTA not supported");
    }
    Object localObject = new Argument();
    ((Argument)localObject).writeString(paramString);
    localObject = command("GETQUOTA", (Argument)localObject);
    paramString = new Vector();
    Response localResponse = localObject[(localObject.length - 1)];
    int i;
    if (localResponse.isOK())
    {
      i = 0;
      int j = localObject.length;
      if (i < j) {}
    }
    else
    {
      notifyResponseHandlers((Response[])localObject);
      handleResult(localResponse);
      localObject = new Quota[paramString.size()];
      paramString.copyInto((Object[])localObject);
      return (Quota[])localObject;
    }
    if (!(localObject[i] instanceof IMAPResponse)) {}
    for (;;)
    {
      i += 1;
      break;
      IMAPResponse localIMAPResponse = (IMAPResponse)localObject[i];
      if (localIMAPResponse.keyEquals("QUOTA"))
      {
        paramString.addElement(parseQuota(localIMAPResponse));
        localObject[i] = null;
      }
    }
  }
  
  public Quota[] getQuotaRoot(String paramString)
    throws ProtocolException
  {
    if (!hasCapability("QUOTA")) {
      throw new BadCommandException("GETQUOTAROOT not supported");
    }
    paramString = BASE64MailboxEncoder.encode(paramString);
    Object localObject1 = new Argument();
    ((Argument)localObject1).writeString(paramString);
    localObject1 = command("GETQUOTAROOT", (Argument)localObject1);
    Response localResponse = localObject1[(localObject1.length - 1)];
    paramString = new Hashtable();
    int i;
    if (localResponse.isOK())
    {
      i = 0;
      int j = localObject1.length;
      if (i < j) {}
    }
    else
    {
      notifyResponseHandlers((Response[])localObject1);
      handleResult(localResponse);
      localObject1 = new Quota[paramString.size()];
      paramString = paramString.elements();
      i = 0;
    }
    for (;;)
    {
      if (!paramString.hasMoreElements())
      {
        return (Quota[])localObject1;
        if (!(localObject1[i] instanceof IMAPResponse)) {}
        for (;;)
        {
          i += 1;
          break;
          Object localObject2 = (IMAPResponse)localObject1[i];
          Object localObject3;
          if (((IMAPResponse)localObject2).keyEquals("QUOTAROOT"))
          {
            ((IMAPResponse)localObject2).readAtomString();
            for (;;)
            {
              localObject3 = ((IMAPResponse)localObject2).readAtomString();
              if (localObject3 == null)
              {
                localObject1[i] = null;
                break;
              }
              paramString.put(localObject3, new Quota((String)localObject3));
            }
          }
          if (((IMAPResponse)localObject2).keyEquals("QUOTA"))
          {
            localObject2 = parseQuota((Response)localObject2);
            localObject3 = (Quota)paramString.get(((Quota)localObject2).quotaRoot);
            if (localObject3 != null) {
              localObject3 = ((Quota)localObject3).resources;
            }
            paramString.put(((Quota)localObject2).quotaRoot, localObject2);
            localObject1[i] = null;
          }
        }
      }
      localObject1[i] = ((Quota)paramString.nextElement());
      i += 1;
    }
  }
  
  protected ByteArray getResponseBuffer()
  {
    ByteArray localByteArray = this.ba;
    this.ba = null;
    return localByteArray;
  }
  
  public boolean hasCapability(String paramString)
  {
    return this.capabilities.containsKey(paramString.toUpperCase(Locale.ENGLISH));
  }
  
  public void idleAbort()
    throws ProtocolException
  {
    OutputStream localOutputStream = getOutputStream();
    try
    {
      localOutputStream.write(DONE);
      localOutputStream.flush();
      return;
    }
    catch (IOException localIOException) {}
  }
  
  public void idleStart()
    throws ProtocolException
  {
    try
    {
      if (!hasCapability("IDLE")) {
        throw new BadCommandException("IDLE not supported");
      }
    }
    finally {}
    try
    {
      this.idleTag = writeCommand("IDLE", null);
      Response localResponse1 = readResponse();
      if (!localResponse1.isContinuation()) {
        handleResult(localResponse1);
      }
      return;
    }
    catch (LiteralException localLiteralException)
    {
      for (;;)
      {
        Response localResponse2 = localLiteralException.getResponse();
      }
    }
    catch (Exception localException)
    {
      for (;;)
      {
        Response localResponse3 = Response.byeResponse(localException);
      }
    }
  }
  
  public boolean isAuthenticated()
  {
    return this.authenticated;
  }
  
  public boolean isREV1()
  {
    return this.rev1;
  }
  
  public ListInfo[] list(String paramString1, String paramString2)
    throws ProtocolException
  {
    return doList("LIST", paramString1, paramString2);
  }
  
  public Rights[] listRights(String paramString1, String paramString2)
    throws ProtocolException
  {
    if (!hasCapability("ACL")) {
      throw new BadCommandException("ACL not supported");
    }
    paramString1 = BASE64MailboxEncoder.encode(paramString1);
    Argument localArgument = new Argument();
    localArgument.writeString(paramString1);
    localArgument.writeString(paramString2);
    paramString2 = command("LISTRIGHTS", localArgument);
    localArgument = paramString2[(paramString2.length - 1)];
    paramString1 = new Vector();
    int i;
    if (localArgument.isOK())
    {
      i = 0;
      int j = paramString2.length;
      if (i < j) {}
    }
    else
    {
      notifyResponseHandlers(paramString2);
      handleResult(localArgument);
      paramString2 = new Rights[paramString1.size()];
      paramString1.copyInto(paramString2);
      return paramString2;
    }
    if (!(paramString2[i] instanceof IMAPResponse)) {}
    IMAPResponse localIMAPResponse;
    do
    {
      i += 1;
      break;
      localIMAPResponse = (IMAPResponse)paramString2[i];
    } while (!localIMAPResponse.keyEquals("LISTRIGHTS"));
    localIMAPResponse.readAtomString();
    localIMAPResponse.readAtomString();
    for (;;)
    {
      String str = localIMAPResponse.readAtomString();
      if (str == null)
      {
        paramString2[i] = null;
        break;
      }
      paramString1.addElement(new Rights(str));
    }
  }
  
  public void login(String paramString1, String paramString2)
    throws ProtocolException
  {
    Argument localArgument = new Argument();
    localArgument.writeString(paramString1);
    localArgument.writeString(paramString2);
    paramString1 = command("LOGIN", localArgument);
    notifyResponseHandlers(paramString1);
    handleResult(paramString1[(paramString1.length - 1)]);
    setCapabilities(paramString1[(paramString1.length - 1)]);
    this.authenticated = true;
  }
  
  public void logout()
    throws ProtocolException
  {
    Response[] arrayOfResponse = command("LOGOUT", null);
    this.authenticated = false;
    notifyResponseHandlers(arrayOfResponse);
    disconnect();
  }
  
  public ListInfo[] lsub(String paramString1, String paramString2)
    throws ProtocolException
  {
    return doList("LSUB", paramString1, paramString2);
  }
  
  public Rights myRights(String paramString)
    throws ProtocolException
  {
    if (!hasCapability("ACL")) {
      throw new BadCommandException("ACL not supported");
    }
    paramString = BASE64MailboxEncoder.encode(paramString);
    Object localObject1 = new Argument();
    ((Argument)localObject1).writeString(paramString);
    Response[] arrayOfResponse = command("MYRIGHTS", (Argument)localObject1);
    Response localResponse = arrayOfResponse[(arrayOfResponse.length - 1)];
    paramString = null;
    localObject1 = null;
    int i;
    if (localResponse.isOK())
    {
      i = 0;
      int j = arrayOfResponse.length;
      paramString = (String)localObject1;
      if (i < j) {}
    }
    else
    {
      notifyResponseHandlers(arrayOfResponse);
      handleResult(localResponse);
      return paramString;
    }
    if (!(arrayOfResponse[i] instanceof IMAPResponse)) {
      localObject1 = paramString;
    }
    for (;;)
    {
      i += 1;
      paramString = (String)localObject1;
      break;
      Object localObject2 = (IMAPResponse)arrayOfResponse[i];
      localObject1 = paramString;
      if (((IMAPResponse)localObject2).keyEquals("MYRIGHTS"))
      {
        ((IMAPResponse)localObject2).readAtomString();
        localObject2 = ((IMAPResponse)localObject2).readAtomString();
        localObject1 = paramString;
        if (paramString == null) {
          localObject1 = new Rights((String)localObject2);
        }
        arrayOfResponse[i] = null;
      }
    }
  }
  
  public Namespaces namespace()
    throws ProtocolException
  {
    if (!hasCapability("NAMESPACE")) {
      throw new BadCommandException("NAMESPACE not supported");
    }
    Response[] arrayOfResponse = command("NAMESPACE", null);
    Object localObject1 = null;
    Object localObject2 = null;
    Response localResponse = arrayOfResponse[(arrayOfResponse.length - 1)];
    int i;
    if (localResponse.isOK())
    {
      i = 0;
      int j = arrayOfResponse.length;
      localObject1 = localObject2;
      if (i < j) {}
    }
    else
    {
      notifyResponseHandlers(arrayOfResponse);
      handleResult(localResponse);
      return (Namespaces)localObject1;
    }
    if (!(arrayOfResponse[i] instanceof IMAPResponse)) {
      localObject2 = localObject1;
    }
    for (;;)
    {
      i += 1;
      localObject1 = localObject2;
      break;
      IMAPResponse localIMAPResponse = (IMAPResponse)arrayOfResponse[i];
      localObject2 = localObject1;
      if (localIMAPResponse.keyEquals("NAMESPACE"))
      {
        localObject2 = localObject1;
        if (localObject1 == null) {
          localObject2 = new Namespaces(localIMAPResponse);
        }
        arrayOfResponse[i] = null;
      }
    }
  }
  
  public void noop()
    throws ProtocolException
  {
    if (this.debug) {
      this.out.println("IMAP DEBUG: IMAPProtocol noop");
    }
    simpleCommand("NOOP", null);
  }
  
  protected void parseCapabilities(Response paramResponse)
  {
    for (;;)
    {
      String str = paramResponse.readAtom(']');
      if (str == null) {}
      do
      {
        return;
        if (str.length() != 0) {
          break;
        }
      } while (paramResponse.peekByte() == 93);
      paramResponse.skipToken();
      continue;
      this.capabilities.put(str.toUpperCase(Locale.ENGLISH), str);
      if (str.regionMatches(true, 0, "AUTH=", 0, 5))
      {
        this.authmechs.add(str.substring(5));
        if (this.debug) {
          this.out.println("IMAP DEBUG: AUTH: " + str.substring(5));
        }
      }
    }
  }
  
  public BODY peekBody(int paramInt, String paramString)
    throws ProtocolException
  {
    return fetchBody(paramInt, paramString, true);
  }
  
  public BODY peekBody(int paramInt1, String paramString, int paramInt2, int paramInt3)
    throws ProtocolException
  {
    return fetchBody(paramInt1, paramString, paramInt2, paramInt3, true, null);
  }
  
  public BODY peekBody(int paramInt1, String paramString, int paramInt2, int paramInt3, ByteArray paramByteArray)
    throws ProtocolException
  {
    return fetchBody(paramInt1, paramString, paramInt2, paramInt3, true, paramByteArray);
  }
  
  protected void processGreeting(Response paramResponse)
    throws ProtocolException
  {
    super.processGreeting(paramResponse);
    if (paramResponse.isOK())
    {
      setCapabilities(paramResponse);
      return;
    }
    if (((IMAPResponse)paramResponse).keyEquals("PREAUTH"))
    {
      this.authenticated = true;
      setCapabilities(paramResponse);
      return;
    }
    throw new ConnectionException(this, paramResponse);
  }
  
  public boolean processIdleResponse(Response paramResponse)
    throws ProtocolException
  {
    int i = 0;
    notifyResponseHandlers(new Response[] { paramResponse });
    if (paramResponse.isBYE()) {
      i = 1;
    }
    int j = i;
    if (paramResponse.isTagged())
    {
      j = i;
      if (paramResponse.getTag().equals(this.idleTag)) {
        j = 1;
      }
    }
    if (j != 0) {
      this.idleTag = null;
    }
    handleResult(paramResponse);
    return j == 0;
  }
  
  public void proxyauth(String paramString)
    throws ProtocolException
  {
    Argument localArgument = new Argument();
    localArgument.writeString(paramString);
    simpleCommand("PROXYAUTH", localArgument);
  }
  
  /* Error */
  public Response readIdleResponse()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 703	com/sun/mail/imap/protocol/IMAPProtocol:idleTag	Ljava/lang/String;
    //   6: astore_1
    //   7: aload_1
    //   8: ifnonnull +9 -> 17
    //   11: aconst_null
    //   12: astore_1
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_1
    //   16: areturn
    //   17: aload_0
    //   18: invokevirtual 411	com/sun/mail/imap/protocol/IMAPProtocol:readResponse	()Lcom/sun/mail/iap/Response;
    //   21: astore_1
    //   22: goto -9 -> 13
    //   25: astore_1
    //   26: aload_1
    //   27: invokestatic 407	com/sun/mail/iap/Response:byeResponse	(Ljava/lang/Exception;)Lcom/sun/mail/iap/Response;
    //   30: astore_1
    //   31: goto -18 -> 13
    //   34: astore_1
    //   35: aload_1
    //   36: invokestatic 407	com/sun/mail/iap/Response:byeResponse	(Ljava/lang/Exception;)Lcom/sun/mail/iap/Response;
    //   39: astore_1
    //   40: goto -27 -> 13
    //   43: astore_1
    //   44: aload_0
    //   45: monitorexit
    //   46: aload_1
    //   47: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	48	0	this	IMAPProtocol
    //   6	16	1	localObject1	Object
    //   25	2	1	localIOException	IOException
    //   30	1	1	localResponse1	Response
    //   34	2	1	localProtocolException	ProtocolException
    //   39	1	1	localResponse2	Response
    //   43	4	1	localObject2	Object
    // Exception table:
    //   from	to	target	type
    //   17	22	25	java/io/IOException
    //   17	22	34	com/sun/mail/iap/ProtocolException
    //   2	7	43	finally
    //   17	22	43	finally
    //   26	31	43	finally
    //   35	40	43	finally
  }
  
  public Response readResponse()
    throws IOException, ProtocolException
  {
    return IMAPResponse.readResponse(this);
  }
  
  public void rename(String paramString1, String paramString2)
    throws ProtocolException
  {
    paramString1 = BASE64MailboxEncoder.encode(paramString1);
    paramString2 = BASE64MailboxEncoder.encode(paramString2);
    Argument localArgument = new Argument();
    localArgument.writeString(paramString1);
    localArgument.writeString(paramString2);
    simpleCommand("RENAME", localArgument);
  }
  
  public void sasllogin(String[] paramArrayOfString, String paramString1, String paramString2, String paramString3, String paramString4)
    throws ProtocolException
  {
    if (this.saslAuthenticator == null) {}
    for (;;)
    {
      int i;
      try
      {
        Constructor localConstructor = Class.forName("com.sun.mail.imap.protocol.IMAPSaslAuthenticator").getConstructor(new Class[] { IMAPProtocol.class, String.class, Properties.class, Boolean.TYPE, PrintStream.class, String.class });
        String str = this.name;
        Properties localProperties = this.props;
        if (this.debug)
        {
          localObject = Boolean.TRUE;
          this.saslAuthenticator = ((SaslAuthenticator)localConstructor.newInstance(new Object[] { this, str, localProperties, localObject, this.out, this.host }));
          if ((paramArrayOfString == null) || (paramArrayOfString.length <= 0)) {
            break label285;
          }
          localObject = new ArrayList(paramArrayOfString.length);
          i = 0;
          if (i < paramArrayOfString.length) {
            break label248;
          }
          paramArrayOfString = (String[])localObject;
          paramArrayOfString = (String[])paramArrayOfString.toArray(new String[paramArrayOfString.size()]);
          if (this.saslAuthenticator.authenticate(paramArrayOfString, paramString1, paramString2, paramString3, paramString4)) {
            this.authenticated = true;
          }
          return;
        }
      }
      catch (Exception paramArrayOfString)
      {
        if (!this.debug) {
          continue;
        }
        this.out.println("IMAP DEBUG: Can't load SASL authenticator: " + paramArrayOfString);
        return;
      }
      Object localObject = Boolean.FALSE;
      continue;
      label248:
      if (this.authmechs.contains(paramArrayOfString[i])) {
        ((List)localObject).add(paramArrayOfString[i]);
      }
      i += 1;
      continue;
      label285:
      paramArrayOfString = this.authmechs;
    }
  }
  
  public int[] search(SearchTerm paramSearchTerm)
    throws ProtocolException, SearchException
  {
    return search("ALL", paramSearchTerm);
  }
  
  public int[] search(MessageSet[] paramArrayOfMessageSet, SearchTerm paramSearchTerm)
    throws ProtocolException, SearchException
  {
    return search(MessageSet.toString(paramArrayOfMessageSet), paramSearchTerm);
  }
  
  public MailboxInfo select(String paramString)
    throws ProtocolException
  {
    paramString = BASE64MailboxEncoder.encode(paramString);
    Object localObject = new Argument();
    ((Argument)localObject).writeString(paramString);
    localObject = command("SELECT", (Argument)localObject);
    paramString = new MailboxInfo((Response[])localObject);
    notifyResponseHandlers((Response[])localObject);
    localObject = localObject[(localObject.length - 1)];
    if (((Response)localObject).isOK()) {
      if (((Response)localObject).toString().indexOf("READ-ONLY") == -1) {
        break label81;
      }
    }
    label81:
    for (paramString.mode = 1;; paramString.mode = 2)
    {
      handleResult((Response)localObject);
      return paramString;
    }
  }
  
  public void setACL(String paramString, char paramChar, ACL paramACL)
    throws ProtocolException
  {
    if (!hasCapability("ACL")) {
      throw new BadCommandException("ACL not supported");
    }
    paramString = BASE64MailboxEncoder.encode(paramString);
    Argument localArgument = new Argument();
    localArgument.writeString(paramString);
    localArgument.writeString(paramACL.getName());
    paramACL = paramACL.getRights().toString();
    if (paramChar != '+')
    {
      paramString = paramACL;
      if (paramChar != '-') {}
    }
    else
    {
      paramString = paramChar + paramACL;
    }
    localArgument.writeString(paramString);
    paramString = command("SETACL", localArgument);
    paramACL = paramString[(paramString.length - 1)];
    notifyResponseHandlers(paramString);
    handleResult(paramACL);
  }
  
  protected void setCapabilities(Response paramResponse)
  {
    int i;
    do
    {
      i = paramResponse.readByte();
    } while ((i > 0) && (i != 91));
    if (i == 0) {}
    while (!paramResponse.readAtom().equalsIgnoreCase("CAPABILITY")) {
      return;
    }
    this.capabilities = new HashMap(10);
    this.authmechs = new ArrayList(5);
    parseCapabilities(paramResponse);
  }
  
  public void setQuota(Quota paramQuota)
    throws ProtocolException
  {
    if (!hasCapability("QUOTA")) {
      throw new BadCommandException("QUOTA not supported");
    }
    Argument localArgument1 = new Argument();
    localArgument1.writeString(paramQuota.quotaRoot);
    Argument localArgument2 = new Argument();
    int i;
    if (paramQuota.resources != null) {
      i = 0;
    }
    for (;;)
    {
      if (i >= paramQuota.resources.length)
      {
        localArgument1.writeArgument(localArgument2);
        paramQuota = command("SETQUOTA", localArgument1);
        localArgument1 = paramQuota[(paramQuota.length - 1)];
        notifyResponseHandlers(paramQuota);
        handleResult(localArgument1);
        return;
      }
      localArgument2.writeAtom(paramQuota.resources[i].name);
      localArgument2.writeNumber(paramQuota.resources[i].limit);
      i += 1;
    }
  }
  
  public void startTLS()
    throws ProtocolException
  {
    try
    {
      super.startTLS("STARTTLS");
      return;
    }
    catch (ProtocolException localProtocolException)
    {
      throw localProtocolException;
    }
    catch (Exception localException)
    {
      notifyResponseHandlers(new Response[] { Response.byeResponse(localException) });
      disconnect();
    }
  }
  
  public Status status(String paramString, String[] paramArrayOfString)
    throws ProtocolException
  {
    if ((!isREV1()) && (!hasCapability("IMAP4SUNVERSION"))) {
      throw new BadCommandException("STATUS not supported");
    }
    paramString = BASE64MailboxEncoder.encode(paramString);
    Object localObject = new Argument();
    ((Argument)localObject).writeString(paramString);
    Argument localArgument = new Argument();
    paramString = paramArrayOfString;
    if (paramArrayOfString == null) {
      paramString = Status.standardItems;
    }
    int i = 0;
    int j = paramString.length;
    for (;;)
    {
      if (i >= j)
      {
        ((Argument)localObject).writeArgument(localArgument);
        localObject = command("STATUS", (Argument)localObject);
        paramString = null;
        paramArrayOfString = null;
        localArgument = localObject[(localObject.length - 1)];
        if (localArgument.isOK())
        {
          i = 0;
          j = localObject.length;
          paramString = paramArrayOfString;
          if (i < j) {
            break;
          }
        }
        notifyResponseHandlers((Response[])localObject);
        handleResult(localArgument);
        return paramString;
      }
      localArgument.writeAtom(paramString[i]);
      i += 1;
    }
    if (!(localObject[i] instanceof IMAPResponse)) {
      paramArrayOfString = paramString;
    }
    IMAPResponse localIMAPResponse;
    do
    {
      i += 1;
      paramString = paramArrayOfString;
      break;
      localIMAPResponse = (IMAPResponse)localObject[i];
      paramArrayOfString = paramString;
    } while (!localIMAPResponse.keyEquals("STATUS"));
    if (paramString == null) {
      paramString = new Status(localIMAPResponse);
    }
    for (;;)
    {
      localObject[i] = null;
      paramArrayOfString = paramString;
      break;
      Status.add(paramString, new Status(localIMAPResponse));
    }
  }
  
  public void storeFlags(int paramInt1, int paramInt2, Flags paramFlags, boolean paramBoolean)
    throws ProtocolException
  {
    storeFlags(String.valueOf(paramInt1) + ":" + String.valueOf(paramInt2), paramFlags, paramBoolean);
  }
  
  public void storeFlags(int paramInt, Flags paramFlags, boolean paramBoolean)
    throws ProtocolException
  {
    storeFlags(String.valueOf(paramInt), paramFlags, paramBoolean);
  }
  
  public void storeFlags(MessageSet[] paramArrayOfMessageSet, Flags paramFlags, boolean paramBoolean)
    throws ProtocolException
  {
    storeFlags(MessageSet.toString(paramArrayOfMessageSet), paramFlags, paramBoolean);
  }
  
  public void subscribe(String paramString)
    throws ProtocolException
  {
    Argument localArgument = new Argument();
    localArgument.writeString(BASE64MailboxEncoder.encode(paramString));
    simpleCommand("SUBSCRIBE", localArgument);
  }
  
  protected boolean supportsNonSyncLiterals()
  {
    return hasCapability("LITERAL+");
  }
  
  public void uidexpunge(UIDSet[] paramArrayOfUIDSet)
    throws ProtocolException
  {
    if (!hasCapability("UIDPLUS")) {
      throw new BadCommandException("UID EXPUNGE not supported");
    }
    simpleCommand("UID EXPUNGE " + UIDSet.toString(paramArrayOfUIDSet), null);
  }
  
  public void unsubscribe(String paramString)
    throws ProtocolException
  {
    Argument localArgument = new Argument();
    localArgument.writeString(BASE64MailboxEncoder.encode(paramString));
    simpleCommand("UNSUBSCRIBE", localArgument);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/protocol/IMAPProtocol.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */