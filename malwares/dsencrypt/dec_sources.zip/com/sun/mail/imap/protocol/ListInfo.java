package com.sun.mail.imap.protocol;

import com.sun.mail.iap.ParsingException;
import java.util.Vector;

public class ListInfo
{
  public static final int CHANGED = 1;
  public static final int INDETERMINATE = 3;
  public static final int UNCHANGED = 2;
  public String[] attrs;
  public boolean canOpen = true;
  public int changeState = 3;
  public boolean hasInferiors = true;
  public String name = null;
  public char separator = '/';
  
  public ListInfo(IMAPResponse paramIMAPResponse)
    throws ParsingException
  {
    String[] arrayOfString = paramIMAPResponse.readSimpleList();
    Vector localVector = new Vector();
    int i;
    if (arrayOfString != null)
    {
      i = 0;
      if (i < arrayOfString.length) {}
    }
    else
    {
      this.attrs = new String[localVector.size()];
      localVector.copyInto(this.attrs);
      paramIMAPResponse.skipSpaces();
      if (paramIMAPResponse.readByte() != 34) {
        break label241;
      }
      char c = (char)paramIMAPResponse.readByte();
      this.separator = c;
      if (c == '\\') {
        this.separator = ((char)paramIMAPResponse.readByte());
      }
      paramIMAPResponse.skip(1);
    }
    for (;;)
    {
      paramIMAPResponse.skipSpaces();
      this.name = paramIMAPResponse.readAtomString();
      this.name = BASE64MailboxDecoder.decode(this.name);
      return;
      if (arrayOfString[i].equalsIgnoreCase("\\Marked")) {
        this.changeState = 1;
      }
      for (;;)
      {
        localVector.addElement(arrayOfString[i]);
        i += 1;
        break;
        if (arrayOfString[i].equalsIgnoreCase("\\Unmarked")) {
          this.changeState = 2;
        } else if (arrayOfString[i].equalsIgnoreCase("\\Noselect")) {
          this.canOpen = false;
        } else if (arrayOfString[i].equalsIgnoreCase("\\Noinferiors")) {
          this.hasInferiors = false;
        }
      }
      label241:
      paramIMAPResponse.skip(2);
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/protocol/ListInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */