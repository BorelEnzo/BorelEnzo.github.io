package com.sun.mail.imap.protocol;

import com.sun.mail.iap.ByteArray;
import com.sun.mail.iap.ParsingException;
import java.io.ByteArrayInputStream;

public class RFC822DATA
  implements Item
{
  static final char[] name = { 82, 70, 67, 56, 50, 50 };
  public ByteArray data;
  public int msgno;
  
  public RFC822DATA(FetchResponse paramFetchResponse)
    throws ParsingException
  {
    this.msgno = paramFetchResponse.getNumber();
    paramFetchResponse.skipSpaces();
    this.data = paramFetchResponse.readByteArray();
  }
  
  public ByteArray getByteArray()
  {
    return this.data;
  }
  
  public ByteArrayInputStream getByteArrayInputStream()
  {
    if (this.data != null) {
      return this.data.toByteArrayInputStream();
    }
    return null;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/protocol/RFC822DATA.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */