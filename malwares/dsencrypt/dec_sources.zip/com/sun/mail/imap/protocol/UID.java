package com.sun.mail.imap.protocol;

import com.sun.mail.iap.ParsingException;

public class UID
  implements Item
{
  static final char[] name = { 85, 73, 68 };
  public int seqnum;
  public long uid;
  
  public UID(FetchResponse paramFetchResponse)
    throws ParsingException
  {
    this.seqnum = paramFetchResponse.getNumber();
    paramFetchResponse.skipSpaces();
    this.uid = paramFetchResponse.readLong();
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/protocol/UID.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */