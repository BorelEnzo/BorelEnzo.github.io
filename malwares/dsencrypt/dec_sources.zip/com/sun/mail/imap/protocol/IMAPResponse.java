package com.sun.mail.imap.protocol;

import com.sun.mail.iap.Protocol;
import com.sun.mail.iap.ProtocolException;
import com.sun.mail.iap.Response;
import com.sun.mail.util.ASCIIUtility;
import java.io.IOException;
import java.util.Vector;

public class IMAPResponse
  extends Response
{
  private String key;
  private int number;
  
  public IMAPResponse(Protocol paramProtocol)
    throws IOException, ProtocolException
  {
    super(paramProtocol);
    if ((isUnTagged()) && (!isOK()) && (!isNO()) && (!isBAD()) && (!isBYE())) {
      this.key = readAtom();
    }
    try
    {
      this.number = Integer.parseInt(this.key);
      this.key = readAtom();
      return;
    }
    catch (NumberFormatException paramProtocol) {}
  }
  
  public IMAPResponse(IMAPResponse paramIMAPResponse)
  {
    super(paramIMAPResponse);
    this.key = paramIMAPResponse.key;
    this.number = paramIMAPResponse.number;
  }
  
  public static IMAPResponse readResponse(Protocol paramProtocol)
    throws IOException, ProtocolException
  {
    IMAPResponse localIMAPResponse = new IMAPResponse(paramProtocol);
    paramProtocol = localIMAPResponse;
    if (localIMAPResponse.keyEquals("FETCH")) {
      paramProtocol = new FetchResponse(localIMAPResponse);
    }
    return paramProtocol;
  }
  
  public String getKey()
  {
    return this.key;
  }
  
  public int getNumber()
  {
    return this.number;
  }
  
  public boolean keyEquals(String paramString)
  {
    return (this.key != null) && (this.key.equalsIgnoreCase(paramString));
  }
  
  public String[] readSimpleList()
  {
    skipSpaces();
    if (this.buffer[this.index] != 40) {
      return null;
    }
    this.index += 1;
    Vector localVector = new Vector();
    int j;
    for (int i = this.index;; i = j)
    {
      if (this.buffer[this.index] == 41)
      {
        if (this.index > i) {
          localVector.addElement(ASCIIUtility.toString(this.buffer, i, this.index));
        }
        this.index += 1;
        i = localVector.size();
        if (i <= 0) {
          break;
        }
        String[] arrayOfString = new String[i];
        localVector.copyInto(arrayOfString);
        return arrayOfString;
      }
      j = i;
      if (this.buffer[this.index] == 32)
      {
        localVector.addElement(ASCIIUtility.toString(this.buffer, i, this.index));
        j = this.index + 1;
      }
      this.index += 1;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/protocol/IMAPResponse.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */