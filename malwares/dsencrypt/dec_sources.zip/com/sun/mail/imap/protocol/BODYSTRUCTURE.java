package com.sun.mail.imap.protocol;

import com.sun.mail.iap.ParsingException;
import com.sun.mail.iap.Response;
import java.io.PrintStream;
import java.util.Vector;
import javax.mail.internet.ParameterList;

public class BODYSTRUCTURE
  implements Item
{
  private static int MULTI = 2;
  private static int NESTED = 3;
  private static int SINGLE;
  static final char[] name;
  private static boolean parseDebug = false;
  public String attachment;
  public BODYSTRUCTURE[] bodies;
  public ParameterList cParams;
  public ParameterList dParams;
  public String description;
  public String disposition;
  public String encoding;
  public ENVELOPE envelope;
  public String id;
  public String[] language;
  public int lines = -1;
  public String md5;
  public int msgno;
  private int processedType;
  public int size = -1;
  public String subtype;
  public String type;
  
  static
  {
    boolean bool = true;
    name = new char[] { 66, 79, 68, 89, 83, 84, 82, 85, 67, 84, 85, 82, 69 };
    SINGLE = 1;
    try
    {
      String str = System.getProperty("mail.imap.parse.debug");
      if ((str != null) && (str.equalsIgnoreCase("true"))) {}
      for (;;)
      {
        parseDebug = bool;
        return;
        bool = false;
      }
      return;
    }
    catch (SecurityException localSecurityException) {}
  }
  
  public BODYSTRUCTURE(FetchResponse paramFetchResponse)
    throws ParsingException
  {
    if (parseDebug) {
      System.out.println("DEBUG IMAP: parsing BODYSTRUCTURE");
    }
    this.msgno = paramFetchResponse.getNumber();
    if (parseDebug) {
      System.out.println("DEBUG IMAP: msgno " + this.msgno);
    }
    paramFetchResponse.skipSpaces();
    if (paramFetchResponse.readByte() != 40) {
      throw new ParsingException("BODYSTRUCTURE parse error: missing ``('' at start");
    }
    Object localObject;
    if (paramFetchResponse.peekByte() == 40)
    {
      if (parseDebug) {
        System.out.println("DEBUG IMAP: parsing multipart");
      }
      this.type = "multipart";
      this.processedType = MULTI;
      localObject = new Vector(1);
      do
      {
        ((Vector)localObject).addElement(new BODYSTRUCTURE(paramFetchResponse));
        paramFetchResponse.skipSpaces();
      } while (paramFetchResponse.peekByte() == 40);
      this.bodies = new BODYSTRUCTURE[((Vector)localObject).size()];
      ((Vector)localObject).copyInto(this.bodies);
      this.subtype = paramFetchResponse.readString();
      if (parseDebug) {
        System.out.println("DEBUG IMAP: subtype " + this.subtype);
      }
      if (paramFetchResponse.readByte() == 41) {
        if (parseDebug) {
          System.out.println("DEBUG IMAP: parse DONE");
        }
      }
    }
    int i;
    label455:
    label508:
    do
    {
      do
      {
        do
        {
          for (;;)
          {
            return;
            if (parseDebug) {
              System.out.println("DEBUG IMAP: parsing extension data");
            }
            this.cParams = parseParameters(paramFetchResponse);
            if (paramFetchResponse.readByte() == 41)
            {
              if (parseDebug) {
                System.out.println("DEBUG IMAP: body parameters DONE");
              }
            }
            else
            {
              i = paramFetchResponse.readByte();
              if (i == 40)
              {
                if (parseDebug) {
                  System.out.println("DEBUG IMAP: parse disposition");
                }
                this.disposition = paramFetchResponse.readString();
                if (parseDebug) {
                  System.out.println("DEBUG IMAP: disposition " + this.disposition);
                }
                this.dParams = parseParameters(paramFetchResponse);
                if (paramFetchResponse.readByte() != 41) {
                  throw new ParsingException("BODYSTRUCTURE parse error: missing ``)'' at end of disposition in multipart");
                }
                if (parseDebug) {
                  System.out.println("DEBUG IMAP: disposition DONE");
                }
              }
              for (;;)
              {
                i = paramFetchResponse.readByte();
                if (i != 41) {
                  break label508;
                }
                if (!parseDebug) {
                  break;
                }
                System.out.println("DEBUG IMAP: no body-fld-lang");
                return;
                if ((i != 78) && (i != 110)) {
                  break label455;
                }
                if (parseDebug) {
                  System.out.println("DEBUG IMAP: disposition NIL");
                }
                paramFetchResponse.skip(2);
              }
              throw new ParsingException("BODYSTRUCTURE parse error: " + this.type + "/" + this.subtype + ": " + "bad multipart disposition, b " + i);
              if (i != 32) {
                throw new ParsingException("BODYSTRUCTURE parse error: missing space after disposition");
              }
              if (paramFetchResponse.peekByte() == 40)
              {
                this.language = paramFetchResponse.readStringList();
                if (parseDebug) {
                  System.out.println("DEBUG IMAP: language len " + this.language.length);
                }
              }
              while (paramFetchResponse.readByte() == 32)
              {
                parseBodyExtension(paramFetchResponse);
                continue;
                localObject = paramFetchResponse.readString();
                if (localObject != null)
                {
                  this.language = new String[] { localObject };
                  if (parseDebug) {
                    System.out.println("DEBUG IMAP: language " + (String)localObject);
                  }
                }
              }
            }
          }
          if (parseDebug) {
            System.out.println("DEBUG IMAP: single part");
          }
          this.type = paramFetchResponse.readString();
          if (parseDebug) {
            System.out.println("DEBUG IMAP: type " + this.type);
          }
          this.processedType = SINGLE;
          this.subtype = paramFetchResponse.readString();
          if (parseDebug) {
            System.out.println("DEBUG IMAP: subtype " + this.subtype);
          }
          if (this.type == null)
          {
            this.type = "application";
            this.subtype = "octet-stream";
          }
          this.cParams = parseParameters(paramFetchResponse);
          if (parseDebug) {
            System.out.println("DEBUG IMAP: cParams " + this.cParams);
          }
          this.id = paramFetchResponse.readString();
          if (parseDebug) {
            System.out.println("DEBUG IMAP: id " + this.id);
          }
          this.description = paramFetchResponse.readString();
          if (parseDebug) {
            System.out.println("DEBUG IMAP: description " + this.description);
          }
          this.encoding = paramFetchResponse.readString();
          if (parseDebug) {
            System.out.println("DEBUG IMAP: encoding " + this.encoding);
          }
          this.size = paramFetchResponse.readNumber();
          if (parseDebug) {
            System.out.println("DEBUG IMAP: size " + this.size);
          }
          if (this.size < 0) {
            throw new ParsingException("BODYSTRUCTURE parse error: bad ``size'' element");
          }
          if (this.type.equalsIgnoreCase("text"))
          {
            this.lines = paramFetchResponse.readNumber();
            if (parseDebug) {
              System.out.println("DEBUG IMAP: lines " + this.lines);
            }
            if (this.lines < 0) {
              throw new ParsingException("BODYSTRUCTURE parse error: bad ``lines'' element");
            }
          }
          else if ((this.type.equalsIgnoreCase("message")) && (this.subtype.equalsIgnoreCase("rfc822")))
          {
            this.processedType = NESTED;
            this.envelope = new ENVELOPE(paramFetchResponse);
            this.bodies = new BODYSTRUCTURE[] { new BODYSTRUCTURE(paramFetchResponse) };
            this.lines = paramFetchResponse.readNumber();
            if (parseDebug) {
              System.out.println("DEBUG IMAP: lines " + this.lines);
            }
            if (this.lines < 0) {
              throw new ParsingException("BODYSTRUCTURE parse error: bad ``lines'' element");
            }
          }
          else
          {
            paramFetchResponse.skipSpaces();
            if (Character.isDigit((char)paramFetchResponse.peekByte())) {
              throw new ParsingException("BODYSTRUCTURE parse error: server erroneously included ``lines'' element with type " + this.type + "/" + this.subtype);
            }
          }
          if (paramFetchResponse.peekByte() != 41) {
            break;
          }
          paramFetchResponse.readByte();
        } while (!parseDebug);
        System.out.println("DEBUG IMAP: parse DONE");
        return;
        this.md5 = paramFetchResponse.readString();
        if (paramFetchResponse.readByte() != 41) {
          break;
        }
      } while (!parseDebug);
      System.out.println("DEBUG IMAP: no MD5 DONE");
      return;
      i = paramFetchResponse.readByte();
      if (i == 40)
      {
        this.disposition = paramFetchResponse.readString();
        if (parseDebug) {
          System.out.println("DEBUG IMAP: disposition " + this.disposition);
        }
        this.dParams = parseParameters(paramFetchResponse);
        if (parseDebug) {
          System.out.println("DEBUG IMAP: dParams " + this.dParams);
        }
        if (paramFetchResponse.readByte() != 41) {
          throw new ParsingException("BODYSTRUCTURE parse error: missing ``)'' at end of disposition");
        }
      }
      else
      {
        if ((i != 78) && (i != 110)) {
          break;
        }
        if (parseDebug) {
          System.out.println("DEBUG IMAP: disposition NIL");
        }
        paramFetchResponse.skip(2);
      }
      if (paramFetchResponse.readByte() != 41) {
        break label1505;
      }
    } while (!parseDebug);
    System.out.println("DEBUG IMAP: disposition DONE");
    return;
    throw new ParsingException("BODYSTRUCTURE parse error: " + this.type + "/" + this.subtype + ": " + "bad single part disposition, b " + i);
    label1505:
    if (paramFetchResponse.peekByte() == 40)
    {
      this.language = paramFetchResponse.readStringList();
      if (parseDebug) {
        System.out.println("DEBUG IMAP: language len " + this.language.length);
      }
    }
    for (;;)
    {
      if (paramFetchResponse.readByte() != 32)
      {
        if (!parseDebug) {
          break;
        }
        System.out.println("DEBUG IMAP: all DONE");
        return;
        localObject = paramFetchResponse.readString();
        if (localObject == null) {
          continue;
        }
        this.language = new String[] { localObject };
        if (!parseDebug) {
          continue;
        }
        System.out.println("DEBUG IMAP: language " + (String)localObject);
        continue;
      }
      parseBodyExtension(paramFetchResponse);
    }
  }
  
  private void parseBodyExtension(Response paramResponse)
    throws ParsingException
  {
    paramResponse.skipSpaces();
    int i = paramResponse.peekByte();
    if (i == 40)
    {
      paramResponse.skip(1);
      do
      {
        parseBodyExtension(paramResponse);
      } while (paramResponse.readByte() != 41);
      return;
    }
    if (Character.isDigit((char)i))
    {
      paramResponse.readNumber();
      return;
    }
    paramResponse.readString();
  }
  
  private ParameterList parseParameters(Response paramResponse)
    throws ParsingException
  {
    paramResponse.skipSpaces();
    int i = paramResponse.readByte();
    if (i == 40)
    {
      ParameterList localParameterList = new ParameterList();
      do
      {
        String str1 = paramResponse.readString();
        if (parseDebug) {
          System.out.println("DEBUG IMAP: parameter name " + str1);
        }
        if (str1 == null) {
          throw new ParsingException("BODYSTRUCTURE parse error: " + this.type + "/" + this.subtype + ": " + "null name in parameter list");
        }
        String str2 = paramResponse.readString();
        if (parseDebug) {
          System.out.println("DEBUG IMAP: parameter value " + str2);
        }
        localParameterList.set(str1, str2);
      } while (paramResponse.readByte() != 41);
      localParameterList.set(null, "DONE");
      return localParameterList;
    }
    if ((i == 78) || (i == 110))
    {
      if (parseDebug) {
        System.out.println("DEBUG IMAP: parameter list NIL");
      }
      paramResponse.skip(2);
      return null;
    }
    throw new ParsingException("Parameter list parse error");
  }
  
  public boolean isMulti()
  {
    return this.processedType == MULTI;
  }
  
  public boolean isNested()
  {
    return this.processedType == NESTED;
  }
  
  public boolean isSingle()
  {
    return this.processedType == SINGLE;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/protocol/BODYSTRUCTURE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */