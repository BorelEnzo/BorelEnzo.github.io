package com.sun.mail.imap.protocol;

import com.sun.mail.iap.ParsingException;
import com.sun.mail.iap.Response;

public class Status
{
  static final String[] standardItems = { "MESSAGES", "RECENT", "UNSEEN", "UIDNEXT", "UIDVALIDITY" };
  public String mbox = null;
  public int recent = -1;
  public int total = -1;
  public long uidnext = -1L;
  public long uidvalidity = -1L;
  public int unseen = -1;
  
  public Status(Response paramResponse)
    throws ParsingException
  {
    this.mbox = paramResponse.readAtomString();
    paramResponse.skipSpaces();
    if (paramResponse.readByte() != 40) {
      throw new ParsingException("parse error in STATUS");
    }
    for (;;)
    {
      String str = paramResponse.readAtom();
      if (str.equalsIgnoreCase("MESSAGES")) {
        this.total = paramResponse.readNumber();
      }
      while (paramResponse.readByte() == 41)
      {
        return;
        if (str.equalsIgnoreCase("RECENT")) {
          this.recent = paramResponse.readNumber();
        } else if (str.equalsIgnoreCase("UIDNEXT")) {
          this.uidnext = paramResponse.readLong();
        } else if (str.equalsIgnoreCase("UIDVALIDITY")) {
          this.uidvalidity = paramResponse.readLong();
        } else if (str.equalsIgnoreCase("UNSEEN")) {
          this.unseen = paramResponse.readNumber();
        }
      }
    }
  }
  
  public static void add(Status paramStatus1, Status paramStatus2)
  {
    if (paramStatus2.total != -1) {
      paramStatus1.total = paramStatus2.total;
    }
    if (paramStatus2.recent != -1) {
      paramStatus1.recent = paramStatus2.recent;
    }
    if (paramStatus2.uidnext != -1L) {
      paramStatus1.uidnext = paramStatus2.uidnext;
    }
    if (paramStatus2.uidvalidity != -1L) {
      paramStatus1.uidvalidity = paramStatus2.uidvalidity;
    }
    if (paramStatus2.unseen != -1) {
      paramStatus1.unseen = paramStatus2.unseen;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/protocol/Status.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */