package com.sun.mail.imap.protocol;

import com.sun.mail.iap.ByteArray;
import com.sun.mail.iap.ProtocolException;
import com.sun.mail.iap.Response;
import com.sun.mail.util.ASCIIUtility;
import com.sun.mail.util.BASE64DecoderStream;
import com.sun.mail.util.BASE64EncoderStream;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Properties;
import java.util.Vector;
import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.sasl.RealmCallback;
import javax.security.sasl.RealmChoiceCallback;
import javax.security.sasl.Sasl;
import javax.security.sasl.SaslClient;
import javax.security.sasl.SaslException;

public class IMAPSaslAuthenticator
  implements SaslAuthenticator
{
  private boolean debug;
  private String host;
  private String name;
  private PrintStream out;
  private IMAPProtocol pr;
  private Properties props;
  
  public IMAPSaslAuthenticator(IMAPProtocol paramIMAPProtocol, String paramString1, Properties paramProperties, boolean paramBoolean, PrintStream paramPrintStream, String paramString2)
  {
    this.pr = paramIMAPProtocol;
    this.name = paramString1;
    this.props = paramProperties;
    this.debug = paramBoolean;
    this.out = paramPrintStream;
    this.host = paramString2;
  }
  
  public boolean authenticate(String[] paramArrayOfString, final String paramString1, String paramString2, final String paramString3, final String paramString4)
    throws ProtocolException
  {
    Vector localVector;
    for (;;)
    {
      int i;
      synchronized (this.pr)
      {
        localVector = new Vector();
        Object localObject = null;
        int j = 0;
        if (this.debug)
        {
          this.out.print("IMAP SASL DEBUG: Mechanisms:");
          i = 0;
          if (i >= paramArrayOfString.length) {
            this.out.println();
          }
        }
        else
        {
          paramString1 = new CallbackHandler()
          {
            public void handle(Callback[] paramAnonymousArrayOfCallback)
            {
              if (IMAPSaslAuthenticator.this.debug) {
                IMAPSaslAuthenticator.this.out.println("IMAP SASL DEBUG: callback length: " + paramAnonymousArrayOfCallback.length);
              }
              int i = 0;
              if (i >= paramAnonymousArrayOfCallback.length) {
                return;
              }
              if (IMAPSaslAuthenticator.this.debug) {
                IMAPSaslAuthenticator.this.out.println("IMAP SASL DEBUG: callback " + i + ": " + paramAnonymousArrayOfCallback[i]);
              }
              if ((paramAnonymousArrayOfCallback[i] instanceof NameCallback)) {
                ((NameCallback)paramAnonymousArrayOfCallback[i]).setName(paramString3);
              }
              label281:
              for (;;)
              {
                i += 1;
                break;
                if ((paramAnonymousArrayOfCallback[i] instanceof PasswordCallback))
                {
                  ((PasswordCallback)paramAnonymousArrayOfCallback[i]).setPassword(paramString4.toCharArray());
                }
                else
                {
                  Object localObject2;
                  Object localObject1;
                  if ((paramAnonymousArrayOfCallback[i] instanceof RealmCallback))
                  {
                    localObject2 = (RealmCallback)paramAnonymousArrayOfCallback[i];
                    if (paramString1 != null) {}
                    for (localObject1 = paramString1;; localObject1 = ((RealmCallback)localObject2).getDefaultText())
                    {
                      ((RealmCallback)localObject2).setText((String)localObject1);
                      break;
                    }
                  }
                  if ((paramAnonymousArrayOfCallback[i] instanceof RealmChoiceCallback))
                  {
                    localObject1 = (RealmChoiceCallback)paramAnonymousArrayOfCallback[i];
                    if (paramString1 == null)
                    {
                      ((RealmChoiceCallback)localObject1).setSelectedIndex(((RealmChoiceCallback)localObject1).getDefaultChoice());
                    }
                    else
                    {
                      localObject2 = ((RealmChoiceCallback)localObject1).getChoices();
                      int j = 0;
                      for (;;)
                      {
                        if (j >= localObject2.length) {
                          break label281;
                        }
                        if (localObject2[j].equals(paramString1))
                        {
                          ((RealmChoiceCallback)localObject1).setSelectedIndex(j);
                          break;
                        }
                        j += 1;
                      }
                    }
                  }
                }
              }
            }
          };
        }
        try
        {
          paramString3 = Sasl.createSaslClient(paramArrayOfString, paramString2, this.name, this.host, this.props, paramString1);
          if (paramString3 != null) {
            continue;
          }
          if (this.debug) {
            this.out.println("IMAP SASL DEBUG: No SASL support");
          }
          return false;
        }
        catch (SaslException paramArrayOfString)
        {
          if (!this.debug) {
            continue;
          }
          this.out.println("IMAP SASL DEBUG: Failed to create SASL client: " + paramArrayOfString);
          return false;
        }
        this.out.print(" " + paramArrayOfString[i]);
        i += 1;
        continue;
        if (this.debug) {
          this.out.println("IMAP SASL DEBUG: SASL client " + paramString3.getMechanismName());
        }
        OutputStream localOutputStream;
        ByteArrayOutputStream localByteArrayOutputStream;
        byte[] arrayOfByte;
        boolean bool;
        try
        {
          paramString4 = this.pr.writeCommand("AUTHENTICATE " + paramString3.getMechanismName(), null);
          localOutputStream = this.pr.getIMAPOutputStream();
          localByteArrayOutputStream = new ByteArrayOutputStream();
          arrayOfByte = new byte[2];
          byte[] tmp281_279 = arrayOfByte;
          tmp281_279[0] = 13;
          byte[] tmp286_281 = tmp281_279;
          tmp286_281[1] = 10;
          tmp286_281;
          bool = paramString3.getMechanismName().equals("XGWTRUSTEDAPP");
          paramArrayOfString = (String[])localObject;
          i = j;
          if (i != 0)
          {
            if (!paramString3.isComplete()) {
              break;
            }
            paramString1 = (String)paramString3.getNegotiatedProperty("javax.security.sasl.qop");
            if ((paramString1 == null) || ((!paramString1.equalsIgnoreCase("auth-int")) && (!paramString1.equalsIgnoreCase("auth-conf")))) {
              break;
            }
            if (this.debug) {
              this.out.println("IMAP SASL DEBUG: Mechanism requires integrity or confidentiality");
            }
            return false;
          }
        }
        catch (Exception paramArrayOfString)
        {
          if (this.debug) {
            this.out.println("IMAP SASL DEBUG: AUTHENTICATE Exception: " + paramArrayOfString);
          }
          return false;
        }
        try
        {
          paramString1 = this.pr.readResponse();
          if (!paramString1.isContinuation()) {
            break label690;
          }
          paramArrayOfString = (byte[])null;
          if (!paramString3.isComplete())
          {
            paramString2 = paramString1.readByteArray().getNewBytes();
            paramArrayOfString = paramString2;
            if (paramString2.length > 0) {
              paramArrayOfString = BASE64DecoderStream.decode(paramString2);
            }
            if (this.debug) {
              this.out.println("IMAP SASL DEBUG: challenge: " + ASCIIUtility.toString(paramArrayOfString, 0, paramArrayOfString.length) + " :");
            }
            paramArrayOfString = paramString3.evaluateChallenge(paramArrayOfString);
          }
          if (paramArrayOfString != null) {
            continue;
          }
          if (this.debug) {
            this.out.println("IMAP SASL DEBUG: no response");
          }
          localOutputStream.write(tmp281_279);
          localOutputStream.flush();
          localByteArrayOutputStream.reset();
          paramArrayOfString = paramString1;
        }
        catch (Exception paramArrayOfString)
        {
          if (this.debug) {
            paramArrayOfString.printStackTrace();
          }
          paramArrayOfString = Response.byeResponse(paramArrayOfString);
          i = 1;
        }
        continue;
        if (this.debug) {
          this.out.println("IMAP SASL DEBUG: response: " + ASCIIUtility.toString(paramArrayOfString, 0, paramArrayOfString.length) + " :");
        }
        paramArrayOfString = BASE64EncoderStream.encode(paramArrayOfString);
        if (bool) {
          localByteArrayOutputStream.write("XGWTRUSTEDAPP ".getBytes());
        }
        localByteArrayOutputStream.write(paramArrayOfString);
        localByteArrayOutputStream.write(tmp281_279);
        localOutputStream.write(localByteArrayOutputStream.toByteArray());
        localOutputStream.flush();
        localByteArrayOutputStream.reset();
        paramArrayOfString = paramString1;
      }
      label690:
      if ((paramString1.isTagged()) && (paramString1.getTag().equals(paramString4)))
      {
        i = 1;
        paramArrayOfString = paramString1;
      }
      else if (paramString1.isBYE())
      {
        i = 1;
        paramArrayOfString = paramString1;
      }
      else
      {
        localVector.addElement(paramString1);
        paramArrayOfString = paramString1;
      }
    }
    paramString1 = new Response[localVector.size()];
    localVector.copyInto(paramString1);
    this.pr.notifyResponseHandlers(paramString1);
    this.pr.handleResult(paramArrayOfString);
    this.pr.setCapabilities(paramArrayOfString);
    return true;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/protocol/IMAPSaslAuthenticator.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */