package com.sun.mail.imap.protocol;

import com.sun.mail.iap.ParsingException;
import com.sun.mail.iap.Response;
import javax.mail.Flags;

public class MailboxInfo
{
  public Flags availableFlags = null;
  public int first = -1;
  public int mode;
  public Flags permanentFlags = null;
  public int recent = -1;
  public int total = -1;
  public long uidnext = -1L;
  public long uidvalidity = -1L;
  
  public MailboxInfo(Response[] paramArrayOfResponse)
    throws ParsingException
  {
    int i = 0;
    if (i >= paramArrayOfResponse.length)
    {
      if (this.permanentFlags == null)
      {
        if (this.availableFlags == null) {
          break label354;
        }
        this.permanentFlags = new Flags(this.availableFlags);
      }
    }
    else
    {
      if ((paramArrayOfResponse[i] == null) || (!(paramArrayOfResponse[i] instanceof IMAPResponse))) {}
      for (;;)
      {
        i += 1;
        break;
        IMAPResponse localIMAPResponse = (IMAPResponse)paramArrayOfResponse[i];
        if (localIMAPResponse.keyEquals("EXISTS"))
        {
          this.total = localIMAPResponse.getNumber();
          paramArrayOfResponse[i] = null;
        }
        else if (localIMAPResponse.keyEquals("RECENT"))
        {
          this.recent = localIMAPResponse.getNumber();
          paramArrayOfResponse[i] = null;
        }
        else if (localIMAPResponse.keyEquals("FLAGS"))
        {
          this.availableFlags = new FLAGS(localIMAPResponse);
          paramArrayOfResponse[i] = null;
        }
        else if ((localIMAPResponse.isUnTagged()) && (localIMAPResponse.isOK()))
        {
          localIMAPResponse.skipSpaces();
          if (localIMAPResponse.readByte() != 91)
          {
            localIMAPResponse.reset();
          }
          else
          {
            int j = 1;
            String str = localIMAPResponse.readAtom();
            if (str.equalsIgnoreCase("UNSEEN")) {
              this.first = localIMAPResponse.readNumber();
            }
            for (;;)
            {
              if (j == 0) {
                break label346;
              }
              paramArrayOfResponse[i] = null;
              break;
              if (str.equalsIgnoreCase("UIDVALIDITY")) {
                this.uidvalidity = localIMAPResponse.readLong();
              } else if (str.equalsIgnoreCase("PERMANENTFLAGS")) {
                this.permanentFlags = new FLAGS(localIMAPResponse);
              } else if (str.equalsIgnoreCase("UIDNEXT")) {
                this.uidnext = localIMAPResponse.readLong();
              } else {
                j = 0;
              }
            }
            label346:
            localIMAPResponse.reset();
          }
        }
      }
    }
    label354:
    this.permanentFlags = new Flags();
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/protocol/MailboxInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */