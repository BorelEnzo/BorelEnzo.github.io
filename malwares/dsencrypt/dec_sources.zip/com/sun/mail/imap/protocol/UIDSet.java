package com.sun.mail.imap.protocol;

import java.util.Vector;

public class UIDSet
{
  public long end;
  public long start;
  
  public UIDSet() {}
  
  public UIDSet(long paramLong1, long paramLong2)
  {
    this.start = paramLong1;
    this.end = paramLong2;
  }
  
  public static UIDSet[] createUIDSets(long[] paramArrayOfLong)
  {
    Vector localVector = new Vector();
    int i = 0;
    if (i >= paramArrayOfLong.length)
    {
      paramArrayOfLong = new UIDSet[localVector.size()];
      localVector.copyInto(paramArrayOfLong);
      return paramArrayOfLong;
    }
    UIDSet localUIDSet = new UIDSet();
    localUIDSet.start = paramArrayOfLong[i];
    i += 1;
    for (;;)
    {
      if (i >= paramArrayOfLong.length) {}
      while (paramArrayOfLong[i] != paramArrayOfLong[(i - 1)] + 1L)
      {
        localUIDSet.end = paramArrayOfLong[(i - 1)];
        localVector.addElement(localUIDSet);
        i = i - 1 + 1;
        break;
      }
      i += 1;
    }
  }
  
  public static long size(UIDSet[] paramArrayOfUIDSet)
  {
    long l = 0L;
    if (paramArrayOfUIDSet == null) {
      return 0L;
    }
    int i = 0;
    for (;;)
    {
      if (i >= paramArrayOfUIDSet.length) {
        return l;
      }
      l += paramArrayOfUIDSet[i].size();
      i += 1;
    }
  }
  
  public static String toString(UIDSet[] paramArrayOfUIDSet)
  {
    if ((paramArrayOfUIDSet == null) || (paramArrayOfUIDSet.length == 0)) {
      return null;
    }
    int i = 0;
    StringBuffer localStringBuffer = new StringBuffer();
    int j = paramArrayOfUIDSet.length;
    for (;;)
    {
      long l1 = paramArrayOfUIDSet[i].start;
      long l2 = paramArrayOfUIDSet[i].end;
      if (l2 > l1) {
        localStringBuffer.append(l1).append(':').append(l2);
      }
      for (;;)
      {
        i += 1;
        if (i < j) {
          break;
        }
        return localStringBuffer.toString();
        localStringBuffer.append(l1);
      }
      localStringBuffer.append(',');
    }
  }
  
  public long size()
  {
    return this.end - this.start + 1L;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/protocol/UIDSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */