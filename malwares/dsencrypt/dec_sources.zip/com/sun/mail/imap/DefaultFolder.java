package com.sun.mail.imap;

import com.sun.mail.iap.ProtocolException;
import com.sun.mail.imap.protocol.IMAPProtocol;
import com.sun.mail.imap.protocol.ListInfo;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.MethodNotSupportedException;

public class DefaultFolder
  extends IMAPFolder
{
  protected DefaultFolder(IMAPStore paramIMAPStore)
  {
    super("", 65535, paramIMAPStore);
    this.exists = true;
    this.type = 2;
  }
  
  public void appendMessages(Message[] paramArrayOfMessage)
    throws MessagingException
  {
    throw new MethodNotSupportedException("Cannot append to Default Folder");
  }
  
  public boolean delete(boolean paramBoolean)
    throws MessagingException
  {
    throw new MethodNotSupportedException("Cannot delete Default Folder");
  }
  
  public Message[] expunge()
    throws MessagingException
  {
    throw new MethodNotSupportedException("Cannot expunge Default Folder");
  }
  
  public Folder getFolder(String paramString)
    throws MessagingException
  {
    return new IMAPFolder(paramString, 65535, (IMAPStore)this.store);
  }
  
  public String getName()
  {
    return this.fullName;
  }
  
  public Folder getParent()
  {
    return null;
  }
  
  public boolean hasNewMessages()
    throws MessagingException
  {
    return false;
  }
  
  public Folder[] list(final String paramString)
    throws MessagingException
  {
    Object localObject = (ListInfo[])null;
    ListInfo[] arrayOfListInfo = (ListInfo[])doCommand(new IMAPFolder.ProtocolCommand()
    {
      public Object doCommand(IMAPProtocol paramAnonymousIMAPProtocol)
        throws ProtocolException
      {
        return paramAnonymousIMAPProtocol.list("", paramString);
      }
    });
    if (arrayOfListInfo == null)
    {
      paramString = new Folder[0];
      return paramString;
    }
    localObject = new IMAPFolder[arrayOfListInfo.length];
    int i = 0;
    for (;;)
    {
      paramString = (String)localObject;
      if (i >= localObject.length) {
        break;
      }
      localObject[i] = new IMAPFolder(arrayOfListInfo[i], (IMAPStore)this.store);
      i += 1;
    }
  }
  
  public Folder[] listSubscribed(final String paramString)
    throws MessagingException
  {
    Object localObject = (ListInfo[])null;
    ListInfo[] arrayOfListInfo = (ListInfo[])doCommand(new IMAPFolder.ProtocolCommand()
    {
      public Object doCommand(IMAPProtocol paramAnonymousIMAPProtocol)
        throws ProtocolException
      {
        return paramAnonymousIMAPProtocol.lsub("", paramString);
      }
    });
    if (arrayOfListInfo == null)
    {
      paramString = new Folder[0];
      return paramString;
    }
    localObject = new IMAPFolder[arrayOfListInfo.length];
    int i = 0;
    for (;;)
    {
      paramString = (String)localObject;
      if (i >= localObject.length) {
        break;
      }
      localObject[i] = new IMAPFolder(arrayOfListInfo[i], (IMAPStore)this.store);
      i += 1;
    }
  }
  
  public boolean renameTo(Folder paramFolder)
    throws MessagingException
  {
    throw new MethodNotSupportedException("Cannot rename Default Folder");
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/DefaultFolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */