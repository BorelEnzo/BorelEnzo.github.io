package com.sun.mail.imap;

public class ACL
  implements Cloneable
{
  private String name;
  private Rights rights;
  
  public ACL(String paramString)
  {
    this.name = paramString;
    this.rights = new Rights();
  }
  
  public ACL(String paramString, Rights paramRights)
  {
    this.name = paramString;
    this.rights = paramRights;
  }
  
  public Object clone()
    throws CloneNotSupportedException
  {
    ACL localACL = (ACL)super.clone();
    localACL.rights = ((Rights)this.rights.clone());
    return localACL;
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public Rights getRights()
  {
    return this.rights;
  }
  
  public void setRights(Rights paramRights)
  {
    this.rights = paramRights;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/ACL.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */