package com.sun.mail.imap;

import com.sun.mail.iap.CommandFailedException;
import com.sun.mail.iap.ConnectionException;
import com.sun.mail.iap.ProtocolException;
import com.sun.mail.iap.Response;
import com.sun.mail.imap.protocol.BODY;
import com.sun.mail.imap.protocol.BODYSTRUCTURE;
import com.sun.mail.imap.protocol.ENVELOPE;
import com.sun.mail.imap.protocol.FetchResponse;
import com.sun.mail.imap.protocol.IMAPProtocol;
import com.sun.mail.imap.protocol.INTERNALDATE;
import com.sun.mail.imap.protocol.MessageSet;
import com.sun.mail.imap.protocol.RFC822DATA;
import com.sun.mail.imap.protocol.RFC822SIZE;
import com.sun.mail.imap.protocol.UID;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Vector;
import javax.activation.DataHandler;
import javax.mail.Address;
import javax.mail.FetchProfile;
import javax.mail.FetchProfile.Item;
import javax.mail.Flags;
import javax.mail.Flags.Flag;
import javax.mail.Folder;
import javax.mail.FolderClosedException;
import javax.mail.Header;
import javax.mail.IllegalWriteException;
import javax.mail.Message;
import javax.mail.Message.RecipientType;
import javax.mail.MessageRemovedException;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.UIDFolder.FetchProfileItem;
import javax.mail.internet.ContentType;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.InternetHeaders;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeUtility;
import javax.mail.internet.ParameterList;

public class IMAPMessage
  extends MimeMessage
{
  private static String EnvelopeCmd = "ENVELOPE INTERNALDATE RFC822.SIZE";
  protected BODYSTRUCTURE bs;
  private String description;
  protected ENVELOPE envelope;
  private boolean headersLoaded = false;
  private Hashtable loadedHeaders;
  private boolean peek;
  private Date receivedDate;
  protected String sectionId;
  private int seqnum;
  private int size = -1;
  private String subject;
  private String type;
  private long uid = -1L;
  
  protected IMAPMessage(IMAPFolder paramIMAPFolder, int paramInt1, int paramInt2)
  {
    super(paramIMAPFolder, paramInt1);
    this.seqnum = paramInt2;
    this.flags = null;
  }
  
  protected IMAPMessage(Session paramSession)
  {
    super(paramSession);
  }
  
  private BODYSTRUCTURE _getBodyStructure()
  {
    return this.bs;
  }
  
  private ENVELOPE _getEnvelope()
  {
    return this.envelope;
  }
  
  private Flags _getFlags()
  {
    return this.flags;
  }
  
  private InternetAddress[] aaclone(InternetAddress[] paramArrayOfInternetAddress)
  {
    if (paramArrayOfInternetAddress == null) {
      return null;
    }
    return (InternetAddress[])paramArrayOfInternetAddress.clone();
  }
  
  private boolean areHeadersLoaded()
  {
    try
    {
      boolean bool = this.headersLoaded;
      return bool;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  private static String craftHeaderCmd(IMAPProtocol paramIMAPProtocol, String[] paramArrayOfString)
  {
    StringBuffer localStringBuffer;
    int i;
    if (paramIMAPProtocol.isREV1())
    {
      localStringBuffer = new StringBuffer("BODY.PEEK[HEADER.FIELDS (");
      i = 0;
      label19:
      if (i < paramArrayOfString.length) {
        break label57;
      }
      if (!paramIMAPProtocol.isREV1()) {
        break label83;
      }
      localStringBuffer.append(")]");
    }
    for (;;)
    {
      return localStringBuffer.toString();
      localStringBuffer = new StringBuffer("RFC822.HEADER.LINES (");
      break;
      label57:
      if (i > 0) {
        localStringBuffer.append(" ");
      }
      localStringBuffer.append(paramArrayOfString[i]);
      i += 1;
      break label19;
      label83:
      localStringBuffer.append(")");
    }
  }
  
  static void fetch(IMAPFolder paramIMAPFolder, Message[] paramArrayOfMessage, FetchProfile paramFetchProfile)
    throws MessagingException
  {
    localObject3 = new StringBuffer();
    j = 1;
    k = 0;
    if (paramFetchProfile.contains(FetchProfile.Item.ENVELOPE))
    {
      ((StringBuffer)localObject3).append(EnvelopeCmd);
      j = 0;
    }
    i = j;
    if (paramFetchProfile.contains(FetchProfile.Item.FLAGS))
    {
      if (j == 0) {
        break label304;
      }
      localObject1 = "FLAGS";
    }
    for (;;)
    {
      ((StringBuffer)localObject3).append((String)localObject1);
      i = 0;
      j = i;
      if (paramFetchProfile.contains(FetchProfile.Item.CONTENT_INFO))
      {
        if (i != 0)
        {
          localObject1 = "BODYSTRUCTURE";
          label90:
          ((StringBuffer)localObject3).append((String)localObject1);
          j = 0;
        }
      }
      else
      {
        i = j;
        if (paramFetchProfile.contains(UIDFolder.FetchProfileItem.UID))
        {
          if (j == 0) {
            break label318;
          }
          localObject1 = "UID";
          label123:
          ((StringBuffer)localObject3).append((String)localObject1);
          i = 0;
        }
        j = i;
        if (paramFetchProfile.contains(IMAPFolder.FetchProfileItem.HEADERS))
        {
          k = 1;
          if (!paramIMAPFolder.protocol.isREV1()) {
            break label332;
          }
          if (i == 0) {
            break label325;
          }
          localObject1 = "BODY.PEEK[HEADER]";
          label167:
          ((StringBuffer)localObject3).append((String)localObject1);
          j = 0;
        }
        i = j;
        if (paramFetchProfile.contains(IMAPFolder.FetchProfileItem.SIZE))
        {
          if (j == 0) {
            break label358;
          }
          localObject1 = "RFC822.SIZE";
          label200:
          ((StringBuffer)localObject3).append((String)localObject1);
          i = 0;
        }
        localObject1 = (String[])null;
        if (k == 0)
        {
          localObject2 = paramFetchProfile.getHeaderNames();
          localObject1 = localObject2;
          if (localObject2.length > 0)
          {
            if (i == 0) {
              ((StringBuffer)localObject3).append(" ");
            }
            ((StringBuffer)localObject3).append(craftHeaderCmd(paramIMAPFolder.protocol, (String[])localObject2));
            localObject1 = localObject2;
          }
        }
        localObject2 = new Utility.Condition()
        {
          private String[] hdrs = null;
          private boolean needBodyStructure = false;
          private boolean needEnvelope = false;
          private boolean needFlags = false;
          private boolean needHeaders = false;
          private boolean needSize = false;
          private boolean needUID = false;
          
          public boolean test(IMAPMessage paramAnonymousIMAPMessage)
          {
            if ((this.needEnvelope) && (paramAnonymousIMAPMessage._getEnvelope() == null)) {}
            while (((this.needFlags) && (paramAnonymousIMAPMessage._getFlags() == null)) || ((this.needBodyStructure) && (paramAnonymousIMAPMessage._getBodyStructure() == null)) || ((this.needUID) && (paramAnonymousIMAPMessage.getUID() == -1L)) || ((this.needHeaders) && (!paramAnonymousIMAPMessage.areHeadersLoaded())) || ((this.needSize) && (paramAnonymousIMAPMessage.size == -1))) {
              return true;
            }
            int i = 0;
            for (;;)
            {
              if (i >= this.hdrs.length) {
                return false;
              }
              if (!paramAnonymousIMAPMessage.isHeaderLoaded(this.hdrs[i])) {
                break;
              }
              i += 1;
            }
          }
        };
      }
      synchronized (paramIMAPFolder.messageCacheLock)
      {
        localObject2 = Utility.toMessageSet(paramArrayOfMessage, (Utility.Condition)localObject2);
        if (localObject2 == null)
        {
          return;
          label304:
          localObject1 = " FLAGS";
          continue;
          localObject1 = " BODYSTRUCTURE";
          break label90;
          label318:
          localObject1 = " UID";
          break label123;
          label325:
          localObject1 = " BODY.PEEK[HEADER]";
          break label167;
          label332:
          if (i != 0) {}
          for (localObject1 = "RFC822.HEADER";; localObject1 = " RFC822.HEADER")
          {
            ((StringBuffer)localObject3).append((String)localObject1);
            break;
          }
          label358:
          localObject1 = " RFC822.SIZE";
          break label200;
        }
        paramArrayOfMessage = (Response[])null;
        localVector = new Vector();
        try
        {
          localObject2 = paramIMAPFolder.protocol.fetch((MessageSet[])localObject2, ((StringBuffer)localObject3).toString());
          paramArrayOfMessage = (Message[])localObject2;
        }
        catch (ConnectionException paramArrayOfMessage)
        {
          throw new FolderClosedException(paramIMAPFolder, paramArrayOfMessage.getMessage());
        }
        catch (ProtocolException paramIMAPFolder)
        {
          throw new MessagingException(paramIMAPFolder.getMessage(), paramIMAPFolder);
          if (i < paramArrayOfMessage.length) {
            break label989;
          }
          i = localVector.size();
          if (i == 0) {
            break label472;
          }
          paramArrayOfMessage = new Response[i];
          localVector.copyInto(paramArrayOfMessage);
          paramIMAPFolder.handleResponses(paramArrayOfMessage);
          return;
          if ((paramArrayOfMessage[i] instanceof FetchResponse)) {
            break label496;
          }
          localVector.addElement(paramArrayOfMessage[i]);
          break label995;
          localObject3 = (FetchResponse)paramArrayOfMessage[i];
          IMAPMessage localIMAPMessage = paramIMAPFolder.getMessageBySeqNumber(((FetchResponse)localObject3).getNumber());
          int i2 = ((FetchResponse)localObject3).getItemCount();
          m = 0;
          j = 0;
          if (j < i2) {
            break label550;
          }
          if (m == 0) {
            break label995;
          }
          localVector.addElement(localObject3);
          break label995;
          localObject2 = ((FetchResponse)localObject3).getItem(j);
          if (!(localObject2 instanceof Flags)) {
            break label602;
          }
          if ((!paramFetchProfile.contains(FetchProfile.Item.FLAGS)) || (localIMAPMessage == null)) {
            break label1002;
          }
          localIMAPMessage.flags = ((Flags)localObject2);
          n = m;
          break label1005;
          if (!(localObject2 instanceof ENVELOPE)) {
            break label627;
          }
          localIMAPMessage.envelope = ((ENVELOPE)localObject2);
          n = m;
          break label1005;
          if (!(localObject2 instanceof INTERNALDATE)) {
            break label655;
          }
          localIMAPMessage.receivedDate = ((INTERNALDATE)localObject2).getDate();
          n = m;
          break label1005;
          if (!(localObject2 instanceof RFC822SIZE)) {
            break label683;
          }
          localIMAPMessage.size = ((RFC822SIZE)localObject2).size;
          n = m;
          break label1005;
          if (!(localObject2 instanceof BODYSTRUCTURE)) {
            break label708;
          }
          localIMAPMessage.bs = ((BODYSTRUCTURE)localObject2);
          n = m;
          break label1005;
          if (!(localObject2 instanceof UID)) {
            break label780;
          }
          localObject2 = (UID)localObject2;
          localIMAPMessage.uid = ((UID)localObject2).uid;
          if (paramIMAPFolder.uidTable != null) {
            break label751;
          }
          paramIMAPFolder.uidTable = new Hashtable();
          paramIMAPFolder.uidTable.put(new Long(((UID)localObject2).uid), localIMAPMessage);
          n = m;
          break label1005;
          if ((localObject2 instanceof RFC822DATA)) {
            break label800;
          }
          n = m;
          if (!(localObject2 instanceof BODY)) {
            break label1005;
          }
          if (!(localObject2 instanceof RFC822DATA)) {
            break label872;
          }
          localObject2 = ((RFC822DATA)localObject2).getByteArrayInputStream();
          Object localObject5 = new InternetHeaders();
          ((InternetHeaders)localObject5).load((InputStream)localObject2);
          if ((localIMAPMessage.headers != null) && (k == 0)) {
            break label885;
          }
          localIMAPMessage.headers = ((InternetHeaders)localObject5);
          for (;;)
          {
            if (k == 0) {
              break label1018;
            }
            localIMAPMessage.setHeadersLoaded(true);
            n = m;
            break label1005;
            localObject2 = ((BODY)localObject2).getByteArrayInputStream();
            break;
            localObject2 = ((InternetHeaders)localObject5).getAllHeaders();
            while (((Enumeration)localObject2).hasMoreElements())
            {
              localObject5 = (Header)((Enumeration)localObject2).nextElement();
              if (!localIMAPMessage.isHeaderLoaded(((Header)localObject5).getName())) {
                localIMAPMessage.headers.addHeader(((Header)localObject5).getName(), ((Header)localObject5).getValue());
              }
            }
          }
          for (;;)
          {
            n = m;
            if (i1 >= localObject1.length) {
              break;
            }
            localIMAPMessage.setHeaderLoaded(localObject1[i1]);
            i1 += 1;
          }
        }
        catch (CommandFailedException localCommandFailedException)
        {
          for (;;)
          {
            int m;
            int n;
            int i1;
            continue;
            i = 0;
            continue;
            if (paramArrayOfMessage[i] == null)
            {
              i += 1;
              continue;
              n = 1;
              j += 1;
              m = n;
              continue;
              i1 = 0;
            }
          }
        }
        if (paramArrayOfMessage == null) {
          return;
        }
      }
    }
  }
  
  /* Error */
  private boolean isHeaderLoaded(String paramString)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 49	com/sun/mail/imap/IMAPMessage:headersLoaded	Z
    //   6: istore_2
    //   7: iload_2
    //   8: ifeq +9 -> 17
    //   11: iconst_1
    //   12: istore_2
    //   13: aload_0
    //   14: monitorexit
    //   15: iload_2
    //   16: ireturn
    //   17: aload_0
    //   18: getfield 368	com/sun/mail/imap/IMAPMessage:loadedHeaders	Ljava/util/Hashtable;
    //   21: ifnull +21 -> 42
    //   24: aload_0
    //   25: getfield 368	com/sun/mail/imap/IMAPMessage:loadedHeaders	Ljava/util/Hashtable;
    //   28: aload_1
    //   29: getstatic 374	java/util/Locale:ENGLISH	Ljava/util/Locale;
    //   32: invokevirtual 380	java/lang/String:toUpperCase	(Ljava/util/Locale;)Ljava/lang/String;
    //   35: invokevirtual 384	java/util/Hashtable:containsKey	(Ljava/lang/Object;)Z
    //   38: istore_2
    //   39: goto -26 -> 13
    //   42: iconst_0
    //   43: istore_2
    //   44: goto -31 -> 13
    //   47: astore_1
    //   48: aload_0
    //   49: monitorexit
    //   50: aload_1
    //   51: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	52	0	this	IMAPMessage
    //   0	52	1	paramString	String
    //   6	38	2	bool	boolean
    // Exception table:
    //   from	to	target	type
    //   2	7	47	finally
    //   17	39	47	finally
  }
  
  /* Error */
  private void loadBODYSTRUCTURE()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 62	com/sun/mail/imap/IMAPMessage:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   6: astore_1
    //   7: aload_1
    //   8: ifnull +6 -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: aload_0
    //   15: invokevirtual 388	com/sun/mail/imap/IMAPMessage:getMessageCacheLock	()Ljava/lang/Object;
    //   18: astore_1
    //   19: aload_1
    //   20: monitorenter
    //   21: aload_0
    //   22: invokevirtual 392	com/sun/mail/imap/IMAPMessage:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   25: astore_2
    //   26: aload_0
    //   27: invokevirtual 395	com/sun/mail/imap/IMAPMessage:checkExpunged	()V
    //   30: aload_0
    //   31: aload_2
    //   32: aload_0
    //   33: invokevirtual 398	com/sun/mail/imap/IMAPMessage:getSequenceNumber	()I
    //   36: invokevirtual 402	com/sun/mail/imap/protocol/IMAPProtocol:fetchBodyStructure	(I)Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   39: putfield 62	com/sun/mail/imap/IMAPMessage:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   42: aload_0
    //   43: getfield 62	com/sun/mail/imap/IMAPMessage:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   46: ifnonnull +63 -> 109
    //   49: aload_0
    //   50: invokevirtual 405	com/sun/mail/imap/IMAPMessage:forceCheckExpunged	()V
    //   53: new 136	javax/mail/MessagingException
    //   56: dup
    //   57: ldc_w 407
    //   60: invokespecial 408	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   63: athrow
    //   64: astore_2
    //   65: aload_1
    //   66: monitorexit
    //   67: aload_2
    //   68: athrow
    //   69: astore_1
    //   70: aload_0
    //   71: monitorexit
    //   72: aload_1
    //   73: athrow
    //   74: astore_2
    //   75: new 236	javax/mail/FolderClosedException
    //   78: dup
    //   79: aload_0
    //   80: getfield 412	com/sun/mail/imap/IMAPMessage:folder	Ljavax/mail/Folder;
    //   83: aload_2
    //   84: invokevirtual 239	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   87: invokespecial 242	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   90: athrow
    //   91: astore_2
    //   92: aload_0
    //   93: invokevirtual 405	com/sun/mail/imap/IMAPMessage:forceCheckExpunged	()V
    //   96: new 136	javax/mail/MessagingException
    //   99: dup
    //   100: aload_2
    //   101: invokevirtual 243	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   104: aload_2
    //   105: invokespecial 246	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   108: athrow
    //   109: aload_1
    //   110: monitorexit
    //   111: goto -100 -> 11
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	114	0	this	IMAPMessage
    //   69	41	1	localObject2	Object
    //   25	7	2	localIMAPProtocol	IMAPProtocol
    //   64	4	2	localObject3	Object
    //   74	10	2	localConnectionException	ConnectionException
    //   91	14	2	localProtocolException	ProtocolException
    // Exception table:
    //   from	to	target	type
    //   21	42	64	finally
    //   42	64	64	finally
    //   65	67	64	finally
    //   75	91	64	finally
    //   92	109	64	finally
    //   109	111	64	finally
    //   2	7	69	finally
    //   14	21	69	finally
    //   67	69	69	finally
    //   21	42	74	com/sun/mail/iap/ConnectionException
    //   21	42	91	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  private void loadEnvelope()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 66	com/sun/mail/imap/IMAPMessage:envelope	Lcom/sun/mail/imap/protocol/ENVELOPE;
    //   6: astore 5
    //   8: aload 5
    //   10: ifnull +6 -> 16
    //   13: aload_0
    //   14: monitorexit
    //   15: return
    //   16: aconst_null
    //   17: checkcast 228	[Lcom/sun/mail/iap/Response;
    //   20: astore 5
    //   22: aload_0
    //   23: invokevirtual 388	com/sun/mail/imap/IMAPMessage:getMessageCacheLock	()Ljava/lang/Object;
    //   26: astore 5
    //   28: aload 5
    //   30: monitorenter
    //   31: aload_0
    //   32: invokevirtual 392	com/sun/mail/imap/IMAPMessage:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   35: astore 6
    //   37: aload_0
    //   38: invokevirtual 395	com/sun/mail/imap/IMAPMessage:checkExpunged	()V
    //   41: aload_0
    //   42: invokevirtual 398	com/sun/mail/imap/IMAPMessage:getSequenceNumber	()I
    //   45: istore_3
    //   46: aload 6
    //   48: iload_3
    //   49: getstatic 35	com/sun/mail/imap/IMAPMessage:EnvelopeCmd	Ljava/lang/String;
    //   52: invokevirtual 416	com/sun/mail/imap/protocol/IMAPProtocol:fetch	(ILjava/lang/String;)[Lcom/sun/mail/iap/Response;
    //   55: astore 7
    //   57: iconst_0
    //   58: istore_1
    //   59: iload_1
    //   60: aload 7
    //   62: arraylength
    //   63: if_icmplt +51 -> 114
    //   66: aload 6
    //   68: aload 7
    //   70: invokevirtual 419	com/sun/mail/imap/protocol/IMAPProtocol:notifyResponseHandlers	([Lcom/sun/mail/iap/Response;)V
    //   73: aload 6
    //   75: aload 7
    //   77: aload 7
    //   79: arraylength
    //   80: iconst_1
    //   81: isub
    //   82: aaload
    //   83: invokevirtual 423	com/sun/mail/imap/protocol/IMAPProtocol:handleResult	(Lcom/sun/mail/iap/Response;)V
    //   86: aload 5
    //   88: monitorexit
    //   89: aload_0
    //   90: getfield 66	com/sun/mail/imap/IMAPMessage:envelope	Lcom/sun/mail/imap/protocol/ENVELOPE;
    //   93: ifnonnull -80 -> 13
    //   96: new 136	javax/mail/MessagingException
    //   99: dup
    //   100: ldc_w 425
    //   103: invokespecial 408	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   106: athrow
    //   107: astore 5
    //   109: aload_0
    //   110: monitorexit
    //   111: aload 5
    //   113: athrow
    //   114: aload 7
    //   116: iload_1
    //   117: aaload
    //   118: ifnull +176 -> 294
    //   121: aload 7
    //   123: iload_1
    //   124: aaload
    //   125: instanceof 261
    //   128: ifeq +166 -> 294
    //   131: aload 7
    //   133: iload_1
    //   134: aaload
    //   135: checkcast 261	com/sun/mail/imap/protocol/FetchResponse
    //   138: invokevirtual 268	com/sun/mail/imap/protocol/FetchResponse:getNumber	()I
    //   141: iload_3
    //   142: if_icmpeq +6 -> 148
    //   145: goto +149 -> 294
    //   148: aload 7
    //   150: iload_1
    //   151: aaload
    //   152: checkcast 261	com/sun/mail/imap/protocol/FetchResponse
    //   155: astore 8
    //   157: aload 8
    //   159: invokevirtual 275	com/sun/mail/imap/protocol/FetchResponse:getItemCount	()I
    //   162: istore 4
    //   164: iconst_0
    //   165: istore_2
    //   166: iload_2
    //   167: iload 4
    //   169: if_icmpge +125 -> 294
    //   172: aload 8
    //   174: iload_2
    //   175: invokevirtual 279	com/sun/mail/imap/protocol/FetchResponse:getItem	(I)Lcom/sun/mail/imap/protocol/Item;
    //   178: astore 9
    //   180: aload 9
    //   182: instanceof 283
    //   185: ifeq +15 -> 200
    //   188: aload_0
    //   189: aload 9
    //   191: checkcast 283	com/sun/mail/imap/protocol/ENVELOPE
    //   194: putfield 66	com/sun/mail/imap/IMAPMessage:envelope	Lcom/sun/mail/imap/protocol/ENVELOPE;
    //   197: goto +104 -> 301
    //   200: aload 9
    //   202: instanceof 285
    //   205: ifeq +45 -> 250
    //   208: aload_0
    //   209: aload 9
    //   211: checkcast 285	com/sun/mail/imap/protocol/INTERNALDATE
    //   214: invokevirtual 289	com/sun/mail/imap/protocol/INTERNALDATE:getDate	()Ljava/util/Date;
    //   217: putfield 291	com/sun/mail/imap/IMAPMessage:receivedDate	Ljava/util/Date;
    //   220: goto +81 -> 301
    //   223: astore 6
    //   225: new 236	javax/mail/FolderClosedException
    //   228: dup
    //   229: aload_0
    //   230: getfield 412	com/sun/mail/imap/IMAPMessage:folder	Ljavax/mail/Folder;
    //   233: aload 6
    //   235: invokevirtual 239	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   238: invokespecial 242	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   241: athrow
    //   242: astore 6
    //   244: aload 5
    //   246: monitorexit
    //   247: aload 6
    //   249: athrow
    //   250: aload 9
    //   252: instanceof 293
    //   255: ifeq +46 -> 301
    //   258: aload_0
    //   259: aload 9
    //   261: checkcast 293	com/sun/mail/imap/protocol/RFC822SIZE
    //   264: getfield 294	com/sun/mail/imap/protocol/RFC822SIZE:size	I
    //   267: putfield 43	com/sun/mail/imap/IMAPMessage:size	I
    //   270: goto +31 -> 301
    //   273: astore 6
    //   275: aload_0
    //   276: invokevirtual 405	com/sun/mail/imap/IMAPMessage:forceCheckExpunged	()V
    //   279: new 136	javax/mail/MessagingException
    //   282: dup
    //   283: aload 6
    //   285: invokevirtual 243	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   288: aload 6
    //   290: invokespecial 246	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   293: athrow
    //   294: iload_1
    //   295: iconst_1
    //   296: iadd
    //   297: istore_1
    //   298: goto -239 -> 59
    //   301: iload_2
    //   302: iconst_1
    //   303: iadd
    //   304: istore_2
    //   305: goto -139 -> 166
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	308	0	this	IMAPMessage
    //   58	240	1	i	int
    //   165	140	2	j	int
    //   45	98	3	k	int
    //   162	8	4	m	int
    //   107	138	5	localObject2	Object
    //   35	39	6	localIMAPProtocol	IMAPProtocol
    //   223	11	6	localConnectionException	ConnectionException
    //   242	6	6	localObject3	Object
    //   273	16	6	localProtocolException	ProtocolException
    //   55	94	7	arrayOfResponse	Response[]
    //   155	18	8	localFetchResponse	FetchResponse
    //   178	82	9	localItem	com.sun.mail.imap.protocol.Item
    // Exception table:
    //   from	to	target	type
    //   2	8	107	finally
    //   16	31	107	finally
    //   89	107	107	finally
    //   247	250	107	finally
    //   31	57	223	com/sun/mail/iap/ConnectionException
    //   59	86	223	com/sun/mail/iap/ConnectionException
    //   121	145	223	com/sun/mail/iap/ConnectionException
    //   148	164	223	com/sun/mail/iap/ConnectionException
    //   172	197	223	com/sun/mail/iap/ConnectionException
    //   200	220	223	com/sun/mail/iap/ConnectionException
    //   250	270	223	com/sun/mail/iap/ConnectionException
    //   31	57	242	finally
    //   59	86	242	finally
    //   86	89	242	finally
    //   121	145	242	finally
    //   148	164	242	finally
    //   172	197	242	finally
    //   200	220	242	finally
    //   225	242	242	finally
    //   244	247	242	finally
    //   250	270	242	finally
    //   275	294	242	finally
    //   31	57	273	com/sun/mail/iap/ProtocolException
    //   59	86	273	com/sun/mail/iap/ProtocolException
    //   121	145	273	com/sun/mail/iap/ProtocolException
    //   148	164	273	com/sun/mail/iap/ProtocolException
    //   172	197	273	com/sun/mail/iap/ProtocolException
    //   200	220	273	com/sun/mail/iap/ProtocolException
    //   250	270	273	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  private void loadFlags()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 55	com/sun/mail/imap/IMAPMessage:flags	Ljavax/mail/Flags;
    //   6: astore_1
    //   7: aload_1
    //   8: ifnull +6 -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: aload_0
    //   15: invokevirtual 388	com/sun/mail/imap/IMAPMessage:getMessageCacheLock	()Ljava/lang/Object;
    //   18: astore_1
    //   19: aload_1
    //   20: monitorenter
    //   21: aload_0
    //   22: invokevirtual 392	com/sun/mail/imap/IMAPMessage:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   25: astore_2
    //   26: aload_0
    //   27: invokevirtual 395	com/sun/mail/imap/IMAPMessage:checkExpunged	()V
    //   30: aload_0
    //   31: aload_2
    //   32: aload_0
    //   33: invokevirtual 398	com/sun/mail/imap/IMAPMessage:getSequenceNumber	()I
    //   36: invokevirtual 430	com/sun/mail/imap/protocol/IMAPProtocol:fetchFlags	(I)Ljavax/mail/Flags;
    //   39: putfield 55	com/sun/mail/imap/IMAPMessage:flags	Ljavax/mail/Flags;
    //   42: aload_1
    //   43: monitorexit
    //   44: goto -33 -> 11
    //   47: astore_2
    //   48: aload_1
    //   49: monitorexit
    //   50: aload_2
    //   51: athrow
    //   52: astore_1
    //   53: aload_0
    //   54: monitorexit
    //   55: aload_1
    //   56: athrow
    //   57: astore_2
    //   58: new 236	javax/mail/FolderClosedException
    //   61: dup
    //   62: aload_0
    //   63: getfield 412	com/sun/mail/imap/IMAPMessage:folder	Ljavax/mail/Folder;
    //   66: aload_2
    //   67: invokevirtual 239	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   70: invokespecial 242	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   73: athrow
    //   74: astore_2
    //   75: aload_0
    //   76: invokevirtual 405	com/sun/mail/imap/IMAPMessage:forceCheckExpunged	()V
    //   79: new 136	javax/mail/MessagingException
    //   82: dup
    //   83: aload_2
    //   84: invokevirtual 243	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   87: aload_2
    //   88: invokespecial 246	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   91: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	92	0	this	IMAPMessage
    //   52	4	1	localObject2	Object
    //   25	7	2	localIMAPProtocol	IMAPProtocol
    //   47	4	2	localObject3	Object
    //   57	10	2	localConnectionException	ConnectionException
    //   74	14	2	localProtocolException	ProtocolException
    // Exception table:
    //   from	to	target	type
    //   21	42	47	finally
    //   42	44	47	finally
    //   48	50	47	finally
    //   58	74	47	finally
    //   75	92	47	finally
    //   2	7	52	finally
    //   14	21	52	finally
    //   50	52	52	finally
    //   21	42	57	com/sun/mail/iap/ConnectionException
    //   21	42	74	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  private void loadHeaders()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 49	com/sun/mail/imap/IMAPMessage:headersLoaded	Z
    //   6: istore_1
    //   7: iload_1
    //   8: ifeq +6 -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: aconst_null
    //   15: astore_2
    //   16: aload_0
    //   17: invokevirtual 388	com/sun/mail/imap/IMAPMessage:getMessageCacheLock	()Ljava/lang/Object;
    //   20: astore_3
    //   21: aload_3
    //   22: monitorenter
    //   23: aload_0
    //   24: invokevirtual 392	com/sun/mail/imap/IMAPMessage:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   27: astore 4
    //   29: aload_0
    //   30: invokevirtual 395	com/sun/mail/imap/IMAPMessage:checkExpunged	()V
    //   33: aload 4
    //   35: invokevirtual 109	com/sun/mail/imap/protocol/IMAPProtocol:isREV1	()Z
    //   38: ifeq +54 -> 92
    //   41: aload 4
    //   43: aload_0
    //   44: invokevirtual 398	com/sun/mail/imap/IMAPMessage:getSequenceNumber	()I
    //   47: aload_0
    //   48: ldc_w 433
    //   51: invokespecial 437	com/sun/mail/imap/IMAPMessage:toSection	(Ljava/lang/String;)Ljava/lang/String;
    //   54: invokevirtual 441	com/sun/mail/imap/protocol/IMAPProtocol:peekBody	(ILjava/lang/String;)Lcom/sun/mail/imap/protocol/BODY;
    //   57: astore 4
    //   59: aload 4
    //   61: ifnull +9 -> 70
    //   64: aload 4
    //   66: invokevirtual 338	com/sun/mail/imap/protocol/BODY:getByteArrayInputStream	()Ljava/io/ByteArrayInputStream;
    //   69: astore_2
    //   70: aload_3
    //   71: monitorexit
    //   72: aload_2
    //   73: ifnonnull +87 -> 160
    //   76: new 136	javax/mail/MessagingException
    //   79: dup
    //   80: ldc_w 443
    //   83: invokespecial 408	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   86: athrow
    //   87: astore_2
    //   88: aload_0
    //   89: monitorexit
    //   90: aload_2
    //   91: athrow
    //   92: aload 4
    //   94: aload_0
    //   95: invokevirtual 398	com/sun/mail/imap/IMAPMessage:getSequenceNumber	()I
    //   98: ldc_w 433
    //   101: invokevirtual 447	com/sun/mail/imap/protocol/IMAPProtocol:fetchRFC822	(ILjava/lang/String;)Lcom/sun/mail/imap/protocol/RFC822DATA;
    //   104: astore 4
    //   106: aload 4
    //   108: ifnull -38 -> 70
    //   111: aload 4
    //   113: invokevirtual 322	com/sun/mail/imap/protocol/RFC822DATA:getByteArrayInputStream	()Ljava/io/ByteArrayInputStream;
    //   116: astore_2
    //   117: goto -47 -> 70
    //   120: astore_2
    //   121: new 236	javax/mail/FolderClosedException
    //   124: dup
    //   125: aload_0
    //   126: getfield 412	com/sun/mail/imap/IMAPMessage:folder	Ljavax/mail/Folder;
    //   129: aload_2
    //   130: invokevirtual 239	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   133: invokespecial 242	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   136: athrow
    //   137: astore_2
    //   138: aload_3
    //   139: monitorexit
    //   140: aload_2
    //   141: athrow
    //   142: astore_2
    //   143: aload_0
    //   144: invokevirtual 405	com/sun/mail/imap/IMAPMessage:forceCheckExpunged	()V
    //   147: new 136	javax/mail/MessagingException
    //   150: dup
    //   151: aload_2
    //   152: invokevirtual 243	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   155: aload_2
    //   156: invokespecial 246	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   159: athrow
    //   160: aload_0
    //   161: new 324	javax/mail/internet/InternetHeaders
    //   164: dup
    //   165: aload_2
    //   166: invokespecial 449	javax/mail/internet/InternetHeaders:<init>	(Ljava/io/InputStream;)V
    //   169: putfield 333	com/sun/mail/imap/IMAPMessage:headers	Ljavax/mail/internet/InternetHeaders;
    //   172: aload_0
    //   173: iconst_1
    //   174: putfield 49	com/sun/mail/imap/IMAPMessage:headersLoaded	Z
    //   177: goto -166 -> 11
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	180	0	this	IMAPMessage
    //   6	2	1	bool	boolean
    //   15	58	2	localByteArrayInputStream1	ByteArrayInputStream
    //   87	4	2	localObject1	Object
    //   116	1	2	localByteArrayInputStream2	ByteArrayInputStream
    //   120	10	2	localConnectionException	ConnectionException
    //   137	4	2	localObject2	Object
    //   142	24	2	localProtocolException	ProtocolException
    //   27	85	4	localObject4	Object
    // Exception table:
    //   from	to	target	type
    //   2	7	87	finally
    //   16	23	87	finally
    //   76	87	87	finally
    //   140	142	87	finally
    //   160	177	87	finally
    //   23	59	120	com/sun/mail/iap/ConnectionException
    //   64	70	120	com/sun/mail/iap/ConnectionException
    //   92	106	120	com/sun/mail/iap/ConnectionException
    //   111	117	120	com/sun/mail/iap/ConnectionException
    //   23	59	137	finally
    //   64	70	137	finally
    //   70	72	137	finally
    //   92	106	137	finally
    //   111	117	137	finally
    //   121	137	137	finally
    //   138	140	137	finally
    //   143	160	137	finally
    //   23	59	142	com/sun/mail/iap/ProtocolException
    //   64	70	142	com/sun/mail/iap/ProtocolException
    //   92	106	142	com/sun/mail/iap/ProtocolException
    //   111	117	142	com/sun/mail/iap/ProtocolException
  }
  
  private void setHeaderLoaded(String paramString)
  {
    try
    {
      if (this.loadedHeaders == null) {
        this.loadedHeaders = new Hashtable(1);
      }
      this.loadedHeaders.put(paramString.toUpperCase(Locale.ENGLISH), paramString);
      return;
    }
    finally {}
  }
  
  private void setHeadersLoaded(boolean paramBoolean)
  {
    try
    {
      this.headersLoaded = paramBoolean;
      return;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  private String toSection(String paramString)
  {
    if (this.sectionId == null) {
      return paramString;
    }
    return this.sectionId + "." + paramString;
  }
  
  Session _getSession()
  {
    return this.session;
  }
  
  void _setFlags(Flags paramFlags)
  {
    this.flags = paramFlags;
  }
  
  public void addFrom(Address[] paramArrayOfAddress)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPMessage is read-only");
  }
  
  public void addHeader(String paramString1, String paramString2)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPMessage is read-only");
  }
  
  public void addHeaderLine(String paramString)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPMessage is read-only");
  }
  
  public void addRecipients(Message.RecipientType paramRecipientType, Address[] paramArrayOfAddress)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPMessage is read-only");
  }
  
  protected void checkExpunged()
    throws MessageRemovedException
  {
    if (this.expunged) {
      throw new MessageRemovedException();
    }
  }
  
  protected void forceCheckExpunged()
    throws MessageRemovedException, FolderClosedException
  {
    try
    {
      synchronized (getMessageCacheLock())
      {
        try
        {
          getProtocol().noop();
          if (this.expunged) {
            throw new MessageRemovedException();
          }
        }
        catch (ConnectionException localConnectionException)
        {
          throw new FolderClosedException(this.folder, localConnectionException.getMessage());
        }
      }
      return;
    }
    catch (ProtocolException localProtocolException)
    {
      for (;;) {}
    }
  }
  
  public Enumeration getAllHeaderLines()
    throws MessagingException
  {
    checkExpunged();
    loadHeaders();
    return super.getAllHeaderLines();
  }
  
  public Enumeration getAllHeaders()
    throws MessagingException
  {
    checkExpunged();
    loadHeaders();
    return super.getAllHeaders();
  }
  
  public String getContentID()
    throws MessagingException
  {
    checkExpunged();
    loadBODYSTRUCTURE();
    return this.bs.id;
  }
  
  public String[] getContentLanguage()
    throws MessagingException
  {
    checkExpunged();
    loadBODYSTRUCTURE();
    if (this.bs.language != null) {
      return (String[])this.bs.language.clone();
    }
    return null;
  }
  
  public String getContentMD5()
    throws MessagingException
  {
    checkExpunged();
    loadBODYSTRUCTURE();
    return this.bs.md5;
  }
  
  protected InputStream getContentStream()
    throws MessagingException
  {
    int i = -1;
    Object localObject1 = null;
    boolean bool = getPeek();
    try
    {
      synchronized (getMessageCacheLock())
      {
        try
        {
          Object localObject3 = getProtocol();
          checkExpunged();
          if ((((IMAPProtocol)localObject3).isREV1()) && (getFetchBlockSize() != -1))
          {
            localObject1 = toSection("TEXT");
            if (this.bs != null) {
              i = this.bs.size;
            }
            localObject1 = new IMAPInputStream(this, (String)localObject1, i, bool);
            return (InputStream)localObject1;
          }
          if (((IMAPProtocol)localObject3).isREV1()) {
            if (bool)
            {
              localObject3 = ((IMAPProtocol)localObject3).peekBody(getSequenceNumber(), toSection("TEXT"));
              if (localObject3 != null) {
                localObject1 = ((BODY)localObject3).getByteArrayInputStream();
              }
            }
          }
          for (;;)
          {
            if (localObject1 == null)
            {
              throw new MessagingException("No content");
              localObject3 = ((IMAPProtocol)localObject3).fetchBody(getSequenceNumber(), toSection("TEXT"));
              break;
              localObject3 = ((IMAPProtocol)localObject3).fetchRFC822(getSequenceNumber(), "TEXT");
              if (localObject3 != null)
              {
                localObject1 = ((RFC822DATA)localObject3).getByteArrayInputStream();
                continue;
                localObject2 = finally;
              }
            }
          }
        }
        catch (ConnectionException localConnectionException)
        {
          throw new FolderClosedException(this.folder, localConnectionException.getMessage());
        }
      }
      return localProtocolException;
    }
    catch (ProtocolException localProtocolException)
    {
      forceCheckExpunged();
      throw new MessagingException(localProtocolException.getMessage(), localProtocolException);
    }
  }
  
  public String getContentType()
    throws MessagingException
  {
    checkExpunged();
    if (this.type == null)
    {
      loadBODYSTRUCTURE();
      this.type = new ContentType(this.bs.type, this.bs.subtype, this.bs.cParams).toString();
    }
    return this.type;
  }
  
  public DataHandler getDataHandler()
    throws MessagingException
  {
    for (;;)
    {
      try
      {
        checkExpunged();
        Object localObject1;
        if (this.dh == null)
        {
          loadBODYSTRUCTURE();
          if (this.type == null) {
            this.type = new ContentType(this.bs.type, this.bs.subtype, this.bs.cParams).toString();
          }
          if (this.bs.isMulti()) {
            this.dh = new DataHandler(new IMAPMultipartDataSource(this, this.bs.bodies, this.sectionId, this));
          }
        }
        else
        {
          localObject1 = super.getDataHandler();
          return (DataHandler)localObject1;
        }
        if ((this.bs.isNested()) && (isREV1()))
        {
          BODYSTRUCTURE localBODYSTRUCTURE = this.bs.bodies[0];
          ENVELOPE localENVELOPE = this.bs.envelope;
          if (this.sectionId == null)
          {
            localObject1 = "1";
            this.dh = new DataHandler(new IMAPNestedMessage(this, localBODYSTRUCTURE, localENVELOPE, (String)localObject1), this.type);
          }
          else
          {
            String str = this.sectionId + ".1";
          }
        }
      }
      finally {}
    }
  }
  
  public String getDescription()
    throws MessagingException
  {
    checkExpunged();
    if (this.description != null) {
      return this.description;
    }
    loadBODYSTRUCTURE();
    if (this.bs.description == null) {
      return null;
    }
    try
    {
      this.description = MimeUtility.decodeText(this.bs.description);
      return this.description;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      for (;;)
      {
        this.description = this.bs.description;
      }
    }
  }
  
  public String getDisposition()
    throws MessagingException
  {
    checkExpunged();
    loadBODYSTRUCTURE();
    return this.bs.disposition;
  }
  
  public String getEncoding()
    throws MessagingException
  {
    checkExpunged();
    loadBODYSTRUCTURE();
    return this.bs.encoding;
  }
  
  protected int getFetchBlockSize()
  {
    return ((IMAPStore)this.folder.getStore()).getFetchBlockSize();
  }
  
  public String getFileName()
    throws MessagingException
  {
    checkExpunged();
    String str1 = null;
    loadBODYSTRUCTURE();
    if (this.bs.dParams != null) {
      str1 = this.bs.dParams.get("filename");
    }
    String str2 = str1;
    if (str1 == null)
    {
      str2 = str1;
      if (this.bs.cParams != null) {
        str2 = this.bs.cParams.get("name");
      }
    }
    return str2;
  }
  
  public Flags getFlags()
    throws MessagingException
  {
    try
    {
      checkExpunged();
      loadFlags();
      Flags localFlags = super.getFlags();
      return localFlags;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public Address[] getFrom()
    throws MessagingException
  {
    checkExpunged();
    loadEnvelope();
    return aaclone(this.envelope.from);
  }
  
  public String getHeader(String paramString1, String paramString2)
    throws MessagingException
  {
    checkExpunged();
    if (getHeader(paramString1) == null) {
      return null;
    }
    return this.headers.getHeader(paramString1, paramString2);
  }
  
  public String[] getHeader(String paramString)
    throws MessagingException
  {
    checkExpunged();
    if (isHeaderLoaded(paramString)) {
      return this.headers.getHeader(paramString);
    }
    ByteArrayInputStream localByteArrayInputStream = null;
    try
    {
      synchronized (getMessageCacheLock())
      {
        try
        {
          Object localObject2 = getProtocol();
          checkExpunged();
          if (((IMAPProtocol)localObject2).isREV1())
          {
            localObject2 = ((IMAPProtocol)localObject2).peekBody(getSequenceNumber(), toSection("HEADER.FIELDS (" + paramString + ")"));
            if (localObject2 != null) {
              localByteArrayInputStream = ((BODY)localObject2).getByteArrayInputStream();
            }
          }
          while (localByteArrayInputStream == null)
          {
            return null;
            localObject2 = ((IMAPProtocol)localObject2).fetchRFC822(getSequenceNumber(), "HEADER.LINES (" + paramString + ")");
            if (localObject2 != null)
            {
              localByteArrayInputStream = ((RFC822DATA)localObject2).getByteArrayInputStream();
              continue;
              paramString = finally;
            }
          }
        }
        catch (ConnectionException paramString)
        {
          throw new FolderClosedException(this.folder, paramString.getMessage());
        }
      }
      if (this.headers != null) {
        break label209;
      }
    }
    catch (ProtocolException paramString)
    {
      forceCheckExpunged();
      throw new MessagingException(paramString.getMessage(), paramString);
    }
    this.headers = new InternetHeaders();
    label209:
    this.headers.load(localByteArrayInputStream);
    setHeaderLoaded(paramString);
    return this.headers.getHeader(paramString);
  }
  
  public String getInReplyTo()
    throws MessagingException
  {
    checkExpunged();
    loadEnvelope();
    return this.envelope.inReplyTo;
  }
  
  public int getLineCount()
    throws MessagingException
  {
    checkExpunged();
    loadBODYSTRUCTURE();
    return this.bs.lines;
  }
  
  public Enumeration getMatchingHeaderLines(String[] paramArrayOfString)
    throws MessagingException
  {
    checkExpunged();
    loadHeaders();
    return super.getMatchingHeaderLines(paramArrayOfString);
  }
  
  public Enumeration getMatchingHeaders(String[] paramArrayOfString)
    throws MessagingException
  {
    checkExpunged();
    loadHeaders();
    return super.getMatchingHeaders(paramArrayOfString);
  }
  
  protected Object getMessageCacheLock()
  {
    return ((IMAPFolder)this.folder).messageCacheLock;
  }
  
  public String getMessageID()
    throws MessagingException
  {
    checkExpunged();
    loadEnvelope();
    return this.envelope.messageId;
  }
  
  public Enumeration getNonMatchingHeaderLines(String[] paramArrayOfString)
    throws MessagingException
  {
    checkExpunged();
    loadHeaders();
    return super.getNonMatchingHeaderLines(paramArrayOfString);
  }
  
  public Enumeration getNonMatchingHeaders(String[] paramArrayOfString)
    throws MessagingException
  {
    checkExpunged();
    loadHeaders();
    return super.getNonMatchingHeaders(paramArrayOfString);
  }
  
  public boolean getPeek()
  {
    try
    {
      boolean bool = this.peek;
      return bool;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  protected IMAPProtocol getProtocol()
    throws ProtocolException, FolderClosedException
  {
    ((IMAPFolder)this.folder).waitIfIdle();
    IMAPProtocol localIMAPProtocol = ((IMAPFolder)this.folder).protocol;
    if (localIMAPProtocol == null) {
      throw new FolderClosedException(this.folder);
    }
    return localIMAPProtocol;
  }
  
  public Date getReceivedDate()
    throws MessagingException
  {
    checkExpunged();
    loadEnvelope();
    if (this.receivedDate == null) {
      return null;
    }
    return new Date(this.receivedDate.getTime());
  }
  
  public Address[] getRecipients(Message.RecipientType paramRecipientType)
    throws MessagingException
  {
    checkExpunged();
    loadEnvelope();
    if (paramRecipientType == Message.RecipientType.TO) {
      return aaclone(this.envelope.to);
    }
    if (paramRecipientType == Message.RecipientType.CC) {
      return aaclone(this.envelope.cc);
    }
    if (paramRecipientType == Message.RecipientType.BCC) {
      return aaclone(this.envelope.bcc);
    }
    return super.getRecipients(paramRecipientType);
  }
  
  public Address[] getReplyTo()
    throws MessagingException
  {
    checkExpunged();
    loadEnvelope();
    return aaclone(this.envelope.replyTo);
  }
  
  public Address getSender()
    throws MessagingException
  {
    checkExpunged();
    loadEnvelope();
    if (this.envelope.sender != null) {
      return this.envelope.sender[0];
    }
    return null;
  }
  
  public Date getSentDate()
    throws MessagingException
  {
    checkExpunged();
    loadEnvelope();
    if (this.envelope.date == null) {
      return null;
    }
    return new Date(this.envelope.date.getTime());
  }
  
  protected int getSequenceNumber()
  {
    return this.seqnum;
  }
  
  public int getSize()
    throws MessagingException
  {
    checkExpunged();
    if (this.size == -1) {
      loadEnvelope();
    }
    return this.size;
  }
  
  public String getSubject()
    throws MessagingException
  {
    checkExpunged();
    if (this.subject != null) {
      return this.subject;
    }
    loadEnvelope();
    if (this.envelope.subject == null) {
      return null;
    }
    try
    {
      this.subject = MimeUtility.decodeText(this.envelope.subject);
      return this.subject;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      for (;;)
      {
        this.subject = this.envelope.subject;
      }
    }
  }
  
  protected long getUID()
  {
    return this.uid;
  }
  
  public void invalidateHeaders()
  {
    try
    {
      this.headersLoaded = false;
      this.loadedHeaders = null;
      this.envelope = null;
      this.bs = null;
      this.receivedDate = null;
      this.size = -1;
      this.type = null;
      this.subject = null;
      this.description = null;
      return;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  protected boolean isREV1()
    throws FolderClosedException
  {
    IMAPProtocol localIMAPProtocol = ((IMAPFolder)this.folder).protocol;
    if (localIMAPProtocol == null) {
      throw new FolderClosedException(this.folder);
    }
    return localIMAPProtocol.isREV1();
  }
  
  public boolean isSet(Flags.Flag paramFlag)
    throws MessagingException
  {
    try
    {
      checkExpunged();
      loadFlags();
      boolean bool = super.isSet(paramFlag);
      return bool;
    }
    finally
    {
      paramFlag = finally;
      throw paramFlag;
    }
  }
  
  public void removeHeader(String paramString)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPMessage is read-only");
  }
  
  public void setContentID(String paramString)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPMessage is read-only");
  }
  
  public void setContentLanguage(String[] paramArrayOfString)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPMessage is read-only");
  }
  
  public void setContentMD5(String paramString)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPMessage is read-only");
  }
  
  public void setDataHandler(DataHandler paramDataHandler)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPMessage is read-only");
  }
  
  public void setDescription(String paramString1, String paramString2)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPMessage is read-only");
  }
  
  public void setDisposition(String paramString)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPMessage is read-only");
  }
  
  protected void setExpunged(boolean paramBoolean)
  {
    super.setExpunged(paramBoolean);
    this.seqnum = -1;
  }
  
  public void setFileName(String paramString)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPMessage is read-only");
  }
  
  /* Error */
  public void setFlags(Flags paramFlags, boolean paramBoolean)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual 388	com/sun/mail/imap/IMAPMessage:getMessageCacheLock	()Ljava/lang/Object;
    //   6: astore_3
    //   7: aload_3
    //   8: monitorenter
    //   9: aload_0
    //   10: invokevirtual 392	com/sun/mail/imap/IMAPMessage:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   13: astore 4
    //   15: aload_0
    //   16: invokevirtual 395	com/sun/mail/imap/IMAPMessage:checkExpunged	()V
    //   19: aload 4
    //   21: aload_0
    //   22: invokevirtual 398	com/sun/mail/imap/IMAPMessage:getSequenceNumber	()I
    //   25: aload_1
    //   26: iload_2
    //   27: invokevirtual 771	com/sun/mail/imap/protocol/IMAPProtocol:storeFlags	(ILjavax/mail/Flags;Z)V
    //   30: aload_3
    //   31: monitorexit
    //   32: aload_0
    //   33: monitorexit
    //   34: return
    //   35: astore_1
    //   36: new 236	javax/mail/FolderClosedException
    //   39: dup
    //   40: aload_0
    //   41: getfield 412	com/sun/mail/imap/IMAPMessage:folder	Ljavax/mail/Folder;
    //   44: aload_1
    //   45: invokevirtual 239	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   48: invokespecial 242	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   51: athrow
    //   52: astore_1
    //   53: aload_3
    //   54: monitorexit
    //   55: aload_1
    //   56: athrow
    //   57: astore_1
    //   58: aload_0
    //   59: monitorexit
    //   60: aload_1
    //   61: athrow
    //   62: astore_1
    //   63: new 136	javax/mail/MessagingException
    //   66: dup
    //   67: aload_1
    //   68: invokevirtual 243	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   71: aload_1
    //   72: invokespecial 246	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   75: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	76	0	this	IMAPMessage
    //   0	76	1	paramFlags	Flags
    //   0	76	2	paramBoolean	boolean
    //   13	7	4	localIMAPProtocol	IMAPProtocol
    // Exception table:
    //   from	to	target	type
    //   9	30	35	com/sun/mail/iap/ConnectionException
    //   9	30	52	finally
    //   30	32	52	finally
    //   36	52	52	finally
    //   53	55	52	finally
    //   63	76	52	finally
    //   2	9	57	finally
    //   55	57	57	finally
    //   9	30	62	com/sun/mail/iap/ProtocolException
  }
  
  public void setFrom(Address paramAddress)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPMessage is read-only");
  }
  
  public void setHeader(String paramString1, String paramString2)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPMessage is read-only");
  }
  
  protected void setMessageNumber(int paramInt)
  {
    super.setMessageNumber(paramInt);
  }
  
  public void setPeek(boolean paramBoolean)
  {
    try
    {
      this.peek = paramBoolean;
      return;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public void setRecipients(Message.RecipientType paramRecipientType, Address[] paramArrayOfAddress)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPMessage is read-only");
  }
  
  public void setReplyTo(Address[] paramArrayOfAddress)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPMessage is read-only");
  }
  
  public void setSender(Address paramAddress)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPMessage is read-only");
  }
  
  public void setSentDate(Date paramDate)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPMessage is read-only");
  }
  
  protected void setSequenceNumber(int paramInt)
  {
    this.seqnum = paramInt;
  }
  
  public void setSubject(String paramString1, String paramString2)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPMessage is read-only");
  }
  
  protected void setUID(long paramLong)
  {
    this.uid = paramLong;
  }
  
  public void writeTo(OutputStream paramOutputStream)
    throws IOException, MessagingException
  {
    ByteArrayInputStream localByteArrayInputStream = null;
    boolean bool = getPeek();
    Object localObject1;
    try
    {
      synchronized (getMessageCacheLock())
      {
        try
        {
          localObject1 = getProtocol();
          checkExpunged();
          if (((IMAPProtocol)localObject1).isREV1()) {
            if (bool)
            {
              localObject1 = ((IMAPProtocol)localObject1).peekBody(getSequenceNumber(), this.sectionId);
              if (localObject1 != null) {
                localByteArrayInputStream = ((BODY)localObject1).getByteArrayInputStream();
              }
            }
          }
          for (;;)
          {
            if (localByteArrayInputStream == null)
            {
              throw new MessagingException("No content");
              localObject1 = ((IMAPProtocol)localObject1).fetchBody(getSequenceNumber(), this.sectionId);
              break;
              localObject1 = ((IMAPProtocol)localObject1).fetchRFC822(getSequenceNumber(), null);
              if (localObject1 != null)
              {
                localByteArrayInputStream = ((RFC822DATA)localObject1).getByteArrayInputStream();
                continue;
                paramOutputStream = finally;
              }
            }
          }
        }
        catch (ConnectionException paramOutputStream)
        {
          throw new FolderClosedException(this.folder, paramOutputStream.getMessage());
        }
      }
      localObject1 = new byte['Ѐ'];
    }
    catch (ProtocolException paramOutputStream)
    {
      forceCheckExpunged();
      throw new MessagingException(paramOutputStream.getMessage(), paramOutputStream);
    }
    for (;;)
    {
      int i = localByteArrayInputStream.read((byte[])localObject1);
      if (i == -1) {
        return;
      }
      paramOutputStream.write((byte[])localObject1, 0, i);
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/IMAPMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */