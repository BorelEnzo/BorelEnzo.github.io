package com.sun.mail.imap;

import java.io.IOException;
import java.io.OutputStream;

class LengthCounter
  extends OutputStream
{
  private byte[] buf = new byte[' '];
  private int maxsize;
  private int size = 0;
  
  public LengthCounter(int paramInt)
  {
    this.maxsize = paramInt;
  }
  
  public byte[] getBytes()
  {
    return this.buf;
  }
  
  public int getSize()
  {
    return this.size;
  }
  
  public void write(int paramInt)
  {
    int i = this.size + 1;
    if (this.buf != null)
    {
      if ((i <= this.maxsize) || (this.maxsize < 0)) {
        break label40;
      }
      this.buf = null;
    }
    for (;;)
    {
      this.size = i;
      return;
      label40:
      if (i > this.buf.length)
      {
        byte[] arrayOfByte = new byte[Math.max(this.buf.length << 1, i)];
        System.arraycopy(this.buf, 0, arrayOfByte, 0, this.size);
        this.buf = arrayOfByte;
        this.buf[this.size] = ((byte)paramInt);
      }
      else
      {
        this.buf[this.size] = ((byte)paramInt);
      }
    }
  }
  
  public void write(byte[] paramArrayOfByte)
    throws IOException
  {
    write(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    if ((paramInt1 < 0) || (paramInt1 > paramArrayOfByte.length) || (paramInt2 < 0) || (paramInt1 + paramInt2 > paramArrayOfByte.length) || (paramInt1 + paramInt2 < 0)) {
      throw new IndexOutOfBoundsException();
    }
    if (paramInt2 == 0) {
      return;
    }
    int i = this.size + paramInt2;
    if (this.buf != null)
    {
      if ((i <= this.maxsize) || (this.maxsize < 0)) {
        break label84;
      }
      this.buf = null;
    }
    for (;;)
    {
      this.size = i;
      return;
      label84:
      if (i > this.buf.length)
      {
        byte[] arrayOfByte = new byte[Math.max(this.buf.length << 1, i)];
        System.arraycopy(this.buf, 0, arrayOfByte, 0, this.size);
        this.buf = arrayOfByte;
        System.arraycopy(paramArrayOfByte, paramInt1, this.buf, this.size, paramInt2);
      }
      else
      {
        System.arraycopy(paramArrayOfByte, paramInt1, this.buf, this.size, paramInt2);
      }
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/LengthCounter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */