package com.sun.mail.imap;

import com.sun.mail.iap.ConnectionException;
import com.sun.mail.iap.ProtocolException;
import com.sun.mail.imap.protocol.BODY;
import com.sun.mail.imap.protocol.BODYSTRUCTURE;
import com.sun.mail.imap.protocol.IMAPProtocol;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import javax.activation.DataHandler;
import javax.mail.FolderClosedException;
import javax.mail.IllegalWriteException;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.ContentType;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeUtility;
import javax.mail.internet.ParameterList;

public class IMAPBodyPart
  extends MimeBodyPart
{
  private BODYSTRUCTURE bs;
  private String description;
  private boolean headersLoaded = false;
  private IMAPMessage message;
  private String sectionId;
  private String type;
  
  protected IMAPBodyPart(BODYSTRUCTURE paramBODYSTRUCTURE, String paramString, IMAPMessage paramIMAPMessage)
  {
    this.bs = paramBODYSTRUCTURE;
    this.sectionId = paramString;
    this.message = paramIMAPMessage;
    this.type = new ContentType(paramBODYSTRUCTURE.type, paramBODYSTRUCTURE.subtype, paramBODYSTRUCTURE.cParams).toString();
  }
  
  /* Error */
  private void loadHeaders()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 21	com/sun/mail/imap/IMAPBodyPart:headersLoaded	Z
    //   6: istore_1
    //   7: iload_1
    //   8: ifeq +6 -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: aload_0
    //   15: getfield 60	com/sun/mail/imap/IMAPBodyPart:headers	Ljavax/mail/internet/InternetHeaders;
    //   18: ifnonnull +14 -> 32
    //   21: aload_0
    //   22: new 62	javax/mail/internet/InternetHeaders
    //   25: dup
    //   26: invokespecial 63	javax/mail/internet/InternetHeaders:<init>	()V
    //   29: putfield 60	com/sun/mail/imap/IMAPBodyPart:headers	Ljavax/mail/internet/InternetHeaders;
    //   32: aload_0
    //   33: getfield 27	com/sun/mail/imap/IMAPBodyPart:message	Lcom/sun/mail/imap/IMAPMessage;
    //   36: invokevirtual 69	com/sun/mail/imap/IMAPMessage:getMessageCacheLock	()Ljava/lang/Object;
    //   39: astore_2
    //   40: aload_2
    //   41: monitorenter
    //   42: aload_0
    //   43: getfield 27	com/sun/mail/imap/IMAPBodyPart:message	Lcom/sun/mail/imap/IMAPMessage;
    //   46: invokevirtual 73	com/sun/mail/imap/IMAPMessage:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   49: astore_3
    //   50: aload_0
    //   51: getfield 27	com/sun/mail/imap/IMAPBodyPart:message	Lcom/sun/mail/imap/IMAPMessage;
    //   54: invokevirtual 76	com/sun/mail/imap/IMAPMessage:checkExpunged	()V
    //   57: aload_3
    //   58: invokevirtual 82	com/sun/mail/imap/protocol/IMAPProtocol:isREV1	()Z
    //   61: ifeq +132 -> 193
    //   64: aload_3
    //   65: aload_0
    //   66: getfield 27	com/sun/mail/imap/IMAPBodyPart:message	Lcom/sun/mail/imap/IMAPMessage;
    //   69: invokevirtual 86	com/sun/mail/imap/IMAPMessage:getSequenceNumber	()I
    //   72: new 88	java/lang/StringBuilder
    //   75: dup
    //   76: aload_0
    //   77: getfield 25	com/sun/mail/imap/IMAPBodyPart:sectionId	Ljava/lang/String;
    //   80: invokestatic 94	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   83: invokespecial 97	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   86: ldc 99
    //   88: invokevirtual 103	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   91: invokevirtual 104	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   94: invokevirtual 108	com/sun/mail/imap/protocol/IMAPProtocol:peekBody	(ILjava/lang/String;)Lcom/sun/mail/imap/protocol/BODY;
    //   97: astore_3
    //   98: aload_3
    //   99: ifnonnull +43 -> 142
    //   102: new 52	javax/mail/MessagingException
    //   105: dup
    //   106: ldc 110
    //   108: invokespecial 111	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   111: athrow
    //   112: astore_3
    //   113: new 113	javax/mail/FolderClosedException
    //   116: dup
    //   117: aload_0
    //   118: getfield 27	com/sun/mail/imap/IMAPBodyPart:message	Lcom/sun/mail/imap/IMAPMessage;
    //   121: invokevirtual 117	com/sun/mail/imap/IMAPMessage:getFolder	()Ljavax/mail/Folder;
    //   124: aload_3
    //   125: invokevirtual 120	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   128: invokespecial 123	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   131: athrow
    //   132: astore_3
    //   133: aload_2
    //   134: monitorexit
    //   135: aload_3
    //   136: athrow
    //   137: astore_2
    //   138: aload_0
    //   139: monitorexit
    //   140: aload_2
    //   141: athrow
    //   142: aload_3
    //   143: invokevirtual 129	com/sun/mail/imap/protocol/BODY:getByteArrayInputStream	()Ljava/io/ByteArrayInputStream;
    //   146: astore_3
    //   147: aload_3
    //   148: ifnonnull +27 -> 175
    //   151: new 52	javax/mail/MessagingException
    //   154: dup
    //   155: ldc 110
    //   157: invokespecial 111	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   160: athrow
    //   161: astore_3
    //   162: new 52	javax/mail/MessagingException
    //   165: dup
    //   166: aload_3
    //   167: invokevirtual 130	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   170: aload_3
    //   171: invokespecial 133	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   174: athrow
    //   175: aload_0
    //   176: getfield 60	com/sun/mail/imap/IMAPBodyPart:headers	Ljavax/mail/internet/InternetHeaders;
    //   179: aload_3
    //   180: invokevirtual 137	javax/mail/internet/InternetHeaders:load	(Ljava/io/InputStream;)V
    //   183: aload_2
    //   184: monitorexit
    //   185: aload_0
    //   186: iconst_1
    //   187: putfield 21	com/sun/mail/imap/IMAPBodyPart:headersLoaded	Z
    //   190: goto -179 -> 11
    //   193: aload_0
    //   194: getfield 60	com/sun/mail/imap/IMAPBodyPart:headers	Ljavax/mail/internet/InternetHeaders;
    //   197: ldc -117
    //   199: aload_0
    //   200: getfield 48	com/sun/mail/imap/IMAPBodyPart:type	Ljava/lang/String;
    //   203: invokevirtual 143	javax/mail/internet/InternetHeaders:addHeader	(Ljava/lang/String;Ljava/lang/String;)V
    //   206: aload_0
    //   207: getfield 60	com/sun/mail/imap/IMAPBodyPart:headers	Ljavax/mail/internet/InternetHeaders;
    //   210: ldc -111
    //   212: aload_0
    //   213: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   216: getfield 148	com/sun/mail/imap/protocol/BODYSTRUCTURE:encoding	Ljava/lang/String;
    //   219: invokevirtual 143	javax/mail/internet/InternetHeaders:addHeader	(Ljava/lang/String;Ljava/lang/String;)V
    //   222: aload_0
    //   223: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   226: getfield 150	com/sun/mail/imap/protocol/BODYSTRUCTURE:description	Ljava/lang/String;
    //   229: ifnull +19 -> 248
    //   232: aload_0
    //   233: getfield 60	com/sun/mail/imap/IMAPBodyPart:headers	Ljavax/mail/internet/InternetHeaders;
    //   236: ldc -104
    //   238: aload_0
    //   239: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   242: getfield 150	com/sun/mail/imap/protocol/BODYSTRUCTURE:description	Ljava/lang/String;
    //   245: invokevirtual 143	javax/mail/internet/InternetHeaders:addHeader	(Ljava/lang/String;Ljava/lang/String;)V
    //   248: aload_0
    //   249: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   252: getfield 155	com/sun/mail/imap/protocol/BODYSTRUCTURE:id	Ljava/lang/String;
    //   255: ifnull +19 -> 274
    //   258: aload_0
    //   259: getfield 60	com/sun/mail/imap/IMAPBodyPart:headers	Ljavax/mail/internet/InternetHeaders;
    //   262: ldc -99
    //   264: aload_0
    //   265: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   268: getfield 155	com/sun/mail/imap/protocol/BODYSTRUCTURE:id	Ljava/lang/String;
    //   271: invokevirtual 143	javax/mail/internet/InternetHeaders:addHeader	(Ljava/lang/String;Ljava/lang/String;)V
    //   274: aload_0
    //   275: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   278: getfield 160	com/sun/mail/imap/protocol/BODYSTRUCTURE:md5	Ljava/lang/String;
    //   281: ifnull -98 -> 183
    //   284: aload_0
    //   285: getfield 60	com/sun/mail/imap/IMAPBodyPart:headers	Ljavax/mail/internet/InternetHeaders;
    //   288: ldc -94
    //   290: aload_0
    //   291: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   294: getfield 160	com/sun/mail/imap/protocol/BODYSTRUCTURE:md5	Ljava/lang/String;
    //   297: invokevirtual 143	javax/mail/internet/InternetHeaders:addHeader	(Ljava/lang/String;Ljava/lang/String;)V
    //   300: goto -117 -> 183
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	303	0	this	IMAPBodyPart
    //   6	2	1	bool	boolean
    //   137	47	2	localObject2	Object
    //   49	50	3	localObject3	Object
    //   112	13	3	localConnectionException	ConnectionException
    //   132	11	3	localObject4	Object
    //   146	2	3	localByteArrayInputStream	ByteArrayInputStream
    //   161	19	3	localProtocolException	ProtocolException
    // Exception table:
    //   from	to	target	type
    //   42	98	112	com/sun/mail/iap/ConnectionException
    //   102	112	112	com/sun/mail/iap/ConnectionException
    //   142	147	112	com/sun/mail/iap/ConnectionException
    //   151	161	112	com/sun/mail/iap/ConnectionException
    //   175	183	112	com/sun/mail/iap/ConnectionException
    //   193	248	112	com/sun/mail/iap/ConnectionException
    //   248	274	112	com/sun/mail/iap/ConnectionException
    //   274	300	112	com/sun/mail/iap/ConnectionException
    //   42	98	132	finally
    //   102	112	132	finally
    //   113	132	132	finally
    //   133	135	132	finally
    //   142	147	132	finally
    //   151	161	132	finally
    //   162	175	132	finally
    //   175	183	132	finally
    //   183	185	132	finally
    //   193	248	132	finally
    //   248	274	132	finally
    //   274	300	132	finally
    //   2	7	137	finally
    //   14	32	137	finally
    //   32	42	137	finally
    //   135	137	137	finally
    //   185	190	137	finally
    //   42	98	161	com/sun/mail/iap/ProtocolException
    //   102	112	161	com/sun/mail/iap/ProtocolException
    //   142	147	161	com/sun/mail/iap/ProtocolException
    //   151	161	161	com/sun/mail/iap/ProtocolException
    //   175	183	161	com/sun/mail/iap/ProtocolException
    //   193	248	161	com/sun/mail/iap/ProtocolException
    //   248	274	161	com/sun/mail/iap/ProtocolException
    //   274	300	161	com/sun/mail/iap/ProtocolException
  }
  
  public void addHeader(String paramString1, String paramString2)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPBodyPart is read-only");
  }
  
  public void addHeaderLine(String paramString)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPBodyPart is read-only");
  }
  
  public Enumeration getAllHeaderLines()
    throws MessagingException
  {
    loadHeaders();
    return super.getAllHeaderLines();
  }
  
  public Enumeration getAllHeaders()
    throws MessagingException
  {
    loadHeaders();
    return super.getAllHeaders();
  }
  
  public String getContentID()
    throws MessagingException
  {
    return this.bs.id;
  }
  
  public String getContentMD5()
    throws MessagingException
  {
    return this.bs.md5;
  }
  
  protected InputStream getContentStream()
    throws MessagingException
  {
    localByteArrayInputStream = null;
    boolean bool = this.message.getPeek();
    try
    {
      synchronized (this.message.getMessageCacheLock())
      {
        try
        {
          Object localObject1 = this.message.getProtocol();
          this.message.checkExpunged();
          if ((((IMAPProtocol)localObject1).isREV1()) && (this.message.getFetchBlockSize() != -1))
          {
            localObject1 = new IMAPInputStream(this.message, this.sectionId, this.bs.size, bool);
            return (InputStream)localObject1;
          }
          int i = this.message.getSequenceNumber();
          if (bool) {}
          for (localObject1 = ((IMAPProtocol)localObject1).peekBody(i, this.sectionId);; localObject1 = ((IMAPProtocol)localObject1).fetchBody(i, this.sectionId))
          {
            if (localObject1 != null) {
              localByteArrayInputStream = ((BODY)localObject1).getByteArrayInputStream();
            }
            if (localByteArrayInputStream != null) {
              break;
            }
            throw new MessagingException("No content");
          }
          localObject2 = finally;
        }
        catch (ConnectionException localConnectionException)
        {
          throw new FolderClosedException(this.message.getFolder(), localConnectionException.getMessage());
        }
      }
      return localByteArrayInputStream;
    }
    catch (ProtocolException localProtocolException)
    {
      throw new MessagingException(localProtocolException.getMessage(), localProtocolException);
    }
  }
  
  public String getContentType()
    throws MessagingException
  {
    return this.type;
  }
  
  /* Error */
  public DataHandler getDataHandler()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 209	com/sun/mail/imap/IMAPBodyPart:dh	Ljavax/activation/DataHandler;
    //   6: ifnonnull +47 -> 53
    //   9: aload_0
    //   10: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   13: invokevirtual 212	com/sun/mail/imap/protocol/BODYSTRUCTURE:isMulti	()Z
    //   16: ifeq +46 -> 62
    //   19: aload_0
    //   20: new 214	javax/activation/DataHandler
    //   23: dup
    //   24: new 216	com/sun/mail/imap/IMAPMultipartDataSource
    //   27: dup
    //   28: aload_0
    //   29: aload_0
    //   30: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   33: getfield 220	com/sun/mail/imap/protocol/BODYSTRUCTURE:bodies	[Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   36: aload_0
    //   37: getfield 25	com/sun/mail/imap/IMAPBodyPart:sectionId	Ljava/lang/String;
    //   40: aload_0
    //   41: getfield 27	com/sun/mail/imap/IMAPBodyPart:message	Lcom/sun/mail/imap/IMAPMessage;
    //   44: invokespecial 223	com/sun/mail/imap/IMAPMultipartDataSource:<init>	(Ljavax/mail/internet/MimePart;[Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;Ljava/lang/String;Lcom/sun/mail/imap/IMAPMessage;)V
    //   47: invokespecial 226	javax/activation/DataHandler:<init>	(Ljavax/activation/DataSource;)V
    //   50: putfield 209	com/sun/mail/imap/IMAPBodyPart:dh	Ljavax/activation/DataHandler;
    //   53: aload_0
    //   54: invokespecial 228	javax/mail/internet/MimeBodyPart:getDataHandler	()Ljavax/activation/DataHandler;
    //   57: astore_1
    //   58: aload_0
    //   59: monitorexit
    //   60: aload_1
    //   61: areturn
    //   62: aload_0
    //   63: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   66: invokevirtual 231	com/sun/mail/imap/protocol/BODYSTRUCTURE:isNested	()Z
    //   69: ifeq -16 -> 53
    //   72: aload_0
    //   73: getfield 27	com/sun/mail/imap/IMAPBodyPart:message	Lcom/sun/mail/imap/IMAPMessage;
    //   76: invokevirtual 232	com/sun/mail/imap/IMAPMessage:isREV1	()Z
    //   79: ifeq -26 -> 53
    //   82: aload_0
    //   83: new 214	javax/activation/DataHandler
    //   86: dup
    //   87: new 234	com/sun/mail/imap/IMAPNestedMessage
    //   90: dup
    //   91: aload_0
    //   92: getfield 27	com/sun/mail/imap/IMAPBodyPart:message	Lcom/sun/mail/imap/IMAPMessage;
    //   95: aload_0
    //   96: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   99: getfield 220	com/sun/mail/imap/protocol/BODYSTRUCTURE:bodies	[Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   102: iconst_0
    //   103: aaload
    //   104: aload_0
    //   105: getfield 23	com/sun/mail/imap/IMAPBodyPart:bs	Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;
    //   108: getfield 238	com/sun/mail/imap/protocol/BODYSTRUCTURE:envelope	Lcom/sun/mail/imap/protocol/ENVELOPE;
    //   111: aload_0
    //   112: getfield 25	com/sun/mail/imap/IMAPBodyPart:sectionId	Ljava/lang/String;
    //   115: invokespecial 241	com/sun/mail/imap/IMAPNestedMessage:<init>	(Lcom/sun/mail/imap/IMAPMessage;Lcom/sun/mail/imap/protocol/BODYSTRUCTURE;Lcom/sun/mail/imap/protocol/ENVELOPE;Ljava/lang/String;)V
    //   118: aload_0
    //   119: getfield 48	com/sun/mail/imap/IMAPBodyPart:type	Ljava/lang/String;
    //   122: invokespecial 244	javax/activation/DataHandler:<init>	(Ljava/lang/Object;Ljava/lang/String;)V
    //   125: putfield 209	com/sun/mail/imap/IMAPBodyPart:dh	Ljavax/activation/DataHandler;
    //   128: goto -75 -> 53
    //   131: astore_1
    //   132: aload_0
    //   133: monitorexit
    //   134: aload_1
    //   135: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	136	0	this	IMAPBodyPart
    //   57	4	1	localDataHandler	DataHandler
    //   131	4	1	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   2	53	131	finally
    //   53	58	131	finally
    //   62	128	131	finally
  }
  
  public String getDescription()
    throws MessagingException
  {
    if (this.description != null) {
      return this.description;
    }
    if (this.bs.description == null) {
      return null;
    }
    try
    {
      this.description = MimeUtility.decodeText(this.bs.description);
      return this.description;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      for (;;)
      {
        this.description = this.bs.description;
      }
    }
  }
  
  public String getDisposition()
    throws MessagingException
  {
    return this.bs.disposition;
  }
  
  public String getEncoding()
    throws MessagingException
  {
    return this.bs.encoding;
  }
  
  public String getFileName()
    throws MessagingException
  {
    String str1 = null;
    if (this.bs.dParams != null) {
      str1 = this.bs.dParams.get("filename");
    }
    String str2 = str1;
    if (str1 == null)
    {
      str2 = str1;
      if (this.bs.cParams != null) {
        str2 = this.bs.cParams.get("name");
      }
    }
    return str2;
  }
  
  public String[] getHeader(String paramString)
    throws MessagingException
  {
    loadHeaders();
    return super.getHeader(paramString);
  }
  
  public int getLineCount()
    throws MessagingException
  {
    return this.bs.lines;
  }
  
  public Enumeration getMatchingHeaderLines(String[] paramArrayOfString)
    throws MessagingException
  {
    loadHeaders();
    return super.getMatchingHeaderLines(paramArrayOfString);
  }
  
  public Enumeration getMatchingHeaders(String[] paramArrayOfString)
    throws MessagingException
  {
    loadHeaders();
    return super.getMatchingHeaders(paramArrayOfString);
  }
  
  public Enumeration getNonMatchingHeaderLines(String[] paramArrayOfString)
    throws MessagingException
  {
    loadHeaders();
    return super.getNonMatchingHeaderLines(paramArrayOfString);
  }
  
  public Enumeration getNonMatchingHeaders(String[] paramArrayOfString)
    throws MessagingException
  {
    loadHeaders();
    return super.getNonMatchingHeaders(paramArrayOfString);
  }
  
  public int getSize()
    throws MessagingException
  {
    return this.bs.size;
  }
  
  public void removeHeader(String paramString)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPBodyPart is read-only");
  }
  
  public void setContent(Object paramObject, String paramString)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPBodyPart is read-only");
  }
  
  public void setContent(Multipart paramMultipart)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPBodyPart is read-only");
  }
  
  public void setContentMD5(String paramString)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPBodyPart is read-only");
  }
  
  public void setDataHandler(DataHandler paramDataHandler)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPBodyPart is read-only");
  }
  
  public void setDescription(String paramString1, String paramString2)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPBodyPart is read-only");
  }
  
  public void setDisposition(String paramString)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPBodyPart is read-only");
  }
  
  public void setFileName(String paramString)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPBodyPart is read-only");
  }
  
  public void setHeader(String paramString1, String paramString2)
    throws MessagingException
  {
    throw new IllegalWriteException("IMAPBodyPart is read-only");
  }
  
  protected void updateHeaders() {}
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/IMAPBodyPart.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */