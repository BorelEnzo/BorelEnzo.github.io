package com.sun.mail.imap;

import com.sun.mail.iap.Literal;
import com.sun.mail.util.CRLFOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import javax.mail.Message;
import javax.mail.MessagingException;

class MessageLiteral
  implements Literal
{
  private byte[] buf;
  private Message msg;
  private int msgSize = -1;
  
  public MessageLiteral(Message paramMessage, int paramInt)
    throws MessagingException, IOException
  {
    this.msg = paramMessage;
    LengthCounter localLengthCounter = new LengthCounter(paramInt);
    CRLFOutputStream localCRLFOutputStream = new CRLFOutputStream(localLengthCounter);
    paramMessage.writeTo(localCRLFOutputStream);
    localCRLFOutputStream.flush();
    this.msgSize = localLengthCounter.getSize();
    this.buf = localLengthCounter.getBytes();
  }
  
  public int size()
  {
    return this.msgSize;
  }
  
  public void writeTo(OutputStream paramOutputStream)
    throws IOException
  {
    try
    {
      if (this.buf != null)
      {
        paramOutputStream.write(this.buf, 0, this.msgSize);
        return;
      }
      paramOutputStream = new CRLFOutputStream(paramOutputStream);
      throw new IOException("MessagingException while appending message: " + paramOutputStream);
    }
    catch (MessagingException paramOutputStream)
    {
      try
      {
        this.msg.writeTo(paramOutputStream);
        return;
      }
      catch (MessagingException paramOutputStream)
      {
        for (;;) {}
      }
      paramOutputStream = paramOutputStream;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/MessageLiteral.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */