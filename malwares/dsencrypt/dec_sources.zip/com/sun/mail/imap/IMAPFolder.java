package com.sun.mail.imap;

import com.sun.mail.iap.BadCommandException;
import com.sun.mail.iap.CommandFailedException;
import com.sun.mail.iap.ConnectionException;
import com.sun.mail.iap.ProtocolException;
import com.sun.mail.iap.Response;
import com.sun.mail.iap.ResponseHandler;
import com.sun.mail.imap.protocol.FetchResponse;
import com.sun.mail.imap.protocol.IMAPProtocol;
import com.sun.mail.imap.protocol.IMAPResponse;
import com.sun.mail.imap.protocol.ListInfo;
import com.sun.mail.imap.protocol.Status;
import java.io.PrintStream;
import java.util.Date;
import java.util.Hashtable;
import java.util.Vector;
import javax.mail.FetchProfile;
import javax.mail.FetchProfile.Item;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.FolderClosedException;
import javax.mail.FolderNotFoundException;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Quota;
import javax.mail.Session;
import javax.mail.StoreClosedException;
import javax.mail.UIDFolder;

public class IMAPFolder
  extends Folder
  implements UIDFolder, ResponseHandler
{
  private static final int ABORTING = 2;
  private static final int IDLE = 1;
  private static final int RUNNING = 0;
  protected static final char UNKNOWN_SEPARATOR = '￿';
  protected String[] attributes;
  protected Flags availableFlags;
  private Status cachedStatus = null;
  private long cachedStatusTime = 0L;
  private boolean connectionPoolDebug;
  private boolean debug = false;
  private boolean doExpungeNotification = true;
  protected boolean exists = false;
  protected String fullName;
  private int idleState = 0;
  protected boolean isNamespace = false;
  protected Vector messageCache;
  protected Object messageCacheLock;
  protected String name;
  private boolean opened = false;
  private PrintStream out;
  protected Flags permanentFlags;
  protected IMAPProtocol protocol;
  private int realTotal = -1;
  private boolean reallyClosed = true;
  private int recent = -1;
  protected char separator;
  private int total = -1;
  protected int type;
  protected Hashtable uidTable;
  private long uidnext = -1L;
  private long uidvalidity = -1L;
  
  static
  {
    if (!IMAPFolder.class.desiredAssertionStatus()) {}
    for (boolean bool = true;; bool = false)
    {
      $assertionsDisabled = bool;
      return;
    }
  }
  
  protected IMAPFolder(ListInfo paramListInfo, IMAPStore paramIMAPStore)
  {
    this(paramListInfo.name, paramListInfo.separator, paramIMAPStore);
    if (paramListInfo.hasInferiors) {
      this.type |= 0x2;
    }
    if (paramListInfo.canOpen) {
      this.type |= 0x1;
    }
    this.attributes = paramListInfo.attrs;
  }
  
  protected IMAPFolder(String paramString, char paramChar, IMAPStore paramIMAPStore)
  {
    super(paramIMAPStore);
    if (paramString == null) {
      throw new NullPointerException("Folder name is null");
    }
    this.fullName = paramString;
    this.separator = paramChar;
    this.messageCacheLock = new Object();
    this.debug = paramIMAPStore.getSession().getDebug();
    this.connectionPoolDebug = paramIMAPStore.getConnectionPoolDebug();
    this.out = paramIMAPStore.getSession().getDebugOut();
    if (this.out == null) {
      this.out = System.out;
    }
    this.isNamespace = false;
    if ((paramChar != 65535) && (paramChar != 0))
    {
      int i = this.fullName.indexOf(paramChar);
      if ((i > 0) && (i == this.fullName.length() - 1))
      {
        this.fullName = this.fullName.substring(0, i);
        this.isNamespace = true;
      }
    }
  }
  
  protected IMAPFolder(String paramString, char paramChar, IMAPStore paramIMAPStore, boolean paramBoolean)
  {
    this(paramString, paramChar, paramIMAPStore);
    this.isNamespace = paramBoolean;
  }
  
  private void checkClosed()
  {
    if (this.opened) {
      throw new IllegalStateException("This operation is not allowed on an open folder");
    }
  }
  
  private void checkExists()
    throws MessagingException
  {
    if ((!this.exists) && (!exists())) {
      throw new FolderNotFoundException(this, this.fullName + " not found");
    }
  }
  
  private void checkFlags(Flags paramFlags)
    throws MessagingException
  {
    assert (Thread.holdsLock(this));
    if (this.mode != 2) {
      throw new IllegalStateException("Cannot change flags on READ_ONLY folder: " + this.fullName);
    }
  }
  
  private void checkOpened()
    throws FolderClosedException
  {
    assert (Thread.holdsLock(this));
    if (!this.opened)
    {
      if (this.reallyClosed) {
        throw new IllegalStateException("This operation is not allowed on a closed folder");
      }
      throw new FolderClosedException(this, "Lost folder connection to server");
    }
  }
  
  /* Error */
  private void checkRange(int paramInt)
    throws MessagingException
  {
    // Byte code:
    //   0: iload_1
    //   1: iconst_1
    //   2: if_icmpge +11 -> 13
    //   5: new 301	java/lang/IndexOutOfBoundsException
    //   8: dup
    //   9: invokespecial 302	java/lang/IndexOutOfBoundsException:<init>	()V
    //   12: athrow
    //   13: iload_1
    //   14: aload_0
    //   15: getfield 151	com/sun/mail/imap/IMAPFolder:total	I
    //   18: if_icmpgt +4 -> 22
    //   21: return
    //   22: aload_0
    //   23: getfield 185	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   26: astore_2
    //   27: aload_2
    //   28: monitorenter
    //   29: aload_0
    //   30: iconst_0
    //   31: invokespecial 306	com/sun/mail/imap/IMAPFolder:keepConnectionAlive	(Z)V
    //   34: aload_2
    //   35: monitorexit
    //   36: iload_1
    //   37: aload_0
    //   38: getfield 151	com/sun/mail/imap/IMAPFolder:total	I
    //   41: if_icmple -20 -> 21
    //   44: new 301	java/lang/IndexOutOfBoundsException
    //   47: dup
    //   48: invokespecial 302	java/lang/IndexOutOfBoundsException:<init>	()V
    //   51: athrow
    //   52: astore_3
    //   53: new 290	javax/mail/FolderClosedException
    //   56: dup
    //   57: aload_0
    //   58: aload_3
    //   59: invokevirtual 309	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   62: invokespecial 295	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   65: athrow
    //   66: astore_3
    //   67: aload_2
    //   68: monitorexit
    //   69: aload_3
    //   70: athrow
    //   71: astore_3
    //   72: new 247	javax/mail/MessagingException
    //   75: dup
    //   76: aload_3
    //   77: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   80: aload_3
    //   81: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   84: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	85	0	this	IMAPFolder
    //   0	85	1	paramInt	int
    //   52	7	3	localConnectionException	ConnectionException
    //   66	4	3	localObject2	Object
    //   71	10	3	localProtocolException	ProtocolException
    // Exception table:
    //   from	to	target	type
    //   29	34	52	com/sun/mail/iap/ConnectionException
    //   29	34	66	finally
    //   34	36	66	finally
    //   53	66	66	finally
    //   67	69	66	finally
    //   72	85	66	finally
    //   29	34	71	com/sun/mail/iap/ProtocolException
  }
  
  private void cleanup(boolean paramBoolean)
  {
    releaseProtocol(paramBoolean);
    this.protocol = null;
    this.messageCache = null;
    this.uidTable = null;
    this.exists = false;
    this.attributes = null;
    this.opened = false;
    this.idleState = 0;
    notifyConnectionListeners(3);
  }
  
  private void close(boolean paramBoolean1, boolean paramBoolean2)
    throws MessagingException
  {
    assert (Thread.holdsLock(this));
    synchronized (this.messageCacheLock)
    {
      if ((!this.opened) && (this.reallyClosed)) {
        throw new IllegalStateException("This operation is not allowed on a closed folder");
      }
    }
    this.reallyClosed = true;
    if (!this.opened) {
      return;
    }
    for (;;)
    {
      try
      {
        waitIfIdle();
        if (paramBoolean2)
        {
          if (this.debug) {
            this.out.println("DEBUG: forcing folder " + this.fullName + " to close");
          }
          if (this.protocol != null) {
            this.protocol.disconnect();
          }
          if (this.opened) {
            cleanup(true);
          }
          return;
        }
        if (((IMAPStore)this.store).isConnectionPoolFull())
        {
          if (this.debug) {
            this.out.println("DEBUG: pool is full, not adding an Authenticated connection");
          }
          if (paramBoolean1) {
            this.protocol.close();
          }
          if (this.protocol == null) {
            continue;
          }
          this.protocol.logout();
          continue;
        }
        if (paramBoolean1) {
          break label275;
        }
      }
      catch (ProtocolException localProtocolException1)
      {
        throw new MessagingException(localProtocolException1.getMessage(), localProtocolException1);
      }
      finally
      {
        if (this.opened) {
          cleanup(true);
        }
      }
      int i = this.mode;
      if (i == 2) {}
      try
      {
        this.protocol.examine(this.fullName);
        label275:
        if (this.protocol == null) {
          continue;
        }
        this.protocol.close();
      }
      catch (ProtocolException localProtocolException2)
      {
        for (;;)
        {
          if (this.protocol != null) {
            this.protocol.disconnect();
          }
        }
      }
    }
  }
  
  /* Error */
  private Folder[] doList(final String paramString, final boolean paramBoolean)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 369	com/sun/mail/imap/IMAPFolder:checkExists	()V
    //   6: aload_0
    //   7: invokespecial 372	com/sun/mail/imap/IMAPFolder:isDirectory	()Z
    //   10: ifne +12 -> 22
    //   13: iconst_0
    //   14: anewarray 4	javax/mail/Folder
    //   17: astore_1
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_1
    //   21: areturn
    //   22: aload_0
    //   23: invokevirtual 376	com/sun/mail/imap/IMAPFolder:getSeparator	()C
    //   26: istore_3
    //   27: aload_0
    //   28: new 32	com/sun/mail/imap/IMAPFolder$2
    //   31: dup
    //   32: aload_0
    //   33: iload_2
    //   34: iload_3
    //   35: aload_1
    //   36: invokespecial 379	com/sun/mail/imap/IMAPFolder$2:<init>	(Lcom/sun/mail/imap/IMAPFolder;ZCLjava/lang/String;)V
    //   39: invokevirtual 383	com/sun/mail/imap/IMAPFolder:doCommandIgnoreFailure	(Lcom/sun/mail/imap/IMAPFolder$ProtocolCommand;)Ljava/lang/Object;
    //   42: checkcast 385	[Lcom/sun/mail/imap/protocol/ListInfo;
    //   45: astore 7
    //   47: aload 7
    //   49: ifnonnull +11 -> 60
    //   52: iconst_0
    //   53: anewarray 4	javax/mail/Folder
    //   56: astore_1
    //   57: goto -39 -> 18
    //   60: iconst_0
    //   61: istore 5
    //   63: iload 5
    //   65: istore 4
    //   67: aload 7
    //   69: arraylength
    //   70: ifle +44 -> 114
    //   73: iload 5
    //   75: istore 4
    //   77: aload 7
    //   79: iconst_0
    //   80: aaload
    //   81: getfield 118	com/sun/mail/imap/protocol/ListInfo:name	Ljava/lang/String;
    //   84: new 253	java/lang/StringBuilder
    //   87: dup
    //   88: aload_0
    //   89: getfield 178	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   92: invokestatic 257	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   95: invokespecial 258	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   98: iload_3
    //   99: invokevirtual 388	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
    //   102: invokevirtual 268	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   105: invokevirtual 391	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   108: ifeq +6 -> 114
    //   111: iconst_1
    //   112: istore 4
    //   114: aload 7
    //   116: arraylength
    //   117: iload 4
    //   119: isub
    //   120: anewarray 2	com/sun/mail/imap/IMAPFolder
    //   123: astore 6
    //   125: iload 4
    //   127: istore 5
    //   129: aload 6
    //   131: astore_1
    //   132: iload 5
    //   134: aload 7
    //   136: arraylength
    //   137: if_icmpge -119 -> 18
    //   140: aload 6
    //   142: iload 5
    //   144: iload 4
    //   146: isub
    //   147: new 2	com/sun/mail/imap/IMAPFolder
    //   150: dup
    //   151: aload 7
    //   153: iload 5
    //   155: aaload
    //   156: aload_0
    //   157: getfield 351	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   160: checkcast 187	com/sun/mail/imap/IMAPStore
    //   163: invokespecial 393	com/sun/mail/imap/IMAPFolder:<init>	(Lcom/sun/mail/imap/protocol/ListInfo;Lcom/sun/mail/imap/IMAPStore;)V
    //   166: aastore
    //   167: iload 5
    //   169: iconst_1
    //   170: iadd
    //   171: istore 5
    //   173: goto -44 -> 129
    //   176: astore_1
    //   177: aload_0
    //   178: monitorexit
    //   179: aload_1
    //   180: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	181	0	this	IMAPFolder
    //   0	181	1	paramString	String
    //   0	181	2	paramBoolean	boolean
    //   26	73	3	c	char
    //   65	82	4	i	int
    //   61	111	5	j	int
    //   123	18	6	arrayOfIMAPFolder	IMAPFolder[]
    //   45	107	7	arrayOfListInfo	ListInfo[]
    // Exception table:
    //   from	to	target	type
    //   2	18	176	finally
    //   22	47	176	finally
    //   52	57	176	finally
    //   67	73	176	finally
    //   77	111	176	finally
    //   114	125	176	finally
    //   132	167	176	finally
  }
  
  private int findName(ListInfo[] paramArrayOfListInfo, String paramString)
  {
    int i = 0;
    for (;;)
    {
      if (i >= paramArrayOfListInfo.length) {}
      while (paramArrayOfListInfo[i].name.equals(paramString))
      {
        int j = i;
        if (i >= paramArrayOfListInfo.length) {
          j = 0;
        }
        return j;
      }
      i += 1;
    }
  }
  
  private IMAPProtocol getProtocol()
    throws ProtocolException
  {
    assert (Thread.holdsLock(this.messageCacheLock));
    waitIfIdle();
    return this.protocol;
  }
  
  private Status getStatus()
    throws ProtocolException
  {
    int i = ((IMAPStore)this.store).getStatusCacheTimeout();
    if ((i > 0) && (this.cachedStatus != null) && (System.currentTimeMillis() - this.cachedStatusTime < i)) {
      return this.cachedStatus;
    }
    Object localObject1 = null;
    try
    {
      IMAPProtocol localIMAPProtocol = getStoreProtocol();
      localObject1 = localIMAPProtocol;
      Status localStatus = localIMAPProtocol.status(this.fullName, null);
      if (i > 0)
      {
        localObject1 = localIMAPProtocol;
        this.cachedStatus = localStatus;
        localObject1 = localIMAPProtocol;
        this.cachedStatusTime = System.currentTimeMillis();
      }
      releaseStoreProtocol(localIMAPProtocol);
      return localStatus;
    }
    finally
    {
      releaseStoreProtocol((IMAPProtocol)localObject1);
    }
  }
  
  private boolean isDirectory()
  {
    return (this.type & 0x2) != 0;
  }
  
  private void keepConnectionAlive(boolean paramBoolean)
    throws ProtocolException
  {
    if (System.currentTimeMillis() - this.protocol.getTimestamp() > 1000L)
    {
      waitIfIdle();
      this.protocol.noop();
    }
    Object localObject1;
    if ((paramBoolean) && (((IMAPStore)this.store).hasSeparateStoreConnection())) {
      localObject1 = null;
    }
    try
    {
      IMAPProtocol localIMAPProtocol = ((IMAPStore)this.store).getStoreProtocol();
      localObject1 = localIMAPProtocol;
      if (System.currentTimeMillis() - localIMAPProtocol.getTimestamp() > 1000L)
      {
        localObject1 = localIMAPProtocol;
        localIMAPProtocol.noop();
      }
      ((IMAPStore)this.store).releaseStoreProtocol(localIMAPProtocol);
      return;
    }
    finally
    {
      ((IMAPStore)this.store).releaseStoreProtocol((IMAPProtocol)localObject1);
    }
  }
  
  private void releaseProtocol(boolean paramBoolean)
  {
    if (this.protocol != null)
    {
      this.protocol.removeResponseHandler(this);
      if (paramBoolean) {
        ((IMAPStore)this.store).releaseProtocol(this, this.protocol);
      }
    }
    else
    {
      return;
    }
    ((IMAPStore)this.store).releaseProtocol(this, null);
  }
  
  private void setACL(final ACL paramACL, final char paramChar)
    throws MessagingException
  {
    doOptionalCommand("ACL not supported", new ProtocolCommand()
    {
      public Object doCommand(IMAPProtocol paramAnonymousIMAPProtocol)
        throws ProtocolException
      {
        paramAnonymousIMAPProtocol.setACL(IMAPFolder.this.fullName, paramChar, paramACL);
        return null;
      }
    });
  }
  
  private void throwClosedException(ConnectionException paramConnectionException)
    throws FolderClosedException, StoreClosedException
  {
    try
    {
      if (((this.protocol != null) && (paramConnectionException.getProtocol() == this.protocol)) || ((this.protocol == null) && (!this.reallyClosed))) {
        throw new FolderClosedException(this, paramConnectionException.getMessage());
      }
    }
    finally {}
    throw new StoreClosedException(this.store, paramConnectionException.getMessage());
  }
  
  public void addACL(ACL paramACL)
    throws MessagingException
  {
    setACL(paramACL, '\000');
  }
  
  /* Error */
  public Message[] addMessages(Message[] paramArrayOfMessage)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 464	com/sun/mail/imap/IMAPFolder:checkOpened	()V
    //   6: aload_1
    //   7: arraylength
    //   8: anewarray 466	javax/mail/internet/MimeMessage
    //   11: astore 8
    //   13: aload_0
    //   14: aload_1
    //   15: invokevirtual 470	com/sun/mail/imap/IMAPFolder:appendUIDMessages	([Ljavax/mail/Message;)[Lcom/sun/mail/imap/AppendUID;
    //   18: astore_1
    //   19: iconst_0
    //   20: istore_2
    //   21: aload_1
    //   22: arraylength
    //   23: istore_3
    //   24: iload_2
    //   25: iload_3
    //   26: if_icmplt +8 -> 34
    //   29: aload_0
    //   30: monitorexit
    //   31: aload 8
    //   33: areturn
    //   34: aload_1
    //   35: iload_2
    //   36: aaload
    //   37: astore 9
    //   39: aload 9
    //   41: ifnull +37 -> 78
    //   44: aload 9
    //   46: getfield 473	com/sun/mail/imap/AppendUID:uidvalidity	J
    //   49: lstore 4
    //   51: aload_0
    //   52: getfield 159	com/sun/mail/imap/IMAPFolder:uidvalidity	J
    //   55: lstore 6
    //   57: lload 4
    //   59: lload 6
    //   61: lcmp
    //   62: ifne +16 -> 78
    //   65: aload 8
    //   67: iload_2
    //   68: aload_0
    //   69: aload 9
    //   71: getfield 476	com/sun/mail/imap/AppendUID:uid	J
    //   74: invokevirtual 480	com/sun/mail/imap/IMAPFolder:getMessageByUID	(J)Ljavax/mail/Message;
    //   77: aastore
    //   78: iload_2
    //   79: iconst_1
    //   80: iadd
    //   81: istore_2
    //   82: goto -61 -> 21
    //   85: astore_1
    //   86: aload_0
    //   87: monitorexit
    //   88: aload_1
    //   89: athrow
    //   90: astore 9
    //   92: goto -14 -> 78
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	95	0	this	IMAPFolder
    //   0	95	1	paramArrayOfMessage	Message[]
    //   20	62	2	i	int
    //   23	4	3	j	int
    //   49	9	4	l1	long
    //   55	5	6	l2	long
    //   11	55	8	arrayOfMimeMessage	javax.mail.internet.MimeMessage[]
    //   37	33	9	localMessage	Message
    //   90	1	9	localMessagingException	MessagingException
    // Exception table:
    //   from	to	target	type
    //   2	19	85	finally
    //   21	24	85	finally
    //   44	57	85	finally
    //   65	78	85	finally
    //   65	78	90	javax/mail/MessagingException
  }
  
  public void addRights(ACL paramACL)
    throws MessagingException
  {
    setACL(paramACL, '+');
  }
  
  /* Error */
  public void appendMessages(Message[] paramArrayOfMessage)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 369	com/sun/mail/imap/IMAPFolder:checkExists	()V
    //   6: aload_0
    //   7: getfield 351	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   10: checkcast 187	com/sun/mail/imap/IMAPStore
    //   13: invokevirtual 490	com/sun/mail/imap/IMAPStore:getAppendBufferSize	()I
    //   16: istore 4
    //   18: iconst_0
    //   19: istore_2
    //   20: aload_1
    //   21: arraylength
    //   22: istore_3
    //   23: iload_2
    //   24: iload_3
    //   25: if_icmplt +6 -> 31
    //   28: aload_0
    //   29: monitorexit
    //   30: return
    //   31: aload_1
    //   32: iload_2
    //   33: aaload
    //   34: astore 7
    //   36: aload 7
    //   38: invokevirtual 495	javax/mail/Message:getSize	()I
    //   41: iload 4
    //   43: if_icmple +92 -> 135
    //   46: iconst_0
    //   47: istore_3
    //   48: new 497	com/sun/mail/imap/MessageLiteral
    //   51: dup
    //   52: aload 7
    //   54: iload_3
    //   55: invokespecial 500	com/sun/mail/imap/MessageLiteral:<init>	(Ljavax/mail/Message;I)V
    //   58: astore 8
    //   60: aload 7
    //   62: invokevirtual 504	javax/mail/Message:getReceivedDate	()Ljava/util/Date;
    //   65: astore 6
    //   67: aload 6
    //   69: astore 5
    //   71: aload 6
    //   73: ifnonnull +10 -> 83
    //   76: aload 7
    //   78: invokevirtual 507	javax/mail/Message:getSentDate	()Ljava/util/Date;
    //   81: astore 5
    //   83: aload_0
    //   84: new 12	com/sun/mail/imap/IMAPFolder$10
    //   87: dup
    //   88: aload_0
    //   89: aload 7
    //   91: invokevirtual 511	javax/mail/Message:getFlags	()Ljavax/mail/Flags;
    //   94: aload 5
    //   96: aload 8
    //   98: invokespecial 514	com/sun/mail/imap/IMAPFolder$10:<init>	(Lcom/sun/mail/imap/IMAPFolder;Ljavax/mail/Flags;Ljava/util/Date;Lcom/sun/mail/imap/MessageLiteral;)V
    //   101: invokevirtual 517	com/sun/mail/imap/IMAPFolder:doCommand	(Lcom/sun/mail/imap/IMAPFolder$ProtocolCommand;)Ljava/lang/Object;
    //   104: pop
    //   105: goto +23 -> 128
    //   108: astore_1
    //   109: new 247	javax/mail/MessagingException
    //   112: dup
    //   113: ldc_w 519
    //   116: aload_1
    //   117: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   120: athrow
    //   121: astore_1
    //   122: aload_0
    //   123: monitorexit
    //   124: aload_1
    //   125: athrow
    //   126: astore 5
    //   128: iload_2
    //   129: iconst_1
    //   130: iadd
    //   131: istore_2
    //   132: goto -112 -> 20
    //   135: iload 4
    //   137: istore_3
    //   138: goto -90 -> 48
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	141	0	this	IMAPFolder
    //   0	141	1	paramArrayOfMessage	Message[]
    //   19	113	2	i	int
    //   22	116	3	j	int
    //   16	120	4	k	int
    //   69	26	5	localDate1	Date
    //   126	1	5	localMessageRemovedException	javax.mail.MessageRemovedException
    //   65	7	6	localDate2	Date
    //   34	56	7	localMessage	Message
    //   58	39	8	localMessageLiteral	MessageLiteral
    // Exception table:
    //   from	to	target	type
    //   36	46	108	java/io/IOException
    //   48	60	108	java/io/IOException
    //   2	18	121	finally
    //   20	23	121	finally
    //   36	46	121	finally
    //   48	60	121	finally
    //   60	67	121	finally
    //   76	83	121	finally
    //   83	105	121	finally
    //   109	121	121	finally
    //   36	46	126	javax/mail/MessageRemovedException
    //   48	60	126	javax/mail/MessageRemovedException
  }
  
  /* Error */
  public AppendUID[] appendUIDMessages(Message[] paramArrayOfMessage)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 369	com/sun/mail/imap/IMAPFolder:checkExists	()V
    //   6: aload_0
    //   7: getfield 351	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   10: checkcast 187	com/sun/mail/imap/IMAPStore
    //   13: invokevirtual 490	com/sun/mail/imap/IMAPStore:getAppendBufferSize	()I
    //   16: istore 4
    //   18: aload_1
    //   19: arraylength
    //   20: anewarray 472	com/sun/mail/imap/AppendUID
    //   23: astore 7
    //   25: iconst_0
    //   26: istore_2
    //   27: aload_1
    //   28: arraylength
    //   29: istore_3
    //   30: iload_2
    //   31: iload_3
    //   32: if_icmplt +8 -> 40
    //   35: aload_0
    //   36: monitorexit
    //   37: aload 7
    //   39: areturn
    //   40: aload_1
    //   41: iload_2
    //   42: aaload
    //   43: astore 8
    //   45: aload 8
    //   47: invokevirtual 495	javax/mail/Message:getSize	()I
    //   50: iload 4
    //   52: if_icmple +98 -> 150
    //   55: iconst_0
    //   56: istore_3
    //   57: new 497	com/sun/mail/imap/MessageLiteral
    //   60: dup
    //   61: aload 8
    //   63: iload_3
    //   64: invokespecial 500	com/sun/mail/imap/MessageLiteral:<init>	(Ljavax/mail/Message;I)V
    //   67: astore 9
    //   69: aload 8
    //   71: invokevirtual 504	javax/mail/Message:getReceivedDate	()Ljava/util/Date;
    //   74: astore 6
    //   76: aload 6
    //   78: astore 5
    //   80: aload 6
    //   82: ifnonnull +10 -> 92
    //   85: aload 8
    //   87: invokevirtual 507	javax/mail/Message:getSentDate	()Ljava/util/Date;
    //   90: astore 5
    //   92: aload 7
    //   94: iload_2
    //   95: aload_0
    //   96: new 14	com/sun/mail/imap/IMAPFolder$11
    //   99: dup
    //   100: aload_0
    //   101: aload 8
    //   103: invokevirtual 511	javax/mail/Message:getFlags	()Ljavax/mail/Flags;
    //   106: aload 5
    //   108: aload 9
    //   110: invokespecial 520	com/sun/mail/imap/IMAPFolder$11:<init>	(Lcom/sun/mail/imap/IMAPFolder;Ljavax/mail/Flags;Ljava/util/Date;Lcom/sun/mail/imap/MessageLiteral;)V
    //   113: invokevirtual 517	com/sun/mail/imap/IMAPFolder:doCommand	(Lcom/sun/mail/imap/IMAPFolder$ProtocolCommand;)Ljava/lang/Object;
    //   116: checkcast 472	com/sun/mail/imap/AppendUID
    //   119: aastore
    //   120: goto +23 -> 143
    //   123: astore_1
    //   124: new 247	javax/mail/MessagingException
    //   127: dup
    //   128: ldc_w 519
    //   131: aload_1
    //   132: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   135: athrow
    //   136: astore_1
    //   137: aload_0
    //   138: monitorexit
    //   139: aload_1
    //   140: athrow
    //   141: astore 5
    //   143: iload_2
    //   144: iconst_1
    //   145: iadd
    //   146: istore_2
    //   147: goto -120 -> 27
    //   150: iload 4
    //   152: istore_3
    //   153: goto -96 -> 57
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	156	0	this	IMAPFolder
    //   0	156	1	paramArrayOfMessage	Message[]
    //   26	121	2	i	int
    //   29	124	3	j	int
    //   16	135	4	k	int
    //   78	29	5	localDate1	Date
    //   141	1	5	localMessageRemovedException	javax.mail.MessageRemovedException
    //   74	7	6	localDate2	Date
    //   23	70	7	arrayOfAppendUID	AppendUID[]
    //   43	59	8	localMessage	Message
    //   67	42	9	localMessageLiteral	MessageLiteral
    // Exception table:
    //   from	to	target	type
    //   45	55	123	java/io/IOException
    //   57	69	123	java/io/IOException
    //   2	25	136	finally
    //   27	30	136	finally
    //   45	55	136	finally
    //   57	69	136	finally
    //   69	76	136	finally
    //   85	92	136	finally
    //   92	120	136	finally
    //   124	136	136	finally
    //   45	55	141	javax/mail/MessageRemovedException
    //   57	69	141	javax/mail/MessageRemovedException
  }
  
  public void close(boolean paramBoolean)
    throws MessagingException
  {
    try
    {
      close(paramBoolean, false);
      return;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  /* Error */
  public void copyMessages(Message[] paramArrayOfMessage, Folder paramFolder)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 464	com/sun/mail/imap/IMAPFolder:checkOpened	()V
    //   6: aload_1
    //   7: arraylength
    //   8: istore_3
    //   9: iload_3
    //   10: ifne +6 -> 16
    //   13: aload_0
    //   14: monitorexit
    //   15: return
    //   16: aload_2
    //   17: invokevirtual 530	javax/mail/Folder:getStore	()Ljavax/mail/Store;
    //   20: aload_0
    //   21: getfield 351	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   24: if_acmpne +154 -> 178
    //   27: aload_0
    //   28: getfield 185	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   31: astore 4
    //   33: aload 4
    //   35: monitorenter
    //   36: aload_0
    //   37: invokespecial 532	com/sun/mail/imap/IMAPFolder:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   40: astore 5
    //   42: aload_1
    //   43: aconst_null
    //   44: invokestatic 538	com/sun/mail/imap/Utility:toMessageSet	([Ljavax/mail/Message;Lcom/sun/mail/imap/Utility$Condition;)[Lcom/sun/mail/imap/protocol/MessageSet;
    //   47: astore_1
    //   48: aload_1
    //   49: ifnonnull +72 -> 121
    //   52: new 487	javax/mail/MessageRemovedException
    //   55: dup
    //   56: ldc_w 540
    //   59: invokespecial 541	javax/mail/MessageRemovedException:<init>	(Ljava/lang/String;)V
    //   62: athrow
    //   63: astore_1
    //   64: aload_1
    //   65: invokevirtual 542	com/sun/mail/iap/CommandFailedException:getMessage	()Ljava/lang/String;
    //   68: ldc_w 544
    //   71: invokevirtual 547	java/lang/String:indexOf	(Ljava/lang/String;)I
    //   74: iconst_m1
    //   75: if_icmpeq +62 -> 137
    //   78: new 251	javax/mail/FolderNotFoundException
    //   81: dup
    //   82: aload_2
    //   83: new 253	java/lang/StringBuilder
    //   86: dup
    //   87: aload_2
    //   88: invokevirtual 550	javax/mail/Folder:getFullName	()Ljava/lang/String;
    //   91: invokestatic 257	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   94: invokespecial 258	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   97: ldc_w 552
    //   100: invokevirtual 264	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   103: invokevirtual 268	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   106: invokespecial 271	javax/mail/FolderNotFoundException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   109: athrow
    //   110: astore_1
    //   111: aload 4
    //   113: monitorexit
    //   114: aload_1
    //   115: athrow
    //   116: astore_1
    //   117: aload_0
    //   118: monitorexit
    //   119: aload_1
    //   120: athrow
    //   121: aload 5
    //   123: aload_1
    //   124: aload_2
    //   125: invokevirtual 550	javax/mail/Folder:getFullName	()Ljava/lang/String;
    //   128: invokevirtual 556	com/sun/mail/imap/protocol/IMAPProtocol:copy	([Lcom/sun/mail/imap/protocol/MessageSet;Ljava/lang/String;)V
    //   131: aload 4
    //   133: monitorexit
    //   134: goto -121 -> 13
    //   137: new 247	javax/mail/MessagingException
    //   140: dup
    //   141: aload_1
    //   142: invokevirtual 542	com/sun/mail/iap/CommandFailedException:getMessage	()Ljava/lang/String;
    //   145: aload_1
    //   146: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   149: athrow
    //   150: astore_1
    //   151: new 290	javax/mail/FolderClosedException
    //   154: dup
    //   155: aload_0
    //   156: aload_1
    //   157: invokevirtual 309	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   160: invokespecial 295	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   163: athrow
    //   164: astore_1
    //   165: new 247	javax/mail/MessagingException
    //   168: dup
    //   169: aload_1
    //   170: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   173: aload_1
    //   174: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   177: athrow
    //   178: aload_0
    //   179: aload_1
    //   180: aload_2
    //   181: invokespecial 558	javax/mail/Folder:copyMessages	([Ljavax/mail/Message;Ljavax/mail/Folder;)V
    //   184: goto -171 -> 13
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	187	0	this	IMAPFolder
    //   0	187	1	paramArrayOfMessage	Message[]
    //   0	187	2	paramFolder	Folder
    //   8	2	3	i	int
    //   40	82	5	localIMAPProtocol	IMAPProtocol
    // Exception table:
    //   from	to	target	type
    //   36	48	63	com/sun/mail/iap/CommandFailedException
    //   52	63	63	com/sun/mail/iap/CommandFailedException
    //   121	131	63	com/sun/mail/iap/CommandFailedException
    //   36	48	110	finally
    //   52	63	110	finally
    //   64	110	110	finally
    //   111	114	110	finally
    //   121	131	110	finally
    //   131	134	110	finally
    //   137	150	110	finally
    //   151	164	110	finally
    //   165	178	110	finally
    //   2	9	116	finally
    //   16	36	116	finally
    //   114	116	116	finally
    //   178	184	116	finally
    //   36	48	150	com/sun/mail/iap/ConnectionException
    //   52	63	150	com/sun/mail/iap/ConnectionException
    //   121	131	150	com/sun/mail/iap/ConnectionException
    //   36	48	164	com/sun/mail/iap/ProtocolException
    //   52	63	164	com/sun/mail/iap/ProtocolException
    //   121	131	164	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public boolean create(final int paramInt)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iconst_0
    //   3: istore_2
    //   4: iload_1
    //   5: iconst_1
    //   6: iand
    //   7: ifne +8 -> 15
    //   10: aload_0
    //   11: invokevirtual 376	com/sun/mail/imap/IMAPFolder:getSeparator	()C
    //   14: istore_2
    //   15: aload_0
    //   16: new 40	com/sun/mail/imap/IMAPFolder$6
    //   19: dup
    //   20: aload_0
    //   21: iload_1
    //   22: iload_2
    //   23: invokespecial 563	com/sun/mail/imap/IMAPFolder$6:<init>	(Lcom/sun/mail/imap/IMAPFolder;IC)V
    //   26: invokevirtual 383	com/sun/mail/imap/IMAPFolder:doCommandIgnoreFailure	(Lcom/sun/mail/imap/IMAPFolder$ProtocolCommand;)Ljava/lang/Object;
    //   29: astore 5
    //   31: aload 5
    //   33: ifnonnull +9 -> 42
    //   36: iconst_0
    //   37: istore_3
    //   38: aload_0
    //   39: monitorexit
    //   40: iload_3
    //   41: ireturn
    //   42: aload_0
    //   43: invokevirtual 249	com/sun/mail/imap/IMAPFolder:exists	()Z
    //   46: istore 4
    //   48: iload 4
    //   50: istore_3
    //   51: iload 4
    //   53: ifeq -15 -> 38
    //   56: aload_0
    //   57: iconst_1
    //   58: invokevirtual 566	com/sun/mail/imap/IMAPFolder:notifyFolderListeners	(I)V
    //   61: iload 4
    //   63: istore_3
    //   64: goto -26 -> 38
    //   67: astore 5
    //   69: aload_0
    //   70: monitorexit
    //   71: aload 5
    //   73: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	74	0	this	IMAPFolder
    //   0	74	1	paramInt	int
    //   3	20	2	c	char
    //   37	27	3	bool1	boolean
    //   46	16	4	bool2	boolean
    //   29	3	5	localObject1	Object
    //   67	5	5	localObject2	Object
    // Exception table:
    //   from	to	target	type
    //   10	15	67	finally
    //   15	31	67	finally
    //   42	48	67	finally
    //   56	61	67	finally
  }
  
  /* Error */
  public boolean delete(boolean paramBoolean)
    throws MessagingException
  {
    // Byte code:
    //   0: iconst_0
    //   1: istore_3
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: invokespecial 570	com/sun/mail/imap/IMAPFolder:checkClosed	()V
    //   8: iload_1
    //   9: ifeq +18 -> 27
    //   12: aload_0
    //   13: invokevirtual 574	com/sun/mail/imap/IMAPFolder:list	()[Ljavax/mail/Folder;
    //   16: astore 4
    //   18: iconst_0
    //   19: istore_2
    //   20: iload_2
    //   21: aload 4
    //   23: arraylength
    //   24: if_icmplt +28 -> 52
    //   27: aload_0
    //   28: new 44	com/sun/mail/imap/IMAPFolder$8
    //   31: dup
    //   32: aload_0
    //   33: invokespecial 577	com/sun/mail/imap/IMAPFolder$8:<init>	(Lcom/sun/mail/imap/IMAPFolder;)V
    //   36: invokevirtual 383	com/sun/mail/imap/IMAPFolder:doCommandIgnoreFailure	(Lcom/sun/mail/imap/IMAPFolder$ProtocolCommand;)Ljava/lang/Object;
    //   39: astore 4
    //   41: aload 4
    //   43: ifnonnull +25 -> 68
    //   46: iload_3
    //   47: istore_1
    //   48: aload_0
    //   49: monitorexit
    //   50: iload_1
    //   51: ireturn
    //   52: aload 4
    //   54: iload_2
    //   55: aaload
    //   56: iload_1
    //   57: invokevirtual 579	javax/mail/Folder:delete	(Z)Z
    //   60: pop
    //   61: iload_2
    //   62: iconst_1
    //   63: iadd
    //   64: istore_2
    //   65: goto -45 -> 20
    //   68: aload_0
    //   69: iconst_0
    //   70: putfield 133	com/sun/mail/imap/IMAPFolder:exists	Z
    //   73: aload_0
    //   74: aconst_null
    //   75: putfield 138	com/sun/mail/imap/IMAPFolder:attributes	[Ljava/lang/String;
    //   78: aload_0
    //   79: iconst_2
    //   80: invokevirtual 566	com/sun/mail/imap/IMAPFolder:notifyFolderListeners	(I)V
    //   83: iconst_1
    //   84: istore_1
    //   85: goto -37 -> 48
    //   88: astore 4
    //   90: aload_0
    //   91: monitorexit
    //   92: aload 4
    //   94: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	95	0	this	IMAPFolder
    //   0	95	1	paramBoolean	boolean
    //   19	46	2	i	int
    //   1	46	3	bool	boolean
    //   16	37	4	localObject1	Object
    //   88	5	4	localObject2	Object
    // Exception table:
    //   from	to	target	type
    //   4	8	88	finally
    //   12	18	88	finally
    //   20	27	88	finally
    //   27	41	88	finally
    //   52	61	88	finally
    //   68	83	88	finally
  }
  
  public Object doCommand(ProtocolCommand paramProtocolCommand)
    throws MessagingException
  {
    try
    {
      paramProtocolCommand = doProtocolCommand(paramProtocolCommand);
      return paramProtocolCommand;
    }
    catch (ConnectionException paramProtocolCommand)
    {
      throwClosedException(paramProtocolCommand);
      return null;
    }
    catch (ProtocolException paramProtocolCommand)
    {
      throw new MessagingException(paramProtocolCommand.getMessage(), paramProtocolCommand);
    }
  }
  
  public Object doCommandIgnoreFailure(ProtocolCommand paramProtocolCommand)
    throws MessagingException
  {
    try
    {
      paramProtocolCommand = doProtocolCommand(paramProtocolCommand);
      return paramProtocolCommand;
    }
    catch (CommandFailedException paramProtocolCommand)
    {
      return null;
    }
    catch (ConnectionException paramProtocolCommand)
    {
      throwClosedException(paramProtocolCommand);
      return null;
    }
    catch (ProtocolException paramProtocolCommand)
    {
      throw new MessagingException(paramProtocolCommand.getMessage(), paramProtocolCommand);
    }
  }
  
  public Object doOptionalCommand(String paramString, ProtocolCommand paramProtocolCommand)
    throws MessagingException
  {
    try
    {
      paramProtocolCommand = doProtocolCommand(paramProtocolCommand);
      return paramProtocolCommand;
    }
    catch (BadCommandException paramProtocolCommand)
    {
      throw new MessagingException(paramString, paramProtocolCommand);
    }
    catch (ConnectionException paramString)
    {
      throwClosedException(paramString);
      return null;
    }
    catch (ProtocolException paramString)
    {
      throw new MessagingException(paramString.getMessage(), paramString);
    }
  }
  
  protected Object doProtocolCommand(ProtocolCommand paramProtocolCommand)
    throws ProtocolException
  {
    try
    {
      if ((this.opened) && (!((IMAPStore)this.store).hasSeparateStoreConnection())) {
        synchronized (this.messageCacheLock)
        {
          paramProtocolCommand = paramProtocolCommand.doCommand(getProtocol());
          return paramProtocolCommand;
        }
      }
    }
    finally {}
    ??? = null;
    try
    {
      IMAPProtocol localIMAPProtocol = getStoreProtocol();
      ??? = localIMAPProtocol;
      paramProtocolCommand = paramProtocolCommand.doCommand(localIMAPProtocol);
      releaseStoreProtocol(localIMAPProtocol);
      return paramProtocolCommand;
    }
    finally
    {
      releaseStoreProtocol((IMAPProtocol)???);
    }
  }
  
  /* Error */
  public boolean exists()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aconst_null
    //   3: checkcast 385	[Lcom/sun/mail/imap/protocol/ListInfo;
    //   6: astore 4
    //   8: aload_0
    //   9: getfield 143	com/sun/mail/imap/IMAPFolder:isNamespace	Z
    //   12: ifeq +212 -> 224
    //   15: aload_0
    //   16: getfield 179	com/sun/mail/imap/IMAPFolder:separator	C
    //   19: ifeq +205 -> 224
    //   22: new 253	java/lang/StringBuilder
    //   25: dup
    //   26: aload_0
    //   27: getfield 178	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   30: invokestatic 257	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   33: invokespecial 258	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   36: aload_0
    //   37: getfield 179	com/sun/mail/imap/IMAPFolder:separator	C
    //   40: invokevirtual 388	java/lang/StringBuilder:append	(C)Ljava/lang/StringBuilder;
    //   43: invokevirtual 268	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   46: astore 4
    //   48: aload_0
    //   49: new 10	com/sun/mail/imap/IMAPFolder$1
    //   52: dup
    //   53: aload_0
    //   54: aload 4
    //   56: invokespecial 592	com/sun/mail/imap/IMAPFolder$1:<init>	(Lcom/sun/mail/imap/IMAPFolder;Ljava/lang/String;)V
    //   59: invokevirtual 517	com/sun/mail/imap/IMAPFolder:doCommand	(Lcom/sun/mail/imap/IMAPFolder$ProtocolCommand;)Ljava/lang/Object;
    //   62: checkcast 385	[Lcom/sun/mail/imap/protocol/ListInfo;
    //   65: astore 5
    //   67: aload 5
    //   69: ifnull +164 -> 233
    //   72: aload_0
    //   73: aload 5
    //   75: aload 4
    //   77: invokespecial 594	com/sun/mail/imap/IMAPFolder:findName	([Lcom/sun/mail/imap/protocol/ListInfo;Ljava/lang/String;)I
    //   80: istore_1
    //   81: aload_0
    //   82: aload 5
    //   84: iload_1
    //   85: aaload
    //   86: getfield 118	com/sun/mail/imap/protocol/ListInfo:name	Ljava/lang/String;
    //   89: putfield 178	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   92: aload_0
    //   93: aload 5
    //   95: iload_1
    //   96: aaload
    //   97: getfield 120	com/sun/mail/imap/protocol/ListInfo:separator	C
    //   100: putfield 179	com/sun/mail/imap/IMAPFolder:separator	C
    //   103: aload_0
    //   104: getfield 178	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   107: invokevirtual 220	java/lang/String:length	()I
    //   110: istore_2
    //   111: aload_0
    //   112: getfield 179	com/sun/mail/imap/IMAPFolder:separator	C
    //   115: ifeq +39 -> 154
    //   118: iload_2
    //   119: ifle +35 -> 154
    //   122: aload_0
    //   123: getfield 178	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   126: iload_2
    //   127: iconst_1
    //   128: isub
    //   129: invokevirtual 598	java/lang/String:charAt	(I)C
    //   132: aload_0
    //   133: getfield 179	com/sun/mail/imap/IMAPFolder:separator	C
    //   136: if_icmpne +18 -> 154
    //   139: aload_0
    //   140: aload_0
    //   141: getfield 178	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   144: iconst_0
    //   145: iload_2
    //   146: iconst_1
    //   147: isub
    //   148: invokevirtual 224	java/lang/String:substring	(II)Ljava/lang/String;
    //   151: putfield 178	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   154: aload_0
    //   155: iconst_0
    //   156: putfield 128	com/sun/mail/imap/IMAPFolder:type	I
    //   159: aload 5
    //   161: iload_1
    //   162: aaload
    //   163: getfield 126	com/sun/mail/imap/protocol/ListInfo:hasInferiors	Z
    //   166: ifeq +13 -> 179
    //   169: aload_0
    //   170: aload_0
    //   171: getfield 128	com/sun/mail/imap/IMAPFolder:type	I
    //   174: iconst_2
    //   175: ior
    //   176: putfield 128	com/sun/mail/imap/IMAPFolder:type	I
    //   179: aload 5
    //   181: iload_1
    //   182: aaload
    //   183: getfield 131	com/sun/mail/imap/protocol/ListInfo:canOpen	Z
    //   186: ifeq +13 -> 199
    //   189: aload_0
    //   190: aload_0
    //   191: getfield 128	com/sun/mail/imap/IMAPFolder:type	I
    //   194: iconst_1
    //   195: ior
    //   196: putfield 128	com/sun/mail/imap/IMAPFolder:type	I
    //   199: aload_0
    //   200: iconst_1
    //   201: putfield 133	com/sun/mail/imap/IMAPFolder:exists	Z
    //   204: aload_0
    //   205: aload 5
    //   207: iload_1
    //   208: aaload
    //   209: getfield 136	com/sun/mail/imap/protocol/ListInfo:attrs	[Ljava/lang/String;
    //   212: putfield 138	com/sun/mail/imap/IMAPFolder:attributes	[Ljava/lang/String;
    //   215: aload_0
    //   216: getfield 133	com/sun/mail/imap/IMAPFolder:exists	Z
    //   219: istore_3
    //   220: aload_0
    //   221: monitorexit
    //   222: iload_3
    //   223: ireturn
    //   224: aload_0
    //   225: getfield 178	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   228: astore 4
    //   230: goto -182 -> 48
    //   233: aload_0
    //   234: aload_0
    //   235: getfield 145	com/sun/mail/imap/IMAPFolder:opened	Z
    //   238: putfield 133	com/sun/mail/imap/IMAPFolder:exists	Z
    //   241: aload_0
    //   242: aconst_null
    //   243: putfield 138	com/sun/mail/imap/IMAPFolder:attributes	[Ljava/lang/String;
    //   246: goto -31 -> 215
    //   249: astore 4
    //   251: aload_0
    //   252: monitorexit
    //   253: aload 4
    //   255: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	256	0	this	IMAPFolder
    //   80	128	1	i	int
    //   110	38	2	j	int
    //   219	4	3	bool	boolean
    //   6	223	4	localObject1	Object
    //   249	5	4	localObject2	Object
    //   65	141	5	arrayOfListInfo	ListInfo[]
    // Exception table:
    //   from	to	target	type
    //   2	48	249	finally
    //   48	67	249	finally
    //   72	118	249	finally
    //   122	154	249	finally
    //   154	179	249	finally
    //   179	199	249	finally
    //   199	215	249	finally
    //   215	220	249	finally
    //   224	230	249	finally
    //   233	246	249	finally
  }
  
  public Message[] expunge()
    throws MessagingException
  {
    try
    {
      Message[] arrayOfMessage = expunge(null);
      return arrayOfMessage;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  /* Error */
  public Message[] expunge(Message[] paramArrayOfMessage)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 464	com/sun/mail/imap/IMAPFolder:checkOpened	()V
    //   6: new 604	java/util/Vector
    //   9: dup
    //   10: invokespecial 605	java/util/Vector:<init>	()V
    //   13: astore 6
    //   15: aload_1
    //   16: ifnull +27 -> 43
    //   19: new 607	javax/mail/FetchProfile
    //   22: dup
    //   23: invokespecial 608	javax/mail/FetchProfile:<init>	()V
    //   26: astore 5
    //   28: aload 5
    //   30: getstatic 614	javax/mail/UIDFolder$FetchProfileItem:UID	Ljavax/mail/UIDFolder$FetchProfileItem;
    //   33: invokevirtual 618	javax/mail/FetchProfile:add	(Ljavax/mail/FetchProfile$Item;)V
    //   36: aload_0
    //   37: aload_1
    //   38: aload 5
    //   40: invokevirtual 622	com/sun/mail/imap/IMAPFolder:fetch	([Ljavax/mail/Message;Ljavax/mail/FetchProfile;)V
    //   43: aload_0
    //   44: getfield 185	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   47: astore 5
    //   49: aload 5
    //   51: monitorenter
    //   52: aload_0
    //   53: iconst_0
    //   54: putfield 163	com/sun/mail/imap/IMAPFolder:doExpungeNotification	Z
    //   57: aload_0
    //   58: invokespecial 532	com/sun/mail/imap/IMAPFolder:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   61: astore 7
    //   63: aload_1
    //   64: ifnull +74 -> 138
    //   67: aload 7
    //   69: aload_1
    //   70: invokestatic 626	com/sun/mail/imap/Utility:toUIDSet	([Ljavax/mail/Message;)[Lcom/sun/mail/imap/protocol/UIDSet;
    //   73: invokevirtual 630	com/sun/mail/imap/protocol/IMAPProtocol:uidexpunge	([Lcom/sun/mail/imap/protocol/UIDSet;)V
    //   76: aload_0
    //   77: iconst_1
    //   78: putfield 163	com/sun/mail/imap/IMAPFolder:doExpungeNotification	Z
    //   81: iconst_0
    //   82: istore_2
    //   83: iload_2
    //   84: aload_0
    //   85: getfield 321	com/sun/mail/imap/IMAPFolder:messageCache	Ljava/util/Vector;
    //   88: invokevirtual 633	java/util/Vector:size	()I
    //   91: if_icmplt +152 -> 243
    //   94: aload 5
    //   96: monitorexit
    //   97: aload_0
    //   98: aload_0
    //   99: getfield 321	com/sun/mail/imap/IMAPFolder:messageCache	Ljava/util/Vector;
    //   102: invokevirtual 633	java/util/Vector:size	()I
    //   105: putfield 151	com/sun/mail/imap/IMAPFolder:total	I
    //   108: aload 6
    //   110: invokevirtual 633	java/util/Vector:size	()I
    //   113: anewarray 492	javax/mail/Message
    //   116: astore_1
    //   117: aload 6
    //   119: aload_1
    //   120: invokevirtual 637	java/util/Vector:copyInto	([Ljava/lang/Object;)V
    //   123: aload_1
    //   124: arraylength
    //   125: ifle +9 -> 134
    //   128: aload_0
    //   129: iconst_1
    //   130: aload_1
    //   131: invokevirtual 641	com/sun/mail/imap/IMAPFolder:notifyMessageRemovedListeners	(Z[Ljavax/mail/Message;)V
    //   134: aload_0
    //   135: monitorexit
    //   136: aload_1
    //   137: areturn
    //   138: aload 7
    //   140: invokevirtual 643	com/sun/mail/imap/protocol/IMAPProtocol:expunge	()V
    //   143: goto -67 -> 76
    //   146: astore_1
    //   147: aload_0
    //   148: getfield 285	com/sun/mail/imap/IMAPFolder:mode	I
    //   151: iconst_2
    //   152: if_icmpeq +50 -> 202
    //   155: new 241	java/lang/IllegalStateException
    //   158: dup
    //   159: new 253	java/lang/StringBuilder
    //   162: dup
    //   163: ldc_w 645
    //   166: invokespecial 258	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   169: aload_0
    //   170: getfield 178	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   173: invokevirtual 264	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   176: invokevirtual 268	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   179: invokespecial 244	java/lang/IllegalStateException:<init>	(Ljava/lang/String;)V
    //   182: athrow
    //   183: astore_1
    //   184: aload_0
    //   185: iconst_1
    //   186: putfield 163	com/sun/mail/imap/IMAPFolder:doExpungeNotification	Z
    //   189: aload_1
    //   190: athrow
    //   191: astore_1
    //   192: aload 5
    //   194: monitorexit
    //   195: aload_1
    //   196: athrow
    //   197: astore_1
    //   198: aload_0
    //   199: monitorexit
    //   200: aload_1
    //   201: athrow
    //   202: new 247	javax/mail/MessagingException
    //   205: dup
    //   206: aload_1
    //   207: invokevirtual 542	com/sun/mail/iap/CommandFailedException:getMessage	()Ljava/lang/String;
    //   210: aload_1
    //   211: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   214: athrow
    //   215: astore_1
    //   216: new 290	javax/mail/FolderClosedException
    //   219: dup
    //   220: aload_0
    //   221: aload_1
    //   222: invokevirtual 309	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   225: invokespecial 295	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   228: athrow
    //   229: astore_1
    //   230: new 247	javax/mail/MessagingException
    //   233: dup
    //   234: aload_1
    //   235: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   238: aload_1
    //   239: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   242: athrow
    //   243: aload_0
    //   244: getfield 321	com/sun/mail/imap/IMAPFolder:messageCache	Ljava/util/Vector;
    //   247: iload_2
    //   248: invokevirtual 649	java/util/Vector:elementAt	(I)Ljava/lang/Object;
    //   251: checkcast 651	com/sun/mail/imap/IMAPMessage
    //   254: astore_1
    //   255: aload_1
    //   256: invokevirtual 654	com/sun/mail/imap/IMAPMessage:isExpunged	()Z
    //   259: ifeq +56 -> 315
    //   262: aload 6
    //   264: aload_1
    //   265: invokevirtual 658	java/util/Vector:addElement	(Ljava/lang/Object;)V
    //   268: aload_0
    //   269: getfield 321	com/sun/mail/imap/IMAPFolder:messageCache	Ljava/util/Vector;
    //   272: iload_2
    //   273: invokevirtual 661	java/util/Vector:removeElementAt	(I)V
    //   276: aload_0
    //   277: getfield 323	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   280: ifnull -197 -> 83
    //   283: aload_1
    //   284: invokevirtual 664	com/sun/mail/imap/IMAPMessage:getUID	()J
    //   287: lstore_3
    //   288: lload_3
    //   289: ldc2_w 156
    //   292: lcmp
    //   293: ifeq -210 -> 83
    //   296: aload_0
    //   297: getfield 323	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   300: new 666	java/lang/Long
    //   303: dup
    //   304: lload_3
    //   305: invokespecial 669	java/lang/Long:<init>	(J)V
    //   308: invokevirtual 675	java/util/Hashtable:remove	(Ljava/lang/Object;)Ljava/lang/Object;
    //   311: pop
    //   312: goto -229 -> 83
    //   315: aload_1
    //   316: aload_1
    //   317: invokevirtual 678	com/sun/mail/imap/IMAPMessage:getSequenceNumber	()I
    //   320: invokevirtual 681	com/sun/mail/imap/IMAPMessage:setMessageNumber	(I)V
    //   323: iload_2
    //   324: iconst_1
    //   325: iadd
    //   326: istore_2
    //   327: goto -244 -> 83
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	330	0	this	IMAPFolder
    //   0	330	1	paramArrayOfMessage	Message[]
    //   82	245	2	i	int
    //   287	18	3	l	long
    //   26	167	5	localObject	Object
    //   13	250	6	localVector	Vector
    //   61	78	7	localIMAPProtocol	IMAPProtocol
    // Exception table:
    //   from	to	target	type
    //   57	63	146	com/sun/mail/iap/CommandFailedException
    //   67	76	146	com/sun/mail/iap/CommandFailedException
    //   138	143	146	com/sun/mail/iap/CommandFailedException
    //   57	63	183	finally
    //   67	76	183	finally
    //   138	143	183	finally
    //   147	183	183	finally
    //   202	215	183	finally
    //   216	229	183	finally
    //   230	243	183	finally
    //   52	57	191	finally
    //   76	81	191	finally
    //   83	97	191	finally
    //   184	191	191	finally
    //   192	195	191	finally
    //   243	288	191	finally
    //   296	312	191	finally
    //   315	323	191	finally
    //   2	15	197	finally
    //   19	43	197	finally
    //   43	52	197	finally
    //   97	134	197	finally
    //   195	197	197	finally
    //   57	63	215	com/sun/mail/iap/ConnectionException
    //   67	76	215	com/sun/mail/iap/ConnectionException
    //   138	143	215	com/sun/mail/iap/ConnectionException
    //   57	63	229	com/sun/mail/iap/ProtocolException
    //   67	76	229	com/sun/mail/iap/ProtocolException
    //   138	143	229	com/sun/mail/iap/ProtocolException
  }
  
  public void fetch(Message[] paramArrayOfMessage, FetchProfile paramFetchProfile)
    throws MessagingException
  {
    try
    {
      checkOpened();
      IMAPMessage.fetch(this, paramArrayOfMessage, paramFetchProfile);
      return;
    }
    finally
    {
      paramArrayOfMessage = finally;
      throw paramArrayOfMessage;
    }
  }
  
  public void forceClose()
    throws MessagingException
  {
    try
    {
      close(false, true);
      return;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public ACL[] getACL()
    throws MessagingException
  {
    (ACL[])doOptionalCommand("ACL not supported", new ProtocolCommand()
    {
      public Object doCommand(IMAPProtocol paramAnonymousIMAPProtocol)
        throws ProtocolException
      {
        return paramAnonymousIMAPProtocol.getACL(IMAPFolder.this.fullName);
      }
    });
  }
  
  public String[] getAttributes()
    throws MessagingException
  {
    if (this.attributes == null) {
      exists();
    }
    return (String[])this.attributes.clone();
  }
  
  /* Error */
  public int getDeletedMessageCount()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 145	com/sun/mail/imap/IMAPFolder:opened	Z
    //   6: ifne +13 -> 19
    //   9: aload_0
    //   10: invokespecial 369	com/sun/mail/imap/IMAPFolder:checkExists	()V
    //   13: iconst_m1
    //   14: istore_1
    //   15: aload_0
    //   16: monitorexit
    //   17: iload_1
    //   18: ireturn
    //   19: new 700	javax/mail/Flags
    //   22: dup
    //   23: invokespecial 701	javax/mail/Flags:<init>	()V
    //   26: astore_3
    //   27: aload_3
    //   28: getstatic 707	javax/mail/Flags$Flag:DELETED	Ljavax/mail/Flags$Flag;
    //   31: invokevirtual 710	javax/mail/Flags:add	(Ljavax/mail/Flags$Flag;)V
    //   34: aload_0
    //   35: getfield 185	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   38: astore_2
    //   39: aload_2
    //   40: monitorenter
    //   41: aload_0
    //   42: invokespecial 532	com/sun/mail/imap/IMAPFolder:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   45: new 712	javax/mail/search/FlagTerm
    //   48: dup
    //   49: aload_3
    //   50: iconst_1
    //   51: invokespecial 715	javax/mail/search/FlagTerm:<init>	(Ljavax/mail/Flags;Z)V
    //   54: invokevirtual 719	com/sun/mail/imap/protocol/IMAPProtocol:search	(Ljavax/mail/search/SearchTerm;)[I
    //   57: arraylength
    //   58: istore_1
    //   59: aload_2
    //   60: monitorexit
    //   61: goto -46 -> 15
    //   64: astore_3
    //   65: aload_2
    //   66: monitorexit
    //   67: aload_3
    //   68: athrow
    //   69: astore_2
    //   70: new 290	javax/mail/FolderClosedException
    //   73: dup
    //   74: aload_0
    //   75: aload_2
    //   76: invokevirtual 309	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   79: invokespecial 295	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   82: athrow
    //   83: astore_2
    //   84: aload_0
    //   85: monitorexit
    //   86: aload_2
    //   87: athrow
    //   88: astore_2
    //   89: new 247	javax/mail/MessagingException
    //   92: dup
    //   93: aload_2
    //   94: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   97: aload_2
    //   98: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   101: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	102	0	this	IMAPFolder
    //   14	45	1	i	int
    //   69	7	2	localConnectionException	ConnectionException
    //   83	4	2	localObject2	Object
    //   88	10	2	localProtocolException	ProtocolException
    //   26	24	3	localFlags	Flags
    //   64	4	3	localObject3	Object
    // Exception table:
    //   from	to	target	type
    //   41	61	64	finally
    //   65	67	64	finally
    //   34	41	69	com/sun/mail/iap/ConnectionException
    //   67	69	69	com/sun/mail/iap/ConnectionException
    //   2	13	83	finally
    //   19	34	83	finally
    //   34	41	83	finally
    //   67	69	83	finally
    //   70	83	83	finally
    //   89	102	83	finally
    //   34	41	88	com/sun/mail/iap/ProtocolException
    //   67	69	88	com/sun/mail/iap/ProtocolException
  }
  
  public Folder getFolder(String paramString)
    throws MessagingException
  {
    if ((this.attributes != null) && (!isDirectory())) {
      throw new MessagingException("Cannot contain subfolders");
    }
    char c = getSeparator();
    return new IMAPFolder(this.fullName + c + paramString, c, (IMAPStore)this.store);
  }
  
  public String getFullName()
  {
    try
    {
      String str = this.fullName;
      return str;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public Message getMessage(int paramInt)
    throws MessagingException
  {
    try
    {
      checkOpened();
      checkRange(paramInt);
      Message localMessage = (Message)this.messageCache.elementAt(paramInt - 1);
      return localMessage;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  IMAPMessage getMessageBySeqNumber(int paramInt)
  {
    int i = paramInt - 1;
    for (;;)
    {
      Object localObject;
      if (i >= this.total) {
        localObject = null;
      }
      IMAPMessage localIMAPMessage;
      do
      {
        return (IMAPMessage)localObject;
        localIMAPMessage = (IMAPMessage)this.messageCache.elementAt(i);
        localObject = localIMAPMessage;
      } while (localIMAPMessage.getSequenceNumber() == paramInt);
      i += 1;
    }
  }
  
  /* Error */
  public Message getMessageByUID(long paramLong)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 464	com/sun/mail/imap/IMAPFolder:checkOpened	()V
    //   6: aconst_null
    //   7: astore_3
    //   8: aload_0
    //   9: getfield 185	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   12: astore 5
    //   14: aload 5
    //   16: monitorenter
    //   17: new 666	java/lang/Long
    //   20: dup
    //   21: lload_1
    //   22: invokespecial 669	java/lang/Long:<init>	(J)V
    //   25: astore 6
    //   27: aload_0
    //   28: getfield 323	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   31: ifnull +33 -> 64
    //   34: aload_0
    //   35: getfield 323	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   38: aload 6
    //   40: invokevirtual 732	java/util/Hashtable:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   43: checkcast 651	com/sun/mail/imap/IMAPMessage
    //   46: astore 4
    //   48: aload 4
    //   50: astore_3
    //   51: aload 4
    //   53: ifnull +22 -> 75
    //   56: aload 5
    //   58: monitorexit
    //   59: aload_0
    //   60: monitorexit
    //   61: aload 4
    //   63: areturn
    //   64: aload_0
    //   65: new 671	java/util/Hashtable
    //   68: dup
    //   69: invokespecial 733	java/util/Hashtable:<init>	()V
    //   72: putfield 323	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   75: aload_0
    //   76: invokespecial 532	com/sun/mail/imap/IMAPFolder:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   79: lload_1
    //   80: invokevirtual 737	com/sun/mail/imap/protocol/IMAPProtocol:fetchSequenceNumber	(J)Lcom/sun/mail/imap/protocol/UID;
    //   83: astore 7
    //   85: aload_3
    //   86: astore 4
    //   88: aload 7
    //   90: ifnull +51 -> 141
    //   93: aload_3
    //   94: astore 4
    //   96: aload 7
    //   98: getfield 742	com/sun/mail/imap/protocol/UID:seqnum	I
    //   101: aload_0
    //   102: getfield 151	com/sun/mail/imap/IMAPFolder:total	I
    //   105: if_icmpgt +36 -> 141
    //   108: aload_0
    //   109: aload 7
    //   111: getfield 742	com/sun/mail/imap/protocol/UID:seqnum	I
    //   114: invokevirtual 744	com/sun/mail/imap/IMAPFolder:getMessageBySeqNumber	(I)Lcom/sun/mail/imap/IMAPMessage;
    //   117: astore 4
    //   119: aload 4
    //   121: aload 7
    //   123: getfield 745	com/sun/mail/imap/protocol/UID:uid	J
    //   126: invokevirtual 748	com/sun/mail/imap/IMAPMessage:setUID	(J)V
    //   129: aload_0
    //   130: getfield 323	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   133: aload 6
    //   135: aload 4
    //   137: invokevirtual 752	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   140: pop
    //   141: aload 5
    //   143: monitorexit
    //   144: goto -85 -> 59
    //   147: astore_3
    //   148: aload 5
    //   150: monitorexit
    //   151: aload_3
    //   152: athrow
    //   153: astore_3
    //   154: new 290	javax/mail/FolderClosedException
    //   157: dup
    //   158: aload_0
    //   159: aload_3
    //   160: invokevirtual 309	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   163: invokespecial 295	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   166: athrow
    //   167: astore_3
    //   168: aload_0
    //   169: monitorexit
    //   170: aload_3
    //   171: athrow
    //   172: astore_3
    //   173: new 247	javax/mail/MessagingException
    //   176: dup
    //   177: aload_3
    //   178: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   181: aload_3
    //   182: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   185: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	186	0	this	IMAPFolder
    //   0	186	1	paramLong	long
    //   7	87	3	localObject1	Object
    //   147	5	3	localObject2	Object
    //   153	7	3	localConnectionException	ConnectionException
    //   167	4	3	localObject3	Object
    //   172	10	3	localProtocolException	ProtocolException
    //   46	90	4	localObject4	Object
    //   25	109	6	localLong	Long
    //   83	39	7	localUID	com.sun.mail.imap.protocol.UID
    // Exception table:
    //   from	to	target	type
    //   17	48	147	finally
    //   56	59	147	finally
    //   64	75	147	finally
    //   75	85	147	finally
    //   96	141	147	finally
    //   141	144	147	finally
    //   148	151	147	finally
    //   8	17	153	com/sun/mail/iap/ConnectionException
    //   151	153	153	com/sun/mail/iap/ConnectionException
    //   2	6	167	finally
    //   8	17	167	finally
    //   151	153	167	finally
    //   154	167	167	finally
    //   173	186	167	finally
    //   8	17	172	com/sun/mail/iap/ProtocolException
    //   151	153	172	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public int getMessageCount()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 145	com/sun/mail/imap/IMAPFolder:opened	Z
    //   6: ifne +142 -> 148
    //   9: aload_0
    //   10: invokespecial 369	com/sun/mail/imap/IMAPFolder:checkExists	()V
    //   13: aload_0
    //   14: invokespecial 233	com/sun/mail/imap/IMAPFolder:getStatus	()Lcom/sun/mail/imap/protocol/Status;
    //   17: getfield 756	com/sun/mail/imap/protocol/Status:total	I
    //   20: istore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: iload_1
    //   24: ireturn
    //   25: astore_2
    //   26: aconst_null
    //   27: astore_3
    //   28: aconst_null
    //   29: astore_2
    //   30: aload_0
    //   31: invokevirtual 407	com/sun/mail/imap/IMAPFolder:getStoreProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   34: astore 4
    //   36: aload 4
    //   38: astore_2
    //   39: aload 4
    //   41: astore_3
    //   42: aload 4
    //   44: aload_0
    //   45: getfield 178	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   48: invokevirtual 365	com/sun/mail/imap/protocol/IMAPProtocol:examine	(Ljava/lang/String;)Lcom/sun/mail/imap/protocol/MailboxInfo;
    //   51: astore 5
    //   53: aload 4
    //   55: astore_2
    //   56: aload 4
    //   58: astore_3
    //   59: aload 4
    //   61: invokevirtual 358	com/sun/mail/imap/protocol/IMAPProtocol:close	()V
    //   64: aload 4
    //   66: astore_2
    //   67: aload 4
    //   69: astore_3
    //   70: aload 5
    //   72: getfield 759	com/sun/mail/imap/protocol/MailboxInfo:total	I
    //   75: istore_1
    //   76: aload_0
    //   77: aload 4
    //   79: invokevirtual 415	com/sun/mail/imap/IMAPFolder:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   82: goto -61 -> 21
    //   85: astore_2
    //   86: aload_0
    //   87: monitorexit
    //   88: aload_2
    //   89: athrow
    //   90: astore 4
    //   92: aload_2
    //   93: astore_3
    //   94: new 247	javax/mail/MessagingException
    //   97: dup
    //   98: aload 4
    //   100: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   103: aload 4
    //   105: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   108: athrow
    //   109: astore_2
    //   110: aload_0
    //   111: aload_3
    //   112: invokevirtual 415	com/sun/mail/imap/IMAPFolder:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   115: aload_2
    //   116: athrow
    //   117: astore_2
    //   118: new 450	javax/mail/StoreClosedException
    //   121: dup
    //   122: aload_0
    //   123: getfield 351	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   126: aload_2
    //   127: invokevirtual 309	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   130: invokespecial 456	javax/mail/StoreClosedException:<init>	(Ljavax/mail/Store;Ljava/lang/String;)V
    //   133: athrow
    //   134: astore_2
    //   135: new 247	javax/mail/MessagingException
    //   138: dup
    //   139: aload_2
    //   140: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   143: aload_2
    //   144: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   147: athrow
    //   148: aload_0
    //   149: getfield 185	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   152: astore_2
    //   153: aload_2
    //   154: monitorenter
    //   155: aload_0
    //   156: iconst_1
    //   157: invokespecial 306	com/sun/mail/imap/IMAPFolder:keepConnectionAlive	(Z)V
    //   160: aload_0
    //   161: getfield 151	com/sun/mail/imap/IMAPFolder:total	I
    //   164: istore_1
    //   165: aload_2
    //   166: monitorexit
    //   167: goto -146 -> 21
    //   170: astore_3
    //   171: aload_2
    //   172: monitorexit
    //   173: aload_3
    //   174: athrow
    //   175: astore_3
    //   176: new 290	javax/mail/FolderClosedException
    //   179: dup
    //   180: aload_0
    //   181: aload_3
    //   182: invokevirtual 309	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   185: invokespecial 295	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   188: athrow
    //   189: astore_3
    //   190: new 247	javax/mail/MessagingException
    //   193: dup
    //   194: aload_3
    //   195: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   198: aload_3
    //   199: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   202: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	203	0	this	IMAPFolder
    //   20	145	1	i	int
    //   25	1	2	localBadCommandException	BadCommandException
    //   29	38	2	localObject1	Object
    //   85	8	2	localObject2	Object
    //   109	7	2	localObject3	Object
    //   117	10	2	localConnectionException1	ConnectionException
    //   134	10	2	localProtocolException1	ProtocolException
    //   27	85	3	localObject5	Object
    //   170	4	3	localObject6	Object
    //   175	7	3	localConnectionException2	ConnectionException
    //   189	10	3	localProtocolException2	ProtocolException
    //   34	44	4	localIMAPProtocol	IMAPProtocol
    //   90	14	4	localProtocolException3	ProtocolException
    //   51	20	5	localMailboxInfo	com.sun.mail.imap.protocol.MailboxInfo
    // Exception table:
    //   from	to	target	type
    //   13	21	25	com/sun/mail/iap/BadCommandException
    //   2	13	85	finally
    //   13	21	85	finally
    //   76	82	85	finally
    //   110	117	85	finally
    //   118	134	85	finally
    //   135	148	85	finally
    //   148	155	85	finally
    //   173	175	85	finally
    //   30	36	90	com/sun/mail/iap/ProtocolException
    //   42	53	90	com/sun/mail/iap/ProtocolException
    //   59	64	90	com/sun/mail/iap/ProtocolException
    //   70	76	90	com/sun/mail/iap/ProtocolException
    //   30	36	109	finally
    //   42	53	109	finally
    //   59	64	109	finally
    //   70	76	109	finally
    //   94	109	109	finally
    //   13	21	117	com/sun/mail/iap/ConnectionException
    //   13	21	134	com/sun/mail/iap/ProtocolException
    //   155	165	170	finally
    //   165	167	170	finally
    //   171	173	170	finally
    //   176	189	170	finally
    //   190	203	170	finally
    //   155	165	175	com/sun/mail/iap/ConnectionException
    //   155	165	189	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public Message[] getMessagesByUID(long paramLong1, long paramLong2)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 464	com/sun/mail/imap/IMAPFolder:checkOpened	()V
    //   6: aload_0
    //   7: getfield 185	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   10: astore 6
    //   12: aload 6
    //   14: monitorenter
    //   15: aload_0
    //   16: getfield 323	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   19: ifnonnull +14 -> 33
    //   22: aload_0
    //   23: new 671	java/util/Hashtable
    //   26: dup
    //   27: invokespecial 733	java/util/Hashtable:<init>	()V
    //   30: putfield 323	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   33: aload_0
    //   34: invokespecial 532	com/sun/mail/imap/IMAPFolder:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   37: lload_1
    //   38: lload_3
    //   39: invokevirtual 765	com/sun/mail/imap/protocol/IMAPProtocol:fetchSequenceNumbers	(JJ)[Lcom/sun/mail/imap/protocol/UID;
    //   42: astore 7
    //   44: aload 7
    //   46: arraylength
    //   47: anewarray 492	javax/mail/Message
    //   50: astore 8
    //   52: iconst_0
    //   53: istore 5
    //   55: iload 5
    //   57: aload 7
    //   59: arraylength
    //   60: if_icmplt +11 -> 71
    //   63: aload 6
    //   65: monitorexit
    //   66: aload_0
    //   67: monitorexit
    //   68: aload 8
    //   70: areturn
    //   71: aload_0
    //   72: aload 7
    //   74: iload 5
    //   76: aaload
    //   77: getfield 742	com/sun/mail/imap/protocol/UID:seqnum	I
    //   80: invokevirtual 744	com/sun/mail/imap/IMAPFolder:getMessageBySeqNumber	(I)Lcom/sun/mail/imap/IMAPMessage;
    //   83: astore 9
    //   85: aload 9
    //   87: aload 7
    //   89: iload 5
    //   91: aaload
    //   92: getfield 745	com/sun/mail/imap/protocol/UID:uid	J
    //   95: invokevirtual 748	com/sun/mail/imap/IMAPMessage:setUID	(J)V
    //   98: aload 8
    //   100: iload 5
    //   102: aload 9
    //   104: aastore
    //   105: aload_0
    //   106: getfield 323	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   109: new 666	java/lang/Long
    //   112: dup
    //   113: aload 7
    //   115: iload 5
    //   117: aaload
    //   118: getfield 745	com/sun/mail/imap/protocol/UID:uid	J
    //   121: invokespecial 669	java/lang/Long:<init>	(J)V
    //   124: aload 9
    //   126: invokevirtual 752	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   129: pop
    //   130: iload 5
    //   132: iconst_1
    //   133: iadd
    //   134: istore 5
    //   136: goto -81 -> 55
    //   139: astore 7
    //   141: aload 6
    //   143: monitorexit
    //   144: aload 7
    //   146: athrow
    //   147: astore 6
    //   149: new 290	javax/mail/FolderClosedException
    //   152: dup
    //   153: aload_0
    //   154: aload 6
    //   156: invokevirtual 309	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   159: invokespecial 295	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   162: athrow
    //   163: astore 6
    //   165: aload_0
    //   166: monitorexit
    //   167: aload 6
    //   169: athrow
    //   170: astore 6
    //   172: new 247	javax/mail/MessagingException
    //   175: dup
    //   176: aload 6
    //   178: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   181: aload 6
    //   183: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   186: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	187	0	this	IMAPFolder
    //   0	187	1	paramLong1	long
    //   0	187	3	paramLong2	long
    //   53	82	5	i	int
    //   147	8	6	localConnectionException	ConnectionException
    //   163	5	6	localObject2	Object
    //   170	12	6	localProtocolException	ProtocolException
    //   42	72	7	arrayOfUID	com.sun.mail.imap.protocol.UID[]
    //   139	6	7	localObject3	Object
    //   50	49	8	arrayOfMessage	Message[]
    //   83	42	9	localIMAPMessage	IMAPMessage
    // Exception table:
    //   from	to	target	type
    //   15	33	139	finally
    //   33	52	139	finally
    //   55	66	139	finally
    //   71	98	139	finally
    //   105	130	139	finally
    //   141	144	139	finally
    //   6	15	147	com/sun/mail/iap/ConnectionException
    //   144	147	147	com/sun/mail/iap/ConnectionException
    //   2	6	163	finally
    //   6	15	163	finally
    //   144	147	163	finally
    //   149	163	163	finally
    //   172	187	163	finally
    //   6	15	170	com/sun/mail/iap/ProtocolException
    //   144	147	170	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public Message[] getMessagesByUID(long[] paramArrayOfLong)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 464	com/sun/mail/imap/IMAPFolder:checkOpened	()V
    //   6: aload_0
    //   7: getfield 185	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   10: astore 5
    //   12: aload 5
    //   14: monitorenter
    //   15: aload_1
    //   16: astore 4
    //   18: aload_0
    //   19: getfield 323	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   22: ifnull +146 -> 168
    //   25: new 604	java/util/Vector
    //   28: dup
    //   29: invokespecial 605	java/util/Vector:<init>	()V
    //   32: astore 6
    //   34: iconst_0
    //   35: istore_2
    //   36: iload_2
    //   37: aload_1
    //   38: arraylength
    //   39: if_icmplt +68 -> 107
    //   42: aload 6
    //   44: invokevirtual 633	java/util/Vector:size	()I
    //   47: istore_3
    //   48: iload_3
    //   49: newarray <illegal type>
    //   51: astore 4
    //   53: iconst_0
    //   54: istore_2
    //   55: goto +253 -> 308
    //   58: aload 4
    //   60: arraylength
    //   61: ifle +23 -> 84
    //   64: aload_0
    //   65: invokespecial 532	com/sun/mail/imap/IMAPFolder:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   68: aload 4
    //   70: invokevirtual 769	com/sun/mail/imap/protocol/IMAPProtocol:fetchSequenceNumbers	([J)[Lcom/sun/mail/imap/protocol/UID;
    //   73: astore 4
    //   75: iconst_0
    //   76: istore_2
    //   77: iload_2
    //   78: aload 4
    //   80: arraylength
    //   81: if_icmplt +126 -> 207
    //   84: aload_1
    //   85: arraylength
    //   86: anewarray 492	javax/mail/Message
    //   89: astore 4
    //   91: iconst_0
    //   92: istore_2
    //   93: iload_2
    //   94: aload_1
    //   95: arraylength
    //   96: if_icmplt +167 -> 263
    //   99: aload 5
    //   101: monitorexit
    //   102: aload_0
    //   103: monitorexit
    //   104: aload 4
    //   106: areturn
    //   107: aload_0
    //   108: getfield 323	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   111: astore 4
    //   113: new 666	java/lang/Long
    //   116: dup
    //   117: aload_1
    //   118: iload_2
    //   119: laload
    //   120: invokespecial 669	java/lang/Long:<init>	(J)V
    //   123: astore 7
    //   125: aload 4
    //   127: aload 7
    //   129: invokevirtual 772	java/util/Hashtable:containsKey	(Ljava/lang/Object;)Z
    //   132: ifne +184 -> 316
    //   135: aload 6
    //   137: aload 7
    //   139: invokevirtual 658	java/util/Vector:addElement	(Ljava/lang/Object;)V
    //   142: goto +174 -> 316
    //   145: aload 4
    //   147: iload_2
    //   148: aload 6
    //   150: iload_2
    //   151: invokevirtual 649	java/util/Vector:elementAt	(I)Ljava/lang/Object;
    //   154: checkcast 666	java/lang/Long
    //   157: invokevirtual 775	java/lang/Long:longValue	()J
    //   160: lastore
    //   161: iload_2
    //   162: iconst_1
    //   163: iadd
    //   164: istore_2
    //   165: goto +143 -> 308
    //   168: aload_0
    //   169: new 671	java/util/Hashtable
    //   172: dup
    //   173: invokespecial 733	java/util/Hashtable:<init>	()V
    //   176: putfield 323	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   179: goto -121 -> 58
    //   182: astore_1
    //   183: aload 5
    //   185: monitorexit
    //   186: aload_1
    //   187: athrow
    //   188: astore_1
    //   189: new 290	javax/mail/FolderClosedException
    //   192: dup
    //   193: aload_0
    //   194: aload_1
    //   195: invokevirtual 309	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   198: invokespecial 295	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   201: athrow
    //   202: astore_1
    //   203: aload_0
    //   204: monitorexit
    //   205: aload_1
    //   206: athrow
    //   207: aload_0
    //   208: aload 4
    //   210: iload_2
    //   211: aaload
    //   212: getfield 742	com/sun/mail/imap/protocol/UID:seqnum	I
    //   215: invokevirtual 744	com/sun/mail/imap/IMAPFolder:getMessageBySeqNumber	(I)Lcom/sun/mail/imap/IMAPMessage;
    //   218: astore 6
    //   220: aload 6
    //   222: aload 4
    //   224: iload_2
    //   225: aaload
    //   226: getfield 745	com/sun/mail/imap/protocol/UID:uid	J
    //   229: invokevirtual 748	com/sun/mail/imap/IMAPMessage:setUID	(J)V
    //   232: aload_0
    //   233: getfield 323	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   236: new 666	java/lang/Long
    //   239: dup
    //   240: aload 4
    //   242: iload_2
    //   243: aaload
    //   244: getfield 745	com/sun/mail/imap/protocol/UID:uid	J
    //   247: invokespecial 669	java/lang/Long:<init>	(J)V
    //   250: aload 6
    //   252: invokevirtual 752	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   255: pop
    //   256: iload_2
    //   257: iconst_1
    //   258: iadd
    //   259: istore_2
    //   260: goto -183 -> 77
    //   263: aload 4
    //   265: iload_2
    //   266: aload_0
    //   267: getfield 323	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   270: new 666	java/lang/Long
    //   273: dup
    //   274: aload_1
    //   275: iload_2
    //   276: laload
    //   277: invokespecial 669	java/lang/Long:<init>	(J)V
    //   280: invokevirtual 732	java/util/Hashtable:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   283: checkcast 492	javax/mail/Message
    //   286: aastore
    //   287: iload_2
    //   288: iconst_1
    //   289: iadd
    //   290: istore_2
    //   291: goto -198 -> 93
    //   294: astore_1
    //   295: new 247	javax/mail/MessagingException
    //   298: dup
    //   299: aload_1
    //   300: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   303: aload_1
    //   304: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   307: athrow
    //   308: iload_2
    //   309: iload_3
    //   310: if_icmplt -165 -> 145
    //   313: goto -255 -> 58
    //   316: iload_2
    //   317: iconst_1
    //   318: iadd
    //   319: istore_2
    //   320: goto -284 -> 36
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	323	0	this	IMAPFolder
    //   0	323	1	paramArrayOfLong	long[]
    //   35	285	2	i	int
    //   47	264	3	j	int
    //   16	248	4	localObject1	Object
    //   10	174	5	localObject2	Object
    //   32	219	6	localObject3	Object
    //   123	15	7	localLong	Long
    // Exception table:
    //   from	to	target	type
    //   18	34	182	finally
    //   36	53	182	finally
    //   58	75	182	finally
    //   77	84	182	finally
    //   84	91	182	finally
    //   93	102	182	finally
    //   107	142	182	finally
    //   145	161	182	finally
    //   168	179	182	finally
    //   183	186	182	finally
    //   207	256	182	finally
    //   263	287	182	finally
    //   6	15	188	com/sun/mail/iap/ConnectionException
    //   186	188	188	com/sun/mail/iap/ConnectionException
    //   2	6	202	finally
    //   6	15	202	finally
    //   186	188	202	finally
    //   189	202	202	finally
    //   295	308	202	finally
    //   6	15	294	com/sun/mail/iap/ProtocolException
    //   186	188	294	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public String getName()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 777	com/sun/mail/imap/IMAPFolder:name	Ljava/lang/String;
    //   6: astore_1
    //   7: aload_1
    //   8: ifnonnull +27 -> 35
    //   11: aload_0
    //   12: aload_0
    //   13: getfield 178	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   16: aload_0
    //   17: getfield 178	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   20: aload_0
    //   21: invokevirtual 376	com/sun/mail/imap/IMAPFolder:getSeparator	()C
    //   24: invokevirtual 780	java/lang/String:lastIndexOf	(I)I
    //   27: iconst_1
    //   28: iadd
    //   29: invokevirtual 783	java/lang/String:substring	(I)Ljava/lang/String;
    //   32: putfield 777	com/sun/mail/imap/IMAPFolder:name	Ljava/lang/String;
    //   35: aload_0
    //   36: getfield 777	com/sun/mail/imap/IMAPFolder:name	Ljava/lang/String;
    //   39: astore_1
    //   40: aload_0
    //   41: monitorexit
    //   42: aload_1
    //   43: areturn
    //   44: astore_1
    //   45: aload_0
    //   46: monitorexit
    //   47: aload_1
    //   48: athrow
    //   49: astore_1
    //   50: goto -15 -> 35
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	53	0	this	IMAPFolder
    //   6	37	1	str	String
    //   44	4	1	localObject	Object
    //   49	1	1	localMessagingException	MessagingException
    // Exception table:
    //   from	to	target	type
    //   2	7	44	finally
    //   11	35	44	finally
    //   35	40	44	finally
    //   11	35	49	javax/mail/MessagingException
  }
  
  /* Error */
  public int getNewMessageCount()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 145	com/sun/mail/imap/IMAPFolder:opened	Z
    //   6: ifne +142 -> 148
    //   9: aload_0
    //   10: invokespecial 369	com/sun/mail/imap/IMAPFolder:checkExists	()V
    //   13: aload_0
    //   14: invokespecial 233	com/sun/mail/imap/IMAPFolder:getStatus	()Lcom/sun/mail/imap/protocol/Status;
    //   17: getfield 785	com/sun/mail/imap/protocol/Status:recent	I
    //   20: istore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: iload_1
    //   24: ireturn
    //   25: astore_2
    //   26: aconst_null
    //   27: astore_3
    //   28: aconst_null
    //   29: astore_2
    //   30: aload_0
    //   31: invokevirtual 407	com/sun/mail/imap/IMAPFolder:getStoreProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   34: astore 4
    //   36: aload 4
    //   38: astore_2
    //   39: aload 4
    //   41: astore_3
    //   42: aload 4
    //   44: aload_0
    //   45: getfield 178	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   48: invokevirtual 365	com/sun/mail/imap/protocol/IMAPProtocol:examine	(Ljava/lang/String;)Lcom/sun/mail/imap/protocol/MailboxInfo;
    //   51: astore 5
    //   53: aload 4
    //   55: astore_2
    //   56: aload 4
    //   58: astore_3
    //   59: aload 4
    //   61: invokevirtual 358	com/sun/mail/imap/protocol/IMAPProtocol:close	()V
    //   64: aload 4
    //   66: astore_2
    //   67: aload 4
    //   69: astore_3
    //   70: aload 5
    //   72: getfield 786	com/sun/mail/imap/protocol/MailboxInfo:recent	I
    //   75: istore_1
    //   76: aload_0
    //   77: aload 4
    //   79: invokevirtual 415	com/sun/mail/imap/IMAPFolder:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   82: goto -61 -> 21
    //   85: astore_2
    //   86: aload_0
    //   87: monitorexit
    //   88: aload_2
    //   89: athrow
    //   90: astore 4
    //   92: aload_2
    //   93: astore_3
    //   94: new 247	javax/mail/MessagingException
    //   97: dup
    //   98: aload 4
    //   100: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   103: aload 4
    //   105: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   108: athrow
    //   109: astore_2
    //   110: aload_0
    //   111: aload_3
    //   112: invokevirtual 415	com/sun/mail/imap/IMAPFolder:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   115: aload_2
    //   116: athrow
    //   117: astore_2
    //   118: new 450	javax/mail/StoreClosedException
    //   121: dup
    //   122: aload_0
    //   123: getfield 351	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   126: aload_2
    //   127: invokevirtual 309	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   130: invokespecial 456	javax/mail/StoreClosedException:<init>	(Ljavax/mail/Store;Ljava/lang/String;)V
    //   133: athrow
    //   134: astore_2
    //   135: new 247	javax/mail/MessagingException
    //   138: dup
    //   139: aload_2
    //   140: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   143: aload_2
    //   144: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   147: athrow
    //   148: aload_0
    //   149: getfield 185	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   152: astore_2
    //   153: aload_2
    //   154: monitorenter
    //   155: aload_0
    //   156: iconst_1
    //   157: invokespecial 306	com/sun/mail/imap/IMAPFolder:keepConnectionAlive	(Z)V
    //   160: aload_0
    //   161: getfield 153	com/sun/mail/imap/IMAPFolder:recent	I
    //   164: istore_1
    //   165: aload_2
    //   166: monitorexit
    //   167: goto -146 -> 21
    //   170: astore_3
    //   171: aload_2
    //   172: monitorexit
    //   173: aload_3
    //   174: athrow
    //   175: astore_3
    //   176: new 290	javax/mail/FolderClosedException
    //   179: dup
    //   180: aload_0
    //   181: aload_3
    //   182: invokevirtual 309	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   185: invokespecial 295	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   188: athrow
    //   189: astore_3
    //   190: new 247	javax/mail/MessagingException
    //   193: dup
    //   194: aload_3
    //   195: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   198: aload_3
    //   199: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   202: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	203	0	this	IMAPFolder
    //   20	145	1	i	int
    //   25	1	2	localBadCommandException	BadCommandException
    //   29	38	2	localObject1	Object
    //   85	8	2	localObject2	Object
    //   109	7	2	localObject3	Object
    //   117	10	2	localConnectionException1	ConnectionException
    //   134	10	2	localProtocolException1	ProtocolException
    //   27	85	3	localObject5	Object
    //   170	4	3	localObject6	Object
    //   175	7	3	localConnectionException2	ConnectionException
    //   189	10	3	localProtocolException2	ProtocolException
    //   34	44	4	localIMAPProtocol	IMAPProtocol
    //   90	14	4	localProtocolException3	ProtocolException
    //   51	20	5	localMailboxInfo	com.sun.mail.imap.protocol.MailboxInfo
    // Exception table:
    //   from	to	target	type
    //   13	21	25	com/sun/mail/iap/BadCommandException
    //   2	13	85	finally
    //   13	21	85	finally
    //   76	82	85	finally
    //   110	117	85	finally
    //   118	134	85	finally
    //   135	148	85	finally
    //   148	155	85	finally
    //   173	175	85	finally
    //   30	36	90	com/sun/mail/iap/ProtocolException
    //   42	53	90	com/sun/mail/iap/ProtocolException
    //   59	64	90	com/sun/mail/iap/ProtocolException
    //   70	76	90	com/sun/mail/iap/ProtocolException
    //   30	36	109	finally
    //   42	53	109	finally
    //   59	64	109	finally
    //   70	76	109	finally
    //   94	109	109	finally
    //   13	21	117	com/sun/mail/iap/ConnectionException
    //   13	21	134	com/sun/mail/iap/ProtocolException
    //   155	165	170	finally
    //   165	167	170	finally
    //   171	173	170	finally
    //   176	189	170	finally
    //   190	203	170	finally
    //   155	165	175	com/sun/mail/iap/ConnectionException
    //   155	165	189	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public Folder getParent()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual 376	com/sun/mail/imap/IMAPFolder:getSeparator	()C
    //   6: istore_1
    //   7: aload_0
    //   8: getfield 178	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   11: iload_1
    //   12: invokevirtual 780	java/lang/String:lastIndexOf	(I)I
    //   15: istore_2
    //   16: iload_2
    //   17: iconst_m1
    //   18: if_icmpeq +32 -> 50
    //   21: new 2	com/sun/mail/imap/IMAPFolder
    //   24: dup
    //   25: aload_0
    //   26: getfield 178	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   29: iconst_0
    //   30: iload_2
    //   31: invokevirtual 224	java/lang/String:substring	(II)Ljava/lang/String;
    //   34: iload_1
    //   35: aload_0
    //   36: getfield 351	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   39: checkcast 187	com/sun/mail/imap/IMAPStore
    //   42: invokespecial 123	com/sun/mail/imap/IMAPFolder:<init>	(Ljava/lang/String;CLcom/sun/mail/imap/IMAPStore;)V
    //   45: astore_3
    //   46: aload_0
    //   47: monitorexit
    //   48: aload_3
    //   49: areturn
    //   50: new 790	com/sun/mail/imap/DefaultFolder
    //   53: dup
    //   54: aload_0
    //   55: getfield 351	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   58: checkcast 187	com/sun/mail/imap/IMAPStore
    //   61: invokespecial 793	com/sun/mail/imap/DefaultFolder:<init>	(Lcom/sun/mail/imap/IMAPStore;)V
    //   64: astore_3
    //   65: goto -19 -> 46
    //   68: astore_3
    //   69: aload_0
    //   70: monitorexit
    //   71: aload_3
    //   72: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	73	0	this	IMAPFolder
    //   6	29	1	c	char
    //   15	16	2	i	int
    //   45	20	3	localObject1	Object
    //   68	4	3	localObject2	Object
    // Exception table:
    //   from	to	target	type
    //   2	16	68	finally
    //   21	46	68	finally
    //   50	65	68	finally
  }
  
  public Flags getPermanentFlags()
  {
    try
    {
      Flags localFlags = (Flags)this.permanentFlags.clone();
      return localFlags;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public Quota[] getQuota()
    throws MessagingException
  {
    (Quota[])doOptionalCommand("QUOTA not supported", new ProtocolCommand()
    {
      public Object doCommand(IMAPProtocol paramAnonymousIMAPProtocol)
        throws ProtocolException
      {
        return paramAnonymousIMAPProtocol.getQuotaRoot(IMAPFolder.this.fullName);
      }
    });
  }
  
  /* Error */
  public char getSeparator()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 179	com/sun/mail/imap/IMAPFolder:separator	C
    //   6: ldc 64
    //   8: if_icmpne +38 -> 46
    //   11: aconst_null
    //   12: checkcast 385	[Lcom/sun/mail/imap/protocol/ListInfo;
    //   15: astore_2
    //   16: aload_0
    //   17: new 34	com/sun/mail/imap/IMAPFolder$3
    //   20: dup
    //   21: aload_0
    //   22: invokespecial 805	com/sun/mail/imap/IMAPFolder$3:<init>	(Lcom/sun/mail/imap/IMAPFolder;)V
    //   25: invokevirtual 517	com/sun/mail/imap/IMAPFolder:doCommand	(Lcom/sun/mail/imap/IMAPFolder$ProtocolCommand;)Ljava/lang/Object;
    //   28: checkcast 385	[Lcom/sun/mail/imap/protocol/ListInfo;
    //   31: astore_2
    //   32: aload_2
    //   33: ifnull +22 -> 55
    //   36: aload_0
    //   37: aload_2
    //   38: iconst_0
    //   39: aaload
    //   40: getfield 120	com/sun/mail/imap/protocol/ListInfo:separator	C
    //   43: putfield 179	com/sun/mail/imap/IMAPFolder:separator	C
    //   46: aload_0
    //   47: getfield 179	com/sun/mail/imap/IMAPFolder:separator	C
    //   50: istore_1
    //   51: aload_0
    //   52: monitorexit
    //   53: iload_1
    //   54: ireturn
    //   55: aload_0
    //   56: bipush 47
    //   58: putfield 179	com/sun/mail/imap/IMAPFolder:separator	C
    //   61: goto -15 -> 46
    //   64: astore_2
    //   65: aload_0
    //   66: monitorexit
    //   67: aload_2
    //   68: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	69	0	this	IMAPFolder
    //   50	4	1	c	char
    //   15	23	2	arrayOfListInfo	ListInfo[]
    //   64	4	2	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   2	32	64	finally
    //   36	46	64	finally
    //   46	51	64	finally
    //   55	61	64	finally
  }
  
  protected IMAPProtocol getStoreProtocol()
    throws ProtocolException
  {
    try
    {
      if (this.connectionPoolDebug) {
        this.out.println("DEBUG: getStoreProtocol() - borrowing a connection");
      }
      IMAPProtocol localIMAPProtocol = ((IMAPStore)this.store).getStoreProtocol();
      return localIMAPProtocol;
    }
    finally {}
  }
  
  /* Error */
  public int getType()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 145	com/sun/mail/imap/IMAPFolder:opened	Z
    //   6: ifeq +24 -> 30
    //   9: aload_0
    //   10: getfield 138	com/sun/mail/imap/IMAPFolder:attributes	[Ljava/lang/String;
    //   13: ifnonnull +8 -> 21
    //   16: aload_0
    //   17: invokevirtual 249	com/sun/mail/imap/IMAPFolder:exists	()Z
    //   20: pop
    //   21: aload_0
    //   22: getfield 128	com/sun/mail/imap/IMAPFolder:type	I
    //   25: istore_1
    //   26: aload_0
    //   27: monitorexit
    //   28: iload_1
    //   29: ireturn
    //   30: aload_0
    //   31: invokespecial 369	com/sun/mail/imap/IMAPFolder:checkExists	()V
    //   34: goto -13 -> 21
    //   37: astore_2
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_2
    //   41: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	42	0	this	IMAPFolder
    //   25	4	1	i	int
    //   37	4	2	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   2	21	37	finally
    //   21	26	37	finally
    //   30	34	37	finally
  }
  
  /* Error */
  public long getUID(Message arg1)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: invokevirtual 811	javax/mail/Message:getFolder	()Ljavax/mail/Folder;
    //   6: aload_0
    //   7: if_acmpeq +19 -> 26
    //   10: new 813	java/util/NoSuchElementException
    //   13: dup
    //   14: ldc_w 815
    //   17: invokespecial 816	java/util/NoSuchElementException:<init>	(Ljava/lang/String;)V
    //   20: athrow
    //   21: astore_1
    //   22: aload_0
    //   23: monitorexit
    //   24: aload_1
    //   25: athrow
    //   26: aload_0
    //   27: invokespecial 464	com/sun/mail/imap/IMAPFolder:checkOpened	()V
    //   30: aload_1
    //   31: checkcast 651	com/sun/mail/imap/IMAPMessage
    //   34: astore 4
    //   36: aload 4
    //   38: invokevirtual 664	com/sun/mail/imap/IMAPMessage:getUID	()J
    //   41: lstore_2
    //   42: lload_2
    //   43: ldc2_w 156
    //   46: lcmp
    //   47: ifeq +7 -> 54
    //   50: aload_0
    //   51: monitorexit
    //   52: lload_2
    //   53: lreturn
    //   54: aload_0
    //   55: getfield 185	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   58: astore_1
    //   59: aload_1
    //   60: monitorenter
    //   61: aload_0
    //   62: invokespecial 532	com/sun/mail/imap/IMAPFolder:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   65: astore 5
    //   67: aload 4
    //   69: invokevirtual 819	com/sun/mail/imap/IMAPMessage:checkExpunged	()V
    //   72: aload 5
    //   74: aload 4
    //   76: invokevirtual 678	com/sun/mail/imap/IMAPMessage:getSequenceNumber	()I
    //   79: invokevirtual 823	com/sun/mail/imap/protocol/IMAPProtocol:fetchUID	(I)Lcom/sun/mail/imap/protocol/UID;
    //   82: astore 5
    //   84: aload 5
    //   86: ifnull +51 -> 137
    //   89: aload 5
    //   91: getfield 745	com/sun/mail/imap/protocol/UID:uid	J
    //   94: lstore_2
    //   95: aload 4
    //   97: lload_2
    //   98: invokevirtual 748	com/sun/mail/imap/IMAPMessage:setUID	(J)V
    //   101: aload_0
    //   102: getfield 323	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   105: ifnonnull +14 -> 119
    //   108: aload_0
    //   109: new 671	java/util/Hashtable
    //   112: dup
    //   113: invokespecial 733	java/util/Hashtable:<init>	()V
    //   116: putfield 323	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   119: aload_0
    //   120: getfield 323	com/sun/mail/imap/IMAPFolder:uidTable	Ljava/util/Hashtable;
    //   123: new 666	java/lang/Long
    //   126: dup
    //   127: lload_2
    //   128: invokespecial 669	java/lang/Long:<init>	(J)V
    //   131: aload 4
    //   133: invokevirtual 752	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   136: pop
    //   137: aload_1
    //   138: monitorexit
    //   139: goto -89 -> 50
    //   142: astore 4
    //   144: new 290	javax/mail/FolderClosedException
    //   147: dup
    //   148: aload_0
    //   149: aload 4
    //   151: invokevirtual 309	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   154: invokespecial 295	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   157: athrow
    //   158: astore 4
    //   160: aload_1
    //   161: monitorexit
    //   162: aload 4
    //   164: athrow
    //   165: astore 4
    //   167: new 247	javax/mail/MessagingException
    //   170: dup
    //   171: aload 4
    //   173: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   176: aload 4
    //   178: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   181: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	182	0	this	IMAPFolder
    //   41	87	2	l	long
    //   34	98	4	localIMAPMessage	IMAPMessage
    //   142	8	4	localConnectionException	ConnectionException
    //   158	5	4	localObject1	Object
    //   165	12	4	localProtocolException	ProtocolException
    //   65	25	5	localObject2	Object
    // Exception table:
    //   from	to	target	type
    //   2	21	21	finally
    //   26	42	21	finally
    //   54	61	21	finally
    //   162	165	21	finally
    //   61	84	142	com/sun/mail/iap/ConnectionException
    //   89	119	142	com/sun/mail/iap/ConnectionException
    //   119	137	142	com/sun/mail/iap/ConnectionException
    //   61	84	158	finally
    //   89	119	158	finally
    //   119	137	158	finally
    //   137	139	158	finally
    //   144	158	158	finally
    //   160	162	158	finally
    //   167	182	158	finally
    //   61	84	165	com/sun/mail/iap/ProtocolException
    //   89	119	165	com/sun/mail/iap/ProtocolException
    //   119	137	165	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public long getUIDNext()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 145	com/sun/mail/imap/IMAPFolder:opened	Z
    //   6: ifeq +12 -> 18
    //   9: aload_0
    //   10: getfield 161	com/sun/mail/imap/IMAPFolder:uidnext	J
    //   13: lstore_1
    //   14: aload_0
    //   15: monitorexit
    //   16: lload_1
    //   17: lreturn
    //   18: aconst_null
    //   19: astore_3
    //   20: aconst_null
    //   21: astore 6
    //   23: aconst_null
    //   24: astore 7
    //   26: aconst_null
    //   27: astore 5
    //   29: aconst_null
    //   30: astore 8
    //   32: aload_0
    //   33: invokevirtual 407	com/sun/mail/imap/IMAPFolder:getStoreProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   36: astore 4
    //   38: aload 4
    //   40: astore 5
    //   42: aload 4
    //   44: astore_3
    //   45: aload 4
    //   47: astore 6
    //   49: aload 4
    //   51: astore 7
    //   53: aload 4
    //   55: aload_0
    //   56: getfield 178	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   59: iconst_1
    //   60: anewarray 212	java/lang/String
    //   63: dup
    //   64: iconst_0
    //   65: ldc_w 826
    //   68: aastore
    //   69: invokevirtual 411	com/sun/mail/imap/protocol/IMAPProtocol:status	(Ljava/lang/String;[Ljava/lang/String;)Lcom/sun/mail/imap/protocol/Status;
    //   72: astore 9
    //   74: aload 9
    //   76: astore_3
    //   77: aload_0
    //   78: aload 4
    //   80: invokevirtual 415	com/sun/mail/imap/IMAPFolder:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   83: aload_3
    //   84: getfield 827	com/sun/mail/imap/protocol/Status:uidnext	J
    //   87: lstore_1
    //   88: goto -74 -> 14
    //   91: astore 4
    //   93: aload 5
    //   95: astore_3
    //   96: new 247	javax/mail/MessagingException
    //   99: dup
    //   100: ldc_w 829
    //   103: aload 4
    //   105: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   108: athrow
    //   109: astore 4
    //   111: aload_0
    //   112: aload_3
    //   113: invokevirtual 415	com/sun/mail/imap/IMAPFolder:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   116: aload 4
    //   118: athrow
    //   119: astore_3
    //   120: aload_0
    //   121: monitorexit
    //   122: aload_3
    //   123: athrow
    //   124: astore 4
    //   126: aload 6
    //   128: astore_3
    //   129: aload_0
    //   130: aload 4
    //   132: invokespecial 584	com/sun/mail/imap/IMAPFolder:throwClosedException	(Lcom/sun/mail/iap/ConnectionException;)V
    //   135: aload_0
    //   136: aload 6
    //   138: invokevirtual 415	com/sun/mail/imap/IMAPFolder:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   141: aload 8
    //   143: astore_3
    //   144: goto -61 -> 83
    //   147: astore 4
    //   149: aload 7
    //   151: astore_3
    //   152: new 247	javax/mail/MessagingException
    //   155: dup
    //   156: aload 4
    //   158: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   161: aload 4
    //   163: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   166: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	167	0	this	IMAPFolder
    //   13	75	1	l	long
    //   19	94	3	localObject1	Object
    //   119	4	3	localObject2	Object
    //   128	24	3	localObject3	Object
    //   36	43	4	localIMAPProtocol	IMAPProtocol
    //   91	13	4	localBadCommandException	BadCommandException
    //   109	8	4	localObject4	Object
    //   124	7	4	localConnectionException	ConnectionException
    //   147	15	4	localProtocolException	ProtocolException
    //   27	67	5	localObject5	Object
    //   21	116	6	localObject6	Object
    //   24	126	7	localObject7	Object
    //   30	112	8	localObject8	Object
    //   72	3	9	localStatus	Status
    // Exception table:
    //   from	to	target	type
    //   32	38	91	com/sun/mail/iap/BadCommandException
    //   53	74	91	com/sun/mail/iap/BadCommandException
    //   32	38	109	finally
    //   53	74	109	finally
    //   96	109	109	finally
    //   129	135	109	finally
    //   152	167	109	finally
    //   2	14	119	finally
    //   77	83	119	finally
    //   83	88	119	finally
    //   111	119	119	finally
    //   135	141	119	finally
    //   32	38	124	com/sun/mail/iap/ConnectionException
    //   53	74	124	com/sun/mail/iap/ConnectionException
    //   32	38	147	com/sun/mail/iap/ProtocolException
    //   53	74	147	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public long getUIDValidity()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 145	com/sun/mail/imap/IMAPFolder:opened	Z
    //   6: ifeq +12 -> 18
    //   9: aload_0
    //   10: getfield 159	com/sun/mail/imap/IMAPFolder:uidvalidity	J
    //   13: lstore_1
    //   14: aload_0
    //   15: monitorexit
    //   16: lload_1
    //   17: lreturn
    //   18: aconst_null
    //   19: astore_3
    //   20: aconst_null
    //   21: astore 6
    //   23: aconst_null
    //   24: astore 7
    //   26: aconst_null
    //   27: astore 5
    //   29: aconst_null
    //   30: astore 8
    //   32: aload_0
    //   33: invokevirtual 407	com/sun/mail/imap/IMAPFolder:getStoreProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   36: astore 4
    //   38: aload 4
    //   40: astore 5
    //   42: aload 4
    //   44: astore_3
    //   45: aload 4
    //   47: astore 6
    //   49: aload 4
    //   51: astore 7
    //   53: aload 4
    //   55: aload_0
    //   56: getfield 178	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   59: iconst_1
    //   60: anewarray 212	java/lang/String
    //   63: dup
    //   64: iconst_0
    //   65: ldc_w 832
    //   68: aastore
    //   69: invokevirtual 411	com/sun/mail/imap/protocol/IMAPProtocol:status	(Ljava/lang/String;[Ljava/lang/String;)Lcom/sun/mail/imap/protocol/Status;
    //   72: astore 9
    //   74: aload 9
    //   76: astore_3
    //   77: aload_0
    //   78: aload 4
    //   80: invokevirtual 415	com/sun/mail/imap/IMAPFolder:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   83: aload_3
    //   84: getfield 833	com/sun/mail/imap/protocol/Status:uidvalidity	J
    //   87: lstore_1
    //   88: goto -74 -> 14
    //   91: astore 4
    //   93: aload 5
    //   95: astore_3
    //   96: new 247	javax/mail/MessagingException
    //   99: dup
    //   100: ldc_w 835
    //   103: aload 4
    //   105: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   108: athrow
    //   109: astore 4
    //   111: aload_0
    //   112: aload_3
    //   113: invokevirtual 415	com/sun/mail/imap/IMAPFolder:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   116: aload 4
    //   118: athrow
    //   119: astore_3
    //   120: aload_0
    //   121: monitorexit
    //   122: aload_3
    //   123: athrow
    //   124: astore 4
    //   126: aload 6
    //   128: astore_3
    //   129: aload_0
    //   130: aload 4
    //   132: invokespecial 584	com/sun/mail/imap/IMAPFolder:throwClosedException	(Lcom/sun/mail/iap/ConnectionException;)V
    //   135: aload_0
    //   136: aload 6
    //   138: invokevirtual 415	com/sun/mail/imap/IMAPFolder:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   141: aload 8
    //   143: astore_3
    //   144: goto -61 -> 83
    //   147: astore 4
    //   149: aload 7
    //   151: astore_3
    //   152: new 247	javax/mail/MessagingException
    //   155: dup
    //   156: aload 4
    //   158: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   161: aload 4
    //   163: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   166: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	167	0	this	IMAPFolder
    //   13	75	1	l	long
    //   19	94	3	localObject1	Object
    //   119	4	3	localObject2	Object
    //   128	24	3	localObject3	Object
    //   36	43	4	localIMAPProtocol	IMAPProtocol
    //   91	13	4	localBadCommandException	BadCommandException
    //   109	8	4	localObject4	Object
    //   124	7	4	localConnectionException	ConnectionException
    //   147	15	4	localProtocolException	ProtocolException
    //   27	67	5	localObject5	Object
    //   21	116	6	localObject6	Object
    //   24	126	7	localObject7	Object
    //   30	112	8	localObject8	Object
    //   72	3	9	localStatus	Status
    // Exception table:
    //   from	to	target	type
    //   32	38	91	com/sun/mail/iap/BadCommandException
    //   53	74	91	com/sun/mail/iap/BadCommandException
    //   32	38	109	finally
    //   53	74	109	finally
    //   96	109	109	finally
    //   129	135	109	finally
    //   152	167	109	finally
    //   2	14	119	finally
    //   77	83	119	finally
    //   83	88	119	finally
    //   111	119	119	finally
    //   135	141	119	finally
    //   32	38	124	com/sun/mail/iap/ConnectionException
    //   53	74	124	com/sun/mail/iap/ConnectionException
    //   32	38	147	com/sun/mail/iap/ProtocolException
    //   53	74	147	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public int getUnreadMessageCount()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 145	com/sun/mail/imap/IMAPFolder:opened	Z
    //   6: ifne +61 -> 67
    //   9: aload_0
    //   10: invokespecial 369	com/sun/mail/imap/IMAPFolder:checkExists	()V
    //   13: aload_0
    //   14: invokespecial 233	com/sun/mail/imap/IMAPFolder:getStatus	()Lcom/sun/mail/imap/protocol/Status;
    //   17: getfield 839	com/sun/mail/imap/protocol/Status:unseen	I
    //   20: istore_1
    //   21: aload_0
    //   22: monitorexit
    //   23: iload_1
    //   24: ireturn
    //   25: astore_2
    //   26: iconst_m1
    //   27: istore_1
    //   28: goto -7 -> 21
    //   31: astore_2
    //   32: new 450	javax/mail/StoreClosedException
    //   35: dup
    //   36: aload_0
    //   37: getfield 351	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   40: aload_2
    //   41: invokevirtual 309	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   44: invokespecial 456	javax/mail/StoreClosedException:<init>	(Ljavax/mail/Store;Ljava/lang/String;)V
    //   47: athrow
    //   48: astore_2
    //   49: aload_0
    //   50: monitorexit
    //   51: aload_2
    //   52: athrow
    //   53: astore_2
    //   54: new 247	javax/mail/MessagingException
    //   57: dup
    //   58: aload_2
    //   59: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   62: aload_2
    //   63: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   66: athrow
    //   67: new 700	javax/mail/Flags
    //   70: dup
    //   71: invokespecial 701	javax/mail/Flags:<init>	()V
    //   74: astore_3
    //   75: aload_3
    //   76: getstatic 842	javax/mail/Flags$Flag:SEEN	Ljavax/mail/Flags$Flag;
    //   79: invokevirtual 710	javax/mail/Flags:add	(Ljavax/mail/Flags$Flag;)V
    //   82: aload_0
    //   83: getfield 185	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   86: astore_2
    //   87: aload_2
    //   88: monitorenter
    //   89: aload_0
    //   90: invokespecial 532	com/sun/mail/imap/IMAPFolder:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   93: new 712	javax/mail/search/FlagTerm
    //   96: dup
    //   97: aload_3
    //   98: iconst_0
    //   99: invokespecial 715	javax/mail/search/FlagTerm:<init>	(Ljavax/mail/Flags;Z)V
    //   102: invokevirtual 719	com/sun/mail/imap/protocol/IMAPProtocol:search	(Ljavax/mail/search/SearchTerm;)[I
    //   105: arraylength
    //   106: istore_1
    //   107: aload_2
    //   108: monitorexit
    //   109: goto -88 -> 21
    //   112: astore_3
    //   113: aload_2
    //   114: monitorexit
    //   115: aload_3
    //   116: athrow
    //   117: astore_2
    //   118: new 290	javax/mail/FolderClosedException
    //   121: dup
    //   122: aload_0
    //   123: aload_2
    //   124: invokevirtual 309	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   127: invokespecial 295	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   130: athrow
    //   131: astore_2
    //   132: new 247	javax/mail/MessagingException
    //   135: dup
    //   136: aload_2
    //   137: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   140: aload_2
    //   141: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   144: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	145	0	this	IMAPFolder
    //   20	87	1	i	int
    //   25	1	2	localBadCommandException	BadCommandException
    //   31	10	2	localConnectionException1	ConnectionException
    //   48	4	2	localObject1	Object
    //   53	10	2	localProtocolException1	ProtocolException
    //   117	7	2	localConnectionException2	ConnectionException
    //   131	10	2	localProtocolException2	ProtocolException
    //   74	24	3	localFlags	Flags
    //   112	4	3	localObject3	Object
    // Exception table:
    //   from	to	target	type
    //   13	21	25	com/sun/mail/iap/BadCommandException
    //   13	21	31	com/sun/mail/iap/ConnectionException
    //   2	13	48	finally
    //   13	21	48	finally
    //   32	48	48	finally
    //   54	67	48	finally
    //   67	82	48	finally
    //   82	89	48	finally
    //   115	117	48	finally
    //   118	131	48	finally
    //   132	145	48	finally
    //   13	21	53	com/sun/mail/iap/ProtocolException
    //   89	109	112	finally
    //   113	115	112	finally
    //   82	89	117	com/sun/mail/iap/ConnectionException
    //   115	117	117	com/sun/mail/iap/ConnectionException
    //   82	89	131	com/sun/mail/iap/ProtocolException
    //   115	117	131	com/sun/mail/iap/ProtocolException
  }
  
  public void handleResponse(Response paramResponse)
  {
    assert (Thread.holdsLock(this.messageCacheLock));
    if ((paramResponse.isOK()) || (paramResponse.isNO()) || (paramResponse.isBAD()) || (paramResponse.isBYE())) {
      ((IMAPStore)this.store).handleResponseCode(paramResponse);
    }
    if (paramResponse.isBYE()) {
      if (this.opened) {
        cleanup(false);
      }
    }
    label82:
    label369:
    do
    {
      Object localObject;
      do
      {
        do
        {
          int i;
          do
          {
            do
            {
              break label82;
              break label82;
              break label82;
              do
              {
                return;
              } while ((paramResponse.isOK()) || (!paramResponse.isUnTagged()));
              if (!(paramResponse instanceof IMAPResponse))
              {
                this.out.println("UNEXPECTED RESPONSE : " + paramResponse.toString());
                this.out.println("CONTACT javamail@sun.com");
                return;
              }
              paramResponse = (IMAPResponse)paramResponse;
              if (!paramResponse.keyEquals("EXISTS")) {
                break;
              }
              i = paramResponse.getNumber();
            } while (i <= this.realTotal);
            int j = i - this.realTotal;
            paramResponse = new Message[j];
            i = 0;
            for (;;)
            {
              if (i >= j)
              {
                notifyMessageAddedListeners(paramResponse);
                return;
              }
              int k = this.total + 1;
              this.total = k;
              int m = this.realTotal + 1;
              this.realTotal = m;
              localObject = new IMAPMessage(this, k, m);
              paramResponse[i] = localObject;
              this.messageCache.addElement(localObject);
              i += 1;
            }
            if (!paramResponse.keyEquals("EXPUNGE")) {
              break label369;
            }
            paramResponse = getMessageBySeqNumber(paramResponse.getNumber());
            paramResponse.setExpunged(true);
            i = paramResponse.getMessageNumber();
            if (i < this.total) {
              break;
            }
            this.realTotal -= 1;
          } while (!this.doExpungeNotification);
          notifyMessageRemovedListeners(false, new Message[] { paramResponse });
          return;
          localObject = (IMAPMessage)this.messageCache.elementAt(i);
          if (((IMAPMessage)localObject).isExpunged()) {}
          for (;;)
          {
            i += 1;
            break;
            ((IMAPMessage)localObject).setSequenceNumber(((IMAPMessage)localObject).getSequenceNumber() - 1);
          }
          if (!paramResponse.keyEquals("FETCH")) {
            break;
          }
          assert ((paramResponse instanceof FetchResponse)) : "!ir instanceof FetchResponse";
          localObject = (FetchResponse)paramResponse;
          paramResponse = (Flags)((FetchResponse)localObject).getItem(Flags.class);
        } while (paramResponse == null);
        localObject = getMessageBySeqNumber(((FetchResponse)localObject).getNumber());
      } while (localObject == null);
      ((IMAPMessage)localObject)._setFlags(paramResponse);
      notifyMessageChangedListeners(1, (Message)localObject);
      return;
    } while (!paramResponse.keyEquals("RECENT"));
    this.recent = paramResponse.getNumber();
  }
  
  void handleResponses(Response[] paramArrayOfResponse)
  {
    int i = 0;
    for (;;)
    {
      if (i >= paramArrayOfResponse.length) {
        return;
      }
      if (paramArrayOfResponse[i] != null) {
        handleResponse(paramArrayOfResponse[i]);
      }
      i += 1;
    }
  }
  
  /* Error */
  public boolean hasNewMessages()
    throws MessagingException
  {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: iconst_0
    //   3: istore_1
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: getfield 145	com/sun/mail/imap/IMAPFolder:opened	Z
    //   10: ifeq +75 -> 85
    //   13: aload_0
    //   14: getfield 185	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   17: astore_3
    //   18: aload_3
    //   19: monitorenter
    //   20: aload_0
    //   21: iconst_1
    //   22: invokespecial 306	com/sun/mail/imap/IMAPFolder:keepConnectionAlive	(Z)V
    //   25: aload_0
    //   26: getfield 153	com/sun/mail/imap/IMAPFolder:recent	I
    //   29: ifle +5 -> 34
    //   32: iconst_1
    //   33: istore_1
    //   34: aload_3
    //   35: monitorexit
    //   36: aload_0
    //   37: monitorexit
    //   38: iload_1
    //   39: ireturn
    //   40: astore 4
    //   42: new 290	javax/mail/FolderClosedException
    //   45: dup
    //   46: aload_0
    //   47: aload 4
    //   49: invokevirtual 309	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   52: invokespecial 295	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   55: athrow
    //   56: astore 4
    //   58: aload_3
    //   59: monitorexit
    //   60: aload 4
    //   62: athrow
    //   63: astore_3
    //   64: aload_0
    //   65: monitorexit
    //   66: aload_3
    //   67: athrow
    //   68: astore 4
    //   70: new 247	javax/mail/MessagingException
    //   73: dup
    //   74: aload 4
    //   76: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   79: aload 4
    //   81: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   84: athrow
    //   85: aload_0
    //   86: invokespecial 369	com/sun/mail/imap/IMAPFolder:checkExists	()V
    //   89: aload_0
    //   90: new 42	com/sun/mail/imap/IMAPFolder$7
    //   93: dup
    //   94: aload_0
    //   95: invokespecial 925	com/sun/mail/imap/IMAPFolder$7:<init>	(Lcom/sun/mail/imap/IMAPFolder;)V
    //   98: invokevirtual 383	com/sun/mail/imap/IMAPFolder:doCommandIgnoreFailure	(Lcom/sun/mail/imap/IMAPFolder$ProtocolCommand;)Ljava/lang/Object;
    //   101: checkcast 927	java/lang/Boolean
    //   104: astore_3
    //   105: iload_2
    //   106: istore_1
    //   107: aload_3
    //   108: ifnull -72 -> 36
    //   111: aload_3
    //   112: invokevirtual 930	java/lang/Boolean:booleanValue	()Z
    //   115: istore_1
    //   116: goto -80 -> 36
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	119	0	this	IMAPFolder
    //   3	113	1	bool1	boolean
    //   1	105	2	bool2	boolean
    //   63	4	3	localObject2	Object
    //   104	8	3	localBoolean	Boolean
    //   40	8	4	localConnectionException	ConnectionException
    //   56	5	4	localObject3	Object
    //   68	12	4	localProtocolException	ProtocolException
    // Exception table:
    //   from	to	target	type
    //   20	25	40	com/sun/mail/iap/ConnectionException
    //   20	25	56	finally
    //   25	32	56	finally
    //   34	36	56	finally
    //   42	56	56	finally
    //   58	60	56	finally
    //   70	85	56	finally
    //   6	20	63	finally
    //   60	63	63	finally
    //   85	105	63	finally
    //   111	116	63	finally
    //   20	25	68	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public void idle()
    throws MessagingException
  {
    // Byte code:
    //   0: getstatic 111	com/sun/mail/imap/IMAPFolder:$assertionsDisabled	Z
    //   3: ifne +18 -> 21
    //   6: aload_0
    //   7: invokestatic 279	java/lang/Thread:holdsLock	(Ljava/lang/Object;)Z
    //   10: ifeq +11 -> 21
    //   13: new 281	java/lang/AssertionError
    //   16: dup
    //   17: invokespecial 282	java/lang/AssertionError:<init>	()V
    //   20: athrow
    //   21: aload_0
    //   22: monitorenter
    //   23: aload_0
    //   24: invokespecial 464	com/sun/mail/imap/IMAPFolder:checkOpened	()V
    //   27: aload_0
    //   28: ldc_w 935
    //   31: new 30	com/sun/mail/imap/IMAPFolder$19
    //   34: dup
    //   35: aload_0
    //   36: invokespecial 936	com/sun/mail/imap/IMAPFolder$19:<init>	(Lcom/sun/mail/imap/IMAPFolder;)V
    //   39: invokevirtual 446	com/sun/mail/imap/IMAPFolder:doOptionalCommand	(Ljava/lang/String;Lcom/sun/mail/imap/IMAPFolder$ProtocolCommand;)Ljava/lang/Object;
    //   42: checkcast 927	java/lang/Boolean
    //   45: invokevirtual 930	java/lang/Boolean:booleanValue	()Z
    //   48: ifne +6 -> 54
    //   51: aload_0
    //   52: monitorexit
    //   53: return
    //   54: aload_0
    //   55: monitorexit
    //   56: aload_0
    //   57: getfield 319	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   60: invokevirtual 940	com/sun/mail/imap/protocol/IMAPProtocol:readIdleResponse	()Lcom/sun/mail/iap/Response;
    //   63: astore 5
    //   65: aload_0
    //   66: getfield 185	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   69: astore 4
    //   71: aload 4
    //   73: monitorenter
    //   74: aload 5
    //   76: ifnull +22 -> 98
    //   79: aload_0
    //   80: getfield 319	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   83: ifnull +15 -> 98
    //   86: aload_0
    //   87: getfield 319	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   90: aload 5
    //   92: invokevirtual 944	com/sun/mail/imap/protocol/IMAPProtocol:processIdleResponse	(Lcom/sun/mail/iap/Response;)Z
    //   95: ifne +51 -> 146
    //   98: aload_0
    //   99: iconst_0
    //   100: putfield 149	com/sun/mail/imap/IMAPFolder:idleState	I
    //   103: aload_0
    //   104: getfield 185	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   107: invokevirtual 947	java/lang/Object:notifyAll	()V
    //   110: aload 4
    //   112: monitorexit
    //   113: aload_0
    //   114: getfield 351	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   117: checkcast 187	com/sun/mail/imap/IMAPStore
    //   120: invokevirtual 950	com/sun/mail/imap/IMAPStore:getMinIdleTime	()I
    //   123: istore_1
    //   124: iload_1
    //   125: ifle +63 -> 188
    //   128: iload_1
    //   129: i2l
    //   130: lstore_2
    //   131: lload_2
    //   132: invokestatic 953	java/lang/Thread:sleep	(J)V
    //   135: return
    //   136: astore 4
    //   138: return
    //   139: astore 4
    //   141: aload_0
    //   142: monitorexit
    //   143: aload 4
    //   145: athrow
    //   146: aload 4
    //   148: monitorexit
    //   149: goto -93 -> 56
    //   152: astore 5
    //   154: aload 4
    //   156: monitorexit
    //   157: aload 5
    //   159: athrow
    //   160: astore 4
    //   162: aload_0
    //   163: aload 4
    //   165: invokespecial 584	com/sun/mail/imap/IMAPFolder:throwClosedException	(Lcom/sun/mail/iap/ConnectionException;)V
    //   168: goto -112 -> 56
    //   171: astore 4
    //   173: new 247	javax/mail/MessagingException
    //   176: dup
    //   177: aload 4
    //   179: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   182: aload 4
    //   184: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   187: athrow
    //   188: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	189	0	this	IMAPFolder
    //   123	6	1	i	int
    //   130	2	2	l	long
    //   69	42	4	localObject1	Object
    //   136	1	4	localInterruptedException	InterruptedException
    //   139	16	4	localObject2	Object
    //   160	4	4	localConnectionException	ConnectionException
    //   171	12	4	localProtocolException	ProtocolException
    //   63	28	5	localResponse	Response
    //   152	6	5	localObject3	Object
    // Exception table:
    //   from	to	target	type
    //   131	135	136	java/lang/InterruptedException
    //   23	53	139	finally
    //   54	56	139	finally
    //   141	143	139	finally
    //   79	98	152	finally
    //   98	113	152	finally
    //   146	149	152	finally
    //   154	157	152	finally
    //   65	74	160	com/sun/mail/iap/ConnectionException
    //   157	160	160	com/sun/mail/iap/ConnectionException
    //   65	74	171	com/sun/mail/iap/ProtocolException
    //   157	160	171	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public boolean isOpen()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 185	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   6: astore_2
    //   7: aload_2
    //   8: monitorenter
    //   9: aload_0
    //   10: getfield 145	com/sun/mail/imap/IMAPFolder:opened	Z
    //   13: istore_1
    //   14: iload_1
    //   15: ifeq +8 -> 23
    //   18: aload_0
    //   19: iconst_0
    //   20: invokespecial 306	com/sun/mail/imap/IMAPFolder:keepConnectionAlive	(Z)V
    //   23: aload_2
    //   24: monitorexit
    //   25: aload_0
    //   26: getfield 145	com/sun/mail/imap/IMAPFolder:opened	Z
    //   29: istore_1
    //   30: aload_0
    //   31: monitorexit
    //   32: iload_1
    //   33: ireturn
    //   34: astore_3
    //   35: aload_2
    //   36: monitorexit
    //   37: aload_3
    //   38: athrow
    //   39: astore_2
    //   40: aload_0
    //   41: monitorexit
    //   42: aload_2
    //   43: athrow
    //   44: astore_3
    //   45: goto -22 -> 23
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	48	0	this	IMAPFolder
    //   13	20	1	bool	boolean
    //   39	4	2	localObject2	Object
    //   34	4	3	localObject3	Object
    //   44	1	3	localProtocolException	ProtocolException
    // Exception table:
    //   from	to	target	type
    //   9	14	34	finally
    //   18	23	34	finally
    //   23	25	34	finally
    //   35	37	34	finally
    //   2	9	39	finally
    //   25	30	39	finally
    //   37	39	39	finally
    //   18	23	44	com/sun/mail/iap/ProtocolException
  }
  
  public boolean isSubscribed()
  {
    Object localObject2;
    final String str;
    ListInfo[] arrayOfListInfo;
    label67:
    try
    {
      localObject2 = (ListInfo[])null;
      if ((this.isNamespace) && (this.separator != 0)) {
        str = this.fullName + this.separator;
      }
    }
    finally {}
    try
    {
      arrayOfListInfo = (ListInfo[])doProtocolCommand(new ProtocolCommand()
      {
        public Object doCommand(IMAPProtocol paramAnonymousIMAPProtocol)
          throws ProtocolException
        {
          return paramAnonymousIMAPProtocol.lsub("", str);
        }
      });
      localObject2 = arrayOfListInfo;
    }
    catch (ProtocolException localProtocolException)
    {
      break label67;
    }
    if (localObject2 != null) {}
    for (boolean bool = localObject2[findName(localObject2, str)].canOpen;; bool = false)
    {
      return bool;
      str = this.fullName;
      break;
    }
  }
  
  public Folder[] list(String paramString)
    throws MessagingException
  {
    return doList(paramString, false);
  }
  
  public Rights[] listRights(final String paramString)
    throws MessagingException
  {
    (Rights[])doOptionalCommand("ACL not supported", new ProtocolCommand()
    {
      public Object doCommand(IMAPProtocol paramAnonymousIMAPProtocol)
        throws ProtocolException
      {
        return paramAnonymousIMAPProtocol.listRights(IMAPFolder.this.fullName, paramString);
      }
    });
  }
  
  public Folder[] listSubscribed(String paramString)
    throws MessagingException
  {
    return doList(paramString, true);
  }
  
  public Rights myRights()
    throws MessagingException
  {
    (Rights)doOptionalCommand("ACL not supported", new ProtocolCommand()
    {
      public Object doCommand(IMAPProtocol paramAnonymousIMAPProtocol)
        throws ProtocolException
      {
        return paramAnonymousIMAPProtocol.myRights(IMAPFolder.this.fullName);
      }
    });
  }
  
  /* Error */
  public void open(int paramInt)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 570	com/sun/mail/imap/IMAPFolder:checkClosed	()V
    //   6: aload_0
    //   7: aload_0
    //   8: getfield 351	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   11: checkcast 187	com/sun/mail/imap/IMAPStore
    //   14: aload_0
    //   15: invokevirtual 974	com/sun/mail/imap/IMAPStore:getProtocol	(Lcom/sun/mail/imap/IMAPFolder;)Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   18: putfield 319	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   21: aconst_null
    //   22: astore_3
    //   23: aload_0
    //   24: getfield 185	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   27: astore 4
    //   29: aload 4
    //   31: monitorenter
    //   32: aload_0
    //   33: getfield 319	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   36: aload_0
    //   37: invokevirtual 977	com/sun/mail/imap/protocol/IMAPProtocol:addResponseHandler	(Lcom/sun/mail/iap/ResponseHandler;)V
    //   40: iload_1
    //   41: iconst_1
    //   42: if_icmpne +185 -> 227
    //   45: aload_0
    //   46: getfield 319	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   49: aload_0
    //   50: getfield 178	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   53: invokevirtual 365	com/sun/mail/imap/protocol/IMAPProtocol:examine	(Ljava/lang/String;)Lcom/sun/mail/imap/protocol/MailboxInfo;
    //   56: astore_2
    //   57: aload_2
    //   58: getfield 978	com/sun/mail/imap/protocol/MailboxInfo:mode	I
    //   61: iload_1
    //   62: if_icmpeq +29 -> 91
    //   65: iload_1
    //   66: iconst_2
    //   67: if_icmpne +229 -> 296
    //   70: aload_2
    //   71: getfield 978	com/sun/mail/imap/protocol/MailboxInfo:mode	I
    //   74: iconst_1
    //   75: if_icmpne +221 -> 296
    //   78: aload_0
    //   79: getfield 351	com/sun/mail/imap/IMAPFolder:store	Ljavax/mail/Store;
    //   82: checkcast 187	com/sun/mail/imap/IMAPStore
    //   85: invokevirtual 981	com/sun/mail/imap/IMAPStore:allowReadOnlySelect	()Z
    //   88: ifeq +208 -> 296
    //   91: aload_0
    //   92: iconst_1
    //   93: putfield 145	com/sun/mail/imap/IMAPFolder:opened	Z
    //   96: aload_0
    //   97: iconst_0
    //   98: putfield 147	com/sun/mail/imap/IMAPFolder:reallyClosed	Z
    //   101: aload_0
    //   102: aload_2
    //   103: getfield 978	com/sun/mail/imap/protocol/MailboxInfo:mode	I
    //   106: putfield 285	com/sun/mail/imap/IMAPFolder:mode	I
    //   109: aload_0
    //   110: aload_2
    //   111: getfield 983	com/sun/mail/imap/protocol/MailboxInfo:availableFlags	Ljavax/mail/Flags;
    //   114: putfield 984	com/sun/mail/imap/IMAPFolder:availableFlags	Ljavax/mail/Flags;
    //   117: aload_0
    //   118: aload_2
    //   119: getfield 985	com/sun/mail/imap/protocol/MailboxInfo:permanentFlags	Ljavax/mail/Flags;
    //   122: putfield 796	com/sun/mail/imap/IMAPFolder:permanentFlags	Ljavax/mail/Flags;
    //   125: aload_2
    //   126: getfield 759	com/sun/mail/imap/protocol/MailboxInfo:total	I
    //   129: istore_1
    //   130: aload_0
    //   131: iload_1
    //   132: putfield 155	com/sun/mail/imap/IMAPFolder:realTotal	I
    //   135: aload_0
    //   136: iload_1
    //   137: putfield 151	com/sun/mail/imap/IMAPFolder:total	I
    //   140: aload_0
    //   141: aload_2
    //   142: getfield 786	com/sun/mail/imap/protocol/MailboxInfo:recent	I
    //   145: putfield 153	com/sun/mail/imap/IMAPFolder:recent	I
    //   148: aload_0
    //   149: aload_2
    //   150: getfield 986	com/sun/mail/imap/protocol/MailboxInfo:uidvalidity	J
    //   153: putfield 159	com/sun/mail/imap/IMAPFolder:uidvalidity	J
    //   156: aload_0
    //   157: aload_2
    //   158: getfield 987	com/sun/mail/imap/protocol/MailboxInfo:uidnext	J
    //   161: putfield 161	com/sun/mail/imap/IMAPFolder:uidnext	J
    //   164: aload_0
    //   165: new 604	java/util/Vector
    //   168: dup
    //   169: aload_0
    //   170: getfield 151	com/sun/mail/imap/IMAPFolder:total	I
    //   173: invokespecial 989	java/util/Vector:<init>	(I)V
    //   176: putfield 321	com/sun/mail/imap/IMAPFolder:messageCache	Ljava/util/Vector;
    //   179: iconst_0
    //   180: istore_1
    //   181: iload_1
    //   182: aload_0
    //   183: getfield 151	com/sun/mail/imap/IMAPFolder:total	I
    //   186: if_icmplt +172 -> 358
    //   189: aload 4
    //   191: monitorexit
    //   192: aload_3
    //   193: astore_2
    //   194: aload_2
    //   195: ifnull +204 -> 399
    //   198: aload_0
    //   199: invokespecial 369	com/sun/mail/imap/IMAPFolder:checkExists	()V
    //   202: aload_0
    //   203: getfield 128	com/sun/mail/imap/IMAPFolder:type	I
    //   206: iconst_1
    //   207: iand
    //   208: ifne +178 -> 386
    //   211: new 247	javax/mail/MessagingException
    //   214: dup
    //   215: ldc_w 991
    //   218: invokespecial 724	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   221: athrow
    //   222: astore_2
    //   223: aload_0
    //   224: monitorexit
    //   225: aload_2
    //   226: athrow
    //   227: aload_0
    //   228: getfield 319	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   231: aload_0
    //   232: getfield 178	com/sun/mail/imap/IMAPFolder:fullName	Ljava/lang/String;
    //   235: invokevirtual 994	com/sun/mail/imap/protocol/IMAPProtocol:select	(Ljava/lang/String;)Lcom/sun/mail/imap/protocol/MailboxInfo;
    //   238: astore_2
    //   239: goto -182 -> 57
    //   242: astore_2
    //   243: aload_0
    //   244: iconst_1
    //   245: invokespecial 317	com/sun/mail/imap/IMAPFolder:releaseProtocol	(Z)V
    //   248: aload_0
    //   249: aconst_null
    //   250: putfield 319	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   253: aload 4
    //   255: monitorexit
    //   256: goto -62 -> 194
    //   259: astore_2
    //   260: aload 4
    //   262: monitorexit
    //   263: aload_2
    //   264: athrow
    //   265: astore_2
    //   266: aload_0
    //   267: getfield 319	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   270: invokevirtual 361	com/sun/mail/imap/protocol/IMAPProtocol:logout	()V
    //   273: aload_0
    //   274: iconst_0
    //   275: invokespecial 317	com/sun/mail/imap/IMAPFolder:releaseProtocol	(Z)V
    //   278: aload_0
    //   279: aconst_null
    //   280: putfield 319	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   283: new 247	javax/mail/MessagingException
    //   286: dup
    //   287: aload_2
    //   288: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   291: aload_2
    //   292: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   295: athrow
    //   296: aload_0
    //   297: getfield 319	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   300: invokevirtual 358	com/sun/mail/imap/protocol/IMAPProtocol:close	()V
    //   303: aload_0
    //   304: iconst_1
    //   305: invokespecial 317	com/sun/mail/imap/IMAPFolder:releaseProtocol	(Z)V
    //   308: aload_0
    //   309: aconst_null
    //   310: putfield 319	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   313: new 996	javax/mail/ReadOnlyFolderException
    //   316: dup
    //   317: aload_0
    //   318: ldc_w 998
    //   321: invokespecial 999	javax/mail/ReadOnlyFolderException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   324: athrow
    //   325: astore_2
    //   326: aload_0
    //   327: getfield 319	com/sun/mail/imap/IMAPFolder:protocol	Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   330: invokevirtual 361	com/sun/mail/imap/protocol/IMAPProtocol:logout	()V
    //   333: aload_0
    //   334: iconst_0
    //   335: invokespecial 317	com/sun/mail/imap/IMAPFolder:releaseProtocol	(Z)V
    //   338: goto -30 -> 308
    //   341: astore_2
    //   342: aload_0
    //   343: iconst_0
    //   344: invokespecial 317	com/sun/mail/imap/IMAPFolder:releaseProtocol	(Z)V
    //   347: goto -39 -> 308
    //   350: astore_2
    //   351: aload_0
    //   352: iconst_0
    //   353: invokespecial 317	com/sun/mail/imap/IMAPFolder:releaseProtocol	(Z)V
    //   356: aload_2
    //   357: athrow
    //   358: aload_0
    //   359: getfield 321	com/sun/mail/imap/IMAPFolder:messageCache	Ljava/util/Vector;
    //   362: new 651	com/sun/mail/imap/IMAPMessage
    //   365: dup
    //   366: aload_0
    //   367: iload_1
    //   368: iconst_1
    //   369: iadd
    //   370: iload_1
    //   371: iconst_1
    //   372: iadd
    //   373: invokespecial 886	com/sun/mail/imap/IMAPMessage:<init>	(Lcom/sun/mail/imap/IMAPFolder;II)V
    //   376: invokevirtual 658	java/util/Vector:addElement	(Ljava/lang/Object;)V
    //   379: iload_1
    //   380: iconst_1
    //   381: iadd
    //   382: istore_1
    //   383: goto -202 -> 181
    //   386: new 247	javax/mail/MessagingException
    //   389: dup
    //   390: aload_2
    //   391: invokevirtual 542	com/sun/mail/iap/CommandFailedException:getMessage	()Ljava/lang/String;
    //   394: aload_2
    //   395: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   398: athrow
    //   399: aload_0
    //   400: iconst_1
    //   401: putfield 133	com/sun/mail/imap/IMAPFolder:exists	Z
    //   404: aload_0
    //   405: aconst_null
    //   406: putfield 138	com/sun/mail/imap/IMAPFolder:attributes	[Ljava/lang/String;
    //   409: aload_0
    //   410: iconst_1
    //   411: putfield 128	com/sun/mail/imap/IMAPFolder:type	I
    //   414: aload_0
    //   415: iconst_1
    //   416: invokevirtual 326	com/sun/mail/imap/IMAPFolder:notifyConnectionListeners	(I)V
    //   419: aload_0
    //   420: monitorexit
    //   421: return
    //   422: astore_3
    //   423: goto -150 -> 273
    //   426: astore_3
    //   427: goto -154 -> 273
    //   430: astore_2
    //   431: goto -123 -> 308
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	434	0	this	IMAPFolder
    //   0	434	1	paramInt	int
    //   56	139	2	localObject1	Object
    //   222	4	2	localObject2	Object
    //   238	1	2	localMailboxInfo	com.sun.mail.imap.protocol.MailboxInfo
    //   242	1	2	localCommandFailedException	CommandFailedException
    //   259	5	2	localObject3	Object
    //   265	27	2	localProtocolException1	ProtocolException
    //   325	1	2	localProtocolException2	ProtocolException
    //   341	1	2	localProtocolException3	ProtocolException
    //   350	45	2	localException	Exception
    //   430	1	2	localObject4	Object
    //   22	171	3	localObject5	Object
    //   422	1	3	localObject6	Object
    //   426	1	3	localProtocolException4	ProtocolException
    //   27	234	4	localObject7	Object
    // Exception table:
    //   from	to	target	type
    //   2	21	222	finally
    //   23	32	222	finally
    //   198	222	222	finally
    //   263	265	222	finally
    //   386	399	222	finally
    //   399	419	222	finally
    //   45	57	242	com/sun/mail/iap/CommandFailedException
    //   227	239	242	com/sun/mail/iap/CommandFailedException
    //   32	40	259	finally
    //   45	57	259	finally
    //   57	65	259	finally
    //   70	91	259	finally
    //   91	179	259	finally
    //   181	192	259	finally
    //   227	239	259	finally
    //   243	253	259	finally
    //   253	256	259	finally
    //   260	263	259	finally
    //   273	296	259	finally
    //   308	325	259	finally
    //   358	379	259	finally
    //   45	57	265	com/sun/mail/iap/ProtocolException
    //   227	239	265	com/sun/mail/iap/ProtocolException
    //   296	308	325	com/sun/mail/iap/ProtocolException
    //   326	333	341	com/sun/mail/iap/ProtocolException
    //   326	333	350	finally
    //   266	273	422	finally
    //   266	273	426	com/sun/mail/iap/ProtocolException
    //   296	308	430	finally
    //   333	338	430	finally
    //   342	347	430	finally
    //   351	358	430	finally
  }
  
  protected void releaseStoreProtocol(IMAPProtocol paramIMAPProtocol)
  {
    try
    {
      if (paramIMAPProtocol != this.protocol) {
        ((IMAPStore)this.store).releaseStoreProtocol(paramIMAPProtocol);
      }
      return;
    }
    finally
    {
      paramIMAPProtocol = finally;
      throw paramIMAPProtocol;
    }
  }
  
  public void removeACL(final String paramString)
    throws MessagingException
  {
    doOptionalCommand("ACL not supported", new ProtocolCommand()
    {
      public Object doCommand(IMAPProtocol paramAnonymousIMAPProtocol)
        throws ProtocolException
      {
        paramAnonymousIMAPProtocol.deleteACL(IMAPFolder.this.fullName, paramString);
        return null;
      }
    });
  }
  
  public void removeRights(ACL paramACL)
    throws MessagingException
  {
    setACL(paramACL, '-');
  }
  
  public boolean renameTo(final Folder paramFolder)
    throws MessagingException
  {
    boolean bool = false;
    try
    {
      checkClosed();
      checkExists();
      if (paramFolder.getStore() != this.store) {
        throw new MessagingException("Can't rename across Stores");
      }
    }
    finally {}
    Object localObject = doCommandIgnoreFailure(new ProtocolCommand()
    {
      public Object doCommand(IMAPProtocol paramAnonymousIMAPProtocol)
        throws ProtocolException
      {
        paramAnonymousIMAPProtocol.rename(IMAPFolder.this.fullName, paramFolder.getFullName());
        return Boolean.TRUE;
      }
    });
    if (localObject == null) {}
    for (;;)
    {
      return bool;
      this.exists = false;
      this.attributes = null;
      notifyFolderRenamedListeners(paramFolder);
      bool = true;
    }
  }
  
  /* Error */
  public Message[] search(javax.mail.search.SearchTerm paramSearchTerm)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 464	com/sun/mail/imap/IMAPFolder:checkOpened	()V
    //   6: aconst_null
    //   7: checkcast 1018	[Ljavax/mail/Message;
    //   10: astore_3
    //   11: aload_0
    //   12: getfield 185	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   15: astore 4
    //   17: aload 4
    //   19: monitorenter
    //   20: aload_0
    //   21: invokespecial 532	com/sun/mail/imap/IMAPFolder:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   24: aload_1
    //   25: invokevirtual 719	com/sun/mail/imap/protocol/IMAPProtocol:search	(Ljavax/mail/search/SearchTerm;)[I
    //   28: astore 5
    //   30: aload 5
    //   32: ifnull +19 -> 51
    //   35: aload 5
    //   37: arraylength
    //   38: anewarray 651	com/sun/mail/imap/IMAPMessage
    //   41: astore_3
    //   42: iconst_0
    //   43: istore_2
    //   44: iload_2
    //   45: aload 5
    //   47: arraylength
    //   48: if_icmplt +10 -> 58
    //   51: aload 4
    //   53: monitorexit
    //   54: aload_0
    //   55: monitorexit
    //   56: aload_3
    //   57: areturn
    //   58: aload_3
    //   59: iload_2
    //   60: aload_0
    //   61: aload 5
    //   63: iload_2
    //   64: iaload
    //   65: invokevirtual 744	com/sun/mail/imap/IMAPFolder:getMessageBySeqNumber	(I)Lcom/sun/mail/imap/IMAPMessage;
    //   68: aastore
    //   69: iload_2
    //   70: iconst_1
    //   71: iadd
    //   72: istore_2
    //   73: goto -29 -> 44
    //   76: astore_3
    //   77: aload 4
    //   79: monitorexit
    //   80: aload_3
    //   81: athrow
    //   82: astore_3
    //   83: aload_0
    //   84: aload_1
    //   85: invokespecial 1020	javax/mail/Folder:search	(Ljavax/mail/search/SearchTerm;)[Ljavax/mail/Message;
    //   88: astore_3
    //   89: goto -35 -> 54
    //   92: astore_3
    //   93: aload_0
    //   94: aload_1
    //   95: invokespecial 1020	javax/mail/Folder:search	(Ljavax/mail/search/SearchTerm;)[Ljavax/mail/Message;
    //   98: astore_3
    //   99: goto -45 -> 54
    //   102: astore_1
    //   103: new 290	javax/mail/FolderClosedException
    //   106: dup
    //   107: aload_0
    //   108: aload_1
    //   109: invokevirtual 309	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   112: invokespecial 295	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   115: athrow
    //   116: astore_1
    //   117: aload_0
    //   118: monitorexit
    //   119: aload_1
    //   120: athrow
    //   121: astore_1
    //   122: new 247	javax/mail/MessagingException
    //   125: dup
    //   126: aload_1
    //   127: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   130: aload_1
    //   131: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   134: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	135	0	this	IMAPFolder
    //   0	135	1	paramSearchTerm	javax.mail.search.SearchTerm
    //   43	30	2	i	int
    //   10	49	3	localObject1	Object
    //   76	5	3	localObject2	Object
    //   82	1	3	localCommandFailedException	CommandFailedException
    //   88	1	3	arrayOfMessage1	Message[]
    //   92	1	3	localSearchException	javax.mail.search.SearchException
    //   98	1	3	arrayOfMessage2	Message[]
    //   28	34	5	arrayOfInt	int[]
    // Exception table:
    //   from	to	target	type
    //   20	30	76	finally
    //   35	42	76	finally
    //   44	51	76	finally
    //   51	54	76	finally
    //   58	69	76	finally
    //   77	80	76	finally
    //   6	20	82	com/sun/mail/iap/CommandFailedException
    //   80	82	82	com/sun/mail/iap/CommandFailedException
    //   6	20	92	javax/mail/search/SearchException
    //   80	82	92	javax/mail/search/SearchException
    //   6	20	102	com/sun/mail/iap/ConnectionException
    //   80	82	102	com/sun/mail/iap/ConnectionException
    //   2	6	116	finally
    //   6	20	116	finally
    //   80	82	116	finally
    //   83	89	116	finally
    //   93	99	116	finally
    //   103	116	116	finally
    //   122	135	116	finally
    //   6	20	121	com/sun/mail/iap/ProtocolException
    //   80	82	121	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public Message[] search(javax.mail.search.SearchTerm paramSearchTerm, Message[] paramArrayOfMessage)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 464	com/sun/mail/imap/IMAPFolder:checkOpened	()V
    //   6: aload_2
    //   7: arraylength
    //   8: istore_3
    //   9: iload_3
    //   10: ifne +7 -> 17
    //   13: aload_0
    //   14: monitorexit
    //   15: aload_2
    //   16: areturn
    //   17: aconst_null
    //   18: checkcast 1018	[Ljavax/mail/Message;
    //   21: astore 4
    //   23: aload_0
    //   24: getfield 185	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   27: astore 5
    //   29: aload 5
    //   31: monitorenter
    //   32: aload_0
    //   33: invokespecial 532	com/sun/mail/imap/IMAPFolder:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   36: astore 6
    //   38: aload_2
    //   39: aconst_null
    //   40: invokestatic 538	com/sun/mail/imap/Utility:toMessageSet	([Ljavax/mail/Message;Lcom/sun/mail/imap/Utility$Condition;)[Lcom/sun/mail/imap/protocol/MessageSet;
    //   43: astore 7
    //   45: aload 7
    //   47: ifnonnull +34 -> 81
    //   50: new 487	javax/mail/MessageRemovedException
    //   53: dup
    //   54: ldc_w 540
    //   57: invokespecial 541	javax/mail/MessageRemovedException:<init>	(Ljava/lang/String;)V
    //   60: athrow
    //   61: astore 4
    //   63: aload 5
    //   65: monitorexit
    //   66: aload 4
    //   68: athrow
    //   69: astore 4
    //   71: aload_0
    //   72: aload_1
    //   73: aload_2
    //   74: invokespecial 1023	javax/mail/Folder:search	(Ljavax/mail/search/SearchTerm;[Ljavax/mail/Message;)[Ljavax/mail/Message;
    //   77: astore_2
    //   78: goto -65 -> 13
    //   81: aload 6
    //   83: aload 7
    //   85: aload_1
    //   86: invokevirtual 1026	com/sun/mail/imap/protocol/IMAPProtocol:search	([Lcom/sun/mail/imap/protocol/MessageSet;Ljavax/mail/search/SearchTerm;)[I
    //   89: astore 6
    //   91: aload 6
    //   93: ifnull +20 -> 113
    //   96: aload 6
    //   98: arraylength
    //   99: anewarray 651	com/sun/mail/imap/IMAPMessage
    //   102: astore 4
    //   104: iconst_0
    //   105: istore_3
    //   106: iload_3
    //   107: aload 6
    //   109: arraylength
    //   110: if_icmplt +12 -> 122
    //   113: aload 5
    //   115: monitorexit
    //   116: aload 4
    //   118: astore_2
    //   119: goto -106 -> 13
    //   122: aload 4
    //   124: iload_3
    //   125: aload_0
    //   126: aload 6
    //   128: iload_3
    //   129: iaload
    //   130: invokevirtual 744	com/sun/mail/imap/IMAPFolder:getMessageBySeqNumber	(I)Lcom/sun/mail/imap/IMAPMessage;
    //   133: aastore
    //   134: iload_3
    //   135: iconst_1
    //   136: iadd
    //   137: istore_3
    //   138: goto -32 -> 106
    //   141: astore 4
    //   143: aload_0
    //   144: aload_1
    //   145: aload_2
    //   146: invokespecial 1023	javax/mail/Folder:search	(Ljavax/mail/search/SearchTerm;[Ljavax/mail/Message;)[Ljavax/mail/Message;
    //   149: astore_2
    //   150: goto -137 -> 13
    //   153: astore_1
    //   154: new 290	javax/mail/FolderClosedException
    //   157: dup
    //   158: aload_0
    //   159: aload_1
    //   160: invokevirtual 309	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   163: invokespecial 295	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   166: athrow
    //   167: astore_1
    //   168: aload_0
    //   169: monitorexit
    //   170: aload_1
    //   171: athrow
    //   172: astore_1
    //   173: new 247	javax/mail/MessagingException
    //   176: dup
    //   177: aload_1
    //   178: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   181: aload_1
    //   182: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   185: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	186	0	this	IMAPFolder
    //   0	186	1	paramSearchTerm	javax.mail.search.SearchTerm
    //   0	186	2	paramArrayOfMessage	Message[]
    //   8	130	3	i	int
    //   21	1	4	arrayOfMessage	Message[]
    //   61	6	4	localObject1	Object
    //   69	1	4	localCommandFailedException	CommandFailedException
    //   102	21	4	arrayOfIMAPMessage	IMAPMessage[]
    //   141	1	4	localSearchException	javax.mail.search.SearchException
    //   36	91	6	localObject3	Object
    //   43	41	7	arrayOfMessageSet	com.sun.mail.imap.protocol.MessageSet[]
    // Exception table:
    //   from	to	target	type
    //   32	45	61	finally
    //   50	61	61	finally
    //   63	66	61	finally
    //   81	91	61	finally
    //   96	104	61	finally
    //   106	113	61	finally
    //   113	116	61	finally
    //   122	134	61	finally
    //   17	32	69	com/sun/mail/iap/CommandFailedException
    //   66	69	69	com/sun/mail/iap/CommandFailedException
    //   17	32	141	javax/mail/search/SearchException
    //   66	69	141	javax/mail/search/SearchException
    //   17	32	153	com/sun/mail/iap/ConnectionException
    //   66	69	153	com/sun/mail/iap/ConnectionException
    //   2	9	167	finally
    //   17	32	167	finally
    //   66	69	167	finally
    //   71	78	167	finally
    //   143	150	167	finally
    //   154	167	167	finally
    //   173	186	167	finally
    //   17	32	172	com/sun/mail/iap/ProtocolException
    //   66	69	172	com/sun/mail/iap/ProtocolException
  }
  
  /* Error */
  public void setFlags(Message[] paramArrayOfMessage, Flags paramFlags, boolean paramBoolean)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 464	com/sun/mail/imap/IMAPFolder:checkOpened	()V
    //   6: aload_0
    //   7: aload_2
    //   8: invokespecial 1030	com/sun/mail/imap/IMAPFolder:checkFlags	(Ljavax/mail/Flags;)V
    //   11: aload_1
    //   12: arraylength
    //   13: istore 4
    //   15: iload 4
    //   17: ifne +6 -> 23
    //   20: aload_0
    //   21: monitorexit
    //   22: return
    //   23: aload_0
    //   24: getfield 185	com/sun/mail/imap/IMAPFolder:messageCacheLock	Ljava/lang/Object;
    //   27: astore 5
    //   29: aload 5
    //   31: monitorenter
    //   32: aload_0
    //   33: invokespecial 532	com/sun/mail/imap/IMAPFolder:getProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   36: astore 6
    //   38: aload_1
    //   39: aconst_null
    //   40: invokestatic 538	com/sun/mail/imap/Utility:toMessageSet	([Ljavax/mail/Message;Lcom/sun/mail/imap/Utility$Condition;)[Lcom/sun/mail/imap/protocol/MessageSet;
    //   43: astore_1
    //   44: aload_1
    //   45: ifnonnull +39 -> 84
    //   48: new 487	javax/mail/MessageRemovedException
    //   51: dup
    //   52: ldc_w 540
    //   55: invokespecial 541	javax/mail/MessageRemovedException:<init>	(Ljava/lang/String;)V
    //   58: athrow
    //   59: astore_1
    //   60: new 290	javax/mail/FolderClosedException
    //   63: dup
    //   64: aload_0
    //   65: aload_1
    //   66: invokevirtual 309	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   69: invokespecial 295	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   72: athrow
    //   73: astore_1
    //   74: aload 5
    //   76: monitorexit
    //   77: aload_1
    //   78: athrow
    //   79: astore_1
    //   80: aload_0
    //   81: monitorexit
    //   82: aload_1
    //   83: athrow
    //   84: aload 6
    //   86: aload_1
    //   87: aload_2
    //   88: iload_3
    //   89: invokevirtual 1034	com/sun/mail/imap/protocol/IMAPProtocol:storeFlags	([Lcom/sun/mail/imap/protocol/MessageSet;Ljavax/mail/Flags;Z)V
    //   92: aload 5
    //   94: monitorexit
    //   95: goto -75 -> 20
    //   98: astore_1
    //   99: new 247	javax/mail/MessagingException
    //   102: dup
    //   103: aload_1
    //   104: invokevirtual 310	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   107: aload_1
    //   108: invokespecial 313	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   111: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	112	0	this	IMAPFolder
    //   0	112	1	paramArrayOfMessage	Message[]
    //   0	112	2	paramFlags	Flags
    //   0	112	3	paramBoolean	boolean
    //   13	3	4	i	int
    //   36	49	6	localIMAPProtocol	IMAPProtocol
    // Exception table:
    //   from	to	target	type
    //   32	44	59	com/sun/mail/iap/ConnectionException
    //   48	59	59	com/sun/mail/iap/ConnectionException
    //   84	92	59	com/sun/mail/iap/ConnectionException
    //   32	44	73	finally
    //   48	59	73	finally
    //   60	73	73	finally
    //   74	77	73	finally
    //   84	92	73	finally
    //   92	95	73	finally
    //   99	112	73	finally
    //   2	15	79	finally
    //   23	32	79	finally
    //   77	79	79	finally
    //   32	44	98	com/sun/mail/iap/ProtocolException
    //   48	59	98	com/sun/mail/iap/ProtocolException
    //   84	92	98	com/sun/mail/iap/ProtocolException
  }
  
  public void setQuota(final Quota paramQuota)
    throws MessagingException
  {
    doOptionalCommand("QUOTA not supported", new ProtocolCommand()
    {
      public Object doCommand(IMAPProtocol paramAnonymousIMAPProtocol)
        throws ProtocolException
      {
        paramAnonymousIMAPProtocol.setQuota(paramQuota);
        return null;
      }
    });
  }
  
  public void setSubscribed(final boolean paramBoolean)
    throws MessagingException
  {
    try
    {
      doCommandIgnoreFailure(new ProtocolCommand()
      {
        public Object doCommand(IMAPProtocol paramAnonymousIMAPProtocol)
          throws ProtocolException
        {
          if (paramBoolean) {
            paramAnonymousIMAPProtocol.subscribe(IMAPFolder.this.fullName);
          }
          for (;;)
          {
            return null;
            paramAnonymousIMAPProtocol.unsubscribe(IMAPFolder.this.fullName);
          }
        }
      });
      return;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  void waitIfIdle()
    throws ProtocolException
  {
    if ((!$assertionsDisabled) && (!Thread.holdsLock(this.messageCacheLock))) {
      throw new AssertionError();
    }
    for (;;)
    {
      if (this.idleState == 1)
      {
        this.protocol.idleAbort();
        this.idleState = 2;
      }
      try
      {
        this.messageCacheLock.wait();
        if (this.idleState != 0) {
          continue;
        }
        return;
      }
      catch (InterruptedException localInterruptedException)
      {
        for (;;) {}
      }
    }
  }
  
  public static class FetchProfileItem
    extends FetchProfile.Item
  {
    public static final FetchProfileItem HEADERS = new FetchProfileItem("HEADERS");
    public static final FetchProfileItem SIZE = new FetchProfileItem("SIZE");
    
    protected FetchProfileItem(String paramString)
    {
      super();
    }
  }
  
  public static abstract interface ProtocolCommand
  {
    public abstract Object doCommand(IMAPProtocol paramIMAPProtocol)
      throws ProtocolException;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/IMAPFolder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */