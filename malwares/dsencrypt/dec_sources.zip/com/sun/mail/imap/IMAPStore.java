package com.sun.mail.imap;

import com.sun.mail.iap.ConnectionException;
import com.sun.mail.iap.ProtocolException;
import com.sun.mail.iap.Response;
import com.sun.mail.iap.ResponseHandler;
import com.sun.mail.imap.protocol.IMAPProtocol;
import com.sun.mail.imap.protocol.Namespaces;
import com.sun.mail.imap.protocol.Namespaces.Namespace;
import java.io.PrintStream;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.mail.Folder;
import javax.mail.MessagingException;
import javax.mail.QuotaAwareStore;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.URLName;

public class IMAPStore
  extends Store
  implements QuotaAwareStore, ResponseHandler
{
  public static final int RESPONSE = 1000;
  private int appendBufferSize = -1;
  private String authorizationID;
  private int blksize = 16384;
  private volatile boolean connected = false;
  private int defaultPort = 143;
  private boolean disableAuthLogin = false;
  private boolean disableAuthPlain = false;
  private boolean enableImapEvents = false;
  private boolean enableSASL = false;
  private boolean enableStartTLS = false;
  private boolean forcePasswordRefresh = false;
  private String host;
  private boolean isSSL = false;
  private int minIdleTime = 10;
  private String name = "imap";
  private Namespaces namespaces;
  private PrintStream out;
  private String password;
  private ConnectionPool pool = new ConnectionPool();
  private int port = -1;
  private String proxyAuthUser;
  private String[] saslMechanisms;
  private String saslRealm;
  private int statusCacheTimeout = 1000;
  private String user;
  
  static
  {
    if (!IMAPStore.class.desiredAssertionStatus()) {}
    for (boolean bool = true;; bool = false)
    {
      $assertionsDisabled = bool;
      return;
    }
  }
  
  public IMAPStore(Session paramSession, URLName paramURLName)
  {
    this(paramSession, paramURLName, "imap", 143, false);
  }
  
  protected IMAPStore(Session paramSession, URLName paramURLName, String paramString, int paramInt, boolean paramBoolean)
  {
    super(paramSession, paramURLName);
    if (paramURLName != null) {
      paramString = paramURLName.getProtocol();
    }
    this.name = paramString;
    this.defaultPort = paramInt;
    this.isSSL = paramBoolean;
    this.pool.lastTimePruned = System.currentTimeMillis();
    this.debug = paramSession.getDebug();
    this.out = paramSession.getDebugOut();
    if (this.out == null) {
      this.out = System.out;
    }
    paramURLName = paramSession.getProperty("mail." + paramString + ".connectionpool.debug");
    if ((paramURLName != null) && (paramURLName.equalsIgnoreCase("true"))) {
      this.pool.debug = true;
    }
    paramURLName = paramSession.getProperty("mail." + paramString + ".partialfetch");
    if ((paramURLName != null) && (paramURLName.equalsIgnoreCase("false")))
    {
      this.blksize = -1;
      if (this.debug) {
        this.out.println("DEBUG: mail.imap.partialfetch: false");
      }
      paramURLName = paramSession.getProperty("mail." + paramString + ".statuscachetimeout");
      if (paramURLName != null)
      {
        this.statusCacheTimeout = Integer.parseInt(paramURLName);
        if (this.debug) {
          this.out.println("DEBUG: mail.imap.statuscachetimeout: " + this.statusCacheTimeout);
        }
      }
      paramURLName = paramSession.getProperty("mail." + paramString + ".appendbuffersize");
      if (paramURLName != null)
      {
        this.appendBufferSize = Integer.parseInt(paramURLName);
        if (this.debug) {
          this.out.println("DEBUG: mail.imap.appendbuffersize: " + this.appendBufferSize);
        }
      }
      paramURLName = paramSession.getProperty("mail." + paramString + ".minidletime");
      if (paramURLName != null)
      {
        this.minIdleTime = Integer.parseInt(paramURLName);
        if (this.debug) {
          this.out.println("DEBUG: mail.imap.minidletime: " + this.minIdleTime);
        }
      }
      paramURLName = paramSession.getProperty("mail." + paramString + ".connectionpoolsize");
      if (paramURLName == null) {}
    }
    try
    {
      paramInt = Integer.parseInt(paramURLName);
      if (paramInt > 0) {
        this.pool.poolSize = paramInt;
      }
    }
    catch (NumberFormatException paramURLName)
    {
      for (;;) {}
    }
    if (this.pool.debug) {
      this.out.println("DEBUG: mail.imap.connectionpoolsize: " + this.pool.poolSize);
    }
    paramURLName = paramSession.getProperty("mail." + paramString + ".connectionpooltimeout");
    if (paramURLName != null) {}
    try
    {
      paramInt = Integer.parseInt(paramURLName);
      if (paramInt > 0) {
        this.pool.clientTimeoutInterval = paramInt;
      }
    }
    catch (NumberFormatException paramURLName)
    {
      for (;;) {}
    }
    if (this.pool.debug) {
      this.out.println("DEBUG: mail.imap.connectionpooltimeout: " + this.pool.clientTimeoutInterval);
    }
    paramURLName = paramSession.getProperty("mail." + paramString + ".servertimeout");
    if (paramURLName != null) {}
    try
    {
      paramInt = Integer.parseInt(paramURLName);
      if (paramInt > 0) {
        this.pool.serverTimeoutInterval = paramInt;
      }
    }
    catch (NumberFormatException paramURLName)
    {
      Object localObject;
      for (;;) {}
    }
    if (this.pool.debug) {
      this.out.println("DEBUG: mail.imap.servertimeout: " + this.pool.serverTimeoutInterval);
    }
    paramURLName = paramSession.getProperty("mail." + paramString + ".separatestoreconnection");
    if ((paramURLName != null) && (paramURLName.equalsIgnoreCase("true")))
    {
      if (this.pool.debug) {
        this.out.println("DEBUG: dedicate a store connection");
      }
      this.pool.separateStoreConnection = true;
    }
    paramURLName = paramSession.getProperty("mail." + paramString + ".proxyauth.user");
    if (paramURLName != null)
    {
      this.proxyAuthUser = paramURLName;
      if (this.debug) {
        this.out.println("DEBUG: mail.imap.proxyauth.user: " + this.proxyAuthUser);
      }
    }
    paramURLName = paramSession.getProperty("mail." + paramString + ".auth.login.disable");
    if ((paramURLName != null) && (paramURLName.equalsIgnoreCase("true")))
    {
      if (this.debug) {
        this.out.println("DEBUG: disable AUTH=LOGIN");
      }
      this.disableAuthLogin = true;
    }
    paramURLName = paramSession.getProperty("mail." + paramString + ".auth.plain.disable");
    if ((paramURLName != null) && (paramURLName.equalsIgnoreCase("true")))
    {
      if (this.debug) {
        this.out.println("DEBUG: disable AUTH=PLAIN");
      }
      this.disableAuthPlain = true;
    }
    paramURLName = paramSession.getProperty("mail." + paramString + ".starttls.enable");
    if ((paramURLName != null) && (paramURLName.equalsIgnoreCase("true")))
    {
      if (this.debug) {
        this.out.println("DEBUG: enable STARTTLS");
      }
      this.enableStartTLS = true;
    }
    paramURLName = paramSession.getProperty("mail." + paramString + ".sasl.enable");
    if ((paramURLName != null) && (paramURLName.equalsIgnoreCase("true")))
    {
      if (this.debug) {
        this.out.println("DEBUG: enable SASL");
      }
      this.enableSASL = true;
    }
    if (this.enableSASL)
    {
      localObject = paramSession.getProperty("mail." + paramString + ".sasl.mechanisms");
      if ((localObject != null) && (((String)localObject).length() > 0))
      {
        if (this.debug) {
          this.out.println("DEBUG: SASL mechanisms allowed: " + (String)localObject);
        }
        paramURLName = new Vector(5);
        localObject = new StringTokenizer((String)localObject, " ,");
      }
    }
    for (;;)
    {
      if (!((StringTokenizer)localObject).hasMoreTokens())
      {
        this.saslMechanisms = new String[paramURLName.size()];
        paramURLName.copyInto(this.saslMechanisms);
        paramURLName = paramSession.getProperty("mail." + paramString + ".sasl.authorizationid");
        if (paramURLName != null)
        {
          this.authorizationID = paramURLName;
          if (this.debug) {
            this.out.println("DEBUG: mail.imap.sasl.authorizationid: " + this.authorizationID);
          }
        }
        paramURLName = paramSession.getProperty("mail." + paramString + ".sasl.realm");
        if (paramURLName != null)
        {
          this.saslRealm = paramURLName;
          if (this.debug) {
            this.out.println("DEBUG: mail.imap.sasl.realm: " + this.saslRealm);
          }
        }
        paramURLName = paramSession.getProperty("mail." + paramString + ".forcepasswordrefresh");
        if ((paramURLName != null) && (paramURLName.equalsIgnoreCase("true")))
        {
          if (this.debug) {
            this.out.println("DEBUG: enable forcePasswordRefresh");
          }
          this.forcePasswordRefresh = true;
        }
        paramSession = paramSession.getProperty("mail." + paramString + ".enableimapevents");
        if ((paramSession != null) && (paramSession.equalsIgnoreCase("true")))
        {
          if (this.debug) {
            this.out.println("DEBUG: enable IMAP events");
          }
          this.enableImapEvents = true;
        }
        return;
        paramURLName = paramSession.getProperty("mail." + paramString + ".fetchsize");
        if (paramURLName != null) {
          this.blksize = Integer.parseInt(paramURLName);
        }
        if (!this.debug) {
          break;
        }
        this.out.println("DEBUG: mail.imap.fetchsize: " + this.blksize);
        break;
      }
      String str = ((StringTokenizer)localObject).nextToken();
      if (str.length() > 0) {
        paramURLName.addElement(str);
      }
    }
  }
  
  private void checkConnected()
  {
    assert (Thread.holdsLock(this));
    if (!this.connected)
    {
      super.setConnected(false);
      throw new IllegalStateException("Not connected");
    }
  }
  
  private void cleanup()
  {
    cleanup(false);
  }
  
  private void cleanup(boolean paramBoolean)
  {
    if (this.debug) {
      this.out.println("DEBUG: IMAPStore cleanup, force " + paramBoolean);
    }
    Object localObject3 = null;
    int i;
    synchronized (this.pool)
    {
      if (this.pool.folders != null)
      {
        i = 0;
        ??? = this.pool.folders;
        this.pool.folders = null;
        label72:
        if (i == 0) {
          break label141;
        }
      }
    }
    for (;;)
    {
      synchronized (this.pool)
      {
        emptyConnectionPool(paramBoolean);
        this.connected = false;
        notifyConnectionListeners(3);
        if (this.debug) {
          this.out.println("DEBUG: IMAPStore cleanup done");
        }
        return;
        i = 1;
        ??? = localObject3;
        break label72;
        localObject2 = finally;
        throw ((Throwable)localObject2);
        label141:
        i = 0;
        int j = ((Vector)localObject2).size();
        localObject3 = localObject2;
        if (i >= j) {
          break;
        }
        localObject3 = (IMAPFolder)((Vector)localObject2).elementAt(i);
        if (paramBoolean) {}
        try
        {
          if (this.debug) {
            this.out.println("DEBUG: force folder to close");
          }
          ((IMAPFolder)localObject3).forceClose();
        }
        catch (MessagingException localMessagingException)
        {
          break label239;
          localObject4 = finally;
          throw ((Throwable)localObject4);
        }
        catch (IllegalStateException localIllegalStateException) {}
        if (this.debug) {
          this.out.println("DEBUG: close folder");
        }
        ((IMAPFolder)localObject3).close(false);
      }
      label239:
      i += 1;
    }
  }
  
  private void emptyConnectionPool(boolean paramBoolean)
  {
    for (;;)
    {
      int i;
      synchronized (this.pool)
      {
        i = this.pool.authenticatedConnections.size() - 1;
        if (i < 0)
        {
          this.pool.authenticatedConnections.removeAllElements();
          if (this.pool.debug) {
            this.out.println("DEBUG: removed all authenticated connections");
          }
          return;
        }
        try
        {
          IMAPProtocol localIMAPProtocol = (IMAPProtocol)this.pool.authenticatedConnections.elementAt(i);
          localIMAPProtocol.removeResponseHandler(this);
          if (paramBoolean) {
            localIMAPProtocol.disconnect();
          } else {
            localIMAPProtocol.logout();
          }
        }
        catch (ProtocolException localProtocolException) {}
      }
      i -= 1;
    }
  }
  
  /* Error */
  private Namespaces getNamespaces()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 420	com/sun/mail/imap/IMAPStore:checkConnected	()V
    //   6: aconst_null
    //   7: astore_3
    //   8: aconst_null
    //   9: astore_1
    //   10: aconst_null
    //   11: astore 4
    //   13: aconst_null
    //   14: astore 5
    //   16: aload_0
    //   17: getfield 422	com/sun/mail/imap/IMAPStore:namespaces	Lcom/sun/mail/imap/protocol/Namespaces;
    //   20: astore_2
    //   21: aload_2
    //   22: ifnonnull +39 -> 61
    //   25: aload_0
    //   26: invokevirtual 426	com/sun/mail/imap/IMAPStore:getStoreProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   29: astore_2
    //   30: aload_2
    //   31: astore 5
    //   33: aload_2
    //   34: astore_3
    //   35: aload_2
    //   36: astore_1
    //   37: aload_2
    //   38: astore 4
    //   40: aload_0
    //   41: aload_2
    //   42: invokevirtual 429	com/sun/mail/imap/protocol/IMAPProtocol:namespace	()Lcom/sun/mail/imap/protocol/Namespaces;
    //   45: putfield 422	com/sun/mail/imap/IMAPStore:namespaces	Lcom/sun/mail/imap/protocol/Namespaces;
    //   48: aload_0
    //   49: aload_2
    //   50: invokevirtual 433	com/sun/mail/imap/IMAPStore:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   53: aload_2
    //   54: ifnonnull +7 -> 61
    //   57: aload_0
    //   58: invokespecial 435	com/sun/mail/imap/IMAPStore:cleanup	()V
    //   61: aload_0
    //   62: getfield 422	com/sun/mail/imap/IMAPStore:namespaces	Lcom/sun/mail/imap/protocol/Namespaces;
    //   65: astore_1
    //   66: aload_0
    //   67: monitorexit
    //   68: aload_1
    //   69: areturn
    //   70: astore_1
    //   71: aload_0
    //   72: aload 5
    //   74: invokevirtual 433	com/sun/mail/imap/IMAPStore:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   77: aload 5
    //   79: ifnonnull -18 -> 61
    //   82: aload_0
    //   83: invokespecial 435	com/sun/mail/imap/IMAPStore:cleanup	()V
    //   86: goto -25 -> 61
    //   89: astore_1
    //   90: aload_0
    //   91: monitorexit
    //   92: aload_1
    //   93: athrow
    //   94: astore_2
    //   95: aload_3
    //   96: astore_1
    //   97: new 437	javax/mail/StoreClosedException
    //   100: dup
    //   101: aload_0
    //   102: aload_2
    //   103: invokevirtual 440	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   106: invokespecial 443	javax/mail/StoreClosedException:<init>	(Ljavax/mail/Store;Ljava/lang/String;)V
    //   109: athrow
    //   110: astore_2
    //   111: aload_0
    //   112: aload_1
    //   113: invokevirtual 433	com/sun/mail/imap/IMAPStore:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   116: aload_1
    //   117: ifnonnull +7 -> 124
    //   120: aload_0
    //   121: invokespecial 435	com/sun/mail/imap/IMAPStore:cleanup	()V
    //   124: aload_2
    //   125: athrow
    //   126: astore_2
    //   127: aload 4
    //   129: astore_1
    //   130: new 353	javax/mail/MessagingException
    //   133: dup
    //   134: aload_2
    //   135: invokevirtual 444	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   138: aload_2
    //   139: invokespecial 447	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   142: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	143	0	this	IMAPStore
    //   9	60	1	localObject1	Object
    //   70	1	1	localBadCommandException	com.sun.mail.iap.BadCommandException
    //   89	4	1	localObject2	Object
    //   96	34	1	localObject3	Object
    //   20	34	2	localObject4	Object
    //   94	9	2	localConnectionException	ConnectionException
    //   110	15	2	localObject5	Object
    //   126	13	2	localProtocolException	ProtocolException
    //   7	89	3	localObject6	Object
    //   11	117	4	localObject7	Object
    //   14	64	5	localObject8	Object
    // Exception table:
    //   from	to	target	type
    //   25	30	70	com/sun/mail/iap/BadCommandException
    //   40	48	70	com/sun/mail/iap/BadCommandException
    //   2	6	89	finally
    //   16	21	89	finally
    //   48	53	89	finally
    //   57	61	89	finally
    //   61	66	89	finally
    //   71	77	89	finally
    //   82	86	89	finally
    //   111	116	89	finally
    //   120	124	89	finally
    //   124	126	89	finally
    //   25	30	94	com/sun/mail/iap/ConnectionException
    //   40	48	94	com/sun/mail/iap/ConnectionException
    //   25	30	110	finally
    //   40	48	110	finally
    //   97	110	110	finally
    //   130	143	110	finally
    //   25	30	126	com/sun/mail/iap/ProtocolException
    //   40	48	126	com/sun/mail/iap/ProtocolException
  }
  
  private void login(IMAPProtocol paramIMAPProtocol, String paramString1, String paramString2)
    throws ProtocolException
  {
    if ((this.enableStartTLS) && (paramIMAPProtocol.hasCapability("STARTTLS")))
    {
      paramIMAPProtocol.startTLS();
      paramIMAPProtocol.capability();
    }
    if (paramIMAPProtocol.isAuthenticated()) {
      return;
    }
    paramIMAPProtocol.getCapabilities().put("__PRELOGIN__", "");
    String str;
    if (this.authorizationID != null) {
      str = this.authorizationID;
    }
    for (;;)
    {
      if (this.enableSASL) {
        paramIMAPProtocol.sasllogin(this.saslMechanisms, this.saslRealm, str, paramString1, paramString2);
      }
      if (paramIMAPProtocol.isAuthenticated())
      {
        label92:
        if (this.proxyAuthUser != null) {
          paramIMAPProtocol.proxyauth(this.proxyAuthUser);
        }
        if (!paramIMAPProtocol.hasCapability("__PRELOGIN__")) {
          break;
        }
      }
      try
      {
        paramIMAPProtocol.capability();
        return;
      }
      catch (ConnectionException paramIMAPProtocol)
      {
        throw paramIMAPProtocol;
        if (this.proxyAuthUser != null)
        {
          str = this.proxyAuthUser;
        }
        else
        {
          str = paramString1;
          continue;
          if ((paramIMAPProtocol.hasCapability("AUTH=PLAIN")) && (!this.disableAuthPlain))
          {
            paramIMAPProtocol.authplain(str, paramString1, paramString2);
            break label92;
          }
          if (((paramIMAPProtocol.hasCapability("AUTH-LOGIN")) || (paramIMAPProtocol.hasCapability("AUTH=LOGIN"))) && (!this.disableAuthLogin))
          {
            paramIMAPProtocol.authlogin(paramString1, paramString2);
            break label92;
          }
          if (!paramIMAPProtocol.hasCapability("LOGINDISABLED"))
          {
            paramIMAPProtocol.login(paramString1, paramString2);
            break label92;
          }
          throw new ProtocolException("No login methods supported!");
        }
      }
      catch (ProtocolException paramIMAPProtocol) {}
    }
  }
  
  private Folder[] namespaceToFolders(Namespaces.Namespace[] paramArrayOfNamespace, String paramString)
  {
    Folder[] arrayOfFolder = new Folder[paramArrayOfNamespace.length];
    int i = 0;
    if (i >= arrayOfFolder.length) {
      return arrayOfFolder;
    }
    String str2 = paramArrayOfNamespace[i].prefix;
    String str1;
    label85:
    char c;
    if (paramString == null)
    {
      int j = str2.length();
      str1 = str2;
      if (j > 0)
      {
        str1 = str2;
        if (str2.charAt(j - 1) == paramArrayOfNamespace[i].delimiter) {
          str1 = str2.substring(0, j - 1);
        }
      }
      c = paramArrayOfNamespace[i].delimiter;
      if (paramString != null) {
        break label151;
      }
    }
    label151:
    for (boolean bool = true;; bool = false)
    {
      arrayOfFolder[i] = new IMAPFolder(str1, c, this, bool);
      i += 1;
      break;
      str1 = str2 + paramString;
      break label85;
    }
  }
  
  private void timeoutConnections()
  {
    for (;;)
    {
      int i;
      IMAPProtocol localIMAPProtocol;
      synchronized (this.pool)
      {
        if ((System.currentTimeMillis() - this.pool.lastTimePruned > this.pool.pruningInterval) && (this.pool.authenticatedConnections.size() > 1))
        {
          if (this.pool.debug)
          {
            this.out.println("DEBUG: checking for connections to prune: " + (System.currentTimeMillis() - this.pool.lastTimePruned));
            this.out.println("DEBUG: clientTimeoutInterval: " + this.pool.clientTimeoutInterval);
          }
          i = this.pool.authenticatedConnections.size() - 1;
          if (i <= 0) {
            this.pool.lastTimePruned = System.currentTimeMillis();
          }
        }
        else
        {
          return;
        }
        localIMAPProtocol = (IMAPProtocol)this.pool.authenticatedConnections.elementAt(i);
        if (this.pool.debug) {
          this.out.println("DEBUG: protocol last used: " + (System.currentTimeMillis() - localIMAPProtocol.getTimestamp()));
        }
        if (System.currentTimeMillis() - localIMAPProtocol.getTimestamp() > this.pool.clientTimeoutInterval)
        {
          if (this.pool.debug)
          {
            this.out.println("DEBUG: authenticated connection timed out");
            this.out.println("DEBUG: logging out the connection");
          }
          localIMAPProtocol.removeResponseHandler(this);
          this.pool.authenticatedConnections.removeElementAt(i);
        }
      }
      try
      {
        localIMAPProtocol.logout();
        i -= 1;
        continue;
        localObject = finally;
        throw ((Throwable)localObject);
      }
      catch (ProtocolException localProtocolException)
      {
        for (;;) {}
      }
    }
  }
  
  private void waitIfIdle()
    throws ProtocolException
  {
    if ((!$assertionsDisabled) && (!Thread.holdsLock(this.pool))) {
      throw new AssertionError();
    }
    for (;;)
    {
      if (this.pool.idleState == 1)
      {
        this.pool.idleProtocol.idleAbort();
        this.pool.idleState = 2;
      }
      try
      {
        this.pool.wait();
        if (this.pool.idleState != 0) {
          continue;
        }
        return;
      }
      catch (InterruptedException localInterruptedException)
      {
        for (;;) {}
      }
    }
  }
  
  boolean allowReadOnlySelect()
  {
    String str = this.session.getProperty("mail." + this.name + ".allowreadonlyselect");
    return (str != null) && (str.equalsIgnoreCase("true"));
  }
  
  /* Error */
  public void close()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 587	javax/mail/Store:isConnected	()Z
    //   6: istore_1
    //   7: iload_1
    //   8: ifne +6 -> 14
    //   11: aload_0
    //   12: monitorexit
    //   13: return
    //   14: aconst_null
    //   15: astore 5
    //   17: aconst_null
    //   18: astore 4
    //   20: aload 4
    //   22: astore_3
    //   23: aload 5
    //   25: astore_2
    //   26: aload_0
    //   27: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   30: astore 6
    //   32: aload 4
    //   34: astore_3
    //   35: aload 5
    //   37: astore_2
    //   38: aload 6
    //   40: monitorenter
    //   41: aload_0
    //   42: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   45: invokestatic 395	com/sun/mail/imap/IMAPStore$ConnectionPool:access$10	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Ljava/util/Vector;
    //   48: invokevirtual 590	java/util/Vector:isEmpty	()Z
    //   51: istore_1
    //   52: aload 6
    //   54: monitorexit
    //   55: iload_1
    //   56: ifeq +105 -> 161
    //   59: aload 4
    //   61: astore_3
    //   62: aload 5
    //   64: astore_2
    //   65: aload_0
    //   66: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   69: invokestatic 207	com/sun/mail/imap/IMAPStore$ConnectionPool:access$3	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Z
    //   72: ifeq +19 -> 91
    //   75: aload 4
    //   77: astore_3
    //   78: aload 5
    //   80: astore_2
    //   81: aload_0
    //   82: getfield 132	com/sun/mail/imap/IMAPStore:out	Ljava/io/PrintStream;
    //   85: ldc_w 592
    //   88: invokevirtual 176	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   91: aload 4
    //   93: astore_3
    //   94: aload 5
    //   96: astore_2
    //   97: aload_0
    //   98: invokespecial 435	com/sun/mail/imap/IMAPStore:cleanup	()V
    //   101: aload_0
    //   102: aconst_null
    //   103: invokevirtual 433	com/sun/mail/imap/IMAPStore:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   106: goto -95 -> 11
    //   109: astore_2
    //   110: aload_0
    //   111: monitorexit
    //   112: aload_2
    //   113: athrow
    //   114: astore 7
    //   116: aload 6
    //   118: monitorexit
    //   119: aload 4
    //   121: astore_3
    //   122: aload 5
    //   124: astore_2
    //   125: aload 7
    //   127: athrow
    //   128: astore 4
    //   130: aload_3
    //   131: astore_2
    //   132: aload_0
    //   133: invokespecial 435	com/sun/mail/imap/IMAPStore:cleanup	()V
    //   136: aload_3
    //   137: astore_2
    //   138: new 353	javax/mail/MessagingException
    //   141: dup
    //   142: aload 4
    //   144: invokevirtual 444	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   147: aload 4
    //   149: invokespecial 447	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   152: athrow
    //   153: astore_3
    //   154: aload_0
    //   155: aload_2
    //   156: invokevirtual 433	com/sun/mail/imap/IMAPStore:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   159: aload_3
    //   160: athrow
    //   161: aload 4
    //   163: astore_3
    //   164: aload 5
    //   166: astore_2
    //   167: aload_0
    //   168: invokevirtual 426	com/sun/mail/imap/IMAPStore:getStoreProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   171: astore 4
    //   173: aload 4
    //   175: astore_3
    //   176: aload 4
    //   178: astore_2
    //   179: aload_0
    //   180: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   183: astore 5
    //   185: aload 4
    //   187: astore_3
    //   188: aload 4
    //   190: astore_2
    //   191: aload 5
    //   193: monitorenter
    //   194: aload_0
    //   195: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   198: invokestatic 395	com/sun/mail/imap/IMAPStore$ConnectionPool:access$10	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Ljava/util/Vector;
    //   201: aload 4
    //   203: invokevirtual 595	java/util/Vector:removeElement	(Ljava/lang/Object;)Z
    //   206: pop
    //   207: aload 5
    //   209: monitorexit
    //   210: aload 4
    //   212: astore_3
    //   213: aload 4
    //   215: astore_2
    //   216: aload 4
    //   218: invokevirtual 412	com/sun/mail/imap/protocol/IMAPProtocol:logout	()V
    //   221: aload_0
    //   222: aload 4
    //   224: invokevirtual 433	com/sun/mail/imap/IMAPStore:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   227: goto -216 -> 11
    //   230: astore 6
    //   232: aload 5
    //   234: monitorexit
    //   235: aload 4
    //   237: astore_3
    //   238: aload 4
    //   240: astore_2
    //   241: aload 6
    //   243: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	244	0	this	IMAPStore
    //   6	50	1	bool	boolean
    //   25	72	2	localConnectionPool1	ConnectionPool
    //   109	4	2	localObject1	Object
    //   124	117	2	localObject2	Object
    //   22	115	3	localObject3	Object
    //   153	7	3	localObject4	Object
    //   163	75	3	localObject5	Object
    //   18	102	4	localObject6	Object
    //   128	34	4	localProtocolException	ProtocolException
    //   171	68	4	localIMAPProtocol	IMAPProtocol
    //   15	218	5	localConnectionPool2	ConnectionPool
    //   30	87	6	localConnectionPool3	ConnectionPool
    //   230	12	6	localObject7	Object
    //   114	12	7	localObject8	Object
    // Exception table:
    //   from	to	target	type
    //   2	7	109	finally
    //   101	106	109	finally
    //   154	161	109	finally
    //   221	227	109	finally
    //   41	55	114	finally
    //   116	119	114	finally
    //   26	32	128	com/sun/mail/iap/ProtocolException
    //   38	41	128	com/sun/mail/iap/ProtocolException
    //   65	75	128	com/sun/mail/iap/ProtocolException
    //   81	91	128	com/sun/mail/iap/ProtocolException
    //   97	101	128	com/sun/mail/iap/ProtocolException
    //   125	128	128	com/sun/mail/iap/ProtocolException
    //   167	173	128	com/sun/mail/iap/ProtocolException
    //   179	185	128	com/sun/mail/iap/ProtocolException
    //   191	194	128	com/sun/mail/iap/ProtocolException
    //   216	221	128	com/sun/mail/iap/ProtocolException
    //   241	244	128	com/sun/mail/iap/ProtocolException
    //   26	32	153	finally
    //   38	41	153	finally
    //   65	75	153	finally
    //   81	91	153	finally
    //   97	101	153	finally
    //   125	128	153	finally
    //   132	136	153	finally
    //   138	153	153	finally
    //   167	173	153	finally
    //   179	185	153	finally
    //   191	194	153	finally
    //   216	221	153	finally
    //   241	244	153	finally
    //   194	210	230	finally
    //   232	235	230	finally
  }
  
  protected void finalize()
    throws Throwable
  {
    super.finalize();
    close();
  }
  
  int getAppendBufferSize()
  {
    return this.appendBufferSize;
  }
  
  boolean getConnectionPoolDebug()
  {
    return this.pool.debug;
  }
  
  public Folder getDefaultFolder()
    throws MessagingException
  {
    try
    {
      checkConnected();
      DefaultFolder localDefaultFolder = new DefaultFolder(this);
      return localDefaultFolder;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  int getFetchBlockSize()
  {
    return this.blksize;
  }
  
  public Folder getFolder(String paramString)
    throws MessagingException
  {
    try
    {
      checkConnected();
      paramString = new IMAPFolder(paramString, 65535, this);
      return paramString;
    }
    finally
    {
      paramString = finally;
      throw paramString;
    }
  }
  
  public Folder getFolder(URLName paramURLName)
    throws MessagingException
  {
    try
    {
      checkConnected();
      paramURLName = new IMAPFolder(paramURLName.getFile(), 65535, this);
      return paramURLName;
    }
    finally
    {
      paramURLName = finally;
      throw paramURLName;
    }
  }
  
  int getMinIdleTime()
  {
    return this.minIdleTime;
  }
  
  public Folder[] getPersonalNamespaces()
    throws MessagingException
  {
    Namespaces localNamespaces = getNamespaces();
    if ((localNamespaces == null) || (localNamespaces.personal == null)) {
      return super.getPersonalNamespaces();
    }
    return namespaceToFolders(localNamespaces.personal, null);
  }
  
  /* Error */
  IMAPProtocol getProtocol(IMAPFolder paramIMAPFolder)
    throws MessagingException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 9
    //   3: aload 9
    //   5: ifnull +6 -> 11
    //   8: aload 9
    //   10: areturn
    //   11: aload_0
    //   12: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   15: astore 11
    //   17: aload 11
    //   19: monitorenter
    //   20: aload_0
    //   21: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   24: invokestatic 395	com/sun/mail/imap/IMAPStore$ConnectionPool:access$10	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Ljava/util/Vector;
    //   27: invokevirtual 590	java/util/Vector:isEmpty	()Z
    //   30: ifne +37 -> 67
    //   33: aload_0
    //   34: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   37: invokestatic 395	com/sun/mail/imap/IMAPStore$ConnectionPool:access$10	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Ljava/util/Vector;
    //   40: invokevirtual 292	java/util/Vector:size	()I
    //   43: iconst_1
    //   44: if_icmpne +220 -> 264
    //   47: aload_0
    //   48: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   51: invokestatic 645	com/sun/mail/imap/IMAPStore$ConnectionPool:access$11	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Z
    //   54: ifne +13 -> 67
    //   57: aload_0
    //   58: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   61: invokestatic 648	com/sun/mail/imap/IMAPStore$ConnectionPool:access$12	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Z
    //   64: ifeq +200 -> 264
    //   67: aload_0
    //   68: getfield 126	com/sun/mail/imap/IMAPStore:debug	Z
    //   71: ifeq +13 -> 84
    //   74: aload_0
    //   75: getfield 132	com/sun/mail/imap/IMAPStore:out	Ljava/io/PrintStream;
    //   78: ldc_w 650
    //   81: invokevirtual 176	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   84: aload_0
    //   85: getfield 94	com/sun/mail/imap/IMAPStore:forcePasswordRefresh	Z
    //   88: istore_2
    //   89: iload_2
    //   90: ifeq +59 -> 149
    //   93: aload_0
    //   94: getfield 652	com/sun/mail/imap/IMAPStore:host	Ljava/lang/String;
    //   97: invokestatic 658	java/net/InetAddress:getByName	(Ljava/lang/String;)Ljava/net/InetAddress;
    //   100: astore 10
    //   102: aload_0
    //   103: getfield 582	com/sun/mail/imap/IMAPStore:session	Ljavax/mail/Session;
    //   106: aload 10
    //   108: aload_0
    //   109: getfield 76	com/sun/mail/imap/IMAPStore:port	I
    //   112: aload_0
    //   113: getfield 70	com/sun/mail/imap/IMAPStore:name	Ljava/lang/String;
    //   116: aconst_null
    //   117: aload_0
    //   118: getfield 660	com/sun/mail/imap/IMAPStore:user	Ljava/lang/String;
    //   121: invokevirtual 664	javax/mail/Session:requestPasswordAuthentication	(Ljava/net/InetAddress;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)Ljavax/mail/PasswordAuthentication;
    //   124: astore 10
    //   126: aload 10
    //   128: ifnull +21 -> 149
    //   131: aload_0
    //   132: aload 10
    //   134: invokevirtual 669	javax/mail/PasswordAuthentication:getUserName	()Ljava/lang/String;
    //   137: putfield 660	com/sun/mail/imap/IMAPStore:user	Ljava/lang/String;
    //   140: aload_0
    //   141: aload 10
    //   143: invokevirtual 672	javax/mail/PasswordAuthentication:getPassword	()Ljava/lang/String;
    //   146: putfield 674	com/sun/mail/imap/IMAPStore:password	Ljava/lang/String;
    //   149: new 402	com/sun/mail/imap/protocol/IMAPProtocol
    //   152: dup
    //   153: aload_0
    //   154: getfield 70	com/sun/mail/imap/IMAPStore:name	Ljava/lang/String;
    //   157: aload_0
    //   158: getfield 652	com/sun/mail/imap/IMAPStore:host	Ljava/lang/String;
    //   161: aload_0
    //   162: getfield 76	com/sun/mail/imap/IMAPStore:port	I
    //   165: aload_0
    //   166: getfield 582	com/sun/mail/imap/IMAPStore:session	Ljavax/mail/Session;
    //   169: invokevirtual 123	javax/mail/Session:getDebug	()Z
    //   172: aload_0
    //   173: getfield 582	com/sun/mail/imap/IMAPStore:session	Ljavax/mail/Session;
    //   176: invokevirtual 130	javax/mail/Session:getDebugOut	()Ljava/io/PrintStream;
    //   179: aload_0
    //   180: getfield 582	com/sun/mail/imap/IMAPStore:session	Ljavax/mail/Session;
    //   183: invokevirtual 678	javax/mail/Session:getProperties	()Ljava/util/Properties;
    //   186: aload_0
    //   187: getfield 74	com/sun/mail/imap/IMAPStore:isSSL	Z
    //   190: invokespecial 681	com/sun/mail/imap/protocol/IMAPProtocol:<init>	(Ljava/lang/String;Ljava/lang/String;IZLjava/io/PrintStream;Ljava/util/Properties;Z)V
    //   193: astore 10
    //   195: aload_0
    //   196: aload 10
    //   198: aload_0
    //   199: getfield 660	com/sun/mail/imap/IMAPStore:user	Ljava/lang/String;
    //   202: aload_0
    //   203: getfield 674	com/sun/mail/imap/IMAPStore:password	Ljava/lang/String;
    //   206: invokespecial 683	com/sun/mail/imap/IMAPStore:login	(Lcom/sun/mail/imap/protocol/IMAPProtocol;Ljava/lang/String;Ljava/lang/String;)V
    //   209: aload 10
    //   211: astore 9
    //   213: aload 9
    //   215: astore 10
    //   217: aload 9
    //   219: ifnonnull +154 -> 373
    //   222: new 353	javax/mail/MessagingException
    //   225: dup
    //   226: ldc_w 685
    //   229: invokespecial 686	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   232: athrow
    //   233: aload 11
    //   235: monitorexit
    //   236: aload_1
    //   237: athrow
    //   238: astore 10
    //   240: aconst_null
    //   241: astore 10
    //   243: goto -141 -> 102
    //   246: astore 10
    //   248: aload 9
    //   250: ifnull +8 -> 258
    //   253: aload 9
    //   255: invokevirtual 409	com/sun/mail/imap/protocol/IMAPProtocol:disconnect	()V
    //   258: aconst_null
    //   259: astore 9
    //   261: goto -48 -> 213
    //   264: aload_0
    //   265: getfield 126	com/sun/mail/imap/IMAPStore:debug	Z
    //   268: ifeq +36 -> 304
    //   271: aload_0
    //   272: getfield 132	com/sun/mail/imap/IMAPStore:out	Ljava/io/PrintStream;
    //   275: new 135	java/lang/StringBuilder
    //   278: dup
    //   279: ldc_w 688
    //   282: invokespecial 140	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   285: aload_0
    //   286: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   289: invokestatic 395	com/sun/mail/imap/IMAPStore$ConnectionPool:access$10	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Ljava/util/Vector;
    //   292: invokevirtual 292	java/util/Vector:size	()I
    //   295: invokevirtual 189	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   298: invokevirtual 149	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   301: invokevirtual 176	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   304: aload_0
    //   305: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   308: invokestatic 395	com/sun/mail/imap/IMAPStore$ConnectionPool:access$10	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Ljava/util/Vector;
    //   311: invokevirtual 692	java/util/Vector:lastElement	()Ljava/lang/Object;
    //   314: checkcast 402	com/sun/mail/imap/protocol/IMAPProtocol
    //   317: astore 10
    //   319: aload_0
    //   320: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   323: invokestatic 395	com/sun/mail/imap/IMAPStore$ConnectionPool:access$10	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Ljava/util/Vector;
    //   326: aload 10
    //   328: invokevirtual 595	java/util/Vector:removeElement	(Ljava/lang/Object;)Z
    //   331: pop
    //   332: invokestatic 114	java/lang/System:currentTimeMillis	()J
    //   335: lstore_3
    //   336: aload 10
    //   338: invokevirtual 549	com/sun/mail/imap/protocol/IMAPProtocol:getTimestamp	()J
    //   341: lstore 5
    //   343: aload_0
    //   344: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   347: invokestatic 237	com/sun/mail/imap/IMAPStore$ConnectionPool:access$8	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)J
    //   350: lstore 7
    //   352: lload_3
    //   353: lload 5
    //   355: lsub
    //   356: lload 7
    //   358: lcmp
    //   359: ifle +8 -> 367
    //   362: aload 10
    //   364: invokevirtual 695	com/sun/mail/imap/protocol/IMAPProtocol:noop	()V
    //   367: aload 10
    //   369: aload_0
    //   370: invokevirtual 406	com/sun/mail/imap/protocol/IMAPProtocol:removeResponseHandler	(Lcom/sun/mail/iap/ResponseHandler;)V
    //   373: aload_0
    //   374: invokespecial 697	com/sun/mail/imap/IMAPStore:timeoutConnections	()V
    //   377: aload_1
    //   378: ifnull +38 -> 416
    //   381: aload_0
    //   382: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   385: invokestatic 362	com/sun/mail/imap/IMAPStore$ConnectionPool:access$13	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Ljava/util/Vector;
    //   388: ifnonnull +17 -> 405
    //   391: aload_0
    //   392: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   395: new 276	java/util/Vector
    //   398: dup
    //   399: invokespecial 698	java/util/Vector:<init>	()V
    //   402: invokestatic 366	com/sun/mail/imap/IMAPStore$ConnectionPool:access$14	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;Ljava/util/Vector;)V
    //   405: aload_0
    //   406: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   409: invokestatic 362	com/sun/mail/imap/IMAPStore$ConnectionPool:access$13	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Ljava/util/Vector;
    //   412: aload_1
    //   413: invokevirtual 329	java/util/Vector:addElement	(Ljava/lang/Object;)V
    //   416: aload 11
    //   418: monitorexit
    //   419: aload 10
    //   421: astore 9
    //   423: goto -420 -> 3
    //   426: astore 9
    //   428: aload 10
    //   430: aload_0
    //   431: invokevirtual 406	com/sun/mail/imap/protocol/IMAPProtocol:removeResponseHandler	(Lcom/sun/mail/iap/ResponseHandler;)V
    //   434: aload 10
    //   436: invokevirtual 409	com/sun/mail/imap/protocol/IMAPProtocol:disconnect	()V
    //   439: aload 11
    //   441: monitorexit
    //   442: aconst_null
    //   443: astore 9
    //   445: goto -442 -> 3
    //   448: astore 9
    //   450: goto -192 -> 258
    //   453: astore_1
    //   454: goto -221 -> 233
    //   457: astore 9
    //   459: goto -20 -> 439
    //   462: astore 9
    //   464: aload 10
    //   466: astore 9
    //   468: goto -220 -> 248
    //   471: astore_1
    //   472: goto -239 -> 233
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	475	0	this	IMAPStore
    //   0	475	1	paramIMAPFolder	IMAPFolder
    //   88	2	2	bool	boolean
    //   335	18	3	l1	long
    //   341	13	5	l2	long
    //   350	7	7	l3	long
    //   1	421	9	localObject1	Object
    //   426	1	9	localProtocolException	ProtocolException
    //   443	1	9	localObject2	Object
    //   448	1	9	localException1	Exception
    //   457	1	9	localObject3	Object
    //   462	1	9	localException2	Exception
    //   466	1	9	localObject4	Object
    //   100	116	10	localObject5	Object
    //   238	1	10	localUnknownHostException	java.net.UnknownHostException
    //   241	1	10	localObject6	Object
    //   246	1	10	localException3	Exception
    //   317	148	10	localIMAPProtocol	IMAPProtocol
    //   15	425	11	localConnectionPool	ConnectionPool
    // Exception table:
    //   from	to	target	type
    //   93	102	238	java/net/UnknownHostException
    //   84	89	246	java/lang/Exception
    //   93	102	246	java/lang/Exception
    //   102	126	246	java/lang/Exception
    //   131	149	246	java/lang/Exception
    //   149	195	246	java/lang/Exception
    //   362	367	426	com/sun/mail/iap/ProtocolException
    //   253	258	448	java/lang/Exception
    //   20	67	453	finally
    //   67	84	453	finally
    //   84	89	453	finally
    //   93	102	453	finally
    //   102	126	453	finally
    //   131	149	453	finally
    //   149	195	453	finally
    //   264	304	453	finally
    //   304	319	453	finally
    //   428	439	457	finally
    //   195	209	462	java/lang/Exception
    //   195	209	471	finally
    //   222	233	471	finally
    //   233	236	471	finally
    //   253	258	471	finally
    //   319	352	471	finally
    //   362	367	471	finally
    //   367	373	471	finally
    //   373	377	471	finally
    //   381	405	471	finally
    //   405	416	471	finally
    //   416	419	471	finally
    //   439	442	471	finally
  }
  
  /* Error */
  public javax.mail.Quota[] getQuota(String paramString)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 420	com/sun/mail/imap/IMAPStore:checkConnected	()V
    //   6: aconst_null
    //   7: checkcast 702	[Ljavax/mail/Quota;
    //   10: astore_2
    //   11: aconst_null
    //   12: astore_2
    //   13: aconst_null
    //   14: astore 5
    //   16: aconst_null
    //   17: astore 6
    //   19: aconst_null
    //   20: astore 4
    //   22: aload_0
    //   23: invokevirtual 426	com/sun/mail/imap/IMAPStore:getStoreProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   26: astore_3
    //   27: aload_3
    //   28: astore 4
    //   30: aload_3
    //   31: astore_2
    //   32: aload_3
    //   33: astore 5
    //   35: aload_3
    //   36: astore 6
    //   38: aload_3
    //   39: aload_1
    //   40: invokevirtual 705	com/sun/mail/imap/protocol/IMAPProtocol:getQuotaRoot	(Ljava/lang/String;)[Ljavax/mail/Quota;
    //   43: astore_1
    //   44: aload_0
    //   45: aload_3
    //   46: invokevirtual 433	com/sun/mail/imap/IMAPStore:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   49: aload_3
    //   50: ifnonnull +7 -> 57
    //   53: aload_0
    //   54: invokespecial 435	com/sun/mail/imap/IMAPStore:cleanup	()V
    //   57: aload_0
    //   58: monitorexit
    //   59: aload_1
    //   60: areturn
    //   61: astore_1
    //   62: aload 4
    //   64: astore_2
    //   65: new 353	javax/mail/MessagingException
    //   68: dup
    //   69: ldc_w 707
    //   72: aload_1
    //   73: invokespecial 447	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   76: athrow
    //   77: astore_1
    //   78: aload_0
    //   79: aload_2
    //   80: invokevirtual 433	com/sun/mail/imap/IMAPStore:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   83: aload_2
    //   84: ifnonnull +7 -> 91
    //   87: aload_0
    //   88: invokespecial 435	com/sun/mail/imap/IMAPStore:cleanup	()V
    //   91: aload_1
    //   92: athrow
    //   93: astore_1
    //   94: aload_0
    //   95: monitorexit
    //   96: aload_1
    //   97: athrow
    //   98: astore_1
    //   99: aload 5
    //   101: astore_2
    //   102: new 437	javax/mail/StoreClosedException
    //   105: dup
    //   106: aload_0
    //   107: aload_1
    //   108: invokevirtual 440	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   111: invokespecial 443	javax/mail/StoreClosedException:<init>	(Ljavax/mail/Store;Ljava/lang/String;)V
    //   114: athrow
    //   115: astore_1
    //   116: aload 6
    //   118: astore_2
    //   119: new 353	javax/mail/MessagingException
    //   122: dup
    //   123: aload_1
    //   124: invokevirtual 444	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   127: aload_1
    //   128: invokespecial 447	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   131: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	132	0	this	IMAPStore
    //   0	132	1	paramString	String
    //   10	109	2	localObject1	Object
    //   26	24	3	localIMAPProtocol	IMAPProtocol
    //   20	43	4	localObject2	Object
    //   14	86	5	localObject3	Object
    //   17	100	6	localObject4	Object
    // Exception table:
    //   from	to	target	type
    //   22	27	61	com/sun/mail/iap/BadCommandException
    //   38	44	61	com/sun/mail/iap/BadCommandException
    //   22	27	77	finally
    //   38	44	77	finally
    //   65	77	77	finally
    //   102	115	77	finally
    //   119	132	77	finally
    //   2	11	93	finally
    //   44	49	93	finally
    //   53	57	93	finally
    //   78	83	93	finally
    //   87	91	93	finally
    //   91	93	93	finally
    //   22	27	98	com/sun/mail/iap/ConnectionException
    //   38	44	98	com/sun/mail/iap/ConnectionException
    //   22	27	115	com/sun/mail/iap/ProtocolException
    //   38	44	115	com/sun/mail/iap/ProtocolException
  }
  
  Session getSession()
  {
    return this.session;
  }
  
  public Folder[] getSharedNamespaces()
    throws MessagingException
  {
    Namespaces localNamespaces = getNamespaces();
    if ((localNamespaces == null) || (localNamespaces.shared == null)) {
      return super.getSharedNamespaces();
    }
    return namespaceToFolders(localNamespaces.shared, null);
  }
  
  int getStatusCacheTimeout()
  {
    return this.statusCacheTimeout;
  }
  
  /* Error */
  IMAPProtocol getStoreProtocol()
    throws ProtocolException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: aload_2
    //   3: ifnull +5 -> 8
    //   6: aload_2
    //   7: areturn
    //   8: aload_0
    //   9: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   12: astore 4
    //   14: aload 4
    //   16: monitorenter
    //   17: aload_0
    //   18: invokespecial 718	com/sun/mail/imap/IMAPStore:waitIfIdle	()V
    //   21: aload_0
    //   22: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   25: invokestatic 395	com/sun/mail/imap/IMAPStore$ConnectionPool:access$10	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Ljava/util/Vector;
    //   28: invokevirtual 590	java/util/Vector:isEmpty	()Z
    //   31: ifeq +166 -> 197
    //   34: aload_0
    //   35: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   38: invokestatic 207	com/sun/mail/imap/IMAPStore$ConnectionPool:access$3	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Z
    //   41: ifeq +13 -> 54
    //   44: aload_0
    //   45: getfield 132	com/sun/mail/imap/IMAPStore:out	Ljava/io/PrintStream;
    //   48: ldc_w 720
    //   51: invokevirtual 176	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   54: new 402	com/sun/mail/imap/protocol/IMAPProtocol
    //   57: dup
    //   58: aload_0
    //   59: getfield 70	com/sun/mail/imap/IMAPStore:name	Ljava/lang/String;
    //   62: aload_0
    //   63: getfield 652	com/sun/mail/imap/IMAPStore:host	Ljava/lang/String;
    //   66: aload_0
    //   67: getfield 76	com/sun/mail/imap/IMAPStore:port	I
    //   70: aload_0
    //   71: getfield 582	com/sun/mail/imap/IMAPStore:session	Ljavax/mail/Session;
    //   74: invokevirtual 123	javax/mail/Session:getDebug	()Z
    //   77: aload_0
    //   78: getfield 582	com/sun/mail/imap/IMAPStore:session	Ljavax/mail/Session;
    //   81: invokevirtual 130	javax/mail/Session:getDebugOut	()Ljava/io/PrintStream;
    //   84: aload_0
    //   85: getfield 582	com/sun/mail/imap/IMAPStore:session	Ljavax/mail/Session;
    //   88: invokevirtual 678	javax/mail/Session:getProperties	()Ljava/util/Properties;
    //   91: aload_0
    //   92: getfield 74	com/sun/mail/imap/IMAPStore:isSSL	Z
    //   95: invokespecial 681	com/sun/mail/imap/protocol/IMAPProtocol:<init>	(Ljava/lang/String;Ljava/lang/String;IZLjava/io/PrintStream;Ljava/util/Properties;Z)V
    //   98: astore_3
    //   99: aload_0
    //   100: aload_3
    //   101: aload_0
    //   102: getfield 660	com/sun/mail/imap/IMAPStore:user	Ljava/lang/String;
    //   105: aload_0
    //   106: getfield 674	com/sun/mail/imap/IMAPStore:password	Ljava/lang/String;
    //   109: invokespecial 683	com/sun/mail/imap/IMAPStore:login	(Lcom/sun/mail/imap/protocol/IMAPProtocol;Ljava/lang/String;Ljava/lang/String;)V
    //   112: aload_3
    //   113: astore_2
    //   114: aload_2
    //   115: ifnonnull +33 -> 148
    //   118: new 418	com/sun/mail/iap/ConnectionException
    //   121: dup
    //   122: ldc_w 722
    //   125: invokespecial 723	com/sun/mail/iap/ConnectionException:<init>	(Ljava/lang/String;)V
    //   128: athrow
    //   129: aload 4
    //   131: monitorexit
    //   132: aload_2
    //   133: athrow
    //   134: astore_3
    //   135: aload_2
    //   136: ifnull +7 -> 143
    //   139: aload_2
    //   140: invokevirtual 412	com/sun/mail/imap/protocol/IMAPProtocol:logout	()V
    //   143: aconst_null
    //   144: astore_2
    //   145: goto -31 -> 114
    //   148: aload_2
    //   149: aload_0
    //   150: invokevirtual 726	com/sun/mail/imap/protocol/IMAPProtocol:addResponseHandler	(Lcom/sun/mail/iap/ResponseHandler;)V
    //   153: aload_0
    //   154: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   157: invokestatic 395	com/sun/mail/imap/IMAPStore$ConnectionPool:access$10	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Ljava/util/Vector;
    //   160: aload_2
    //   161: invokevirtual 329	java/util/Vector:addElement	(Ljava/lang/Object;)V
    //   164: aload_0
    //   165: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   168: invokestatic 648	com/sun/mail/imap/IMAPStore$ConnectionPool:access$12	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Z
    //   171: istore_1
    //   172: iload_1
    //   173: ifeq +84 -> 257
    //   176: aconst_null
    //   177: astore_3
    //   178: aload_0
    //   179: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   182: invokevirtual 577	java/lang/Object:wait	()V
    //   185: aload_0
    //   186: invokespecial 697	com/sun/mail/imap/IMAPStore:timeoutConnections	()V
    //   189: aload 4
    //   191: monitorexit
    //   192: aload_3
    //   193: astore_2
    //   194: goto -192 -> 2
    //   197: aload_0
    //   198: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   201: invokestatic 207	com/sun/mail/imap/IMAPStore$ConnectionPool:access$3	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Z
    //   204: ifeq +36 -> 240
    //   207: aload_0
    //   208: getfield 132	com/sun/mail/imap/IMAPStore:out	Ljava/io/PrintStream;
    //   211: new 135	java/lang/StringBuilder
    //   214: dup
    //   215: ldc_w 728
    //   218: invokespecial 140	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   221: aload_0
    //   222: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   225: invokestatic 395	com/sun/mail/imap/IMAPStore$ConnectionPool:access$10	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Ljava/util/Vector;
    //   228: invokevirtual 292	java/util/Vector:size	()I
    //   231: invokevirtual 189	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   234: invokevirtual 149	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   237: invokevirtual 176	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   240: aload_0
    //   241: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   244: invokestatic 395	com/sun/mail/imap/IMAPStore$ConnectionPool:access$10	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Ljava/util/Vector;
    //   247: invokevirtual 731	java/util/Vector:firstElement	()Ljava/lang/Object;
    //   250: checkcast 402	com/sun/mail/imap/protocol/IMAPProtocol
    //   253: astore_2
    //   254: goto -90 -> 164
    //   257: aload_0
    //   258: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   261: iconst_1
    //   262: invokestatic 734	com/sun/mail/imap/IMAPStore$ConnectionPool:access$15	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;Z)V
    //   265: aload_2
    //   266: astore_3
    //   267: aload_0
    //   268: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   271: invokestatic 207	com/sun/mail/imap/IMAPStore$ConnectionPool:access$3	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Z
    //   274: ifeq -89 -> 185
    //   277: aload_0
    //   278: getfield 132	com/sun/mail/imap/IMAPStore:out	Ljava/io/PrintStream;
    //   281: ldc_w 736
    //   284: invokevirtual 176	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   287: aload_2
    //   288: astore_3
    //   289: goto -104 -> 185
    //   292: astore_2
    //   293: goto -150 -> 143
    //   296: astore_2
    //   297: goto -168 -> 129
    //   300: astore_2
    //   301: goto -116 -> 185
    //   304: astore_2
    //   305: aload_3
    //   306: astore_2
    //   307: goto -172 -> 135
    //   310: astore_2
    //   311: goto -182 -> 129
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	314	0	this	IMAPStore
    //   171	2	1	bool	boolean
    //   1	287	2	localObject1	Object
    //   292	1	2	localException1	Exception
    //   296	1	2	localObject2	Object
    //   300	1	2	localInterruptedException	InterruptedException
    //   304	1	2	localException2	Exception
    //   306	1	2	localObject3	Object
    //   310	1	2	localObject4	Object
    //   98	15	3	localIMAPProtocol	IMAPProtocol
    //   134	1	3	localException3	Exception
    //   177	129	3	localObject5	Object
    //   12	178	4	localConnectionPool	ConnectionPool
    // Exception table:
    //   from	to	target	type
    //   54	99	134	java/lang/Exception
    //   139	143	292	java/lang/Exception
    //   17	54	296	finally
    //   54	99	296	finally
    //   197	240	296	finally
    //   240	254	296	finally
    //   178	185	300	java/lang/InterruptedException
    //   99	112	304	java/lang/Exception
    //   99	112	310	finally
    //   118	129	310	finally
    //   129	132	310	finally
    //   139	143	310	finally
    //   148	164	310	finally
    //   164	172	310	finally
    //   178	185	310	finally
    //   185	192	310	finally
    //   257	265	310	finally
    //   267	287	310	finally
  }
  
  public Folder[] getUserNamespaces(String paramString)
    throws MessagingException
  {
    Namespaces localNamespaces = getNamespaces();
    if ((localNamespaces == null) || (localNamespaces.otherUsers == null)) {
      return super.getUserNamespaces(paramString);
    }
    return namespaceToFolders(localNamespaces.otherUsers, paramString);
  }
  
  public void handleResponse(Response paramResponse)
  {
    if ((paramResponse.isOK()) || (paramResponse.isNO()) || (paramResponse.isBAD()) || (paramResponse.isBYE())) {
      handleResponseCode(paramResponse);
    }
    if (paramResponse.isBYE())
    {
      if (this.debug) {
        this.out.println("DEBUG: IMAPStore connection dead");
      }
      if (this.connected) {
        cleanup(paramResponse.isSynthetic());
      }
    }
  }
  
  void handleResponseCode(Response paramResponse)
  {
    String str2 = paramResponse.getRest();
    int i = 0;
    int j = 0;
    String str1 = str2;
    if (str2.startsWith("["))
    {
      int k = str2.indexOf(']');
      i = j;
      if (k > 0)
      {
        i = j;
        if (str2.substring(0, k + 1).equalsIgnoreCase("[ALERT]")) {
          i = 1;
        }
      }
      str1 = str2.substring(k + 1).trim();
    }
    if (i != 0) {
      notifyStoreListeners(1, str1);
    }
    while ((!paramResponse.isUnTagged()) || (str1.length() <= 0)) {
      return;
    }
    notifyStoreListeners(2, str1);
  }
  
  /* Error */
  public boolean hasCapability(String paramString)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aconst_null
    //   3: astore 4
    //   5: aconst_null
    //   6: astore_3
    //   7: aload_0
    //   8: invokevirtual 426	com/sun/mail/imap/IMAPStore:getStoreProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   11: astore 5
    //   13: aload 5
    //   15: astore_3
    //   16: aload 5
    //   18: astore 4
    //   20: aload 5
    //   22: aload_1
    //   23: invokevirtual 455	com/sun/mail/imap/protocol/IMAPProtocol:hasCapability	(Ljava/lang/String;)Z
    //   26: istore_2
    //   27: aload_0
    //   28: aload 5
    //   30: invokevirtual 433	com/sun/mail/imap/IMAPStore:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   33: aload_0
    //   34: monitorexit
    //   35: iload_2
    //   36: ireturn
    //   37: astore_1
    //   38: aload_3
    //   39: ifnonnull +10 -> 49
    //   42: aload_3
    //   43: astore 4
    //   45: aload_0
    //   46: invokespecial 435	com/sun/mail/imap/IMAPStore:cleanup	()V
    //   49: aload_3
    //   50: astore 4
    //   52: new 353	javax/mail/MessagingException
    //   55: dup
    //   56: aload_1
    //   57: invokevirtual 444	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   60: aload_1
    //   61: invokespecial 447	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   64: athrow
    //   65: astore_1
    //   66: aload_0
    //   67: aload 4
    //   69: invokevirtual 433	com/sun/mail/imap/IMAPStore:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   72: aload_1
    //   73: athrow
    //   74: astore_1
    //   75: aload_0
    //   76: monitorexit
    //   77: aload_1
    //   78: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	79	0	this	IMAPStore
    //   0	79	1	paramString	String
    //   26	10	2	bool	boolean
    //   6	44	3	localObject1	Object
    //   3	65	4	localObject2	Object
    //   11	18	5	localIMAPProtocol	IMAPProtocol
    // Exception table:
    //   from	to	target	type
    //   7	13	37	com/sun/mail/iap/ProtocolException
    //   20	27	37	com/sun/mail/iap/ProtocolException
    //   7	13	65	finally
    //   20	27	65	finally
    //   45	49	65	finally
    //   52	65	65	finally
    //   27	33	74	finally
    //   66	74	74	finally
  }
  
  boolean hasSeparateStoreConnection()
  {
    return this.pool.separateStoreConnection;
  }
  
  /* Error */
  public void idle()
    throws MessagingException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 9
    //   3: aconst_null
    //   4: astore 10
    //   6: aconst_null
    //   7: astore 11
    //   9: aconst_null
    //   10: astore 12
    //   12: aconst_null
    //   13: astore 6
    //   15: getstatic 56	com/sun/mail/imap/IMAPStore:$assertionsDisabled	Z
    //   18: ifne +21 -> 39
    //   21: aload_0
    //   22: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   25: invokestatic 336	java/lang/Thread:holdsLock	(Ljava/lang/Object;)Z
    //   28: ifeq +11 -> 39
    //   31: new 338	java/lang/AssertionError
    //   34: dup
    //   35: invokespecial 339	java/lang/AssertionError:<init>	()V
    //   38: athrow
    //   39: aload_0
    //   40: monitorenter
    //   41: aload_0
    //   42: invokespecial 420	com/sun/mail/imap/IMAPStore:checkConnected	()V
    //   45: aload_0
    //   46: monitorexit
    //   47: aload 9
    //   49: astore 7
    //   51: aload 10
    //   53: astore 4
    //   55: aload 11
    //   57: astore 8
    //   59: aload 12
    //   61: astore 5
    //   63: aload_0
    //   64: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   67: astore 13
    //   69: aload 9
    //   71: astore 7
    //   73: aload 10
    //   75: astore 4
    //   77: aload 11
    //   79: astore 8
    //   81: aload 12
    //   83: astore 5
    //   85: aload 13
    //   87: monitorenter
    //   88: aload 6
    //   90: astore 5
    //   92: aload_0
    //   93: invokevirtual 426	com/sun/mail/imap/IMAPStore:getStoreProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   96: astore 6
    //   98: aload 6
    //   100: astore 5
    //   102: aload_0
    //   103: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   106: invokestatic 562	com/sun/mail/imap/IMAPStore$ConnectionPool:access$19	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)I
    //   109: ifne +232 -> 341
    //   112: aload 6
    //   114: astore 5
    //   116: aload 6
    //   118: invokevirtual 799	com/sun/mail/imap/protocol/IMAPProtocol:idleStart	()V
    //   121: aload 6
    //   123: astore 5
    //   125: aload_0
    //   126: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   129: iconst_1
    //   130: invokestatic 572	com/sun/mail/imap/IMAPStore$ConnectionPool:access$20	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;I)V
    //   133: aload 6
    //   135: astore 5
    //   137: aload_0
    //   138: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   141: aload 6
    //   143: invokestatic 803	com/sun/mail/imap/IMAPStore$ConnectionPool:access$18	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   146: aload 6
    //   148: astore 5
    //   150: aload 13
    //   152: monitorexit
    //   153: aload 6
    //   155: astore 7
    //   157: aload 6
    //   159: astore 4
    //   161: aload 6
    //   163: astore 8
    //   165: aload 6
    //   167: astore 5
    //   169: aload 6
    //   171: invokevirtual 807	com/sun/mail/imap/protocol/IMAPProtocol:readIdleResponse	()Lcom/sun/mail/iap/Response;
    //   174: astore 10
    //   176: aload 6
    //   178: astore 7
    //   180: aload 6
    //   182: astore 4
    //   184: aload 6
    //   186: astore 8
    //   188: aload 6
    //   190: astore 5
    //   192: aload_0
    //   193: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   196: astore 9
    //   198: aload 6
    //   200: astore 7
    //   202: aload 6
    //   204: astore 4
    //   206: aload 6
    //   208: astore 8
    //   210: aload 6
    //   212: astore 5
    //   214: aload 9
    //   216: monitorenter
    //   217: aload 10
    //   219: ifnull +13 -> 232
    //   222: aload 6
    //   224: aload 10
    //   226: invokevirtual 811	com/sun/mail/imap/protocol/IMAPProtocol:processIdleResponse	(Lcom/sun/mail/iap/Response;)Z
    //   229: ifne +253 -> 482
    //   232: aload_0
    //   233: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   236: iconst_0
    //   237: invokestatic 572	com/sun/mail/imap/IMAPStore$ConnectionPool:access$20	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;I)V
    //   240: aload_0
    //   241: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   244: invokevirtual 814	java/lang/Object:notifyAll	()V
    //   247: aload 9
    //   249: monitorexit
    //   250: aload 6
    //   252: astore 7
    //   254: aload 6
    //   256: astore 4
    //   258: aload 6
    //   260: astore 8
    //   262: aload 6
    //   264: astore 5
    //   266: aload_0
    //   267: invokevirtual 816	com/sun/mail/imap/IMAPStore:getMinIdleTime	()I
    //   270: istore_1
    //   271: iload_1
    //   272: ifle +26 -> 298
    //   275: iload_1
    //   276: i2l
    //   277: lstore_2
    //   278: aload 6
    //   280: astore 7
    //   282: aload 6
    //   284: astore 4
    //   286: aload 6
    //   288: astore 8
    //   290: aload 6
    //   292: astore 5
    //   294: lload_2
    //   295: invokestatic 820	java/lang/Thread:sleep	(J)V
    //   298: aload_0
    //   299: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   302: astore 4
    //   304: aload 4
    //   306: monitorenter
    //   307: aload_0
    //   308: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   311: aconst_null
    //   312: invokestatic 803	com/sun/mail/imap/IMAPStore$ConnectionPool:access$18	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   315: aload 4
    //   317: monitorexit
    //   318: aload_0
    //   319: aload 6
    //   321: invokevirtual 433	com/sun/mail/imap/IMAPStore:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   324: aload 6
    //   326: ifnonnull +7 -> 333
    //   329: aload_0
    //   330: invokespecial 435	com/sun/mail/imap/IMAPStore:cleanup	()V
    //   333: return
    //   334: astore 4
    //   336: aload_0
    //   337: monitorexit
    //   338: aload 4
    //   340: athrow
    //   341: aload 6
    //   343: astore 5
    //   345: aload_0
    //   346: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   349: invokevirtual 577	java/lang/Object:wait	()V
    //   352: aload 6
    //   354: astore 5
    //   356: aload 13
    //   358: monitorexit
    //   359: aload_0
    //   360: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   363: astore 4
    //   365: aload 4
    //   367: monitorenter
    //   368: aload_0
    //   369: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   372: aconst_null
    //   373: invokestatic 803	com/sun/mail/imap/IMAPStore$ConnectionPool:access$18	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   376: aload 4
    //   378: monitorexit
    //   379: aload_0
    //   380: aload 6
    //   382: invokevirtual 433	com/sun/mail/imap/IMAPStore:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   385: aload 6
    //   387: ifnonnull -54 -> 333
    //   390: aload_0
    //   391: invokespecial 435	com/sun/mail/imap/IMAPStore:cleanup	()V
    //   394: return
    //   395: astore 5
    //   397: aload 4
    //   399: monitorexit
    //   400: aload 5
    //   402: athrow
    //   403: astore 6
    //   405: aload 13
    //   407: monitorexit
    //   408: aload 5
    //   410: astore 7
    //   412: aload 5
    //   414: astore 4
    //   416: aload 5
    //   418: astore 8
    //   420: aload 6
    //   422: athrow
    //   423: astore 5
    //   425: aload 7
    //   427: astore 4
    //   429: new 353	javax/mail/MessagingException
    //   432: dup
    //   433: ldc_w 822
    //   436: aload 5
    //   438: invokespecial 447	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   441: athrow
    //   442: astore 6
    //   444: aload_0
    //   445: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   448: astore 5
    //   450: aload 5
    //   452: monitorenter
    //   453: aload_0
    //   454: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   457: aconst_null
    //   458: invokestatic 803	com/sun/mail/imap/IMAPStore$ConnectionPool:access$18	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   461: aload 5
    //   463: monitorexit
    //   464: aload_0
    //   465: aload 4
    //   467: invokevirtual 433	com/sun/mail/imap/IMAPStore:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   470: aload 4
    //   472: ifnonnull +7 -> 479
    //   475: aload_0
    //   476: invokespecial 435	com/sun/mail/imap/IMAPStore:cleanup	()V
    //   479: aload 6
    //   481: athrow
    //   482: aload 9
    //   484: monitorexit
    //   485: aload 6
    //   487: astore 7
    //   489: aload 6
    //   491: astore 4
    //   493: aload 6
    //   495: astore 8
    //   497: aload 6
    //   499: astore 5
    //   501: aload_0
    //   502: getfield 96	com/sun/mail/imap/IMAPStore:enableImapEvents	Z
    //   505: ifeq -352 -> 153
    //   508: aload 6
    //   510: astore 7
    //   512: aload 6
    //   514: astore 4
    //   516: aload 6
    //   518: astore 8
    //   520: aload 6
    //   522: astore 5
    //   524: aload 10
    //   526: invokevirtual 794	com/sun/mail/iap/Response:isUnTagged	()Z
    //   529: ifeq -376 -> 153
    //   532: aload 6
    //   534: astore 7
    //   536: aload 6
    //   538: astore 4
    //   540: aload 6
    //   542: astore 8
    //   544: aload 6
    //   546: astore 5
    //   548: aload_0
    //   549: sipush 1000
    //   552: aload 10
    //   554: invokevirtual 823	com/sun/mail/iap/Response:toString	()Ljava/lang/String;
    //   557: invokevirtual 791	com/sun/mail/imap/IMAPStore:notifyStoreListeners	(ILjava/lang/String;)V
    //   560: goto -407 -> 153
    //   563: astore 5
    //   565: aload 8
    //   567: astore 4
    //   569: new 437	javax/mail/StoreClosedException
    //   572: dup
    //   573: aload_0
    //   574: aload 5
    //   576: invokevirtual 440	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   579: invokespecial 443	javax/mail/StoreClosedException:<init>	(Ljavax/mail/Store;Ljava/lang/String;)V
    //   582: athrow
    //   583: astore 10
    //   585: aload 9
    //   587: monitorexit
    //   588: aload 6
    //   590: astore 7
    //   592: aload 6
    //   594: astore 4
    //   596: aload 6
    //   598: astore 8
    //   600: aload 6
    //   602: astore 5
    //   604: aload 10
    //   606: athrow
    //   607: astore 6
    //   609: aload 5
    //   611: astore 4
    //   613: new 353	javax/mail/MessagingException
    //   616: dup
    //   617: aload 6
    //   619: invokevirtual 444	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   622: aload 6
    //   624: invokespecial 447	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   627: athrow
    //   628: astore 4
    //   630: aload 5
    //   632: monitorexit
    //   633: aload 4
    //   635: athrow
    //   636: astore 5
    //   638: aload 4
    //   640: monitorexit
    //   641: aload 5
    //   643: athrow
    //   644: astore 4
    //   646: goto -348 -> 298
    //   649: astore 4
    //   651: goto -299 -> 352
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	654	0	this	IMAPStore
    //   270	6	1	i	int
    //   277	18	2	l	long
    //   334	5	4	localObject2	Object
    //   628	11	4	localObject4	Object
    //   644	1	4	localInterruptedException1	InterruptedException
    //   649	1	4	localInterruptedException2	InterruptedException
    //   61	294	5	localObject5	Object
    //   395	22	5	localObject6	Object
    //   423	14	5	localBadCommandException	com.sun.mail.iap.BadCommandException
    //   563	12	5	localConnectionException	ConnectionException
    //   602	29	5	localObject8	Object
    //   636	6	5	localObject9	Object
    //   13	373	6	localIMAPProtocol	IMAPProtocol
    //   403	18	6	localObject10	Object
    //   442	159	6	localObject11	Object
    //   607	16	6	localProtocolException	ProtocolException
    //   49	542	7	localObject12	Object
    //   57	542	8	localObject13	Object
    //   1	585	9	localConnectionPool1	ConnectionPool
    //   4	549	10	localResponse	Response
    //   583	22	10	localObject14	Object
    //   7	71	11	localObject15	Object
    //   10	72	12	localObject16	Object
    //   67	339	13	localConnectionPool2	ConnectionPool
    // Exception table:
    //   from	to	target	type
    //   41	47	334	finally
    //   336	338	334	finally
    //   368	379	395	finally
    //   397	400	395	finally
    //   92	98	403	finally
    //   102	112	403	finally
    //   116	121	403	finally
    //   125	133	403	finally
    //   137	146	403	finally
    //   150	153	403	finally
    //   345	352	403	finally
    //   356	359	403	finally
    //   405	408	403	finally
    //   63	69	423	com/sun/mail/iap/BadCommandException
    //   85	88	423	com/sun/mail/iap/BadCommandException
    //   169	176	423	com/sun/mail/iap/BadCommandException
    //   192	198	423	com/sun/mail/iap/BadCommandException
    //   214	217	423	com/sun/mail/iap/BadCommandException
    //   266	271	423	com/sun/mail/iap/BadCommandException
    //   294	298	423	com/sun/mail/iap/BadCommandException
    //   420	423	423	com/sun/mail/iap/BadCommandException
    //   501	508	423	com/sun/mail/iap/BadCommandException
    //   524	532	423	com/sun/mail/iap/BadCommandException
    //   548	560	423	com/sun/mail/iap/BadCommandException
    //   604	607	423	com/sun/mail/iap/BadCommandException
    //   63	69	442	finally
    //   85	88	442	finally
    //   169	176	442	finally
    //   192	198	442	finally
    //   214	217	442	finally
    //   266	271	442	finally
    //   294	298	442	finally
    //   420	423	442	finally
    //   429	442	442	finally
    //   501	508	442	finally
    //   524	532	442	finally
    //   548	560	442	finally
    //   569	583	442	finally
    //   604	607	442	finally
    //   613	628	442	finally
    //   63	69	563	com/sun/mail/iap/ConnectionException
    //   85	88	563	com/sun/mail/iap/ConnectionException
    //   169	176	563	com/sun/mail/iap/ConnectionException
    //   192	198	563	com/sun/mail/iap/ConnectionException
    //   214	217	563	com/sun/mail/iap/ConnectionException
    //   266	271	563	com/sun/mail/iap/ConnectionException
    //   294	298	563	com/sun/mail/iap/ConnectionException
    //   420	423	563	com/sun/mail/iap/ConnectionException
    //   501	508	563	com/sun/mail/iap/ConnectionException
    //   524	532	563	com/sun/mail/iap/ConnectionException
    //   548	560	563	com/sun/mail/iap/ConnectionException
    //   604	607	563	com/sun/mail/iap/ConnectionException
    //   222	232	583	finally
    //   232	250	583	finally
    //   482	485	583	finally
    //   585	588	583	finally
    //   63	69	607	com/sun/mail/iap/ProtocolException
    //   85	88	607	com/sun/mail/iap/ProtocolException
    //   169	176	607	com/sun/mail/iap/ProtocolException
    //   192	198	607	com/sun/mail/iap/ProtocolException
    //   214	217	607	com/sun/mail/iap/ProtocolException
    //   266	271	607	com/sun/mail/iap/ProtocolException
    //   294	298	607	com/sun/mail/iap/ProtocolException
    //   420	423	607	com/sun/mail/iap/ProtocolException
    //   501	508	607	com/sun/mail/iap/ProtocolException
    //   524	532	607	com/sun/mail/iap/ProtocolException
    //   548	560	607	com/sun/mail/iap/ProtocolException
    //   604	607	607	com/sun/mail/iap/ProtocolException
    //   453	464	628	finally
    //   630	633	628	finally
    //   307	318	636	finally
    //   638	641	636	finally
    //   294	298	644	java/lang/InterruptedException
    //   345	352	649	java/lang/InterruptedException
  }
  
  /* Error */
  public boolean isConnected()
  {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: getfield 98	com/sun/mail/imap/IMAPStore:connected	Z
    //   8: ifne +12 -> 20
    //   11: aload_0
    //   12: iconst_0
    //   13: invokespecial 343	javax/mail/Store:setConnected	(Z)V
    //   16: aload_0
    //   17: monitorexit
    //   18: iload_1
    //   19: ireturn
    //   20: aconst_null
    //   21: astore_3
    //   22: aconst_null
    //   23: astore_2
    //   24: aload_0
    //   25: invokevirtual 426	com/sun/mail/imap/IMAPStore:getStoreProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   28: astore 4
    //   30: aload 4
    //   32: astore_2
    //   33: aload 4
    //   35: astore_3
    //   36: aload 4
    //   38: invokevirtual 695	com/sun/mail/imap/protocol/IMAPProtocol:noop	()V
    //   41: aload_0
    //   42: aload 4
    //   44: invokevirtual 433	com/sun/mail/imap/IMAPStore:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   47: aload_0
    //   48: invokespecial 587	javax/mail/Store:isConnected	()Z
    //   51: istore_1
    //   52: goto -36 -> 16
    //   55: astore_3
    //   56: aload_2
    //   57: ifnonnull +9 -> 66
    //   60: aload_2
    //   61: astore_3
    //   62: aload_0
    //   63: invokespecial 435	com/sun/mail/imap/IMAPStore:cleanup	()V
    //   66: aload_0
    //   67: aload_2
    //   68: invokevirtual 433	com/sun/mail/imap/IMAPStore:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   71: goto -24 -> 47
    //   74: astore_2
    //   75: aload_0
    //   76: monitorexit
    //   77: aload_2
    //   78: athrow
    //   79: astore_2
    //   80: aload_0
    //   81: aload_3
    //   82: invokevirtual 433	com/sun/mail/imap/IMAPStore:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   85: aload_2
    //   86: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	87	0	this	IMAPStore
    //   1	51	1	bool	boolean
    //   23	45	2	localObject1	Object
    //   74	4	2	localObject2	Object
    //   79	7	2	localObject3	Object
    //   21	15	3	localObject4	Object
    //   55	1	3	localProtocolException	ProtocolException
    //   61	21	3	localObject5	Object
    //   28	15	4	localIMAPProtocol	IMAPProtocol
    // Exception table:
    //   from	to	target	type
    //   24	30	55	com/sun/mail/iap/ProtocolException
    //   36	41	55	com/sun/mail/iap/ProtocolException
    //   4	16	74	finally
    //   41	47	74	finally
    //   47	52	74	finally
    //   66	71	74	finally
    //   80	87	74	finally
    //   24	30	79	finally
    //   36	41	79	finally
    //   62	66	79	finally
  }
  
  boolean isConnectionPoolFull()
  {
    for (;;)
    {
      synchronized (this.pool)
      {
        if (this.pool.debug) {
          this.out.println("DEBUG: current size: " + this.pool.authenticatedConnections.size() + "   pool size: " + this.pool.poolSize);
        }
        if (this.pool.authenticatedConnections.size() >= this.pool.poolSize)
        {
          bool = true;
          return bool;
        }
      }
      boolean bool = false;
    }
  }
  
  /* Error */
  protected boolean protocolConnect(String arg1, int paramInt, String paramString2, String paramString3)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnull +12 -> 15
    //   6: aload 4
    //   8: ifnull +7 -> 15
    //   11: aload_3
    //   12: ifnonnull +84 -> 96
    //   15: aload_0
    //   16: getfield 126	com/sun/mail/imap/IMAPStore:debug	Z
    //   19: ifeq +62 -> 81
    //   22: aload_0
    //   23: getfield 132	com/sun/mail/imap/IMAPStore:out	Ljava/io/PrintStream;
    //   26: astore 6
    //   28: new 135	java/lang/StringBuilder
    //   31: dup
    //   32: ldc_w 836
    //   35: invokespecial 140	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   38: aload_1
    //   39: invokevirtual 144	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   42: ldc_w 838
    //   45: invokevirtual 144	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   48: aload_3
    //   49: invokevirtual 144	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   52: ldc_w 840
    //   55: invokevirtual 144	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   58: astore_3
    //   59: aload 4
    //   61: ifnull +28 -> 89
    //   64: ldc_w 842
    //   67: astore_1
    //   68: aload 6
    //   70: aload_3
    //   71: aload_1
    //   72: invokevirtual 144	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   75: invokevirtual 149	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   78: invokevirtual 176	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   81: iconst_0
    //   82: istore 5
    //   84: aload_0
    //   85: monitorexit
    //   86: iload 5
    //   88: ireturn
    //   89: ldc_w 844
    //   92: astore_1
    //   93: goto -25 -> 68
    //   96: iload_2
    //   97: iconst_m1
    //   98: if_icmpeq +206 -> 304
    //   101: aload_0
    //   102: iload_2
    //   103: putfield 76	com/sun/mail/imap/IMAPStore:port	I
    //   106: aload_0
    //   107: getfield 76	com/sun/mail/imap/IMAPStore:port	I
    //   110: iconst_m1
    //   111: if_icmpne +11 -> 122
    //   114: aload_0
    //   115: aload_0
    //   116: getfield 72	com/sun/mail/imap/IMAPStore:defaultPort	I
    //   119: putfield 76	com/sun/mail/imap/IMAPStore:port	I
    //   122: aload_0
    //   123: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   126: astore 6
    //   128: aload 6
    //   130: monitorenter
    //   131: aload_0
    //   132: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   135: invokestatic 395	com/sun/mail/imap/IMAPStore$ConnectionPool:access$10	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Ljava/util/Vector;
    //   138: invokevirtual 590	java/util/Vector:isEmpty	()Z
    //   141: istore 5
    //   143: aload 6
    //   145: monitorexit
    //   146: iload 5
    //   148: ifeq +295 -> 443
    //   151: new 402	com/sun/mail/imap/protocol/IMAPProtocol
    //   154: dup
    //   155: aload_0
    //   156: getfield 70	com/sun/mail/imap/IMAPStore:name	Ljava/lang/String;
    //   159: aload_1
    //   160: aload_0
    //   161: getfield 76	com/sun/mail/imap/IMAPStore:port	I
    //   164: aload_0
    //   165: getfield 582	com/sun/mail/imap/IMAPStore:session	Ljavax/mail/Session;
    //   168: invokevirtual 123	javax/mail/Session:getDebug	()Z
    //   171: aload_0
    //   172: getfield 582	com/sun/mail/imap/IMAPStore:session	Ljavax/mail/Session;
    //   175: invokevirtual 130	javax/mail/Session:getDebugOut	()Ljava/io/PrintStream;
    //   178: aload_0
    //   179: getfield 582	com/sun/mail/imap/IMAPStore:session	Ljavax/mail/Session;
    //   182: invokevirtual 678	javax/mail/Session:getProperties	()Ljava/util/Properties;
    //   185: aload_0
    //   186: getfield 74	com/sun/mail/imap/IMAPStore:isSSL	Z
    //   189: invokespecial 681	com/sun/mail/imap/protocol/IMAPProtocol:<init>	(Ljava/lang/String;Ljava/lang/String;IZLjava/io/PrintStream;Ljava/util/Properties;Z)V
    //   192: astore 6
    //   194: aload_0
    //   195: getfield 126	com/sun/mail/imap/IMAPStore:debug	Z
    //   198: ifeq +43 -> 241
    //   201: aload_0
    //   202: getfield 132	com/sun/mail/imap/IMAPStore:out	Ljava/io/PrintStream;
    //   205: new 135	java/lang/StringBuilder
    //   208: dup
    //   209: ldc_w 846
    //   212: invokespecial 140	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   215: aload_1
    //   216: invokevirtual 144	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   219: ldc_w 838
    //   222: invokevirtual 144	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   225: aload_3
    //   226: invokevirtual 144	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   229: ldc_w 848
    //   232: invokevirtual 144	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   235: invokevirtual 149	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   238: invokevirtual 176	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   241: aload_0
    //   242: aload 6
    //   244: aload_3
    //   245: aload 4
    //   247: invokespecial 683	com/sun/mail/imap/IMAPStore:login	(Lcom/sun/mail/imap/protocol/IMAPProtocol;Ljava/lang/String;Ljava/lang/String;)V
    //   250: aload 6
    //   252: aload_0
    //   253: invokevirtual 726	com/sun/mail/imap/protocol/IMAPProtocol:addResponseHandler	(Lcom/sun/mail/iap/ResponseHandler;)V
    //   256: aload_0
    //   257: aload_1
    //   258: putfield 652	com/sun/mail/imap/IMAPStore:host	Ljava/lang/String;
    //   261: aload_0
    //   262: aload_3
    //   263: putfield 660	com/sun/mail/imap/IMAPStore:user	Ljava/lang/String;
    //   266: aload_0
    //   267: aload 4
    //   269: putfield 674	com/sun/mail/imap/IMAPStore:password	Ljava/lang/String;
    //   272: aload_0
    //   273: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   276: astore_1
    //   277: aload_1
    //   278: monitorenter
    //   279: aload_0
    //   280: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   283: invokestatic 395	com/sun/mail/imap/IMAPStore$ConnectionPool:access$10	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Ljava/util/Vector;
    //   286: aload 6
    //   288: invokevirtual 329	java/util/Vector:addElement	(Ljava/lang/Object;)V
    //   291: aload_1
    //   292: monitorexit
    //   293: aload_0
    //   294: iconst_1
    //   295: putfield 98	com/sun/mail/imap/IMAPStore:connected	Z
    //   298: iconst_1
    //   299: istore 5
    //   301: goto -217 -> 84
    //   304: aload_0
    //   305: getfield 582	com/sun/mail/imap/IMAPStore:session	Ljavax/mail/Session;
    //   308: new 135	java/lang/StringBuilder
    //   311: dup
    //   312: ldc -119
    //   314: invokespecial 140	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   317: aload_0
    //   318: getfield 70	com/sun/mail/imap/IMAPStore:name	Ljava/lang/String;
    //   321: invokevirtual 144	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   324: ldc_w 850
    //   327: invokevirtual 144	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   330: invokevirtual 149	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   333: invokevirtual 153	javax/mail/Session:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   336: astore 6
    //   338: aload 6
    //   340: ifnull -234 -> 106
    //   343: aload_0
    //   344: aload 6
    //   346: invokestatic 184	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   349: putfield 76	com/sun/mail/imap/IMAPStore:port	I
    //   352: goto -246 -> 106
    //   355: astore_1
    //   356: aload_0
    //   357: monitorexit
    //   358: aload_1
    //   359: athrow
    //   360: astore_1
    //   361: aload 6
    //   363: monitorexit
    //   364: aload_1
    //   365: athrow
    //   366: astore_3
    //   367: aconst_null
    //   368: astore_1
    //   369: aload_1
    //   370: ifnull +7 -> 377
    //   373: aload_1
    //   374: invokevirtual 409	com/sun/mail/imap/protocol/IMAPProtocol:disconnect	()V
    //   377: new 852	javax/mail/AuthenticationFailedException
    //   380: dup
    //   381: aload_3
    //   382: invokevirtual 855	com/sun/mail/iap/CommandFailedException:getResponse	()Lcom/sun/mail/iap/Response;
    //   385: invokevirtual 770	com/sun/mail/iap/Response:getRest	()Ljava/lang/String;
    //   388: invokespecial 856	javax/mail/AuthenticationFailedException:<init>	(Ljava/lang/String;)V
    //   391: athrow
    //   392: astore_1
    //   393: goto -37 -> 356
    //   396: astore_3
    //   397: aload_1
    //   398: monitorexit
    //   399: aload_3
    //   400: athrow
    //   401: astore_3
    //   402: aload 6
    //   404: astore_1
    //   405: goto -36 -> 369
    //   408: astore_1
    //   409: new 353	javax/mail/MessagingException
    //   412: dup
    //   413: aload_1
    //   414: invokevirtual 444	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   417: aload_1
    //   418: invokespecial 447	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   421: athrow
    //   422: new 353	javax/mail/MessagingException
    //   425: dup
    //   426: aload_1
    //   427: invokevirtual 857	java/io/IOException:getMessage	()Ljava/lang/String;
    //   430: aload_1
    //   431: invokespecial 447	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   434: athrow
    //   435: astore_1
    //   436: goto -14 -> 422
    //   439: astore_1
    //   440: goto -31 -> 409
    //   443: goto -150 -> 293
    //   446: astore_1
    //   447: goto -25 -> 422
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	450	0	this	IMAPStore
    //   0	450	2	paramInt	int
    //   0	450	3	paramString2	String
    //   0	450	4	paramString3	String
    //   82	218	5	bool	boolean
    //   26	377	6	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   15	59	355	finally
    //   68	81	355	finally
    //   101	106	355	finally
    //   106	122	355	finally
    //   122	131	355	finally
    //   151	194	355	finally
    //   304	338	355	finally
    //   343	352	355	finally
    //   364	366	355	finally
    //   131	146	360	finally
    //   361	364	360	finally
    //   122	131	366	com/sun/mail/iap/CommandFailedException
    //   151	194	366	com/sun/mail/iap/CommandFailedException
    //   364	366	366	com/sun/mail/iap/CommandFailedException
    //   194	241	392	finally
    //   241	279	392	finally
    //   293	298	392	finally
    //   373	377	392	finally
    //   377	392	392	finally
    //   399	401	392	finally
    //   409	422	392	finally
    //   422	435	392	finally
    //   279	293	396	finally
    //   397	399	396	finally
    //   194	241	401	com/sun/mail/iap/CommandFailedException
    //   241	279	401	com/sun/mail/iap/CommandFailedException
    //   399	401	401	com/sun/mail/iap/CommandFailedException
    //   122	131	408	com/sun/mail/iap/ProtocolException
    //   151	194	408	com/sun/mail/iap/ProtocolException
    //   364	366	408	com/sun/mail/iap/ProtocolException
    //   194	241	435	java/io/IOException
    //   241	279	435	java/io/IOException
    //   399	401	435	java/io/IOException
    //   194	241	439	com/sun/mail/iap/ProtocolException
    //   241	279	439	com/sun/mail/iap/ProtocolException
    //   399	401	439	com/sun/mail/iap/ProtocolException
    //   122	131	446	java/io/IOException
    //   151	194	446	java/io/IOException
    //   364	366	446	java/io/IOException
  }
  
  /* Error */
  void releaseProtocol(IMAPFolder paramIMAPFolder, IMAPProtocol paramIMAPProtocol)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   4: astore_3
    //   5: aload_3
    //   6: monitorenter
    //   7: aload_2
    //   8: ifnull +66 -> 74
    //   11: aload_0
    //   12: invokevirtual 861	com/sun/mail/imap/IMAPStore:isConnectionPoolFull	()Z
    //   15: ifne +88 -> 103
    //   18: aload_2
    //   19: aload_0
    //   20: invokevirtual 726	com/sun/mail/imap/protocol/IMAPProtocol:addResponseHandler	(Lcom/sun/mail/iap/ResponseHandler;)V
    //   23: aload_0
    //   24: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   27: invokestatic 395	com/sun/mail/imap/IMAPStore$ConnectionPool:access$10	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Ljava/util/Vector;
    //   30: aload_2
    //   31: invokevirtual 329	java/util/Vector:addElement	(Ljava/lang/Object;)V
    //   34: aload_0
    //   35: getfield 126	com/sun/mail/imap/IMAPStore:debug	Z
    //   38: ifeq +36 -> 74
    //   41: aload_0
    //   42: getfield 132	com/sun/mail/imap/IMAPStore:out	Ljava/io/PrintStream;
    //   45: new 135	java/lang/StringBuilder
    //   48: dup
    //   49: ldc_w 863
    //   52: invokespecial 140	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   55: aload_0
    //   56: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   59: invokestatic 395	com/sun/mail/imap/IMAPStore$ConnectionPool:access$10	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Ljava/util/Vector;
    //   62: invokevirtual 292	java/util/Vector:size	()I
    //   65: invokevirtual 189	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   68: invokevirtual 149	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   71: invokevirtual 176	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   74: aload_0
    //   75: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   78: invokestatic 362	com/sun/mail/imap/IMAPStore$ConnectionPool:access$13	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Ljava/util/Vector;
    //   81: ifnull +15 -> 96
    //   84: aload_0
    //   85: getfield 102	com/sun/mail/imap/IMAPStore:pool	Lcom/sun/mail/imap/IMAPStore$ConnectionPool;
    //   88: invokestatic 362	com/sun/mail/imap/IMAPStore$ConnectionPool:access$13	(Lcom/sun/mail/imap/IMAPStore$ConnectionPool;)Ljava/util/Vector;
    //   91: aload_1
    //   92: invokevirtual 595	java/util/Vector:removeElement	(Ljava/lang/Object;)Z
    //   95: pop
    //   96: aload_0
    //   97: invokespecial 697	com/sun/mail/imap/IMAPStore:timeoutConnections	()V
    //   100: aload_3
    //   101: monitorexit
    //   102: return
    //   103: aload_0
    //   104: getfield 126	com/sun/mail/imap/IMAPStore:debug	Z
    //   107: ifeq +13 -> 120
    //   110: aload_0
    //   111: getfield 132	com/sun/mail/imap/IMAPStore:out	Ljava/io/PrintStream;
    //   114: ldc_w 865
    //   117: invokevirtual 176	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   120: aload_2
    //   121: invokevirtual 412	com/sun/mail/imap/protocol/IMAPProtocol:logout	()V
    //   124: goto -50 -> 74
    //   127: astore_2
    //   128: goto -54 -> 74
    //   131: astore_1
    //   132: aload_3
    //   133: monitorexit
    //   134: aload_1
    //   135: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	136	0	this	IMAPStore
    //   0	136	1	paramIMAPFolder	IMAPFolder
    //   0	136	2	paramIMAPProtocol	IMAPProtocol
    //   4	129	3	localConnectionPool	ConnectionPool
    // Exception table:
    //   from	to	target	type
    //   120	124	127	com/sun/mail/iap/ProtocolException
    //   11	74	131	finally
    //   74	96	131	finally
    //   96	102	131	finally
    //   103	120	131	finally
    //   120	124	131	finally
    //   132	134	131	finally
  }
  
  void releaseStoreProtocol(IMAPProtocol arg1)
  {
    if (??? == null) {
      return;
    }
    synchronized (this.pool)
    {
      this.pool.storeConnectionInUse = false;
      this.pool.notifyAll();
      if (this.pool.debug) {
        this.out.println("DEBUG: releaseStoreProtocol()");
      }
      timeoutConnections();
      return;
    }
  }
  
  public void setPassword(String paramString)
  {
    try
    {
      this.password = paramString;
      return;
    }
    finally
    {
      paramString = finally;
      throw paramString;
    }
  }
  
  /* Error */
  public void setQuota(javax.mail.Quota paramQuota)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 420	com/sun/mail/imap/IMAPStore:checkConnected	()V
    //   6: aconst_null
    //   7: astore_2
    //   8: aconst_null
    //   9: astore 5
    //   11: aconst_null
    //   12: astore 6
    //   14: aconst_null
    //   15: astore 4
    //   17: aload_0
    //   18: invokevirtual 426	com/sun/mail/imap/IMAPStore:getStoreProtocol	()Lcom/sun/mail/imap/protocol/IMAPProtocol;
    //   21: astore_3
    //   22: aload_3
    //   23: astore 4
    //   25: aload_3
    //   26: astore_2
    //   27: aload_3
    //   28: astore 5
    //   30: aload_3
    //   31: astore 6
    //   33: aload_3
    //   34: aload_1
    //   35: invokevirtual 872	com/sun/mail/imap/protocol/IMAPProtocol:setQuota	(Ljavax/mail/Quota;)V
    //   38: aload_0
    //   39: aload_3
    //   40: invokevirtual 433	com/sun/mail/imap/IMAPStore:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   43: aload_3
    //   44: ifnonnull +7 -> 51
    //   47: aload_0
    //   48: invokespecial 435	com/sun/mail/imap/IMAPStore:cleanup	()V
    //   51: aload_0
    //   52: monitorexit
    //   53: return
    //   54: astore_1
    //   55: aload 4
    //   57: astore_2
    //   58: new 353	javax/mail/MessagingException
    //   61: dup
    //   62: ldc_w 707
    //   65: aload_1
    //   66: invokespecial 447	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   69: athrow
    //   70: astore_1
    //   71: aload_0
    //   72: aload_2
    //   73: invokevirtual 433	com/sun/mail/imap/IMAPStore:releaseStoreProtocol	(Lcom/sun/mail/imap/protocol/IMAPProtocol;)V
    //   76: aload_2
    //   77: ifnonnull +7 -> 84
    //   80: aload_0
    //   81: invokespecial 435	com/sun/mail/imap/IMAPStore:cleanup	()V
    //   84: aload_1
    //   85: athrow
    //   86: astore_1
    //   87: aload_0
    //   88: monitorexit
    //   89: aload_1
    //   90: athrow
    //   91: astore_1
    //   92: aload 5
    //   94: astore_2
    //   95: new 437	javax/mail/StoreClosedException
    //   98: dup
    //   99: aload_0
    //   100: aload_1
    //   101: invokevirtual 440	com/sun/mail/iap/ConnectionException:getMessage	()Ljava/lang/String;
    //   104: invokespecial 443	javax/mail/StoreClosedException:<init>	(Ljavax/mail/Store;Ljava/lang/String;)V
    //   107: athrow
    //   108: astore_1
    //   109: aload 6
    //   111: astore_2
    //   112: new 353	javax/mail/MessagingException
    //   115: dup
    //   116: aload_1
    //   117: invokevirtual 444	com/sun/mail/iap/ProtocolException:getMessage	()Ljava/lang/String;
    //   120: aload_1
    //   121: invokespecial 447	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   124: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	125	0	this	IMAPStore
    //   0	125	1	paramQuota	javax.mail.Quota
    //   7	105	2	localObject1	Object
    //   21	23	3	localIMAPProtocol	IMAPProtocol
    //   15	41	4	localObject2	Object
    //   9	84	5	localObject3	Object
    //   12	98	6	localObject4	Object
    // Exception table:
    //   from	to	target	type
    //   17	22	54	com/sun/mail/iap/BadCommandException
    //   33	38	54	com/sun/mail/iap/BadCommandException
    //   17	22	70	finally
    //   33	38	70	finally
    //   58	70	70	finally
    //   95	108	70	finally
    //   112	125	70	finally
    //   2	6	86	finally
    //   38	43	86	finally
    //   47	51	86	finally
    //   71	76	86	finally
    //   80	84	86	finally
    //   84	86	86	finally
    //   17	22	91	com/sun/mail/iap/ConnectionException
    //   33	38	91	com/sun/mail/iap/ConnectionException
    //   17	22	108	com/sun/mail/iap/ProtocolException
    //   33	38	108	com/sun/mail/iap/ProtocolException
  }
  
  public void setUsername(String paramString)
  {
    try
    {
      this.user = paramString;
      return;
    }
    finally
    {
      paramString = finally;
      throw paramString;
    }
  }
  
  static class ConnectionPool
  {
    private static final int ABORTING = 2;
    private static final int IDLE = 1;
    private static final int RUNNING = 0;
    private Vector authenticatedConnections = new Vector();
    private long clientTimeoutInterval = 45000L;
    private boolean debug = false;
    private Vector folders;
    private IMAPProtocol idleProtocol;
    private int idleState = 0;
    private long lastTimePruned;
    private int poolSize = 1;
    private long pruningInterval = 60000L;
    private boolean separateStoreConnection = false;
    private long serverTimeoutInterval = 1800000L;
    private boolean storeConnectionInUse = false;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/IMAPStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */