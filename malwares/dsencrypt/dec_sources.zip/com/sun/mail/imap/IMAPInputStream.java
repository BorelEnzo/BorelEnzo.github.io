package com.sun.mail.imap;

import com.sun.mail.iap.ByteArray;
import com.sun.mail.iap.ConnectionException;
import com.sun.mail.iap.ProtocolException;
import com.sun.mail.imap.protocol.BODY;
import com.sun.mail.imap.protocol.IMAPProtocol;
import com.sun.mail.util.FolderClosedIOException;
import com.sun.mail.util.MessageRemovedIOException;
import java.io.IOException;
import java.io.InputStream;
import javax.mail.Flags.Flag;
import javax.mail.Folder;
import javax.mail.FolderClosedException;
import javax.mail.MessagingException;

public class IMAPInputStream
  extends InputStream
{
  private static final int slop = 64;
  private int blksize;
  private byte[] buf;
  private int bufcount;
  private int bufpos;
  private int max;
  private IMAPMessage msg;
  private boolean peek;
  private int pos;
  private ByteArray readbuf;
  private String section;
  
  public IMAPInputStream(IMAPMessage paramIMAPMessage, String paramString, int paramInt, boolean paramBoolean)
  {
    this.msg = paramIMAPMessage;
    this.section = paramString;
    this.max = paramInt;
    this.peek = paramBoolean;
    this.pos = 0;
    this.blksize = paramIMAPMessage.getFetchBlockSize();
  }
  
  private void checkSeen()
  {
    if (this.peek) {}
    for (;;)
    {
      return;
      try
      {
        Folder localFolder = this.msg.getFolder();
        if ((localFolder != null) && (localFolder.getMode() != 1) && (!this.msg.isSet(Flags.Flag.SEEN)))
        {
          this.msg.setFlag(Flags.Flag.SEEN, true);
          return;
        }
      }
      catch (MessagingException localMessagingException) {}
    }
  }
  
  private void fill()
    throws IOException
  {
    if ((this.max != -1) && (this.pos >= this.max))
    {
      if (this.pos == 0) {
        checkSeen();
      }
      this.readbuf = null;
      return;
    }
    if (this.readbuf == null) {
      this.readbuf = new ByteArray(this.blksize + 64);
    }
    try
    {
      synchronized (this.msg.getMessageCacheLock())
      {
        try
        {
          IMAPProtocol localIMAPProtocol = this.msg.getProtocol();
          if (this.msg.isExpunged()) {
            throw new MessageRemovedIOException("No content for expunged message");
          }
        }
        catch (ProtocolException localProtocolException)
        {
          forceCheckExpunged();
          throw new IOException(localProtocolException.getMessage());
        }
      }
      int k = this.msg.getSequenceNumber();
      int j = this.blksize;
      i = j;
      if (this.max != -1)
      {
        i = j;
        if (this.pos + this.blksize > this.max) {
          i = this.max - this.pos;
        }
      }
      if (this.peek) {}
      for (Object localObject2 = ((IMAPProtocol)localObject1).peekBody(k, this.section, this.pos, i, this.readbuf);; localObject2 = ((IMAPProtocol)localObject2).fetchBody(k, this.section, this.pos, i, this.readbuf))
      {
        if (localObject2 != null)
        {
          localObject2 = ((BODY)localObject2).getByteArray();
          if (localObject2 != null) {
            break;
          }
        }
        forceCheckExpunged();
        throw new IOException("No content");
      }
    }
    catch (FolderClosedException localFolderClosedException)
    {
      throw new FolderClosedIOException(localFolderClosedException.getFolder(), localFolderClosedException.getMessage());
    }
    if (this.pos == 0) {
      checkSeen();
    }
    this.buf = localFolderClosedException.getBytes();
    this.bufpos = localFolderClosedException.getStart();
    int i = localFolderClosedException.getCount();
    this.bufcount = (this.bufpos + i);
    this.pos += i;
  }
  
  private void forceCheckExpunged()
    throws MessageRemovedIOException, FolderClosedIOException
  {
    try
    {
      synchronized (this.msg.getMessageCacheLock())
      {
        try
        {
          this.msg.getProtocol().noop();
          if (this.msg.isExpunged()) {
            throw new MessageRemovedIOException();
          }
        }
        catch (ConnectionException localConnectionException)
        {
          throw new FolderClosedIOException(this.msg.getFolder(), localConnectionException.getMessage());
        }
      }
    }
    catch (FolderClosedException localFolderClosedException)
    {
      throw new FolderClosedIOException(localFolderClosedException.getFolder(), localFolderClosedException.getMessage());
      return;
    }
    catch (ProtocolException localProtocolException)
    {
      for (;;) {}
    }
  }
  
  public int available()
    throws IOException
  {
    try
    {
      int i = this.bufcount;
      int j = this.bufpos;
      return i - j;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  /* Error */
  public int read()
    throws IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 153	com/sun/mail/imap/IMAPInputStream:bufpos	I
    //   6: aload_0
    //   7: getfield 158	com/sun/mail/imap/IMAPInputStream:bufcount	I
    //   10: if_icmplt +28 -> 38
    //   13: aload_0
    //   14: invokespecial 170	com/sun/mail/imap/IMAPInputStream:fill	()V
    //   17: aload_0
    //   18: getfield 153	com/sun/mail/imap/IMAPInputStream:bufpos	I
    //   21: istore_1
    //   22: aload_0
    //   23: getfield 158	com/sun/mail/imap/IMAPInputStream:bufcount	I
    //   26: istore_2
    //   27: iload_1
    //   28: iload_2
    //   29: if_icmplt +9 -> 38
    //   32: iconst_m1
    //   33: istore_1
    //   34: aload_0
    //   35: monitorexit
    //   36: iload_1
    //   37: ireturn
    //   38: aload_0
    //   39: getfield 148	com/sun/mail/imap/IMAPInputStream:buf	[B
    //   42: astore_3
    //   43: aload_0
    //   44: getfield 153	com/sun/mail/imap/IMAPInputStream:bufpos	I
    //   47: istore_1
    //   48: aload_0
    //   49: iload_1
    //   50: iconst_1
    //   51: iadd
    //   52: putfield 153	com/sun/mail/imap/IMAPInputStream:bufpos	I
    //   55: aload_3
    //   56: iload_1
    //   57: baload
    //   58: istore_1
    //   59: iload_1
    //   60: sipush 255
    //   63: iand
    //   64: istore_1
    //   65: goto -31 -> 34
    //   68: astore_3
    //   69: aload_0
    //   70: monitorexit
    //   71: aload_3
    //   72: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	73	0	this	IMAPInputStream
    //   21	44	1	i	int
    //   26	4	2	j	int
    //   42	14	3	arrayOfByte	byte[]
    //   68	4	3	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   2	27	68	finally
    //   38	55	68	finally
  }
  
  public int read(byte[] paramArrayOfByte)
    throws IOException
  {
    return read(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    try
    {
      int j = this.bufcount - this.bufpos;
      int i = j;
      if (j <= 0)
      {
        fill();
        i = this.bufcount;
        j = this.bufpos;
        j = i - j;
        i = j;
        if (j <= 0)
        {
          paramInt2 = -1;
          return paramInt2;
        }
      }
      if (i < paramInt2) {
        paramInt2 = i;
      }
      for (;;)
      {
        System.arraycopy(this.buf, this.bufpos, paramArrayOfByte, paramInt1, paramInt2);
        this.bufpos += paramInt2;
        break;
      }
    }
    finally {}
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/imap/IMAPInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */