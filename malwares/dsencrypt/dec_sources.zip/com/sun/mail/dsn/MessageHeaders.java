package com.sun.mail.dsn;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import javax.activation.DataHandler;
import javax.mail.MessagingException;
import javax.mail.internet.InternetHeaders;
import javax.mail.internet.MimeMessage;

public class MessageHeaders
  extends MimeMessage
{
  public MessageHeaders()
    throws MessagingException
  {
    super(null);
    this.content = new byte[0];
  }
  
  public MessageHeaders(InputStream paramInputStream)
    throws MessagingException
  {
    super(null, paramInputStream);
    this.content = new byte[0];
  }
  
  public MessageHeaders(InternetHeaders paramInternetHeaders)
    throws MessagingException
  {
    super(null);
    this.headers = paramInternetHeaders;
    this.content = new byte[0];
  }
  
  protected InputStream getContentStream()
  {
    return new ByteArrayInputStream(this.content);
  }
  
  public InputStream getInputStream()
  {
    return new ByteArrayInputStream(this.content);
  }
  
  public int getSize()
  {
    return 0;
  }
  
  public void setDataHandler(DataHandler paramDataHandler)
    throws MessagingException
  {
    throw new MessagingException("Can't set content for MessageHeaders");
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/dsn/MessageHeaders.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */