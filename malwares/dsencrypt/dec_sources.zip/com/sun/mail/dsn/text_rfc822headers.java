package com.sun.mail.dsn;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import javax.activation.ActivationDataFlavor;
import javax.activation.DataContentHandler;
import javax.activation.DataSource;
import javax.mail.MessagingException;
import javax.mail.internet.ContentType;
import javax.mail.internet.MimeUtility;
import myjava.awt.datatransfer.DataFlavor;

public class text_rfc822headers
  implements DataContentHandler
{
  private static ActivationDataFlavor myDF = new ActivationDataFlavor(MessageHeaders.class, "text/rfc822-headers", "RFC822 headers");
  private static ActivationDataFlavor myDFs = new ActivationDataFlavor(String.class, "text/rfc822-headers", "RFC822 headers");
  
  private String getCharset(String paramString)
  {
    try
    {
      String str = new ContentType(paramString).getParameter("charset");
      paramString = str;
      if (str == null) {
        paramString = "us-ascii";
      }
      paramString = MimeUtility.javaCharset(paramString);
      return paramString;
    }
    catch (Exception paramString) {}
    return null;
  }
  
  private Object getStringContent(DataSource paramDataSource)
    throws IOException
  {
    Object localObject1 = null;
    int j;
    do
    {
      try
      {
        Object localObject2 = getCharset(paramDataSource.getContentType());
        localObject1 = localObject2;
        localObject2 = new InputStreamReader(paramDataSource.getInputStream(), (String)localObject2);
        i = 0;
        paramDataSource = new char['Ѐ'];
        j = ((InputStreamReader)localObject2).read(paramDataSource, i, paramDataSource.length - i);
        if (j == -1) {
          return new String(paramDataSource, 0, i);
        }
      }
      catch (IllegalArgumentException paramDataSource)
      {
        throw new UnsupportedEncodingException((String)localObject1);
      }
      j = i + j;
      i = j;
    } while (j < paramDataSource.length);
    int i = paramDataSource.length;
    if (i < 262144) {
      i += i;
    }
    for (;;)
    {
      localObject1 = new char[i];
      System.arraycopy(paramDataSource, 0, localObject1, 0, j);
      paramDataSource = (DataSource)localObject1;
      i = j;
      break;
      i += 262144;
    }
  }
  
  public Object getContent(DataSource paramDataSource)
    throws IOException
  {
    try
    {
      paramDataSource = new MessageHeaders(paramDataSource.getInputStream());
      return paramDataSource;
    }
    catch (MessagingException paramDataSource)
    {
      throw new IOException("Exception creating MessageHeaders: " + paramDataSource);
    }
  }
  
  public Object getTransferData(DataFlavor paramDataFlavor, DataSource paramDataSource)
    throws IOException
  {
    if (myDF.equals(paramDataFlavor)) {
      return getContent(paramDataSource);
    }
    if (myDFs.equals(paramDataFlavor)) {
      return getStringContent(paramDataSource);
    }
    return null;
  }
  
  public DataFlavor[] getTransferDataFlavors()
  {
    return new DataFlavor[] { myDF, myDFs };
  }
  
  public void writeTo(Object paramObject, String paramString, OutputStream paramOutputStream)
    throws IOException
  {
    if ((paramObject instanceof MessageHeaders))
    {
      paramObject = (MessageHeaders)paramObject;
      try
      {
        ((MessageHeaders)paramObject).writeTo(paramOutputStream);
        return;
      }
      catch (MessagingException paramObject)
      {
        paramString = ((MessagingException)paramObject).getNextException();
        if ((paramString instanceof IOException)) {
          throw ((IOException)paramString);
        }
        throw new IOException("Exception writing headers: " + paramObject);
      }
    }
    if (!(paramObject instanceof String)) {
      throw new IOException("\"" + myDFs.getMimeType() + "\" DataContentHandler requires String object, " + "was given object of type " + paramObject.getClass().toString());
    }
    String str = null;
    try
    {
      paramString = getCharset(paramString);
      str = paramString;
      paramString = new OutputStreamWriter(paramOutputStream, paramString);
      paramObject = (String)paramObject;
      paramString.write((String)paramObject, 0, ((String)paramObject).length());
      paramString.flush();
      return;
    }
    catch (IllegalArgumentException paramObject)
    {
      throw new UnsupportedEncodingException(str);
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/dsn/text_rfc822headers.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */