package com.sun.mail.dsn;

import java.io.IOException;
import java.util.Vector;
import javax.activation.DataSource;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.ContentType;
import javax.mail.internet.InternetHeaders;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class MultipartReport
  extends MimeMultipart
{
  protected boolean constructed;
  
  public MultipartReport()
    throws MessagingException
  {
    super("report");
    setBodyPart(new MimeBodyPart(), 0);
    setBodyPart(new MimeBodyPart(), 1);
    this.constructed = true;
  }
  
  public MultipartReport(String paramString, DeliveryStatus paramDeliveryStatus)
    throws MessagingException
  {
    super("report");
    Object localObject = new ContentType(this.contentType);
    ((ContentType)localObject).setParameter("report-type", "delivery-status");
    this.contentType = ((ContentType)localObject).toString();
    localObject = new MimeBodyPart();
    ((MimeBodyPart)localObject).setText(paramString);
    setBodyPart((BodyPart)localObject, 0);
    paramString = new MimeBodyPart();
    paramString.setContent(paramDeliveryStatus, "message/delivery-status");
    setBodyPart(paramString, 1);
    this.constructed = true;
  }
  
  public MultipartReport(String paramString, DeliveryStatus paramDeliveryStatus, InternetHeaders paramInternetHeaders)
    throws MessagingException
  {
    this(paramString, paramDeliveryStatus);
    if (paramInternetHeaders != null)
    {
      paramString = new MimeBodyPart();
      paramString.setContent(new MessageHeaders(paramInternetHeaders), "text/rfc822-headers");
      setBodyPart(paramString, 2);
    }
  }
  
  public MultipartReport(String paramString, DeliveryStatus paramDeliveryStatus, MimeMessage paramMimeMessage)
    throws MessagingException
  {
    this(paramString, paramDeliveryStatus);
    if (paramMimeMessage != null)
    {
      paramString = new MimeBodyPart();
      paramString.setContent(paramMimeMessage, "message/rfc822");
      setBodyPart(paramString, 2);
    }
  }
  
  public MultipartReport(DataSource paramDataSource)
    throws MessagingException
  {
    super(paramDataSource);
    parse();
    this.constructed = true;
  }
  
  private void setBodyPart(BodyPart paramBodyPart, int paramInt)
    throws MessagingException
  {
    try
    {
      if (this.parts == null) {
        this.parts = new Vector();
      }
      if (paramInt < this.parts.size()) {
        super.removeBodyPart(paramInt);
      }
      super.addBodyPart(paramBodyPart, paramInt);
      return;
    }
    finally {}
  }
  
  public void addBodyPart(BodyPart paramBodyPart)
    throws MessagingException
  {
    try
    {
      if (!this.constructed)
      {
        super.addBodyPart(paramBodyPart);
        return;
      }
      throw new MessagingException("Can't add body parts to multipart/report 1");
    }
    finally {}
  }
  
  public void addBodyPart(BodyPart paramBodyPart, int paramInt)
    throws MessagingException
  {
    try
    {
      throw new MessagingException("Can't add body parts to multipart/report 2");
    }
    finally {}
  }
  
  /* Error */
  public DeliveryStatus getDeliveryStatus()
    throws MessagingException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: invokevirtual 108	com/sun/mail/dsn/MultipartReport:getCount	()I
    //   8: istore_1
    //   9: iload_1
    //   10: iconst_2
    //   11: if_icmpge +7 -> 18
    //   14: aload_0
    //   15: monitorexit
    //   16: aload_3
    //   17: areturn
    //   18: aload_0
    //   19: iconst_1
    //   20: invokevirtual 112	com/sun/mail/dsn/MultipartReport:getBodyPart	(I)Ljavax/mail/BodyPart;
    //   23: astore 4
    //   25: aload 4
    //   27: ldc 52
    //   29: invokevirtual 118	javax/mail/BodyPart:isMimeType	(Ljava/lang/String;)Z
    //   32: istore_2
    //   33: iload_2
    //   34: ifeq -20 -> 14
    //   37: aload 4
    //   39: invokevirtual 122	javax/mail/BodyPart:getContent	()Ljava/lang/Object;
    //   42: checkcast 124	com/sun/mail/dsn/DeliveryStatus
    //   45: astore_3
    //   46: goto -32 -> 14
    //   49: astore_3
    //   50: new 10	javax/mail/MessagingException
    //   53: dup
    //   54: ldc 126
    //   56: aload_3
    //   57: invokespecial 129	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   60: athrow
    //   61: astore_3
    //   62: aload_0
    //   63: monitorexit
    //   64: aload_3
    //   65: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	66	0	this	MultipartReport
    //   8	4	1	i	int
    //   32	2	2	bool	boolean
    //   1	45	3	localDeliveryStatus	DeliveryStatus
    //   49	8	3	localIOException	IOException
    //   61	4	3	localObject	Object
    //   23	15	4	localBodyPart	BodyPart
    // Exception table:
    //   from	to	target	type
    //   37	46	49	java/io/IOException
    //   4	9	61	finally
    //   18	33	61	finally
    //   37	46	61	finally
    //   50	61	61	finally
  }
  
  /* Error */
  public MimeMessage getReturnedMessage()
    throws MessagingException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: invokevirtual 108	com/sun/mail/dsn/MultipartReport:getCount	()I
    //   8: istore_1
    //   9: iload_1
    //   10: iconst_3
    //   11: if_icmpge +7 -> 18
    //   14: aload_0
    //   15: monitorexit
    //   16: aload_3
    //   17: areturn
    //   18: aload_0
    //   19: iconst_2
    //   20: invokevirtual 112	com/sun/mail/dsn/MultipartReport:getBodyPart	(I)Ljavax/mail/BodyPart;
    //   23: astore 4
    //   25: aload 4
    //   27: ldc 69
    //   29: invokevirtual 118	javax/mail/BodyPart:isMimeType	(Ljava/lang/String;)Z
    //   32: ifne +15 -> 47
    //   35: aload 4
    //   37: ldc 66
    //   39: invokevirtual 118	javax/mail/BodyPart:isMimeType	(Ljava/lang/String;)Z
    //   42: istore_2
    //   43: iload_2
    //   44: ifeq -30 -> 14
    //   47: aload 4
    //   49: invokevirtual 122	javax/mail/BodyPart:getContent	()Ljava/lang/Object;
    //   52: checkcast 133	javax/mail/internet/MimeMessage
    //   55: astore_3
    //   56: goto -42 -> 14
    //   59: astore_3
    //   60: new 10	javax/mail/MessagingException
    //   63: dup
    //   64: ldc -121
    //   66: aload_3
    //   67: invokespecial 129	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   70: athrow
    //   71: astore_3
    //   72: aload_0
    //   73: monitorexit
    //   74: aload_3
    //   75: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	76	0	this	MultipartReport
    //   8	4	1	i	int
    //   42	2	2	bool	boolean
    //   1	55	3	localMimeMessage	MimeMessage
    //   59	8	3	localIOException	IOException
    //   71	4	3	localObject	Object
    //   23	25	4	localBodyPart	BodyPart
    // Exception table:
    //   from	to	target	type
    //   47	56	59	java/io/IOException
    //   4	9	71	finally
    //   18	43	71	finally
    //   47	56	71	finally
    //   60	71	71	finally
  }
  
  public String getText()
    throws MessagingException
  {
    for (;;)
    {
      try
      {
        Object localObject1 = getBodyPart(0);
        if (((BodyPart)localObject1).isMimeType("text/plain"))
        {
          localObject1 = (String)((BodyPart)localObject1).getContent();
          return (String)localObject1;
        }
        if (((BodyPart)localObject1).isMimeType("multipart/alternative"))
        {
          localObject1 = (Multipart)((BodyPart)localObject1).getContent();
          int i = 0;
          if (i < ((Multipart)localObject1).getCount())
          {
            BodyPart localBodyPart = ((Multipart)localObject1).getBodyPart(i);
            if (localBodyPart.isMimeType("text/plain"))
            {
              localObject1 = (String)localBodyPart.getContent();
              continue;
            }
            i += 1;
            continue;
          }
        }
        Object localObject3 = null;
      }
      catch (IOException localIOException)
      {
        throw new MessagingException("Exception getting text content", localIOException);
      }
      finally {}
    }
  }
  
  public MimeBodyPart getTextBodyPart()
    throws MessagingException
  {
    try
    {
      MimeBodyPart localMimeBodyPart = (MimeBodyPart)getBodyPart(0);
      return localMimeBodyPart;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public void removeBodyPart(int paramInt)
    throws MessagingException
  {
    throw new MessagingException("Can't remove body parts from multipart/report");
  }
  
  public boolean removeBodyPart(BodyPart paramBodyPart)
    throws MessagingException
  {
    throw new MessagingException("Can't remove body parts from multipart/report");
  }
  
  public void setDeliveryStatus(DeliveryStatus paramDeliveryStatus)
    throws MessagingException
  {
    try
    {
      MimeBodyPart localMimeBodyPart = new MimeBodyPart();
      localMimeBodyPart.setContent(paramDeliveryStatus, "message/delivery-status");
      setBodyPart(localMimeBodyPart, 2);
      paramDeliveryStatus = new ContentType(this.contentType);
      paramDeliveryStatus.setParameter("report-type", "delivery-status");
      this.contentType = paramDeliveryStatus.toString();
      return;
    }
    finally
    {
      paramDeliveryStatus = finally;
      throw paramDeliveryStatus;
    }
  }
  
  public void setReturnedMessage(MimeMessage paramMimeMessage)
    throws MessagingException
  {
    if (paramMimeMessage == null) {}
    try
    {
      paramMimeMessage = (BodyPart)this.parts.elementAt(2);
      super.removeBodyPart(2);
      return;
    }
    finally {}
    MimeBodyPart localMimeBodyPart = new MimeBodyPart();
    if ((paramMimeMessage instanceof MessageHeaders)) {
      localMimeBodyPart.setContent(paramMimeMessage, "text/rfc822-headers");
    }
    for (;;)
    {
      setBodyPart(localMimeBodyPart, 2);
      break;
      localMimeBodyPart.setContent(paramMimeMessage, "message/rfc822");
    }
  }
  
  public void setSubType(String paramString)
    throws MessagingException
  {
    try
    {
      throw new MessagingException("Can't change subtype of MultipartReport");
    }
    finally {}
  }
  
  public void setText(String paramString)
    throws MessagingException
  {
    try
    {
      MimeBodyPart localMimeBodyPart = new MimeBodyPart();
      localMimeBodyPart.setText(paramString);
      setBodyPart(localMimeBodyPart, 0);
      return;
    }
    finally
    {
      paramString = finally;
      throw paramString;
    }
  }
  
  public void setTextBodyPart(MimeBodyPart paramMimeBodyPart)
    throws MessagingException
  {
    try
    {
      setBodyPart(paramMimeBodyPart, 0);
      return;
    }
    finally
    {
      paramMimeBodyPart = finally;
      throw paramMimeBodyPart;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/dsn/MultipartReport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */