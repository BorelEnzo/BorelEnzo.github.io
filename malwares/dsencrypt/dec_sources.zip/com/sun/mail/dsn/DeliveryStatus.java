package com.sun.mail.dsn;

import com.sun.mail.util.LineOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Vector;
import javax.mail.MessagingException;
import javax.mail.internet.InternetHeaders;

public class DeliveryStatus
{
  private static boolean debug;
  protected InternetHeaders messageDSN;
  protected InternetHeaders[] recipientDSN;
  
  static
  {
    boolean bool2 = false;
    debug = false;
    try
    {
      String str = System.getProperty("mail.dsn.debug");
      boolean bool1 = bool2;
      if (str != null)
      {
        bool1 = bool2;
        if (!str.equalsIgnoreCase("false")) {
          bool1 = true;
        }
      }
      debug = bool1;
      return;
    }
    catch (SecurityException localSecurityException) {}
  }
  
  public DeliveryStatus()
    throws MessagingException
  {
    this.messageDSN = new InternetHeaders();
    this.recipientDSN = new InternetHeaders[0];
  }
  
  public DeliveryStatus(InputStream paramInputStream)
    throws MessagingException, IOException
  {
    this.messageDSN = new InternetHeaders(paramInputStream);
    if (debug) {
      System.out.println("DSN: got messageDSN");
    }
    Vector localVector = new Vector();
    for (;;)
    {
      try
      {
        int i = paramInputStream.available();
        if (i > 0) {
          continue;
        }
      }
      catch (EOFException paramInputStream)
      {
        InternetHeaders localInternetHeaders;
        if (!debug) {
          continue;
        }
        System.out.println("DSN: got EOFException");
        continue;
      }
      if (debug) {
        System.out.println("DSN: recipientDSN size " + localVector.size());
      }
      this.recipientDSN = new InternetHeaders[localVector.size()];
      localVector.copyInto(this.recipientDSN);
      return;
      localInternetHeaders = new InternetHeaders(paramInputStream);
      if (debug) {
        System.out.println("DSN: got recipientDSN");
      }
      localVector.addElement(localInternetHeaders);
    }
  }
  
  /* Error */
  private static void writeInternetHeaders(InternetHeaders paramInternetHeaders, LineOutputStream paramLineOutputStream)
    throws IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 109	javax/mail/internet/InternetHeaders:getAllHeaderLines	()Ljava/util/Enumeration;
    //   4: astore_0
    //   5: aload_0
    //   6: invokeinterface 115 1 0
    //   11: ifne +4 -> 15
    //   14: return
    //   15: aload_1
    //   16: aload_0
    //   17: invokeinterface 119 1 0
    //   22: checkcast 28	java/lang/String
    //   25: invokevirtual 124	com/sun/mail/util/LineOutputStream:writeln	(Ljava/lang/String;)V
    //   28: goto -23 -> 5
    //   31: astore_0
    //   32: aload_0
    //   33: invokevirtual 128	javax/mail/MessagingException:getNextException	()Ljava/lang/Exception;
    //   36: astore_1
    //   37: aload_1
    //   38: instanceof 49
    //   41: ifeq +8 -> 49
    //   44: aload_1
    //   45: checkcast 49	java/io/IOException
    //   48: athrow
    //   49: new 49	java/io/IOException
    //   52: dup
    //   53: new 76	java/lang/StringBuilder
    //   56: dup
    //   57: ldc -126
    //   59: invokespecial 80	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   62: aload_0
    //   63: invokevirtual 133	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   66: invokevirtual 91	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   69: invokespecial 134	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   72: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	73	0	paramInternetHeaders	InternetHeaders
    //   0	73	1	paramLineOutputStream	LineOutputStream
    // Exception table:
    //   from	to	target	type
    //   5	14	31	javax/mail/MessagingException
    //   15	28	31	javax/mail/MessagingException
  }
  
  public void addRecipientDSN(InternetHeaders paramInternetHeaders)
  {
    InternetHeaders[] arrayOfInternetHeaders = new InternetHeaders[this.recipientDSN.length + 1];
    System.arraycopy(this.recipientDSN, 0, arrayOfInternetHeaders, 0, this.recipientDSN.length);
    this.recipientDSN = arrayOfInternetHeaders;
    this.recipientDSN[(this.recipientDSN.length - 1)] = paramInternetHeaders;
  }
  
  public InternetHeaders getMessageDSN()
  {
    return this.messageDSN;
  }
  
  public InternetHeaders getRecipientDSN(int paramInt)
  {
    return this.recipientDSN[paramInt];
  }
  
  public int getRecipientDSNCount()
  {
    return this.recipientDSN.length;
  }
  
  public void setMessageDSN(InternetHeaders paramInternetHeaders)
  {
    this.messageDSN = paramInternetHeaders;
  }
  
  public String toString()
  {
    return "DeliveryStatus: Reporting-MTA=" + this.messageDSN.getHeader("Reporting-MTA", null) + ", #Recipients=" + this.recipientDSN.length;
  }
  
  public void writeTo(OutputStream paramOutputStream)
    throws IOException, MessagingException
  {
    int i;
    if ((paramOutputStream instanceof LineOutputStream))
    {
      paramOutputStream = (LineOutputStream)paramOutputStream;
      writeInternetHeaders(this.messageDSN, paramOutputStream);
      paramOutputStream.writeln();
      i = 0;
    }
    for (;;)
    {
      if (i >= this.recipientDSN.length)
      {
        return;
        paramOutputStream = new LineOutputStream(paramOutputStream);
        break;
      }
      writeInternetHeaders(this.recipientDSN[i], paramOutputStream);
      paramOutputStream.writeln();
      i += 1;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/dsn/DeliveryStatus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */