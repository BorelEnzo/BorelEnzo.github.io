package com.sun.mail.dsn;

import java.io.IOException;
import java.io.OutputStream;
import javax.activation.ActivationDataFlavor;
import javax.activation.DataContentHandler;
import javax.activation.DataSource;
import javax.mail.MessagingException;
import myjava.awt.datatransfer.DataFlavor;

public class message_deliverystatus
  implements DataContentHandler
{
  ActivationDataFlavor ourDataFlavor = new ActivationDataFlavor(DeliveryStatus.class, "message/delivery-status", "Delivery Status");
  
  public Object getContent(DataSource paramDataSource)
    throws IOException
  {
    try
    {
      paramDataSource = new DeliveryStatus(paramDataSource.getInputStream());
      return paramDataSource;
    }
    catch (MessagingException paramDataSource)
    {
      throw new IOException("Exception creating DeliveryStatus in message/devliery-status DataContentHandler: " + paramDataSource.toString());
    }
  }
  
  public Object getTransferData(DataFlavor paramDataFlavor, DataSource paramDataSource)
    throws IOException
  {
    if (this.ourDataFlavor.equals(paramDataFlavor)) {
      return getContent(paramDataSource);
    }
    return null;
  }
  
  public DataFlavor[] getTransferDataFlavors()
  {
    return new DataFlavor[] { this.ourDataFlavor };
  }
  
  public void writeTo(Object paramObject, String paramString, OutputStream paramOutputStream)
    throws IOException
  {
    if ((paramObject instanceof DeliveryStatus))
    {
      paramObject = (DeliveryStatus)paramObject;
      try
      {
        ((DeliveryStatus)paramObject).writeTo(paramOutputStream);
        return;
      }
      catch (MessagingException paramObject)
      {
        throw new IOException(((MessagingException)paramObject).toString());
      }
    }
    throw new IOException("unsupported object");
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/dsn/message_deliverystatus.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */