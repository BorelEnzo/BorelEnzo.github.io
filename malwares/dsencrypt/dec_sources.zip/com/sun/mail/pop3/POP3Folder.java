package com.sun.mail.pop3;

import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Constructor;
import java.util.Vector;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.FolderNotFoundException;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.MethodNotSupportedException;
import javax.mail.Store;

public class POP3Folder
  extends Folder
{
  private boolean doneUidl = false;
  private boolean exists = false;
  private Vector message_cache;
  private String name;
  private boolean opened = false;
  private Protocol port;
  private int size;
  private int total;
  
  POP3Folder(POP3Store paramPOP3Store, String paramString)
  {
    super(paramPOP3Store);
    this.name = paramString;
    if (paramString.equalsIgnoreCase("INBOX")) {
      this.exists = true;
    }
  }
  
  public void appendMessages(Message[] paramArrayOfMessage)
    throws MessagingException
  {
    throw new MethodNotSupportedException("Append not supported");
  }
  
  void checkClosed()
    throws IllegalStateException
  {
    if (this.opened) {
      throw new IllegalStateException("Folder is Open");
    }
  }
  
  void checkOpen()
    throws IllegalStateException
  {
    if (!this.opened) {
      throw new IllegalStateException("Folder is not Open");
    }
  }
  
  void checkReadable()
    throws IllegalStateException
  {
    if ((!this.opened) || ((this.mode != 1) && (this.mode != 2))) {
      throw new IllegalStateException("Folder is not Readable");
    }
  }
  
  void checkWritable()
    throws IllegalStateException
  {
    if ((!this.opened) || (this.mode != 2)) {
      throw new IllegalStateException("Folder is not Writable");
    }
  }
  
  /* Error */
  public void close(boolean paramBoolean)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual 76	com/sun/mail/pop3/POP3Folder:checkOpen	()V
    //   6: aload_0
    //   7: getfield 80	com/sun/mail/pop3/POP3Folder:store	Ljavax/mail/Store;
    //   10: checkcast 82	com/sun/mail/pop3/POP3Store
    //   13: getfield 85	com/sun/mail/pop3/POP3Store:rsetBeforeQuit	Z
    //   16: ifeq +11 -> 27
    //   19: aload_0
    //   20: getfield 87	com/sun/mail/pop3/POP3Folder:port	Lcom/sun/mail/pop3/Protocol;
    //   23: invokevirtual 93	com/sun/mail/pop3/Protocol:rset	()Z
    //   26: pop
    //   27: iload_1
    //   28: ifeq +24 -> 52
    //   31: aload_0
    //   32: getfield 65	com/sun/mail/pop3/POP3Folder:mode	I
    //   35: iconst_2
    //   36: if_icmpne +16 -> 52
    //   39: iconst_0
    //   40: istore_2
    //   41: iload_2
    //   42: aload_0
    //   43: getfield 95	com/sun/mail/pop3/POP3Folder:message_cache	Ljava/util/Vector;
    //   46: invokevirtual 100	java/util/Vector:size	()I
    //   49: if_icmplt +45 -> 94
    //   52: aload_0
    //   53: getfield 87	com/sun/mail/pop3/POP3Folder:port	Lcom/sun/mail/pop3/Protocol;
    //   56: invokevirtual 103	com/sun/mail/pop3/Protocol:quit	()Z
    //   59: pop
    //   60: aload_0
    //   61: aconst_null
    //   62: putfield 87	com/sun/mail/pop3/POP3Folder:port	Lcom/sun/mail/pop3/Protocol;
    //   65: aload_0
    //   66: getfield 80	com/sun/mail/pop3/POP3Folder:store	Ljavax/mail/Store;
    //   69: checkcast 82	com/sun/mail/pop3/POP3Store
    //   72: aload_0
    //   73: invokevirtual 107	com/sun/mail/pop3/POP3Store:closePort	(Lcom/sun/mail/pop3/POP3Folder;)V
    //   76: aload_0
    //   77: aconst_null
    //   78: putfield 95	com/sun/mail/pop3/POP3Folder:message_cache	Ljava/util/Vector;
    //   81: aload_0
    //   82: iconst_0
    //   83: putfield 26	com/sun/mail/pop3/POP3Folder:opened	Z
    //   86: aload_0
    //   87: iconst_3
    //   88: invokevirtual 111	com/sun/mail/pop3/POP3Folder:notifyConnectionListeners	(I)V
    //   91: aload_0
    //   92: monitorexit
    //   93: return
    //   94: aload_0
    //   95: getfield 95	com/sun/mail/pop3/POP3Folder:message_cache	Ljava/util/Vector;
    //   98: iload_2
    //   99: invokevirtual 115	java/util/Vector:elementAt	(I)Ljava/lang/Object;
    //   102: checkcast 117	com/sun/mail/pop3/POP3Message
    //   105: astore_3
    //   106: aload_3
    //   107: ifnull +26 -> 133
    //   110: aload_3
    //   111: getstatic 123	javax/mail/Flags$Flag:DELETED	Ljavax/mail/Flags$Flag;
    //   114: invokevirtual 127	com/sun/mail/pop3/POP3Message:isSet	(Ljavax/mail/Flags$Flag;)Z
    //   117: istore_1
    //   118: iload_1
    //   119: ifeq +14 -> 133
    //   122: aload_0
    //   123: getfield 87	com/sun/mail/pop3/POP3Folder:port	Lcom/sun/mail/pop3/Protocol;
    //   126: iload_2
    //   127: iconst_1
    //   128: iadd
    //   129: invokevirtual 131	com/sun/mail/pop3/Protocol:dele	(I)Z
    //   132: pop
    //   133: iload_2
    //   134: iconst_1
    //   135: iadd
    //   136: istore_2
    //   137: goto -96 -> 41
    //   140: astore_3
    //   141: new 43	javax/mail/MessagingException
    //   144: dup
    //   145: ldc -123
    //   147: aload_3
    //   148: invokespecial 136	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   151: athrow
    //   152: astore_3
    //   153: aload_0
    //   154: aconst_null
    //   155: putfield 87	com/sun/mail/pop3/POP3Folder:port	Lcom/sun/mail/pop3/Protocol;
    //   158: aload_0
    //   159: getfield 80	com/sun/mail/pop3/POP3Folder:store	Ljavax/mail/Store;
    //   162: checkcast 82	com/sun/mail/pop3/POP3Store
    //   165: aload_0
    //   166: invokevirtual 107	com/sun/mail/pop3/POP3Store:closePort	(Lcom/sun/mail/pop3/POP3Folder;)V
    //   169: aload_0
    //   170: aconst_null
    //   171: putfield 95	com/sun/mail/pop3/POP3Folder:message_cache	Ljava/util/Vector;
    //   174: aload_0
    //   175: iconst_0
    //   176: putfield 26	com/sun/mail/pop3/POP3Folder:opened	Z
    //   179: aload_0
    //   180: iconst_3
    //   181: invokevirtual 111	com/sun/mail/pop3/POP3Folder:notifyConnectionListeners	(I)V
    //   184: goto -93 -> 91
    //   187: astore_3
    //   188: aload_0
    //   189: monitorexit
    //   190: aload_3
    //   191: athrow
    //   192: astore_3
    //   193: aload_0
    //   194: aconst_null
    //   195: putfield 87	com/sun/mail/pop3/POP3Folder:port	Lcom/sun/mail/pop3/Protocol;
    //   198: aload_0
    //   199: getfield 80	com/sun/mail/pop3/POP3Folder:store	Ljavax/mail/Store;
    //   202: checkcast 82	com/sun/mail/pop3/POP3Store
    //   205: aload_0
    //   206: invokevirtual 107	com/sun/mail/pop3/POP3Store:closePort	(Lcom/sun/mail/pop3/POP3Folder;)V
    //   209: aload_0
    //   210: aconst_null
    //   211: putfield 95	com/sun/mail/pop3/POP3Folder:message_cache	Ljava/util/Vector;
    //   214: aload_0
    //   215: iconst_0
    //   216: putfield 26	com/sun/mail/pop3/POP3Folder:opened	Z
    //   219: aload_0
    //   220: iconst_3
    //   221: invokevirtual 111	com/sun/mail/pop3/POP3Folder:notifyConnectionListeners	(I)V
    //   224: aload_3
    //   225: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	226	0	this	POP3Folder
    //   0	226	1	paramBoolean	boolean
    //   40	97	2	i	int
    //   105	6	3	localPOP3Message	POP3Message
    //   140	8	3	localIOException1	IOException
    //   152	1	3	localIOException2	IOException
    //   187	4	3	localObject1	Object
    //   192	33	3	localObject2	Object
    // Exception table:
    //   from	to	target	type
    //   122	133	140	java/io/IOException
    //   6	27	152	java/io/IOException
    //   31	39	152	java/io/IOException
    //   41	52	152	java/io/IOException
    //   52	60	152	java/io/IOException
    //   94	106	152	java/io/IOException
    //   110	118	152	java/io/IOException
    //   141	152	152	java/io/IOException
    //   2	6	187	finally
    //   60	91	187	finally
    //   153	184	187	finally
    //   193	226	187	finally
    //   6	27	192	finally
    //   31	39	192	finally
    //   41	52	192	finally
    //   52	60	192	finally
    //   94	106	192	finally
    //   110	118	192	finally
    //   122	133	192	finally
    //   141	152	192	finally
  }
  
  public boolean create(int paramInt)
    throws MessagingException
  {
    return false;
  }
  
  protected POP3Message createMessage(Folder paramFolder, int paramInt)
    throws MessagingException
  {
    Object localObject = null;
    Constructor localConstructor = ((POP3Store)this.store).messageConstructor;
    paramFolder = (Folder)localObject;
    if (localConstructor != null) {}
    try
    {
      paramFolder = (POP3Message)localConstructor.newInstance(new Object[] { this, new Integer(paramInt) });
      localObject = paramFolder;
      if (paramFolder == null) {
        localObject = new POP3Message(this, paramInt);
      }
      return (POP3Message)localObject;
    }
    catch (Exception paramFolder)
    {
      for (;;)
      {
        paramFolder = (Folder)localObject;
      }
    }
  }
  
  public boolean delete(boolean paramBoolean)
    throws MessagingException
  {
    throw new MethodNotSupportedException("delete");
  }
  
  public boolean exists()
  {
    return this.exists;
  }
  
  public Message[] expunge()
    throws MessagingException
  {
    throw new MethodNotSupportedException("Expunge not supported");
  }
  
  /* Error */
  public void fetch(Message[] paramArrayOfMessage, javax.mail.FetchProfile paramFetchProfile)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual 175	com/sun/mail/pop3/POP3Folder:checkReadable	()V
    //   6: aload_0
    //   7: getfield 28	com/sun/mail/pop3/POP3Folder:doneUidl	Z
    //   10: ifne +92 -> 102
    //   13: aload_2
    //   14: getstatic 181	javax/mail/UIDFolder$FetchProfileItem:UID	Ljavax/mail/UIDFolder$FetchProfileItem;
    //   17: invokevirtual 187	javax/mail/FetchProfile:contains	(Ljavax/mail/FetchProfile$Item;)Z
    //   20: ifeq +82 -> 102
    //   23: aload_0
    //   24: getfield 95	com/sun/mail/pop3/POP3Folder:message_cache	Ljava/util/Vector;
    //   27: invokevirtual 100	java/util/Vector:size	()I
    //   30: anewarray 34	java/lang/String
    //   33: astore 6
    //   35: aload_0
    //   36: getfield 87	com/sun/mail/pop3/POP3Folder:port	Lcom/sun/mail/pop3/Protocol;
    //   39: aload 6
    //   41: invokevirtual 191	com/sun/mail/pop3/Protocol:uidl	([Ljava/lang/String;)Z
    //   44: istore 5
    //   46: iload 5
    //   48: ifne +136 -> 184
    //   51: aload_0
    //   52: monitorexit
    //   53: return
    //   54: astore_1
    //   55: aload_0
    //   56: iconst_0
    //   57: invokevirtual 193	com/sun/mail/pop3/POP3Folder:close	(Z)V
    //   60: new 195	javax/mail/FolderClosedException
    //   63: dup
    //   64: aload_0
    //   65: aload_1
    //   66: invokevirtual 199	java/io/EOFException:toString	()Ljava/lang/String;
    //   69: invokespecial 202	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   72: athrow
    //   73: astore_1
    //   74: aload_0
    //   75: monitorexit
    //   76: aload_1
    //   77: athrow
    //   78: astore_1
    //   79: new 43	javax/mail/MessagingException
    //   82: dup
    //   83: ldc -52
    //   85: aload_1
    //   86: invokespecial 136	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   89: athrow
    //   90: iload_3
    //   91: aload 6
    //   93: arraylength
    //   94: if_icmplt +56 -> 150
    //   97: aload_0
    //   98: iconst_1
    //   99: putfield 28	com/sun/mail/pop3/POP3Folder:doneUidl	Z
    //   102: aload_2
    //   103: getstatic 210	javax/mail/FetchProfile$Item:ENVELOPE	Ljavax/mail/FetchProfile$Item;
    //   106: invokevirtual 187	javax/mail/FetchProfile:contains	(Ljavax/mail/FetchProfile$Item;)Z
    //   109: ifeq -58 -> 51
    //   112: iconst_0
    //   113: istore_3
    //   114: aload_1
    //   115: arraylength
    //   116: istore 4
    //   118: iload_3
    //   119: iload 4
    //   121: if_icmpge -70 -> 51
    //   124: aload_1
    //   125: iload_3
    //   126: aaload
    //   127: checkcast 117	com/sun/mail/pop3/POP3Message
    //   130: astore_2
    //   131: aload_2
    //   132: ldc -44
    //   134: invokevirtual 216	com/sun/mail/pop3/POP3Message:getHeader	(Ljava/lang/String;)[Ljava/lang/String;
    //   137: pop
    //   138: aload_2
    //   139: invokevirtual 219	com/sun/mail/pop3/POP3Message:getSize	()I
    //   142: pop
    //   143: iload_3
    //   144: iconst_1
    //   145: iadd
    //   146: istore_3
    //   147: goto -33 -> 114
    //   150: aload 6
    //   152: iload_3
    //   153: aaload
    //   154: ifnonnull +6 -> 160
    //   157: goto +32 -> 189
    //   160: aload_0
    //   161: iload_3
    //   162: iconst_1
    //   163: iadd
    //   164: invokevirtual 223	com/sun/mail/pop3/POP3Folder:getMessage	(I)Ljavax/mail/Message;
    //   167: checkcast 117	com/sun/mail/pop3/POP3Message
    //   170: aload 6
    //   172: iload_3
    //   173: aaload
    //   174: putfield 226	com/sun/mail/pop3/POP3Message:uid	Ljava/lang/String;
    //   177: goto +12 -> 189
    //   180: astore_2
    //   181: goto -38 -> 143
    //   184: iconst_0
    //   185: istore_3
    //   186: goto -96 -> 90
    //   189: iload_3
    //   190: iconst_1
    //   191: iadd
    //   192: istore_3
    //   193: goto -103 -> 90
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	196	0	this	POP3Folder
    //   0	196	1	paramArrayOfMessage	Message[]
    //   0	196	2	paramFetchProfile	javax.mail.FetchProfile
    //   90	103	3	i	int
    //   116	6	4	j	int
    //   44	3	5	bool	boolean
    //   33	138	6	arrayOfString	String[]
    // Exception table:
    //   from	to	target	type
    //   35	46	54	java/io/EOFException
    //   2	35	73	finally
    //   35	46	73	finally
    //   55	73	73	finally
    //   79	90	73	finally
    //   90	102	73	finally
    //   102	112	73	finally
    //   114	118	73	finally
    //   124	143	73	finally
    //   160	177	73	finally
    //   35	46	78	java/io/IOException
    //   124	143	180	javax/mail/MessageRemovedException
  }
  
  protected void finalize()
    throws Throwable
  {
    super.finalize();
    close(false);
  }
  
  public Folder getFolder(String paramString)
    throws MessagingException
  {
    throw new MessagingException("not a directory");
  }
  
  public String getFullName()
  {
    return this.name;
  }
  
  public Message getMessage(int paramInt)
    throws MessagingException
  {
    try
    {
      checkOpen();
      POP3Message localPOP3Message2 = (POP3Message)this.message_cache.elementAt(paramInt - 1);
      POP3Message localPOP3Message1 = localPOP3Message2;
      if (localPOP3Message2 == null)
      {
        localPOP3Message1 = createMessage(this, paramInt);
        this.message_cache.setElementAt(localPOP3Message1, paramInt - 1);
      }
      return localPOP3Message1;
    }
    finally {}
  }
  
  /* Error */
  public int getMessageCount()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 26	com/sun/mail/pop3/POP3Folder:opened	Z
    //   6: istore_2
    //   7: iload_2
    //   8: ifne +9 -> 17
    //   11: iconst_m1
    //   12: istore_1
    //   13: aload_0
    //   14: monitorexit
    //   15: iload_1
    //   16: ireturn
    //   17: aload_0
    //   18: invokevirtual 175	com/sun/mail/pop3/POP3Folder:checkReadable	()V
    //   21: aload_0
    //   22: getfield 246	com/sun/mail/pop3/POP3Folder:total	I
    //   25: istore_1
    //   26: goto -13 -> 13
    //   29: astore_3
    //   30: aload_0
    //   31: monitorexit
    //   32: aload_3
    //   33: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	34	0	this	POP3Folder
    //   12	14	1	i	int
    //   6	2	2	bool	boolean
    //   29	4	3	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   2	7	29	finally
    //   17	26	29	finally
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public Folder getParent()
  {
    return new DefaultFolder((POP3Store)this.store);
  }
  
  public Flags getPermanentFlags()
  {
    return new Flags();
  }
  
  Protocol getProtocol()
    throws MessagingException
  {
    checkOpen();
    return this.port;
  }
  
  public char getSeparator()
  {
    return '\000';
  }
  
  public int getSize()
    throws MessagingException
  {
    try
    {
      checkOpen();
      int i = this.size;
      return i;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  /* Error */
  public int[] getSizes()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual 76	com/sun/mail/pop3/POP3Folder:checkOpen	()V
    //   6: aload_0
    //   7: getfield 246	com/sun/mail/pop3/POP3Folder:total	I
    //   10: newarray <illegal type>
    //   12: astore 9
    //   14: aconst_null
    //   15: astore 5
    //   17: aconst_null
    //   18: astore 4
    //   20: aconst_null
    //   21: astore 7
    //   23: aconst_null
    //   24: astore 8
    //   26: aload_0
    //   27: getfield 87	com/sun/mail/pop3/POP3Folder:port	Lcom/sun/mail/pop3/Protocol;
    //   30: invokevirtual 272	com/sun/mail/pop3/Protocol:list	()Ljava/io/InputStream;
    //   33: astore_3
    //   34: aload_3
    //   35: astore 4
    //   37: aload_3
    //   38: astore 5
    //   40: new 274	com/sun/mail/util/LineInputStream
    //   43: dup
    //   44: aload_3
    //   45: invokespecial 277	com/sun/mail/util/LineInputStream:<init>	(Ljava/io/InputStream;)V
    //   48: astore 6
    //   50: aload 6
    //   52: invokevirtual 280	com/sun/mail/util/LineInputStream:readLine	()Ljava/lang/String;
    //   55: astore 4
    //   57: aload 4
    //   59: ifnonnull +26 -> 85
    //   62: aload 6
    //   64: ifnull +8 -> 72
    //   67: aload 6
    //   69: invokevirtual 282	com/sun/mail/util/LineInputStream:close	()V
    //   72: aload_3
    //   73: ifnull +181 -> 254
    //   76: aload_3
    //   77: invokevirtual 285	java/io/InputStream:close	()V
    //   80: aload_0
    //   81: monitorexit
    //   82: aload 9
    //   84: areturn
    //   85: new 287	java/util/StringTokenizer
    //   88: dup
    //   89: aload 4
    //   91: invokespecial 288	java/util/StringTokenizer:<init>	(Ljava/lang/String;)V
    //   94: astore 4
    //   96: aload 4
    //   98: invokevirtual 291	java/util/StringTokenizer:nextToken	()Ljava/lang/String;
    //   101: invokestatic 295	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   104: istore_1
    //   105: aload 4
    //   107: invokevirtual 291	java/util/StringTokenizer:nextToken	()Ljava/lang/String;
    //   110: invokestatic 295	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   113: istore_2
    //   114: iload_1
    //   115: ifle -65 -> 50
    //   118: iload_1
    //   119: aload_0
    //   120: getfield 246	com/sun/mail/pop3/POP3Folder:total	I
    //   123: if_icmpgt -73 -> 50
    //   126: aload 9
    //   128: iload_1
    //   129: iconst_1
    //   130: isub
    //   131: iload_2
    //   132: iastore
    //   133: goto -83 -> 50
    //   136: astore 4
    //   138: goto -88 -> 50
    //   141: astore_3
    //   142: aload 8
    //   144: astore 5
    //   146: aload 4
    //   148: astore_3
    //   149: aload 5
    //   151: ifnull +8 -> 159
    //   154: aload 5
    //   156: invokevirtual 282	com/sun/mail/util/LineInputStream:close	()V
    //   159: aload_3
    //   160: ifnull -80 -> 80
    //   163: aload_3
    //   164: invokevirtual 285	java/io/InputStream:close	()V
    //   167: goto -87 -> 80
    //   170: astore_3
    //   171: goto -91 -> 80
    //   174: astore_3
    //   175: aload 7
    //   177: astore 4
    //   179: aload 4
    //   181: ifnull +8 -> 189
    //   184: aload 4
    //   186: invokevirtual 282	com/sun/mail/util/LineInputStream:close	()V
    //   189: aload 5
    //   191: ifnull +8 -> 199
    //   194: aload 5
    //   196: invokevirtual 285	java/io/InputStream:close	()V
    //   199: aload_3
    //   200: athrow
    //   201: astore_3
    //   202: aload_0
    //   203: monitorexit
    //   204: aload_3
    //   205: athrow
    //   206: astore_3
    //   207: goto -127 -> 80
    //   210: astore 4
    //   212: goto -53 -> 159
    //   215: astore 4
    //   217: goto -28 -> 189
    //   220: astore 4
    //   222: goto -23 -> 199
    //   225: astore 4
    //   227: goto -155 -> 72
    //   230: astore 7
    //   232: aload 6
    //   234: astore 4
    //   236: aload_3
    //   237: astore 5
    //   239: aload 7
    //   241: astore_3
    //   242: goto -63 -> 179
    //   245: astore 4
    //   247: aload 6
    //   249: astore 5
    //   251: goto -102 -> 149
    //   254: goto -174 -> 80
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	257	0	this	POP3Folder
    //   104	27	1	i	int
    //   113	19	2	j	int
    //   33	44	3	localInputStream	InputStream
    //   141	1	3	localIOException1	IOException
    //   148	16	3	localException1	Exception
    //   170	1	3	localIOException2	IOException
    //   174	26	3	localObject1	Object
    //   201	4	3	localObject2	Object
    //   206	31	3	localIOException3	IOException
    //   241	1	3	localObject3	Object
    //   18	88	4	localObject4	Object
    //   136	11	4	localException2	Exception
    //   177	8	4	localObject5	Object
    //   210	1	4	localIOException4	IOException
    //   215	1	4	localIOException5	IOException
    //   220	1	4	localIOException6	IOException
    //   225	1	4	localIOException7	IOException
    //   234	1	4	localObject6	Object
    //   245	1	4	localIOException8	IOException
    //   15	235	5	localObject7	Object
    //   48	200	6	localLineInputStream	com.sun.mail.util.LineInputStream
    //   21	155	7	localObject8	Object
    //   230	10	7	localObject9	Object
    //   24	119	8	localObject10	Object
    //   12	115	9	arrayOfInt	int[]
    // Exception table:
    //   from	to	target	type
    //   85	114	136	java/lang/Exception
    //   118	126	136	java/lang/Exception
    //   26	34	141	java/io/IOException
    //   40	50	141	java/io/IOException
    //   163	167	170	java/io/IOException
    //   26	34	174	finally
    //   40	50	174	finally
    //   2	14	201	finally
    //   67	72	201	finally
    //   76	80	201	finally
    //   154	159	201	finally
    //   163	167	201	finally
    //   184	189	201	finally
    //   194	199	201	finally
    //   199	201	201	finally
    //   76	80	206	java/io/IOException
    //   154	159	210	java/io/IOException
    //   184	189	215	java/io/IOException
    //   194	199	220	java/io/IOException
    //   67	72	225	java/io/IOException
    //   50	57	230	finally
    //   85	114	230	finally
    //   118	126	230	finally
    //   50	57	245	java/io/IOException
    //   85	114	245	java/io/IOException
    //   118	126	245	java/io/IOException
  }
  
  public int getType()
  {
    return 1;
  }
  
  /* Error */
  public String getUID(Message paramMessage)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual 76	com/sun/mail/pop3/POP3Folder:checkOpen	()V
    //   6: aload_1
    //   7: checkcast 117	com/sun/mail/pop3/POP3Message
    //   10: astore_1
    //   11: aload_1
    //   12: getfield 226	com/sun/mail/pop3/POP3Message:uid	Ljava/lang/String;
    //   15: ldc_w 300
    //   18: if_acmpne +18 -> 36
    //   21: aload_1
    //   22: aload_0
    //   23: getfield 87	com/sun/mail/pop3/POP3Folder:port	Lcom/sun/mail/pop3/Protocol;
    //   26: aload_1
    //   27: invokevirtual 303	com/sun/mail/pop3/POP3Message:getMessageNumber	()I
    //   30: invokevirtual 306	com/sun/mail/pop3/Protocol:uidl	(I)Ljava/lang/String;
    //   33: putfield 226	com/sun/mail/pop3/POP3Message:uid	Ljava/lang/String;
    //   36: aload_1
    //   37: getfield 226	com/sun/mail/pop3/POP3Message:uid	Ljava/lang/String;
    //   40: astore_1
    //   41: aload_0
    //   42: monitorexit
    //   43: aload_1
    //   44: areturn
    //   45: astore_1
    //   46: aload_0
    //   47: iconst_0
    //   48: invokevirtual 193	com/sun/mail/pop3/POP3Folder:close	(Z)V
    //   51: new 195	javax/mail/FolderClosedException
    //   54: dup
    //   55: aload_0
    //   56: aload_1
    //   57: invokevirtual 199	java/io/EOFException:toString	()Ljava/lang/String;
    //   60: invokespecial 202	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   63: athrow
    //   64: astore_1
    //   65: aload_0
    //   66: monitorexit
    //   67: aload_1
    //   68: athrow
    //   69: astore_1
    //   70: new 43	javax/mail/MessagingException
    //   73: dup
    //   74: ldc -52
    //   76: aload_1
    //   77: invokespecial 136	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   80: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	81	0	this	POP3Folder
    //   0	81	1	paramMessage	Message
    // Exception table:
    //   from	to	target	type
    //   11	36	45	java/io/EOFException
    //   36	41	45	java/io/EOFException
    //   2	11	64	finally
    //   11	36	64	finally
    //   36	41	64	finally
    //   46	64	64	finally
    //   70	81	64	finally
    //   11	36	69	java/io/IOException
    //   36	41	69	java/io/IOException
  }
  
  public boolean hasNewMessages()
    throws MessagingException
  {
    return false;
  }
  
  public boolean isOpen()
  {
    if (!this.opened) {
      return false;
    }
    if (this.store.isConnected()) {
      return true;
    }
    try
    {
      close(false);
      return false;
    }
    catch (MessagingException localMessagingException) {}
    return false;
  }
  
  public Folder[] list(String paramString)
    throws MessagingException
  {
    throw new MessagingException("not a directory");
  }
  
  public InputStream listCommand()
    throws MessagingException, IOException
  {
    try
    {
      checkOpen();
      InputStream localInputStream = this.port.list();
      return localInputStream;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  protected void notifyMessageChangedListeners(int paramInt, Message paramMessage)
  {
    super.notifyMessageChangedListeners(paramInt, paramMessage);
  }
  
  public void open(int paramInt)
    throws MessagingException
  {
    try
    {
      checkClosed();
      if (!this.exists) {
        throw new FolderNotFoundException(this, "folder is not INBOX");
      }
    }
    finally {}
    try
    {
      this.port = ((POP3Store)this.store).getPort(this);
      Status localStatus = this.port.stat();
      this.total = localStatus.total;
      this.size = localStatus.size;
      this.mode = paramInt;
      this.opened = true;
      this.message_cache = new Vector(this.total);
      this.message_cache.setSize(this.total);
      this.doneUidl = false;
      notifyConnectionListeners(1);
      return;
    }
    catch (IOException localIOException1)
    {
      try
      {
        if (this.port != null) {
          this.port.quit();
        }
        this.port = null;
        ((POP3Store)this.store).closePort(this);
      }
      catch (IOException localIOException2)
      {
        for (;;)
        {
          localIOException2 = localIOException2;
          this.port = null;
          ((POP3Store)this.store).closePort(this);
        }
      }
      finally
      {
        localObject2 = finally;
        this.port = null;
        ((POP3Store)this.store).closePort(this);
        throw ((Throwable)localObject2);
      }
      throw new MessagingException("Open failed", localIOException1);
    }
  }
  
  public boolean renameTo(Folder paramFolder)
    throws MessagingException
  {
    throw new MethodNotSupportedException("renameTo");
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/pop3/POP3Folder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */