package com.sun.mail.pop3;

class Status
{
  int size = 0;
  int total = 0;
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/pop3/Status.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */