package com.sun.mail.pop3;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import javax.mail.util.SharedByteArrayInputStream;

class SharedByteArrayOutputStream
  extends ByteArrayOutputStream
{
  public SharedByteArrayOutputStream(int paramInt)
  {
    super(paramInt);
  }
  
  public InputStream toStream()
  {
    return new SharedByteArrayInputStream(this.buf, 0, this.count);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/pop3/SharedByteArrayOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */