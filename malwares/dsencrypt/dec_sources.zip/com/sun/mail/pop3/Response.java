package com.sun.mail.pop3;

import java.io.InputStream;

class Response
{
  InputStream bytes = null;
  String data = null;
  boolean ok = false;
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/pop3/Response.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */