package com.sun.mail.pop3;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.FolderClosedException;
import javax.mail.IllegalWriteException;
import javax.mail.MessageRemovedException;
import javax.mail.MessagingException;
import javax.mail.internet.InternetHeaders;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.SharedInputStream;

public class POP3Message
  extends MimeMessage
{
  static final String UNKNOWN = "UNKNOWN";
  private POP3Folder folder;
  private int hdrSize = -1;
  private int msgSize = -1;
  String uid = "UNKNOWN";
  
  public POP3Message(Folder paramFolder, int paramInt)
    throws MessagingException
  {
    super(paramFolder, paramInt);
    this.folder = ((POP3Folder)paramFolder);
  }
  
  private void loadHeaders()
    throws MessagingException
  {
    for (;;)
    {
      try {}catch (EOFException localEOFException)
      {
        this.folder.close(false);
        throw new FolderClosedException(this.folder, localEOFException.toString());
        this.hdrSize = localEOFException.available();
        this.headers = new InternetHeaders(localEOFException);
        continue;
      }
      catch (IOException localIOException)
      {
        throw new MessagingException("error loading POP3 headers", localIOException);
      }
      try
      {
        if (this.headers != null) {
          return;
        }
        if (!((POP3Store)this.folder.getStore()).disableTop)
        {
          InputStream localInputStream = this.folder.getProtocol().top(this.msgnum, 0);
          if (localInputStream != null) {}
        }
        else
        {
          getContentStream().close();
          return;
        }
      }
      finally {}
    }
  }
  
  public void addHeader(String paramString1, String paramString2)
    throws MessagingException
  {
    throw new IllegalWriteException("POP3 messages are read-only");
  }
  
  public void addHeaderLine(String paramString)
    throws MessagingException
  {
    throw new IllegalWriteException("POP3 messages are read-only");
  }
  
  public Enumeration getAllHeaderLines()
    throws MessagingException
  {
    if (this.headers == null) {
      loadHeaders();
    }
    return this.headers.getAllHeaderLines();
  }
  
  public Enumeration getAllHeaders()
    throws MessagingException
  {
    if (this.headers == null) {
      loadHeaders();
    }
    return this.headers.getAllHeaders();
  }
  
  protected InputStream getContentStream()
    throws MessagingException
  {
    for (;;)
    {
      try {}catch (EOFException localEOFException)
      {
        this.folder.close(false);
        throw new FolderClosedException(this.folder, localEOFException.toString());
        int i = 0;
        continue;
        if ((this.headers != null) && (!((POP3Store)this.folder.getStore()).forgetTopHeaders)) {
          continue;
        }
        this.headers = new InternetHeaders(localEOFException);
        this.hdrSize = ((int)((SharedInputStream)localEOFException).getPosition());
        this.contentStream = ((SharedInputStream)localEOFException).newStream(this.hdrSize, -1L);
        return super.getContentStream();
        i = 0;
        int j = localEOFException.read();
        if (j >= 0) {
          continue;
        }
        if (localEOFException.available() != 0) {
          continue;
        }
        this.hdrSize = ((int)((SharedInputStream)localEOFException).getPosition());
        continue;
        if (j == 10) {
          continue;
        }
        if (j != 13) {
          continue;
        }
        if (localEOFException.available() <= 0) {
          continue;
        }
        localEOFException.mark(1);
        if (localEOFException.read() == 10) {
          continue;
        }
        localEOFException.reset();
        continue;
        i += 1;
        continue;
        if (i != 0) {
          continue;
        }
        continue;
      }
      catch (IOException localIOException)
      {
        throw new MessagingException("error fetching POP3 content", localIOException);
      }
      try
      {
        if (this.contentStream == null)
        {
          Object localObject1 = this.folder.getProtocol();
          j = this.msgnum;
          if (this.msgSize > 0)
          {
            i = this.msgSize + this.hdrSize;
            localObject1 = ((Protocol)localObject1).retr(j, i);
            if (localObject1 != null) {
              continue;
            }
            this.expunged = true;
            throw new MessageRemovedException();
          }
        }
      }
      finally {}
    }
  }
  
  public String getHeader(String paramString1, String paramString2)
    throws MessagingException
  {
    if (this.headers == null) {
      loadHeaders();
    }
    return this.headers.getHeader(paramString1, paramString2);
  }
  
  public String[] getHeader(String paramString)
    throws MessagingException
  {
    if (this.headers == null) {
      loadHeaders();
    }
    return this.headers.getHeader(paramString);
  }
  
  public Enumeration getMatchingHeaderLines(String[] paramArrayOfString)
    throws MessagingException
  {
    if (this.headers == null) {
      loadHeaders();
    }
    return this.headers.getMatchingHeaderLines(paramArrayOfString);
  }
  
  public Enumeration getMatchingHeaders(String[] paramArrayOfString)
    throws MessagingException
  {
    if (this.headers == null) {
      loadHeaders();
    }
    return this.headers.getMatchingHeaders(paramArrayOfString);
  }
  
  public Enumeration getNonMatchingHeaderLines(String[] paramArrayOfString)
    throws MessagingException
  {
    if (this.headers == null) {
      loadHeaders();
    }
    return this.headers.getNonMatchingHeaderLines(paramArrayOfString);
  }
  
  public Enumeration getNonMatchingHeaders(String[] paramArrayOfString)
    throws MessagingException
  {
    if (this.headers == null) {
      loadHeaders();
    }
    return this.headers.getNonMatchingHeaders(paramArrayOfString);
  }
  
  public int getSize()
    throws MessagingException
  {
    for (;;)
    {
      try {}catch (EOFException localEOFException)
      {
        int i;
        this.folder.close(false);
        throw new FolderClosedException(this.folder, localEOFException.toString());
        this.msgSize = (this.folder.getProtocol().list(this.msgnum) - this.hdrSize);
        continue;
      }
      catch (IOException localIOException)
      {
        throw new MessagingException("error getting size", localIOException);
      }
      try
      {
        if (this.msgSize >= 0)
        {
          i = this.msgSize;
          return i;
        }
        if (this.msgSize < 0)
        {
          if (this.headers == null) {
            loadHeaders();
          }
          if (this.contentStream != null) {
            this.msgSize = this.contentStream.available();
          }
        }
        else
        {
          i = this.msgSize;
          return i;
        }
      }
      finally {}
    }
  }
  
  public void invalidate(boolean paramBoolean)
  {
    try
    {
      this.content = null;
      this.contentStream = null;
      this.msgSize = -1;
      if (paramBoolean)
      {
        this.headers = null;
        this.hdrSize = -1;
      }
      return;
    }
    finally {}
  }
  
  public void removeHeader(String paramString)
    throws MessagingException
  {
    throw new IllegalWriteException("POP3 messages are read-only");
  }
  
  public void saveChanges()
    throws MessagingException
  {
    throw new IllegalWriteException("POP3 messages are read-only");
  }
  
  public void setFlags(Flags paramFlags, boolean paramBoolean)
    throws MessagingException
  {
    Flags localFlags = (Flags)this.flags.clone();
    super.setFlags(paramFlags, paramBoolean);
    if (!this.flags.equals(localFlags)) {
      this.folder.notifyMessageChangedListeners(1, this);
    }
  }
  
  public void setHeader(String paramString1, String paramString2)
    throws MessagingException
  {
    throw new IllegalWriteException("POP3 messages are read-only");
  }
  
  /* Error */
  public InputStream top(int paramInt)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 29	com/sun/mail/pop3/POP3Message:folder	Lcom/sun/mail/pop3/POP3Folder;
    //   6: invokevirtual 55	com/sun/mail/pop3/POP3Folder:getProtocol	()Lcom/sun/mail/pop3/Protocol;
    //   9: aload_0
    //   10: getfield 58	com/sun/mail/pop3/POP3Message:msgnum	I
    //   13: iload_1
    //   14: invokevirtual 64	com/sun/mail/pop3/Protocol:top	(II)Ljava/io/InputStream;
    //   17: astore_2
    //   18: aload_0
    //   19: monitorexit
    //   20: aload_2
    //   21: areturn
    //   22: astore_2
    //   23: aload_0
    //   24: monitorexit
    //   25: aload_2
    //   26: athrow
    //   27: astore_2
    //   28: aload_0
    //   29: getfield 29	com/sun/mail/pop3/POP3Message:folder	Lcom/sun/mail/pop3/POP3Folder;
    //   32: iconst_0
    //   33: invokevirtual 76	com/sun/mail/pop3/POP3Folder:close	(Z)V
    //   36: new 78	javax/mail/FolderClosedException
    //   39: dup
    //   40: aload_0
    //   41: getfield 29	com/sun/mail/pop3/POP3Message:folder	Lcom/sun/mail/pop3/POP3Folder;
    //   44: aload_2
    //   45: invokevirtual 82	java/io/EOFException:toString	()Ljava/lang/String;
    //   48: invokespecial 85	javax/mail/FolderClosedException:<init>	(Ljavax/mail/Folder;Ljava/lang/String;)V
    //   51: athrow
    //   52: astore_2
    //   53: new 17	javax/mail/MessagingException
    //   56: dup
    //   57: ldc -69
    //   59: aload_2
    //   60: invokespecial 99	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   63: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	64	0	this	POP3Message
    //   0	64	1	paramInt	int
    //   17	4	2	localInputStream	InputStream
    //   22	4	2	localObject	Object
    //   27	18	2	localEOFException	EOFException
    //   52	8	2	localIOException	IOException
    // Exception table:
    //   from	to	target	type
    //   2	20	22	finally
    //   23	25	22	finally
    //   0	2	27	java/io/EOFException
    //   25	27	27	java/io/EOFException
    //   0	2	52	java/io/IOException
    //   25	27	52	java/io/IOException
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/pop3/POP3Message.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */