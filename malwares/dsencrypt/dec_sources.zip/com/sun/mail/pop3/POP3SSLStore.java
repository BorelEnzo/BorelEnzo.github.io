package com.sun.mail.pop3;

import javax.mail.Session;
import javax.mail.URLName;

public class POP3SSLStore
  extends POP3Store
{
  public POP3SSLStore(Session paramSession, URLName paramURLName)
  {
    super(paramSession, paramURLName, "pop3s", 995, true);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/pop3/POP3SSLStore.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */