package com.sun.mail.pop3;

import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.Socket;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

class Protocol
{
  private static final String CRLF = "\r\n";
  private static final int POP3_PORT = 110;
  private static char[] digits = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102 };
  private String apopChallenge;
  private boolean debug;
  private DataInputStream input;
  private PrintStream out;
  private PrintWriter output;
  private Socket socket;
  
  /* Error */
  Protocol(String paramString1, int paramInt, boolean paramBoolean1, PrintStream paramPrintStream, java.util.Properties paramProperties, String paramString2, boolean paramBoolean2)
    throws IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial 51	java/lang/Object:<init>	()V
    //   4: aload_0
    //   5: iconst_0
    //   6: putfield 53	com/sun/mail/pop3/Protocol:debug	Z
    //   9: aload_0
    //   10: aconst_null
    //   11: putfield 55	com/sun/mail/pop3/Protocol:apopChallenge	Ljava/lang/String;
    //   14: aload_0
    //   15: iload_3
    //   16: putfield 53	com/sun/mail/pop3/Protocol:debug	Z
    //   19: aload_0
    //   20: aload 4
    //   22: putfield 57	com/sun/mail/pop3/Protocol:out	Ljava/io/PrintStream;
    //   25: aload 5
    //   27: new 59	java/lang/StringBuilder
    //   30: dup
    //   31: aload 6
    //   33: invokestatic 65	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   36: invokespecial 68	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   39: ldc 70
    //   41: invokevirtual 74	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   44: invokevirtual 78	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   47: invokevirtual 84	java/util/Properties:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   50: astore 10
    //   52: aload 10
    //   54: ifnull +178 -> 232
    //   57: aload 10
    //   59: ldc 86
    //   61: invokevirtual 90	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   64: ifeq +168 -> 232
    //   67: iconst_1
    //   68: istore 8
    //   70: iload_2
    //   71: istore 9
    //   73: iload_2
    //   74: iconst_m1
    //   75: if_icmpne +7 -> 82
    //   78: bipush 110
    //   80: istore 9
    //   82: iload_3
    //   83: ifeq +44 -> 127
    //   86: aload 4
    //   88: new 59	java/lang/StringBuilder
    //   91: dup
    //   92: ldc 92
    //   94: invokespecial 68	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   97: aload_1
    //   98: invokevirtual 74	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   101: ldc 94
    //   103: invokevirtual 74	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   106: iload 9
    //   108: invokevirtual 97	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   111: ldc 99
    //   113: invokevirtual 74	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   116: iload 7
    //   118: invokevirtual 102	java/lang/StringBuilder:append	(Z)Ljava/lang/StringBuilder;
    //   121: invokevirtual 78	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   124: invokevirtual 107	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   127: aload_0
    //   128: aload_1
    //   129: iload 9
    //   131: aload 5
    //   133: aload 6
    //   135: iload 7
    //   137: invokestatic 113	com/sun/mail/util/SocketFetcher:getSocket	(Ljava/lang/String;ILjava/util/Properties;Ljava/lang/String;Z)Ljava/net/Socket;
    //   140: putfield 115	com/sun/mail/pop3/Protocol:socket	Ljava/net/Socket;
    //   143: aload_0
    //   144: new 117	java/io/DataInputStream
    //   147: dup
    //   148: new 119	java/io/BufferedInputStream
    //   151: dup
    //   152: aload_0
    //   153: getfield 115	com/sun/mail/pop3/Protocol:socket	Ljava/net/Socket;
    //   156: invokevirtual 125	java/net/Socket:getInputStream	()Ljava/io/InputStream;
    //   159: invokespecial 128	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
    //   162: invokespecial 129	java/io/DataInputStream:<init>	(Ljava/io/InputStream;)V
    //   165: putfield 131	com/sun/mail/pop3/Protocol:input	Ljava/io/DataInputStream;
    //   168: aload_0
    //   169: new 133	java/io/PrintWriter
    //   172: dup
    //   173: new 135	java/io/BufferedWriter
    //   176: dup
    //   177: new 137	java/io/OutputStreamWriter
    //   180: dup
    //   181: aload_0
    //   182: getfield 115	com/sun/mail/pop3/Protocol:socket	Ljava/net/Socket;
    //   185: invokevirtual 141	java/net/Socket:getOutputStream	()Ljava/io/OutputStream;
    //   188: ldc -113
    //   190: invokespecial 146	java/io/OutputStreamWriter:<init>	(Ljava/io/OutputStream;Ljava/lang/String;)V
    //   193: invokespecial 149	java/io/BufferedWriter:<init>	(Ljava/io/Writer;)V
    //   196: invokespecial 150	java/io/PrintWriter:<init>	(Ljava/io/Writer;)V
    //   199: putfield 152	com/sun/mail/pop3/Protocol:output	Ljava/io/PrintWriter;
    //   202: aload_0
    //   203: aconst_null
    //   204: invokespecial 156	com/sun/mail/pop3/Protocol:simpleCommand	(Ljava/lang/String;)Lcom/sun/mail/pop3/Response;
    //   207: astore_1
    //   208: aload_1
    //   209: getfield 161	com/sun/mail/pop3/Response:ok	Z
    //   212: ifne +36 -> 248
    //   215: aload_0
    //   216: getfield 115	com/sun/mail/pop3/Protocol:socket	Ljava/net/Socket;
    //   219: invokevirtual 164	java/net/Socket:close	()V
    //   222: new 49	java/io/IOException
    //   225: dup
    //   226: ldc -90
    //   228: invokespecial 167	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   231: athrow
    //   232: iconst_0
    //   233: istore 8
    //   235: goto -165 -> 70
    //   238: astore_1
    //   239: aload_0
    //   240: getfield 115	com/sun/mail/pop3/Protocol:socket	Ljava/net/Socket;
    //   243: invokevirtual 164	java/net/Socket:close	()V
    //   246: aload_1
    //   247: athrow
    //   248: iload 8
    //   250: ifeq +80 -> 330
    //   253: aload_1
    //   254: getfield 170	com/sun/mail/pop3/Response:data	Ljava/lang/String;
    //   257: bipush 60
    //   259: invokevirtual 174	java/lang/String:indexOf	(I)I
    //   262: istore_2
    //   263: aload_1
    //   264: getfield 170	com/sun/mail/pop3/Response:data	Ljava/lang/String;
    //   267: bipush 62
    //   269: iload_2
    //   270: invokevirtual 177	java/lang/String:indexOf	(II)I
    //   273: istore 8
    //   275: iload_2
    //   276: iconst_m1
    //   277: if_icmpeq +25 -> 302
    //   280: iload 8
    //   282: iconst_m1
    //   283: if_icmpeq +19 -> 302
    //   286: aload_0
    //   287: aload_1
    //   288: getfield 170	com/sun/mail/pop3/Response:data	Ljava/lang/String;
    //   291: iload_2
    //   292: iload 8
    //   294: iconst_1
    //   295: iadd
    //   296: invokevirtual 181	java/lang/String:substring	(II)Ljava/lang/String;
    //   299: putfield 55	com/sun/mail/pop3/Protocol:apopChallenge	Ljava/lang/String;
    //   302: iload_3
    //   303: ifeq +27 -> 330
    //   306: aload 4
    //   308: new 59	java/lang/StringBuilder
    //   311: dup
    //   312: ldc -73
    //   314: invokespecial 68	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   317: aload_0
    //   318: getfield 55	com/sun/mail/pop3/Protocol:apopChallenge	Ljava/lang/String;
    //   321: invokevirtual 74	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   324: invokevirtual 78	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   327: invokevirtual 107	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   330: return
    //   331: astore_1
    //   332: goto -110 -> 222
    //   335: astore 4
    //   337: goto -91 -> 246
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	340	0	this	Protocol
    //   0	340	1	paramString1	String
    //   0	340	2	paramInt	int
    //   0	340	3	paramBoolean1	boolean
    //   0	340	4	paramPrintStream	PrintStream
    //   0	340	5	paramProperties	java.util.Properties
    //   0	340	6	paramString2	String
    //   0	340	7	paramBoolean2	boolean
    //   68	228	8	i	int
    //   71	59	9	j	int
    //   50	8	10	str	String
    // Exception table:
    //   from	to	target	type
    //   86	127	238	java/io/IOException
    //   127	208	238	java/io/IOException
    //   215	222	331	finally
    //   239	246	335	finally
  }
  
  private String getDigest(String paramString)
  {
    paramString = this.apopChallenge + paramString;
    try
    {
      paramString = MessageDigest.getInstance("MD5").digest(paramString.getBytes("iso-8859-1"));
      return toHex(paramString);
    }
    catch (NoSuchAlgorithmException paramString)
    {
      return null;
    }
    catch (UnsupportedEncodingException paramString) {}
    return null;
  }
  
  private Response multilineCommand(String paramString, int paramInt)
    throws IOException
  {
    paramString = simpleCommand(paramString);
    if (!paramString.ok) {
      return paramString;
    }
    SharedByteArrayOutputStream localSharedByteArrayOutputStream = new SharedByteArrayOutputStream(paramInt);
    for (int i = 10;; i = paramInt)
    {
      int j = this.input.read();
      if (j < 0) {}
      for (;;)
      {
        if (j >= 0) {
          break label181;
        }
        throw new EOFException("EOF on socket");
        paramInt = j;
        if (i != 10) {
          break;
        }
        paramInt = j;
        if (j != 46) {
          break;
        }
        if (this.debug) {
          this.out.write(j);
        }
        i = this.input.read();
        paramInt = i;
        if (i != 13) {
          break;
        }
        if (this.debug) {
          this.out.write(i);
        }
        paramInt = this.input.read();
        j = paramInt;
        if (this.debug)
        {
          this.out.write(paramInt);
          j = paramInt;
        }
      }
      localSharedByteArrayOutputStream.write(paramInt);
      if (this.debug) {
        this.out.write(paramInt);
      }
    }
    label181:
    paramString.bytes = localSharedByteArrayOutputStream.toStream();
    return paramString;
  }
  
  private Response simpleCommand(String paramString)
    throws IOException
  {
    if (this.socket == null) {
      throw new IOException("Folder is closed");
    }
    if (paramString != null)
    {
      if (this.debug) {
        this.out.println("C: " + paramString);
      }
      paramString = paramString + "\r\n";
      this.output.print(paramString);
      this.output.flush();
    }
    paramString = this.input.readLine();
    if (paramString == null)
    {
      if (this.debug) {
        this.out.println("S: EOF");
      }
      throw new EOFException("EOF on socket");
    }
    if (this.debug) {
      this.out.println("S: " + paramString);
    }
    Response localResponse = new Response();
    if (paramString.startsWith("+OK")) {}
    for (localResponse.ok = true;; localResponse.ok = false)
    {
      int i = paramString.indexOf(' ');
      if (i >= 0) {
        localResponse.data = paramString.substring(i + 1);
      }
      return localResponse;
      if (!paramString.startsWith("-ERR")) {
        break;
      }
    }
    throw new IOException("Unexpected response: " + paramString);
  }
  
  private static String toHex(byte[] paramArrayOfByte)
  {
    char[] arrayOfChar = new char[paramArrayOfByte.length * 2];
    int i = 0;
    int j = 0;
    for (;;)
    {
      if (i >= paramArrayOfByte.length) {
        return new String(arrayOfChar);
      }
      int k = paramArrayOfByte[i] & 0xFF;
      int m = j + 1;
      arrayOfChar[j] = digits[(k >> 4)];
      j = m + 1;
      arrayOfChar[m] = digits[(k & 0xF)];
      i += 1;
    }
  }
  
  boolean dele(int paramInt)
    throws IOException
  {
    try
    {
      boolean bool = simpleCommand("DELE " + paramInt).ok;
      return bool;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  protected void finalize()
    throws Throwable
  {
    super.finalize();
    if (this.socket != null) {
      quit();
    }
  }
  
  /* Error */
  int list(int paramInt)
    throws IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: new 59	java/lang/StringBuilder
    //   6: dup
    //   7: ldc_w 287
    //   10: invokespecial 68	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   13: iload_1
    //   14: invokevirtual 97	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   17: invokevirtual 78	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   20: invokespecial 156	com/sun/mail/pop3/Protocol:simpleCommand	(Ljava/lang/String;)Lcom/sun/mail/pop3/Response;
    //   23: astore_3
    //   24: iconst_m1
    //   25: istore_2
    //   26: iload_2
    //   27: istore_1
    //   28: aload_3
    //   29: getfield 161	com/sun/mail/pop3/Response:ok	Z
    //   32: ifeq +41 -> 73
    //   35: aload_3
    //   36: getfield 170	com/sun/mail/pop3/Response:data	Ljava/lang/String;
    //   39: astore 4
    //   41: iload_2
    //   42: istore_1
    //   43: aload 4
    //   45: ifnull +28 -> 73
    //   48: new 289	java/util/StringTokenizer
    //   51: dup
    //   52: aload_3
    //   53: getfield 170	com/sun/mail/pop3/Response:data	Ljava/lang/String;
    //   56: invokespecial 290	java/util/StringTokenizer:<init>	(Ljava/lang/String;)V
    //   59: astore_3
    //   60: aload_3
    //   61: invokevirtual 293	java/util/StringTokenizer:nextToken	()Ljava/lang/String;
    //   64: pop
    //   65: aload_3
    //   66: invokevirtual 293	java/util/StringTokenizer:nextToken	()Ljava/lang/String;
    //   69: invokestatic 299	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   72: istore_1
    //   73: aload_0
    //   74: monitorexit
    //   75: iload_1
    //   76: ireturn
    //   77: astore_3
    //   78: aload_0
    //   79: monitorexit
    //   80: aload_3
    //   81: athrow
    //   82: astore_3
    //   83: iload_2
    //   84: istore_1
    //   85: goto -12 -> 73
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	88	0	this	Protocol
    //   0	88	1	paramInt	int
    //   25	59	2	i	int
    //   23	43	3	localObject1	Object
    //   77	4	3	localObject2	Object
    //   82	1	3	localException	Exception
    //   39	5	4	str	String
    // Exception table:
    //   from	to	target	type
    //   2	24	77	finally
    //   28	41	77	finally
    //   48	73	77	finally
    //   48	73	82	java/lang/Exception
  }
  
  InputStream list()
    throws IOException
  {
    try
    {
      InputStream localInputStream = multilineCommand("LIST", 128).bytes;
      return localInputStream;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  String login(String paramString1, String paramString2)
    throws IOException
  {
    String str = null;
    label169:
    for (;;)
    {
      try
      {
        if (this.apopChallenge != null) {
          str = getDigest(paramString2);
        }
        if ((this.apopChallenge != null) && (str != null))
        {
          paramString1 = simpleCommand("APOP " + paramString1 + " " + str);
          if (paramString1.ok) {
            continue;
          }
          if (paramString1.data != null)
          {
            paramString1 = paramString1.data;
            return paramString1;
          }
        }
        else
        {
          paramString1 = simpleCommand("USER " + paramString1);
          if (!paramString1.ok)
          {
            if (paramString1.data == null) {
              break label169;
            }
            paramString1 = paramString1.data;
            continue;
          }
          paramString1 = simpleCommand("PASS " + paramString2);
          continue;
        }
        paramString1 = "login failed";
        continue;
        paramString1 = null;
        continue;
        paramString1 = "USER command failed";
      }
      finally {}
    }
  }
  
  boolean noop()
    throws IOException
  {
    try
    {
      boolean bool = simpleCommand("NOOP").ok;
      return bool;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  /* Error */
  boolean quit()
    throws IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc_w 324
    //   6: invokespecial 156	com/sun/mail/pop3/Protocol:simpleCommand	(Ljava/lang/String;)Lcom/sun/mail/pop3/Response;
    //   9: getfield 161	com/sun/mail/pop3/Response:ok	Z
    //   12: istore_1
    //   13: aload_0
    //   14: getfield 115	com/sun/mail/pop3/Protocol:socket	Ljava/net/Socket;
    //   17: invokevirtual 164	java/net/Socket:close	()V
    //   20: aload_0
    //   21: aconst_null
    //   22: putfield 115	com/sun/mail/pop3/Protocol:socket	Ljava/net/Socket;
    //   25: aload_0
    //   26: aconst_null
    //   27: putfield 131	com/sun/mail/pop3/Protocol:input	Ljava/io/DataInputStream;
    //   30: aload_0
    //   31: aconst_null
    //   32: putfield 152	com/sun/mail/pop3/Protocol:output	Ljava/io/PrintWriter;
    //   35: aload_0
    //   36: monitorexit
    //   37: iload_1
    //   38: ireturn
    //   39: astore_2
    //   40: aload_0
    //   41: getfield 115	com/sun/mail/pop3/Protocol:socket	Ljava/net/Socket;
    //   44: invokevirtual 164	java/net/Socket:close	()V
    //   47: aload_0
    //   48: aconst_null
    //   49: putfield 115	com/sun/mail/pop3/Protocol:socket	Ljava/net/Socket;
    //   52: aload_0
    //   53: aconst_null
    //   54: putfield 131	com/sun/mail/pop3/Protocol:input	Ljava/io/DataInputStream;
    //   57: aload_0
    //   58: aconst_null
    //   59: putfield 152	com/sun/mail/pop3/Protocol:output	Ljava/io/PrintWriter;
    //   62: aload_2
    //   63: athrow
    //   64: astore_2
    //   65: aload_0
    //   66: monitorexit
    //   67: aload_2
    //   68: athrow
    //   69: astore_2
    //   70: aload_0
    //   71: aconst_null
    //   72: putfield 115	com/sun/mail/pop3/Protocol:socket	Ljava/net/Socket;
    //   75: aload_0
    //   76: aconst_null
    //   77: putfield 131	com/sun/mail/pop3/Protocol:input	Ljava/io/DataInputStream;
    //   80: aload_0
    //   81: aconst_null
    //   82: putfield 152	com/sun/mail/pop3/Protocol:output	Ljava/io/PrintWriter;
    //   85: aload_2
    //   86: athrow
    //   87: astore_2
    //   88: aload_0
    //   89: aconst_null
    //   90: putfield 115	com/sun/mail/pop3/Protocol:socket	Ljava/net/Socket;
    //   93: aload_0
    //   94: aconst_null
    //   95: putfield 131	com/sun/mail/pop3/Protocol:input	Ljava/io/DataInputStream;
    //   98: aload_0
    //   99: aconst_null
    //   100: putfield 152	com/sun/mail/pop3/Protocol:output	Ljava/io/PrintWriter;
    //   103: aload_2
    //   104: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	105	0	this	Protocol
    //   12	26	1	bool	boolean
    //   39	24	2	localObject1	Object
    //   64	4	2	localObject2	Object
    //   69	17	2	localObject3	Object
    //   87	17	2	localObject4	Object
    // Exception table:
    //   from	to	target	type
    //   2	13	39	finally
    //   20	35	64	finally
    //   47	64	64	finally
    //   70	87	64	finally
    //   88	105	64	finally
    //   40	47	69	finally
    //   13	20	87	finally
  }
  
  InputStream retr(int paramInt1, int paramInt2)
    throws IOException
  {
    try
    {
      InputStream localInputStream = multilineCommand("RETR " + paramInt1, paramInt2).bytes;
      return localInputStream;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  boolean rset()
    throws IOException
  {
    try
    {
      boolean bool = simpleCommand("RSET").ok;
      return bool;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  /* Error */
  Status stat()
    throws IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: ldc_w 335
    //   6: invokespecial 156	com/sun/mail/pop3/Protocol:simpleCommand	(Ljava/lang/String;)Lcom/sun/mail/pop3/Response;
    //   9: astore_2
    //   10: new 337	com/sun/mail/pop3/Status
    //   13: dup
    //   14: invokespecial 338	com/sun/mail/pop3/Status:<init>	()V
    //   17: astore_1
    //   18: aload_2
    //   19: getfield 161	com/sun/mail/pop3/Response:ok	Z
    //   22: ifeq +46 -> 68
    //   25: aload_2
    //   26: getfield 170	com/sun/mail/pop3/Response:data	Ljava/lang/String;
    //   29: astore_3
    //   30: aload_3
    //   31: ifnull +37 -> 68
    //   34: new 289	java/util/StringTokenizer
    //   37: dup
    //   38: aload_2
    //   39: getfield 170	com/sun/mail/pop3/Response:data	Ljava/lang/String;
    //   42: invokespecial 290	java/util/StringTokenizer:<init>	(Ljava/lang/String;)V
    //   45: astore_2
    //   46: aload_1
    //   47: aload_2
    //   48: invokevirtual 293	java/util/StringTokenizer:nextToken	()Ljava/lang/String;
    //   51: invokestatic 299	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   54: putfield 341	com/sun/mail/pop3/Status:total	I
    //   57: aload_1
    //   58: aload_2
    //   59: invokevirtual 293	java/util/StringTokenizer:nextToken	()Ljava/lang/String;
    //   62: invokestatic 299	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   65: putfield 344	com/sun/mail/pop3/Status:size	I
    //   68: aload_0
    //   69: monitorexit
    //   70: aload_1
    //   71: areturn
    //   72: astore_1
    //   73: aload_0
    //   74: monitorexit
    //   75: aload_1
    //   76: athrow
    //   77: astore_2
    //   78: goto -10 -> 68
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	81	0	this	Protocol
    //   17	54	1	localStatus	Status
    //   72	4	1	localObject1	Object
    //   9	50	2	localObject2	Object
    //   77	1	2	localException	Exception
    //   29	2	3	str	String
    // Exception table:
    //   from	to	target	type
    //   2	30	72	finally
    //   34	68	72	finally
    //   34	68	77	java/lang/Exception
  }
  
  InputStream top(int paramInt1, int paramInt2)
    throws IOException
  {
    try
    {
      InputStream localInputStream = multilineCommand("TOP " + paramInt1 + " " + paramInt2, 0).bytes;
      return localInputStream;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  /* Error */
  String uidl(int paramInt)
    throws IOException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: new 59	java/lang/StringBuilder
    //   8: dup
    //   9: ldc_w 350
    //   12: invokespecial 68	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   15: iload_1
    //   16: invokevirtual 97	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   19: invokevirtual 78	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   22: invokespecial 156	com/sun/mail/pop3/Protocol:simpleCommand	(Ljava/lang/String;)Lcom/sun/mail/pop3/Response;
    //   25: astore 4
    //   27: aload 4
    //   29: getfield 161	com/sun/mail/pop3/Response:ok	Z
    //   32: istore_2
    //   33: iload_2
    //   34: ifne +7 -> 41
    //   37: aload_0
    //   38: monitorexit
    //   39: aload_3
    //   40: areturn
    //   41: aload 4
    //   43: getfield 170	com/sun/mail/pop3/Response:data	Ljava/lang/String;
    //   46: bipush 32
    //   48: invokevirtual 174	java/lang/String:indexOf	(I)I
    //   51: istore_1
    //   52: iload_1
    //   53: ifle -16 -> 37
    //   56: aload 4
    //   58: getfield 170	com/sun/mail/pop3/Response:data	Ljava/lang/String;
    //   61: iload_1
    //   62: iconst_1
    //   63: iadd
    //   64: invokevirtual 262	java/lang/String:substring	(I)Ljava/lang/String;
    //   67: astore_3
    //   68: goto -31 -> 37
    //   71: astore_3
    //   72: aload_0
    //   73: monitorexit
    //   74: aload_3
    //   75: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	76	0	this	Protocol
    //   0	76	1	paramInt	int
    //   32	2	2	bool	boolean
    //   1	67	3	str	String
    //   71	4	3	localObject	Object
    //   25	32	4	localResponse	Response
    // Exception table:
    //   from	to	target	type
    //   4	33	71	finally
    //   41	52	71	finally
    //   56	68	71	finally
  }
  
  /* Error */
  boolean uidl(String[] paramArrayOfString)
    throws IOException
  {
    // Byte code:
    //   0: iconst_0
    //   1: istore 4
    //   3: aload_0
    //   4: monitorenter
    //   5: aload_0
    //   6: ldc_w 353
    //   9: aload_1
    //   10: arraylength
    //   11: bipush 15
    //   13: imul
    //   14: invokespecial 303	com/sun/mail/pop3/Protocol:multilineCommand	(Ljava/lang/String;I)Lcom/sun/mail/pop3/Response;
    //   17: astore 6
    //   19: aload 6
    //   21: getfield 161	com/sun/mail/pop3/Response:ok	Z
    //   24: istore 5
    //   26: iload 5
    //   28: ifne +8 -> 36
    //   31: aload_0
    //   32: monitorexit
    //   33: iload 4
    //   35: ireturn
    //   36: new 355	com/sun/mail/util/LineInputStream
    //   39: dup
    //   40: aload 6
    //   42: getfield 236	com/sun/mail/pop3/Response:bytes	Ljava/io/InputStream;
    //   45: invokespecial 356	com/sun/mail/util/LineInputStream:<init>	(Ljava/io/InputStream;)V
    //   48: astore 6
    //   50: aload 6
    //   52: invokevirtual 357	com/sun/mail/util/LineInputStream:readLine	()Ljava/lang/String;
    //   55: astore 7
    //   57: aload 7
    //   59: ifnonnull +9 -> 68
    //   62: iconst_1
    //   63: istore 4
    //   65: goto -34 -> 31
    //   68: aload 7
    //   70: bipush 32
    //   72: invokevirtual 174	java/lang/String:indexOf	(I)I
    //   75: istore_2
    //   76: iload_2
    //   77: iconst_1
    //   78: if_icmplt -28 -> 50
    //   81: iload_2
    //   82: aload 7
    //   84: invokevirtual 360	java/lang/String:length	()I
    //   87: if_icmpge -37 -> 50
    //   90: aload 7
    //   92: iconst_0
    //   93: iload_2
    //   94: invokevirtual 181	java/lang/String:substring	(II)Ljava/lang/String;
    //   97: invokestatic 299	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   100: istore_3
    //   101: iload_3
    //   102: ifle -52 -> 50
    //   105: iload_3
    //   106: aload_1
    //   107: arraylength
    //   108: if_icmpgt -58 -> 50
    //   111: aload_1
    //   112: iload_3
    //   113: iconst_1
    //   114: isub
    //   115: aload 7
    //   117: iload_2
    //   118: iconst_1
    //   119: iadd
    //   120: invokevirtual 262	java/lang/String:substring	(I)Ljava/lang/String;
    //   123: aastore
    //   124: goto -74 -> 50
    //   127: astore_1
    //   128: aload_0
    //   129: monitorexit
    //   130: aload_1
    //   131: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	132	0	this	Protocol
    //   0	132	1	paramArrayOfString	String[]
    //   75	45	2	i	int
    //   100	15	3	j	int
    //   1	63	4	bool1	boolean
    //   24	3	5	bool2	boolean
    //   17	34	6	localObject	Object
    //   55	61	7	str	String
    // Exception table:
    //   from	to	target	type
    //   5	26	127	finally
    //   36	50	127	finally
    //   50	57	127	finally
    //   68	76	127	finally
    //   81	101	127	finally
    //   105	124	127	finally
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/pop3/Protocol.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */