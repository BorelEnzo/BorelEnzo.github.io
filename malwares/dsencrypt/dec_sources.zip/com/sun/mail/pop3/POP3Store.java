package com.sun.mail.pop3;

import java.io.PrintStream;
import java.lang.reflect.Constructor;
import javax.mail.Folder;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.URLName;

public class POP3Store
  extends Store
{
  private int defaultPort = 110;
  boolean disableTop = false;
  boolean forgetTopHeaders = false;
  private String host = null;
  private boolean isSSL = false;
  Constructor messageConstructor = null;
  private String name = "pop3";
  private String passwd = null;
  private Protocol port = null;
  private int portNum = -1;
  private POP3Folder portOwner = null;
  boolean rsetBeforeQuit = false;
  private String user = null;
  
  public POP3Store(Session paramSession, URLName paramURLName)
  {
    this(paramSession, paramURLName, "pop3", 110, false);
  }
  
  public POP3Store(Session paramSession, URLName paramURLName, String paramString, int paramInt, boolean paramBoolean)
  {
    super(paramSession, paramURLName);
    if (paramURLName != null) {
      paramString = paramURLName.getProtocol();
    }
    this.name = paramString;
    this.defaultPort = paramInt;
    this.isSSL = paramBoolean;
    paramURLName = paramSession.getProperty("mail." + paramString + ".rsetbeforequit");
    if ((paramURLName != null) && (paramURLName.equalsIgnoreCase("true"))) {
      this.rsetBeforeQuit = true;
    }
    paramURLName = paramSession.getProperty("mail." + paramString + ".disabletop");
    if ((paramURLName != null) && (paramURLName.equalsIgnoreCase("true"))) {
      this.disableTop = true;
    }
    paramURLName = paramSession.getProperty("mail." + paramString + ".forgettopheaders");
    if ((paramURLName != null) && (paramURLName.equalsIgnoreCase("true"))) {
      this.forgetTopHeaders = true;
    }
    paramString = paramSession.getProperty("mail." + paramString + ".message.class");
    if (paramString != null)
    {
      if (paramSession.getDebug()) {
        paramSession.getDebugOut().println("DEBUG: POP3 message class: " + paramString);
      }
      try
      {
        paramURLName = getClass().getClassLoader();
        try
        {
          paramURLName = paramURLName.loadClass(paramString);
          this.messageConstructor = paramURLName.getConstructor(new Class[] { Folder.class, Integer.TYPE });
          return;
        }
        catch (ClassNotFoundException paramURLName)
        {
          for (;;)
          {
            paramURLName = Class.forName(paramString);
          }
        }
        return;
      }
      catch (Exception paramURLName)
      {
        if (paramSession.getDebug()) {
          paramSession.getDebugOut().println("DEBUG: failed to load POP3 message class: " + paramURLName);
        }
      }
    }
  }
  
  private void checkConnected()
    throws MessagingException
  {
    if (!super.isConnected()) {
      throw new MessagingException("Not connected");
    }
  }
  
  /* Error */
  public void close()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 45	com/sun/mail/pop3/POP3Store:port	Lcom/sun/mail/pop3/Protocol;
    //   6: ifnull +11 -> 17
    //   9: aload_0
    //   10: getfield 45	com/sun/mail/pop3/POP3Store:port	Lcom/sun/mail/pop3/Protocol;
    //   13: invokevirtual 177	com/sun/mail/pop3/Protocol:quit	()Z
    //   16: pop
    //   17: aload_0
    //   18: aconst_null
    //   19: putfield 45	com/sun/mail/pop3/POP3Store:port	Lcom/sun/mail/pop3/Protocol;
    //   22: aload_0
    //   23: invokespecial 179	javax/mail/Store:close	()V
    //   26: aload_0
    //   27: monitorexit
    //   28: return
    //   29: astore_1
    //   30: aload_0
    //   31: aconst_null
    //   32: putfield 45	com/sun/mail/pop3/POP3Store:port	Lcom/sun/mail/pop3/Protocol;
    //   35: aload_0
    //   36: invokespecial 179	javax/mail/Store:close	()V
    //   39: goto -13 -> 26
    //   42: astore_1
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_1
    //   46: athrow
    //   47: astore_1
    //   48: aload_0
    //   49: aconst_null
    //   50: putfield 45	com/sun/mail/pop3/POP3Store:port	Lcom/sun/mail/pop3/Protocol;
    //   53: aload_0
    //   54: invokespecial 179	javax/mail/Store:close	()V
    //   57: aload_1
    //   58: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	59	0	this	POP3Store
    //   29	1	1	localIOException	java.io.IOException
    //   42	4	1	localObject1	Object
    //   47	11	1	localObject2	Object
    // Exception table:
    //   from	to	target	type
    //   2	17	29	java/io/IOException
    //   17	26	42	finally
    //   30	39	42	finally
    //   48	59	42	finally
    //   2	17	47	finally
  }
  
  void closePort(POP3Folder paramPOP3Folder)
  {
    try
    {
      if (this.portOwner == paramPOP3Folder)
      {
        this.port = null;
        this.portOwner = null;
      }
      return;
    }
    finally
    {
      paramPOP3Folder = finally;
      throw paramPOP3Folder;
    }
  }
  
  protected void finalize()
    throws Throwable
  {
    super.finalize();
    if (this.port != null) {
      close();
    }
  }
  
  public Folder getDefaultFolder()
    throws MessagingException
  {
    checkConnected();
    return new DefaultFolder(this);
  }
  
  public Folder getFolder(String paramString)
    throws MessagingException
  {
    checkConnected();
    return new POP3Folder(this, paramString);
  }
  
  public Folder getFolder(URLName paramURLName)
    throws MessagingException
  {
    checkConnected();
    return new POP3Folder(this, paramURLName.getFile());
  }
  
  /* Error */
  Protocol getPort(POP3Folder paramPOP3Folder)
    throws java.io.IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 45	com/sun/mail/pop3/POP3Store:port	Lcom/sun/mail/pop3/Protocol;
    //   6: ifnull +24 -> 30
    //   9: aload_0
    //   10: getfield 47	com/sun/mail/pop3/POP3Store:portOwner	Lcom/sun/mail/pop3/POP3Folder;
    //   13: ifnonnull +17 -> 30
    //   16: aload_0
    //   17: aload_1
    //   18: putfield 47	com/sun/mail/pop3/POP3Store:portOwner	Lcom/sun/mail/pop3/POP3Folder;
    //   21: aload_0
    //   22: getfield 45	com/sun/mail/pop3/POP3Store:port	Lcom/sun/mail/pop3/Protocol;
    //   25: astore_2
    //   26: aload_0
    //   27: monitorexit
    //   28: aload_2
    //   29: areturn
    //   30: new 174	com/sun/mail/pop3/Protocol
    //   33: dup
    //   34: aload_0
    //   35: getfield 49	com/sun/mail/pop3/POP3Store:host	Ljava/lang/String;
    //   38: aload_0
    //   39: getfield 51	com/sun/mail/pop3/POP3Store:portNum	I
    //   42: aload_0
    //   43: getfield 213	com/sun/mail/pop3/POP3Store:session	Ljavax/mail/Session;
    //   46: invokevirtual 109	javax/mail/Session:getDebug	()Z
    //   49: aload_0
    //   50: getfield 213	com/sun/mail/pop3/POP3Store:session	Ljavax/mail/Session;
    //   53: invokevirtual 113	javax/mail/Session:getDebugOut	()Ljava/io/PrintStream;
    //   56: aload_0
    //   57: getfield 213	com/sun/mail/pop3/POP3Store:session	Ljavax/mail/Session;
    //   60: invokevirtual 217	javax/mail/Session:getProperties	()Ljava/util/Properties;
    //   63: new 71	java/lang/StringBuilder
    //   66: dup
    //   67: ldc 73
    //   69: invokespecial 76	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   72: aload_0
    //   73: getfield 39	com/sun/mail/pop3/POP3Store:name	Ljava/lang/String;
    //   76: invokevirtual 80	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   79: invokevirtual 85	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   82: aload_0
    //   83: getfield 43	com/sun/mail/pop3/POP3Store:isSSL	Z
    //   86: invokespecial 220	com/sun/mail/pop3/Protocol:<init>	(Ljava/lang/String;IZLjava/io/PrintStream;Ljava/util/Properties;Ljava/lang/String;Z)V
    //   89: astore_3
    //   90: aload_3
    //   91: aload_0
    //   92: getfield 53	com/sun/mail/pop3/POP3Store:user	Ljava/lang/String;
    //   95: aload_0
    //   96: getfield 55	com/sun/mail/pop3/POP3Store:passwd	Ljava/lang/String;
    //   99: invokevirtual 224	com/sun/mail/pop3/Protocol:login	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   102: astore_2
    //   103: aload_2
    //   104: ifnull +22 -> 126
    //   107: aload_3
    //   108: invokevirtual 177	com/sun/mail/pop3/Protocol:quit	()Z
    //   111: pop
    //   112: new 226	java/io/EOFException
    //   115: dup
    //   116: aload_2
    //   117: invokespecial 227	java/io/EOFException:<init>	(Ljava/lang/String;)V
    //   120: athrow
    //   121: astore_1
    //   122: aload_0
    //   123: monitorexit
    //   124: aload_1
    //   125: athrow
    //   126: aload_0
    //   127: getfield 45	com/sun/mail/pop3/POP3Store:port	Lcom/sun/mail/pop3/Protocol;
    //   130: ifnonnull +17 -> 147
    //   133: aload_1
    //   134: ifnull +13 -> 147
    //   137: aload_0
    //   138: aload_3
    //   139: putfield 45	com/sun/mail/pop3/POP3Store:port	Lcom/sun/mail/pop3/Protocol;
    //   142: aload_0
    //   143: aload_1
    //   144: putfield 47	com/sun/mail/pop3/POP3Store:portOwner	Lcom/sun/mail/pop3/POP3Folder;
    //   147: aload_3
    //   148: astore_2
    //   149: aload_0
    //   150: getfield 47	com/sun/mail/pop3/POP3Store:portOwner	Lcom/sun/mail/pop3/POP3Folder;
    //   153: ifnonnull -127 -> 26
    //   156: aload_0
    //   157: aload_1
    //   158: putfield 47	com/sun/mail/pop3/POP3Store:portOwner	Lcom/sun/mail/pop3/POP3Folder;
    //   161: aload_3
    //   162: astore_2
    //   163: goto -137 -> 26
    //   166: astore_1
    //   167: goto -55 -> 112
    //   170: astore_1
    //   171: goto -59 -> 112
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	174	0	this	POP3Store
    //   0	174	1	paramPOP3Folder	POP3Folder
    //   25	138	2	localObject	Object
    //   89	73	3	localProtocol	Protocol
    // Exception table:
    //   from	to	target	type
    //   2	26	121	finally
    //   30	103	121	finally
    //   112	121	121	finally
    //   126	133	121	finally
    //   137	147	121	finally
    //   149	161	121	finally
    //   107	112	166	java/io/IOException
    //   107	112	170	finally
  }
  
  /* Error */
  public boolean isConnected()
  {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: invokespecial 165	javax/mail/Store:isConnected	()Z
    //   8: istore_2
    //   9: iload_2
    //   10: ifne +7 -> 17
    //   13: aload_0
    //   14: monitorexit
    //   15: iload_1
    //   16: ireturn
    //   17: aload_0
    //   18: monitorenter
    //   19: aload_0
    //   20: getfield 45	com/sun/mail/pop3/POP3Store:port	Lcom/sun/mail/pop3/Protocol;
    //   23: ifnonnull +19 -> 42
    //   26: aload_0
    //   27: aload_0
    //   28: aconst_null
    //   29: invokevirtual 229	com/sun/mail/pop3/POP3Store:getPort	(Lcom/sun/mail/pop3/POP3Folder;)Lcom/sun/mail/pop3/Protocol;
    //   32: putfield 45	com/sun/mail/pop3/POP3Store:port	Lcom/sun/mail/pop3/Protocol;
    //   35: aload_0
    //   36: monitorexit
    //   37: iconst_1
    //   38: istore_1
    //   39: goto -26 -> 13
    //   42: aload_0
    //   43: getfield 45	com/sun/mail/pop3/POP3Store:port	Lcom/sun/mail/pop3/Protocol;
    //   46: invokevirtual 232	com/sun/mail/pop3/Protocol:noop	()Z
    //   49: pop
    //   50: goto -15 -> 35
    //   53: astore_3
    //   54: aload_0
    //   55: invokespecial 179	javax/mail/Store:close	()V
    //   58: aload_0
    //   59: monitorexit
    //   60: goto -47 -> 13
    //   63: astore_3
    //   64: aload_0
    //   65: monitorexit
    //   66: aload_3
    //   67: athrow
    //   68: astore_3
    //   69: aload_0
    //   70: monitorexit
    //   71: aload_3
    //   72: athrow
    //   73: astore_3
    //   74: goto -16 -> 58
    //   77: astore_3
    //   78: goto -20 -> 58
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	81	0	this	POP3Store
    //   1	38	1	bool1	boolean
    //   8	2	2	bool2	boolean
    //   53	1	3	localIOException	java.io.IOException
    //   63	4	3	localObject1	Object
    //   68	4	3	localObject2	Object
    //   73	1	3	localMessagingException	MessagingException
    //   77	1	3	localObject3	Object
    // Exception table:
    //   from	to	target	type
    //   19	35	53	java/io/IOException
    //   42	50	53	java/io/IOException
    //   19	35	63	finally
    //   35	37	63	finally
    //   42	50	63	finally
    //   58	60	63	finally
    //   64	66	63	finally
    //   4	9	68	finally
    //   17	19	68	finally
    //   66	68	68	finally
    //   54	58	73	javax/mail/MessagingException
    //   54	58	77	finally
  }
  
  /* Error */
  protected boolean protocolConnect(String paramString1, int paramInt, String paramString2, String paramString3)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: ifnull +12 -> 15
    //   6: aload 4
    //   8: ifnull +7 -> 15
    //   11: aload_3
    //   12: ifnonnull +11 -> 23
    //   15: iconst_0
    //   16: istore 6
    //   18: aload_0
    //   19: monitorexit
    //   20: iload 6
    //   22: ireturn
    //   23: iload_2
    //   24: istore 5
    //   26: iload_2
    //   27: iconst_m1
    //   28: if_icmpne +51 -> 79
    //   31: aload_0
    //   32: getfield 213	com/sun/mail/pop3/POP3Store:session	Ljavax/mail/Session;
    //   35: new 71	java/lang/StringBuilder
    //   38: dup
    //   39: ldc 73
    //   41: invokespecial 76	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   44: aload_0
    //   45: getfield 39	com/sun/mail/pop3/POP3Store:name	Ljava/lang/String;
    //   48: invokevirtual 80	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   51: ldc -20
    //   53: invokevirtual 80	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   56: invokevirtual 85	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   59: invokevirtual 91	javax/mail/Session:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   62: astore 7
    //   64: iload_2
    //   65: istore 5
    //   67: aload 7
    //   69: ifnull +10 -> 79
    //   72: aload 7
    //   74: invokestatic 240	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   77: istore 5
    //   79: iload 5
    //   81: istore_2
    //   82: iload 5
    //   84: iconst_m1
    //   85: if_icmpne +8 -> 93
    //   88: aload_0
    //   89: getfield 41	com/sun/mail/pop3/POP3Store:defaultPort	I
    //   92: istore_2
    //   93: aload_0
    //   94: aload_1
    //   95: putfield 49	com/sun/mail/pop3/POP3Store:host	Ljava/lang/String;
    //   98: aload_0
    //   99: iload_2
    //   100: putfield 51	com/sun/mail/pop3/POP3Store:portNum	I
    //   103: aload_0
    //   104: aload_3
    //   105: putfield 53	com/sun/mail/pop3/POP3Store:user	Ljava/lang/String;
    //   108: aload_0
    //   109: aload 4
    //   111: putfield 55	com/sun/mail/pop3/POP3Store:passwd	Ljava/lang/String;
    //   114: aload_0
    //   115: aload_0
    //   116: aconst_null
    //   117: invokevirtual 229	com/sun/mail/pop3/POP3Store:getPort	(Lcom/sun/mail/pop3/POP3Folder;)Lcom/sun/mail/pop3/Protocol;
    //   120: putfield 45	com/sun/mail/pop3/POP3Store:port	Lcom/sun/mail/pop3/Protocol;
    //   123: iconst_1
    //   124: istore 6
    //   126: goto -108 -> 18
    //   129: astore_1
    //   130: new 242	javax/mail/AuthenticationFailedException
    //   133: dup
    //   134: aload_1
    //   135: invokevirtual 245	java/io/EOFException:getMessage	()Ljava/lang/String;
    //   138: invokespecial 246	javax/mail/AuthenticationFailedException:<init>	(Ljava/lang/String;)V
    //   141: athrow
    //   142: astore_1
    //   143: aload_0
    //   144: monitorexit
    //   145: aload_1
    //   146: athrow
    //   147: astore_1
    //   148: new 162	javax/mail/MessagingException
    //   151: dup
    //   152: ldc -8
    //   154: aload_1
    //   155: invokespecial 251	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   158: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	159	0	this	POP3Store
    //   0	159	1	paramString1	String
    //   0	159	2	paramInt	int
    //   0	159	3	paramString2	String
    //   0	159	4	paramString3	String
    //   24	62	5	i	int
    //   16	109	6	bool	boolean
    //   62	11	7	str	String
    // Exception table:
    //   from	to	target	type
    //   114	123	129	java/io/EOFException
    //   31	64	142	finally
    //   72	79	142	finally
    //   88	93	142	finally
    //   93	114	142	finally
    //   114	123	142	finally
    //   130	142	142	finally
    //   148	159	142	finally
    //   114	123	147	java/io/IOException
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/pop3/POP3Store.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */