package com.sun.mail.smtp;

import com.sun.mail.util.ASCIIUtility;
import com.sun.mail.util.BASE64DecoderStream;
import com.sun.mail.util.BASE64EncoderStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.StreamTokenizer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Hashtable;
import java.util.StringTokenizer;

public class DigestMD5
{
  private static char[] digits = { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102 };
  private String clientResponse;
  private PrintStream debugout;
  private MessageDigest md5;
  private String uri;
  
  public DigestMD5(PrintStream paramPrintStream)
  {
    this.debugout = paramPrintStream;
    if (paramPrintStream != null) {
      paramPrintStream.println("DEBUG DIGEST-MD5: Loaded");
    }
  }
  
  private static String toHex(byte[] paramArrayOfByte)
  {
    char[] arrayOfChar = new char[paramArrayOfByte.length * 2];
    int i = 0;
    int j = 0;
    for (;;)
    {
      if (i >= paramArrayOfByte.length) {
        return new String(arrayOfChar);
      }
      int k = paramArrayOfByte[i] & 0xFF;
      int m = j + 1;
      arrayOfChar[j] = digits[(k >> 4)];
      j = m + 1;
      arrayOfChar[m] = digits[(k & 0xF)];
      i += 1;
    }
  }
  
  private Hashtable tokenize(String paramString)
    throws IOException
  {
    Hashtable localHashtable = new Hashtable();
    Object localObject = paramString.getBytes();
    paramString = null;
    localObject = new StreamTokenizer(new InputStreamReader(new BASE64DecoderStream(new ByteArrayInputStream((byte[])localObject, 4, localObject.length - 4))));
    ((StreamTokenizer)localObject).ordinaryChars(48, 57);
    ((StreamTokenizer)localObject).wordChars(48, 57);
    for (;;)
    {
      int i = ((StreamTokenizer)localObject).nextToken();
      if (i == -1) {
        return localHashtable;
      }
      switch (i)
      {
      default: 
        break;
      case -3: 
        if (paramString != null) {
          break label128;
        }
        paramString = ((StreamTokenizer)localObject).sval;
      }
    }
    label128:
    if (this.debugout != null) {
      this.debugout.println("DEBUG DIGEST-MD5: Received => " + paramString + "='" + ((StreamTokenizer)localObject).sval + "'");
    }
    if (localHashtable.containsKey(paramString)) {
      localHashtable.put(paramString, localHashtable.get(paramString) + "," + ((StreamTokenizer)localObject).sval);
    }
    for (;;)
    {
      paramString = null;
      break;
      localHashtable.put(paramString, ((StreamTokenizer)localObject).sval);
    }
  }
  
  public byte[] authClient(String paramString1, String paramString2, String paramString3, String paramString4, String paramString5)
    throws IOException
  {
    ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
    BASE64EncoderStream localBASE64EncoderStream = new BASE64EncoderStream(localByteArrayOutputStream, Integer.MAX_VALUE);
    for (;;)
    {
      try
      {
        SecureRandom localSecureRandom = new SecureRandom();
        this.md5 = MessageDigest.getInstance("MD5");
        StringBuffer localStringBuffer = new StringBuffer();
        this.uri = ("smtp/" + paramString1);
        byte[] arrayOfByte = new byte[32];
        if (this.debugout != null) {
          this.debugout.println("DEBUG DIGEST-MD5: Begin authentication ...");
        }
        Hashtable localHashtable = tokenize(paramString5);
        paramString5 = paramString4;
        if (paramString4 == null)
        {
          paramString4 = (String)localHashtable.get("realm");
          if (paramString4 != null) {
            paramString5 = new StringTokenizer(paramString4, ",").nextToken();
          }
        }
        else
        {
          paramString1 = (String)localHashtable.get("nonce");
          localSecureRandom.nextBytes(arrayOfByte);
          localBASE64EncoderStream.write(arrayOfByte);
          localBASE64EncoderStream.flush();
          paramString4 = localByteArrayOutputStream.toString();
          localByteArrayOutputStream.reset();
          this.md5.update(this.md5.digest(ASCIIUtility.getBytes(paramString2 + ":" + paramString5 + ":" + paramString3)));
          this.md5.update(ASCIIUtility.getBytes(":" + paramString1 + ":" + paramString4));
          this.clientResponse = (toHex(this.md5.digest()) + ":" + paramString1 + ":" + "00000001" + ":" + paramString4 + ":" + "auth" + ":");
          this.md5.update(ASCIIUtility.getBytes("AUTHENTICATE:" + this.uri));
          this.md5.update(ASCIIUtility.getBytes(this.clientResponse + toHex(this.md5.digest())));
          localStringBuffer.append("username=\"" + paramString2 + "\"");
          localStringBuffer.append(",realm=\"" + paramString5 + "\"");
          localStringBuffer.append(",qop=" + "auth");
          localStringBuffer.append(",nc=" + "00000001");
          localStringBuffer.append(",nonce=\"" + paramString1 + "\"");
          localStringBuffer.append(",cnonce=\"" + paramString4 + "\"");
          localStringBuffer.append(",digest-uri=\"" + this.uri + "\"");
          localStringBuffer.append(",response=" + toHex(this.md5.digest()));
          if (this.debugout != null) {
            this.debugout.println("DEBUG DIGEST-MD5: Response => " + localStringBuffer.toString());
          }
          localBASE64EncoderStream.write(ASCIIUtility.getBytes(localStringBuffer.toString()));
          localBASE64EncoderStream.flush();
          return localByteArrayOutputStream.toByteArray();
        }
      }
      catch (NoSuchAlgorithmException paramString1)
      {
        if (this.debugout != null) {
          this.debugout.println("DEBUG DIGEST-MD5: " + paramString1);
        }
        throw new IOException(paramString1.toString());
      }
      paramString5 = paramString1;
    }
  }
  
  public boolean authServer(String paramString)
    throws IOException
  {
    paramString = tokenize(paramString);
    this.md5.update(ASCIIUtility.getBytes(":" + this.uri));
    this.md5.update(ASCIIUtility.getBytes(this.clientResponse + toHex(this.md5.digest())));
    String str = toHex(this.md5.digest());
    if (!str.equals((String)paramString.get("rspauth")))
    {
      if (this.debugout != null) {
        this.debugout.println("DEBUG DIGEST-MD5: Expected => rspauth=" + str);
      }
      return false;
    }
    return true;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/smtp/DigestMD5.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */