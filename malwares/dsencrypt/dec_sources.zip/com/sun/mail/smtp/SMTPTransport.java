package com.sun.mail.smtp;

import com.sun.mail.util.ASCIIUtility;
import com.sun.mail.util.BASE64EncoderStream;
import com.sun.mail.util.LineInputStream;
import com.sun.mail.util.SocketFetcher;
import com.sun.mail.util.TraceInputStream;
import com.sun.mail.util.TraceOutputStream;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.io.StringReader;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.mail.Address;
import javax.mail.MessagingException;
import javax.mail.SendFailedException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.URLName;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimePart;
import javax.mail.internet.ParseException;

public class SMTPTransport
  extends Transport
{
  private static final byte[] CRLF;
  private static final String UNKNOWN = "UNKNOWN";
  private static char[] hexchar;
  private static final String[] ignoreList;
  private Address[] addresses;
  private SMTPOutputStream dataStream;
  private int defaultPort = 25;
  private MessagingException exception;
  private Hashtable extMap;
  private Address[] invalidAddr;
  private boolean isSSL = false;
  private int lastReturnCode;
  private String lastServerResponse;
  private LineInputStream lineInputStream;
  private String localHostName;
  private DigestMD5 md5support;
  private MimeMessage message;
  private String name = "smtp";
  private PrintStream out;
  private boolean quitWait = false;
  private boolean reportSuccess;
  private String saslRealm = "UNKNOWN";
  private boolean sendPartiallyFailed = false;
  private BufferedInputStream serverInput;
  private OutputStream serverOutput;
  private Socket serverSocket;
  private boolean useRset;
  private boolean useStartTLS;
  private Address[] validSentAddr;
  private Address[] validUnsentAddr;
  
  static
  {
    if (!SMTPTransport.class.desiredAssertionStatus()) {}
    for (boolean bool = true;; bool = false)
    {
      $assertionsDisabled = bool;
      ignoreList = new String[] { "Bcc", "Content-Length" };
      CRLF = new byte[] { 13, 10 };
      hexchar = new char[] { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70 };
      return;
    }
  }
  
  public SMTPTransport(Session paramSession, URLName paramURLName)
  {
    this(paramSession, paramURLName, "smtp", 25, false);
  }
  
  protected SMTPTransport(Session paramSession, URLName paramURLName, String paramString, int paramInt, boolean paramBoolean)
  {
    super(paramSession, paramURLName);
    if (paramURLName != null) {
      paramString = paramURLName.getProtocol();
    }
    this.name = paramString;
    this.defaultPort = paramInt;
    this.isSSL = paramBoolean;
    this.out = paramSession.getDebugOut();
    paramURLName = paramSession.getProperty("mail." + paramString + ".quitwait");
    if ((paramURLName != null) && (!paramURLName.equalsIgnoreCase("true")))
    {
      paramBoolean = false;
      this.quitWait = paramBoolean;
      paramURLName = paramSession.getProperty("mail." + paramString + ".reportsuccess");
      if ((paramURLName == null) || (!paramURLName.equalsIgnoreCase("true"))) {
        break label276;
      }
      paramBoolean = true;
      label166:
      this.reportSuccess = paramBoolean;
      paramURLName = paramSession.getProperty("mail." + paramString + ".starttls.enable");
      if ((paramURLName == null) || (!paramURLName.equalsIgnoreCase("true"))) {
        break label282;
      }
      paramBoolean = true;
      label214:
      this.useStartTLS = paramBoolean;
      paramSession = paramSession.getProperty("mail." + paramString + ".userset");
      if ((paramSession == null) || (!paramSession.equalsIgnoreCase("true"))) {
        break label288;
      }
    }
    label276:
    label282:
    label288:
    for (paramBoolean = bool;; paramBoolean = false)
    {
      this.useRset = paramBoolean;
      return;
      paramBoolean = true;
      break;
      paramBoolean = false;
      break label166;
      paramBoolean = false;
      break label214;
    }
  }
  
  private void closeConnection()
    throws MessagingException
  {
    try
    {
      if (this.serverSocket != null) {
        this.serverSocket.close();
      }
      return;
    }
    catch (IOException localIOException)
    {
      throw new MessagingException("Server Close Failed", localIOException);
    }
    finally
    {
      this.serverSocket = null;
      this.serverOutput = null;
      this.serverInput = null;
      this.lineInputStream = null;
      if (super.isConnected()) {
        super.close();
      }
    }
  }
  
  private boolean convertTo8Bit(MimePart paramMimePart)
  {
    boolean bool5 = false;
    boolean bool6 = false;
    boolean bool7 = false;
    boolean bool1 = false;
    boolean bool4 = bool5;
    boolean bool2 = bool6;
    try
    {
      boolean bool3;
      if (paramMimePart.isMimeType("text/*"))
      {
        bool4 = bool5;
        bool2 = bool6;
        String str = paramMimePart.getEncoding();
        bool3 = bool7;
        if (str != null)
        {
          bool4 = bool5;
          bool2 = bool6;
          if (!str.equalsIgnoreCase("quoted-printable"))
          {
            bool4 = bool5;
            bool2 = bool6;
            bool3 = bool7;
            if (!str.equalsIgnoreCase("base64")) {}
          }
          else
          {
            bool4 = bool5;
            bool2 = bool6;
            bool3 = bool7;
            if (is8Bit(paramMimePart.getInputStream()))
            {
              bool4 = bool5;
              bool2 = bool6;
              paramMimePart.setContent(paramMimePart.getContent(), paramMimePart.getContentType());
              bool4 = bool5;
              bool2 = bool6;
              paramMimePart.setHeader("Content-Transfer-Encoding", "8bit");
              return true;
            }
          }
        }
      }
      else
      {
        bool4 = bool5;
        bool2 = bool6;
        bool3 = bool7;
        if (paramMimePart.isMimeType("multipart/*"))
        {
          bool4 = bool5;
          bool2 = bool6;
          paramMimePart = (MimeMultipart)paramMimePart.getContent();
          bool4 = bool5;
          bool2 = bool6;
          int j = paramMimePart.getCount();
          int i = 0;
          for (;;)
          {
            bool3 = bool1;
            if (i >= j) {
              break;
            }
            bool4 = bool1;
            bool2 = bool1;
            bool3 = convertTo8Bit((MimePart)paramMimePart.getBodyPart(i));
            if (bool3) {
              bool1 = true;
            }
            i += 1;
          }
        }
      }
      return bool3;
    }
    catch (MessagingException paramMimePart)
    {
      return bool4;
    }
    catch (IOException paramMimePart)
    {
      bool3 = bool2;
    }
  }
  
  private void expandGroups()
  {
    Object localObject1 = null;
    int i = 0;
    Object localObject2;
    if (i >= this.addresses.length)
    {
      if (localObject1 != null)
      {
        localObject2 = new InternetAddress[((Vector)localObject1).size()];
        ((Vector)localObject1).copyInto((Object[])localObject2);
        this.addresses = ((Address[])localObject2);
      }
      return;
    }
    InternetAddress localInternetAddress = (InternetAddress)this.addresses[i];
    int j;
    if (localInternetAddress.isGroup())
    {
      localObject2 = localObject1;
      if (localObject1 == null)
      {
        localObject2 = new Vector();
        j = 0;
        label82:
        if (j < i) {
          break label122;
        }
      }
    }
    for (;;)
    {
      try
      {
        localObject1 = localInternetAddress.getGroup(true);
        if (localObject1 == null) {
          continue;
        }
        j = 0;
        int k = localObject1.length;
        if (j < k) {
          continue;
        }
      }
      catch (ParseException localParseException)
      {
        label122:
        ((Vector)localObject2).addElement(localInternetAddress);
        continue;
      }
      i += 1;
      localObject1 = localObject2;
      break;
      ((Vector)localObject2).addElement(this.addresses[j]);
      j += 1;
      break label82;
      ((Vector)localObject2).addElement(localObject1[j]);
      j += 1;
      continue;
      ((Vector)localObject2).addElement(localInternetAddress);
      continue;
      localObject2 = localParseException;
      if (localParseException != null)
      {
        localParseException.addElement(localInternetAddress);
        localObject2 = localParseException;
      }
    }
  }
  
  /* Error */
  private DigestMD5 getMD5()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 285	com/sun/mail/smtp/SMTPTransport:md5support	Lcom/sun/mail/smtp/DigestMD5;
    //   6: ifnonnull +27 -> 33
    //   9: aload_0
    //   10: getfield 288	com/sun/mail/smtp/SMTPTransport:debug	Z
    //   13: ifeq +29 -> 42
    //   16: aload_0
    //   17: getfield 129	com/sun/mail/smtp/SMTPTransport:out	Ljava/io/PrintStream;
    //   20: astore_1
    //   21: aload_0
    //   22: new 290	com/sun/mail/smtp/DigestMD5
    //   25: dup
    //   26: aload_1
    //   27: invokespecial 293	com/sun/mail/smtp/DigestMD5:<init>	(Ljava/io/PrintStream;)V
    //   30: putfield 285	com/sun/mail/smtp/SMTPTransport:md5support	Lcom/sun/mail/smtp/DigestMD5;
    //   33: aload_0
    //   34: getfield 285	com/sun/mail/smtp/SMTPTransport:md5support	Lcom/sun/mail/smtp/DigestMD5;
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: areturn
    //   42: aconst_null
    //   43: astore_1
    //   44: goto -23 -> 21
    //   47: astore_1
    //   48: aload_0
    //   49: monitorexit
    //   50: aload_1
    //   51: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	52	0	this	SMTPTransport
    //   20	24	1	localObject1	Object
    //   47	4	1	localObject2	Object
    // Exception table:
    //   from	to	target	type
    //   2	21	47	finally
    //   21	33	47	finally
    //   33	38	47	finally
  }
  
  private void initStreams()
    throws IOException
  {
    Object localObject2 = this.session.getProperties();
    Object localObject1 = this.session.getDebugOut();
    boolean bool2 = this.session.getDebug();
    localObject2 = ((Properties)localObject2).getProperty("mail.debug.quote");
    if ((localObject2 != null) && (((String)localObject2).equalsIgnoreCase("true"))) {}
    for (boolean bool1 = true;; bool1 = false)
    {
      localObject2 = new TraceInputStream(this.serverSocket.getInputStream(), (OutputStream)localObject1);
      ((TraceInputStream)localObject2).setTrace(bool2);
      ((TraceInputStream)localObject2).setQuote(bool1);
      localObject1 = new TraceOutputStream(this.serverSocket.getOutputStream(), (OutputStream)localObject1);
      ((TraceOutputStream)localObject1).setTrace(bool2);
      ((TraceOutputStream)localObject1).setQuote(bool1);
      this.serverOutput = new BufferedOutputStream((OutputStream)localObject1);
      this.serverInput = new BufferedInputStream((InputStream)localObject2);
      this.lineInputStream = new LineInputStream(this.serverInput);
      return;
    }
  }
  
  private boolean is8Bit(InputStream paramInputStream)
  {
    int j = 0;
    boolean bool = false;
    try
    {
      int i = paramInputStream.read();
      if (i < 0)
      {
        if ((this.debug) && (bool)) {
          this.out.println("DEBUG SMTP: found an 8bit part");
        }
        return bool;
      }
      int k = i & 0xFF;
      if ((k == 13) || (k == 10)) {
        i = 0;
      }
      do
      {
        j = i;
        if (k <= 127) {
          break;
        }
        bool = true;
        j = i;
        break;
        if (k == 0) {
          return false;
        }
        j += 1;
        i = j;
      } while (j <= 998);
      return false;
    }
    catch (IOException paramInputStream) {}
    return false;
  }
  
  private boolean isNotLastLine(String paramString)
  {
    return (paramString != null) && (paramString.length() >= 4) && (paramString.charAt(3) == '-');
  }
  
  private void issueSendCommand(String paramString, int paramInt)
    throws MessagingException
  {
    sendCommand(paramString);
    int j = readServerResponse();
    if (j != paramInt)
    {
      if (this.validSentAddr == null)
      {
        paramInt = 0;
        if (this.validUnsentAddr != null) {
          break label210;
        }
      }
      label210:
      for (int i = 0;; i = this.validUnsentAddr.length)
      {
        Object localObject = new Address[paramInt + i];
        if (paramInt > 0) {
          System.arraycopy(this.validSentAddr, 0, localObject, 0, paramInt);
        }
        if (i > 0) {
          System.arraycopy(this.validUnsentAddr, 0, localObject, paramInt, i);
        }
        this.validSentAddr = null;
        this.validUnsentAddr = ((Address[])localObject);
        if (this.debug) {
          this.out.println("DEBUG SMTP: got response code " + j + ", with response: " + this.lastServerResponse);
        }
        localObject = this.lastServerResponse;
        paramInt = this.lastReturnCode;
        if (this.serverSocket != null) {
          issueCommand("RSET", 250);
        }
        this.lastServerResponse = ((String)localObject);
        this.lastReturnCode = paramInt;
        throw new SMTPSendFailedException(paramString, j, this.lastServerResponse, this.exception, this.validSentAddr, this.validUnsentAddr, this.invalidAddr);
        paramInt = this.validSentAddr.length;
        break;
      }
    }
  }
  
  private String normalizeAddress(String paramString)
  {
    String str = paramString;
    if (!paramString.startsWith("<"))
    {
      str = paramString;
      if (!paramString.endsWith(">")) {
        str = "<" + paramString + ">";
      }
    }
    return str;
  }
  
  private void openServer()
    throws MessagingException
  {
    int i = -1;
    String str = "UNKNOWN";
    Object localObject = str;
    int j;
    try
    {
      j = this.serverSocket.getPort();
      i = j;
      localObject = str;
      str = this.serverSocket.getInetAddress().getHostName();
      i = j;
      localObject = str;
      if (this.debug)
      {
        i = j;
        localObject = str;
        this.out.println("DEBUG SMTP: starting protocol to host \"" + str + "\", port " + j);
      }
      i = j;
      localObject = str;
      initStreams();
      i = j;
      localObject = str;
      int k = readServerResponse();
      if (k != 220)
      {
        i = j;
        localObject = str;
        this.serverSocket.close();
        i = j;
        localObject = str;
        this.serverSocket = null;
        i = j;
        localObject = str;
        this.serverOutput = null;
        i = j;
        localObject = str;
        this.serverInput = null;
        i = j;
        localObject = str;
        this.lineInputStream = null;
        i = j;
        localObject = str;
        if (this.debug)
        {
          i = j;
          localObject = str;
          this.out.println("DEBUG SMTP: got bad greeting from host \"" + str + "\", port: " + j + ", response: " + k + "\n");
        }
        i = j;
        localObject = str;
        throw new MessagingException("Got bad greeting from SMTP host: " + str + ", port: " + j + ", response: " + k);
      }
    }
    catch (IOException localIOException)
    {
      throw new MessagingException("Could not start protocol to SMTP host: " + (String)localObject + ", port: " + i, localIOException);
    }
    i = j;
    localObject = localIOException;
    if (this.debug)
    {
      i = j;
      localObject = localIOException;
      this.out.println("DEBUG SMTP: protocol started to host \"" + localIOException + "\", port: " + j + "\n");
    }
  }
  
  private void openServer(String paramString, int paramInt)
    throws MessagingException
  {
    if (this.debug) {
      this.out.println("DEBUG SMTP: trying to connect to host \"" + paramString + "\", port " + paramInt + ", isSSL " + this.isSSL);
    }
    int i = paramInt;
    try
    {
      this.serverSocket = SocketFetcher.getSocket(paramString, paramInt, this.session.getProperties(), "mail." + this.name, this.isSSL);
      i = paramInt;
      paramInt = this.serverSocket.getPort();
      i = paramInt;
      initStreams();
      i = paramInt;
      int j = readServerResponse();
      if (j != 220)
      {
        i = paramInt;
        this.serverSocket.close();
        i = paramInt;
        this.serverSocket = null;
        i = paramInt;
        this.serverOutput = null;
        i = paramInt;
        this.serverInput = null;
        i = paramInt;
        this.lineInputStream = null;
        i = paramInt;
        if (this.debug)
        {
          i = paramInt;
          this.out.println("DEBUG SMTP: could not connect to host \"" + paramString + "\", port: " + paramInt + ", response: " + j + "\n");
        }
        i = paramInt;
        throw new MessagingException("Could not connect to SMTP host: " + paramString + ", port: " + paramInt + ", response: " + j);
      }
    }
    catch (UnknownHostException localUnknownHostException)
    {
      throw new MessagingException("Unknown SMTP host: " + paramString, localUnknownHostException);
      i = paramInt;
      if (this.debug)
      {
        i = paramInt;
        this.out.println("DEBUG SMTP: connected to host \"" + paramString + "\", port: " + paramInt + "\n");
      }
      return;
    }
    catch (IOException localIOException)
    {
      throw new MessagingException("Could not connect to SMTP host: " + paramString + ", port: " + i, localIOException);
    }
  }
  
  private void sendCommand(byte[] paramArrayOfByte)
    throws MessagingException
  {
    assert (Thread.holdsLock(this));
    try
    {
      this.serverOutput.write(paramArrayOfByte);
      this.serverOutput.write(CRLF);
      this.serverOutput.flush();
      return;
    }
    catch (IOException paramArrayOfByte)
    {
      throw new MessagingException("Can't send command to SMTP host", paramArrayOfByte);
    }
  }
  
  protected static String xtext(String paramString)
  {
    Object localObject1 = null;
    int i = 0;
    if (i >= paramString.length())
    {
      if (localObject1 != null) {
        paramString = ((StringBuffer)localObject1).toString();
      }
      return paramString;
    }
    char c = paramString.charAt(i);
    if (c >= '') {
      throw new IllegalArgumentException("Non-ASCII character in SMTP submitter: " + paramString);
    }
    Object localObject2;
    if ((c < '!') || (c > '~') || (c == '+') || (c == '='))
    {
      localObject2 = localObject1;
      if (localObject1 == null)
      {
        localObject2 = new StringBuffer(paramString.length() + 4);
        ((StringBuffer)localObject2).append(paramString.substring(0, i));
      }
      ((StringBuffer)localObject2).append('+');
      ((StringBuffer)localObject2).append(hexchar[((c & 0xF0) >> '\004')]);
      ((StringBuffer)localObject2).append(hexchar[(c & 0xF)]);
    }
    for (;;)
    {
      i += 1;
      localObject1 = localObject2;
      break;
      localObject2 = localObject1;
      if (localObject1 != null)
      {
        ((StringBuffer)localObject1).append(c);
        localObject2 = localObject1;
      }
    }
  }
  
  protected void checkConnected()
  {
    if (!super.isConnected()) {
      throw new IllegalStateException("Not connected");
    }
  }
  
  public void close()
    throws MessagingException
  {
    try
    {
      boolean bool = super.isConnected();
      if (bool) {
        break label14;
      }
    }
    finally
    {
      try
      {
        for (;;)
        {
          label14:
          if (this.serverSocket != null)
          {
            sendCommand("QUIT");
            if (this.quitWait)
            {
              int i = readServerResponse();
              if ((i != 221) && (i != -1)) {
                this.out.println("DEBUG SMTP: QUIT failed with " + i);
              }
            }
          }
          closeConnection();
        }
      }
      finally
      {
        closeConnection();
      }
      localObject1 = finally;
    }
  }
  
  public void connect(Socket paramSocket)
    throws MessagingException
  {
    try
    {
      this.serverSocket = paramSocket;
      super.connect();
      return;
    }
    finally
    {
      paramSocket = finally;
      throw paramSocket;
    }
  }
  
  protected OutputStream data()
    throws MessagingException
  {
    assert (Thread.holdsLock(this));
    issueSendCommand("DATA", 354);
    this.dataStream = new SMTPOutputStream(this.serverOutput);
    return this.dataStream;
  }
  
  protected boolean ehlo(String paramString)
    throws MessagingException
  {
    boolean bool = false;
    int j;
    BufferedReader localBufferedReader;
    int i;
    if (paramString != null)
    {
      paramString = "EHLO " + paramString;
      sendCommand(paramString);
      j = readServerResponse();
      if (j == 250)
      {
        localBufferedReader = new BufferedReader(new StringReader(this.lastServerResponse));
        this.extMap = new Hashtable();
        i = 1;
      }
    }
    for (;;)
    {
      try
      {
        paramString = localBufferedReader.readLine();
        if (paramString != null) {
          continue;
        }
      }
      catch (IOException paramString)
      {
        String str2;
        int k;
        String str1;
        continue;
      }
      if (j == 250) {
        bool = true;
      }
      return bool;
      paramString = "EHLO";
      break;
      if (i != 0)
      {
        i = 0;
      }
      else if (paramString.length() >= 5)
      {
        str2 = paramString.substring(4);
        k = str2.indexOf(' ');
        str1 = "";
        paramString = str2;
        if (k > 0)
        {
          str1 = str2.substring(k + 1);
          paramString = str2.substring(0, k);
        }
        if (this.debug) {
          this.out.println("DEBUG SMTP: Found extension \"" + paramString + "\", arg \"" + str1 + "\"");
        }
        this.extMap.put(paramString.toUpperCase(Locale.ENGLISH), str1);
      }
    }
  }
  
  protected void finalize()
    throws Throwable
  {
    super.finalize();
    try
    {
      closeConnection();
      return;
    }
    catch (MessagingException localMessagingException) {}
  }
  
  protected void finishData()
    throws IOException, MessagingException
  {
    assert (Thread.holdsLock(this));
    this.dataStream.ensureAtBOL();
    issueSendCommand(".", 250);
  }
  
  public String getExtensionParameter(String paramString)
  {
    if (this.extMap == null) {
      return null;
    }
    return (String)this.extMap.get(paramString.toUpperCase(Locale.ENGLISH));
  }
  
  public int getLastReturnCode()
  {
    try
    {
      int i = this.lastReturnCode;
      return i;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public String getLastServerResponse()
  {
    try
    {
      String str = this.lastServerResponse;
      return str;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  /* Error */
  public String getLocalHost()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 621	com/sun/mail/smtp/SMTPTransport:localHostName	Ljava/lang/String;
    //   6: ifnull +13 -> 19
    //   9: aload_0
    //   10: getfield 621	com/sun/mail/smtp/SMTPTransport:localHostName	Ljava/lang/String;
    //   13: invokevirtual 363	java/lang/String:length	()I
    //   16: ifgt +39 -> 55
    //   19: aload_0
    //   20: aload_0
    //   21: getfield 298	com/sun/mail/smtp/SMTPTransport:session	Ljavax/mail/Session;
    //   24: new 131	java/lang/StringBuilder
    //   27: dup
    //   28: ldc -123
    //   30: invokespecial 136	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   33: aload_0
    //   34: getfield 105	com/sun/mail/smtp/SMTPTransport:name	Ljava/lang/String;
    //   37: invokevirtual 140	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   40: ldc_w 623
    //   43: invokevirtual 140	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   46: invokevirtual 145	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   49: invokevirtual 149	javax/mail/Session:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   52: putfield 621	com/sun/mail/smtp/SMTPTransport:localHostName	Ljava/lang/String;
    //   55: aload_0
    //   56: getfield 621	com/sun/mail/smtp/SMTPTransport:localHostName	Ljava/lang/String;
    //   59: ifnull +13 -> 72
    //   62: aload_0
    //   63: getfield 621	com/sun/mail/smtp/SMTPTransport:localHostName	Ljava/lang/String;
    //   66: invokevirtual 363	java/lang/String:length	()I
    //   69: ifgt +39 -> 108
    //   72: aload_0
    //   73: aload_0
    //   74: getfield 298	com/sun/mail/smtp/SMTPTransport:session	Ljavax/mail/Session;
    //   77: new 131	java/lang/StringBuilder
    //   80: dup
    //   81: ldc -123
    //   83: invokespecial 136	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   86: aload_0
    //   87: getfield 105	com/sun/mail/smtp/SMTPTransport:name	Ljava/lang/String;
    //   90: invokevirtual 140	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   93: ldc_w 625
    //   96: invokevirtual 140	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   99: invokevirtual 145	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   102: invokevirtual 149	javax/mail/Session:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   105: putfield 621	com/sun/mail/smtp/SMTPTransport:localHostName	Ljava/lang/String;
    //   108: aload_0
    //   109: getfield 621	com/sun/mail/smtp/SMTPTransport:localHostName	Ljava/lang/String;
    //   112: ifnull +13 -> 125
    //   115: aload_0
    //   116: getfield 621	com/sun/mail/smtp/SMTPTransport:localHostName	Ljava/lang/String;
    //   119: invokevirtual 363	java/lang/String:length	()I
    //   122: ifgt +52 -> 174
    //   125: invokestatic 627	java/net/InetAddress:getLocalHost	()Ljava/net/InetAddress;
    //   128: astore_1
    //   129: aload_0
    //   130: aload_1
    //   131: invokevirtual 436	java/net/InetAddress:getHostName	()Ljava/lang/String;
    //   134: putfield 621	com/sun/mail/smtp/SMTPTransport:localHostName	Ljava/lang/String;
    //   137: aload_0
    //   138: getfield 621	com/sun/mail/smtp/SMTPTransport:localHostName	Ljava/lang/String;
    //   141: ifnonnull +33 -> 174
    //   144: aload_0
    //   145: new 131	java/lang/StringBuilder
    //   148: dup
    //   149: ldc_w 629
    //   152: invokespecial 136	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   155: aload_1
    //   156: invokevirtual 632	java/net/InetAddress:getHostAddress	()Ljava/lang/String;
    //   159: invokevirtual 140	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   162: ldc_w 634
    //   165: invokevirtual 140	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   168: invokevirtual 145	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   171: putfield 621	com/sun/mail/smtp/SMTPTransport:localHostName	Ljava/lang/String;
    //   174: aload_0
    //   175: getfield 621	com/sun/mail/smtp/SMTPTransport:localHostName	Ljava/lang/String;
    //   178: astore_1
    //   179: aload_0
    //   180: monitorexit
    //   181: aload_1
    //   182: areturn
    //   183: astore_1
    //   184: aload_0
    //   185: monitorexit
    //   186: aload_1
    //   187: athrow
    //   188: astore_1
    //   189: goto -15 -> 174
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	192	0	this	SMTPTransport
    //   128	54	1	localObject1	Object
    //   183	4	1	localObject2	Object
    //   188	1	1	localUnknownHostException	UnknownHostException
    // Exception table:
    //   from	to	target	type
    //   2	19	183	finally
    //   19	55	183	finally
    //   55	72	183	finally
    //   72	108	183	finally
    //   108	125	183	finally
    //   125	174	183	finally
    //   174	179	183	finally
    //   2	19	188	java/net/UnknownHostException
    //   19	55	188	java/net/UnknownHostException
    //   55	72	188	java/net/UnknownHostException
    //   72	108	188	java/net/UnknownHostException
    //   108	125	188	java/net/UnknownHostException
    //   125	174	188	java/net/UnknownHostException
  }
  
  public boolean getReportSuccess()
  {
    try
    {
      boolean bool = this.reportSuccess;
      return bool;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public String getSASLRealm()
  {
    try
    {
      if (this.saslRealm == "UNKNOWN")
      {
        this.saslRealm = this.session.getProperty("mail." + this.name + ".sasl.realm");
        if (this.saslRealm == null) {
          this.saslRealm = this.session.getProperty("mail." + this.name + ".saslrealm");
        }
      }
      String str = this.saslRealm;
      return str;
    }
    finally {}
  }
  
  public boolean getStartTLS()
  {
    try
    {
      boolean bool = this.useStartTLS;
      return bool;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public boolean getUseRset()
  {
    try
    {
      boolean bool = this.useRset;
      return bool;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  protected void helo(String paramString)
    throws MessagingException
  {
    if (paramString != null)
    {
      issueCommand("HELO " + paramString, 250);
      return;
    }
    issueCommand("HELO", 250);
  }
  
  /* Error */
  public boolean isConnected()
  {
    // Byte code:
    //   0: iconst_0
    //   1: istore_2
    //   2: aload_0
    //   3: monitorenter
    //   4: aload_0
    //   5: invokespecial 188	javax/mail/Transport:isConnected	()Z
    //   8: istore_3
    //   9: iload_3
    //   10: ifne +7 -> 17
    //   13: aload_0
    //   14: monitorexit
    //   15: iload_2
    //   16: ireturn
    //   17: aload_0
    //   18: getfield 167	com/sun/mail/smtp/SMTPTransport:useRset	Z
    //   21: ifeq +31 -> 52
    //   24: aload_0
    //   25: ldc_w 400
    //   28: invokevirtual 372	com/sun/mail/smtp/SMTPTransport:sendCommand	(Ljava/lang/String;)V
    //   31: aload_0
    //   32: invokevirtual 375	com/sun/mail/smtp/SMTPTransport:readServerResponse	()I
    //   35: istore_1
    //   36: iload_1
    //   37: iflt +39 -> 76
    //   40: iload_1
    //   41: sipush 421
    //   44: if_icmpeq +32 -> 76
    //   47: iconst_1
    //   48: istore_2
    //   49: goto -36 -> 13
    //   52: aload_0
    //   53: ldc_w 651
    //   56: invokevirtual 372	com/sun/mail/smtp/SMTPTransport:sendCommand	(Ljava/lang/String;)V
    //   59: goto -28 -> 31
    //   62: astore 4
    //   64: aload_0
    //   65: invokespecial 536	com/sun/mail/smtp/SMTPTransport:closeConnection	()V
    //   68: goto -55 -> 13
    //   71: astore 4
    //   73: goto -60 -> 13
    //   76: aload_0
    //   77: invokespecial 536	com/sun/mail/smtp/SMTPTransport:closeConnection	()V
    //   80: goto -67 -> 13
    //   83: astore 4
    //   85: goto -72 -> 13
    //   88: astore 4
    //   90: aload_0
    //   91: monitorexit
    //   92: aload 4
    //   94: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	95	0	this	SMTPTransport
    //   35	10	1	i	int
    //   1	48	2	bool1	boolean
    //   8	2	3	bool2	boolean
    //   62	1	4	localException	Exception
    //   71	1	4	localMessagingException1	MessagingException
    //   83	1	4	localMessagingException2	MessagingException
    //   88	5	4	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   17	31	62	java/lang/Exception
    //   31	36	62	java/lang/Exception
    //   52	59	62	java/lang/Exception
    //   76	80	62	java/lang/Exception
    //   64	68	71	javax/mail/MessagingException
    //   76	80	83	javax/mail/MessagingException
    //   4	9	88	finally
    //   17	31	88	finally
    //   31	36	88	finally
    //   52	59	88	finally
    //   64	68	88	finally
    //   76	80	88	finally
  }
  
  public void issueCommand(String paramString, int paramInt)
    throws MessagingException
  {
    try
    {
      sendCommand(paramString);
      if (readServerResponse() != paramInt) {
        throw new MessagingException(this.lastServerResponse);
      }
    }
    finally {}
  }
  
  protected void mailFrom()
    throws MessagingException
  {
    Object localObject2 = null;
    if ((this.message instanceof SMTPMessage)) {
      localObject2 = ((SMTPMessage)this.message).getEnvelopeFrom();
    }
    Object localObject1;
    if (localObject2 != null)
    {
      localObject1 = localObject2;
      if (((String)localObject2).length() > 0) {}
    }
    else
    {
      localObject1 = this.session.getProperty("mail." + this.name + ".from");
    }
    if (localObject1 != null)
    {
      localObject2 = localObject1;
      if (((String)localObject1).length() > 0) {}
    }
    else
    {
      if (this.message == null) {
        break label470;
      }
      localObject1 = this.message.getFrom();
      if ((localObject1 == null) || (localObject1.length <= 0)) {
        break label470;
      }
      localObject1 = localObject1[0];
    }
    for (;;)
    {
      Object localObject3;
      if (localObject1 != null)
      {
        localObject2 = ((InternetAddress)localObject1).getAddress();
        localObject3 = "MAIL FROM:" + normalizeAddress((String)localObject2);
        localObject1 = localObject3;
        if (supportsExtension("DSN"))
        {
          localObject1 = null;
          if ((this.message instanceof SMTPMessage)) {
            localObject1 = ((SMTPMessage)this.message).getDSNRet();
          }
          localObject2 = localObject1;
          if (localObject1 == null) {
            localObject2 = this.session.getProperty("mail." + this.name + ".dsn.ret");
          }
          localObject1 = localObject3;
          if (localObject2 != null) {
            localObject1 = localObject3 + " RET=" + (String)localObject2;
          }
        }
        localObject2 = localObject1;
        if (supportsExtension("AUTH"))
        {
          localObject2 = null;
          if ((this.message instanceof SMTPMessage)) {
            localObject2 = ((SMTPMessage)this.message).getSubmitter();
          }
          localObject3 = localObject2;
          if (localObject2 == null) {
            localObject3 = this.session.getProperty("mail." + this.name + ".submitter");
          }
          localObject2 = localObject1;
          if (localObject3 == null) {}
        }
      }
      try
      {
        localObject2 = xtext((String)localObject3);
        localObject2 = localObject1 + " AUTH=" + (String)localObject2;
        localObject1 = null;
        if ((this.message instanceof SMTPMessage)) {
          localObject1 = ((SMTPMessage)this.message).getMailExtension();
        }
        localObject3 = localObject1;
        if (localObject1 == null) {
          localObject3 = this.session.getProperty("mail." + this.name + ".mailextension");
        }
        localObject1 = localObject2;
        if (localObject3 != null)
        {
          localObject1 = localObject2;
          if (((String)localObject3).length() > 0) {
            localObject1 = localObject2 + " " + (String)localObject3;
          }
        }
        issueSendCommand((String)localObject1, 250);
        return;
        label470:
        localObject1 = InternetAddress.getLocalAddress(this.session);
        continue;
        throw new MessagingException("can't determine local email address");
      }
      catch (IllegalArgumentException localIllegalArgumentException)
      {
        for (;;)
        {
          localObject2 = localObject1;
          if (this.debug)
          {
            this.out.println("DEBUG SMTP: ignoring invalid submitter: " + (String)localObject3 + ", Exception: " + localIllegalArgumentException);
            localObject2 = localObject1;
          }
        }
      }
    }
  }
  
  protected boolean protocolConnect(String paramString1, int paramInt, String paramString2, String paramString3)
    throws MessagingException
  {
    Object localObject = this.session.getProperty("mail." + this.name + ".ehlo");
    boolean bool1;
    if ((localObject != null) && (((String)localObject).equalsIgnoreCase("false")))
    {
      bool1 = false;
      localObject = this.session.getProperty("mail." + this.name + ".auth");
      if ((localObject == null) || (!((String)localObject).equalsIgnoreCase("true"))) {
        break label170;
      }
    }
    label170:
    for (boolean bool2 = true;; bool2 = false)
    {
      if (this.debug) {
        this.out.println("DEBUG SMTP: useEhlo " + bool1 + ", useAuth " + bool2);
      }
      if ((!bool2) || ((paramString2 != null) && (paramString3 != null))) {
        break label176;
      }
      return false;
      bool1 = true;
      break;
    }
    label176:
    int i = paramInt;
    boolean bool3;
    if (paramInt == -1)
    {
      localObject = this.session.getProperty("mail." + this.name + ".port");
      if (localObject != null) {
        i = Integer.parseInt((String)localObject);
      }
    }
    else
    {
      if (paramString1 != null)
      {
        localObject = paramString1;
        if (paramString1.length() != 0) {}
      }
      else
      {
        localObject = "localhost";
      }
      bool3 = false;
      if (this.serverSocket == null) {
        break label642;
      }
      openServer();
    }
    int j;
    int k;
    for (;;)
    {
      if (bool1) {
        bool3 = ehlo(getLocalHost());
      }
      if (!bool3) {
        helo(getLocalHost());
      }
      if ((this.useStartTLS) && (supportsExtension("STARTTLS")))
      {
        startTLS();
        ehlo(getLocalHost());
      }
      if (((!bool2) && ((paramString2 == null) || (paramString3 == null))) || ((!supportsExtension("AUTH")) && (!supportsExtension("AUTH=LOGIN")))) {
        break label1029;
      }
      if (this.debug)
      {
        this.out.println("DEBUG SMTP: Attempt to authenticate");
        if ((!supportsAuthentication("LOGIN")) && (supportsExtension("AUTH=LOGIN"))) {
          this.out.println("DEBUG SMTP: use AUTH=LOGIN hack");
        }
      }
      if ((!supportsAuthentication("LOGIN")) && (!supportsExtension("AUTH=LOGIN"))) {
        break label685;
      }
      i = simpleCommand("AUTH LOGIN");
      paramInt = i;
      if (i == 530)
      {
        startTLS();
        paramInt = simpleCommand("AUTH LOGIN");
      }
      j = paramInt;
      k = paramInt;
      try
      {
        paramString1 = new ByteArrayOutputStream();
        j = paramInt;
        k = paramInt;
        localObject = new BASE64EncoderStream(paramString1, Integer.MAX_VALUE);
        i = paramInt;
        if (paramInt == 334)
        {
          j = paramInt;
          k = paramInt;
          ((OutputStream)localObject).write(ASCIIUtility.getBytes(paramString2));
          j = paramInt;
          k = paramInt;
          ((OutputStream)localObject).flush();
          j = paramInt;
          k = paramInt;
          i = simpleCommand(paramString1.toByteArray());
          j = i;
          k = i;
          paramString1.reset();
        }
        paramInt = i;
        if (i == 334)
        {
          j = i;
          k = i;
          ((OutputStream)localObject).write(ASCIIUtility.getBytes(paramString3));
          j = i;
          k = i;
          ((OutputStream)localObject).flush();
          j = i;
          k = i;
          paramInt = simpleCommand(paramString1.toByteArray());
          j = paramInt;
          k = paramInt;
          paramString1.reset();
        }
      }
      catch (IOException paramString1) {}finally
      {
        label642:
        if (k == 235) {
          break label683;
        }
        closeConnection();
        return false;
      }
      i = this.defaultPort;
      break;
      openServer((String)localObject, i);
    }
    label683:
    label685:
    if (supportsAuthentication("PLAIN"))
    {
      i = simpleCommand("AUTH PLAIN");
      try
      {
        paramString1 = new ByteArrayOutputStream();
        localObject = new BASE64EncoderStream(paramString1, Integer.MAX_VALUE);
        paramInt = i;
        if (i == 334)
        {
          ((OutputStream)localObject).write(0);
          ((OutputStream)localObject).write(ASCIIUtility.getBytes(paramString2));
          ((OutputStream)localObject).write(0);
          ((OutputStream)localObject).write(ASCIIUtility.getBytes(paramString3));
          ((OutputStream)localObject).flush();
          paramInt = simpleCommand(paramString1.toByteArray());
        }
      }
      catch (IOException paramString1) {}finally
      {
        if (i != 235)
        {
          closeConnection();
          return false;
        }
      }
    }
    if (supportsAuthentication("DIGEST-MD5"))
    {
      paramString1 = getMD5();
      if (paramString1 != null)
      {
        j = simpleCommand("AUTH DIGEST-MD5");
        paramInt = j;
        if (j == 334) {
          paramInt = j;
        }
        try
        {
          i = simpleCommand(paramString1.authClient((String)localObject, paramString2, paramString3, getSASLRealm(), this.lastServerResponse));
          paramInt = i;
          if (i == 334)
          {
            paramInt = i;
            j = i;
            bool1 = paramString1.authServer(this.lastServerResponse);
            if (bool1) {
              break label939;
            }
          }
          for (paramInt = -1; paramInt != 235; paramInt = i)
          {
            closeConnection();
            return false;
            label939:
            paramInt = i;
            j = i;
            i = simpleCommand(new byte[0]);
          }
          return true;
        }
        catch (Exception paramString1)
        {
          j = paramInt;
          if (this.debug)
          {
            j = paramInt;
            this.out.println("DEBUG SMTP: DIGEST-MD5: " + paramString1);
          }
        }
        finally
        {
          if (j != 235)
          {
            closeConnection();
            return false;
          }
        }
      }
    }
  }
  
  protected void rcptTo()
    throws MessagingException
  {
    Vector localVector1 = new Vector();
    Vector localVector2 = new Vector();
    Vector localVector3 = new Vector();
    Object localObject4 = null;
    int i = 0;
    this.invalidAddr = null;
    this.validUnsentAddr = null;
    this.validSentAddr = null;
    boolean bool1 = false;
    if ((this.message instanceof SMTPMessage)) {
      bool1 = ((SMTPMessage)this.message).getSendPartial();
    }
    boolean bool2 = bool1;
    Object localObject1;
    int j;
    Object localObject2;
    int k;
    int m;
    if (!bool1)
    {
      localObject1 = this.session.getProperty("mail." + this.name + ".sendpartial");
      if ((localObject1 != null) && (((String)localObject1).equalsIgnoreCase("true"))) {
        bool2 = true;
      }
    }
    else
    {
      if ((this.debug) && (bool2)) {
        this.out.println("DEBUG SMTP: sendPartial set");
      }
      j = 0;
      localObject2 = null;
      localObject1 = null;
      k = j;
      if (supportsExtension("DSN"))
      {
        localObject2 = localObject1;
        if ((this.message instanceof SMTPMessage)) {
          localObject2 = ((SMTPMessage)this.message).getDSNNotify();
        }
        localObject1 = localObject2;
        if (localObject2 == null) {
          localObject1 = this.session.getProperty("mail." + this.name + ".dsn.notify");
        }
        k = j;
        localObject2 = localObject1;
        if (localObject1 != null)
        {
          k = 1;
          localObject2 = localObject1;
        }
      }
      m = 0;
      if (m < this.addresses.length) {
        break label587;
      }
      j = i;
      if (bool2)
      {
        j = i;
        if (localVector1.size() == 0) {
          j = 1;
        }
      }
      if (j == 0) {
        break label1228;
      }
      this.invalidAddr = new Address[localVector3.size()];
      localVector3.copyInto(this.invalidAddr);
      this.validUnsentAddr = new Address[localVector1.size() + localVector2.size()];
      i = 0;
      k = 0;
      label340:
      if (k < localVector1.size()) {
        break label1176;
      }
      k = 0;
      label351:
      if (k < localVector2.size()) {
        break label1202;
      }
      label360:
      if (this.debug)
      {
        if ((this.validSentAddr != null) && (this.validSentAddr.length > 0))
        {
          this.out.println("DEBUG SMTP: Verified Addresses");
          i = 0;
          label394:
          if (i < this.validSentAddr.length) {
            break label1344;
          }
        }
        if ((this.validUnsentAddr != null) && (this.validUnsentAddr.length > 0))
        {
          this.out.println("DEBUG SMTP: Valid Unsent Addresses");
          i = 0;
          label430:
          if (i < this.validUnsentAddr.length) {
            break label1380;
          }
        }
        if ((this.invalidAddr != null) && (this.invalidAddr.length > 0))
        {
          this.out.println("DEBUG SMTP: Invalid Addresses");
          i = 0;
        }
      }
    }
    for (;;)
    {
      if (i >= this.invalidAddr.length)
      {
        if (j == 0) {
          return;
        }
        if (this.debug) {
          this.out.println("DEBUG SMTP: Sending failed because of invalid destination addresses");
        }
        notifyTransportListeners(2, this.validSentAddr, this.validUnsentAddr, this.invalidAddr, this.message);
        localObject1 = this.lastServerResponse;
        i = this.lastReturnCode;
      }
      try
      {
        if (this.serverSocket != null) {
          issueCommand("RSET", 250);
        }
      }
      catch (MessagingException localMessagingException1)
      {
        try
        {
          InternetAddress localInternetAddress;
          Object localObject5;
          int n;
          close();
        }
        catch (MessagingException localMessagingException2)
        {
          for (;;)
          {
            if (this.debug) {
              localMessagingException2.printStackTrace(this.out);
            }
          }
        }
      }
      finally
      {
        this.lastServerResponse = ((String)localObject1);
        this.lastReturnCode = i;
      }
      throw new SendFailedException("Invalid Addresses", (Exception)localObject4, this.validSentAddr, this.validUnsentAddr, this.invalidAddr);
      bool2 = false;
      break;
      label587:
      localInternetAddress = (InternetAddress)this.addresses[m];
      localObject1 = "RCPT TO:" + normalizeAddress(localInternetAddress.getAddress());
      localObject5 = localObject1;
      if (k != 0) {
        localObject5 = localObject1 + " NOTIFY=" + (String)localObject2;
      }
      sendCommand((String)localObject5);
      n = readServerResponse();
      switch (n)
      {
      default: 
        if ((n >= 400) && (n <= 499))
        {
          localVector2.addElement(localInternetAddress);
          label799:
          if (!bool2) {
            i = 1;
          }
          localObject1 = new SMTPAddressFailedException(localInternetAddress, (String)localObject5, n, this.lastServerResponse);
          if (localObject4 != null) {
            break label1159;
          }
          j = i;
        }
        break;
      }
      for (;;)
      {
        m += 1;
        localObject4 = localObject1;
        i = j;
        break;
        localVector1.addElement(localInternetAddress);
        localObject1 = localObject4;
        j = i;
        if (this.reportSuccess)
        {
          localObject1 = new SMTPAddressSucceededException(localInternetAddress, (String)localObject5, n, this.lastServerResponse);
          if (localObject4 == null)
          {
            j = i;
          }
          else
          {
            ((MessagingException)localObject4).setNextException((Exception)localObject1);
            localObject1 = localObject4;
            j = i;
            continue;
            if (!bool2) {
              i = 1;
            }
            localVector3.addElement(localInternetAddress);
            localObject1 = new SMTPAddressFailedException(localInternetAddress, (String)localObject5, n, this.lastServerResponse);
            if (localObject4 == null)
            {
              j = i;
            }
            else
            {
              ((MessagingException)localObject4).setNextException((Exception)localObject1);
              localObject1 = localObject4;
              j = i;
              continue;
              if (!bool2) {
                i = 1;
              }
              localVector2.addElement(localInternetAddress);
              localObject1 = new SMTPAddressFailedException(localInternetAddress, (String)localObject5, n, this.lastServerResponse);
              if (localObject4 == null)
              {
                j = i;
              }
              else
              {
                ((MessagingException)localObject4).setNextException((Exception)localObject1);
                localObject1 = localObject4;
                j = i;
                continue;
                if ((n >= 500) && (n <= 599))
                {
                  localVector3.addElement(localInternetAddress);
                  break label799;
                }
                if (this.debug) {
                  this.out.println("DEBUG SMTP: got response code " + n + ", with response: " + this.lastServerResponse);
                }
                localObject1 = this.lastServerResponse;
                i = this.lastReturnCode;
                if (this.serverSocket != null) {
                  issueCommand("RSET", 250);
                }
                this.lastServerResponse = ((String)localObject1);
                this.lastReturnCode = i;
                throw new SMTPAddressFailedException(localInternetAddress, (String)localObject5, n, (String)localObject1);
                label1159:
                ((MessagingException)localObject4).setNextException((Exception)localObject1);
                localObject1 = localObject4;
                j = i;
              }
            }
          }
        }
      }
      label1176:
      this.validUnsentAddr[i] = ((Address)localVector1.elementAt(k));
      k += 1;
      i += 1;
      break label340;
      label1202:
      this.validUnsentAddr[i] = ((Address)localVector2.elementAt(k));
      k += 1;
      i += 1;
      break label351;
      label1228:
      if ((this.reportSuccess) || ((bool2) && ((localVector3.size() > 0) || (localVector2.size() > 0))))
      {
        this.sendPartiallyFailed = true;
        this.exception = ((MessagingException)localObject4);
        this.invalidAddr = new Address[localVector3.size()];
        localVector3.copyInto(this.invalidAddr);
        this.validUnsentAddr = new Address[localVector2.size()];
        localVector2.copyInto(this.validUnsentAddr);
        this.validSentAddr = new Address[localVector1.size()];
        localVector1.copyInto(this.validSentAddr);
        break label360;
      }
      this.validSentAddr = this.addresses;
      break label360;
      label1344:
      this.out.println("DEBUG SMTP:   " + this.validSentAddr[i]);
      i += 1;
      break label394;
      label1380:
      this.out.println("DEBUG SMTP:   " + this.validUnsentAddr[i]);
      i += 1;
      break label430;
      this.out.println("DEBUG SMTP:   " + this.invalidAddr[i]);
      i += 1;
    }
  }
  
  /* Error */
  protected int readServerResponse()
    throws MessagingException
  {
    // Byte code:
    //   0: getstatic 63	com/sun/mail/smtp/SMTPTransport:$assertionsDisabled	Z
    //   3: ifne +18 -> 21
    //   6: aload_0
    //   7: invokestatic 489	java/lang/Thread:holdsLock	(Ljava/lang/Object;)Z
    //   10: ifne +11 -> 21
    //   13: new 491	java/lang/AssertionError
    //   16: dup
    //   17: invokespecial 492	java/lang/AssertionError:<init>	()V
    //   20: athrow
    //   21: new 505	java/lang/StringBuffer
    //   24: dup
    //   25: bipush 100
    //   27: invokespecial 514	java/lang/StringBuffer:<init>	(I)V
    //   30: astore_2
    //   31: aload_0
    //   32: getfield 185	com/sun/mail/smtp/SMTPTransport:lineInputStream	Lcom/sun/mail/util/LineInputStream;
    //   35: invokevirtual 885	com/sun/mail/util/LineInputStream:readLine	()Ljava/lang/String;
    //   38: astore_3
    //   39: aload_3
    //   40: ifnonnull +64 -> 104
    //   43: aload_2
    //   44: invokevirtual 506	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   47: astore_3
    //   48: aload_3
    //   49: astore_2
    //   50: aload_3
    //   51: invokevirtual 363	java/lang/String:length	()I
    //   54: ifne +7 -> 61
    //   57: ldc_w 887
    //   60: astore_2
    //   61: aload_0
    //   62: aload_2
    //   63: putfield 396	com/sun/mail/smtp/SMTPTransport:lastServerResponse	Ljava/lang/String;
    //   66: aload_0
    //   67: iconst_m1
    //   68: putfield 398	com/sun/mail/smtp/SMTPTransport:lastReturnCode	I
    //   71: aload_0
    //   72: getfield 288	com/sun/mail/smtp/SMTPTransport:debug	Z
    //   75: ifeq +245 -> 320
    //   78: aload_0
    //   79: getfield 129	com/sun/mail/smtp/SMTPTransport:out	Ljava/io/PrintStream;
    //   82: new 131	java/lang/StringBuilder
    //   85: dup
    //   86: ldc_w 889
    //   89: invokespecial 136	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   92: aload_2
    //   93: invokevirtual 140	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   96: invokevirtual 145	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   99: invokevirtual 359	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   102: iconst_m1
    //   103: ireturn
    //   104: aload_2
    //   105: aload_3
    //   106: invokevirtual 521	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   109: pop
    //   110: aload_2
    //   111: ldc_w 450
    //   114: invokevirtual 521	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   117: pop
    //   118: aload_0
    //   119: aload_3
    //   120: invokespecial 891	com/sun/mail/smtp/SMTPTransport:isNotLastLine	(Ljava/lang/String;)Z
    //   123: ifne -92 -> 31
    //   126: aload_2
    //   127: invokevirtual 506	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   130: astore_2
    //   131: aload_2
    //   132: ifnull +183 -> 315
    //   135: aload_2
    //   136: invokevirtual 363	java/lang/String:length	()I
    //   139: iconst_3
    //   140: if_icmplt +175 -> 315
    //   143: aload_2
    //   144: iconst_0
    //   145: iconst_3
    //   146: invokevirtual 518	java/lang/String:substring	(II)Ljava/lang/String;
    //   149: invokestatic 741	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   152: istore_1
    //   153: iload_1
    //   154: iconst_m1
    //   155: if_icmpne +34 -> 189
    //   158: aload_0
    //   159: getfield 288	com/sun/mail/smtp/SMTPTransport:debug	Z
    //   162: ifeq +27 -> 189
    //   165: aload_0
    //   166: getfield 129	com/sun/mail/smtp/SMTPTransport:out	Ljava/io/PrintStream;
    //   169: new 131	java/lang/StringBuilder
    //   172: dup
    //   173: ldc_w 893
    //   176: invokespecial 136	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   179: aload_2
    //   180: invokevirtual 140	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   183: invokevirtual 145	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   186: invokevirtual 359	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   189: aload_0
    //   190: aload_2
    //   191: putfield 396	com/sun/mail/smtp/SMTPTransport:lastServerResponse	Ljava/lang/String;
    //   194: aload_0
    //   195: iload_1
    //   196: putfield 398	com/sun/mail/smtp/SMTPTransport:lastReturnCode	I
    //   199: iload_1
    //   200: ireturn
    //   201: astore_2
    //   202: aload_0
    //   203: getfield 288	com/sun/mail/smtp/SMTPTransport:debug	Z
    //   206: ifeq +27 -> 233
    //   209: aload_0
    //   210: getfield 129	com/sun/mail/smtp/SMTPTransport:out	Ljava/io/PrintStream;
    //   213: new 131	java/lang/StringBuilder
    //   216: dup
    //   217: ldc_w 895
    //   220: invokespecial 136	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   223: aload_2
    //   224: invokevirtual 721	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   227: invokevirtual 145	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   230: invokevirtual 359	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   233: aload_0
    //   234: ldc_w 580
    //   237: putfield 396	com/sun/mail/smtp/SMTPTransport:lastServerResponse	Ljava/lang/String;
    //   240: aload_0
    //   241: iconst_0
    //   242: putfield 398	com/sun/mail/smtp/SMTPTransport:lastReturnCode	I
    //   245: new 170	javax/mail/MessagingException
    //   248: dup
    //   249: ldc_w 897
    //   252: aload_2
    //   253: invokespecial 194	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   256: athrow
    //   257: astore_3
    //   258: aload_0
    //   259: invokevirtual 877	com/sun/mail/smtp/SMTPTransport:close	()V
    //   262: iconst_m1
    //   263: istore_1
    //   264: goto -111 -> 153
    //   267: astore_3
    //   268: aload_0
    //   269: getfield 288	com/sun/mail/smtp/SMTPTransport:debug	Z
    //   272: ifeq -10 -> 262
    //   275: aload_3
    //   276: aload_0
    //   277: getfield 129	com/sun/mail/smtp/SMTPTransport:out	Ljava/io/PrintStream;
    //   280: invokevirtual 880	javax/mail/MessagingException:printStackTrace	(Ljava/io/PrintStream;)V
    //   283: goto -21 -> 262
    //   286: astore_3
    //   287: aload_0
    //   288: invokevirtual 877	com/sun/mail/smtp/SMTPTransport:close	()V
    //   291: iconst_m1
    //   292: istore_1
    //   293: goto -140 -> 153
    //   296: astore_3
    //   297: aload_0
    //   298: getfield 288	com/sun/mail/smtp/SMTPTransport:debug	Z
    //   301: ifeq -10 -> 291
    //   304: aload_3
    //   305: aload_0
    //   306: getfield 129	com/sun/mail/smtp/SMTPTransport:out	Ljava/io/PrintStream;
    //   309: invokevirtual 880	javax/mail/MessagingException:printStackTrace	(Ljava/io/PrintStream;)V
    //   312: goto -21 -> 291
    //   315: iconst_m1
    //   316: istore_1
    //   317: goto -164 -> 153
    //   320: iconst_m1
    //   321: ireturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	322	0	this	SMTPTransport
    //   152	165	1	i	int
    //   30	161	2	localObject	Object
    //   201	52	2	localIOException	IOException
    //   38	82	3	str	String
    //   257	1	3	localNumberFormatException	NumberFormatException
    //   267	9	3	localMessagingException1	MessagingException
    //   286	1	3	localStringIndexOutOfBoundsException	StringIndexOutOfBoundsException
    //   296	9	3	localMessagingException2	MessagingException
    // Exception table:
    //   from	to	target	type
    //   31	39	201	java/io/IOException
    //   43	48	201	java/io/IOException
    //   50	57	201	java/io/IOException
    //   61	102	201	java/io/IOException
    //   104	131	201	java/io/IOException
    //   143	153	257	java/lang/NumberFormatException
    //   258	262	267	javax/mail/MessagingException
    //   143	153	286	java/lang/StringIndexOutOfBoundsException
    //   287	291	296	javax/mail/MessagingException
  }
  
  protected void sendCommand(String paramString)
    throws MessagingException
  {
    sendCommand(ASCIIUtility.getBytes(paramString));
  }
  
  /* Error */
  public void sendMessage(javax.mail.Message paramMessage, Address[] paramArrayOfAddress)
    throws MessagingException, SendFailedException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual 903	com/sun/mail/smtp/SMTPTransport:checkConnected	()V
    //   6: aload_1
    //   7: instanceof 663
    //   10: ifne +36 -> 46
    //   13: aload_0
    //   14: getfield 288	com/sun/mail/smtp/SMTPTransport:debug	Z
    //   17: ifeq +13 -> 30
    //   20: aload_0
    //   21: getfield 129	com/sun/mail/smtp/SMTPTransport:out	Ljava/io/PrintStream;
    //   24: ldc_w 905
    //   27: invokevirtual 359	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   30: new 170	javax/mail/MessagingException
    //   33: dup
    //   34: ldc_w 907
    //   37: invokespecial 455	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   40: athrow
    //   41: astore_1
    //   42: aload_0
    //   43: monitorexit
    //   44: aload_1
    //   45: athrow
    //   46: iconst_0
    //   47: istore_3
    //   48: iload_3
    //   49: aload_2
    //   50: arraylength
    //   51: if_icmplt +354 -> 405
    //   54: aload_0
    //   55: aload_1
    //   56: checkcast 663	javax/mail/internet/MimeMessage
    //   59: putfield 654	com/sun/mail/smtp/SMTPTransport:message	Ljavax/mail/internet/MimeMessage;
    //   62: aload_0
    //   63: aload_2
    //   64: putfield 257	com/sun/mail/smtp/SMTPTransport:addresses	[Ljavax/mail/Address;
    //   67: aload_0
    //   68: aload_2
    //   69: putfield 379	com/sun/mail/smtp/SMTPTransport:validUnsentAddr	[Ljavax/mail/Address;
    //   72: aload_0
    //   73: invokespecial 909	com/sun/mail/smtp/SMTPTransport:expandGroups	()V
    //   76: iconst_0
    //   77: istore 4
    //   79: aload_1
    //   80: instanceof 656
    //   83: ifeq +12 -> 95
    //   86: aload_1
    //   87: checkcast 656	com/sun/mail/smtp/SMTPMessage
    //   90: invokevirtual 912	com/sun/mail/smtp/SMTPMessage:getAllow8bitMIME	()Z
    //   93: istore 4
    //   95: iload 4
    //   97: istore 5
    //   99: iload 4
    //   101: ifne +52 -> 153
    //   104: aload_0
    //   105: getfield 298	com/sun/mail/smtp/SMTPTransport:session	Ljavax/mail/Session;
    //   108: new 131	java/lang/StringBuilder
    //   111: dup
    //   112: ldc -123
    //   114: invokespecial 136	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   117: aload_0
    //   118: getfield 105	com/sun/mail/smtp/SMTPTransport:name	Ljava/lang/String;
    //   121: invokevirtual 140	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   124: ldc_w 914
    //   127: invokevirtual 140	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   130: invokevirtual 145	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   133: invokevirtual 149	javax/mail/Session:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   136: astore_1
    //   137: aload_1
    //   138: ifnull +313 -> 451
    //   141: aload_1
    //   142: ldc -105
    //   144: invokevirtual 155	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   147: ifeq +304 -> 451
    //   150: iconst_1
    //   151: istore 5
    //   153: aload_0
    //   154: getfield 288	com/sun/mail/smtp/SMTPTransport:debug	Z
    //   157: ifeq +28 -> 185
    //   160: aload_0
    //   161: getfield 129	com/sun/mail/smtp/SMTPTransport:out	Ljava/io/PrintStream;
    //   164: new 131	java/lang/StringBuilder
    //   167: dup
    //   168: ldc_w 916
    //   171: invokespecial 136	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   174: iload 5
    //   176: invokevirtual 468	java/lang/StringBuilder:append	(Z)Ljava/lang/StringBuilder;
    //   179: invokevirtual 145	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   182: invokevirtual 359	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   185: iload 5
    //   187: ifeq +35 -> 222
    //   190: aload_0
    //   191: ldc_w 918
    //   194: invokevirtual 679	com/sun/mail/smtp/SMTPTransport:supportsExtension	(Ljava/lang/String;)Z
    //   197: ifeq +25 -> 222
    //   200: aload_0
    //   201: aload_0
    //   202: getfield 654	com/sun/mail/smtp/SMTPTransport:message	Ljavax/mail/internet/MimeMessage;
    //   205: invokespecial 252	com/sun/mail/smtp/SMTPTransport:convertTo8Bit	(Ljavax/mail/internet/MimePart;)Z
    //   208: istore 4
    //   210: iload 4
    //   212: ifeq +10 -> 222
    //   215: aload_0
    //   216: getfield 654	com/sun/mail/smtp/SMTPTransport:message	Ljavax/mail/internet/MimeMessage;
    //   219: invokevirtual 921	javax/mail/internet/MimeMessage:saveChanges	()V
    //   222: aload_0
    //   223: invokevirtual 923	com/sun/mail/smtp/SMTPTransport:mailFrom	()V
    //   226: aload_0
    //   227: invokevirtual 925	com/sun/mail/smtp/SMTPTransport:rcptTo	()V
    //   230: aload_0
    //   231: getfield 654	com/sun/mail/smtp/SMTPTransport:message	Ljavax/mail/internet/MimeMessage;
    //   234: aload_0
    //   235: invokevirtual 927	com/sun/mail/smtp/SMTPTransport:data	()Ljava/io/OutputStream;
    //   238: getstatic 71	com/sun/mail/smtp/SMTPTransport:ignoreList	[Ljava/lang/String;
    //   241: invokevirtual 931	javax/mail/internet/MimeMessage:writeTo	(Ljava/io/OutputStream;[Ljava/lang/String;)V
    //   244: aload_0
    //   245: invokevirtual 933	com/sun/mail/smtp/SMTPTransport:finishData	()V
    //   248: aload_0
    //   249: getfield 111	com/sun/mail/smtp/SMTPTransport:sendPartiallyFailed	Z
    //   252: ifeq +205 -> 457
    //   255: aload_0
    //   256: getfield 288	com/sun/mail/smtp/SMTPTransport:debug	Z
    //   259: ifeq +13 -> 272
    //   262: aload_0
    //   263: getfield 129	com/sun/mail/smtp/SMTPTransport:out	Ljava/io/PrintStream;
    //   266: ldc_w 935
    //   269: invokevirtual 359	java/io/PrintStream:println	(Ljava/lang/String;)V
    //   272: aload_0
    //   273: iconst_3
    //   274: aload_0
    //   275: getfield 377	com/sun/mail/smtp/SMTPTransport:validSentAddr	[Ljavax/mail/Address;
    //   278: aload_0
    //   279: getfield 379	com/sun/mail/smtp/SMTPTransport:validUnsentAddr	[Ljavax/mail/Address;
    //   282: aload_0
    //   283: getfield 409	com/sun/mail/smtp/SMTPTransport:invalidAddr	[Ljavax/mail/Address;
    //   286: aload_0
    //   287: getfield 654	com/sun/mail/smtp/SMTPTransport:message	Ljavax/mail/internet/MimeMessage;
    //   290: invokevirtual 847	com/sun/mail/smtp/SMTPTransport:notifyTransportListeners	(I[Ljavax/mail/Address;[Ljavax/mail/Address;[Ljavax/mail/Address;Ljavax/mail/Message;)V
    //   293: new 405	com/sun/mail/smtp/SMTPSendFailedException
    //   296: dup
    //   297: ldc_w 611
    //   300: aload_0
    //   301: getfield 398	com/sun/mail/smtp/SMTPTransport:lastReturnCode	I
    //   304: aload_0
    //   305: getfield 396	com/sun/mail/smtp/SMTPTransport:lastServerResponse	Ljava/lang/String;
    //   308: aload_0
    //   309: getfield 407	com/sun/mail/smtp/SMTPTransport:exception	Ljavax/mail/MessagingException;
    //   312: aload_0
    //   313: getfield 377	com/sun/mail/smtp/SMTPTransport:validSentAddr	[Ljavax/mail/Address;
    //   316: aload_0
    //   317: getfield 379	com/sun/mail/smtp/SMTPTransport:validUnsentAddr	[Ljavax/mail/Address;
    //   320: aload_0
    //   321: getfield 409	com/sun/mail/smtp/SMTPTransport:invalidAddr	[Ljavax/mail/Address;
    //   324: invokespecial 412	com/sun/mail/smtp/SMTPSendFailedException:<init>	(Ljava/lang/String;ILjava/lang/String;Ljava/lang/Exception;[Ljavax/mail/Address;[Ljavax/mail/Address;[Ljavax/mail/Address;)V
    //   327: athrow
    //   328: astore_1
    //   329: aload_0
    //   330: getfield 288	com/sun/mail/smtp/SMTPTransport:debug	Z
    //   333: ifeq +11 -> 344
    //   336: aload_1
    //   337: aload_0
    //   338: getfield 129	com/sun/mail/smtp/SMTPTransport:out	Ljava/io/PrintStream;
    //   341: invokevirtual 880	javax/mail/MessagingException:printStackTrace	(Ljava/io/PrintStream;)V
    //   344: aload_0
    //   345: iconst_2
    //   346: aload_0
    //   347: getfield 377	com/sun/mail/smtp/SMTPTransport:validSentAddr	[Ljavax/mail/Address;
    //   350: aload_0
    //   351: getfield 379	com/sun/mail/smtp/SMTPTransport:validUnsentAddr	[Ljavax/mail/Address;
    //   354: aload_0
    //   355: getfield 409	com/sun/mail/smtp/SMTPTransport:invalidAddr	[Ljavax/mail/Address;
    //   358: aload_0
    //   359: getfield 654	com/sun/mail/smtp/SMTPTransport:message	Ljavax/mail/internet/MimeMessage;
    //   362: invokevirtual 847	com/sun/mail/smtp/SMTPTransport:notifyTransportListeners	(I[Ljavax/mail/Address;[Ljavax/mail/Address;[Ljavax/mail/Address;Ljavax/mail/Message;)V
    //   365: aload_1
    //   366: athrow
    //   367: astore_1
    //   368: aload_0
    //   369: aconst_null
    //   370: putfield 409	com/sun/mail/smtp/SMTPTransport:invalidAddr	[Ljavax/mail/Address;
    //   373: aload_0
    //   374: aconst_null
    //   375: putfield 379	com/sun/mail/smtp/SMTPTransport:validUnsentAddr	[Ljavax/mail/Address;
    //   378: aload_0
    //   379: aconst_null
    //   380: putfield 377	com/sun/mail/smtp/SMTPTransport:validSentAddr	[Ljavax/mail/Address;
    //   383: aload_0
    //   384: aconst_null
    //   385: putfield 257	com/sun/mail/smtp/SMTPTransport:addresses	[Ljavax/mail/Address;
    //   388: aload_0
    //   389: aconst_null
    //   390: putfield 654	com/sun/mail/smtp/SMTPTransport:message	Ljavax/mail/internet/MimeMessage;
    //   393: aload_0
    //   394: aconst_null
    //   395: putfield 407	com/sun/mail/smtp/SMTPTransport:exception	Ljavax/mail/MessagingException;
    //   398: aload_0
    //   399: iconst_0
    //   400: putfield 111	com/sun/mail/smtp/SMTPTransport:sendPartiallyFailed	Z
    //   403: aload_1
    //   404: athrow
    //   405: aload_2
    //   406: iload_3
    //   407: aaload
    //   408: instanceof 264
    //   411: ifne +33 -> 444
    //   414: new 170	javax/mail/MessagingException
    //   417: dup
    //   418: new 131	java/lang/StringBuilder
    //   421: dup
    //   422: invokespecial 936	java/lang/StringBuilder:<init>	()V
    //   425: aload_2
    //   426: iload_3
    //   427: aaload
    //   428: invokevirtual 721	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   431: ldc_w 938
    //   434: invokevirtual 140	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   437: invokevirtual 145	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   440: invokespecial 455	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   443: athrow
    //   444: iload_3
    //   445: iconst_1
    //   446: iadd
    //   447: istore_3
    //   448: goto -400 -> 48
    //   451: iconst_0
    //   452: istore 5
    //   454: goto -301 -> 153
    //   457: aload_0
    //   458: iconst_1
    //   459: aload_0
    //   460: getfield 377	com/sun/mail/smtp/SMTPTransport:validSentAddr	[Ljavax/mail/Address;
    //   463: aload_0
    //   464: getfield 379	com/sun/mail/smtp/SMTPTransport:validUnsentAddr	[Ljavax/mail/Address;
    //   467: aload_0
    //   468: getfield 409	com/sun/mail/smtp/SMTPTransport:invalidAddr	[Ljavax/mail/Address;
    //   471: aload_0
    //   472: getfield 654	com/sun/mail/smtp/SMTPTransport:message	Ljavax/mail/internet/MimeMessage;
    //   475: invokevirtual 847	com/sun/mail/smtp/SMTPTransport:notifyTransportListeners	(I[Ljavax/mail/Address;[Ljavax/mail/Address;[Ljavax/mail/Address;Ljavax/mail/Message;)V
    //   478: aload_0
    //   479: aconst_null
    //   480: putfield 409	com/sun/mail/smtp/SMTPTransport:invalidAddr	[Ljavax/mail/Address;
    //   483: aload_0
    //   484: aconst_null
    //   485: putfield 379	com/sun/mail/smtp/SMTPTransport:validUnsentAddr	[Ljavax/mail/Address;
    //   488: aload_0
    //   489: aconst_null
    //   490: putfield 377	com/sun/mail/smtp/SMTPTransport:validSentAddr	[Ljavax/mail/Address;
    //   493: aload_0
    //   494: aconst_null
    //   495: putfield 257	com/sun/mail/smtp/SMTPTransport:addresses	[Ljavax/mail/Address;
    //   498: aload_0
    //   499: aconst_null
    //   500: putfield 654	com/sun/mail/smtp/SMTPTransport:message	Ljavax/mail/internet/MimeMessage;
    //   503: aload_0
    //   504: aconst_null
    //   505: putfield 407	com/sun/mail/smtp/SMTPTransport:exception	Ljavax/mail/MessagingException;
    //   508: aload_0
    //   509: iconst_0
    //   510: putfield 111	com/sun/mail/smtp/SMTPTransport:sendPartiallyFailed	Z
    //   513: aload_0
    //   514: monitorexit
    //   515: return
    //   516: astore_1
    //   517: aload_0
    //   518: getfield 288	com/sun/mail/smtp/SMTPTransport:debug	Z
    //   521: ifeq +11 -> 532
    //   524: aload_1
    //   525: aload_0
    //   526: getfield 129	com/sun/mail/smtp/SMTPTransport:out	Ljava/io/PrintStream;
    //   529: invokevirtual 939	java/io/IOException:printStackTrace	(Ljava/io/PrintStream;)V
    //   532: aload_0
    //   533: invokespecial 536	com/sun/mail/smtp/SMTPTransport:closeConnection	()V
    //   536: aload_0
    //   537: iconst_2
    //   538: aload_0
    //   539: getfield 377	com/sun/mail/smtp/SMTPTransport:validSentAddr	[Ljavax/mail/Address;
    //   542: aload_0
    //   543: getfield 379	com/sun/mail/smtp/SMTPTransport:validUnsentAddr	[Ljavax/mail/Address;
    //   546: aload_0
    //   547: getfield 409	com/sun/mail/smtp/SMTPTransport:invalidAddr	[Ljavax/mail/Address;
    //   550: aload_0
    //   551: getfield 654	com/sun/mail/smtp/SMTPTransport:message	Ljavax/mail/internet/MimeMessage;
    //   554: invokevirtual 847	com/sun/mail/smtp/SMTPTransport:notifyTransportListeners	(I[Ljavax/mail/Address;[Ljavax/mail/Address;[Ljavax/mail/Address;Ljavax/mail/Message;)V
    //   557: new 170	javax/mail/MessagingException
    //   560: dup
    //   561: ldc_w 941
    //   564: aload_1
    //   565: invokespecial 194	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   568: athrow
    //   569: astore_2
    //   570: goto -34 -> 536
    //   573: astore_1
    //   574: goto -352 -> 222
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	577	0	this	SMTPTransport
    //   0	577	1	paramMessage	javax.mail.Message
    //   0	577	2	paramArrayOfAddress	Address[]
    //   47	401	3	i	int
    //   77	134	4	bool1	boolean
    //   97	356	5	bool2	boolean
    // Exception table:
    //   from	to	target	type
    //   2	30	41	finally
    //   30	41	41	finally
    //   48	76	41	finally
    //   79	95	41	finally
    //   104	137	41	finally
    //   141	150	41	finally
    //   153	185	41	finally
    //   190	210	41	finally
    //   215	222	41	finally
    //   368	405	41	finally
    //   405	444	41	finally
    //   478	513	41	finally
    //   222	272	328	javax/mail/MessagingException
    //   272	328	328	javax/mail/MessagingException
    //   457	478	328	javax/mail/MessagingException
    //   222	272	367	finally
    //   272	328	367	finally
    //   329	344	367	finally
    //   344	367	367	finally
    //   457	478	367	finally
    //   517	532	367	finally
    //   532	536	367	finally
    //   536	569	367	finally
    //   222	272	516	java/io/IOException
    //   272	328	516	java/io/IOException
    //   457	478	516	java/io/IOException
    //   532	536	569	javax/mail/MessagingException
    //   215	222	573	javax/mail/MessagingException
  }
  
  public void setLocalHost(String paramString)
  {
    try
    {
      this.localHostName = paramString;
      return;
    }
    finally
    {
      paramString = finally;
      throw paramString;
    }
  }
  
  public void setReportSuccess(boolean paramBoolean)
  {
    try
    {
      this.reportSuccess = paramBoolean;
      return;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public void setSASLRealm(String paramString)
  {
    try
    {
      this.saslRealm = paramString;
      return;
    }
    finally
    {
      paramString = finally;
      throw paramString;
    }
  }
  
  public void setStartTLS(boolean paramBoolean)
  {
    try
    {
      this.useStartTLS = paramBoolean;
      return;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public void setUseRset(boolean paramBoolean)
  {
    try
    {
      this.useRset = paramBoolean;
      return;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public int simpleCommand(String paramString)
    throws MessagingException
  {
    try
    {
      sendCommand(paramString);
      int i = readServerResponse();
      return i;
    }
    finally
    {
      paramString = finally;
      throw paramString;
    }
  }
  
  protected int simpleCommand(byte[] paramArrayOfByte)
    throws MessagingException
  {
    assert (Thread.holdsLock(this));
    sendCommand(paramArrayOfByte);
    return readServerResponse();
  }
  
  protected void startTLS()
    throws MessagingException
  {
    issueCommand("STARTTLS", 220);
    try
    {
      this.serverSocket = SocketFetcher.startTLS(this.serverSocket, this.session.getProperties(), "mail." + this.name);
      initStreams();
      return;
    }
    catch (IOException localIOException)
    {
      closeConnection();
      throw new MessagingException("Could not convert socket to TLS", localIOException);
    }
  }
  
  protected boolean supportsAuthentication(String paramString)
  {
    assert (Thread.holdsLock(this));
    if (this.extMap == null) {}
    Object localObject;
    do
    {
      while (!((StringTokenizer)localObject).hasMoreTokens())
      {
        do
        {
          return false;
          localObject = (String)this.extMap.get("AUTH");
        } while (localObject == null);
        localObject = new StringTokenizer((String)localObject);
      }
    } while (!((StringTokenizer)localObject).nextToken().equalsIgnoreCase(paramString));
    return true;
  }
  
  public boolean supportsExtension(String paramString)
  {
    return (this.extMap != null) && (this.extMap.get(paramString.toUpperCase(Locale.ENGLISH)) != null);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/smtp/SMTPTransport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */