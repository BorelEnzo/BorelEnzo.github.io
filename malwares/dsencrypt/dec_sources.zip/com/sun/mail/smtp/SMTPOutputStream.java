package com.sun.mail.smtp;

import com.sun.mail.util.CRLFOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class SMTPOutputStream
  extends CRLFOutputStream
{
  public SMTPOutputStream(OutputStream paramOutputStream)
  {
    super(paramOutputStream);
  }
  
  public void ensureAtBOL()
    throws IOException
  {
    if (!this.atBOL) {
      super.writeln();
    }
  }
  
  public void flush() {}
  
  public void write(int paramInt)
    throws IOException
  {
    if (((this.lastb == 10) || (this.lastb == 13) || (this.lastb == -1)) && (paramInt == 46)) {
      this.out.write(46);
    }
    super.write(paramInt);
  }
  
  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i;
    int j;
    int k;
    if (this.lastb == -1)
    {
      i = 10;
      j = paramInt1;
      k = paramInt2 + paramInt1;
      paramInt2 = j;
      j = i;
    }
    for (;;)
    {
      if (paramInt1 >= k)
      {
        if (k - paramInt2 > 0) {
          super.write(paramArrayOfByte, paramInt2, k - paramInt2);
        }
        return;
        i = this.lastb;
        break;
      }
      if (j != 10)
      {
        i = paramInt2;
        if (j != 13) {}
      }
      else
      {
        i = paramInt2;
        if (paramArrayOfByte[paramInt1] == 46)
        {
          super.write(paramArrayOfByte, paramInt2, paramInt1 - paramInt2);
          this.out.write(46);
          i = paramInt1;
        }
      }
      j = paramArrayOfByte[paramInt1];
      paramInt1 += 1;
      paramInt2 = i;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/smtp/SMTPOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */