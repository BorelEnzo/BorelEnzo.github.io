package com.sun.mail.smtp;

import javax.mail.Session;
import javax.mail.URLName;

public class SMTPSSLTransport
  extends SMTPTransport
{
  public SMTPSSLTransport(Session paramSession, URLName paramURLName)
  {
    super(paramSession, paramURLName, "smtps", 465, true);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/smtp/SMTPSSLTransport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */