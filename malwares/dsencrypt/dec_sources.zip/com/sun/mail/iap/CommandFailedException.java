package com.sun.mail.iap;

public class CommandFailedException
  extends ProtocolException
{
  private static final long serialVersionUID = 793932807880443631L;
  
  public CommandFailedException() {}
  
  public CommandFailedException(Response paramResponse)
  {
    super(paramResponse);
  }
  
  public CommandFailedException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/iap/CommandFailedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */