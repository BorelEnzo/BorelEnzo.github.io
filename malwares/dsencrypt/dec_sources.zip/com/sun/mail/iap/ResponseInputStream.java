package com.sun.mail.iap;

import com.sun.mail.util.ASCIIUtility;
import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;

public class ResponseInputStream
{
  private static final int incrementSlop = 16;
  private static final int maxIncrement = 262144;
  private static final int minIncrement = 256;
  private BufferedInputStream bin;
  
  public ResponseInputStream(InputStream paramInputStream)
  {
    this.bin = new BufferedInputStream(paramInputStream, 2048);
  }
  
  public ByteArray readResponse()
    throws IOException
  {
    return readResponse(null);
  }
  
  public ByteArray readResponse(ByteArray paramByteArray)
    throws IOException
  {
    ByteArray localByteArray = paramByteArray;
    if (paramByteArray == null) {
      localByteArray = new ByteArray(new byte[''], 0, 128);
    }
    paramByteArray = localByteArray.getBytes();
    int i;
    label190:
    label205:
    label222:
    label346:
    label358:
    label367:
    for (int j = 0;; j = i)
    {
      int k = 0;
      int m = 0;
      i = j;
      j = k;
      if (m == 0)
      {
        j = this.bin.read();
        if (j != -1) {}
      }
      else
      {
        if (j != -1) {
          break label190;
        }
        throw new IOException();
      }
      switch (j)
      {
      default: 
        k = m;
      }
      Object localObject;
      for (;;)
      {
        localObject = paramByteArray;
        if (i >= paramByteArray.length)
        {
          int n = paramByteArray.length;
          m = n;
          if (n > 262144) {
            m = 262144;
          }
          localByteArray.grow(m);
          localObject = localByteArray.getBytes();
        }
        localObject[i] = ((byte)j);
        i += 1;
        paramByteArray = (ByteArray)localObject;
        m = k;
        break;
        k = m;
        if (i > 0)
        {
          k = m;
          if (paramByteArray[(i - 1)] == 13) {
            k = 1;
          }
        }
      }
      if ((i < 5) || (paramByteArray[(i - 3)] != 125)) {}
      do
      {
        localByteArray.setCount(i);
        return localByteArray;
        j = i - 4;
      } while ((j < 0) && (j < 0));
      for (;;)
      {
        try
        {
          j = ASCIIUtility.parseInt(paramByteArray, j + 1, i - 3);
          if (j <= 0) {
            break label367;
          }
          k = paramByteArray.length - i;
          if (j + 16 <= k) {
            break label358;
          }
          if (256 <= j + 16 - k) {
            break label346;
          }
          k = 256;
          localByteArray.grow(k);
          localObject = localByteArray.getBytes();
          k = j;
          paramByteArray = (ByteArray)localObject;
          j = i;
          if (k <= 0) {
            break;
          }
          j = this.bin.read((byte[])localObject, i, k);
          k -= j;
          i += j;
          continue;
          if (paramByteArray[j] == 123) {
            break label222;
          }
          j -= 1;
        }
        catch (NumberFormatException paramByteArray) {}
        break label205;
        k = j + 16 - k;
        continue;
        localObject = paramByteArray;
        k = j;
      }
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/iap/ResponseInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */