package com.sun.mail.iap;

import com.sun.mail.util.ASCIIUtility;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.Vector;

public class Response
{
  public static final int BAD = 12;
  public static final int BYE = 16;
  public static final int CONTINUATION = 1;
  public static final int NO = 8;
  public static final int OK = 4;
  public static final int SYNTHETIC = 32;
  public static final int TAGGED = 2;
  public static final int TAG_MASK = 3;
  public static final int TYPE_MASK = 28;
  public static final int UNTAGGED = 3;
  private static final int increment = 100;
  protected byte[] buffer = null;
  protected int index;
  protected int pindex;
  protected int size;
  protected String tag = null;
  protected int type = 0;
  
  public Response(Protocol paramProtocol)
    throws IOException, ProtocolException
  {
    ByteArray localByteArray = paramProtocol.getResponseBuffer();
    paramProtocol = paramProtocol.getInputStream().readResponse(localByteArray);
    this.buffer = paramProtocol.getBytes();
    this.size = (paramProtocol.getCount() - 2);
    parse();
  }
  
  public Response(Response paramResponse)
  {
    this.index = paramResponse.index;
    this.size = paramResponse.size;
    this.buffer = paramResponse.buffer;
    this.type = paramResponse.type;
    this.tag = paramResponse.tag;
  }
  
  public Response(String paramString)
  {
    this.buffer = ASCIIUtility.getBytes(paramString);
    this.size = this.buffer.length;
    parse();
  }
  
  public static Response byeResponse(Exception paramException)
  {
    paramException = new Response(("* BYE JavaMail Exception: " + paramException.toString()).replace('\r', ' ').replace('\n', ' '));
    paramException.type |= 0x20;
    return paramException;
  }
  
  private void parse()
  {
    this.index = 0;
    if (this.buffer[this.index] == 43)
    {
      this.type |= 0x1;
      this.index += 1;
      return;
    }
    int i;
    String str1;
    if (this.buffer[this.index] == 42)
    {
      this.type |= 0x3;
      this.index += 1;
      i = this.index;
      String str2 = readAtom();
      str1 = str2;
      if (str2 == null) {
        str1 = "";
      }
      if (!str1.equalsIgnoreCase("OK")) {
        break label142;
      }
      this.type |= 0x4;
    }
    for (;;)
    {
      this.pindex = this.index;
      return;
      this.type |= 0x2;
      this.tag = readAtom();
      break;
      label142:
      if (str1.equalsIgnoreCase("NO")) {
        this.type |= 0x8;
      } else if (str1.equalsIgnoreCase("BAD")) {
        this.type |= 0xC;
      } else if (str1.equalsIgnoreCase("BYE")) {
        this.type |= 0x10;
      } else {
        this.index = i;
      }
    }
  }
  
  private Object parseString(boolean paramBoolean1, boolean paramBoolean2)
  {
    String str1 = null;
    skipSpaces();
    int i = this.buffer[this.index];
    int j;
    int k;
    if (i == 34)
    {
      this.index += 1;
      j = this.index;
      i = this.index;
      k = this.buffer[this.index];
      if (k == 34)
      {
        this.index += 1;
        if (!paramBoolean2) {
          break label148;
        }
        str1 = ASCIIUtility.toString(this.buffer, j, i);
      }
    }
    label148:
    label313:
    do
    {
      do
      {
        return str1;
        if (k == 92) {
          this.index += 1;
        }
        if (this.index != i) {
          this.buffer[i] = this.buffer[this.index];
        }
        i += 1;
        this.index += 1;
        break;
        return new ByteArray(this.buffer, j, i - j);
        if (i == 123)
        {
          i = this.index + 1;
          for (this.index = i;; this.index += 1)
          {
            if (this.buffer[this.index] == 125) {}
            try
            {
              i = ASCIIUtility.parseInt(this.buffer, i, this.index);
              j = this.index + 3;
              this.index = (j + i);
              if (!paramBoolean2) {
                break;
              }
              return ASCIIUtility.toString(this.buffer, j, j + i);
            }
            catch (NumberFormatException localNumberFormatException)
            {
              return null;
            }
          }
          return new ByteArray(this.buffer, j, i);
        }
        if (!paramBoolean1) {
          break label313;
        }
        i = this.index;
        String str2 = readAtom();
      } while (paramBoolean2);
      return new ByteArray(this.buffer, i, this.index);
    } while ((i != 78) && (i != 110));
    this.index += 3;
    return null;
  }
  
  public String getRest()
  {
    skipSpaces();
    return ASCIIUtility.toString(this.buffer, this.index, this.size);
  }
  
  public String getTag()
  {
    return this.tag;
  }
  
  public int getType()
  {
    return this.type;
  }
  
  public boolean isBAD()
  {
    return (this.type & 0x1C) == 12;
  }
  
  public boolean isBYE()
  {
    return (this.type & 0x1C) == 16;
  }
  
  public boolean isContinuation()
  {
    return (this.type & 0x3) == 1;
  }
  
  public boolean isNO()
  {
    return (this.type & 0x1C) == 8;
  }
  
  public boolean isOK()
  {
    return (this.type & 0x1C) == 4;
  }
  
  public boolean isSynthetic()
  {
    return (this.type & 0x20) == 32;
  }
  
  public boolean isTagged()
  {
    return (this.type & 0x3) == 2;
  }
  
  public boolean isUnTagged()
  {
    return (this.type & 0x3) == 3;
  }
  
  public byte peekByte()
  {
    if (this.index < this.size) {
      return this.buffer[this.index];
    }
    return 0;
  }
  
  public String readAtom()
  {
    return readAtom('\000');
  }
  
  public String readAtom(char paramChar)
  {
    skipSpaces();
    if (this.index >= this.size) {
      return null;
    }
    int i = this.index;
    for (;;)
    {
      if (this.index < this.size)
      {
        char c = this.buffer[this.index];
        if ((c > ' ') && (c != '(') && (c != ')') && (c != '%') && (c != '*') && (c != '"') && (c != '\\') && (c != '') && ((paramChar == 0) || (c != paramChar))) {}
      }
      else
      {
        return ASCIIUtility.toString(this.buffer, i, this.index);
      }
      this.index += 1;
    }
  }
  
  public String readAtomString()
  {
    return (String)parseString(true, true);
  }
  
  public byte readByte()
  {
    if (this.index < this.size)
    {
      byte[] arrayOfByte = this.buffer;
      int i = this.index;
      this.index = (i + 1);
      return arrayOfByte[i];
    }
    return 0;
  }
  
  public ByteArray readByteArray()
  {
    if (isContinuation())
    {
      skipSpaces();
      return new ByteArray(this.buffer, this.index, this.size - this.index);
    }
    return (ByteArray)parseString(false, false);
  }
  
  public ByteArrayInputStream readBytes()
  {
    ByteArray localByteArray = readByteArray();
    if (localByteArray != null) {
      return localByteArray.toByteArrayInputStream();
    }
    return null;
  }
  
  public long readLong()
  {
    skipSpaces();
    int i = this.index;
    for (;;)
    {
      if (((this.index >= this.size) || (!Character.isDigit((char)this.buffer[this.index]))) && (this.index <= i)) {
        break label74;
      }
      try
      {
        long l = ASCIIUtility.parseLong(this.buffer, i, this.index);
        return l;
      }
      catch (NumberFormatException localNumberFormatException) {}
      this.index += 1;
    }
    label74:
    return -1L;
  }
  
  public int readNumber()
  {
    skipSpaces();
    int i = this.index;
    while (((this.index < this.size) && (Character.isDigit((char)this.buffer[this.index]))) || (this.index > i))
    {
      try
      {
        i = ASCIIUtility.parseInt(this.buffer, i, this.index);
        return i;
      }
      catch (NumberFormatException localNumberFormatException) {}
      this.index += 1;
    }
    return -1;
  }
  
  public String readString()
  {
    return (String)parseString(false, true);
  }
  
  public String readString(char paramChar)
  {
    skipSpaces();
    if (this.index >= this.size) {
      return null;
    }
    int i = this.index;
    for (;;)
    {
      if ((this.index >= this.size) || (this.buffer[this.index] == paramChar)) {
        return ASCIIUtility.toString(this.buffer, i, this.index);
      }
      this.index += 1;
    }
  }
  
  public String[] readStringList()
  {
    skipSpaces();
    if (this.buffer[this.index] != 40) {}
    Vector localVector;
    int i;
    do
    {
      return null;
      this.index += 1;
      localVector = new Vector();
      do
      {
        localVector.addElement(readString());
        localObject = this.buffer;
        i = this.index;
        this.index = (i + 1);
      } while (localObject[i] != 41);
      i = localVector.size();
    } while (i <= 0);
    Object localObject = new String[i];
    localVector.copyInto((Object[])localObject);
    return (String[])localObject;
  }
  
  public void reset()
  {
    this.index = this.pindex;
  }
  
  public void skip(int paramInt)
  {
    this.index += paramInt;
  }
  
  public void skipSpaces()
  {
    for (;;)
    {
      if ((this.index >= this.size) || (this.buffer[this.index] != 32)) {
        return;
      }
      this.index += 1;
    }
  }
  
  public void skipToken()
  {
    for (;;)
    {
      if ((this.index >= this.size) || (this.buffer[this.index] == 32)) {
        return;
      }
      this.index += 1;
    }
  }
  
  public String toString()
  {
    return ASCIIUtility.toString(this.buffer, 0, this.size);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/iap/Response.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */