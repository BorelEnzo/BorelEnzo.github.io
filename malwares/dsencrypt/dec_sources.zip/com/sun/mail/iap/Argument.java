package com.sun.mail.iap;

import com.sun.mail.util.ASCIIUtility;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Vector;

public class Argument
{
  protected Vector items = new Vector(1);
  
  private void astring(byte[] paramArrayOfByte, Protocol paramProtocol)
    throws IOException, ProtocolException
  {
    DataOutputStream localDataOutputStream = (DataOutputStream)paramProtocol.getOutputStream();
    int i1 = paramArrayOfByte.length;
    if (i1 > 1024) {
      literal(paramArrayOfByte, paramProtocol);
    }
    label41:
    label67:
    label91:
    label241:
    label284:
    label291:
    for (;;)
    {
      return;
      int i;
      int k;
      int j;
      if (i1 == 0)
      {
        i = 1;
        k = 0;
        j = 0;
        if (j < i1) {
          break label91;
        }
        if (i != 0) {
          localDataOutputStream.write(34);
        }
        if (k == 0) {
          break label284;
        }
        j = 0;
        if (j < i1) {
          break label241;
        }
      }
      for (;;)
      {
        if (i == 0) {
          break label291;
        }
        localDataOutputStream.write(34);
        return;
        i = 0;
        break;
        int i2 = paramArrayOfByte[j];
        if ((i2 == 0) || (i2 == 13) || (i2 == 10) || ((i2 & 0xFF) > 127))
        {
          literal(paramArrayOfByte, paramProtocol);
          return;
        }
        int m;
        if ((i2 != 42) && (i2 != 37) && (i2 != 40) && (i2 != 41) && (i2 != 123) && (i2 != 34) && (i2 != 92))
        {
          m = k;
          if ((i2 & 0xFF) > 32) {}
        }
        else
        {
          int n = 1;
          if (i2 != 34)
          {
            m = k;
            i = n;
            if (i2 != 92) {}
          }
          else
          {
            m = 1;
            i = n;
          }
        }
        j += 1;
        k = m;
        break label41;
        k = paramArrayOfByte[j];
        if ((k == 34) || (k == 92)) {
          localDataOutputStream.write(92);
        }
        localDataOutputStream.write(k);
        j += 1;
        break label67;
        localDataOutputStream.write(paramArrayOfByte);
      }
    }
  }
  
  private void literal(Literal paramLiteral, Protocol paramProtocol)
    throws IOException, ProtocolException
  {
    paramLiteral.writeTo(startLiteral(paramProtocol, paramLiteral.size()));
  }
  
  private void literal(ByteArrayOutputStream paramByteArrayOutputStream, Protocol paramProtocol)
    throws IOException, ProtocolException
  {
    paramByteArrayOutputStream.writeTo(startLiteral(paramProtocol, paramByteArrayOutputStream.size()));
  }
  
  private void literal(byte[] paramArrayOfByte, Protocol paramProtocol)
    throws IOException, ProtocolException
  {
    startLiteral(paramProtocol, paramArrayOfByte.length).write(paramArrayOfByte);
  }
  
  private OutputStream startLiteral(Protocol paramProtocol, int paramInt)
    throws IOException, ProtocolException
  {
    DataOutputStream localDataOutputStream = (DataOutputStream)paramProtocol.getOutputStream();
    boolean bool = paramProtocol.supportsNonSyncLiterals();
    localDataOutputStream.write(123);
    localDataOutputStream.writeBytes(Integer.toString(paramInt));
    if (bool)
    {
      localDataOutputStream.writeBytes("+}\r\n");
      localDataOutputStream.flush();
      if (bool) {}
    }
    Response localResponse;
    do
    {
      localResponse = paramProtocol.readResponse();
      if (localResponse.isContinuation())
      {
        return localDataOutputStream;
        localDataOutputStream.writeBytes("}\r\n");
        break;
      }
    } while (!localResponse.isTagged());
    throw new LiteralException(localResponse);
  }
  
  public void append(Argument paramArgument)
  {
    this.items.ensureCapacity(this.items.size() + paramArgument.items.size());
    int i = 0;
    for (;;)
    {
      if (i >= paramArgument.items.size()) {
        return;
      }
      this.items.addElement(paramArgument.items.elementAt(i));
      i += 1;
    }
  }
  
  public void write(Protocol paramProtocol)
    throws IOException, ProtocolException
  {
    if (this.items != null) {}
    DataOutputStream localDataOutputStream;
    int j;
    for (int i = this.items.size();; i = 0)
    {
      localDataOutputStream = (DataOutputStream)paramProtocol.getOutputStream();
      j = 0;
      if (j < i) {
        break;
      }
      return;
    }
    if (j > 0) {
      localDataOutputStream.write(32);
    }
    Object localObject = this.items.elementAt(j);
    if ((localObject instanceof Atom)) {
      localDataOutputStream.writeBytes(((Atom)localObject).string);
    }
    for (;;)
    {
      j += 1;
      break;
      if ((localObject instanceof Number))
      {
        localDataOutputStream.writeBytes(((Number)localObject).toString());
      }
      else if ((localObject instanceof AString))
      {
        astring(((AString)localObject).bytes, paramProtocol);
      }
      else if ((localObject instanceof byte[]))
      {
        literal((byte[])localObject, paramProtocol);
      }
      else if ((localObject instanceof ByteArrayOutputStream))
      {
        literal((ByteArrayOutputStream)localObject, paramProtocol);
      }
      else if ((localObject instanceof Literal))
      {
        literal((Literal)localObject, paramProtocol);
      }
      else if ((localObject instanceof Argument))
      {
        localDataOutputStream.write(40);
        ((Argument)localObject).write(paramProtocol);
        localDataOutputStream.write(41);
      }
    }
  }
  
  public void writeArgument(Argument paramArgument)
  {
    this.items.addElement(paramArgument);
  }
  
  public void writeAtom(String paramString)
  {
    this.items.addElement(new Atom(paramString));
  }
  
  public void writeBytes(Literal paramLiteral)
  {
    this.items.addElement(paramLiteral);
  }
  
  public void writeBytes(ByteArrayOutputStream paramByteArrayOutputStream)
  {
    this.items.addElement(paramByteArrayOutputStream);
  }
  
  public void writeBytes(byte[] paramArrayOfByte)
  {
    this.items.addElement(paramArrayOfByte);
  }
  
  public void writeNumber(int paramInt)
  {
    this.items.addElement(new Integer(paramInt));
  }
  
  public void writeNumber(long paramLong)
  {
    this.items.addElement(new Long(paramLong));
  }
  
  public void writeString(String paramString)
  {
    this.items.addElement(new AString(ASCIIUtility.getBytes(paramString)));
  }
  
  public void writeString(String paramString1, String paramString2)
    throws UnsupportedEncodingException
  {
    if (paramString2 == null)
    {
      writeString(paramString1);
      return;
    }
    this.items.addElement(new AString(paramString1.getBytes(paramString2)));
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/iap/Argument.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */