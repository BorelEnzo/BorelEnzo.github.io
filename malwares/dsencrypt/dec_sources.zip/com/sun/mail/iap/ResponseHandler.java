package com.sun.mail.iap;

public abstract interface ResponseHandler
{
  public abstract void handleResponse(Response paramResponse);
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/iap/ResponseHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */