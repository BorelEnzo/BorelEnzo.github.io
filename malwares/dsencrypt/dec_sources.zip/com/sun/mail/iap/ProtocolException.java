package com.sun.mail.iap;

public class ProtocolException
  extends Exception
{
  private static final long serialVersionUID = -4360500807971797439L;
  protected transient Response response = null;
  
  public ProtocolException() {}
  
  public ProtocolException(Response paramResponse)
  {
    super(paramResponse.toString());
    this.response = paramResponse;
  }
  
  public ProtocolException(String paramString)
  {
    super(paramString);
  }
  
  public Response getResponse()
  {
    return this.response;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/iap/ProtocolException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */