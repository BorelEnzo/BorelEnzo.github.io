package com.sun.mail.iap;

import com.sun.mail.util.SocketFetcher;
import com.sun.mail.util.TraceInputStream;
import com.sun.mail.util.TraceOutputStream;
import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.Socket;
import java.util.Properties;
import java.util.Vector;

public class Protocol
{
  private static final byte[] CRLF = { 13, 10 };
  private boolean connected = false;
  protected boolean debug;
  private volatile Vector handlers = null;
  protected String host = "localhost";
  private volatile ResponseInputStream input;
  protected PrintStream out;
  private volatile DataOutputStream output;
  protected String prefix;
  protected Properties props;
  protected boolean quote;
  private Socket socket;
  private int tagCounter = 0;
  private volatile long timestamp;
  private TraceInputStream traceInput;
  private TraceOutputStream traceOutput;
  
  public Protocol(InputStream paramInputStream, OutputStream paramOutputStream, boolean paramBoolean)
    throws IOException
  {
    this.debug = paramBoolean;
    this.quote = false;
    this.out = System.out;
    this.traceInput = new TraceInputStream(paramInputStream, System.out);
    this.traceInput.setTrace(paramBoolean);
    this.traceInput.setQuote(this.quote);
    this.input = new ResponseInputStream(this.traceInput);
    this.traceOutput = new TraceOutputStream(paramOutputStream, System.out);
    this.traceOutput.setTrace(paramBoolean);
    this.traceOutput.setQuote(this.quote);
    this.output = new DataOutputStream(new BufferedOutputStream(this.traceOutput));
    this.timestamp = System.currentTimeMillis();
  }
  
  /* Error */
  public Protocol(String paramString1, int paramInt, boolean paramBoolean1, PrintStream paramPrintStream, Properties paramProperties, String paramString2, boolean paramBoolean2)
    throws IOException, ProtocolException
  {
    // Byte code:
    //   0: iconst_1
    //   1: istore 8
    //   3: aload_0
    //   4: invokespecial 46	java/lang/Object:<init>	()V
    //   7: aload_0
    //   8: iconst_0
    //   9: putfield 48	com/sun/mail/iap/Protocol:connected	Z
    //   12: aload_0
    //   13: iconst_0
    //   14: putfield 50	com/sun/mail/iap/Protocol:tagCounter	I
    //   17: aload_0
    //   18: aconst_null
    //   19: putfield 52	com/sun/mail/iap/Protocol:handlers	Ljava/util/Vector;
    //   22: aload_0
    //   23: aload_1
    //   24: putfield 56	com/sun/mail/iap/Protocol:host	Ljava/lang/String;
    //   27: aload_0
    //   28: iload_3
    //   29: putfield 58	com/sun/mail/iap/Protocol:debug	Z
    //   32: aload_0
    //   33: aload 4
    //   35: putfield 65	com/sun/mail/iap/Protocol:out	Ljava/io/PrintStream;
    //   38: aload_0
    //   39: aload 5
    //   41: putfield 117	com/sun/mail/iap/Protocol:props	Ljava/util/Properties;
    //   44: aload_0
    //   45: aload 6
    //   47: putfield 119	com/sun/mail/iap/Protocol:prefix	Ljava/lang/String;
    //   50: aload_0
    //   51: aload_1
    //   52: iload_2
    //   53: aload 5
    //   55: aload 6
    //   57: iload 7
    //   59: invokestatic 125	com/sun/mail/util/SocketFetcher:getSocket	(Ljava/lang/String;ILjava/util/Properties;Ljava/lang/String;Z)Ljava/net/Socket;
    //   62: putfield 127	com/sun/mail/iap/Protocol:socket	Ljava/net/Socket;
    //   65: aload 5
    //   67: ldc -127
    //   69: invokevirtual 135	java/util/Properties:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   72: astore_1
    //   73: aload_1
    //   74: ifnull +58 -> 132
    //   77: aload_1
    //   78: ldc -119
    //   80: invokevirtual 143	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   83: ifeq +49 -> 132
    //   86: iload 8
    //   88: istore_3
    //   89: aload_0
    //   90: iload_3
    //   91: putfield 60	com/sun/mail/iap/Protocol:quote	Z
    //   94: aload_0
    //   95: aload 4
    //   97: invokespecial 147	com/sun/mail/iap/Protocol:initStreams	(Ljava/io/PrintStream;)V
    //   100: aload_0
    //   101: aload_0
    //   102: invokevirtual 151	com/sun/mail/iap/Protocol:readResponse	()Lcom/sun/mail/iap/Response;
    //   105: invokevirtual 155	com/sun/mail/iap/Protocol:processGreeting	(Lcom/sun/mail/iap/Response;)V
    //   108: aload_0
    //   109: invokestatic 109	java/lang/System:currentTimeMillis	()J
    //   112: putfield 111	com/sun/mail/iap/Protocol:timestamp	J
    //   115: aload_0
    //   116: iconst_1
    //   117: putfield 48	com/sun/mail/iap/Protocol:connected	Z
    //   120: aload_0
    //   121: getfield 48	com/sun/mail/iap/Protocol:connected	Z
    //   124: ifne +7 -> 131
    //   127: aload_0
    //   128: invokevirtual 158	com/sun/mail/iap/Protocol:disconnect	()V
    //   131: return
    //   132: iconst_0
    //   133: istore_3
    //   134: goto -45 -> 89
    //   137: astore_1
    //   138: aload_0
    //   139: getfield 48	com/sun/mail/iap/Protocol:connected	Z
    //   142: ifne +7 -> 149
    //   145: aload_0
    //   146: invokevirtual 158	com/sun/mail/iap/Protocol:disconnect	()V
    //   149: aload_1
    //   150: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	151	0	this	Protocol
    //   0	151	1	paramString1	String
    //   0	151	2	paramInt	int
    //   0	151	3	paramBoolean1	boolean
    //   0	151	4	paramPrintStream	PrintStream
    //   0	151	5	paramProperties	Properties
    //   0	151	6	paramString2	String
    //   0	151	7	paramBoolean2	boolean
    //   1	86	8	bool	boolean
    // Exception table:
    //   from	to	target	type
    //   22	73	137	finally
    //   77	86	137	finally
    //   89	120	137	finally
  }
  
  private void initStreams(PrintStream paramPrintStream)
    throws IOException
  {
    this.traceInput = new TraceInputStream(this.socket.getInputStream(), paramPrintStream);
    this.traceInput.setTrace(this.debug);
    this.traceInput.setQuote(this.quote);
    this.input = new ResponseInputStream(this.traceInput);
    this.traceOutput = new TraceOutputStream(this.socket.getOutputStream(), paramPrintStream);
    this.traceOutput.setTrace(this.debug);
    this.traceOutput.setQuote(this.quote);
    this.output = new DataOutputStream(new BufferedOutputStream(this.traceOutput));
  }
  
  public void addResponseHandler(ResponseHandler paramResponseHandler)
  {
    try
    {
      if (this.handlers == null) {
        this.handlers = new Vector();
      }
      this.handlers.addElement(paramResponseHandler);
      return;
    }
    finally {}
  }
  
  /* Error */
  public Response[] command(String paramString, Argument paramArgument)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new 172	java/util/Vector
    //   5: dup
    //   6: invokespecial 173	java/util/Vector:<init>	()V
    //   9: astore 6
    //   11: iconst_0
    //   12: istore_3
    //   13: aconst_null
    //   14: astore 5
    //   16: aload_0
    //   17: aload_1
    //   18: aload_2
    //   19: invokevirtual 187	com/sun/mail/iap/Protocol:writeCommand	(Ljava/lang/String;Lcom/sun/mail/iap/Argument;)Ljava/lang/String;
    //   22: astore_1
    //   23: iload_3
    //   24: ifeq +65 -> 89
    //   27: aload 6
    //   29: invokevirtual 191	java/util/Vector:size	()I
    //   32: anewarray 193	com/sun/mail/iap/Response
    //   35: astore_1
    //   36: aload 6
    //   38: aload_1
    //   39: invokevirtual 197	java/util/Vector:copyInto	([Ljava/lang/Object;)V
    //   42: aload_0
    //   43: invokestatic 109	java/lang/System:currentTimeMillis	()J
    //   46: putfield 111	com/sun/mail/iap/Protocol:timestamp	J
    //   49: aload_0
    //   50: monitorexit
    //   51: aload_1
    //   52: areturn
    //   53: astore_1
    //   54: aload 6
    //   56: aload_1
    //   57: invokevirtual 200	com/sun/mail/iap/LiteralException:getResponse	()Lcom/sun/mail/iap/Response;
    //   60: invokevirtual 177	java/util/Vector:addElement	(Ljava/lang/Object;)V
    //   63: iconst_1
    //   64: istore_3
    //   65: aload 5
    //   67: astore_1
    //   68: goto -45 -> 23
    //   71: astore_1
    //   72: aload 6
    //   74: aload_1
    //   75: invokestatic 204	com/sun/mail/iap/Response:byeResponse	(Ljava/lang/Exception;)Lcom/sun/mail/iap/Response;
    //   78: invokevirtual 177	java/util/Vector:addElement	(Ljava/lang/Object;)V
    //   81: iconst_1
    //   82: istore_3
    //   83: aload 5
    //   85: astore_1
    //   86: goto -63 -> 23
    //   89: aload_0
    //   90: invokevirtual 151	com/sun/mail/iap/Protocol:readResponse	()Lcom/sun/mail/iap/Response;
    //   93: astore_2
    //   94: aload 6
    //   96: aload_2
    //   97: invokevirtual 177	java/util/Vector:addElement	(Ljava/lang/Object;)V
    //   100: iload_3
    //   101: istore 4
    //   103: aload_2
    //   104: invokevirtual 208	com/sun/mail/iap/Response:isBYE	()Z
    //   107: ifeq +6 -> 113
    //   110: iconst_1
    //   111: istore 4
    //   113: iload 4
    //   115: istore_3
    //   116: aload_2
    //   117: invokevirtual 211	com/sun/mail/iap/Response:isTagged	()Z
    //   120: ifeq -97 -> 23
    //   123: iload 4
    //   125: istore_3
    //   126: aload_2
    //   127: invokevirtual 215	com/sun/mail/iap/Response:getTag	()Ljava/lang/String;
    //   130: aload_1
    //   131: invokevirtual 219	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   134: ifeq -111 -> 23
    //   137: iconst_1
    //   138: istore_3
    //   139: goto -116 -> 23
    //   142: astore_2
    //   143: aload_2
    //   144: invokestatic 204	com/sun/mail/iap/Response:byeResponse	(Ljava/lang/Exception;)Lcom/sun/mail/iap/Response;
    //   147: astore_2
    //   148: goto -54 -> 94
    //   151: astore_2
    //   152: goto -129 -> 23
    //   155: astore_1
    //   156: aload_0
    //   157: monitorexit
    //   158: aload_1
    //   159: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	160	0	this	Protocol
    //   0	160	1	paramString	String
    //   0	160	2	paramArgument	Argument
    //   12	127	3	i	int
    //   101	23	4	j	int
    //   14	70	5	localObject	Object
    //   9	86	6	localVector	Vector
    // Exception table:
    //   from	to	target	type
    //   16	23	53	com/sun/mail/iap/LiteralException
    //   16	23	71	java/lang/Exception
    //   89	94	142	java/io/IOException
    //   89	94	151	com/sun/mail/iap/ProtocolException
    //   2	11	155	finally
    //   16	23	155	finally
    //   27	49	155	finally
    //   54	63	155	finally
    //   72	81	155	finally
    //   89	94	155	finally
    //   94	100	155	finally
    //   103	110	155	finally
    //   116	123	155	finally
    //   126	137	155	finally
    //   143	148	155	finally
  }
  
  /* Error */
  protected void disconnect()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 127	com/sun/mail/iap/Protocol:socket	Ljava/net/Socket;
    //   6: astore_1
    //   7: aload_1
    //   8: ifnull +15 -> 23
    //   11: aload_0
    //   12: getfield 127	com/sun/mail/iap/Protocol:socket	Ljava/net/Socket;
    //   15: invokevirtual 222	java/net/Socket:close	()V
    //   18: aload_0
    //   19: aconst_null
    //   20: putfield 127	com/sun/mail/iap/Protocol:socket	Ljava/net/Socket;
    //   23: aload_0
    //   24: monitorexit
    //   25: return
    //   26: astore_1
    //   27: aload_0
    //   28: monitorexit
    //   29: aload_1
    //   30: athrow
    //   31: astore_1
    //   32: goto -14 -> 18
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	35	0	this	Protocol
    //   6	2	1	localSocket	Socket
    //   26	4	1	localObject	Object
    //   31	1	1	localIOException	IOException
    // Exception table:
    //   from	to	target	type
    //   2	7	26	finally
    //   11	18	26	finally
    //   18	23	26	finally
    //   11	18	31	java/io/IOException
  }
  
  protected void finalize()
    throws Throwable
  {
    super.finalize();
    disconnect();
  }
  
  protected ResponseInputStream getInputStream()
  {
    return this.input;
  }
  
  protected OutputStream getOutputStream()
  {
    return this.output;
  }
  
  protected ByteArray getResponseBuffer()
  {
    return null;
  }
  
  public long getTimestamp()
  {
    return this.timestamp;
  }
  
  public void handleResult(Response paramResponse)
    throws ProtocolException
  {
    if (paramResponse.isOK()) {}
    do
    {
      return;
      if (paramResponse.isNO()) {
        throw new CommandFailedException(paramResponse);
      }
      if (paramResponse.isBAD()) {
        throw new BadCommandException(paramResponse);
      }
    } while (!paramResponse.isBYE());
    disconnect();
    throw new ConnectionException(this, paramResponse);
  }
  
  public void notifyResponseHandlers(Response[] paramArrayOfResponse)
  {
    if (this.handlers == null) {
      return;
    }
    int i = 0;
    label10:
    Response localResponse;
    if (i < paramArrayOfResponse.length)
    {
      localResponse = paramArrayOfResponse[i];
      if (localResponse != null) {
        break label33;
      }
    }
    for (;;)
    {
      i += 1;
      break label10;
      break;
      label33:
      int k = this.handlers.size();
      if (k == 0) {
        break;
      }
      Object[] arrayOfObject = new Object[k];
      this.handlers.copyInto(arrayOfObject);
      int j = 0;
      while (j < k)
      {
        ((ResponseHandler)arrayOfObject[j]).handleResponse(localResponse);
        j += 1;
      }
    }
  }
  
  protected void processGreeting(Response paramResponse)
    throws ProtocolException
  {
    if (paramResponse.isBYE()) {
      throw new ConnectionException(this, paramResponse);
    }
  }
  
  public Response readResponse()
    throws IOException, ProtocolException
  {
    return new Response(this);
  }
  
  public void removeResponseHandler(ResponseHandler paramResponseHandler)
  {
    try
    {
      if (this.handlers != null) {
        this.handlers.removeElement(paramResponseHandler);
      }
      return;
    }
    finally
    {
      paramResponseHandler = finally;
      throw paramResponseHandler;
    }
  }
  
  public void simpleCommand(String paramString, Argument paramArgument)
    throws ProtocolException
  {
    paramString = command(paramString, paramArgument);
    notifyResponseHandlers(paramString);
    handleResult(paramString[(paramString.length - 1)]);
  }
  
  public void startTLS(String paramString)
    throws IOException, ProtocolException
  {
    try
    {
      simpleCommand(paramString, null);
      this.socket = SocketFetcher.startTLS(this.socket, this.props, this.prefix);
      initStreams(this.out);
      return;
    }
    finally
    {
      paramString = finally;
      throw paramString;
    }
  }
  
  protected boolean supportsNonSyncLiterals()
  {
    return false;
  }
  
  public String writeCommand(String paramString, Argument paramArgument)
    throws IOException, ProtocolException
  {
    Object localObject = new StringBuilder("A");
    int i = this.tagCounter;
    this.tagCounter = (i + 1);
    localObject = Integer.toString(i, 10);
    this.output.writeBytes(localObject + " " + paramString);
    if (paramArgument != null)
    {
      this.output.write(32);
      paramArgument.write(this);
    }
    this.output.write(CRLF);
    this.output.flush();
    return (String)localObject;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/iap/Protocol.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */