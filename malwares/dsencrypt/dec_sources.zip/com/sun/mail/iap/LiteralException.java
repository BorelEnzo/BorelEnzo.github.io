package com.sun.mail.iap;

public class LiteralException
  extends ProtocolException
{
  private static final long serialVersionUID = -6919179828339609913L;
  
  public LiteralException(Response paramResponse)
  {
    super(paramResponse.toString());
    this.response = paramResponse;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/iap/LiteralException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */