package com.sun.mail.iap;

public class ConnectionException
  extends ProtocolException
{
  private static final long serialVersionUID = 5749739604257464727L;
  private transient Protocol p;
  
  public ConnectionException() {}
  
  public ConnectionException(Protocol paramProtocol, Response paramResponse)
  {
    super(paramResponse);
    this.p = paramProtocol;
  }
  
  public ConnectionException(String paramString)
  {
    super(paramString);
  }
  
  public Protocol getProtocol()
  {
    return this.p;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/iap/ConnectionException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */