package com.sun.mail.util;

import java.io.FilterOutputStream;
import java.io.OutputStream;
import javax.mail.MessagingException;

public class LineOutputStream
  extends FilterOutputStream
{
  private static byte[] newline = new byte[2];
  
  static
  {
    newline[0] = 13;
    newline[1] = 10;
  }
  
  public LineOutputStream(OutputStream paramOutputStream)
  {
    super(paramOutputStream);
  }
  
  public void writeln()
    throws MessagingException
  {
    try
    {
      this.out.write(newline);
      return;
    }
    catch (Exception localException)
    {
      throw new MessagingException("IOException", localException);
    }
  }
  
  public void writeln(String paramString)
    throws MessagingException
  {
    try
    {
      paramString = ASCIIUtility.getBytes(paramString);
      this.out.write(paramString);
      this.out.write(newline);
      return;
    }
    catch (Exception paramString)
    {
      throw new MessagingException("IOException", paramString);
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/util/LineOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */