package com.sun.mail.util;

import java.io.IOException;

public class MessageRemovedIOException
  extends IOException
{
  private static final long serialVersionUID = 4280468026581616424L;
  
  public MessageRemovedIOException() {}
  
  public MessageRemovedIOException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/util/MessageRemovedIOException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */