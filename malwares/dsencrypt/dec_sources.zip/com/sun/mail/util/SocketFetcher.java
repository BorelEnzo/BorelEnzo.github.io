package com.sun.mail.util;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;
import javax.net.SocketFactory;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

public class SocketFetcher
{
  private static void configureSSLSocket(Socket paramSocket, Properties paramProperties, String paramString)
  {
    if (!(paramSocket instanceof SSLSocket)) {
      return;
    }
    paramSocket = (SSLSocket)paramSocket;
    String str = paramProperties.getProperty(paramString + ".ssl.protocols", null);
    if (str != null) {
      paramSocket.setEnabledProtocols(stringArray(str));
    }
    for (;;)
    {
      paramProperties = paramProperties.getProperty(paramString + ".ssl.ciphersuites", null);
      if (paramProperties == null) {
        break;
      }
      paramSocket.setEnabledCipherSuites(stringArray(paramProperties));
      return;
      paramSocket.setEnabledProtocols(new String[] { "TLSv1" });
    }
  }
  
  private static Socket createSocket(InetAddress paramInetAddress, int paramInt1, String paramString, int paramInt2, int paramInt3, SocketFactory paramSocketFactory, boolean paramBoolean)
    throws IOException
  {
    if (paramSocketFactory != null) {
      paramSocketFactory = paramSocketFactory.createSocket();
    }
    for (;;)
    {
      if (paramInetAddress != null) {
        paramSocketFactory.bind(new InetSocketAddress(paramInetAddress, paramInt1));
      }
      if (paramInt3 < 0) {
        break;
      }
      paramSocketFactory.connect(new InetSocketAddress(paramString, paramInt2), paramInt3);
      return paramSocketFactory;
      if (paramBoolean) {
        paramSocketFactory = SSLSocketFactory.getDefault().createSocket();
      } else {
        paramSocketFactory = new Socket();
      }
    }
    paramSocketFactory.connect(new InetSocketAddress(paramString, paramInt2));
    return paramSocketFactory;
  }
  
  private static ClassLoader getContextClassLoader()
  {
    (ClassLoader)AccessController.doPrivileged(new PrivilegedAction()
    {
      public Object run()
      {
        try
        {
          ClassLoader localClassLoader = Thread.currentThread().getContextClassLoader();
          return localClassLoader;
        }
        catch (SecurityException localSecurityException) {}
        return null;
      }
    });
  }
  
  public static Socket getSocket(String paramString1, int paramInt, Properties paramProperties, String paramString2)
    throws IOException
  {
    return getSocket(paramString1, paramInt, paramProperties, paramString2, false);
  }
  
  /* Error */
  public static Socket getSocket(String paramString1, int paramInt, Properties paramProperties, String paramString2, boolean paramBoolean)
    throws IOException
  {
    // Byte code:
    //   0: aload_3
    //   1: astore 11
    //   3: aload_3
    //   4: ifnonnull +7 -> 11
    //   7: ldc 118
    //   9: astore 11
    //   11: aload_2
    //   12: astore_3
    //   13: aload_2
    //   14: ifnonnull +11 -> 25
    //   17: new 38	java/util/Properties
    //   20: dup
    //   21: invokespecial 119	java/util/Properties:<init>	()V
    //   24: astore_3
    //   25: aload_3
    //   26: new 17	java/lang/StringBuilder
    //   29: dup
    //   30: aload 11
    //   32: invokestatic 23	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   35: invokespecial 26	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   38: ldc 121
    //   40: invokevirtual 32	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   43: invokevirtual 36	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   46: aconst_null
    //   47: invokevirtual 42	java/util/Properties:getProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   50: astore_2
    //   51: iconst_m1
    //   52: istore 5
    //   54: iload 5
    //   56: istore 7
    //   58: aload_2
    //   59: ifnull +9 -> 68
    //   62: aload_2
    //   63: invokestatic 127	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   66: istore 7
    //   68: aconst_null
    //   69: astore 13
    //   71: aload_3
    //   72: new 17	java/lang/StringBuilder
    //   75: dup
    //   76: aload 11
    //   78: invokestatic 23	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   81: invokespecial 26	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   84: ldc -127
    //   86: invokevirtual 32	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   89: invokevirtual 36	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   92: aconst_null
    //   93: invokevirtual 42	java/util/Properties:getProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   96: astore 15
    //   98: aload_3
    //   99: new 17	java/lang/StringBuilder
    //   102: dup
    //   103: aload 11
    //   105: invokestatic 23	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   108: invokespecial 26	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   111: ldc -125
    //   113: invokevirtual 32	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   116: invokevirtual 36	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   119: aconst_null
    //   120: invokevirtual 42	java/util/Properties:getProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   123: astore_2
    //   124: aconst_null
    //   125: astore 12
    //   127: aload_2
    //   128: ifnull +9 -> 137
    //   131: aload_2
    //   132: invokestatic 137	java/net/InetAddress:getByName	(Ljava/lang/String;)Ljava/net/InetAddress;
    //   135: astore 12
    //   137: aload_3
    //   138: new 17	java/lang/StringBuilder
    //   141: dup
    //   142: aload 11
    //   144: invokestatic 23	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   147: invokespecial 26	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   150: ldc -117
    //   152: invokevirtual 32	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   155: invokevirtual 36	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   158: aconst_null
    //   159: invokevirtual 42	java/util/Properties:getProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   162: astore_2
    //   163: iconst_0
    //   164: istore 5
    //   166: iload 5
    //   168: istore 8
    //   170: aload_2
    //   171: ifnull +9 -> 180
    //   174: aload_2
    //   175: invokestatic 127	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   178: istore 8
    //   180: aload_3
    //   181: new 17	java/lang/StringBuilder
    //   184: dup
    //   185: aload 11
    //   187: invokestatic 23	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   190: invokespecial 26	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   193: ldc -115
    //   195: invokevirtual 32	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   198: invokevirtual 36	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   201: aconst_null
    //   202: invokevirtual 42	java/util/Properties:getProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   205: astore_2
    //   206: aload_2
    //   207: ifnull +211 -> 418
    //   210: aload_2
    //   211: ldc -113
    //   213: invokevirtual 147	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   216: ifeq +202 -> 418
    //   219: iconst_0
    //   220: istore 9
    //   222: aload_3
    //   223: new 17	java/lang/StringBuilder
    //   226: dup
    //   227: aload 11
    //   229: invokestatic 23	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   232: invokespecial 26	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   235: ldc -107
    //   237: invokevirtual 32	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   240: invokevirtual 36	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   243: aconst_null
    //   244: invokevirtual 42	java/util/Properties:getProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   247: astore 16
    //   249: iconst_m1
    //   250: istore 6
    //   252: iload 6
    //   254: istore 5
    //   256: aload 16
    //   258: invokestatic 153	com/sun/mail/util/SocketFetcher:getSocketFactory	(Ljava/lang/String;)Ljavax/net/SocketFactory;
    //   261: astore 14
    //   263: aload 13
    //   265: astore_2
    //   266: aload 14
    //   268: ifnull +89 -> 357
    //   271: iload 6
    //   273: istore 5
    //   275: aload_3
    //   276: new 17	java/lang/StringBuilder
    //   279: dup
    //   280: aload 11
    //   282: invokestatic 23	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   285: invokespecial 26	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   288: ldc -101
    //   290: invokevirtual 32	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   293: invokevirtual 36	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   296: aconst_null
    //   297: invokevirtual 42	java/util/Properties:getProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   300: astore_2
    //   301: iload 6
    //   303: istore 5
    //   305: aload_2
    //   306: ifnull +17 -> 323
    //   309: iload 6
    //   311: istore 5
    //   313: aload_2
    //   314: invokestatic 127	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   317: istore 10
    //   319: iload 10
    //   321: istore 5
    //   323: iload 5
    //   325: istore 6
    //   327: iload 5
    //   329: iconst_m1
    //   330: if_icmpne +6 -> 336
    //   333: iload_1
    //   334: istore 6
    //   336: iload 6
    //   338: istore 5
    //   340: aload 12
    //   342: iload 8
    //   344: aload_0
    //   345: iload 6
    //   347: iload 7
    //   349: aload 14
    //   351: iload 4
    //   353: invokestatic 157	com/sun/mail/util/SocketFetcher:createSocket	(Ljava/net/InetAddress;ILjava/lang/String;IILjavax/net/SocketFactory;Z)Ljava/net/Socket;
    //   356: astore_2
    //   357: aload_2
    //   358: astore 13
    //   360: aload_2
    //   361: ifnonnull +19 -> 380
    //   364: aload 12
    //   366: iload 8
    //   368: aload_0
    //   369: iload_1
    //   370: iload 7
    //   372: aconst_null
    //   373: iload 4
    //   375: invokestatic 157	com/sun/mail/util/SocketFetcher:createSocket	(Ljava/net/InetAddress;ILjava/lang/String;IILjavax/net/SocketFactory;Z)Ljava/net/Socket;
    //   378: astore 13
    //   380: iconst_m1
    //   381: istore 5
    //   383: iload 5
    //   385: istore_1
    //   386: aload 15
    //   388: ifnull +9 -> 397
    //   391: aload 15
    //   393: invokestatic 127	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   396: istore_1
    //   397: iload_1
    //   398: iflt +9 -> 407
    //   401: aload 13
    //   403: iload_1
    //   404: invokevirtual 161	java/net/Socket:setSoTimeout	(I)V
    //   407: aload 13
    //   409: aload_3
    //   410: aload 11
    //   412: invokestatic 163	com/sun/mail/util/SocketFetcher:configureSSLSocket	(Ljava/net/Socket;Ljava/util/Properties;Ljava/lang/String;)V
    //   415: aload 13
    //   417: areturn
    //   418: iconst_1
    //   419: istore 9
    //   421: goto -199 -> 222
    //   424: astore_0
    //   425: aload_0
    //   426: athrow
    //   427: astore 14
    //   429: aload 13
    //   431: astore_2
    //   432: iload 9
    //   434: ifne -77 -> 357
    //   437: aload 14
    //   439: astore_2
    //   440: aload 14
    //   442: instanceof 165
    //   445: ifeq +27 -> 472
    //   448: aload 14
    //   450: checkcast 165	java/lang/reflect/InvocationTargetException
    //   453: invokevirtual 169	java/lang/reflect/InvocationTargetException:getTargetException	()Ljava/lang/Throwable;
    //   456: astore_3
    //   457: aload 14
    //   459: astore_2
    //   460: aload_3
    //   461: instanceof 116
    //   464: ifeq +8 -> 472
    //   467: aload_3
    //   468: checkcast 116	java/lang/Exception
    //   471: astore_2
    //   472: aload_2
    //   473: instanceof 61
    //   476: ifeq +8 -> 484
    //   479: aload_2
    //   480: checkcast 61	java/io/IOException
    //   483: athrow
    //   484: new 61	java/io/IOException
    //   487: dup
    //   488: new 17	java/lang/StringBuilder
    //   491: dup
    //   492: ldc -85
    //   494: invokespecial 26	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   497: aload 16
    //   499: invokevirtual 32	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   502: ldc -83
    //   504: invokevirtual 32	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   507: aload_0
    //   508: invokevirtual 32	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   511: ldc -81
    //   513: invokevirtual 32	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   516: iload 5
    //   518: invokevirtual 178	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   521: ldc -76
    //   523: invokevirtual 32	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   526: aload_2
    //   527: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   530: invokevirtual 36	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   533: invokespecial 184	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   536: astore_0
    //   537: aload_0
    //   538: aload_2
    //   539: invokevirtual 188	java/io/IOException:initCause	(Ljava/lang/Throwable;)Ljava/lang/Throwable;
    //   542: pop
    //   543: aload_0
    //   544: athrow
    //   545: astore_2
    //   546: iload 5
    //   548: istore 7
    //   550: goto -482 -> 68
    //   553: astore_2
    //   554: iload 5
    //   556: istore 8
    //   558: goto -378 -> 180
    //   561: astore_2
    //   562: iload 6
    //   564: istore 5
    //   566: goto -243 -> 323
    //   569: astore_0
    //   570: iload 5
    //   572: istore_1
    //   573: goto -176 -> 397
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	576	0	paramString1	String
    //   0	576	1	paramInt	int
    //   0	576	2	paramProperties	Properties
    //   0	576	3	paramString2	String
    //   0	576	4	paramBoolean	boolean
    //   52	519	5	i	int
    //   250	313	6	j	int
    //   56	493	7	k	int
    //   168	389	8	m	int
    //   220	213	9	n	int
    //   317	3	10	i1	int
    //   1	410	11	str1	String
    //   125	240	12	localInetAddress	InetAddress
    //   69	361	13	localObject	Object
    //   261	89	14	localSocketFactory	SocketFactory
    //   427	31	14	localException	Exception
    //   96	296	15	str2	String
    //   247	251	16	str3	String
    // Exception table:
    //   from	to	target	type
    //   256	263	424	java/net/SocketTimeoutException
    //   275	301	424	java/net/SocketTimeoutException
    //   313	319	424	java/net/SocketTimeoutException
    //   340	357	424	java/net/SocketTimeoutException
    //   256	263	427	java/lang/Exception
    //   275	301	427	java/lang/Exception
    //   313	319	427	java/lang/Exception
    //   340	357	427	java/lang/Exception
    //   62	68	545	java/lang/NumberFormatException
    //   174	180	553	java/lang/NumberFormatException
    //   313	319	561	java/lang/NumberFormatException
    //   391	397	569	java/lang/NumberFormatException
  }
  
  private static SocketFactory getSocketFactory(String paramString)
    throws ClassNotFoundException, NoSuchMethodException, IllegalAccessException, InvocationTargetException
  {
    if ((paramString == null) || (paramString.length() == 0)) {
      return null;
    }
    ClassLoader localClassLoader = getContextClassLoader();
    Object localObject3 = null;
    Object localObject1 = localObject3;
    if (localClassLoader != null) {}
    try
    {
      localObject1 = localClassLoader.loadClass(paramString);
      localObject3 = localObject1;
      if (localObject1 == null) {
        localObject3 = Class.forName(paramString);
      }
      return (SocketFactory)((Class)localObject3).getMethod("getDefault", new Class[0]).invoke(new Object(), new Object[0]);
    }
    catch (ClassNotFoundException localClassNotFoundException)
    {
      for (;;)
      {
        Object localObject2 = localObject3;
      }
    }
  }
  
  public static Socket startTLS(Socket paramSocket)
    throws IOException
  {
    return startTLS(paramSocket, new Properties(), "socket");
  }
  
  /* Error */
  public static Socket startTLS(Socket paramSocket, Properties paramProperties, String paramString)
    throws IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 229	java/net/Socket:getInetAddress	()Ljava/net/InetAddress;
    //   4: invokevirtual 232	java/net/InetAddress:getHostName	()Ljava/lang/String;
    //   7: astore 5
    //   9: aload_0
    //   10: invokevirtual 235	java/net/Socket:getPort	()I
    //   13: istore_3
    //   14: aload_1
    //   15: new 17	java/lang/StringBuilder
    //   18: dup
    //   19: aload_2
    //   20: invokestatic 23	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   23: invokespecial 26	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   26: ldc -107
    //   28: invokevirtual 32	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   31: invokevirtual 36	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   34: aconst_null
    //   35: invokevirtual 42	java/util/Properties:getProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   38: invokestatic 153	com/sun/mail/util/SocketFetcher:getSocketFactory	(Ljava/lang/String;)Ljavax/net/SocketFactory;
    //   41: astore 4
    //   43: aload 4
    //   45: ifnull +37 -> 82
    //   48: aload 4
    //   50: instanceof 86
    //   53: ifeq +29 -> 82
    //   56: aload 4
    //   58: checkcast 86	javax/net/ssl/SSLSocketFactory
    //   61: astore 4
    //   63: aload 4
    //   65: aload_0
    //   66: aload 5
    //   68: iload_3
    //   69: iconst_1
    //   70: invokevirtual 238	javax/net/ssl/SSLSocketFactory:createSocket	(Ljava/net/Socket;Ljava/lang/String;IZ)Ljava/net/Socket;
    //   73: astore_0
    //   74: aload_0
    //   75: aload_1
    //   76: aload_2
    //   77: invokestatic 163	com/sun/mail/util/SocketFetcher:configureSSLSocket	(Ljava/net/Socket;Ljava/util/Properties;Ljava/lang/String;)V
    //   80: aload_0
    //   81: areturn
    //   82: invokestatic 90	javax/net/ssl/SSLSocketFactory:getDefault	()Ljavax/net/SocketFactory;
    //   85: checkcast 86	javax/net/ssl/SSLSocketFactory
    //   88: astore 4
    //   90: goto -27 -> 63
    //   93: astore_1
    //   94: aload_1
    //   95: astore_0
    //   96: aload_1
    //   97: instanceof 165
    //   100: ifeq +25 -> 125
    //   103: aload_1
    //   104: checkcast 165	java/lang/reflect/InvocationTargetException
    //   107: invokevirtual 169	java/lang/reflect/InvocationTargetException:getTargetException	()Ljava/lang/Throwable;
    //   110: astore_2
    //   111: aload_1
    //   112: astore_0
    //   113: aload_2
    //   114: instanceof 116
    //   117: ifeq +8 -> 125
    //   120: aload_2
    //   121: checkcast 116	java/lang/Exception
    //   124: astore_0
    //   125: aload_0
    //   126: instanceof 61
    //   129: ifeq +8 -> 137
    //   132: aload_0
    //   133: checkcast 61	java/io/IOException
    //   136: athrow
    //   137: new 61	java/io/IOException
    //   140: dup
    //   141: new 17	java/lang/StringBuilder
    //   144: dup
    //   145: ldc -16
    //   147: invokespecial 26	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   150: aload 5
    //   152: invokevirtual 32	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   155: ldc -14
    //   157: invokevirtual 32	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   160: iload_3
    //   161: invokevirtual 178	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   164: ldc -76
    //   166: invokevirtual 32	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   169: aload_0
    //   170: invokevirtual 183	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   173: invokevirtual 36	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   176: invokespecial 184	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   179: astore_1
    //   180: aload_1
    //   181: aload_0
    //   182: invokevirtual 188	java/io/IOException:initCause	(Ljava/lang/Throwable;)Ljava/lang/Throwable;
    //   185: pop
    //   186: aload_1
    //   187: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	188	0	paramSocket	Socket
    //   0	188	1	paramProperties	Properties
    //   0	188	2	paramString	String
    //   13	148	3	i	int
    //   41	48	4	localObject	Object
    //   7	144	5	str	String
    // Exception table:
    //   from	to	target	type
    //   14	43	93	java/lang/Exception
    //   48	63	93	java/lang/Exception
    //   63	80	93	java/lang/Exception
    //   82	90	93	java/lang/Exception
  }
  
  private static String[] stringArray(String paramString)
  {
    paramString = new StringTokenizer(paramString);
    ArrayList localArrayList = new ArrayList();
    for (;;)
    {
      if (!paramString.hasMoreTokens()) {
        return (String[])localArrayList.toArray(new String[localArrayList.size()]);
      }
      localArrayList.add(paramString.nextToken());
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/util/SocketFetcher.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */