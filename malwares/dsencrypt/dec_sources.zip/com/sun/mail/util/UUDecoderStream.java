package com.sun.mail.util;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

public class UUDecoderStream
  extends FilterInputStream
{
  private byte[] buffer;
  private int bufsize = 0;
  private boolean gotEnd = false;
  private boolean gotPrefix = false;
  private int index = 0;
  private LineInputStream lin;
  private int mode;
  private String name;
  
  public UUDecoderStream(InputStream paramInputStream)
  {
    super(paramInputStream);
    this.lin = new LineInputStream(paramInputStream);
    this.buffer = new byte[45];
  }
  
  private boolean decode()
    throws IOException
  {
    if (this.gotEnd) {
      return false;
    }
    this.bufsize = 0;
    String str;
    do
    {
      str = this.lin.readLine();
      if (str == null) {
        throw new IOException("Missing End");
      }
      if (str.regionMatches(true, 0, "end", 0, 3))
      {
        this.gotEnd = true;
        return false;
      }
    } while (str.length() == 0);
    int i = str.charAt(0);
    if (i < 32) {
      throw new IOException("Buffer format error");
    }
    int n = i - 32 & 0x3F;
    if (n == 0)
    {
      str = this.lin.readLine();
      if ((str == null) || (!str.regionMatches(true, 0, "end", 0, 3))) {
        throw new IOException("Missing End");
      }
      this.gotEnd = true;
      return false;
    }
    i = (n * 8 + 5) / 6;
    if (str.length() < i + 1) {
      throw new IOException("Short buffer error");
    }
    int j = 1;
    for (;;)
    {
      if (this.bufsize >= n) {
        return true;
      }
      int k = j + 1;
      i = (byte)(str.charAt(j) - ' ' & 0x3F);
      j = k + 1;
      int m = (byte)(str.charAt(k) - ' ' & 0x3F);
      byte[] arrayOfByte = this.buffer;
      k = this.bufsize;
      this.bufsize = (k + 1);
      arrayOfByte[k] = ((byte)(i << 2 & 0xFC | m >>> 4 & 0x3));
      k = m;
      i = j;
      if (this.bufsize < n)
      {
        k = (byte)(str.charAt(j) - ' ' & 0x3F);
        arrayOfByte = this.buffer;
        i = this.bufsize;
        this.bufsize = (i + 1);
        arrayOfByte[i] = ((byte)(m << 4 & 0xF0 | k >>> 2 & 0xF));
        i = j + 1;
      }
      j = i;
      if (this.bufsize < n)
      {
        j = (byte)(str.charAt(i) - ' ' & 0x3F);
        arrayOfByte = this.buffer;
        m = this.bufsize;
        this.bufsize = (m + 1);
        arrayOfByte[m] = ((byte)(k << 6 & 0xC0 | j & 0x3F));
        j = i + 1;
      }
    }
  }
  
  private void readPrefix()
    throws IOException
  {
    if (this.gotPrefix) {
      return;
    }
    String str;
    do
    {
      str = this.lin.readLine();
      if (str == null) {
        throw new IOException("UUDecoder error: No Begin");
      }
    } while (!str.regionMatches(true, 0, "begin", 0, 5));
    try
    {
      this.mode = Integer.parseInt(str.substring(6, 9));
      this.name = str.substring(10);
      this.gotPrefix = true;
      return;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      throw new IOException("UUDecoder error: " + localNumberFormatException.toString());
    }
  }
  
  public int available()
    throws IOException
  {
    return this.in.available() * 3 / 4 + (this.bufsize - this.index);
  }
  
  public int getMode()
    throws IOException
  {
    readPrefix();
    return this.mode;
  }
  
  public String getName()
    throws IOException
  {
    readPrefix();
    return this.name;
  }
  
  public boolean markSupported()
  {
    return false;
  }
  
  public int read()
    throws IOException
  {
    if (this.index >= this.bufsize)
    {
      readPrefix();
      if (!decode()) {
        return -1;
      }
      this.index = 0;
    }
    byte[] arrayOfByte = this.buffer;
    int i = this.index;
    this.index = (i + 1);
    return arrayOfByte[i] & 0xFF;
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i = 0;
    for (;;)
    {
      if (i >= paramInt2) {}
      int j;
      do
      {
        return i;
        j = read();
        if (j != -1) {
          break;
        }
      } while (i != 0);
      return -1;
      paramArrayOfByte[(paramInt1 + i)] = ((byte)j);
      i += 1;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/util/UUDecoderStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */