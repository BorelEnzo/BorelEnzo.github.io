package com.sun.mail.util;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;

public class QPDecoderStream
  extends FilterInputStream
{
  protected byte[] ba = new byte[2];
  protected int spaces = 0;
  
  public QPDecoderStream(InputStream paramInputStream)
  {
    super(new PushbackInputStream(paramInputStream, 2));
  }
  
  public int available()
    throws IOException
  {
    return this.in.available();
  }
  
  public boolean markSupported()
  {
    return false;
  }
  
  public int read()
    throws IOException
  {
    if (this.spaces > 0)
    {
      this.spaces -= 1;
      i = 32;
    }
    int j;
    do
    {
      return i;
      j = this.in.read();
      if (j == 32)
      {
        for (;;)
        {
          i = this.in.read();
          if (i != 32)
          {
            if ((i != 13) && (i != 10) && (i != -1)) {
              break;
            }
            this.spaces = 0;
            return i;
          }
          this.spaces += 1;
        }
        ((PushbackInputStream)this.in).unread(i);
        return 32;
      }
      i = j;
    } while (j != 61);
    int i = this.in.read();
    if (i == 10) {
      return read();
    }
    if (i == 13)
    {
      i = this.in.read();
      if (i != 10) {
        ((PushbackInputStream)this.in).unread(i);
      }
      return read();
    }
    if (i == -1) {
      return -1;
    }
    this.ba[0] = ((byte)i);
    this.ba[1] = ((byte)this.in.read());
    try
    {
      i = ASCIIUtility.parseInt(this.ba, 0, 2, 16);
      return i;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      ((PushbackInputStream)this.in).unread(this.ba);
    }
    return j;
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i = 0;
    for (;;)
    {
      if (i >= paramInt2) {}
      int j;
      do
      {
        return i;
        j = read();
        if (j != -1) {
          break;
        }
      } while (i != 0);
      return -1;
      paramArrayOfByte[(paramInt1 + i)] = ((byte)j);
      i += 1;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/util/QPDecoderStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */