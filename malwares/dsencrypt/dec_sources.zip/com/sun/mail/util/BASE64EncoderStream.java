package com.sun.mail.util;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class BASE64EncoderStream
  extends FilterOutputStream
{
  private static byte[] newline = { 13, 10 };
  private static final char[] pem_array = { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };
  private byte[] buffer = new byte[3];
  private int bufsize = 0;
  private int bytesPerLine;
  private int count = 0;
  private int lineLimit;
  private boolean noCRLF = false;
  private byte[] outbuf;
  
  public BASE64EncoderStream(OutputStream paramOutputStream)
  {
    this(paramOutputStream, 76);
  }
  
  public BASE64EncoderStream(OutputStream paramOutputStream, int paramInt)
  {
    super(paramOutputStream);
    int i;
    if (paramInt != Integer.MAX_VALUE)
    {
      i = paramInt;
      if (paramInt >= 4) {}
    }
    else
    {
      this.noCRLF = true;
      i = 76;
    }
    paramInt = i / 4 * 4;
    this.bytesPerLine = paramInt;
    this.lineLimit = (paramInt / 4 * 3);
    if (this.noCRLF)
    {
      this.outbuf = new byte[paramInt];
      return;
    }
    this.outbuf = new byte[paramInt + 2];
    this.outbuf[paramInt] = 13;
    this.outbuf[(paramInt + 1)] = 10;
  }
  
  private void encode()
    throws IOException
  {
    int i = encodedSize(this.bufsize);
    this.out.write(encode(this.buffer, 0, this.bufsize, this.outbuf), 0, i);
    this.count += i;
    if (this.count >= this.bytesPerLine)
    {
      if (!this.noCRLF) {
        this.out.write(newline);
      }
      this.count = 0;
    }
  }
  
  public static byte[] encode(byte[] paramArrayOfByte)
  {
    if (paramArrayOfByte.length == 0) {
      return paramArrayOfByte;
    }
    return encode(paramArrayOfByte, 0, paramArrayOfByte.length, null);
  }
  
  private static byte[] encode(byte[] paramArrayOfByte1, int paramInt1, int paramInt2, byte[] paramArrayOfByte2)
  {
    byte[] arrayOfByte = paramArrayOfByte2;
    if (paramArrayOfByte2 == null) {
      arrayOfByte = new byte[encodedSize(paramInt2)];
    }
    int j = 0;
    int i = paramInt2;
    paramInt2 = j;
    for (;;)
    {
      if (i < 3)
      {
        if (i != 1) {
          break;
        }
        paramInt1 = (paramArrayOfByte1[paramInt1] & 0xFF) << 4;
        arrayOfByte[(paramInt2 + 3)] = 61;
        arrayOfByte[(paramInt2 + 2)] = 61;
        arrayOfByte[(paramInt2 + 1)] = ((byte)pem_array[(paramInt1 & 0x3F)]);
        arrayOfByte[(paramInt2 + 0)] = ((byte)pem_array[(paramInt1 >> 6 & 0x3F)]);
        return arrayOfByte;
      }
      j = paramInt1 + 1;
      int k = paramArrayOfByte1[paramInt1];
      paramInt1 = j + 1;
      j = ((k & 0xFF) << 8 | paramArrayOfByte1[j] & 0xFF) << 8 | paramArrayOfByte1[paramInt1] & 0xFF;
      arrayOfByte[(paramInt2 + 3)] = ((byte)pem_array[(j & 0x3F)]);
      j >>= 6;
      arrayOfByte[(paramInt2 + 2)] = ((byte)pem_array[(j & 0x3F)]);
      j >>= 6;
      arrayOfByte[(paramInt2 + 1)] = ((byte)pem_array[(j & 0x3F)]);
      arrayOfByte[(paramInt2 + 0)] = ((byte)pem_array[(j >> 6 & 0x3F)]);
      i -= 3;
      paramInt2 += 4;
      paramInt1 += 1;
    }
    j = paramInt1;
    if (i == 2)
    {
      i = paramInt1 + 1;
      paramInt1 = paramArrayOfByte1[paramInt1];
      j = i + 1;
      paramInt1 = ((paramInt1 & 0xFF) << 8 | paramArrayOfByte1[i] & 0xFF) << 2;
      arrayOfByte[(paramInt2 + 3)] = 61;
      arrayOfByte[(paramInt2 + 2)] = ((byte)pem_array[(paramInt1 & 0x3F)]);
      paramInt1 >>= 6;
      arrayOfByte[(paramInt2 + 1)] = ((byte)pem_array[(paramInt1 & 0x3F)]);
      arrayOfByte[(paramInt2 + 0)] = ((byte)pem_array[(paramInt1 >> 6 & 0x3F)]);
    }
    return arrayOfByte;
  }
  
  private static int encodedSize(int paramInt)
  {
    return (paramInt + 2) / 3 * 4;
  }
  
  public void close()
    throws IOException
  {
    try
    {
      flush();
      if ((this.count > 0) && (!this.noCRLF))
      {
        this.out.write(newline);
        this.out.flush();
      }
      this.out.close();
      return;
    }
    finally {}
  }
  
  public void flush()
    throws IOException
  {
    try
    {
      if (this.bufsize > 0)
      {
        encode();
        this.bufsize = 0;
      }
      this.out.flush();
      return;
    }
    finally {}
  }
  
  public void write(int paramInt)
    throws IOException
  {
    try
    {
      byte[] arrayOfByte = this.buffer;
      int i = this.bufsize;
      this.bufsize = (i + 1);
      arrayOfByte[i] = ((byte)paramInt);
      if (this.bufsize == 3)
      {
        encode();
        this.bufsize = 0;
      }
      return;
    }
    finally {}
  }
  
  public void write(byte[] paramArrayOfByte)
    throws IOException
  {
    write(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int j = paramInt1 + paramInt2;
    label275:
    for (;;)
    {
      try
      {
        if ((this.bufsize == 0) || (paramInt1 >= j))
        {
          int k = (this.bytesPerLine - this.count) / 4 * 3;
          if (paramInt1 + k >= j) {
            break label275;
          }
          i = encodedSize(k);
          paramInt2 = i;
          if (!this.noCRLF)
          {
            byte[] arrayOfByte = this.outbuf;
            int m = i + 1;
            arrayOfByte[i] = 13;
            arrayOfByte = this.outbuf;
            paramInt2 = m + 1;
            arrayOfByte[m] = 10;
          }
          this.out.write(encode(paramArrayOfByte, paramInt1, k, this.outbuf), 0, paramInt2);
          paramInt1 += k;
        }
      }
      finally
      {
        try
        {
          int i;
          this.count = 0;
          if (this.lineLimit + paramInt1 >= j)
          {
            paramInt2 = paramInt1;
            if (paramInt1 + 3 < j)
            {
              paramInt2 = (j - paramInt1) / 3 * 3;
              i = encodedSize(paramInt2);
              this.out.write(encode(paramArrayOfByte, paramInt1, paramInt2, this.outbuf), 0, i);
              paramInt2 = paramInt1 + paramInt2;
              this.count += i;
            }
            if (paramInt2 >= j)
            {
              return;
              write(paramArrayOfByte[paramInt1]);
              paramInt1 += 1;
            }
          }
          else
          {
            this.out.write(encode(paramArrayOfByte, paramInt1, this.lineLimit, this.outbuf));
            paramInt1 += this.lineLimit;
            continue;
          }
          write(paramArrayOfByte[paramInt2]);
          paramInt2 += 1;
          continue;
          paramArrayOfByte = finally;
        }
        finally
        {
          continue;
        }
      }
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/util/BASE64EncoderStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */