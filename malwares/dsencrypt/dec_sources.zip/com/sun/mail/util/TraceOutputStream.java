package com.sun.mail.util;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class TraceOutputStream
  extends FilterOutputStream
{
  private boolean quote = false;
  private boolean trace = false;
  private OutputStream traceOut;
  
  public TraceOutputStream(OutputStream paramOutputStream1, OutputStream paramOutputStream2)
  {
    super(paramOutputStream1);
    this.traceOut = paramOutputStream2;
  }
  
  private final void writeByte(int paramInt)
    throws IOException
  {
    int i = paramInt & 0xFF;
    paramInt = i;
    if (i > 127)
    {
      this.traceOut.write(77);
      this.traceOut.write(45);
      paramInt = i & 0x7F;
    }
    if (paramInt == 13)
    {
      this.traceOut.write(92);
      this.traceOut.write(114);
      return;
    }
    if (paramInt == 10)
    {
      this.traceOut.write(92);
      this.traceOut.write(110);
      this.traceOut.write(10);
      return;
    }
    if (paramInt == 9)
    {
      this.traceOut.write(92);
      this.traceOut.write(116);
      return;
    }
    if (paramInt < 32)
    {
      this.traceOut.write(94);
      this.traceOut.write(paramInt + 64);
      return;
    }
    this.traceOut.write(paramInt);
  }
  
  public void setQuote(boolean paramBoolean)
  {
    this.quote = paramBoolean;
  }
  
  public void setTrace(boolean paramBoolean)
  {
    this.trace = paramBoolean;
  }
  
  public void write(int paramInt)
    throws IOException
  {
    if (this.trace)
    {
      if (!this.quote) {
        break label28;
      }
      writeByte(paramInt);
    }
    for (;;)
    {
      this.out.write(paramInt);
      return;
      label28:
      this.traceOut.write(paramInt);
    }
  }
  
  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i;
    if (this.trace)
    {
      if (!this.quote) {
        break label53;
      }
      i = 0;
      if (i < paramInt2) {
        break label34;
      }
    }
    for (;;)
    {
      this.out.write(paramArrayOfByte, paramInt1, paramInt2);
      return;
      label34:
      writeByte(paramArrayOfByte[(paramInt1 + i)]);
      i += 1;
      break;
      label53:
      this.traceOut.write(paramArrayOfByte, paramInt1, paramInt2);
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/util/TraceOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */