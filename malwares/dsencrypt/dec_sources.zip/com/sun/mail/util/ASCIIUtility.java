package com.sun.mail.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class ASCIIUtility
{
  public static byte[] getBytes(InputStream paramInputStream)
    throws IOException
  {
    int i;
    if ((paramInputStream instanceof ByteArrayInputStream))
    {
      i = paramInputStream.available();
      localObject = new byte[i];
      paramInputStream.read((byte[])localObject, 0, i);
      return (byte[])localObject;
    }
    Object localObject = new ByteArrayOutputStream();
    byte[] arrayOfByte = new byte['Ѐ'];
    for (;;)
    {
      i = paramInputStream.read(arrayOfByte, 0, 1024);
      if (i == -1) {
        return ((ByteArrayOutputStream)localObject).toByteArray();
      }
      ((ByteArrayOutputStream)localObject).write(arrayOfByte, 0, i);
    }
  }
  
  public static byte[] getBytes(String paramString)
  {
    paramString = paramString.toCharArray();
    int j = paramString.length;
    byte[] arrayOfByte = new byte[j];
    int i = 0;
    for (;;)
    {
      if (i >= j) {
        return arrayOfByte;
      }
      arrayOfByte[i] = ((byte)paramString[i]);
      i += 1;
    }
  }
  
  public static int parseInt(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws NumberFormatException
  {
    return parseInt(paramArrayOfByte, paramInt1, paramInt2, 10);
  }
  
  public static int parseInt(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3)
    throws NumberFormatException
  {
    if (paramArrayOfByte == null) {
      throw new NumberFormatException("null");
    }
    int j = 0;
    int m = 0;
    int i = paramInt1;
    int k;
    int i1;
    int n;
    if (paramInt2 > paramInt1)
    {
      if (paramArrayOfByte[i] == 45)
      {
        m = 1;
        k = Integer.MIN_VALUE;
        i += 1;
      }
      for (;;)
      {
        i1 = k / paramInt3;
        if (i >= paramInt2) {
          break label260;
        }
        n = i + 1;
        i = Character.digit((char)paramArrayOfByte[i], paramInt3);
        if (i >= 0) {
          break;
        }
        throw new NumberFormatException("illegal number: " + toString(paramArrayOfByte, paramInt1, paramInt2));
        k = -2147483647;
      }
      j = -i;
      i = n;
    }
    label256:
    label260:
    for (;;)
    {
      if (i >= paramInt2)
      {
        if (m == 0) {
          break label256;
        }
        if (i > paramInt1 + 1) {
          return j;
        }
      }
      else
      {
        n = Character.digit((char)paramArrayOfByte[i], paramInt3);
        if (n < 0) {
          throw new NumberFormatException("illegal number");
        }
        if (j < i1) {
          throw new NumberFormatException("illegal number");
        }
        j *= paramInt3;
        if (j < k + n) {
          throw new NumberFormatException("illegal number");
        }
        j -= n;
        i += 1;
        continue;
        throw new NumberFormatException("illegal number");
      }
      throw new NumberFormatException("illegal number");
      return -j;
    }
  }
  
  public static long parseLong(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws NumberFormatException
  {
    return parseLong(paramArrayOfByte, paramInt1, paramInt2, 10);
  }
  
  public static long parseLong(byte[] paramArrayOfByte, int paramInt1, int paramInt2, int paramInt3)
    throws NumberFormatException
  {
    if (paramArrayOfByte == null) {
      throw new NumberFormatException("null");
    }
    long l1 = 0L;
    int j = 0;
    int i = paramInt1;
    long l2;
    long l3;
    int k;
    if (paramInt2 > paramInt1)
    {
      if (paramArrayOfByte[i] == 45)
      {
        j = 1;
        l2 = Long.MIN_VALUE;
        i += 1;
      }
      for (;;)
      {
        l3 = l2 / paramInt3;
        if (i >= paramInt2) {
          break label269;
        }
        k = i + 1;
        i = Character.digit((char)paramArrayOfByte[i], paramInt3);
        if (i >= 0) {
          break;
        }
        throw new NumberFormatException("illegal number: " + toString(paramArrayOfByte, paramInt1, paramInt2));
        l2 = -9223372036854775807L;
      }
      l1 = -i;
      i = k;
    }
    label265:
    label269:
    for (;;)
    {
      if (i >= paramInt2)
      {
        if (j == 0) {
          break label265;
        }
        if (i > paramInt1 + 1) {
          return l1;
        }
      }
      else
      {
        k = Character.digit((char)paramArrayOfByte[i], paramInt3);
        if (k < 0) {
          throw new NumberFormatException("illegal number");
        }
        if (l1 < l3) {
          throw new NumberFormatException("illegal number");
        }
        l1 *= paramInt3;
        if (l1 < k + l2) {
          throw new NumberFormatException("illegal number");
        }
        l1 -= k;
        i += 1;
        continue;
        throw new NumberFormatException("illegal number");
      }
      throw new NumberFormatException("illegal number");
      return -l1;
    }
  }
  
  public static String toString(ByteArrayInputStream paramByteArrayInputStream)
  {
    int j = paramByteArrayInputStream.available();
    char[] arrayOfChar = new char[j];
    byte[] arrayOfByte = new byte[j];
    paramByteArrayInputStream.read(arrayOfByte, 0, j);
    int i = 0;
    for (;;)
    {
      if (i >= j) {
        return new String(arrayOfChar);
      }
      arrayOfChar[i] = ((char)(arrayOfByte[i] & 0xFF));
      i += 1;
    }
  }
  
  public static String toString(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
  {
    int j = paramInt2 - paramInt1;
    char[] arrayOfChar = new char[j];
    int i = 0;
    paramInt2 = paramInt1;
    paramInt1 = i;
    for (;;)
    {
      if (paramInt1 >= j) {
        return new String(arrayOfChar);
      }
      arrayOfChar[paramInt1] = ((char)(paramArrayOfByte[paramInt2] & 0xFF));
      paramInt2 += 1;
      paramInt1 += 1;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/util/ASCIIUtility.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */