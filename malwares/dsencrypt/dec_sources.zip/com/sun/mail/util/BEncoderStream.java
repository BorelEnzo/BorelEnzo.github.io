package com.sun.mail.util;

import java.io.OutputStream;

public class BEncoderStream
  extends BASE64EncoderStream
{
  public BEncoderStream(OutputStream paramOutputStream)
  {
    super(paramOutputStream, Integer.MAX_VALUE);
  }
  
  public static int encodedLength(byte[] paramArrayOfByte)
  {
    return (paramArrayOfByte.length + 2) / 3 * 4;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/util/BEncoderStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */