package com.sun.mail.util;

import java.io.IOException;
import java.io.OutputStream;

public class QEncoderStream
  extends QPEncoderStream
{
  private static String TEXT_SPECIALS = "=_?";
  private static String WORD_SPECIALS = "=_?\"#$%&'(),.:;<>@[\\]^`{|}~";
  private String specials;
  
  public QEncoderStream(OutputStream paramOutputStream, boolean paramBoolean)
  {
    super(paramOutputStream, Integer.MAX_VALUE);
    if (paramBoolean) {}
    for (paramOutputStream = WORD_SPECIALS;; paramOutputStream = TEXT_SPECIALS)
    {
      this.specials = paramOutputStream;
      return;
    }
  }
  
  public static int encodedLength(byte[] paramArrayOfByte, boolean paramBoolean)
  {
    int i = 0;
    if (paramBoolean) {}
    int j;
    for (String str = WORD_SPECIALS;; str = TEXT_SPECIALS)
    {
      j = 0;
      if (j < paramArrayOfByte.length) {
        break;
      }
      return i;
    }
    int k = paramArrayOfByte[j] & 0xFF;
    if ((k < 32) || (k >= 127) || (str.indexOf(k) >= 0)) {
      i += 3;
    }
    for (;;)
    {
      j += 1;
      break;
      i += 1;
    }
  }
  
  public void write(int paramInt)
    throws IOException
  {
    paramInt &= 0xFF;
    if (paramInt == 32)
    {
      output(95, false);
      return;
    }
    if ((paramInt < 32) || (paramInt >= 127) || (this.specials.indexOf(paramInt) >= 0))
    {
      output(paramInt, true);
      return;
    }
    output(paramInt, false);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/util/QEncoderStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */