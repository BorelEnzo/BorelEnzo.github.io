package com.sun.mail.util;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class TraceInputStream
  extends FilterInputStream
{
  private boolean quote = false;
  private boolean trace = false;
  private OutputStream traceOut;
  
  public TraceInputStream(InputStream paramInputStream, OutputStream paramOutputStream)
  {
    super(paramInputStream);
    this.traceOut = paramOutputStream;
  }
  
  private final void writeByte(int paramInt)
    throws IOException
  {
    int i = paramInt & 0xFF;
    paramInt = i;
    if (i > 127)
    {
      this.traceOut.write(77);
      this.traceOut.write(45);
      paramInt = i & 0x7F;
    }
    if (paramInt == 13)
    {
      this.traceOut.write(92);
      this.traceOut.write(114);
      return;
    }
    if (paramInt == 10)
    {
      this.traceOut.write(92);
      this.traceOut.write(110);
      this.traceOut.write(10);
      return;
    }
    if (paramInt == 9)
    {
      this.traceOut.write(92);
      this.traceOut.write(116);
      return;
    }
    if (paramInt < 32)
    {
      this.traceOut.write(94);
      this.traceOut.write(paramInt + 64);
      return;
    }
    this.traceOut.write(paramInt);
  }
  
  public int read()
    throws IOException
  {
    int i = this.in.read();
    if ((this.trace) && (i != -1))
    {
      if (this.quote) {
        writeByte(i);
      }
    }
    else {
      return i;
    }
    this.traceOut.write(i);
    return i;
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i = this.in.read(paramArrayOfByte, paramInt1, paramInt2);
    if ((this.trace) && (i != -1))
    {
      if (this.quote) {
        paramInt2 = 0;
      }
    }
    else {
      for (;;)
      {
        if (paramInt2 >= i) {
          return i;
        }
        writeByte(paramArrayOfByte[(paramInt1 + paramInt2)]);
        paramInt2 += 1;
      }
    }
    this.traceOut.write(paramArrayOfByte, paramInt1, i);
    return i;
  }
  
  public void setQuote(boolean paramBoolean)
  {
    this.quote = paramBoolean;
  }
  
  public void setTrace(boolean paramBoolean)
  {
    this.trace = paramBoolean;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/util/TraceInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */