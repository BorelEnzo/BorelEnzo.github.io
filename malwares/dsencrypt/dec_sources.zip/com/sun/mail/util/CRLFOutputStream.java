package com.sun.mail.util;

import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;

public class CRLFOutputStream
  extends FilterOutputStream
{
  private static final byte[] newline = { 13, 10 };
  protected boolean atBOL = true;
  protected int lastb = -1;
  
  public CRLFOutputStream(OutputStream paramOutputStream)
  {
    super(paramOutputStream);
  }
  
  public void write(int paramInt)
    throws IOException
  {
    if (paramInt == 13) {
      writeln();
    }
    for (;;)
    {
      this.lastb = paramInt;
      return;
      if (paramInt == 10)
      {
        if (this.lastb != 13) {
          writeln();
        }
      }
      else
      {
        this.out.write(paramInt);
        this.atBOL = false;
      }
    }
  }
  
  public void write(byte[] paramArrayOfByte)
    throws IOException
  {
    write(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i = paramInt1;
    int j = paramInt2 + paramInt1;
    paramInt2 = i;
    if (paramInt2 >= j)
    {
      if (j - i > 0)
      {
        this.out.write(paramArrayOfByte, i, j - i);
        this.atBOL = false;
      }
      return;
    }
    if (paramArrayOfByte[paramInt2] == 13)
    {
      this.out.write(paramArrayOfByte, i, paramInt2 - i);
      writeln();
      paramInt1 = paramInt2 + 1;
    }
    for (;;)
    {
      this.lastb = paramArrayOfByte[paramInt2];
      paramInt2 += 1;
      i = paramInt1;
      break;
      paramInt1 = i;
      if (paramArrayOfByte[paramInt2] == 10)
      {
        if (this.lastb != 13)
        {
          this.out.write(paramArrayOfByte, i, paramInt2 - i);
          writeln();
        }
        paramInt1 = paramInt2 + 1;
      }
    }
  }
  
  public void writeln()
    throws IOException
  {
    this.out.write(newline);
    this.atBOL = true;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/util/CRLFOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */