package com.sun.mail.util;

import java.io.EOFException;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

public class BASE64DecoderStream
  extends FilterInputStream
{
  private static final char[] pem_array = { 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 43, 47 };
  private static final byte[] pem_convert_array = new byte['Ā'];
  private byte[] buffer = new byte[3];
  private int bufsize = 0;
  private boolean ignoreErrors = false;
  private int index = 0;
  private byte[] input_buffer = new byte['῾'];
  private int input_len = 0;
  private int input_pos = 0;
  
  static
  {
    int i = 0;
    if (i >= 255) {
      i = 0;
    }
    for (;;)
    {
      if (i >= pem_array.length)
      {
        return;
        pem_convert_array[i] = -1;
        i += 1;
        break;
      }
      pem_convert_array[pem_array[i]] = ((byte)i);
      i += 1;
    }
  }
  
  public BASE64DecoderStream(InputStream paramInputStream)
  {
    super(paramInputStream);
    try
    {
      paramInputStream = System.getProperty("mail.mime.base64.ignoreerrors");
      boolean bool1 = bool2;
      if (paramInputStream != null)
      {
        bool1 = bool2;
        if (!paramInputStream.equalsIgnoreCase("false")) {
          bool1 = true;
        }
      }
      this.ignoreErrors = bool1;
      return;
    }
    catch (SecurityException paramInputStream) {}
  }
  
  public BASE64DecoderStream(InputStream paramInputStream, boolean paramBoolean)
  {
    super(paramInputStream);
    this.ignoreErrors = paramBoolean;
  }
  
  private int decode(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i = paramInt2;
    paramInt2 = paramInt1;
    int m = paramInt2;
    if (i < 3) {
      return m - paramInt1;
    }
    int k = 0;
    int j;
    for (paramInt2 = 0;; paramInt2 = paramInt2 << 6 | j)
    {
      if (k >= 4)
      {
        paramArrayOfByte[(m + 2)] = ((byte)(paramInt2 & 0xFF));
        paramInt2 >>= 8;
        paramArrayOfByte[(m + 1)] = ((byte)(paramInt2 & 0xFF));
        paramArrayOfByte[m] = ((byte)(paramInt2 >> 8 & 0xFF));
        i -= 3;
        paramInt2 = m + 3;
        break;
      }
      j = getByte();
      if ((j == -1) || (j == -2))
      {
        int n;
        if (j == -1)
        {
          if (k == 0) {
            return m - paramInt1;
          }
          if (!this.ignoreErrors) {
            throw new IOException("Error in encoded stream: needed 4 valid base64 characters but only got " + k + " before EOF" + recentChars());
          }
          i = 1;
          n = k - 1;
          j = n;
          if (n == 0) {
            j = 1;
          }
          n = k + 1;
          k = paramInt2 << 6;
          paramInt2 = n;
        }
        for (;;)
        {
          if (paramInt2 >= 4)
          {
            paramInt2 = k >> 8;
            if (j == 2) {
              paramArrayOfByte[(m + 1)] = ((byte)(paramInt2 & 0xFF));
            }
            paramArrayOfByte[m] = ((byte)(paramInt2 >> 8 & 0xFF));
            return m + j - paramInt1;
            if ((k < 2) && (!this.ignoreErrors)) {
              throw new IOException("Error in encoded stream: needed at least 2 valid base64 characters, but only got " + k + " before padding character (=)" + recentChars());
            }
            if (k == 0) {
              return m - paramInt1;
            }
            i = 0;
            break;
          }
          if (i == 0)
          {
            n = getByte();
            if (n == -1)
            {
              if (!this.ignoreErrors) {
                throw new IOException("Error in encoded stream: hit EOF while looking for padding characters (=)" + recentChars());
              }
            }
            else if ((n != -2) && (!this.ignoreErrors)) {
              throw new IOException("Error in encoded stream: found valid base64 character after a padding character (=)" + recentChars());
            }
          }
          k <<= 6;
          paramInt2 += 1;
        }
      }
      k += 1;
    }
  }
  
  public static byte[] decode(byte[] paramArrayOfByte)
  {
    int j = paramArrayOfByte.length / 4 * 3;
    if (j == 0) {
      return paramArrayOfByte;
    }
    int i = j;
    if (paramArrayOfByte[(paramArrayOfByte.length - 1)] == 61)
    {
      j -= 1;
      i = j;
      if (paramArrayOfByte[(paramArrayOfByte.length - 2)] == 61) {
        i = j - 1;
      }
    }
    byte[] arrayOfByte1 = new byte[i];
    int m = 0;
    int k = paramArrayOfByte.length;
    i = 0;
    if (k <= 0) {
      return arrayOfByte1;
    }
    j = 3;
    byte[] arrayOfByte2 = pem_convert_array;
    int n = i + 1;
    int i1 = arrayOfByte2[(paramArrayOfByte[i] & 0xFF)];
    arrayOfByte2 = pem_convert_array;
    i = n + 1;
    n = (i1 << 6 | arrayOfByte2[(paramArrayOfByte[n] & 0xFF)]) << 6;
    if (paramArrayOfByte[i] != 61)
    {
      arrayOfByte2 = pem_convert_array;
      i1 = i + 1;
      n |= arrayOfByte2[(paramArrayOfByte[i] & 0xFF)];
      i = j;
      j = i1;
      label161:
      n <<= 6;
      if (paramArrayOfByte[j] == 61) {
        break label284;
      }
      n |= pem_convert_array[(paramArrayOfByte[j] & 0xFF)];
      j += 1;
    }
    for (;;)
    {
      if (i > 2) {
        arrayOfByte1[(m + 2)] = ((byte)(n & 0xFF));
      }
      n >>= 8;
      if (i > 1) {
        arrayOfByte1[(m + 1)] = ((byte)(n & 0xFF));
      }
      arrayOfByte1[m] = ((byte)(n >> 8 & 0xFF));
      m += i;
      k -= 4;
      i = j;
      break;
      i1 = 3 - 1;
      j = i;
      i = i1;
      break label161;
      label284:
      i -= 1;
    }
  }
  
  private int getByte()
    throws IOException
  {
    int i;
    do
    {
      if (this.input_pos >= this.input_len)
      {
        try
        {
          this.input_len = this.in.read(this.input_buffer);
          if (this.input_len <= 0) {
            return -1;
          }
        }
        catch (EOFException localEOFException)
        {
          return -1;
        }
        this.input_pos = 0;
      }
      byte[] arrayOfByte = this.input_buffer;
      i = this.input_pos;
      this.input_pos = (i + 1);
      i = arrayOfByte[i] & 0xFF;
      if (i == 61) {
        return -2;
      }
      i = pem_convert_array[i];
    } while (i == -1);
    return i;
  }
  
  private String recentChars()
  {
    int i = 10;
    String str = "";
    if (this.input_pos > 10) {}
    for (;;)
    {
      if (i > 0)
      {
        str = "" + ", the " + i + " most recent characters were: \"";
        i = this.input_pos - i;
        if (i < this.input_pos) {
          break;
        }
        str = str + "\"";
      }
      return str;
      i = this.input_pos;
    }
    char c = (char)(this.input_buffer[i] & 0xFF);
    switch (c)
    {
    case '\013': 
    case '\f': 
    default: 
      if ((c >= ' ') && (c < '')) {
        str = str + c;
      }
      break;
    }
    for (;;)
    {
      i += 1;
      break;
      str = str + "\\r";
      continue;
      str = str + "\\n";
      continue;
      str = str + "\\t";
      continue;
      str = str + "\\" + c;
    }
  }
  
  public int available()
    throws IOException
  {
    return this.in.available() * 3 / 4 + (this.bufsize - this.index);
  }
  
  public boolean markSupported()
  {
    return false;
  }
  
  public int read()
    throws IOException
  {
    if (this.index >= this.bufsize)
    {
      this.bufsize = decode(this.buffer, 0, this.buffer.length);
      if (this.bufsize <= 0) {
        return -1;
      }
      this.index = 0;
    }
    byte[] arrayOfByte = this.buffer;
    int i = this.index;
    this.index = (i + 1);
    return arrayOfByte[i] & 0xFF;
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int k;
    int j;
    for (int i = paramInt1;; i = k + 1)
    {
      k = i;
      if ((this.index >= this.bufsize) || (paramInt2 <= 0))
      {
        if (this.index >= this.bufsize)
        {
          this.index = 0;
          this.bufsize = 0;
        }
        int m = paramInt2 / 3 * 3;
        j = k;
        i = paramInt2;
        if (m <= 0) {
          break label199;
        }
        int n = decode(paramArrayOfByte, k, m);
        k += n;
        i = paramInt2 - n;
        j = k;
        if (n == m) {
          break label199;
        }
        if (k != paramInt1) {
          break;
        }
        return -1;
      }
      byte[] arrayOfByte = this.buffer;
      i = this.index;
      this.index = (i + 1);
      paramArrayOfByte[k] = arrayOfByte[i];
      paramInt2 -= 1;
    }
    return k - paramInt1;
    label199:
    label203:
    for (;;)
    {
      j = read();
      if (j == -1)
      {
        if (paramInt2 == paramInt1) {
          return -1;
        }
      }
      else
      {
        paramArrayOfByte[paramInt2] = ((byte)j);
        i -= 1;
        paramInt2 += 1;
      }
      for (;;)
      {
        if (i > 0) {
          break label203;
        }
        break;
        return paramInt2 - paramInt1;
        paramInt2 = j;
      }
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/util/BASE64DecoderStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */