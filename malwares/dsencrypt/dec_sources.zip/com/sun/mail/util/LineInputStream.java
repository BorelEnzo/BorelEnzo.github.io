package com.sun.mail.util;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PushbackInputStream;

public class LineInputStream
  extends FilterInputStream
{
  private char[] lineBuffer = null;
  
  public LineInputStream(InputStream paramInputStream)
  {
    super(paramInputStream);
  }
  
  public String readLine()
    throws IOException
  {
    InputStream localInputStream = this.in;
    Object localObject2 = this.lineBuffer;
    Object localObject1 = localObject2;
    if (localObject2 == null)
    {
      localObject1 = new char[''];
      this.lineBuffer = ((char[])localObject1);
    }
    int i = localObject1.length;
    int j = 0;
    for (;;)
    {
      int m = localInputStream.read();
      if (m == -1) {}
      for (;;)
      {
        if ((m != -1) || (j != 0)) {
          break label205;
        }
        return null;
        if (m != 10)
        {
          if (m != 13) {
            break;
          }
          k = localInputStream.read();
          i = k;
          if (k == 13) {
            i = localInputStream.read();
          }
          if (i != 10)
          {
            localObject2 = localInputStream;
            if (!(localInputStream instanceof PushbackInputStream))
            {
              localObject2 = new PushbackInputStream(localInputStream);
              this.in = ((InputStream)localObject2);
            }
            ((PushbackInputStream)localObject2).unread(i);
          }
        }
      }
      int k = i - 1;
      i = k;
      if (k < 0)
      {
        localObject1 = new char[j + 128];
        i = localObject1.length - j - 1;
        System.arraycopy(this.lineBuffer, 0, localObject1, 0, j);
        this.lineBuffer = ((char[])localObject1);
      }
      localObject1[j] = ((char)m);
      j += 1;
    }
    label205:
    return String.copyValueOf((char[])localObject1, 0, j);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/util/LineInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */