package com.sun.mail.handlers;

import java.io.IOException;
import java.io.OutputStream;
import javax.activation.ActivationDataFlavor;
import javax.activation.DataContentHandler;
import javax.activation.DataSource;
import javax.mail.Message;
import javax.mail.MessagingException;
import myjava.awt.datatransfer.DataFlavor;

public class message_rfc822
  implements DataContentHandler
{
  ActivationDataFlavor ourDataFlavor = new ActivationDataFlavor(Message.class, "message/rfc822", "Message");
  
  /* Error */
  public Object getContent(DataSource paramDataSource)
    throws IOException
  {
    // Byte code:
    //   0: aload_1
    //   1: instanceof 34
    //   4: ifeq +31 -> 35
    //   7: aload_1
    //   8: checkcast 34	javax/mail/MessageAware
    //   11: invokeinterface 38 1 0
    //   16: invokevirtual 44	javax/mail/MessageContext:getSession	()Ljavax/mail/Session;
    //   19: astore_2
    //   20: new 46	javax/mail/internet/MimeMessage
    //   23: dup
    //   24: aload_2
    //   25: aload_1
    //   26: invokeinterface 52 1 0
    //   31: invokespecial 55	javax/mail/internet/MimeMessage:<init>	(Ljavax/mail/Session;Ljava/io/InputStream;)V
    //   34: areturn
    //   35: new 57	java/util/Properties
    //   38: dup
    //   39: invokespecial 58	java/util/Properties:<init>	()V
    //   42: aconst_null
    //   43: invokestatic 64	javax/mail/Session:getDefaultInstance	(Ljava/util/Properties;Ljavax/mail/Authenticator;)Ljavax/mail/Session;
    //   46: astore_2
    //   47: goto -27 -> 20
    //   50: astore_1
    //   51: new 30	java/io/IOException
    //   54: dup
    //   55: new 66	java/lang/StringBuilder
    //   58: dup
    //   59: ldc 68
    //   61: invokespecial 71	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   64: aload_1
    //   65: invokevirtual 75	javax/mail/MessagingException:toString	()Ljava/lang/String;
    //   68: invokevirtual 79	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   71: invokevirtual 80	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   74: invokespecial 81	java/io/IOException:<init>	(Ljava/lang/String;)V
    //   77: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	78	0	this	message_rfc822
    //   0	78	1	paramDataSource	DataSource
    //   19	28	2	localSession	javax.mail.Session
    // Exception table:
    //   from	to	target	type
    //   0	20	50	javax/mail/MessagingException
    //   20	35	50	javax/mail/MessagingException
    //   35	47	50	javax/mail/MessagingException
  }
  
  public Object getTransferData(DataFlavor paramDataFlavor, DataSource paramDataSource)
    throws IOException
  {
    if (this.ourDataFlavor.equals(paramDataFlavor)) {
      return getContent(paramDataSource);
    }
    return null;
  }
  
  public DataFlavor[] getTransferDataFlavors()
  {
    return new DataFlavor[] { this.ourDataFlavor };
  }
  
  public void writeTo(Object paramObject, String paramString, OutputStream paramOutputStream)
    throws IOException
  {
    if ((paramObject instanceof Message))
    {
      paramObject = (Message)paramObject;
      try
      {
        ((Message)paramObject).writeTo(paramOutputStream);
        return;
      }
      catch (MessagingException paramObject)
      {
        throw new IOException(((MessagingException)paramObject).toString());
      }
    }
    throw new IOException("unsupported object");
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/handlers/message_rfc822.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */