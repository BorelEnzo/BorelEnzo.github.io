package com.sun.mail.handlers;

import javax.activation.ActivationDataFlavor;

public class text_xml
  extends text_plain
{
  private static ActivationDataFlavor myDF = new ActivationDataFlavor(String.class, "text/xml", "XML String");
  
  protected ActivationDataFlavor getDF()
  {
    return myDF;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/handlers/text_xml.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */