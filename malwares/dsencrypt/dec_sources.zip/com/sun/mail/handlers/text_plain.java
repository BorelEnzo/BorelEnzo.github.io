package com.sun.mail.handlers;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import javax.activation.ActivationDataFlavor;
import javax.activation.DataContentHandler;
import javax.activation.DataSource;
import javax.mail.internet.ContentType;
import javax.mail.internet.MimeUtility;
import myjava.awt.datatransfer.DataFlavor;

public class text_plain
  implements DataContentHandler
{
  private static ActivationDataFlavor myDF = new ActivationDataFlavor(String.class, "text/plain", "Text String");
  
  private String getCharset(String paramString)
  {
    try
    {
      String str = new ContentType(paramString).getParameter("charset");
      paramString = str;
      if (str == null) {
        paramString = "us-ascii";
      }
      paramString = MimeUtility.javaCharset(paramString);
      return paramString;
    }
    catch (Exception paramString) {}
    return null;
  }
  
  /* Error */
  public Object getContent(DataSource paramDataSource)
    throws IOException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 4
    //   3: aload_0
    //   4: aload_1
    //   5: invokeinterface 60 1 0
    //   10: invokespecial 62	com/sun/mail/handlers/text_plain:getCharset	(Ljava/lang/String;)Ljava/lang/String;
    //   13: astore 5
    //   15: aload 5
    //   17: astore 4
    //   19: new 64	java/io/InputStreamReader
    //   22: dup
    //   23: aload_1
    //   24: invokeinterface 68 1 0
    //   29: aload 5
    //   31: invokespecial 71	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;Ljava/lang/String;)V
    //   34: astore 5
    //   36: iconst_0
    //   37: istore_2
    //   38: sipush 1024
    //   41: newarray <illegal type>
    //   43: astore_1
    //   44: aload 5
    //   46: aload_1
    //   47: iload_2
    //   48: aload_1
    //   49: arraylength
    //   50: iload_2
    //   51: isub
    //   52: invokevirtual 75	java/io/InputStreamReader:read	([CII)I
    //   55: istore_3
    //   56: iload_3
    //   57: iconst_m1
    //   58: if_icmpne +32 -> 90
    //   61: new 14	java/lang/String
    //   64: dup
    //   65: aload_1
    //   66: iconst_0
    //   67: iload_2
    //   68: invokespecial 78	java/lang/String:<init>	([CII)V
    //   71: astore_1
    //   72: aload 5
    //   74: invokevirtual 81	java/io/InputStreamReader:close	()V
    //   77: aload_1
    //   78: areturn
    //   79: astore_1
    //   80: new 83	java/io/UnsupportedEncodingException
    //   83: dup
    //   84: aload 4
    //   86: invokespecial 84	java/io/UnsupportedEncodingException:<init>	(Ljava/lang/String;)V
    //   89: athrow
    //   90: iload_2
    //   91: iload_3
    //   92: iadd
    //   93: istore_3
    //   94: iload_3
    //   95: istore_2
    //   96: iload_3
    //   97: aload_1
    //   98: arraylength
    //   99: if_icmplt -55 -> 44
    //   102: aload_1
    //   103: arraylength
    //   104: istore_2
    //   105: iload_2
    //   106: ldc 85
    //   108: if_icmpge +29 -> 137
    //   111: iload_2
    //   112: iload_2
    //   113: iadd
    //   114: istore_2
    //   115: iload_2
    //   116: newarray <illegal type>
    //   118: astore 4
    //   120: aload_1
    //   121: iconst_0
    //   122: aload 4
    //   124: iconst_0
    //   125: iload_3
    //   126: invokestatic 91	java/lang/System:arraycopy	(Ljava/lang/Object;ILjava/lang/Object;II)V
    //   129: aload 4
    //   131: astore_1
    //   132: iload_3
    //   133: istore_2
    //   134: goto -90 -> 44
    //   137: iload_2
    //   138: ldc 85
    //   140: iadd
    //   141: istore_2
    //   142: goto -27 -> 115
    //   145: astore_1
    //   146: aload 5
    //   148: invokevirtual 81	java/io/InputStreamReader:close	()V
    //   151: aload_1
    //   152: athrow
    //   153: astore 4
    //   155: aload_1
    //   156: areturn
    //   157: astore 4
    //   159: goto -8 -> 151
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	162	0	this	text_plain
    //   0	162	1	paramDataSource	DataSource
    //   37	105	2	i	int
    //   55	78	3	j	int
    //   1	129	4	localObject1	Object
    //   153	1	4	localIOException1	IOException
    //   157	1	4	localIOException2	IOException
    //   13	134	5	localObject2	Object
    // Exception table:
    //   from	to	target	type
    //   3	15	79	java/lang/IllegalArgumentException
    //   19	36	79	java/lang/IllegalArgumentException
    //   38	44	145	finally
    //   44	56	145	finally
    //   61	72	145	finally
    //   96	105	145	finally
    //   115	129	145	finally
    //   72	77	153	java/io/IOException
    //   146	151	157	java/io/IOException
  }
  
  protected ActivationDataFlavor getDF()
  {
    return myDF;
  }
  
  public Object getTransferData(DataFlavor paramDataFlavor, DataSource paramDataSource)
    throws IOException
  {
    if (getDF().equals(paramDataFlavor)) {
      return getContent(paramDataSource);
    }
    return null;
  }
  
  public DataFlavor[] getTransferDataFlavors()
  {
    return new DataFlavor[] { getDF() };
  }
  
  public void writeTo(Object paramObject, String paramString, OutputStream paramOutputStream)
    throws IOException
  {
    if (!(paramObject instanceof String)) {
      throw new IOException("\"" + getDF().getMimeType() + "\" DataContentHandler requires String object, " + "was given object of type " + paramObject.getClass().toString());
    }
    String str = null;
    try
    {
      paramString = getCharset(paramString);
      str = paramString;
      paramString = new OutputStreamWriter(paramOutputStream, paramString);
      paramObject = (String)paramObject;
      paramString.write((String)paramObject, 0, ((String)paramObject).length());
      paramString.flush();
      return;
    }
    catch (IllegalArgumentException paramObject)
    {
      throw new UnsupportedEncodingException(str);
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/handlers/text_plain.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */