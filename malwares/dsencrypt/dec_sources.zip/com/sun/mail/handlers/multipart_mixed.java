package com.sun.mail.handlers;

import java.io.IOException;
import java.io.OutputStream;
import javax.activation.ActivationDataFlavor;
import javax.activation.DataContentHandler;
import javax.activation.DataSource;
import javax.mail.MessagingException;
import javax.mail.internet.MimeMultipart;
import myjava.awt.datatransfer.DataFlavor;

public class multipart_mixed
  implements DataContentHandler
{
  private ActivationDataFlavor myDF = new ActivationDataFlavor(MimeMultipart.class, "multipart/mixed", "Multipart");
  
  public Object getContent(DataSource paramDataSource)
    throws IOException
  {
    try
    {
      paramDataSource = new MimeMultipart(paramDataSource);
      return paramDataSource;
    }
    catch (MessagingException paramDataSource)
    {
      IOException localIOException = new IOException("Exception while constructing MimeMultipart");
      localIOException.initCause(paramDataSource);
      throw localIOException;
    }
  }
  
  public Object getTransferData(DataFlavor paramDataFlavor, DataSource paramDataSource)
    throws IOException
  {
    if (this.myDF.equals(paramDataFlavor)) {
      return getContent(paramDataSource);
    }
    return null;
  }
  
  public DataFlavor[] getTransferDataFlavors()
  {
    return new DataFlavor[] { this.myDF };
  }
  
  public void writeTo(Object paramObject, String paramString, OutputStream paramOutputStream)
    throws IOException
  {
    if ((paramObject instanceof MimeMultipart)) {}
    try
    {
      ((MimeMultipart)paramObject).writeTo(paramOutputStream);
      return;
    }
    catch (MessagingException paramObject)
    {
      throw new IOException(((MessagingException)paramObject).toString());
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/mail/handlers/multipart_mixed.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */