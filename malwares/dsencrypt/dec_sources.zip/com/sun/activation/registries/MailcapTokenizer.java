package com.sun.activation.registries;

public class MailcapTokenizer
{
  public static final int EOI_TOKEN = 5;
  public static final int EQUALS_TOKEN = 61;
  public static final int SEMICOLON_TOKEN = 59;
  public static final int SLASH_TOKEN = 47;
  public static final int START_TOKEN = 1;
  public static final int STRING_TOKEN = 2;
  public static final int UNKNOWN_TOKEN = 0;
  private char autoquoteChar;
  private int currentToken;
  private String currentTokenValue;
  private String data;
  private int dataIndex;
  private int dataLength;
  private boolean isAutoquoting;
  
  public MailcapTokenizer(String paramString)
  {
    this.data = paramString;
    this.dataIndex = 0;
    this.dataLength = paramString.length();
    this.currentToken = 1;
    this.currentTokenValue = "";
    this.isAutoquoting = false;
    this.autoquoteChar = ';';
  }
  
  private static String fixEscapeSequences(String paramString)
  {
    int j = paramString.length();
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.ensureCapacity(j);
    int i = 0;
    if (i >= j) {
      return localStringBuffer.toString();
    }
    char c = paramString.charAt(i);
    if (c != '\\') {
      localStringBuffer.append(c);
    }
    for (;;)
    {
      i += 1;
      break;
      if (i < j - 1)
      {
        localStringBuffer.append(paramString.charAt(i + 1));
        i += 1;
      }
      else
      {
        localStringBuffer.append(c);
      }
    }
  }
  
  private static boolean isControlChar(char paramChar)
  {
    return Character.isISOControl(paramChar);
  }
  
  private static boolean isSpecialChar(char paramChar)
  {
    switch (paramChar)
    {
    default: 
      return false;
    }
    return true;
  }
  
  private static boolean isStringTokenChar(char paramChar)
  {
    return (!isSpecialChar(paramChar)) && (!isControlChar(paramChar)) && (!isWhiteSpaceChar(paramChar));
  }
  
  private static boolean isWhiteSpaceChar(char paramChar)
  {
    return Character.isWhitespace(paramChar);
  }
  
  public static String nameForToken(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return "really unknown";
    case 0: 
      return "unknown";
    case 1: 
      return "start";
    case 2: 
      return "string";
    case 5: 
      return "EOI";
    case 47: 
      return "'/'";
    case 59: 
      return "';'";
    }
    return "'='";
  }
  
  private void processAutoquoteToken()
  {
    int j = this.dataIndex;
    int i = 0;
    for (;;)
    {
      if ((this.dataIndex >= this.dataLength) || (i != 0))
      {
        this.currentToken = 2;
        this.currentTokenValue = fixEscapeSequences(this.data.substring(j, this.dataIndex));
        return;
      }
      if (this.data.charAt(this.dataIndex) != this.autoquoteChar) {
        this.dataIndex += 1;
      } else {
        i = 1;
      }
    }
  }
  
  private void processStringToken()
  {
    int i = this.dataIndex;
    for (;;)
    {
      if ((this.dataIndex >= this.dataLength) || (!isStringTokenChar(this.data.charAt(this.dataIndex))))
      {
        this.currentToken = 2;
        this.currentTokenValue = this.data.substring(i, this.dataIndex);
        return;
      }
      this.dataIndex += 1;
    }
  }
  
  public int getCurrentToken()
  {
    return this.currentToken;
  }
  
  public String getCurrentTokenValue()
  {
    return this.currentTokenValue;
  }
  
  public int nextToken()
  {
    char c;
    if (this.dataIndex < this.dataLength) {
      if ((this.dataIndex >= this.dataLength) || (!isWhiteSpaceChar(this.data.charAt(this.dataIndex))))
      {
        if (this.dataIndex >= this.dataLength) {
          break label234;
        }
        c = this.data.charAt(this.dataIndex);
        if (!this.isAutoquoting) {
          break label136;
        }
        if ((c != ';') && (c != '=')) {
          break label129;
        }
        this.currentToken = c;
        this.currentTokenValue = new Character(c).toString();
        this.dataIndex += 1;
      }
    }
    for (;;)
    {
      return this.currentToken;
      this.dataIndex += 1;
      break;
      label129:
      processAutoquoteToken();
      continue;
      label136:
      if (isStringTokenChar(c))
      {
        processStringToken();
      }
      else if ((c == '/') || (c == ';') || (c == '='))
      {
        this.currentToken = c;
        this.currentTokenValue = new Character(c).toString();
        this.dataIndex += 1;
      }
      else
      {
        this.currentToken = 0;
        this.currentTokenValue = new Character(c).toString();
        this.dataIndex += 1;
        continue;
        label234:
        this.currentToken = 5;
        this.currentTokenValue = null;
        continue;
        this.currentToken = 5;
        this.currentTokenValue = null;
      }
    }
  }
  
  public void setIsAutoquoting(boolean paramBoolean)
  {
    this.isAutoquoting = paramBoolean;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/activation/registries/MailcapTokenizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */