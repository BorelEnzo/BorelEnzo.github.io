package com.sun.activation.registries;

import java.util.NoSuchElementException;
import java.util.Vector;

class LineTokenizer
{
  private static final String singles = "=";
  private int currentPosition = 0;
  private int maxPosition;
  private Vector stack = new Vector();
  private String str;
  
  public LineTokenizer(String paramString)
  {
    this.str = paramString;
    this.maxPosition = paramString.length();
  }
  
  private void skipWhiteSpace()
  {
    for (;;)
    {
      if ((this.currentPosition >= this.maxPosition) || (!Character.isWhitespace(this.str.charAt(this.currentPosition)))) {
        return;
      }
      this.currentPosition += 1;
    }
  }
  
  public boolean hasMoreTokens()
  {
    if (this.stack.size() > 0) {}
    do
    {
      return true;
      skipWhiteSpace();
    } while (this.currentPosition < this.maxPosition);
    return false;
  }
  
  public String nextToken()
  {
    int i = this.stack.size();
    Object localObject;
    if (i > 0)
    {
      localObject = (String)this.stack.elementAt(i - 1);
      this.stack.removeElementAt(i - 1);
      return (String)localObject;
    }
    skipWhiteSpace();
    if (this.currentPosition >= this.maxPosition) {
      throw new NoSuchElementException();
    }
    int j = this.currentPosition;
    i = this.str.charAt(j);
    if (i == 34)
    {
      this.currentPosition += 1;
      i = 0;
      if (this.currentPosition < this.maxPosition) {}
    }
    for (;;)
    {
      return this.str.substring(j, this.currentPosition);
      localObject = this.str;
      int k = this.currentPosition;
      this.currentPosition = (k + 1);
      k = ((String)localObject).charAt(k);
      if (k == 92)
      {
        this.currentPosition += 1;
        i = 1;
        break;
      }
      if (k != 34) {
        break;
      }
      if (i != 0)
      {
        localObject = new StringBuffer();
        i = j + 1;
        if (i < this.currentPosition - 1) {}
      }
      for (localObject = ((StringBuffer)localObject).toString();; localObject = this.str.substring(j + 1, this.currentPosition - 1))
      {
        return (String)localObject;
        char c = this.str.charAt(i);
        if (c != '\\') {
          ((StringBuffer)localObject).append(c);
        }
        i += 1;
        break;
      }
      if ("=".indexOf(i) >= 0) {
        this.currentPosition += 1;
      } else {
        do
        {
          this.currentPosition += 1;
          if ((this.currentPosition >= this.maxPosition) || ("=".indexOf(this.str.charAt(this.currentPosition)) >= 0)) {
            break;
          }
        } while (!Character.isWhitespace(this.str.charAt(this.currentPosition)));
      }
    }
  }
  
  public void pushToken(String paramString)
  {
    this.stack.addElement(paramString);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/activation/registries/LineTokenizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */