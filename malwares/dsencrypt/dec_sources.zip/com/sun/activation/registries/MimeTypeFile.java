package com.sun.activation.registries;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.util.Hashtable;
import java.util.StringTokenizer;

public class MimeTypeFile
{
  private String fname = null;
  private Hashtable type_hash = new Hashtable();
  
  public MimeTypeFile() {}
  
  public MimeTypeFile(InputStream paramInputStream)
    throws IOException
  {
    parse(new BufferedReader(new InputStreamReader(paramInputStream, "iso-8859-1")));
  }
  
  public MimeTypeFile(String paramString)
    throws IOException
  {
    this.fname = paramString;
    FileReader localFileReader = new FileReader(new File(this.fname));
    try
    {
      parse(new BufferedReader(localFileReader));
      return;
    }
    finally
    {
      try
      {
        localFileReader.close();
        return;
      }
      catch (IOException paramString) {}
      paramString = finally;
      try
      {
        localFileReader.close();
        throw paramString;
      }
      catch (IOException localIOException)
      {
        for (;;) {}
      }
    }
  }
  
  private void parse(BufferedReader paramBufferedReader)
    throws IOException
  {
    Object localObject = null;
    for (;;)
    {
      String str = paramBufferedReader.readLine();
      if (str == null)
      {
        if (localObject != null) {
          parseEntry((String)localObject);
        }
        return;
      }
      if (localObject == null) {}
      for (localObject = str;; localObject = localObject + str)
      {
        int i = ((String)localObject).length();
        if ((((String)localObject).length() <= 0) || (((String)localObject).charAt(i - 1) != '\\')) {
          break label89;
        }
        localObject = ((String)localObject).substring(0, i - 1);
        break;
      }
      label89:
      parseEntry((String)localObject);
      localObject = null;
    }
  }
  
  private void parseEntry(String paramString)
  {
    String str1 = null;
    Object localObject1 = paramString.trim();
    if (((String)localObject1).length() == 0)
    {
      return;
      break label16;
      break label49;
    }
    for (;;)
    {
      label16:
      if (((String)localObject1).charAt(0) != '#')
      {
        label49:
        String str2;
        if (((String)localObject1).indexOf('=') > 0)
        {
          LineTokenizer localLineTokenizer = new LineTokenizer((String)localObject1);
          for (;;)
          {
            Object localObject2;
            if (localLineTokenizer.hasMoreTokens())
            {
              localObject2 = localLineTokenizer.nextToken();
              str2 = null;
              paramString = str2;
              if (localLineTokenizer.hasMoreTokens())
              {
                paramString = str2;
                if (localLineTokenizer.nextToken().equals("="))
                {
                  paramString = str2;
                  if (localLineTokenizer.hasMoreTokens()) {
                    paramString = localLineTokenizer.nextToken();
                  }
                }
              }
              if (paramString == null)
              {
                if (!LogSupport.isLoggable()) {
                  break;
                }
                LogSupport.log("Bad .mime.types entry: " + (String)localObject1);
                return;
              }
              if (!((String)localObject2).equals("type")) {
                break label153;
              }
              str1 = paramString;
              continue;
            }
            break label16;
            label153:
            if (!((String)localObject2).equals("exts")) {
              break;
            }
            paramString = new StringTokenizer(paramString, ",");
            while (paramString.hasMoreTokens())
            {
              str2 = paramString.nextToken();
              localObject2 = new MimeTypeEntry(str1, str2);
              this.type_hash.put(str2, localObject2);
              if (LogSupport.isLoggable()) {
                LogSupport.log("Added: " + ((MimeTypeEntry)localObject2).toString());
              }
            }
          }
        }
        paramString = new StringTokenizer((String)localObject1);
        if (paramString.countTokens() == 0) {
          break;
        }
        str1 = paramString.nextToken();
        while (paramString.hasMoreTokens())
        {
          str2 = paramString.nextToken();
          localObject1 = new MimeTypeEntry(str1, str2);
          this.type_hash.put(str2, localObject1);
          if (LogSupport.isLoggable()) {
            LogSupport.log("Added: " + ((MimeTypeEntry)localObject1).toString());
          }
        }
      }
    }
  }
  
  public void appendToRegistry(String paramString)
  {
    try
    {
      parse(new BufferedReader(new StringReader(paramString)));
      return;
    }
    catch (IOException paramString) {}
  }
  
  public String getMIMETypeString(String paramString)
  {
    paramString = getMimeTypeEntry(paramString);
    if (paramString != null) {
      return paramString.getMIMEType();
    }
    return null;
  }
  
  public MimeTypeEntry getMimeTypeEntry(String paramString)
  {
    return (MimeTypeEntry)this.type_hash.get(paramString);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/activation/registries/MimeTypeFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */