package com.sun.activation.registries;

import java.io.PrintStream;
import java.util.logging.Level;
import java.util.logging.Logger;

public class LogSupport
{
  private static boolean debug = false;
  private static final Level level = Level.FINE;
  private static Logger logger;
  
  static
  {
    try
    {
      debug = Boolean.getBoolean("javax.activation.debug");
      logger = Logger.getLogger("javax.activation");
      return;
    }
    catch (Throwable localThrowable)
    {
      for (;;) {}
    }
  }
  
  public static boolean isLoggable()
  {
    return (debug) || (logger.isLoggable(level));
  }
  
  public static void log(String paramString)
  {
    if (debug) {
      System.out.println(paramString);
    }
    logger.log(level, paramString);
  }
  
  public static void log(String paramString, Throwable paramThrowable)
  {
    if (debug) {
      System.out.println(paramString + "; Exception: " + paramThrowable);
    }
    logger.log(level, paramString, paramThrowable);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/activation/registries/LogSupport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */