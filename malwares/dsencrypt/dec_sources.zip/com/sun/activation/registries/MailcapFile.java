package com.sun.activation.registries;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class MailcapFile
{
  private static boolean addReverse = false;
  private Map fallback_hash = new HashMap();
  private Map native_commands = new HashMap();
  private Map type_hash = new HashMap();
  
  static
  {
    try
    {
      addReverse = Boolean.getBoolean("javax.activation.addreverse");
      return;
    }
    catch (Throwable localThrowable) {}
  }
  
  public MailcapFile()
  {
    if (LogSupport.isLoggable()) {
      LogSupport.log("new MailcapFile: default");
    }
  }
  
  public MailcapFile(InputStream paramInputStream)
    throws IOException
  {
    if (LogSupport.isLoggable()) {
      LogSupport.log("new MailcapFile: InputStream");
    }
    parse(new BufferedReader(new InputStreamReader(paramInputStream, "iso-8859-1")));
  }
  
  /* Error */
  public MailcapFile(String paramString)
    throws IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial 28	java/lang/Object:<init>	()V
    //   4: aload_0
    //   5: new 30	java/util/HashMap
    //   8: dup
    //   9: invokespecial 31	java/util/HashMap:<init>	()V
    //   12: putfield 33	com/sun/activation/registries/MailcapFile:type_hash	Ljava/util/Map;
    //   15: aload_0
    //   16: new 30	java/util/HashMap
    //   19: dup
    //   20: invokespecial 31	java/util/HashMap:<init>	()V
    //   23: putfield 35	com/sun/activation/registries/MailcapFile:fallback_hash	Ljava/util/Map;
    //   26: aload_0
    //   27: new 30	java/util/HashMap
    //   30: dup
    //   31: invokespecial 31	java/util/HashMap:<init>	()V
    //   34: putfield 37	com/sun/activation/registries/MailcapFile:native_commands	Ljava/util/Map;
    //   37: invokestatic 43	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   40: ifeq +22 -> 62
    //   43: new 72	java/lang/StringBuilder
    //   46: dup
    //   47: ldc 74
    //   49: invokespecial 76	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   52: aload_1
    //   53: invokevirtual 80	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   56: invokevirtual 84	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   59: invokestatic 49	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;)V
    //   62: aconst_null
    //   63: astore_2
    //   64: new 86	java/io/FileReader
    //   67: dup
    //   68: aload_1
    //   69: invokespecial 87	java/io/FileReader:<init>	(Ljava/lang/String;)V
    //   72: astore_3
    //   73: aload_0
    //   74: new 56	java/io/BufferedReader
    //   77: dup
    //   78: aload_3
    //   79: invokespecial 66	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
    //   82: invokespecial 69	com/sun/activation/registries/MailcapFile:parse	(Ljava/io/Reader;)V
    //   85: aload_3
    //   86: ifnull +7 -> 93
    //   89: aload_3
    //   90: invokevirtual 90	java/io/FileReader:close	()V
    //   93: return
    //   94: astore_1
    //   95: aload_2
    //   96: ifnull +7 -> 103
    //   99: aload_2
    //   100: invokevirtual 90	java/io/FileReader:close	()V
    //   103: aload_1
    //   104: athrow
    //   105: astore_2
    //   106: goto -3 -> 103
    //   109: astore_1
    //   110: return
    //   111: astore_1
    //   112: aload_3
    //   113: astore_2
    //   114: goto -19 -> 95
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	117	0	this	MailcapFile
    //   0	117	1	paramString	String
    //   63	37	2	localObject1	Object
    //   105	1	2	localIOException	IOException
    //   113	1	2	localObject2	Object
    //   72	41	3	localFileReader	java.io.FileReader
    // Exception table:
    //   from	to	target	type
    //   64	73	94	finally
    //   99	103	105	java/io/IOException
    //   89	93	109	java/io/IOException
    //   73	85	111	finally
  }
  
  private Map mergeResults(Map paramMap1, Map paramMap2)
  {
    Iterator localIterator = paramMap2.keySet().iterator();
    paramMap1 = new HashMap(paramMap1);
    for (;;)
    {
      if (!localIterator.hasNext()) {
        return paramMap1;
      }
      String str = (String)localIterator.next();
      Object localObject = (List)paramMap1.get(str);
      if (localObject == null)
      {
        paramMap1.put(str, paramMap2.get(str));
      }
      else
      {
        List localList = (List)paramMap2.get(str);
        localObject = new ArrayList((Collection)localObject);
        ((List)localObject).addAll(localList);
        paramMap1.put(str, localObject);
      }
    }
  }
  
  private void parse(Reader paramReader)
    throws IOException
  {
    BufferedReader localBufferedReader = new BufferedReader(paramReader);
    paramReader = null;
    for (;;)
    {
      Object localObject = localBufferedReader.readLine();
      if (localObject == null) {
        return;
      }
      String str = ((String)localObject).trim();
      localObject = paramReader;
      try
      {
        if (str.charAt(0) == '#') {
          continue;
        }
        localObject = paramReader;
        if (str.charAt(str.length() - 1) == '\\')
        {
          if (paramReader != null)
          {
            localObject = paramReader;
            paramReader = paramReader + str.substring(0, str.length() - 1);
            continue;
          }
          localObject = paramReader;
          paramReader = str.substring(0, str.length() - 1);
          continue;
        }
        if (paramReader != null)
        {
          localObject = paramReader;
          paramReader = paramReader + str;
          localObject = paramReader;
        }
        try
        {
          parseLine(paramReader);
          paramReader = null;
          continue;
          localObject = paramReader;
          try
          {
            parseLine(str);
          }
          catch (MailcapParseException localMailcapParseException) {}
        }
        catch (MailcapParseException paramReader)
        {
          for (;;) {}
        }
      }
      catch (StringIndexOutOfBoundsException paramReader)
      {
        paramReader = localMailcapParseException;
      }
    }
  }
  
  protected static void reportParseError(int paramInt1, int paramInt2, int paramInt3, int paramInt4, String paramString)
    throws MailcapParseException
  {
    if (LogSupport.isLoggable()) {
      LogSupport.log("PARSE ERROR: Encountered a " + MailcapTokenizer.nameForToken(paramInt4) + " token (" + paramString + ") while expecting a " + MailcapTokenizer.nameForToken(paramInt1) + ", a " + MailcapTokenizer.nameForToken(paramInt2) + ", or a " + MailcapTokenizer.nameForToken(paramInt3) + " token.");
    }
    throw new MailcapParseException("Encountered a " + MailcapTokenizer.nameForToken(paramInt4) + " token (" + paramString + ") while expecting a " + MailcapTokenizer.nameForToken(paramInt1) + ", a " + MailcapTokenizer.nameForToken(paramInt2) + ", or a " + MailcapTokenizer.nameForToken(paramInt3) + " token.");
  }
  
  protected static void reportParseError(int paramInt1, int paramInt2, int paramInt3, String paramString)
    throws MailcapParseException
  {
    throw new MailcapParseException("Encountered a " + MailcapTokenizer.nameForToken(paramInt3) + " token (" + paramString + ") while expecting a " + MailcapTokenizer.nameForToken(paramInt1) + " or a " + MailcapTokenizer.nameForToken(paramInt2) + " token.");
  }
  
  protected static void reportParseError(int paramInt1, int paramInt2, String paramString)
    throws MailcapParseException
  {
    throw new MailcapParseException("Encountered a " + MailcapTokenizer.nameForToken(paramInt2) + " token (" + paramString + ") while expecting a " + MailcapTokenizer.nameForToken(paramInt1) + " token.");
  }
  
  public void appendToMailcap(String paramString)
  {
    if (LogSupport.isLoggable()) {
      LogSupport.log("appendToMailcap: " + paramString);
    }
    try
    {
      parse(new StringReader(paramString));
      return;
    }
    catch (IOException paramString) {}
  }
  
  public Map getMailcapFallbackList(String paramString)
  {
    Map localMap2 = (Map)this.fallback_hash.get(paramString);
    int i = paramString.indexOf('/');
    Map localMap1 = localMap2;
    if (!paramString.substring(i + 1).equals("*"))
    {
      paramString = paramString.substring(0, i + 1) + "*";
      paramString = (Map)this.fallback_hash.get(paramString);
      localMap1 = localMap2;
      if (paramString != null)
      {
        if (localMap2 == null) {
          return paramString;
        }
        localMap1 = mergeResults(localMap2, paramString);
      }
    }
    return localMap1;
    return paramString;
  }
  
  public Map getMailcapList(String paramString)
  {
    Map localMap2 = (Map)this.type_hash.get(paramString);
    int i = paramString.indexOf('/');
    Map localMap1 = localMap2;
    if (!paramString.substring(i + 1).equals("*"))
    {
      paramString = paramString.substring(0, i + 1) + "*";
      paramString = (Map)this.type_hash.get(paramString);
      localMap1 = localMap2;
      if (paramString != null)
      {
        if (localMap2 == null) {
          return paramString;
        }
        localMap1 = mergeResults(localMap2, paramString);
      }
    }
    return localMap1;
    return paramString;
  }
  
  public String[] getMimeTypes()
  {
    HashSet localHashSet = new HashSet(this.type_hash.keySet());
    localHashSet.addAll(this.fallback_hash.keySet());
    localHashSet.addAll(this.native_commands.keySet());
    return (String[])localHashSet.toArray(new String[localHashSet.size()]);
  }
  
  public String[] getNativeCommands(String paramString)
  {
    String[] arrayOfString = (String[])null;
    List localList = (List)this.native_commands.get(paramString.toLowerCase(Locale.ENGLISH));
    paramString = arrayOfString;
    if (localList != null) {
      paramString = (String[])localList.toArray(new String[localList.size()]);
    }
    return paramString;
  }
  
  protected void parseLine(String paramString)
    throws MailcapParseException, IOException
  {
    Object localObject3 = new MailcapTokenizer(paramString);
    ((MailcapTokenizer)localObject3).setIsAutoquoting(false);
    if (LogSupport.isLoggable()) {
      LogSupport.log("parse: " + paramString);
    }
    int i = ((MailcapTokenizer)localObject3).nextToken();
    if (i != 2) {
      reportParseError(2, i, ((MailcapTokenizer)localObject3).getCurrentTokenValue());
    }
    Object localObject2 = ((MailcapTokenizer)localObject3).getCurrentTokenValue().toLowerCase(Locale.ENGLISH);
    Object localObject1 = "*";
    int j = ((MailcapTokenizer)localObject3).nextToken();
    if ((j != 47) && (j != 59)) {
      reportParseError(47, 59, j, ((MailcapTokenizer)localObject3).getCurrentTokenValue());
    }
    i = j;
    if (j == 47)
    {
      i = ((MailcapTokenizer)localObject3).nextToken();
      if (i != 2) {
        reportParseError(2, i, ((MailcapTokenizer)localObject3).getCurrentTokenValue());
      }
      localObject1 = ((MailcapTokenizer)localObject3).getCurrentTokenValue().toLowerCase(Locale.ENGLISH);
      i = ((MailcapTokenizer)localObject3).nextToken();
    }
    Object localObject4 = localObject2 + "/" + (String)localObject1;
    if (LogSupport.isLoggable()) {
      LogSupport.log("  Type: " + (String)localObject4);
    }
    localObject2 = new LinkedHashMap();
    if (i != 59) {
      reportParseError(59, i, ((MailcapTokenizer)localObject3).getCurrentTokenValue());
    }
    ((MailcapTokenizer)localObject3).setIsAutoquoting(true);
    j = ((MailcapTokenizer)localObject3).nextToken();
    ((MailcapTokenizer)localObject3).setIsAutoquoting(false);
    if ((j != 2) && (j != 59)) {
      reportParseError(2, 59, j, ((MailcapTokenizer)localObject3).getCurrentTokenValue());
    }
    if (j == 2)
    {
      localObject1 = (List)this.native_commands.get(localObject4);
      if (localObject1 == null)
      {
        localObject1 = new ArrayList();
        ((List)localObject1).add(paramString);
        this.native_commands.put(localObject4, localObject1);
      }
    }
    else
    {
      i = j;
      if (j != 59) {
        i = ((MailcapTokenizer)localObject3).nextToken();
      }
      if (i != 59) {
        break label958;
      }
      i = 0;
      do
      {
        j = ((MailcapTokenizer)localObject3).nextToken();
        if (j != 2) {
          reportParseError(2, j, ((MailcapTokenizer)localObject3).getCurrentTokenValue());
        }
        paramString = ((MailcapTokenizer)localObject3).getCurrentTokenValue().toLowerCase(Locale.ENGLISH);
        m = ((MailcapTokenizer)localObject3).nextToken();
        if ((m != 61) && (m != 59) && (m != 5)) {
          reportParseError(61, 59, 5, m, ((MailcapTokenizer)localObject3).getCurrentTokenValue());
        }
        k = m;
        j = i;
        if (m == 61)
        {
          ((MailcapTokenizer)localObject3).setIsAutoquoting(true);
          j = ((MailcapTokenizer)localObject3).nextToken();
          ((MailcapTokenizer)localObject3).setIsAutoquoting(false);
          if (j != 2) {
            reportParseError(2, j, ((MailcapTokenizer)localObject3).getCurrentTokenValue());
          }
          str1 = ((MailcapTokenizer)localObject3).getCurrentTokenValue();
          j = i;
          if (paramString.startsWith("x-java-"))
          {
            str2 = paramString.substring(7);
            if ((!str2.equals("fallback-entry")) || (!str1.equalsIgnoreCase("true"))) {
              break;
            }
            j = 1;
          }
          k = ((MailcapTokenizer)localObject3).nextToken();
        }
        i = j;
      } while (k == 59);
      if (j == 0) {
        break label712;
      }
      paramString = this.fallback_hash;
      localObject1 = (Map)paramString.get(localObject4);
      if (localObject1 != null) {
        break label720;
      }
      paramString.put(localObject4, localObject2);
    }
    label712:
    label720:
    label958:
    while (i == 5)
    {
      String str1;
      for (;;)
      {
        int m;
        int k;
        String str2;
        return;
        ((List)localObject1).add(paramString);
        break;
        if (LogSupport.isLoggable()) {
          LogSupport.log("    Command: " + str2 + ", Class: " + str1);
        }
        localObject1 = (List)((Map)localObject2).get(str2);
        paramString = (String)localObject1;
        if (localObject1 == null)
        {
          paramString = new ArrayList();
          ((Map)localObject2).put(str2, paramString);
        }
        if (addReverse)
        {
          paramString.add(0, str1);
          j = i;
        }
        else
        {
          paramString.add(str1);
          j = i;
          continue;
          paramString = this.type_hash;
        }
      }
      if (LogSupport.isLoggable()) {
        LogSupport.log("Merging commands for type " + (String)localObject4);
      }
      paramString = ((Map)localObject1).keySet().iterator();
      for (;;)
      {
        if (!paramString.hasNext())
        {
          paramString = ((Map)localObject2).keySet().iterator();
          while (paramString.hasNext())
          {
            localObject3 = (String)paramString.next();
            if (!((Map)localObject1).containsKey(localObject3)) {
              ((Map)localObject1).put(localObject3, (List)((Map)localObject2).get(localObject3));
            }
          }
          break;
        }
        localObject4 = (String)paramString.next();
        localObject3 = (List)((Map)localObject1).get(localObject4);
        localObject4 = (List)((Map)localObject2).get(localObject4);
        if (localObject4 != null)
        {
          localObject4 = ((List)localObject4).iterator();
          while (((Iterator)localObject4).hasNext())
          {
            str1 = (String)((Iterator)localObject4).next();
            if (!((List)localObject3).contains(str1)) {
              if (addReverse) {
                ((List)localObject3).add(0, str1);
              } else {
                ((List)localObject3).add(str1);
              }
            }
          }
        }
      }
    }
    reportParseError(5, 59, i, ((MailcapTokenizer)localObject3).getCurrentTokenValue());
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/com/sun/activation/registries/MailcapFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */