package javax.activation;

public class MimeTypeParseException
  extends Exception
{
  public MimeTypeParseException() {}
  
  public MimeTypeParseException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/activation/MimeTypeParseException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */