package javax.activation;

import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import myjava.awt.datatransfer.DataFlavor;
import myjava.awt.datatransfer.UnsupportedFlavorException;

class ObjectDataContentHandler
  implements DataContentHandler
{
  private DataContentHandler dch = null;
  private String mimeType;
  private Object obj;
  private DataFlavor[] transferFlavors = null;
  
  public ObjectDataContentHandler(DataContentHandler paramDataContentHandler, Object paramObject, String paramString)
  {
    this.obj = paramObject;
    this.mimeType = paramString;
    this.dch = paramDataContentHandler;
  }
  
  public Object getContent(DataSource paramDataSource)
  {
    return this.obj;
  }
  
  public DataContentHandler getDCH()
  {
    return this.dch;
  }
  
  public Object getTransferData(DataFlavor paramDataFlavor, DataSource paramDataSource)
    throws UnsupportedFlavorException, IOException
  {
    if (this.dch != null) {
      return this.dch.getTransferData(paramDataFlavor, paramDataSource);
    }
    if (paramDataFlavor.equals(getTransferDataFlavors()[0])) {
      return this.obj;
    }
    throw new UnsupportedFlavorException(paramDataFlavor);
  }
  
  /* Error */
  public DataFlavor[] getTransferDataFlavors()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 21	javax/activation/ObjectDataContentHandler:transferFlavors	[Lmyjava/awt/datatransfer/DataFlavor;
    //   6: ifnonnull +23 -> 29
    //   9: aload_0
    //   10: getfield 23	javax/activation/ObjectDataContentHandler:dch	Ljavax/activation/DataContentHandler;
    //   13: ifnull +25 -> 38
    //   16: aload_0
    //   17: aload_0
    //   18: getfield 23	javax/activation/ObjectDataContentHandler:dch	Ljavax/activation/DataContentHandler;
    //   21: invokeinterface 55 1 0
    //   26: putfield 21	javax/activation/ObjectDataContentHandler:transferFlavors	[Lmyjava/awt/datatransfer/DataFlavor;
    //   29: aload_0
    //   30: getfield 21	javax/activation/ObjectDataContentHandler:transferFlavors	[Lmyjava/awt/datatransfer/DataFlavor;
    //   33: astore_1
    //   34: aload_0
    //   35: monitorexit
    //   36: aload_1
    //   37: areturn
    //   38: aload_0
    //   39: iconst_1
    //   40: anewarray 46	myjava/awt/datatransfer/DataFlavor
    //   43: putfield 21	javax/activation/ObjectDataContentHandler:transferFlavors	[Lmyjava/awt/datatransfer/DataFlavor;
    //   46: aload_0
    //   47: getfield 21	javax/activation/ObjectDataContentHandler:transferFlavors	[Lmyjava/awt/datatransfer/DataFlavor;
    //   50: iconst_0
    //   51: new 57	javax/activation/ActivationDataFlavor
    //   54: dup
    //   55: aload_0
    //   56: getfield 25	javax/activation/ObjectDataContentHandler:obj	Ljava/lang/Object;
    //   59: invokevirtual 61	java/lang/Object:getClass	()Ljava/lang/Class;
    //   62: aload_0
    //   63: getfield 27	javax/activation/ObjectDataContentHandler:mimeType	Ljava/lang/String;
    //   66: aload_0
    //   67: getfield 27	javax/activation/ObjectDataContentHandler:mimeType	Ljava/lang/String;
    //   70: invokespecial 64	javax/activation/ActivationDataFlavor:<init>	(Ljava/lang/Class;Ljava/lang/String;Ljava/lang/String;)V
    //   73: aastore
    //   74: goto -45 -> 29
    //   77: astore_1
    //   78: aload_0
    //   79: monitorexit
    //   80: aload_1
    //   81: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	82	0	this	ObjectDataContentHandler
    //   33	4	1	arrayOfDataFlavor	DataFlavor[]
    //   77	4	1	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   2	29	77	finally
    //   29	34	77	finally
    //   38	74	77	finally
  }
  
  public void writeTo(Object paramObject, String paramString, OutputStream paramOutputStream)
    throws IOException
  {
    if (this.dch != null)
    {
      this.dch.writeTo(paramObject, paramString, paramOutputStream);
      return;
    }
    if ((paramObject instanceof byte[]))
    {
      paramOutputStream.write((byte[])paramObject);
      return;
    }
    if ((paramObject instanceof String))
    {
      paramString = new OutputStreamWriter(paramOutputStream);
      paramString.write((String)paramObject);
      paramString.flush();
      return;
    }
    throw new UnsupportedDataTypeException("no object DCH for MIME type " + this.mimeType);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/activation/ObjectDataContentHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */