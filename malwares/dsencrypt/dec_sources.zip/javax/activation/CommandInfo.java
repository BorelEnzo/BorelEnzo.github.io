package javax.activation;

import java.beans.Beans;
import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInputStream;

public class CommandInfo
{
  private String className;
  private String verb;
  
  public CommandInfo(String paramString1, String paramString2)
  {
    this.verb = paramString1;
    this.className = paramString2;
  }
  
  public String getCommandClass()
  {
    return this.className;
  }
  
  public String getCommandName()
  {
    return this.verb;
  }
  
  public Object getCommandObject(DataHandler paramDataHandler, ClassLoader paramClassLoader)
    throws IOException, ClassNotFoundException
  {
    paramClassLoader = Beans.instantiate(paramClassLoader, this.className);
    if (paramClassLoader != null)
    {
      if (!(paramClassLoader instanceof CommandObject)) {
        break label36;
      }
      ((CommandObject)paramClassLoader).setCommandContext(this.verb, paramDataHandler);
    }
    label36:
    do
    {
      do
      {
        return paramClassLoader;
      } while ((!(paramClassLoader instanceof Externalizable)) || (paramDataHandler == null));
      paramDataHandler = paramDataHandler.getInputStream();
    } while (paramDataHandler == null);
    ((Externalizable)paramClassLoader).readExternal(new ObjectInputStream(paramDataHandler));
    return paramClassLoader;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/activation/CommandInfo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */