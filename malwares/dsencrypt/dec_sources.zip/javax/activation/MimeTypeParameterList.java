package javax.activation;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Locale;

public class MimeTypeParameterList
{
  private static final String TSPECIALS = "()<>@,;:/[]?=\\\"";
  private Hashtable parameters = new Hashtable();
  
  public MimeTypeParameterList() {}
  
  public MimeTypeParameterList(String paramString)
    throws MimeTypeParseException
  {
    parse(paramString);
  }
  
  private static boolean isTokenChar(char paramChar)
  {
    return (paramChar > ' ') && (paramChar < '') && ("()<>@,;:/[]?=\\\"".indexOf(paramChar) < 0);
  }
  
  private static String quote(String paramString)
  {
    int i = 0;
    int k = paramString.length();
    int j = 0;
    Object localObject;
    if ((j >= k) || (i != 0))
    {
      localObject = paramString;
      if (i != 0)
      {
        localObject = new StringBuffer();
        ((StringBuffer)localObject).ensureCapacity((int)(k * 1.5D));
        ((StringBuffer)localObject).append('"');
        i = 0;
      }
    }
    for (;;)
    {
      if (i >= k)
      {
        ((StringBuffer)localObject).append('"');
        localObject = ((StringBuffer)localObject).toString();
        return (String)localObject;
        if (isTokenChar(paramString.charAt(j))) {}
        for (i = 0;; i = 1)
        {
          j += 1;
          break;
        }
      }
      char c = paramString.charAt(i);
      if ((c == '\\') || (c == '"')) {
        ((StringBuffer)localObject).append('\\');
      }
      ((StringBuffer)localObject).append(c);
      i += 1;
    }
  }
  
  private static int skipWhiteSpace(String paramString, int paramInt)
  {
    int i = paramString.length();
    for (;;)
    {
      if ((paramInt >= i) || (!Character.isWhitespace(paramString.charAt(paramInt)))) {
        return paramInt;
      }
      paramInt += 1;
    }
  }
  
  private static String unquote(String paramString)
  {
    int k = paramString.length();
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.ensureCapacity(k);
    int i = 0;
    int j = 0;
    if (j >= k) {
      return localStringBuffer.toString();
    }
    char c = paramString.charAt(j);
    if ((i == 0) && (c != '\\')) {
      localStringBuffer.append(c);
    }
    for (;;)
    {
      j += 1;
      break;
      if (i != 0)
      {
        localStringBuffer.append(c);
        i = 0;
      }
      else
      {
        i = 1;
      }
    }
  }
  
  public String get(String paramString)
  {
    return (String)this.parameters.get(paramString.trim().toLowerCase(Locale.ENGLISH));
  }
  
  public Enumeration getNames()
  {
    return this.parameters.keys();
  }
  
  public boolean isEmpty()
  {
    return this.parameters.isEmpty();
  }
  
  protected void parse(String paramString)
    throws MimeTypeParseException
  {
    if (paramString == null) {}
    int n;
    do
    {
      return;
      n = paramString.length();
    } while (n <= 0);
    int j;
    char c1;
    String str1;
    for (int i = skipWhiteSpace(paramString, 0);; i = skipWhiteSpace(paramString, i))
    {
      if ((i >= n) || (paramString.charAt(i) != ';'))
      {
        if (i >= n) {
          break;
        }
        throw new MimeTypeParseException("More characters encountered in input than expected.");
      }
      j = skipWhiteSpace(paramString, i + 1);
      if (j >= n) {
        break;
      }
      i = j;
      String str2;
      for (;;)
      {
        if ((i >= n) || (!isTokenChar(paramString.charAt(i))))
        {
          str2 = paramString.substring(j, i).toLowerCase(Locale.ENGLISH);
          i = skipWhiteSpace(paramString, i);
          if ((i < n) && (paramString.charAt(i) == '=')) {
            break;
          }
          throw new MimeTypeParseException("Couldn't find the '=' that separates a parameter name from its value.");
        }
        i += 1;
      }
      j = skipWhiteSpace(paramString, i + 1);
      if (j >= n) {
        throw new MimeTypeParseException("Couldn't find a value for parameter named " + str2);
      }
      c1 = paramString.charAt(j);
      if (c1 != '"') {
        break label340;
      }
      int m = j + 1;
      if (m >= n) {
        throw new MimeTypeParseException("Encountered unterminated quoted parameter value.");
      }
      i = m;
      char c2 = c1;
      for (;;)
      {
        j = i;
        if (j >= n) {}
        do
        {
          if (c2 == '"') {
            break;
          }
          throw new MimeTypeParseException("Encountered unterminated quoted parameter value.");
          i = paramString.charAt(j);
          c2 = i;
        } while (i == 34);
        c2 = j;
        if (i == 92) {
          k = j + 1;
        }
        j = k + 1;
        int k = i;
        i = j;
      }
      str1 = unquote(paramString.substring(m, j));
      i = j + 1;
      this.parameters.put(str2, str1);
    }
    label340:
    if (isTokenChar(c1))
    {
      i = j;
      for (;;)
      {
        if ((i >= n) || (!isTokenChar(paramString.charAt(i))))
        {
          str1 = paramString.substring(j, i);
          break;
        }
        i += 1;
      }
    }
    throw new MimeTypeParseException("Unexpected character encountered at index " + j);
  }
  
  public void remove(String paramString)
  {
    this.parameters.remove(paramString.trim().toLowerCase(Locale.ENGLISH));
  }
  
  public void set(String paramString1, String paramString2)
  {
    this.parameters.put(paramString1.trim().toLowerCase(Locale.ENGLISH), paramString2);
  }
  
  public int size()
  {
    return this.parameters.size();
  }
  
  public String toString()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.ensureCapacity(this.parameters.size() * 16);
    Enumeration localEnumeration = this.parameters.keys();
    for (;;)
    {
      if (!localEnumeration.hasMoreElements()) {
        return localStringBuffer.toString();
      }
      String str = (String)localEnumeration.nextElement();
      localStringBuffer.append("; ");
      localStringBuffer.append(str);
      localStringBuffer.append('=');
      localStringBuffer.append(quote((String)this.parameters.get(str)));
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/activation/MimeTypeParameterList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */