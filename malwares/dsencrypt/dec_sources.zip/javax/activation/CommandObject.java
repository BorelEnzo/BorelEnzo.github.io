package javax.activation;

import java.io.IOException;

public abstract interface CommandObject
{
  public abstract void setCommandContext(String paramString, DataHandler paramDataHandler)
    throws IOException;
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/activation/CommandObject.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */