package javax.activation;

public abstract interface DataContentHandlerFactory
{
  public abstract DataContentHandler createDataContentHandler(String paramString);
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/activation/DataContentHandlerFactory.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */