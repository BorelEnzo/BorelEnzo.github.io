package javax.activation;

import com.sun.activation.registries.LogSupport;
import com.sun.activation.registries.MailcapFile;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class MailcapCommandMap
  extends CommandMap
{
  private static final int PROG = 0;
  private static MailcapFile defDB = null;
  private MailcapFile[] DB;
  
  public MailcapCommandMap()
  {
    ArrayList localArrayList = new ArrayList(5);
    localArrayList.add(null);
    LogSupport.log("MailcapCommandMap: load HOME");
    try
    {
      localObject2 = System.getProperty("user.home");
      if (localObject2 != null)
      {
        localObject2 = loadFile(localObject2 + File.separator + ".mailcap");
        if (localObject2 != null) {
          localArrayList.add(localObject2);
        }
      }
    }
    catch (SecurityException localSecurityException2)
    {
      Object localObject2;
      for (;;) {}
    }
    LogSupport.log("MailcapCommandMap: load SYS");
    try
    {
      localObject2 = loadFile(System.getProperty("java.home") + File.separator + "lib" + File.separator + "mailcap");
      if (localObject2 != null) {
        localArrayList.add(localObject2);
      }
    }
    catch (SecurityException localSecurityException1)
    {
      for (;;) {}
    }
    LogSupport.log("MailcapCommandMap: load JAR");
    loadAllResources(localArrayList, "mailcap");
    LogSupport.log("MailcapCommandMap: load DEF");
    try
    {
      if (defDB == null) {
        defDB = loadResource("mailcap.default");
      }
      if (defDB != null) {
        localArrayList.add(defDB);
      }
      this.DB = new MailcapFile[localArrayList.size()];
      this.DB = ((MailcapFile[])localArrayList.toArray(this.DB));
      return;
    }
    finally {}
  }
  
  public MailcapCommandMap(InputStream paramInputStream)
  {
    this();
    LogSupport.log("MailcapCommandMap: load PROG");
    if (this.DB[0] == null) {}
    try
    {
      this.DB[0] = new MailcapFile(paramInputStream);
      return;
    }
    catch (IOException paramInputStream) {}
  }
  
  public MailcapCommandMap(String paramString)
    throws IOException
  {
    this();
    if (LogSupport.isLoggable()) {
      LogSupport.log("MailcapCommandMap: load PROG from " + paramString);
    }
    if (this.DB[0] == null) {
      this.DB[0] = new MailcapFile(paramString);
    }
  }
  
  private void appendCmdsToList(Map paramMap, List paramList)
  {
    Iterator localIterator1 = paramMap.keySet().iterator();
    for (;;)
    {
      if (!localIterator1.hasNext()) {
        return;
      }
      String str = (String)localIterator1.next();
      Iterator localIterator2 = ((List)paramMap.get(str)).iterator();
      while (localIterator2.hasNext()) {
        paramList.add(new CommandInfo(str, (String)localIterator2.next()));
      }
    }
  }
  
  private void appendPrefCmdsToList(Map paramMap, List paramList)
  {
    Iterator localIterator = paramMap.keySet().iterator();
    for (;;)
    {
      if (!localIterator.hasNext()) {
        return;
      }
      String str = (String)localIterator.next();
      if (!checkForVerb(paramList, str)) {
        paramList.add(new CommandInfo(str, (String)((List)paramMap.get(str)).get(0)));
      }
    }
  }
  
  private boolean checkForVerb(List paramList, String paramString)
  {
    paramList = paramList.iterator();
    do
    {
      if (!paramList.hasNext()) {
        return false;
      }
    } while (!((CommandInfo)paramList.next()).getCommandName().equals(paramString));
    return true;
  }
  
  /* Error */
  private DataContentHandler getDataContentHandler(String paramString)
  {
    // Byte code:
    //   0: invokestatic 124	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   3: ifeq +8 -> 11
    //   6: ldc -69
    //   8: invokestatic 40	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;)V
    //   11: invokestatic 124	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   14: ifeq +22 -> 36
    //   17: new 50	java/lang/StringBuilder
    //   20: dup
    //   21: ldc -67
    //   23: invokespecial 58	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   26: aload_1
    //   27: invokevirtual 68	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   30: invokevirtual 74	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   33: invokestatic 40	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;)V
    //   36: invokestatic 195	javax/activation/SecuritySupport:getContextClassLoader	()Ljava/lang/ClassLoader;
    //   39: astore_3
    //   40: aload_3
    //   41: astore_2
    //   42: aload_3
    //   43: ifnonnull +11 -> 54
    //   46: aload_0
    //   47: invokevirtual 201	java/lang/Object:getClass	()Ljava/lang/Class;
    //   50: invokevirtual 206	java/lang/Class:getClassLoader	()Ljava/lang/ClassLoader;
    //   53: astore_2
    //   54: aload_2
    //   55: aload_1
    //   56: invokevirtual 212	java/lang/ClassLoader:loadClass	(Ljava/lang/String;)Ljava/lang/Class;
    //   59: astore_2
    //   60: aload_2
    //   61: ifnull +47 -> 108
    //   64: aload_2
    //   65: invokevirtual 215	java/lang/Class:newInstance	()Ljava/lang/Object;
    //   68: checkcast 217	javax/activation/DataContentHandler
    //   71: areturn
    //   72: astore_2
    //   73: aload_1
    //   74: invokestatic 220	java/lang/Class:forName	(Ljava/lang/String;)Ljava/lang/Class;
    //   77: astore_2
    //   78: goto -18 -> 60
    //   81: astore_2
    //   82: invokestatic 124	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   85: ifeq +23 -> 108
    //   88: new 50	java/lang/StringBuilder
    //   91: dup
    //   92: ldc -34
    //   94: invokespecial 58	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   97: aload_1
    //   98: invokevirtual 68	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   101: invokevirtual 74	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   104: aload_2
    //   105: invokestatic 225	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   108: aconst_null
    //   109: areturn
    //   110: astore_2
    //   111: invokestatic 124	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   114: ifeq -6 -> 108
    //   117: new 50	java/lang/StringBuilder
    //   120: dup
    //   121: ldc -34
    //   123: invokespecial 58	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   126: aload_1
    //   127: invokevirtual 68	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   130: invokevirtual 74	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   133: aload_2
    //   134: invokestatic 225	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   137: goto -29 -> 108
    //   140: astore_2
    //   141: invokestatic 124	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   144: ifeq -36 -> 108
    //   147: new 50	java/lang/StringBuilder
    //   150: dup
    //   151: ldc -34
    //   153: invokespecial 58	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   156: aload_1
    //   157: invokevirtual 68	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   160: invokevirtual 74	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   163: aload_2
    //   164: invokestatic 225	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   167: goto -59 -> 108
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	170	0	this	MailcapCommandMap
    //   0	170	1	paramString	String
    //   41	24	2	localObject	Object
    //   72	1	2	localException	Exception
    //   77	1	2	localClass	Class
    //   81	24	2	localIllegalAccessException	IllegalAccessException
    //   110	24	2	localClassNotFoundException	ClassNotFoundException
    //   140	24	2	localInstantiationException	InstantiationException
    //   39	4	3	localClassLoader	ClassLoader
    // Exception table:
    //   from	to	target	type
    //   54	60	72	java/lang/Exception
    //   36	40	81	java/lang/IllegalAccessException
    //   46	54	81	java/lang/IllegalAccessException
    //   54	60	81	java/lang/IllegalAccessException
    //   64	72	81	java/lang/IllegalAccessException
    //   73	78	81	java/lang/IllegalAccessException
    //   36	40	110	java/lang/ClassNotFoundException
    //   46	54	110	java/lang/ClassNotFoundException
    //   54	60	110	java/lang/ClassNotFoundException
    //   64	72	110	java/lang/ClassNotFoundException
    //   73	78	110	java/lang/ClassNotFoundException
    //   36	40	140	java/lang/InstantiationException
    //   46	54	140	java/lang/InstantiationException
    //   54	60	140	java/lang/InstantiationException
    //   64	72	140	java/lang/InstantiationException
    //   73	78	140	java/lang/InstantiationException
  }
  
  private void loadAllResources(List paramList, String paramString)
  {
    i = 0;
    m = 0;
    k = 0;
    j = m;
    for (;;)
    {
      try
      {
        localObject3 = SecuritySupport.getContextClassLoader();
        localObject1 = localObject3;
        if (localObject3 == null)
        {
          j = m;
          localObject1 = getClass().getClassLoader();
        }
        if (localObject1 == null) {
          continue;
        }
        j = m;
        arrayOfURL = SecuritySupport.getResources((ClassLoader)localObject1, paramString);
        if (arrayOfURL == null) {
          continue;
        }
        j = m;
        if (!LogSupport.isLoggable()) {
          continue;
        }
        j = m;
        LogSupport.log("MailcapCommandMap: getResources");
      }
      catch (Exception localException)
      {
        int i1;
        try
        {
          Object localObject3;
          Object localObject1;
          URL[] arrayOfURL;
          URL localURL;
          Object localObject5;
          int n;
          localIOException2.close();
          j = n;
          throw ((Throwable)localObject4);
          localException = localException;
          i = j;
          if (!LogSupport.isLoggable()) {
            continue;
          }
          LogSupport.log("MailcapCommandMap: can't load " + paramString, localException);
          i = j;
        }
        catch (IOException localIOException3)
        {
          continue;
        }
        int i2 = 0;
        i = k;
        continue;
      }
      j = i;
      k = arrayOfURL.length;
      if (i2 < k) {
        continue;
      }
      if (i == 0)
      {
        if (LogSupport.isLoggable()) {
          LogSupport.log("MailcapCommandMap: !anyLoaded");
        }
        paramString = loadResource("/" + paramString);
        if (paramString != null) {
          paramList.add(paramString);
        }
      }
      return;
      j = m;
      arrayOfURL = SecuritySupport.getSystemResources(paramString);
    }
    localURL = arrayOfURL[i2];
    localObject5 = null;
    localObject1 = null;
    localObject3 = null;
    j = i;
    if (LogSupport.isLoggable())
    {
      j = i;
      LogSupport.log("MailcapCommandMap: URL " + localURL);
    }
    k = i;
    m = i;
    n = i;
    for (;;)
    {
      try
      {
        localInputStream = SecuritySupport.openStream(localURL);
        if (localInputStream != null)
        {
          k = i;
          localObject3 = localInputStream;
          m = i;
          localObject5 = localInputStream;
          n = i;
          localObject1 = localInputStream;
          paramList.add(new MailcapFile(localInputStream));
          j = 1;
          int i3 = 1;
          int i4 = 1;
          i = 1;
          i1 = i;
          k = j;
          localObject3 = localInputStream;
          m = i3;
          localObject5 = localInputStream;
          n = i4;
          localObject1 = localInputStream;
          if (LogSupport.isLoggable())
          {
            k = j;
            localObject3 = localInputStream;
            m = i3;
            localObject5 = localInputStream;
            n = i4;
            localObject1 = localInputStream;
            LogSupport.log("MailcapCommandMap: successfully loaded mailcap file from URL: " + localURL);
            i1 = i;
          }
          i = i1;
        }
      }
      catch (IOException localIOException5)
      {
        InputStream localInputStream;
        n = k;
        localObject1 = localObject3;
        if (LogSupport.isLoggable())
        {
          n = k;
          localObject1 = localObject3;
          LogSupport.log("MailcapCommandMap: can't load " + localURL, localIOException5);
        }
        i = k;
        if (localObject3 == null) {
          continue;
        }
        j = k;
        try
        {
          ((InputStream)localObject3).close();
          i = k;
        }
        catch (IOException localIOException1)
        {
          i = k;
        }
        continue;
      }
      catch (SecurityException localSecurityException)
      {
        n = m;
        Object localObject2 = localIOException5;
        if (LogSupport.isLoggable())
        {
          n = m;
          localObject2 = localIOException5;
          LogSupport.log("MailcapCommandMap: can't load " + localURL, localSecurityException);
        }
        i = m;
        if (localIOException5 == null) {
          continue;
        }
        j = m;
        try
        {
          localIOException5.close();
          i = m;
        }
        catch (IOException localIOException2)
        {
          i = m;
        }
        continue;
      }
      finally
      {
        if (localIOException2 != null) {
          j = n;
        }
      }
      try
      {
        localInputStream.close();
        i = i1;
      }
      catch (IOException localIOException4)
      {
        i = i1;
        continue;
      }
      i2 += 1;
      break;
      i1 = i;
      k = i;
      localObject3 = localInputStream;
      m = i;
      localObject5 = localInputStream;
      n = i;
      localObject1 = localInputStream;
      if (LogSupport.isLoggable())
      {
        k = i;
        localObject3 = localInputStream;
        m = i;
        localObject5 = localInputStream;
        n = i;
        localObject1 = localInputStream;
        LogSupport.log("MailcapCommandMap: not loading mailcap file from URL: " + localURL);
        i1 = i;
      }
    }
  }
  
  private MailcapFile loadFile(String paramString)
  {
    try
    {
      paramString = new MailcapFile(paramString);
      return paramString;
    }
    catch (IOException paramString) {}
    return null;
  }
  
  /* Error */
  private MailcapFile loadResource(String paramString)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 4
    //   3: aconst_null
    //   4: astore_2
    //   5: aconst_null
    //   6: astore_3
    //   7: aload_0
    //   8: invokevirtual 201	java/lang/Object:getClass	()Ljava/lang/Class;
    //   11: aload_1
    //   12: invokestatic 263	javax/activation/SecuritySupport:getResourceAsStream	(Ljava/lang/Class;Ljava/lang/String;)Ljava/io/InputStream;
    //   15: astore 5
    //   17: aload 5
    //   19: ifnull +83 -> 102
    //   22: aload 5
    //   24: astore_3
    //   25: aload 5
    //   27: astore 4
    //   29: aload 5
    //   31: astore_2
    //   32: new 105	com/sun/activation/registries/MailcapFile
    //   35: dup
    //   36: aload 5
    //   38: invokespecial 120	com/sun/activation/registries/MailcapFile:<init>	(Ljava/io/InputStream;)V
    //   41: astore 6
    //   43: aload 5
    //   45: astore_3
    //   46: aload 5
    //   48: astore 4
    //   50: aload 5
    //   52: astore_2
    //   53: invokestatic 124	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   56: ifeq +33 -> 89
    //   59: aload 5
    //   61: astore_3
    //   62: aload 5
    //   64: astore 4
    //   66: aload 5
    //   68: astore_2
    //   69: new 50	java/lang/StringBuilder
    //   72: dup
    //   73: ldc_w 265
    //   76: invokespecial 58	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   79: aload_1
    //   80: invokevirtual 68	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   83: invokevirtual 74	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   86: invokestatic 40	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;)V
    //   89: aload 5
    //   91: ifnull +8 -> 99
    //   94: aload 5
    //   96: invokevirtual 255	java/io/InputStream:close	()V
    //   99: aload 6
    //   101: areturn
    //   102: aload 5
    //   104: astore_3
    //   105: aload 5
    //   107: astore 4
    //   109: aload 5
    //   111: astore_2
    //   112: invokestatic 124	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   115: ifeq +33 -> 148
    //   118: aload 5
    //   120: astore_3
    //   121: aload 5
    //   123: astore 4
    //   125: aload 5
    //   127: astore_2
    //   128: new 50	java/lang/StringBuilder
    //   131: dup
    //   132: ldc_w 267
    //   135: invokespecial 58	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   138: aload_1
    //   139: invokevirtual 68	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   142: invokevirtual 74	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   145: invokestatic 40	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;)V
    //   148: aload 5
    //   150: ifnull +8 -> 158
    //   153: aload 5
    //   155: invokevirtual 255	java/io/InputStream:close	()V
    //   158: aconst_null
    //   159: areturn
    //   160: astore 4
    //   162: aload_3
    //   163: astore_2
    //   164: invokestatic 124	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   167: ifeq +27 -> 194
    //   170: aload_3
    //   171: astore_2
    //   172: new 50	java/lang/StringBuilder
    //   175: dup
    //   176: ldc_w 259
    //   179: invokespecial 58	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   182: aload_1
    //   183: invokevirtual 68	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   186: invokevirtual 74	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   189: aload 4
    //   191: invokestatic 225	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   194: aload_3
    //   195: ifnull -37 -> 158
    //   198: aload_3
    //   199: invokevirtual 255	java/io/InputStream:close	()V
    //   202: goto -44 -> 158
    //   205: astore_1
    //   206: goto -48 -> 158
    //   209: astore_3
    //   210: aload 4
    //   212: astore_2
    //   213: invokestatic 124	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   216: ifeq +27 -> 243
    //   219: aload 4
    //   221: astore_2
    //   222: new 50	java/lang/StringBuilder
    //   225: dup
    //   226: ldc_w 259
    //   229: invokespecial 58	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   232: aload_1
    //   233: invokevirtual 68	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   236: invokevirtual 74	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   239: aload_3
    //   240: invokestatic 225	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   243: aload 4
    //   245: ifnull -87 -> 158
    //   248: aload 4
    //   250: invokevirtual 255	java/io/InputStream:close	()V
    //   253: goto -95 -> 158
    //   256: astore_1
    //   257: goto -99 -> 158
    //   260: astore_1
    //   261: aload_2
    //   262: ifnull +7 -> 269
    //   265: aload_2
    //   266: invokevirtual 255	java/io/InputStream:close	()V
    //   269: aload_1
    //   270: athrow
    //   271: astore_1
    //   272: aload 6
    //   274: areturn
    //   275: astore_2
    //   276: goto -7 -> 269
    //   279: astore_1
    //   280: goto -122 -> 158
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	283	0	this	MailcapCommandMap
    //   0	283	1	paramString	String
    //   4	262	2	localObject1	Object
    //   275	1	2	localIOException1	IOException
    //   6	193	3	localObject2	Object
    //   209	31	3	localSecurityException	SecurityException
    //   1	123	4	localObject3	Object
    //   160	89	4	localIOException2	IOException
    //   15	139	5	localInputStream	InputStream
    //   41	232	6	localMailcapFile	MailcapFile
    // Exception table:
    //   from	to	target	type
    //   7	17	160	java/io/IOException
    //   32	43	160	java/io/IOException
    //   53	59	160	java/io/IOException
    //   69	89	160	java/io/IOException
    //   112	118	160	java/io/IOException
    //   128	148	160	java/io/IOException
    //   198	202	205	java/io/IOException
    //   7	17	209	java/lang/SecurityException
    //   32	43	209	java/lang/SecurityException
    //   53	59	209	java/lang/SecurityException
    //   69	89	209	java/lang/SecurityException
    //   112	118	209	java/lang/SecurityException
    //   128	148	209	java/lang/SecurityException
    //   248	253	256	java/io/IOException
    //   7	17	260	finally
    //   32	43	260	finally
    //   53	59	260	finally
    //   69	89	260	finally
    //   112	118	260	finally
    //   128	148	260	finally
    //   164	170	260	finally
    //   172	194	260	finally
    //   213	219	260	finally
    //   222	243	260	finally
    //   94	99	271	java/io/IOException
    //   265	269	275	java/io/IOException
    //   153	158	279	java/io/IOException
  }
  
  public void addMailcap(String paramString)
  {
    try
    {
      LogSupport.log("MailcapCommandMap: add to PROG");
      if (this.DB[0] == null) {
        this.DB[0] = new MailcapFile();
      }
      this.DB[0].appendToMailcap(paramString);
      return;
    }
    finally {}
  }
  
  public DataContentHandler createDataContentHandler(String paramString)
  {
    String str;
    int i;
    try
    {
      if (LogSupport.isLoggable()) {
        LogSupport.log("MailcapCommandMap: createDataContentHandler for " + paramString);
      }
      str = paramString;
      if (paramString == null) {
        break label266;
      }
      str = paramString.toLowerCase(Locale.ENGLISH);
    }
    finally {}
    if (i >= this.DB.length) {
      i = 0;
    }
    for (;;)
    {
      int j = this.DB.length;
      if (i >= j) {
        paramString = null;
      }
      for (;;)
      {
        return paramString;
        if (this.DB[i] == null) {
          break;
        }
        if (LogSupport.isLoggable()) {
          LogSupport.log("  search DB #" + i);
        }
        paramString = this.DB[i].getMailcapList(str);
        if (paramString == null) {
          break;
        }
        paramString = (List)paramString.get("content-handler");
        if (paramString == null) {
          break;
        }
        paramString = getDataContentHandler((String)paramString.get(0));
        if (paramString == null) {
          break;
        }
        continue;
        if (this.DB[i] == null) {
          break label278;
        }
        if (LogSupport.isLoggable()) {
          LogSupport.log("  search fallback DB #" + i);
        }
        paramString = this.DB[i].getMailcapFallbackList(str);
        if (paramString == null) {
          break label278;
        }
        paramString = (List)paramString.get("content-handler");
        if (paramString == null) {
          break label278;
        }
        paramString = getDataContentHandler((String)paramString.get(0));
        if (paramString == null) {
          break label278;
        }
      }
      label266:
      i = 0;
      break;
      i += 1;
      break;
      label278:
      i += 1;
    }
  }
  
  public CommandInfo[] getAllCommands(String paramString)
  {
    ArrayList localArrayList;
    String str;
    int i;
    try
    {
      localArrayList = new ArrayList();
      str = paramString;
      if (paramString == null) {
        break label152;
      }
      str = paramString.toLowerCase(Locale.ENGLISH);
    }
    finally {}
    if (i >= this.DB.length) {
      i = 0;
    }
    for (;;)
    {
      if (i >= this.DB.length)
      {
        paramString = (CommandInfo[])localArrayList.toArray(new CommandInfo[localArrayList.size()]);
        return paramString;
        if (this.DB[i] != null)
        {
          paramString = this.DB[i].getMailcapList(str);
          if (paramString != null) {
            appendCmdsToList(paramString, localArrayList);
          }
        }
      }
      else
      {
        if (this.DB[i] == null) {
          break label164;
        }
        paramString = this.DB[i].getMailcapFallbackList(str);
        if (paramString == null) {
          break label164;
        }
        appendCmdsToList(paramString, localArrayList);
        break label164;
        label152:
        i = 0;
        break;
      }
      i += 1;
      break;
      label164:
      i += 1;
    }
  }
  
  public CommandInfo getCommand(String paramString1, String paramString2)
  {
    String str = paramString1;
    int i;
    if (paramString1 != null)
    {
      try
      {
        str = paramString1.toLowerCase(Locale.ENGLISH);
      }
      finally {}
      if (i >= this.DB.length) {
        i = 0;
      }
    }
    for (;;)
    {
      int j = this.DB.length;
      if (i >= j) {
        paramString1 = null;
      }
      for (;;)
      {
        return paramString1;
        if (this.DB[i] == null) {
          break;
        }
        paramString1 = this.DB[i].getMailcapList(str);
        if (paramString1 == null) {
          break;
        }
        paramString1 = (List)paramString1.get(paramString2);
        if (paramString1 == null) {
          break;
        }
        paramString1 = (String)paramString1.get(0);
        if (paramString1 == null) {
          break;
        }
        paramString1 = new CommandInfo(paramString2, paramString1);
        continue;
        if (this.DB[i] == null) {
          break label210;
        }
        paramString1 = this.DB[i].getMailcapFallbackList(str);
        if (paramString1 == null) {
          break label210;
        }
        paramString1 = (List)paramString1.get(paramString2);
        if (paramString1 == null) {
          break label210;
        }
        paramString1 = (String)paramString1.get(0);
        if (paramString1 == null) {
          break label210;
        }
        paramString1 = new CommandInfo(paramString2, paramString1);
      }
      i = 0;
      break;
      i += 1;
      break;
      label210:
      i += 1;
    }
  }
  
  public String[] getMimeTypes()
  {
    for (;;)
    {
      try
      {
        Object localObject1 = new ArrayList();
        int i = 0;
        if (i >= this.DB.length)
        {
          localObject1 = (String[])((List)localObject1).toArray(new String[((List)localObject1).size()]);
          return (String[])localObject1;
        }
        if (this.DB[i] != null)
        {
          String[] arrayOfString = this.DB[i].getMimeTypes();
          if (arrayOfString != null)
          {
            int j = 0;
            if (j < arrayOfString.length)
            {
              if (!((List)localObject1).contains(arrayOfString[j])) {
                ((List)localObject1).add(arrayOfString[j]);
              }
              j += 1;
              continue;
            }
          }
        }
        i += 1;
      }
      finally {}
    }
  }
  
  public String[] getNativeCommands(String paramString)
  {
    for (;;)
    {
      ArrayList localArrayList;
      String str;
      int i;
      try
      {
        localArrayList = new ArrayList();
        str = paramString;
        if (paramString == null) {
          break label136;
        }
        str = paramString.toLowerCase(Locale.ENGLISH);
      }
      finally {}
      if (i >= this.DB.length)
      {
        paramString = (String[])localArrayList.toArray(new String[localArrayList.size()]);
        return paramString;
      }
      if (this.DB[i] != null)
      {
        paramString = this.DB[i].getNativeCommands(str);
        if (paramString != null)
        {
          int j = 0;
          if (j < paramString.length)
          {
            if (!localArrayList.contains(paramString[j])) {
              localArrayList.add(paramString[j]);
            }
            j += 1;
            continue;
            label136:
            i = 0;
            continue;
          }
        }
      }
      i += 1;
    }
  }
  
  public CommandInfo[] getPreferredCommands(String paramString)
  {
    ArrayList localArrayList;
    String str;
    int i;
    try
    {
      localArrayList = new ArrayList();
      str = paramString;
      if (paramString == null) {
        break label152;
      }
      str = paramString.toLowerCase(Locale.ENGLISH);
    }
    finally {}
    if (i >= this.DB.length) {
      i = 0;
    }
    for (;;)
    {
      if (i >= this.DB.length)
      {
        paramString = (CommandInfo[])localArrayList.toArray(new CommandInfo[localArrayList.size()]);
        return paramString;
        if (this.DB[i] != null)
        {
          paramString = this.DB[i].getMailcapList(str);
          if (paramString != null) {
            appendPrefCmdsToList(paramString, localArrayList);
          }
        }
      }
      else
      {
        if (this.DB[i] == null) {
          break label164;
        }
        paramString = this.DB[i].getMailcapFallbackList(str);
        if (paramString == null) {
          break label164;
        }
        appendPrefCmdsToList(paramString, localArrayList);
        break label164;
        label152:
        i = 0;
        break;
      }
      i += 1;
      break;
      label164:
      i += 1;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/activation/MailcapCommandMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */