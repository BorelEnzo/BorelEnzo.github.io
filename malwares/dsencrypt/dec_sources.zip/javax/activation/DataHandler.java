package javax.activation;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.net.URL;
import myjava.awt.datatransfer.DataFlavor;
import myjava.awt.datatransfer.Transferable;
import myjava.awt.datatransfer.UnsupportedFlavorException;

public class DataHandler
  implements Transferable
{
  private static final DataFlavor[] emptyFlavors = new DataFlavor[0];
  private static DataContentHandlerFactory factory = null;
  private CommandMap currentCommandMap = null;
  private DataContentHandler dataContentHandler = null;
  private DataSource dataSource = null;
  private DataContentHandler factoryDCH = null;
  private DataSource objDataSource = null;
  private Object object = null;
  private String objectMimeType = null;
  private DataContentHandlerFactory oldFactory = null;
  private String shortType = null;
  private DataFlavor[] transferFlavors = emptyFlavors;
  
  public DataHandler(Object paramObject, String paramString)
  {
    this.object = paramObject;
    this.objectMimeType = paramString;
    this.oldFactory = factory;
  }
  
  public DataHandler(URL paramURL)
  {
    this.dataSource = new URLDataSource(paramURL);
    this.oldFactory = factory;
  }
  
  public DataHandler(DataSource paramDataSource)
  {
    this.dataSource = paramDataSource;
    this.oldFactory = factory;
  }
  
  /* Error */
  private String getBaseType()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 60	javax/activation/DataHandler:shortType	Ljava/lang/String;
    //   6: ifnonnull +23 -> 29
    //   9: aload_0
    //   10: invokevirtual 77	javax/activation/DataHandler:getContentType	()Ljava/lang/String;
    //   13: astore_1
    //   14: aload_0
    //   15: new 79	javax/activation/MimeType
    //   18: dup
    //   19: aload_1
    //   20: invokespecial 82	javax/activation/MimeType:<init>	(Ljava/lang/String;)V
    //   23: invokevirtual 84	javax/activation/MimeType:getBaseType	()Ljava/lang/String;
    //   26: putfield 60	javax/activation/DataHandler:shortType	Ljava/lang/String;
    //   29: aload_0
    //   30: getfield 60	javax/activation/DataHandler:shortType	Ljava/lang/String;
    //   33: astore_1
    //   34: aload_0
    //   35: monitorexit
    //   36: aload_1
    //   37: areturn
    //   38: astore_2
    //   39: aload_0
    //   40: aload_1
    //   41: putfield 60	javax/activation/DataHandler:shortType	Ljava/lang/String;
    //   44: goto -15 -> 29
    //   47: astore_1
    //   48: aload_0
    //   49: monitorexit
    //   50: aload_1
    //   51: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	52	0	this	DataHandler
    //   13	28	1	str	String
    //   47	4	1	localObject	Object
    //   38	1	2	localMimeTypeParseException	MimeTypeParseException
    // Exception table:
    //   from	to	target	type
    //   14	29	38	javax/activation/MimeTypeParseException
    //   2	14	47	finally
    //   14	29	47	finally
    //   29	34	47	finally
    //   39	44	47	finally
  }
  
  /* Error */
  private CommandMap getCommandMap()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 50	javax/activation/DataHandler:currentCommandMap	Ljavax/activation/CommandMap;
    //   6: ifnull +12 -> 18
    //   9: aload_0
    //   10: getfield 50	javax/activation/DataHandler:currentCommandMap	Ljavax/activation/CommandMap;
    //   13: astore_1
    //   14: aload_0
    //   15: monitorexit
    //   16: aload_1
    //   17: areturn
    //   18: invokestatic 91	javax/activation/CommandMap:getDefaultCommandMap	()Ljavax/activation/CommandMap;
    //   21: astore_1
    //   22: goto -8 -> 14
    //   25: astore_1
    //   26: aload_0
    //   27: monitorexit
    //   28: aload_1
    //   29: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	30	0	this	DataHandler
    //   13	9	1	localCommandMap	CommandMap
    //   25	4	1	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   2	14	25	finally
    //   18	22	25	finally
  }
  
  private DataContentHandler getDataContentHandler()
  {
    label182:
    for (;;)
    {
      try
      {
        if (factory != this.oldFactory)
        {
          this.oldFactory = factory;
          this.factoryDCH = null;
          this.dataContentHandler = null;
          this.transferFlavors = emptyFlavors;
        }
        if (this.dataContentHandler != null)
        {
          localObject1 = this.dataContentHandler;
          return (DataContentHandler)localObject1;
        }
        Object localObject1 = getBaseType();
        if ((this.factoryDCH == null) && (factory != null)) {
          this.factoryDCH = factory.createDataContentHandler((String)localObject1);
        }
        if (this.factoryDCH != null) {
          this.dataContentHandler = this.factoryDCH;
        }
        if (this.dataContentHandler == null)
        {
          if (this.dataSource != null) {
            this.dataContentHandler = getCommandMap().createDataContentHandler((String)localObject1, this.dataSource);
          }
        }
        else
        {
          if (this.dataSource == null) {
            break label182;
          }
          this.dataContentHandler = new DataSourceDataContentHandler(this.dataContentHandler, this.dataSource);
          localObject1 = this.dataContentHandler;
          continue;
        }
        this.dataContentHandler = getCommandMap().createDataContentHandler((String)localObject1);
        continue;
        this.dataContentHandler = new ObjectDataContentHandler(this.dataContentHandler, this.object, this.objectMimeType);
      }
      finally {}
    }
  }
  
  public static void setDataContentHandlerFactory(DataContentHandlerFactory paramDataContentHandlerFactory)
  {
    try
    {
      if (factory != null) {
        throw new Error("DataContentHandlerFactory already defined");
      }
    }
    finally {}
    SecurityManager localSecurityManager = System.getSecurityManager();
    if (localSecurityManager != null) {}
    try
    {
      localSecurityManager.checkSetFactory();
      factory = paramDataContentHandlerFactory;
      return;
    }
    catch (SecurityException localSecurityException)
    {
      while (DataHandler.class.getClassLoader() == paramDataContentHandlerFactory.getClass().getClassLoader()) {}
      throw localSecurityException;
    }
  }
  
  public CommandInfo[] getAllCommands()
  {
    if (this.dataSource != null) {
      return getCommandMap().getAllCommands(getBaseType(), this.dataSource);
    }
    return getCommandMap().getAllCommands(getBaseType());
  }
  
  public Object getBean(CommandInfo paramCommandInfo)
  {
    try
    {
      ClassLoader localClassLoader2 = SecuritySupport.getContextClassLoader();
      ClassLoader localClassLoader1 = localClassLoader2;
      if (localClassLoader2 == null) {
        localClassLoader1 = getClass().getClassLoader();
      }
      paramCommandInfo = paramCommandInfo.getCommandObject(this, localClassLoader1);
      return paramCommandInfo;
    }
    catch (ClassNotFoundException paramCommandInfo)
    {
      return null;
    }
    catch (IOException paramCommandInfo) {}
    return null;
  }
  
  public CommandInfo getCommand(String paramString)
  {
    if (this.dataSource != null) {
      return getCommandMap().getCommand(getBaseType(), paramString, this.dataSource);
    }
    return getCommandMap().getCommand(getBaseType(), paramString);
  }
  
  public Object getContent()
    throws IOException
  {
    if (this.object != null) {
      return this.object;
    }
    return getDataContentHandler().getContent(getDataSource());
  }
  
  public String getContentType()
  {
    if (this.dataSource != null) {
      return this.dataSource.getContentType();
    }
    return this.objectMimeType;
  }
  
  public DataSource getDataSource()
  {
    if (this.dataSource == null)
    {
      if (this.objDataSource == null) {
        this.objDataSource = new DataHandlerDataSource(this);
      }
      return this.objDataSource;
    }
    return this.dataSource;
  }
  
  public InputStream getInputStream()
    throws IOException
  {
    if (this.dataSource != null) {
      return this.dataSource.getInputStream();
    }
    final DataContentHandler localDataContentHandler = getDataContentHandler();
    if (localDataContentHandler == null) {
      throw new UnsupportedDataTypeException("no DCH for MIME type " + getBaseType());
    }
    if (((localDataContentHandler instanceof ObjectDataContentHandler)) && (((ObjectDataContentHandler)localDataContentHandler).getDCH() == null)) {
      throw new UnsupportedDataTypeException("no object DCH for MIME type " + getBaseType());
    }
    final PipedOutputStream localPipedOutputStream = new PipedOutputStream();
    PipedInputStream localPipedInputStream = new PipedInputStream(localPipedOutputStream);
    new Thread(new Runnable()
    {
      /* Error */
      public void run()
      {
        // Byte code:
        //   0: aload_0
        //   1: getfield 25	javax/activation/DataHandler$1:val$fdch	Ljavax/activation/DataContentHandler;
        //   4: aload_0
        //   5: getfield 21	javax/activation/DataHandler$1:this$0	Ljavax/activation/DataHandler;
        //   8: invokestatic 36	javax/activation/DataHandler:access$0	(Ljavax/activation/DataHandler;)Ljava/lang/Object;
        //   11: aload_0
        //   12: getfield 21	javax/activation/DataHandler$1:this$0	Ljavax/activation/DataHandler;
        //   15: invokestatic 40	javax/activation/DataHandler:access$1	(Ljavax/activation/DataHandler;)Ljava/lang/String;
        //   18: aload_0
        //   19: getfield 23	javax/activation/DataHandler$1:val$pos	Ljava/io/PipedOutputStream;
        //   22: invokeinterface 46 4 0
        //   27: aload_0
        //   28: getfield 23	javax/activation/DataHandler$1:val$pos	Ljava/io/PipedOutputStream;
        //   31: invokevirtual 51	java/io/PipedOutputStream:close	()V
        //   34: return
        //   35: astore_1
        //   36: aload_0
        //   37: getfield 23	javax/activation/DataHandler$1:val$pos	Ljava/io/PipedOutputStream;
        //   40: invokevirtual 51	java/io/PipedOutputStream:close	()V
        //   43: return
        //   44: astore_1
        //   45: return
        //   46: astore_1
        //   47: aload_0
        //   48: getfield 23	javax/activation/DataHandler$1:val$pos	Ljava/io/PipedOutputStream;
        //   51: invokevirtual 51	java/io/PipedOutputStream:close	()V
        //   54: aload_1
        //   55: athrow
        //   56: astore_1
        //   57: return
        //   58: astore_2
        //   59: goto -5 -> 54
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	62	0	this	1
        //   35	1	1	localIOException1	IOException
        //   44	1	1	localIOException2	IOException
        //   46	9	1	localObject	Object
        //   56	1	1	localIOException3	IOException
        //   58	1	2	localIOException4	IOException
        // Exception table:
        //   from	to	target	type
        //   0	27	35	java/io/IOException
        //   36	43	44	java/io/IOException
        //   0	27	46	finally
        //   27	34	56	java/io/IOException
        //   47	54	58	java/io/IOException
      }
    }, "DataHandler.getInputStream").start();
    return localPipedInputStream;
  }
  
  public String getName()
  {
    if (this.dataSource != null) {
      return this.dataSource.getName();
    }
    return null;
  }
  
  public OutputStream getOutputStream()
    throws IOException
  {
    if (this.dataSource != null) {
      return this.dataSource.getOutputStream();
    }
    return null;
  }
  
  public CommandInfo[] getPreferredCommands()
  {
    if (this.dataSource != null) {
      return getCommandMap().getPreferredCommands(getBaseType(), this.dataSource);
    }
    return getCommandMap().getPreferredCommands(getBaseType());
  }
  
  public Object getTransferData(DataFlavor paramDataFlavor)
    throws UnsupportedFlavorException, IOException
  {
    return getDataContentHandler().getTransferData(paramDataFlavor, this.dataSource);
  }
  
  public DataFlavor[] getTransferDataFlavors()
  {
    try
    {
      if (factory != this.oldFactory) {
        this.transferFlavors = emptyFlavors;
      }
      if (this.transferFlavors == emptyFlavors) {
        this.transferFlavors = getDataContentHandler().getTransferDataFlavors();
      }
      DataFlavor[] arrayOfDataFlavor = this.transferFlavors;
      return arrayOfDataFlavor;
    }
    finally {}
  }
  
  public boolean isDataFlavorSupported(DataFlavor paramDataFlavor)
  {
    DataFlavor[] arrayOfDataFlavor = getTransferDataFlavors();
    int i = 0;
    for (;;)
    {
      if (i >= arrayOfDataFlavor.length) {
        return false;
      }
      if (arrayOfDataFlavor[i].equals(paramDataFlavor)) {
        return true;
      }
      i += 1;
    }
  }
  
  public void setCommandMap(CommandMap paramCommandMap)
  {
    try
    {
      if ((paramCommandMap != this.currentCommandMap) || (paramCommandMap == null))
      {
        this.transferFlavors = emptyFlavors;
        this.dataContentHandler = null;
        this.currentCommandMap = paramCommandMap;
      }
      return;
    }
    finally {}
  }
  
  public void writeTo(OutputStream paramOutputStream)
    throws IOException
  {
    if (this.dataSource != null)
    {
      byte[] arrayOfByte = new byte[' '];
      InputStream localInputStream = this.dataSource.getInputStream();
      try
      {
        for (;;)
        {
          int i = localInputStream.read(arrayOfByte);
          if (i <= 0) {
            return;
          }
          paramOutputStream.write(arrayOfByte, 0, i);
        }
        getDataContentHandler().writeTo(this.object, this.objectMimeType, paramOutputStream);
      }
      finally
      {
        localInputStream.close();
      }
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/activation/DataHandler.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */