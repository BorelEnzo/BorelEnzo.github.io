package javax.activation;

import myjava.awt.datatransfer.DataFlavor;

public class ActivationDataFlavor
  extends DataFlavor
{
  private String humanPresentableName = null;
  private MimeType mimeObject = null;
  private String mimeType = null;
  private Class representationClass = null;
  
  public ActivationDataFlavor(Class paramClass, String paramString)
  {
    super(paramClass, paramString);
    this.mimeType = super.getMimeType();
    this.representationClass = paramClass;
    this.humanPresentableName = paramString;
  }
  
  public ActivationDataFlavor(Class paramClass, String paramString1, String paramString2)
  {
    super(paramString1, paramString2);
    this.mimeType = paramString1;
    this.humanPresentableName = paramString2;
    this.representationClass = paramClass;
  }
  
  public ActivationDataFlavor(String paramString1, String paramString2)
  {
    super(paramString1, paramString2);
    this.mimeType = paramString1;
    try
    {
      this.representationClass = Class.forName("java.io.InputStream");
      this.humanPresentableName = paramString2;
      return;
    }
    catch (ClassNotFoundException paramString1)
    {
      for (;;) {}
    }
  }
  
  public boolean equals(DataFlavor paramDataFlavor)
  {
    return (isMimeTypeEqual(paramDataFlavor)) && (paramDataFlavor.getRepresentationClass() == this.representationClass);
  }
  
  public String getHumanPresentableName()
  {
    return this.humanPresentableName;
  }
  
  public String getMimeType()
  {
    return this.mimeType;
  }
  
  public Class getRepresentationClass()
  {
    return this.representationClass;
  }
  
  public boolean isMimeTypeEqual(String paramString)
  {
    try
    {
      if (this.mimeObject == null) {
        this.mimeObject = new MimeType(this.mimeType);
      }
      MimeType localMimeType = new MimeType(paramString);
      return this.mimeObject.match(localMimeType);
    }
    catch (MimeTypeParseException localMimeTypeParseException) {}
    return this.mimeType.equalsIgnoreCase(paramString);
  }
  
  protected String normalizeMimeType(String paramString)
  {
    return paramString;
  }
  
  protected String normalizeMimeTypeParameter(String paramString1, String paramString2)
  {
    return paramString2;
  }
  
  public void setHumanPresentableName(String paramString)
  {
    this.humanPresentableName = paramString;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/activation/ActivationDataFlavor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */