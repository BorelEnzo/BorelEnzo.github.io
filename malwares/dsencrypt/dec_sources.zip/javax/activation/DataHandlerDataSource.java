package javax.activation;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

class DataHandlerDataSource
  implements DataSource
{
  DataHandler dataHandler = null;
  
  public DataHandlerDataSource(DataHandler paramDataHandler)
  {
    this.dataHandler = paramDataHandler;
  }
  
  public String getContentType()
  {
    return this.dataHandler.getContentType();
  }
  
  public InputStream getInputStream()
    throws IOException
  {
    return this.dataHandler.getInputStream();
  }
  
  public String getName()
  {
    return this.dataHandler.getName();
  }
  
  public OutputStream getOutputStream()
    throws IOException
  {
    return this.dataHandler.getOutputStream();
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/activation/DataHandlerDataSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */