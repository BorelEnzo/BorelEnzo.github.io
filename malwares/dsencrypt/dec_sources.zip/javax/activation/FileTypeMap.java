package javax.activation;

import java.io.File;

public abstract class FileTypeMap
{
  private static FileTypeMap defaultMap = null;
  
  public static FileTypeMap getDefaultFileTypeMap()
  {
    if (defaultMap == null) {
      defaultMap = new MimetypesFileTypeMap();
    }
    return defaultMap;
  }
  
  public static void setDefaultFileTypeMap(FileTypeMap paramFileTypeMap)
  {
    SecurityManager localSecurityManager = System.getSecurityManager();
    if (localSecurityManager != null) {}
    try
    {
      localSecurityManager.checkSetFactory();
      defaultMap = paramFileTypeMap;
      return;
    }
    catch (SecurityException localSecurityException)
    {
      while (FileTypeMap.class.getClassLoader() == paramFileTypeMap.getClass().getClassLoader()) {}
      throw localSecurityException;
    }
  }
  
  public abstract String getContentType(File paramFile);
  
  public abstract String getContentType(String paramString);
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/activation/FileTypeMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */