package javax.activation;

import java.io.IOException;

public class UnsupportedDataTypeException
  extends IOException
{
  public UnsupportedDataTypeException() {}
  
  public UnsupportedDataTypeException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/activation/UnsupportedDataTypeException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */