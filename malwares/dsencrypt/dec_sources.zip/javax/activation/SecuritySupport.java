package javax.activation;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.security.AccessController;
import java.security.PrivilegedAction;
import java.security.PrivilegedActionException;
import java.security.PrivilegedExceptionAction;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;

class SecuritySupport
{
  public static ClassLoader getContextClassLoader()
  {
    (ClassLoader)AccessController.doPrivileged(new PrivilegedAction()
    {
      public Object run()
      {
        try
        {
          ClassLoader localClassLoader = Thread.currentThread().getContextClassLoader();
          return localClassLoader;
        }
        catch (SecurityException localSecurityException) {}
        return null;
      }
    });
  }
  
  public static InputStream getResourceAsStream(Class paramClass, final String paramString)
    throws IOException
  {
    try
    {
      paramClass = (InputStream)AccessController.doPrivileged(new PrivilegedExceptionAction()
      {
        public Object run()
          throws IOException
        {
          return SecuritySupport.this.getResourceAsStream(paramString);
        }
      });
      return paramClass;
    }
    catch (PrivilegedActionException paramClass)
    {
      throw ((IOException)paramClass.getException());
    }
  }
  
  public static URL[] getResources(ClassLoader paramClassLoader, final String paramString)
  {
    (URL[])AccessController.doPrivileged(new PrivilegedAction()
    {
      public Object run()
      {
        URL[] arrayOfURL2 = (URL[])null;
        URL[] arrayOfURL3 = arrayOfURL2;
        URL[] arrayOfURL1 = arrayOfURL2;
        try
        {
          ArrayList localArrayList = new ArrayList();
          arrayOfURL3 = arrayOfURL2;
          arrayOfURL1 = arrayOfURL2;
          Object localObject = SecuritySupport.this.getResources(paramString);
          for (;;)
          {
            if (localObject != null)
            {
              arrayOfURL3 = arrayOfURL2;
              arrayOfURL1 = arrayOfURL2;
              if (((Enumeration)localObject).hasMoreElements()) {}
            }
            else
            {
              arrayOfURL3 = arrayOfURL2;
              arrayOfURL1 = arrayOfURL2;
              localObject = arrayOfURL2;
              if (localArrayList.size() <= 0) {
                break;
              }
              arrayOfURL3 = arrayOfURL2;
              arrayOfURL1 = arrayOfURL2;
              arrayOfURL2 = new URL[localArrayList.size()];
              arrayOfURL3 = arrayOfURL2;
              arrayOfURL1 = arrayOfURL2;
              return (URL[])localArrayList.toArray(arrayOfURL2);
            }
            arrayOfURL3 = arrayOfURL2;
            arrayOfURL1 = arrayOfURL2;
            URL localURL = (URL)((Enumeration)localObject).nextElement();
            if (localURL != null)
            {
              arrayOfURL3 = arrayOfURL2;
              arrayOfURL1 = arrayOfURL2;
              localArrayList.add(localURL);
            }
          }
          return localObject;
        }
        catch (IOException localIOException)
        {
          return arrayOfURL3;
        }
        catch (SecurityException localSecurityException)
        {
          localObject = localIOException;
        }
      }
    });
  }
  
  public static URL[] getSystemResources(String paramString)
  {
    (URL[])AccessController.doPrivileged(new PrivilegedAction()
    {
      public Object run()
      {
        URL[] arrayOfURL2 = (URL[])null;
        URL[] arrayOfURL3 = arrayOfURL2;
        URL[] arrayOfURL1 = arrayOfURL2;
        try
        {
          ArrayList localArrayList = new ArrayList();
          arrayOfURL3 = arrayOfURL2;
          arrayOfURL1 = arrayOfURL2;
          Object localObject = ClassLoader.getSystemResources(SecuritySupport.this);
          for (;;)
          {
            if (localObject != null)
            {
              arrayOfURL3 = arrayOfURL2;
              arrayOfURL1 = arrayOfURL2;
              if (((Enumeration)localObject).hasMoreElements()) {}
            }
            else
            {
              arrayOfURL3 = arrayOfURL2;
              arrayOfURL1 = arrayOfURL2;
              localObject = arrayOfURL2;
              if (localArrayList.size() <= 0) {
                break;
              }
              arrayOfURL3 = arrayOfURL2;
              arrayOfURL1 = arrayOfURL2;
              arrayOfURL2 = new URL[localArrayList.size()];
              arrayOfURL3 = arrayOfURL2;
              arrayOfURL1 = arrayOfURL2;
              return (URL[])localArrayList.toArray(arrayOfURL2);
            }
            arrayOfURL3 = arrayOfURL2;
            arrayOfURL1 = arrayOfURL2;
            URL localURL = (URL)((Enumeration)localObject).nextElement();
            if (localURL != null)
            {
              arrayOfURL3 = arrayOfURL2;
              arrayOfURL1 = arrayOfURL2;
              localArrayList.add(localURL);
            }
          }
          return localObject;
        }
        catch (IOException localIOException)
        {
          return arrayOfURL3;
        }
        catch (SecurityException localSecurityException)
        {
          localObject = localIOException;
        }
      }
    });
  }
  
  public static InputStream openStream(URL paramURL)
    throws IOException
  {
    try
    {
      paramURL = (InputStream)AccessController.doPrivileged(new PrivilegedExceptionAction()
      {
        public Object run()
          throws IOException
        {
          return SecuritySupport.this.openStream();
        }
      });
      return paramURL;
    }
    catch (PrivilegedActionException paramURL)
    {
      throw ((IOException)paramURL.getException());
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/activation/SecuritySupport.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */