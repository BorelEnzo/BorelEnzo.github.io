package javax.activation;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URL;
import java.net.URLConnection;

public class URLDataSource
  implements DataSource
{
  private URL url = null;
  private URLConnection url_conn = null;
  
  public URLDataSource(URL paramURL)
  {
    this.url = paramURL;
  }
  
  public String getContentType()
  {
    String str1 = null;
    try
    {
      if (this.url_conn == null) {
        this.url_conn = this.url.openConnection();
      }
      if (this.url_conn != null) {
        str1 = this.url_conn.getContentType();
      }
      String str2 = str1;
      if (str1 == null) {
        str2 = "application/octet-stream";
      }
      return str2;
    }
    catch (IOException localIOException)
    {
      for (;;) {}
    }
  }
  
  public InputStream getInputStream()
    throws IOException
  {
    return this.url.openStream();
  }
  
  public String getName()
  {
    return this.url.getFile();
  }
  
  public OutputStream getOutputStream()
    throws IOException
  {
    this.url_conn = this.url.openConnection();
    if (this.url_conn != null)
    {
      this.url_conn.setDoOutput(true);
      return this.url_conn.getOutputStream();
    }
    return null;
  }
  
  public URL getURL()
  {
    return this.url;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/activation/URLDataSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */