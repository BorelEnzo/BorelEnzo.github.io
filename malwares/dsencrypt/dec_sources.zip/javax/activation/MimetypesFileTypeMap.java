package javax.activation;

import com.sun.activation.registries.LogSupport;
import com.sun.activation.registries.MimeTypeFile;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Vector;

public class MimetypesFileTypeMap
  extends FileTypeMap
{
  private static final int PROG = 0;
  private static MimeTypeFile defDB = null;
  private static String defaultType = "application/octet-stream";
  private MimeTypeFile[] DB;
  
  public MimetypesFileTypeMap()
  {
    Vector localVector = new Vector(5);
    localVector.addElement(null);
    LogSupport.log("MimetypesFileTypeMap: load HOME");
    try
    {
      localObject2 = System.getProperty("user.home");
      if (localObject2 != null)
      {
        localObject2 = loadFile(localObject2 + File.separator + ".mime.types");
        if (localObject2 != null) {
          localVector.addElement(localObject2);
        }
      }
    }
    catch (SecurityException localSecurityException2)
    {
      Object localObject2;
      for (;;) {}
    }
    LogSupport.log("MimetypesFileTypeMap: load SYS");
    try
    {
      localObject2 = loadFile(System.getProperty("java.home") + File.separator + "lib" + File.separator + "mime.types");
      if (localObject2 != null) {
        localVector.addElement(localObject2);
      }
    }
    catch (SecurityException localSecurityException1)
    {
      for (;;) {}
    }
    LogSupport.log("MimetypesFileTypeMap: load JAR");
    loadAllResources(localVector, "mime.types");
    LogSupport.log("MimetypesFileTypeMap: load DEF");
    try
    {
      if (defDB == null) {
        defDB = loadResource("/mimetypes.default");
      }
      if (defDB != null) {
        localVector.addElement(defDB);
      }
      this.DB = new MimeTypeFile[localVector.size()];
      localVector.copyInto(this.DB);
      return;
    }
    finally {}
  }
  
  public MimetypesFileTypeMap(InputStream paramInputStream)
  {
    this();
    try
    {
      this.DB[0] = new MimeTypeFile(paramInputStream);
      return;
    }
    catch (IOException paramInputStream) {}
  }
  
  public MimetypesFileTypeMap(String paramString)
    throws IOException
  {
    this();
    this.DB[0] = new MimeTypeFile(paramString);
  }
  
  private void loadAllResources(Vector paramVector, String paramString)
  {
    i = 0;
    m = 0;
    k = 0;
    j = m;
    for (;;)
    {
      try
      {
        localObject3 = SecuritySupport.getContextClassLoader();
        localObject1 = localObject3;
        if (localObject3 == null)
        {
          j = m;
          localObject1 = getClass().getClassLoader();
        }
        if (localObject1 == null) {
          continue;
        }
        j = m;
        arrayOfURL = SecuritySupport.getResources((ClassLoader)localObject1, paramString);
        if (arrayOfURL == null) {
          continue;
        }
        j = m;
        if (!LogSupport.isLoggable()) {
          continue;
        }
        j = m;
        LogSupport.log("MimetypesFileTypeMap: getResources");
      }
      catch (Exception localException)
      {
        int i1;
        try
        {
          Object localObject3;
          Object localObject1;
          URL[] arrayOfURL;
          URL localURL;
          Object localObject5;
          int n;
          localIOException2.close();
          j = n;
          throw ((Throwable)localObject4);
          localException = localException;
          i = j;
          if (!LogSupport.isLoggable()) {
            continue;
          }
          LogSupport.log("MimetypesFileTypeMap: can't load " + paramString, localException);
          i = j;
        }
        catch (IOException localIOException3)
        {
          continue;
        }
        int i2 = 0;
        i = k;
        continue;
      }
      j = i;
      k = arrayOfURL.length;
      if (i2 < k) {
        continue;
      }
      if (i == 0)
      {
        LogSupport.log("MimetypesFileTypeMap: !anyLoaded");
        paramString = loadResource("/" + paramString);
        if (paramString != null) {
          paramVector.addElement(paramString);
        }
      }
      return;
      j = m;
      arrayOfURL = SecuritySupport.getSystemResources(paramString);
    }
    localURL = arrayOfURL[i2];
    localObject5 = null;
    localObject1 = null;
    localObject3 = null;
    j = i;
    if (LogSupport.isLoggable())
    {
      j = i;
      LogSupport.log("MimetypesFileTypeMap: URL " + localURL);
    }
    k = i;
    m = i;
    n = i;
    for (;;)
    {
      try
      {
        localInputStream = SecuritySupport.openStream(localURL);
        if (localInputStream != null)
        {
          k = i;
          localObject3 = localInputStream;
          m = i;
          localObject5 = localInputStream;
          n = i;
          localObject1 = localInputStream;
          paramVector.addElement(new MimeTypeFile(localInputStream));
          j = 1;
          int i3 = 1;
          int i4 = 1;
          i = 1;
          i1 = i;
          k = j;
          localObject3 = localInputStream;
          m = i3;
          localObject5 = localInputStream;
          n = i4;
          localObject1 = localInputStream;
          if (LogSupport.isLoggable())
          {
            k = j;
            localObject3 = localInputStream;
            m = i3;
            localObject5 = localInputStream;
            n = i4;
            localObject1 = localInputStream;
            LogSupport.log("MimetypesFileTypeMap: successfully loaded mime types from URL: " + localURL);
            i1 = i;
          }
          i = i1;
        }
      }
      catch (IOException localIOException5)
      {
        InputStream localInputStream;
        n = k;
        localObject1 = localObject3;
        if (LogSupport.isLoggable())
        {
          n = k;
          localObject1 = localObject3;
          LogSupport.log("MimetypesFileTypeMap: can't load " + localURL, localIOException5);
        }
        i = k;
        if (localObject3 == null) {
          continue;
        }
        j = k;
        try
        {
          ((InputStream)localObject3).close();
          i = k;
        }
        catch (IOException localIOException1)
        {
          i = k;
        }
        continue;
      }
      catch (SecurityException localSecurityException)
      {
        n = m;
        Object localObject2 = localIOException5;
        if (LogSupport.isLoggable())
        {
          n = m;
          localObject2 = localIOException5;
          LogSupport.log("MimetypesFileTypeMap: can't load " + localURL, localSecurityException);
        }
        i = m;
        if (localIOException5 == null) {
          continue;
        }
        j = m;
        try
        {
          localIOException5.close();
          i = m;
        }
        catch (IOException localIOException2)
        {
          i = m;
        }
        continue;
      }
      finally
      {
        if (localIOException2 != null) {
          j = n;
        }
      }
      try
      {
        localInputStream.close();
        i = i1;
      }
      catch (IOException localIOException4)
      {
        i = i1;
        continue;
      }
      i2 += 1;
      break;
      i1 = i;
      k = i;
      localObject3 = localInputStream;
      m = i;
      localObject5 = localInputStream;
      n = i;
      localObject1 = localInputStream;
      if (LogSupport.isLoggable())
      {
        k = i;
        localObject3 = localInputStream;
        m = i;
        localObject5 = localInputStream;
        n = i;
        localObject1 = localInputStream;
        LogSupport.log("MimetypesFileTypeMap: not loading mime types from URL: " + localURL);
        i1 = i;
      }
    }
  }
  
  private MimeTypeFile loadFile(String paramString)
  {
    try
    {
      paramString = new MimeTypeFile(paramString);
      return paramString;
    }
    catch (IOException paramString) {}
    return null;
  }
  
  /* Error */
  private MimeTypeFile loadResource(String paramString)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 4
    //   3: aconst_null
    //   4: astore_2
    //   5: aconst_null
    //   6: astore_3
    //   7: aload_0
    //   8: invokevirtual 136	java/lang/Object:getClass	()Ljava/lang/Class;
    //   11: aload_1
    //   12: invokestatic 186	javax/activation/SecuritySupport:getResourceAsStream	(Ljava/lang/Class;Ljava/lang/String;)Ljava/io/InputStream;
    //   15: astore 5
    //   17: aload 5
    //   19: ifnull +82 -> 101
    //   22: aload 5
    //   24: astore_3
    //   25: aload 5
    //   27: astore 4
    //   29: aload 5
    //   31: astore_2
    //   32: new 108	com/sun/activation/registries/MimeTypeFile
    //   35: dup
    //   36: aload 5
    //   38: invokespecial 120	com/sun/activation/registries/MimeTypeFile:<init>	(Ljava/io/InputStream;)V
    //   41: astore 6
    //   43: aload 5
    //   45: astore_3
    //   46: aload 5
    //   48: astore 4
    //   50: aload 5
    //   52: astore_2
    //   53: invokestatic 149	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   56: ifeq +32 -> 88
    //   59: aload 5
    //   61: astore_3
    //   62: aload 5
    //   64: astore 4
    //   66: aload 5
    //   68: astore_2
    //   69: new 54	java/lang/StringBuilder
    //   72: dup
    //   73: ldc -68
    //   75: invokespecial 62	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   78: aload_1
    //   79: invokevirtual 71	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   82: invokevirtual 77	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   85: invokestatic 44	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;)V
    //   88: aload 5
    //   90: ifnull +8 -> 98
    //   93: aload 5
    //   95: invokevirtual 175	java/io/InputStream:close	()V
    //   98: aload 6
    //   100: areturn
    //   101: aload 5
    //   103: astore_3
    //   104: aload 5
    //   106: astore 4
    //   108: aload 5
    //   110: astore_2
    //   111: invokestatic 149	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   114: ifeq +32 -> 146
    //   117: aload 5
    //   119: astore_3
    //   120: aload 5
    //   122: astore 4
    //   124: aload 5
    //   126: astore_2
    //   127: new 54	java/lang/StringBuilder
    //   130: dup
    //   131: ldc -66
    //   133: invokespecial 62	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   136: aload_1
    //   137: invokevirtual 71	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   140: invokevirtual 77	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   143: invokestatic 44	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;)V
    //   146: aload 5
    //   148: ifnull +8 -> 156
    //   151: aload 5
    //   153: invokevirtual 175	java/io/InputStream:close	()V
    //   156: aconst_null
    //   157: areturn
    //   158: astore 4
    //   160: aload_3
    //   161: astore_2
    //   162: invokestatic 149	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   165: ifeq +26 -> 191
    //   168: aload_3
    //   169: astore_2
    //   170: new 54	java/lang/StringBuilder
    //   173: dup
    //   174: ldc -77
    //   176: invokespecial 62	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   179: aload_1
    //   180: invokevirtual 71	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   183: invokevirtual 77	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   186: aload 4
    //   188: invokestatic 182	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   191: aload_3
    //   192: ifnull -36 -> 156
    //   195: aload_3
    //   196: invokevirtual 175	java/io/InputStream:close	()V
    //   199: goto -43 -> 156
    //   202: astore_1
    //   203: goto -47 -> 156
    //   206: astore_3
    //   207: aload 4
    //   209: astore_2
    //   210: invokestatic 149	com/sun/activation/registries/LogSupport:isLoggable	()Z
    //   213: ifeq +26 -> 239
    //   216: aload 4
    //   218: astore_2
    //   219: new 54	java/lang/StringBuilder
    //   222: dup
    //   223: ldc -77
    //   225: invokespecial 62	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   228: aload_1
    //   229: invokevirtual 71	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   232: invokevirtual 77	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   235: aload_3
    //   236: invokestatic 182	com/sun/activation/registries/LogSupport:log	(Ljava/lang/String;Ljava/lang/Throwable;)V
    //   239: aload 4
    //   241: ifnull -85 -> 156
    //   244: aload 4
    //   246: invokevirtual 175	java/io/InputStream:close	()V
    //   249: goto -93 -> 156
    //   252: astore_1
    //   253: goto -97 -> 156
    //   256: astore_1
    //   257: aload_2
    //   258: ifnull +7 -> 265
    //   261: aload_2
    //   262: invokevirtual 175	java/io/InputStream:close	()V
    //   265: aload_1
    //   266: athrow
    //   267: astore_1
    //   268: aload 6
    //   270: areturn
    //   271: astore_2
    //   272: goto -7 -> 265
    //   275: astore_1
    //   276: goto -120 -> 156
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	279	0	this	MimetypesFileTypeMap
    //   0	279	1	paramString	String
    //   4	258	2	localObject1	Object
    //   271	1	2	localIOException1	IOException
    //   6	190	3	localObject2	Object
    //   206	30	3	localSecurityException	SecurityException
    //   1	122	4	localObject3	Object
    //   158	87	4	localIOException2	IOException
    //   15	137	5	localInputStream	InputStream
    //   41	228	6	localMimeTypeFile	MimeTypeFile
    // Exception table:
    //   from	to	target	type
    //   7	17	158	java/io/IOException
    //   32	43	158	java/io/IOException
    //   53	59	158	java/io/IOException
    //   69	88	158	java/io/IOException
    //   111	117	158	java/io/IOException
    //   127	146	158	java/io/IOException
    //   195	199	202	java/io/IOException
    //   7	17	206	java/lang/SecurityException
    //   32	43	206	java/lang/SecurityException
    //   53	59	206	java/lang/SecurityException
    //   69	88	206	java/lang/SecurityException
    //   111	117	206	java/lang/SecurityException
    //   127	146	206	java/lang/SecurityException
    //   244	249	252	java/io/IOException
    //   7	17	256	finally
    //   32	43	256	finally
    //   53	59	256	finally
    //   69	88	256	finally
    //   111	117	256	finally
    //   127	146	256	finally
    //   162	168	256	finally
    //   170	191	256	finally
    //   210	216	256	finally
    //   219	239	256	finally
    //   93	98	267	java/io/IOException
    //   261	265	271	java/io/IOException
    //   151	156	275	java/io/IOException
  }
  
  public void addMimeTypes(String paramString)
  {
    try
    {
      if (this.DB[0] == null) {
        this.DB[0] = new MimeTypeFile();
      }
      this.DB[0].appendToRegistry(paramString);
      return;
    }
    finally {}
  }
  
  public String getContentType(File paramFile)
  {
    return getContentType(paramFile.getName());
  }
  
  public String getContentType(String paramString)
  {
    for (;;)
    {
      int i;
      try
      {
        i = paramString.lastIndexOf(".");
        if (i < 0)
        {
          paramString = defaultType;
          return paramString;
        }
        String str = paramString.substring(i + 1);
        if (str.length() == 0)
        {
          paramString = defaultType;
          continue;
          if (i >= this.DB.length)
          {
            paramString = defaultType;
            continue;
          }
          if (this.DB[i] == null) {
            break label99;
          }
          paramString = this.DB[i].getMIMETypeString(str);
          if (paramString == null) {
            break label99;
          }
          continue;
        }
        i = 0;
      }
      finally {}
      continue;
      label99:
      i += 1;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/activation/MimetypesFileTypeMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */