package javax.mail.util;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import javax.mail.internet.SharedInputStream;

public class SharedFileInputStream
  extends BufferedInputStream
  implements SharedInputStream
{
  private static int defaultBufferSize = 2048;
  protected long bufpos;
  protected int bufsize;
  protected long datalen;
  protected RandomAccessFile in;
  private boolean master = true;
  private SharedFile sf;
  protected long start = 0L;
  
  public SharedFileInputStream(File paramFile)
    throws IOException
  {
    this(paramFile, defaultBufferSize);
  }
  
  public SharedFileInputStream(File paramFile, int paramInt)
    throws IOException
  {
    super(null);
    if (paramInt <= 0) {
      throw new IllegalArgumentException("Buffer size <= 0");
    }
    init(new SharedFile(paramFile), paramInt);
  }
  
  public SharedFileInputStream(String paramString)
    throws IOException
  {
    this(paramString, defaultBufferSize);
  }
  
  public SharedFileInputStream(String paramString, int paramInt)
    throws IOException
  {
    super(null);
    if (paramInt <= 0) {
      throw new IllegalArgumentException("Buffer size <= 0");
    }
    init(new SharedFile(paramString), paramInt);
  }
  
  private SharedFileInputStream(SharedFile paramSharedFile, long paramLong1, long paramLong2, int paramInt)
  {
    super(null);
    this.master = false;
    this.sf = paramSharedFile;
    this.in = paramSharedFile.open();
    this.start = paramLong1;
    this.bufpos = paramLong1;
    this.datalen = paramLong2;
    this.bufsize = paramInt;
    this.buf = new byte[paramInt];
  }
  
  private void ensureOpen()
    throws IOException
  {
    if (this.in == null) {
      throw new IOException("Stream closed");
    }
  }
  
  private void fill()
    throws IOException
  {
    if (this.markpos < 0)
    {
      this.pos = 0;
      this.bufpos += this.count;
    }
    for (;;)
    {
      this.count = this.pos;
      this.in.seek(this.bufpos + this.pos);
      int j = this.buf.length - this.pos;
      int i = j;
      if (this.bufpos - this.start + this.pos + j > this.datalen) {
        i = (int)(this.datalen - (this.bufpos - this.start + this.pos));
      }
      i = this.in.read(this.buf, this.pos, i);
      if (i > 0) {
        this.count = (this.pos + i);
      }
      return;
      if (this.pos >= this.buf.length) {
        if (this.markpos > 0)
        {
          i = this.pos - this.markpos;
          System.arraycopy(this.buf, this.markpos, this.buf, 0, i);
          this.pos = i;
          this.bufpos += this.markpos;
          this.markpos = 0;
        }
        else if (this.buf.length >= this.marklimit)
        {
          this.markpos = -1;
          this.pos = 0;
          this.bufpos += this.count;
        }
        else
        {
          j = this.pos * 2;
          i = j;
          if (j > this.marklimit) {
            i = this.marklimit;
          }
          byte[] arrayOfByte = new byte[i];
          System.arraycopy(this.buf, 0, arrayOfByte, 0, this.pos);
          this.buf = arrayOfByte;
        }
      }
    }
  }
  
  private int in_available()
    throws IOException
  {
    return (int)(this.start + this.datalen - (this.bufpos + this.count));
  }
  
  private void init(SharedFile paramSharedFile, int paramInt)
    throws IOException
  {
    this.sf = paramSharedFile;
    this.in = paramSharedFile.open();
    this.start = 0L;
    this.datalen = this.in.length();
    this.bufsize = paramInt;
    this.buf = new byte[paramInt];
  }
  
  private int read1(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int j = this.count - this.pos;
    int i = j;
    if (j <= 0)
    {
      fill();
      j = this.count - this.pos;
      i = j;
      if (j <= 0) {
        return -1;
      }
    }
    if (i < paramInt2) {}
    for (;;)
    {
      System.arraycopy(this.buf, this.pos, paramArrayOfByte, paramInt1, i);
      this.pos += i;
      return i;
      i = paramInt2;
    }
  }
  
  public int available()
    throws IOException
  {
    try
    {
      ensureOpen();
      int i = this.count;
      int j = this.pos;
      int k = in_available();
      return i - j + k;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  /* Error */
  public void close()
    throws IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 68	javax/mail/util/SharedFileInputStream:in	Ljava/io/RandomAccessFile;
    //   4: ifnonnull +4 -> 8
    //   7: return
    //   8: aload_0
    //   9: getfield 42	javax/mail/util/SharedFileInputStream:master	Z
    //   12: ifeq +26 -> 38
    //   15: aload_0
    //   16: getfield 62	javax/mail/util/SharedFileInputStream:sf	Ljavax/mail/util/SharedFileInputStream$SharedFile;
    //   19: invokevirtual 129	javax/mail/util/SharedFileInputStream$SharedFile:forceClose	()V
    //   22: aload_0
    //   23: aconst_null
    //   24: putfield 62	javax/mail/util/SharedFileInputStream:sf	Ljavax/mail/util/SharedFileInputStream$SharedFile;
    //   27: aload_0
    //   28: aconst_null
    //   29: putfield 68	javax/mail/util/SharedFileInputStream:in	Ljava/io/RandomAccessFile;
    //   32: aload_0
    //   33: aconst_null
    //   34: putfield 78	javax/mail/util/SharedFileInputStream:buf	[B
    //   37: return
    //   38: aload_0
    //   39: getfield 62	javax/mail/util/SharedFileInputStream:sf	Ljavax/mail/util/SharedFileInputStream$SharedFile;
    //   42: invokevirtual 131	javax/mail/util/SharedFileInputStream$SharedFile:close	()V
    //   45: goto -23 -> 22
    //   48: astore_1
    //   49: aload_0
    //   50: aconst_null
    //   51: putfield 62	javax/mail/util/SharedFileInputStream:sf	Ljavax/mail/util/SharedFileInputStream$SharedFile;
    //   54: aload_0
    //   55: aconst_null
    //   56: putfield 68	javax/mail/util/SharedFileInputStream:in	Ljava/io/RandomAccessFile;
    //   59: aload_0
    //   60: aconst_null
    //   61: putfield 78	javax/mail/util/SharedFileInputStream:buf	[B
    //   64: aload_1
    //   65: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	66	0	this	SharedFileInputStream
    //   48	17	1	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   8	22	48	finally
    //   38	45	48	finally
  }
  
  protected void finalize()
    throws Throwable
  {
    super.finalize();
    close();
  }
  
  public long getPosition()
  {
    if (this.in == null) {
      throw new RuntimeException("Stream closed");
    }
    return this.bufpos + this.pos - this.start;
  }
  
  public void mark(int paramInt)
  {
    try
    {
      this.marklimit = paramInt;
      this.markpos = this.pos;
      return;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public boolean markSupported()
  {
    return true;
  }
  
  public InputStream newStream(long paramLong1, long paramLong2)
  {
    if (this.in == null) {
      throw new RuntimeException("Stream closed");
    }
    if (paramLong1 < 0L) {
      throw new IllegalArgumentException("start < 0");
    }
    long l = paramLong2;
    if (paramLong2 == -1L) {
      l = this.datalen;
    }
    return new SharedFileInputStream(this.sf, this.start + (int)paramLong1, (int)(l - paramLong1), this.bufsize);
  }
  
  /* Error */
  public int read()
    throws IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokespecial 123	javax/mail/util/SharedFileInputStream:ensureOpen	()V
    //   6: aload_0
    //   7: getfield 89	javax/mail/util/SharedFileInputStream:pos	I
    //   10: aload_0
    //   11: getfield 92	javax/mail/util/SharedFileInputStream:count	I
    //   14: if_icmplt +28 -> 42
    //   17: aload_0
    //   18: invokespecial 120	javax/mail/util/SharedFileInputStream:fill	()V
    //   21: aload_0
    //   22: getfield 89	javax/mail/util/SharedFileInputStream:pos	I
    //   25: istore_1
    //   26: aload_0
    //   27: getfield 92	javax/mail/util/SharedFileInputStream:count	I
    //   30: istore_2
    //   31: iload_1
    //   32: iload_2
    //   33: if_icmplt +9 -> 42
    //   36: iconst_m1
    //   37: istore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: iload_1
    //   41: ireturn
    //   42: aload_0
    //   43: getfield 78	javax/mail/util/SharedFileInputStream:buf	[B
    //   46: astore_3
    //   47: aload_0
    //   48: getfield 89	javax/mail/util/SharedFileInputStream:pos	I
    //   51: istore_1
    //   52: aload_0
    //   53: iload_1
    //   54: iconst_1
    //   55: iadd
    //   56: putfield 89	javax/mail/util/SharedFileInputStream:pos	I
    //   59: aload_3
    //   60: iload_1
    //   61: baload
    //   62: istore_1
    //   63: iload_1
    //   64: sipush 255
    //   67: iand
    //   68: istore_1
    //   69: goto -31 -> 38
    //   72: astore_3
    //   73: aload_0
    //   74: monitorexit
    //   75: aload_3
    //   76: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	77	0	this	SharedFileInputStream
    //   25	44	1	i	int
    //   30	4	2	j	int
    //   46	14	3	arrayOfByte	byte[]
    //   72	4	3	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   2	31	72	finally
    //   42	59	72	finally
  }
  
  public int read(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    try
    {
      ensureOpen();
      if ((paramInt1 | paramInt2 | paramInt1 + paramInt2 | paramArrayOfByte.length - (paramInt1 + paramInt2)) < 0) {
        throw new IndexOutOfBoundsException();
      }
    }
    finally {}
    int i;
    if (paramInt2 == 0) {
      i = 0;
    }
    int j;
    do
    {
      return i;
      j = read1(paramArrayOfByte, paramInt1, paramInt2);
      i = j;
    } while (j <= 0);
    for (;;)
    {
      i = j;
      if (j >= paramInt2) {
        break;
      }
      int k = read1(paramArrayOfByte, paramInt1 + j, paramInt2 - j);
      i = j;
      if (k <= 0) {
        break;
      }
      j += k;
    }
  }
  
  public void reset()
    throws IOException
  {
    try
    {
      ensureOpen();
      if (this.markpos < 0) {
        throw new IOException("Resetting to invalid mark");
      }
    }
    finally {}
    this.pos = this.markpos;
  }
  
  public long skip(long paramLong)
    throws IOException
  {
    long l2 = 0L;
    for (;;)
    {
      try
      {
        ensureOpen();
        if (paramLong <= 0L)
        {
          l1 = l2;
          return l1;
        }
        long l3 = this.count - this.pos;
        l1 = l3;
        if (l3 > 0L) {
          break label103;
        }
        fill();
        l3 = this.count - this.pos;
        l1 = l2;
        if (l3 <= 0L) {
          continue;
        }
        l1 = l3;
      }
      finally {}
      this.pos = ((int)(this.pos + paramLong));
      long l1 = paramLong;
      continue;
      label103:
      do
      {
        break;
      } while (l1 >= paramLong);
      paramLong = l1;
    }
  }
  
  static class SharedFile
  {
    private int cnt;
    private RandomAccessFile in;
    
    SharedFile(File paramFile)
      throws IOException
    {
      this.in = new RandomAccessFile(paramFile, "r");
    }
    
    SharedFile(String paramString)
      throws IOException
    {
      this.in = new RandomAccessFile(paramString, "r");
    }
    
    public void close()
      throws IOException
    {
      try
      {
        if (this.cnt > 0)
        {
          int i = this.cnt - 1;
          this.cnt = i;
          if (i <= 0) {
            this.in.close();
          }
        }
        return;
      }
      finally {}
    }
    
    protected void finalize()
      throws Throwable
    {
      super.finalize();
      this.in.close();
    }
    
    /* Error */
    public void forceClose()
      throws IOException
    {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield 36	javax/mail/util/SharedFileInputStream$SharedFile:cnt	I
      //   6: ifle +18 -> 24
      //   9: aload_0
      //   10: iconst_0
      //   11: putfield 36	javax/mail/util/SharedFileInputStream$SharedFile:cnt	I
      //   14: aload_0
      //   15: getfield 27	javax/mail/util/SharedFileInputStream$SharedFile:in	Ljava/io/RandomAccessFile;
      //   18: invokevirtual 38	java/io/RandomAccessFile:close	()V
      //   21: aload_0
      //   22: monitorexit
      //   23: return
      //   24: aload_0
      //   25: getfield 27	javax/mail/util/SharedFileInputStream$SharedFile:in	Ljava/io/RandomAccessFile;
      //   28: invokevirtual 38	java/io/RandomAccessFile:close	()V
      //   31: goto -10 -> 21
      //   34: astore_1
      //   35: goto -14 -> 21
      //   38: astore_1
      //   39: aload_0
      //   40: monitorexit
      //   41: aload_1
      //   42: athrow
      // Local variable table:
      //   start	length	slot	name	signature
      //   0	43	0	this	SharedFile
      //   34	1	1	localIOException	IOException
      //   38	4	1	localObject	Object
      // Exception table:
      //   from	to	target	type
      //   24	31	34	java/io/IOException
      //   2	21	38	finally
      //   24	31	38	finally
    }
    
    public RandomAccessFile open()
    {
      this.cnt += 1;
      return this.in;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/util/SharedFileInputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */