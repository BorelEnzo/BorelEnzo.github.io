package javax.mail;

public class Header
{
  protected String name;
  protected String value;
  
  public Header(String paramString1, String paramString2)
  {
    this.name = paramString1;
    this.value = paramString2;
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public String getValue()
  {
    return this.value;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/Header.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */