package javax.mail;

public class FolderClosedException
  extends MessagingException
{
  private static final long serialVersionUID = 1687879213433302315L;
  private transient Folder folder;
  
  public FolderClosedException(Folder paramFolder)
  {
    this(paramFolder, null);
  }
  
  public FolderClosedException(Folder paramFolder, String paramString)
  {
    super(paramString);
    this.folder = paramFolder;
  }
  
  public Folder getFolder()
  {
    return this.folder;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/FolderClosedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */