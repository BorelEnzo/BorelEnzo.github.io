package javax.mail;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Locale;
import java.util.Vector;

public class Flags
  implements Cloneable, Serializable
{
  private static final int ANSWERED_BIT = 1;
  private static final int DELETED_BIT = 2;
  private static final int DRAFT_BIT = 4;
  private static final int FLAGGED_BIT = 8;
  private static final int RECENT_BIT = 16;
  private static final int SEEN_BIT = 32;
  private static final int USER_BIT = Integer.MIN_VALUE;
  private static final long serialVersionUID = 6243590407214169028L;
  private int system_flags = 0;
  private Hashtable user_flags = null;
  
  public Flags() {}
  
  public Flags(String paramString)
  {
    this.user_flags = new Hashtable(1);
    this.user_flags.put(paramString.toLowerCase(Locale.ENGLISH), paramString);
  }
  
  public Flags(Flag paramFlag)
  {
    this.system_flags |= paramFlag.bit;
  }
  
  public Flags(Flags paramFlags)
  {
    this.system_flags = paramFlags.system_flags;
    if (paramFlags.user_flags != null) {
      this.user_flags = ((Hashtable)paramFlags.user_flags.clone());
    }
  }
  
  public void add(String paramString)
  {
    if (this.user_flags == null) {
      this.user_flags = new Hashtable(1);
    }
    this.user_flags.put(paramString.toLowerCase(Locale.ENGLISH), paramString);
  }
  
  public void add(Flag paramFlag)
  {
    this.system_flags |= paramFlag.bit;
  }
  
  public void add(Flags paramFlags)
  {
    this.system_flags |= paramFlags.system_flags;
    Enumeration localEnumeration;
    if (paramFlags.user_flags != null)
    {
      if (this.user_flags == null) {
        this.user_flags = new Hashtable(1);
      }
      localEnumeration = paramFlags.user_flags.keys();
    }
    for (;;)
    {
      if (!localEnumeration.hasMoreElements()) {
        return;
      }
      String str = (String)localEnumeration.nextElement();
      this.user_flags.put(str, paramFlags.user_flags.get(str));
    }
  }
  
  public Object clone()
  {
    Object localObject = null;
    try
    {
      Flags localFlags = (Flags)super.clone();
      localObject = localFlags;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException)
    {
      for (;;) {}
    }
    if ((this.user_flags != null) && (localObject != null)) {
      ((Flags)localObject).user_flags = ((Hashtable)this.user_flags.clone());
    }
    return localObject;
  }
  
  public boolean contains(String paramString)
  {
    if (this.user_flags == null) {
      return false;
    }
    return this.user_flags.containsKey(paramString.toLowerCase(Locale.ENGLISH));
  }
  
  public boolean contains(Flag paramFlag)
  {
    return (this.system_flags & paramFlag.bit) != 0;
  }
  
  public boolean contains(Flags paramFlags)
  {
    if ((paramFlags.system_flags & this.system_flags) != paramFlags.system_flags) {}
    do
    {
      return false;
      if (paramFlags.user_flags == null) {
        break;
      }
    } while (this.user_flags == null);
    paramFlags = paramFlags.user_flags.keys();
    do
    {
      if (!paramFlags.hasMoreElements()) {
        return true;
      }
    } while (this.user_flags.containsKey(paramFlags.nextElement()));
    return false;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof Flags)) {}
    do
    {
      do
      {
        return false;
        paramObject = (Flags)paramObject;
      } while (((Flags)paramObject).system_flags != this.system_flags);
      if ((((Flags)paramObject).user_flags == null) && (this.user_flags == null)) {
        return true;
      }
    } while ((((Flags)paramObject).user_flags == null) || (this.user_flags == null) || (((Flags)paramObject).user_flags.size() != this.user_flags.size()));
    paramObject = ((Flags)paramObject).user_flags.keys();
    do
    {
      if (!((Enumeration)paramObject).hasMoreElements()) {
        return true;
      }
    } while (this.user_flags.containsKey(((Enumeration)paramObject).nextElement()));
    return false;
  }
  
  public Flag[] getSystemFlags()
  {
    Vector localVector = new Vector();
    if ((this.system_flags & 0x1) != 0) {
      localVector.addElement(Flag.ANSWERED);
    }
    if ((this.system_flags & 0x2) != 0) {
      localVector.addElement(Flag.DELETED);
    }
    if ((this.system_flags & 0x4) != 0) {
      localVector.addElement(Flag.DRAFT);
    }
    if ((this.system_flags & 0x8) != 0) {
      localVector.addElement(Flag.FLAGGED);
    }
    if ((this.system_flags & 0x10) != 0) {
      localVector.addElement(Flag.RECENT);
    }
    if ((this.system_flags & 0x20) != 0) {
      localVector.addElement(Flag.SEEN);
    }
    if ((this.system_flags & 0x80000000) != 0) {
      localVector.addElement(Flag.USER);
    }
    Flag[] arrayOfFlag = new Flag[localVector.size()];
    localVector.copyInto(arrayOfFlag);
    return arrayOfFlag;
  }
  
  public String[] getUserFlags()
  {
    Vector localVector = new Vector();
    Object localObject;
    if (this.user_flags != null) {
      localObject = this.user_flags.elements();
    }
    for (;;)
    {
      if (!((Enumeration)localObject).hasMoreElements())
      {
        localObject = new String[localVector.size()];
        localVector.copyInto((Object[])localObject);
        return (String[])localObject;
      }
      localVector.addElement(((Enumeration)localObject).nextElement());
    }
  }
  
  public int hashCode()
  {
    int i = this.system_flags;
    int j = i;
    Enumeration localEnumeration;
    if (this.user_flags != null) {
      localEnumeration = this.user_flags.keys();
    }
    for (;;)
    {
      if (!localEnumeration.hasMoreElements())
      {
        j = i;
        return j;
      }
      i += ((String)localEnumeration.nextElement()).hashCode();
    }
  }
  
  public void remove(String paramString)
  {
    if (this.user_flags != null) {
      this.user_flags.remove(paramString.toLowerCase(Locale.ENGLISH));
    }
  }
  
  public void remove(Flag paramFlag)
  {
    this.system_flags &= (paramFlag.bit ^ 0xFFFFFFFF);
  }
  
  public void remove(Flags paramFlags)
  {
    this.system_flags &= (paramFlags.system_flags ^ 0xFFFFFFFF);
    if ((paramFlags.user_flags == null) || (this.user_flags == null)) {}
    for (;;)
    {
      return;
      paramFlags = paramFlags.user_flags.keys();
      while (paramFlags.hasMoreElements()) {
        this.user_flags.remove(paramFlags.nextElement());
      }
    }
  }
  
  public static final class Flag
  {
    public static final Flag ANSWERED = new Flag(1);
    public static final Flag DELETED = new Flag(2);
    public static final Flag DRAFT = new Flag(4);
    public static final Flag FLAGGED = new Flag(8);
    public static final Flag RECENT = new Flag(16);
    public static final Flag SEEN = new Flag(32);
    public static final Flag USER = new Flag(Integer.MIN_VALUE);
    private int bit;
    
    private Flag(int paramInt)
    {
      this.bit = paramInt;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/Flags.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */