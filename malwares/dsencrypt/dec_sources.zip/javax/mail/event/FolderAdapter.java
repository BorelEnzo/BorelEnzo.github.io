package javax.mail.event;

public abstract class FolderAdapter
  implements FolderListener
{
  public void folderCreated(FolderEvent paramFolderEvent) {}
  
  public void folderDeleted(FolderEvent paramFolderEvent) {}
  
  public void folderRenamed(FolderEvent paramFolderEvent) {}
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/event/FolderAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */