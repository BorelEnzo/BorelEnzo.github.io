package javax.mail.event;

import java.util.EventListener;

public abstract interface MessageChangedListener
  extends EventListener
{
  public abstract void messageChanged(MessageChangedEvent paramMessageChangedEvent);
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/event/MessageChangedListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */