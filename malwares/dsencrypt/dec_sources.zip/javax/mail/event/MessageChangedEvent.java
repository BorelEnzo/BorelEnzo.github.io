package javax.mail.event;

import javax.mail.Message;

public class MessageChangedEvent
  extends MailEvent
{
  public static final int ENVELOPE_CHANGED = 2;
  public static final int FLAGS_CHANGED = 1;
  private static final long serialVersionUID = -4974972972105535108L;
  protected transient Message msg;
  protected int type;
  
  public MessageChangedEvent(Object paramObject, int paramInt, Message paramMessage)
  {
    super(paramObject);
    this.msg = paramMessage;
    this.type = paramInt;
  }
  
  public void dispatch(Object paramObject)
  {
    ((MessageChangedListener)paramObject).messageChanged(this);
  }
  
  public Message getMessage()
  {
    return this.msg;
  }
  
  public int getMessageChangeType()
  {
    return this.type;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/event/MessageChangedEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */