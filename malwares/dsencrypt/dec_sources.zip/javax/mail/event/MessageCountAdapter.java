package javax.mail.event;

public abstract class MessageCountAdapter
  implements MessageCountListener
{
  public void messagesAdded(MessageCountEvent paramMessageCountEvent) {}
  
  public void messagesRemoved(MessageCountEvent paramMessageCountEvent) {}
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/event/MessageCountAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */