package javax.mail.event;

import java.util.EventListener;

public abstract interface StoreListener
  extends EventListener
{
  public abstract void notification(StoreEvent paramStoreEvent);
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/event/StoreListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */