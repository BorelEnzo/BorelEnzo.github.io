package javax.mail.event;

import java.util.EventListener;

public abstract interface MessageCountListener
  extends EventListener
{
  public abstract void messagesAdded(MessageCountEvent paramMessageCountEvent);
  
  public abstract void messagesRemoved(MessageCountEvent paramMessageCountEvent);
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/event/MessageCountListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */