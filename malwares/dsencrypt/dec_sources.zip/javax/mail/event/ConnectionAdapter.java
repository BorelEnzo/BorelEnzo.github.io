package javax.mail.event;

public abstract class ConnectionAdapter
  implements ConnectionListener
{
  public void closed(ConnectionEvent paramConnectionEvent) {}
  
  public void disconnected(ConnectionEvent paramConnectionEvent) {}
  
  public void opened(ConnectionEvent paramConnectionEvent) {}
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/event/ConnectionAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */