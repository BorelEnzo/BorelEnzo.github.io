package javax.mail.event;

import java.util.EventListener;

public abstract interface FolderListener
  extends EventListener
{
  public abstract void folderCreated(FolderEvent paramFolderEvent);
  
  public abstract void folderDeleted(FolderEvent paramFolderEvent);
  
  public abstract void folderRenamed(FolderEvent paramFolderEvent);
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/event/FolderListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */