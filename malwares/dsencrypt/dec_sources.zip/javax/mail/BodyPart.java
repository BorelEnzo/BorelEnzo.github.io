package javax.mail;

public abstract class BodyPart
  implements Part
{
  protected Multipart parent;
  
  public Multipart getParent()
  {
    return this.parent;
  }
  
  void setParent(Multipart paramMultipart)
  {
    this.parent = paramMultipart;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/BodyPart.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */