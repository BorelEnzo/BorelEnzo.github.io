package javax.mail;

import java.util.Vector;
import javax.mail.event.MailEvent;

class EventQueue
  implements Runnable
{
  private QueueElement head = null;
  private Thread qThread = new Thread(this, "JavaMail-EventQueue");
  private QueueElement tail = null;
  
  public EventQueue()
  {
    this.qThread.setDaemon(true);
    this.qThread.start();
  }
  
  private QueueElement dequeue()
    throws InterruptedException
  {
    for (;;)
    {
      try
      {
        if (this.tail != null)
        {
          QueueElement localQueueElement = this.tail;
          this.tail = localQueueElement.prev;
          if (this.tail == null)
          {
            this.head = null;
            localQueueElement.next = null;
            localQueueElement.prev = null;
            return localQueueElement;
          }
        }
        else
        {
          wait();
          continue;
        }
        this.tail.next = null;
      }
      finally {}
    }
  }
  
  /* Error */
  public void enqueue(MailEvent paramMailEvent, Vector paramVector)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new 8	javax/mail/EventQueue$QueueElement
    //   5: dup
    //   6: aload_1
    //   7: aload_2
    //   8: invokespecial 57	javax/mail/EventQueue$QueueElement:<init>	(Ljavax/mail/event/MailEvent;Ljava/util/Vector;)V
    //   11: astore_1
    //   12: aload_0
    //   13: getfield 20	javax/mail/EventQueue:head	Ljavax/mail/EventQueue$QueueElement;
    //   16: ifnonnull +20 -> 36
    //   19: aload_0
    //   20: aload_1
    //   21: putfield 20	javax/mail/EventQueue:head	Ljavax/mail/EventQueue$QueueElement;
    //   24: aload_0
    //   25: aload_1
    //   26: putfield 22	javax/mail/EventQueue:tail	Ljavax/mail/EventQueue$QueueElement;
    //   29: aload_0
    //   30: invokevirtual 60	java/lang/Object:notifyAll	()V
    //   33: aload_0
    //   34: monitorexit
    //   35: return
    //   36: aload_1
    //   37: aload_0
    //   38: getfield 20	javax/mail/EventQueue:head	Ljavax/mail/EventQueue$QueueElement;
    //   41: putfield 49	javax/mail/EventQueue$QueueElement:next	Ljavax/mail/EventQueue$QueueElement;
    //   44: aload_0
    //   45: getfield 20	javax/mail/EventQueue:head	Ljavax/mail/EventQueue$QueueElement;
    //   48: aload_1
    //   49: putfield 46	javax/mail/EventQueue$QueueElement:prev	Ljavax/mail/EventQueue$QueueElement;
    //   52: aload_0
    //   53: aload_1
    //   54: putfield 20	javax/mail/EventQueue:head	Ljavax/mail/EventQueue$QueueElement;
    //   57: goto -28 -> 29
    //   60: astore_1
    //   61: aload_0
    //   62: monitorexit
    //   63: aload_1
    //   64: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	65	0	this	EventQueue
    //   0	65	1	paramMailEvent	MailEvent
    //   0	65	2	paramVector	Vector
    // Exception table:
    //   from	to	target	type
    //   2	29	60	finally
    //   29	33	60	finally
    //   36	57	60	finally
  }
  
  public void run()
  {
    try
    {
      Object localObject = dequeue();
      if (localObject == null) {
        return;
      }
      MailEvent localMailEvent = ((QueueElement)localObject).event;
      localObject = ((QueueElement)localObject).vector;
      int i = 0;
      for (;;)
      {
        int j = ((Vector)localObject).size();
        if (i >= j) {
          break;
        }
        try
        {
          localMailEvent.dispatch(((Vector)localObject).elementAt(i));
          i += 1;
        }
        catch (Throwable localThrowable)
        {
          boolean bool;
          do
          {
            bool = localThrowable instanceof InterruptedException;
          } while (!bool);
          return;
        }
      }
      return;
    }
    catch (InterruptedException localInterruptedException) {}
  }
  
  void stop()
  {
    if (this.qThread != null)
    {
      this.qThread.interrupt();
      this.qThread = null;
    }
  }
  
  static class QueueElement
  {
    MailEvent event = null;
    QueueElement next = null;
    QueueElement prev = null;
    Vector vector = null;
    
    QueueElement(MailEvent paramMailEvent, Vector paramVector)
    {
      this.event = paramMailEvent;
      this.vector = paramVector;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/EventQueue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */