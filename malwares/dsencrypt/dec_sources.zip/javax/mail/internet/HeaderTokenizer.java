package javax.mail.internet;

public class HeaderTokenizer
{
  private static final Token EOFToken = new Token(-4, null);
  public static final String MIME = "()<>@,;:\\\"\t []/?=";
  public static final String RFC822 = "()<>@,;:\\\"\t .[]";
  private int currentPos;
  private String delimiters;
  private int maxPos;
  private int nextPos;
  private int peekPos;
  private boolean skipComments;
  private String string;
  
  public HeaderTokenizer(String paramString)
  {
    this(paramString, "()<>@,;:\\\"\t .[]");
  }
  
  public HeaderTokenizer(String paramString1, String paramString2)
  {
    this(paramString1, paramString2, true);
  }
  
  public HeaderTokenizer(String paramString1, String paramString2, boolean paramBoolean)
  {
    String str = paramString1;
    if (paramString1 == null) {
      str = "";
    }
    this.string = str;
    this.skipComments = paramBoolean;
    this.delimiters = paramString2;
    this.peekPos = 0;
    this.nextPos = 0;
    this.currentPos = 0;
    this.maxPos = this.string.length();
  }
  
  private static String filterToken(String paramString, int paramInt1, int paramInt2)
  {
    StringBuffer localStringBuffer = new StringBuffer();
    int i = 0;
    int k = 0;
    int j = paramInt1;
    paramInt1 = k;
    if (j >= paramInt2) {
      return localStringBuffer.toString();
    }
    char c = paramString.charAt(j);
    if ((c == '\n') && (paramInt1 != 0)) {
      paramInt1 = 0;
    }
    for (;;)
    {
      j += 1;
      break;
      paramInt1 = 0;
      if (i == 0)
      {
        if (c == '\\') {
          i = 1;
        } else if (c == '\r') {
          paramInt1 = 1;
        } else {
          localStringBuffer.append(c);
        }
      }
      else
      {
        localStringBuffer.append(c);
        i = 0;
      }
    }
  }
  
  private Token getNext()
    throws ParseException
  {
    if (this.currentPos >= this.maxPos) {
      return EOFToken;
    }
    if (skipWhiteSpace() == -4) {
      return EOFToken;
    }
    int j = 0;
    int i = this.string.charAt(this.currentPos);
    int m;
    int k;
    for (;;)
    {
      if (i != 40)
      {
        if (i != 34) {
          break label476;
        }
        m = this.currentPos + 1;
        this.currentPos = m;
        k = j;
        if (this.currentPos < this.maxPos) {
          break;
        }
        throw new ParseException("Unbalanced quoted string");
      }
      int i1 = this.currentPos + 1;
      this.currentPos = i1;
      m = 1;
      n = j;
      if ((m <= 0) || (this.currentPos >= this.maxPos))
      {
        if (m != 0) {
          throw new ParseException("Unbalanced comments");
        }
      }
      else
      {
        int i2 = this.string.charAt(this.currentPos);
        if (i2 == 92)
        {
          this.currentPos += 1;
          j = 1;
          k = m;
        }
        for (;;)
        {
          this.currentPos += 1;
          n = j;
          m = k;
          break;
          if (i2 == 13)
          {
            j = 1;
            k = m;
          }
          else if (i2 == 40)
          {
            k = m + 1;
            j = n;
          }
          else
          {
            j = n;
            k = m;
            if (i2 == 41)
            {
              k = m - 1;
              j = n;
            }
          }
        }
      }
      if (!this.skipComments)
      {
        if (n != 0) {}
        for (str = filterToken(this.string, i1, this.currentPos - 1);; str = this.string.substring(i1, this.currentPos - 1)) {
          return new Token(-3, str);
        }
      }
      if (skipWhiteSpace() == -4) {
        return EOFToken;
      }
      i = this.string.charAt(this.currentPos);
      j = n;
    }
    int n = this.string.charAt(this.currentPos);
    if (n == 92)
    {
      this.currentPos += 1;
      j = 1;
    }
    label404:
    do
    {
      for (;;)
      {
        this.currentPos += 1;
        k = j;
        break;
        if (n != 13) {
          break label404;
        }
        j = 1;
      }
      j = k;
    } while (n != 34);
    this.currentPos += 1;
    if (k != 0) {}
    for (String str = filterToken(this.string, m, this.currentPos - 1);; str = this.string.substring(m, this.currentPos - 1)) {
      return new Token(-2, str);
    }
    label476:
    if ((i < 32) || (i >= 127) || (this.delimiters.indexOf(i) >= 0))
    {
      this.currentPos += 1;
      return new Token(i, new String(new char[] { i }));
    }
    j = this.currentPos;
    for (;;)
    {
      if (this.currentPos >= this.maxPos) {}
      do
      {
        return new Token(-1, this.string.substring(j, this.currentPos));
        k = this.string.charAt(this.currentPos);
      } while ((k < 32) || (k >= 127) || (k == 40) || (k == 32) || (k == 34) || (this.delimiters.indexOf(k) >= 0));
      this.currentPos += 1;
    }
  }
  
  private int skipWhiteSpace()
  {
    for (;;)
    {
      if (this.currentPos >= this.maxPos) {
        return -4;
      }
      int i = this.string.charAt(this.currentPos);
      if ((i != 32) && (i != 9) && (i != 13) && (i != 10)) {
        return this.currentPos;
      }
      this.currentPos += 1;
    }
  }
  
  public String getRemainder()
  {
    return this.string.substring(this.nextPos);
  }
  
  public Token next()
    throws ParseException
  {
    this.currentPos = this.nextPos;
    Token localToken = getNext();
    int i = this.currentPos;
    this.peekPos = i;
    this.nextPos = i;
    return localToken;
  }
  
  public Token peek()
    throws ParseException
  {
    this.currentPos = this.peekPos;
    Token localToken = getNext();
    this.peekPos = this.currentPos;
    return localToken;
  }
  
  public static class Token
  {
    public static final int ATOM = -1;
    public static final int COMMENT = -3;
    public static final int EOF = -4;
    public static final int QUOTEDSTRING = -2;
    private int type;
    private String value;
    
    public Token(int paramInt, String paramString)
    {
      this.type = paramInt;
      this.value = paramString;
    }
    
    public int getType()
    {
      return this.type;
    }
    
    public String getValue()
    {
      return this.value;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/internet/HeaderTokenizer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */