package javax.mail.internet;

import java.text.ParseException;

class MailDateParser
{
  int index = 0;
  char[] orig = null;
  
  public MailDateParser(char[] paramArrayOfChar)
  {
    this.orig = paramArrayOfChar;
  }
  
  int getIndex()
  {
    return this.index;
  }
  
  public int parseAlphaTimeZone()
    throws ParseException
  {
    int j = 0;
    try
    {
      char[] arrayOfChar1 = this.orig;
      i = this.index;
      this.index = (i + 1);
      switch (arrayOfChar1[i])
      {
      case 'U': 
        throw new ParseException("Bad Alpha TimeZone", this.index);
      }
    }
    catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException)
    {
      throw new ParseException("Bad Alpha TimeZone", this.index);
    }
    char[] arrayOfChar2 = this.orig;
    int i = this.index;
    this.index = (i + 1);
    i = arrayOfChar2[i];
    if ((i == 84) || (i == 116)) {
      i = 0;
    }
    for (;;)
    {
      int k = i;
      if (j != 0)
      {
        arrayOfChar2 = this.orig;
        j = this.index;
        this.index = (j + 1);
        j = arrayOfChar2[j];
        if ((j == 83) || (j == 115))
        {
          arrayOfChar2 = this.orig;
          j = this.index;
          this.index = (j + 1);
          j = arrayOfChar2[j];
          k = i;
          if (j != 84)
          {
            k = i;
            if (j != 116)
            {
              throw new ParseException("Bad Alpha TimeZone", this.index);
              throw new ParseException("Bad Alpha TimeZone", this.index);
              arrayOfChar2 = this.orig;
              i = this.index;
              this.index = (i + 1);
              i = arrayOfChar2[i];
              if ((i == 77) || (i == 109))
              {
                arrayOfChar2 = this.orig;
                i = this.index;
                this.index = (i + 1);
                i = arrayOfChar2[i];
                if ((i == 84) || (i == 116)) {
                  break label503;
                }
              }
              throw new ParseException("Bad Alpha TimeZone", this.index);
              i = 300;
              j = 1;
              continue;
              i = 360;
              j = 1;
              continue;
              i = 420;
              j = 1;
              continue;
              i = 480;
              j = 1;
            }
          }
        }
        else if (j != 68)
        {
          k = i;
          if (j != 100) {}
        }
        else
        {
          arrayOfChar2 = this.orig;
          j = this.index;
          this.index = (j + 1);
          j = arrayOfChar2[j];
          if ((j != 84) && (j == 116)) {
            break label486;
          }
          k = i - 60;
        }
      }
      return k;
      label486:
      throw new ParseException("Bad Alpha TimeZone", this.index);
      break;
      label503:
      i = 0;
    }
  }
  
  public int parseMonth()
    throws ParseException
  {
    int i;
    for (;;)
    {
      try
      {
        arrayOfChar = this.orig;
        i = this.index;
        this.index = (i + 1);
        i = arrayOfChar[i];
        switch (i)
        {
        }
      }
      catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException)
      {
        char[] arrayOfChar;
        continue;
        continue;
      }
      throw new ParseException("Bad Month", this.index);
      arrayOfChar = this.orig;
      i = this.index;
      this.index = (i + 1);
      switch (arrayOfChar[i])
      {
      case 'A': 
      case 'a': 
        arrayOfChar = this.orig;
        i = this.index;
        this.index = (i + 1);
        i = arrayOfChar[i];
        if (i == 78) {
          break label834;
        }
        if (i != 110) {}
        break;
      case 'U': 
      case 'u': 
        arrayOfChar = this.orig;
        i = this.index;
        this.index = (i + 1);
        i = arrayOfChar[i];
        if (i == 78) {
          break label836;
        }
        if (i != 110) {
          break label838;
        }
        break label836;
        arrayOfChar = this.orig;
        i = this.index;
        this.index = (i + 1);
        i = arrayOfChar[i];
        if ((i == 69) || (i == 101))
        {
          arrayOfChar = this.orig;
          i = this.index;
          this.index = (i + 1);
          i = arrayOfChar[i];
          if (i == 66) {
            break label853;
          }
          if (i == 98)
          {
            break label853;
            arrayOfChar = this.orig;
            i = this.index;
            this.index = (i + 1);
            i = arrayOfChar[i];
            if ((i == 65) || (i == 97))
            {
              arrayOfChar = this.orig;
              i = this.index;
              this.index = (i + 1);
              i = arrayOfChar[i];
              if (i == 82) {
                break label855;
              }
              if (i != 114) {
                break label857;
              }
              break label855;
              arrayOfChar = this.orig;
              i = this.index;
              this.index = (i + 1);
              i = arrayOfChar[i];
              if ((i != 80) && (i != 112)) {
                break label873;
              }
              arrayOfChar = this.orig;
              i = this.index;
              this.index = (i + 1);
              i = arrayOfChar[i];
              if (i == 82) {
                break label871;
              }
              if (i == 114) {
                break label871;
              }
            }
          }
        }
        break;
      }
    }
    for (;;)
    {
      arrayOfChar = this.orig;
      i = this.index;
      this.index = (i + 1);
      i = arrayOfChar[i];
      if (i == 71) {
        break label888;
      }
      if (i != 103) {
        break;
      }
      break label888;
      arrayOfChar = this.orig;
      i = this.index;
      this.index = (i + 1);
      i = arrayOfChar[i];
      if ((i != 69) && (i != 101)) {
        break;
      }
      arrayOfChar = this.orig;
      i = this.index;
      this.index = (i + 1);
      i = arrayOfChar[i];
      if (i == 80) {
        break label891;
      }
      if (i != 112) {
        break;
      }
      break label891;
      arrayOfChar = this.orig;
      i = this.index;
      this.index = (i + 1);
      i = arrayOfChar[i];
      if ((i != 67) && (i != 99)) {
        break;
      }
      arrayOfChar = this.orig;
      i = this.index;
      this.index = (i + 1);
      i = arrayOfChar[i];
      if (i == 84) {
        break label894;
      }
      if (i != 116) {
        break;
      }
      break label894;
      arrayOfChar = this.orig;
      i = this.index;
      this.index = (i + 1);
      i = arrayOfChar[i];
      if ((i != 79) && (i != 111)) {
        break;
      }
      arrayOfChar = this.orig;
      i = this.index;
      this.index = (i + 1);
      i = arrayOfChar[i];
      if (i == 86) {
        break label897;
      }
      if (i != 118) {
        break;
      }
      break label897;
      arrayOfChar = this.orig;
      i = this.index;
      this.index = (i + 1);
      i = arrayOfChar[i];
      if ((i != 69) && (i != 101)) {
        break;
      }
      arrayOfChar = this.orig;
      i = this.index;
      this.index = (i + 1);
      i = arrayOfChar[i];
      if ((i != 67) && (i != 99)) {
        break;
      }
      return 11;
      label834:
      return 0;
      label836:
      return 5;
      label838:
      if ((i != 76) && (i != 108)) {
        break;
      }
      return 6;
      label853:
      return 1;
      label855:
      return 2;
      label857:
      if ((i != 89) && (i != 121)) {
        break;
      }
      return 4;
      label871:
      return 3;
      label873:
      if (i != 85) {
        if (i != 117) {
          break;
        }
      }
    }
    label888:
    return 7;
    label891:
    return 8;
    label894:
    return 9;
    label897:
    return 10;
  }
  
  public int parseNumber()
    throws ParseException
  {
    int k = this.orig.length;
    int j = 0;
    int i = 0;
    if (this.index >= k)
    {
      if (j == 0) {}
    }
    else
    {
      do
      {
        return i;
        switch (this.orig[this.index])
        {
        }
      } while (j != 0);
      throw new ParseException("No Number found", this.index);
      i *= 10;
      for (;;)
      {
        j = 1;
        this.index += 1;
        break;
        i = i * 10 + 1;
        continue;
        i = i * 10 + 2;
        continue;
        i = i * 10 + 3;
        continue;
        i = i * 10 + 4;
        continue;
        i = i * 10 + 5;
        continue;
        i = i * 10 + 6;
        continue;
        i = i * 10 + 7;
        continue;
        i = i * 10 + 8;
        continue;
        i = i * 10 + 9;
      }
    }
    throw new ParseException("No Number found", this.index);
  }
  
  public int parseNumericTimeZone()
    throws ParseException
  {
    int i = 0;
    char[] arrayOfChar = this.orig;
    int j = this.index;
    this.index = (j + 1);
    j = arrayOfChar[j];
    if (j == 43) {
      i = 1;
    }
    while (j == 45)
    {
      j = parseNumber();
      int k = j / 100 * 60 + j % 100;
      j = k;
      if (i != 0) {
        j = -k;
      }
      return j;
    }
    throw new ParseException("Bad Numeric TimeZone", this.index);
  }
  
  public int parseTimeZone()
    throws ParseException
  {
    if (this.index >= this.orig.length) {
      throw new ParseException("No more characters", this.index);
    }
    int i = this.orig[this.index];
    if ((i == 43) || (i == 45)) {
      return parseNumericTimeZone();
    }
    return parseAlphaTimeZone();
  }
  
  public int peekChar()
    throws ParseException
  {
    if (this.index < this.orig.length) {
      return this.orig[this.index];
    }
    throw new ParseException("No more characters", this.index);
  }
  
  public void skipChar(char paramChar)
    throws ParseException
  {
    if (this.index < this.orig.length)
    {
      if (this.orig[this.index] == paramChar)
      {
        this.index += 1;
        return;
      }
      throw new ParseException("Wrong char", this.index);
    }
    throw new ParseException("No more characters", this.index);
  }
  
  public boolean skipIfChar(char paramChar)
    throws ParseException
  {
    if (this.index < this.orig.length)
    {
      if (this.orig[this.index] == paramChar)
      {
        this.index += 1;
        return true;
      }
      return false;
    }
    throw new ParseException("No more characters", this.index);
  }
  
  public void skipUntilNumber()
    throws ParseException
  {
    for (;;)
    {
      try
      {
        switch (this.orig[this.index])
        {
        case '0': 
          this.index += 1;
          break;
        case '1': 
        case '2': 
        case '3': 
        case '4': 
        case '5': 
        case '6': 
        case '7': 
        case '8': 
        case '9': 
          return;
        }
      }
      catch (ArrayIndexOutOfBoundsException localArrayIndexOutOfBoundsException)
      {
        throw new ParseException("No Number Found", this.index);
      }
    }
  }
  
  public void skipWhiteSpace()
  {
    int i = this.orig.length;
    for (;;)
    {
      if (this.index >= i) {
        return;
      }
      switch (this.orig[this.index])
      {
      default: 
        return;
      }
      this.index += 1;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/internet/MailDateParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */