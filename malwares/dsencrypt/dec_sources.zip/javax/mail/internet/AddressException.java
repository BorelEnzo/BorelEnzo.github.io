package javax.mail.internet;

public class AddressException
  extends ParseException
{
  private static final long serialVersionUID = 9134583443539323120L;
  protected int pos = -1;
  protected String ref = null;
  
  public AddressException() {}
  
  public AddressException(String paramString)
  {
    super(paramString);
  }
  
  public AddressException(String paramString1, String paramString2)
  {
    super(paramString1);
    this.ref = paramString2;
  }
  
  public AddressException(String paramString1, String paramString2, int paramInt)
  {
    super(paramString1);
    this.ref = paramString2;
    this.pos = paramInt;
  }
  
  public int getPos()
  {
    return this.pos;
  }
  
  public String getRef()
  {
    return this.ref;
  }
  
  public String toString()
  {
    String str = super.toString();
    if (this.ref == null) {
      return str;
    }
    str = str + " in string ``" + this.ref + "''";
    if (this.pos < 0) {
      return str;
    }
    return str + " at position " + this.pos;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/internet/AddressException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */