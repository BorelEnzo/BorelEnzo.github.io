package javax.mail.internet;

import javax.mail.Session;

class UniqueValue
{
  private static int id = 0;
  
  public static String getUniqueBoundaryValue()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append("----=_Part_").append(getUniqueId()).append("_").append(localStringBuffer.hashCode()).append('.').append(System.currentTimeMillis());
    return localStringBuffer.toString();
  }
  
  private static int getUniqueId()
  {
    try
    {
      int i = id;
      id = i + 1;
      return i;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public static String getUniqueMessageIDValue(Session paramSession)
  {
    paramSession = InternetAddress.getLocalAddress(paramSession);
    if (paramSession != null) {}
    for (paramSession = paramSession.getAddress();; paramSession = "javamailuser@localhost")
    {
      StringBuffer localStringBuffer = new StringBuffer();
      localStringBuffer.append(localStringBuffer.hashCode()).append('.').append(getUniqueId()).append('.').append(System.currentTimeMillis()).append('.').append("JavaMail.").append(paramSession);
      return localStringBuffer.toString();
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/internet/UniqueValue.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */