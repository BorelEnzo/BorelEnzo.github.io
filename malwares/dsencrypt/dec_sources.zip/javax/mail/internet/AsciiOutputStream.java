package javax.mail.internet;

import java.io.EOFException;
import java.io.IOException;
import java.io.OutputStream;

class AsciiOutputStream
  extends OutputStream
{
  private int ascii = 0;
  private boolean badEOL = false;
  private boolean breakOnNonAscii;
  private boolean checkEOL = false;
  private int lastb = 0;
  private int linelen = 0;
  private boolean longLine = false;
  private int non_ascii = 0;
  private int ret = 0;
  
  public AsciiOutputStream(boolean paramBoolean1, boolean paramBoolean2)
  {
    this.breakOnNonAscii = paramBoolean1;
    boolean bool1 = bool2;
    if (paramBoolean2)
    {
      bool1 = bool2;
      if (paramBoolean1) {
        bool1 = true;
      }
    }
    this.checkEOL = bool1;
  }
  
  private final void check(int paramInt)
    throws IOException
  {
    paramInt &= 0xFF;
    if ((this.checkEOL) && (((this.lastb == 13) && (paramInt != 10)) || ((this.lastb != 13) && (paramInt == 10)))) {
      this.badEOL = true;
    }
    if ((paramInt == 13) || (paramInt == 10)) {
      this.linelen = 0;
    }
    while (MimeUtility.nonascii(paramInt))
    {
      this.non_ascii += 1;
      if (!this.breakOnNonAscii) {
        break label140;
      }
      this.ret = 3;
      throw new EOFException();
      this.linelen += 1;
      if (this.linelen > 998) {
        this.longLine = true;
      }
    }
    this.ascii += 1;
    label140:
    this.lastb = paramInt;
  }
  
  public int getAscii()
  {
    int j = 3;
    int i;
    if (this.ret != 0) {
      i = this.ret;
    }
    do
    {
      do
      {
        return i;
        i = j;
      } while (this.badEOL);
      if (this.non_ascii == 0)
      {
        if (this.longLine) {
          return 2;
        }
        return 1;
      }
      i = j;
    } while (this.ascii <= this.non_ascii);
    return 2;
  }
  
  public void write(int paramInt)
    throws IOException
  {
    check(paramInt);
  }
  
  public void write(byte[] paramArrayOfByte)
    throws IOException
  {
    write(paramArrayOfByte, 0, paramArrayOfByte.length);
  }
  
  public void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    int i = paramInt1;
    for (;;)
    {
      if (i >= paramInt2 + paramInt1) {
        return;
      }
      check(paramArrayOfByte[i]);
      i += 1;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/internet/AsciiOutputStream.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */