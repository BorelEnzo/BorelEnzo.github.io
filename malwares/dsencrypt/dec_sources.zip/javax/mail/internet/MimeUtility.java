package javax.mail.internet;

import com.sun.mail.util.ASCIIUtility;
import com.sun.mail.util.BASE64DecoderStream;
import com.sun.mail.util.BASE64EncoderStream;
import com.sun.mail.util.BEncoderStream;
import com.sun.mail.util.LineInputStream;
import com.sun.mail.util.QDecoderStream;
import com.sun.mail.util.QEncoderStream;
import com.sun.mail.util.QPDecoderStream;
import com.sun.mail.util.QPEncoderStream;
import com.sun.mail.util.UUDecoderStream;
import com.sun.mail.util.UUEncoderStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Hashtable;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;
import javax.mail.MessagingException;

public class MimeUtility
{
  public static final int ALL = -1;
  static final int ALL_ASCII = 1;
  static final int MOSTLY_ASCII = 2;
  static final int MOSTLY_NONASCII = 3;
  private static boolean decodeStrict;
  private static String defaultJavaCharset;
  private static String defaultMIMECharset;
  private static boolean encodeEolStrict;
  private static boolean foldEncodedWords;
  private static boolean foldText;
  private static Hashtable java2mime;
  private static Hashtable mime2java;
  
  /* Error */
  static
  {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: iconst_1
    //   3: putstatic 35	javax/mail/internet/MimeUtility:decodeStrict	Z
    //   6: iconst_0
    //   7: putstatic 37	javax/mail/internet/MimeUtility:encodeEolStrict	Z
    //   10: iconst_0
    //   11: putstatic 39	javax/mail/internet/MimeUtility:foldEncodedWords	Z
    //   14: iconst_1
    //   15: putstatic 41	javax/mail/internet/MimeUtility:foldText	Z
    //   18: ldc 43
    //   20: invokestatic 49	java/lang/System:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   23: astore_2
    //   24: aload_2
    //   25: ifnull +680 -> 705
    //   28: aload_2
    //   29: ldc 51
    //   31: invokevirtual 57	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   34: ifeq +671 -> 705
    //   37: iconst_0
    //   38: istore_0
    //   39: iload_0
    //   40: putstatic 35	javax/mail/internet/MimeUtility:decodeStrict	Z
    //   43: ldc 59
    //   45: invokestatic 49	java/lang/System:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   48: astore_2
    //   49: aload_2
    //   50: ifnull +660 -> 710
    //   53: aload_2
    //   54: ldc 61
    //   56: invokevirtual 57	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   59: ifeq +651 -> 710
    //   62: iconst_1
    //   63: istore_0
    //   64: iload_0
    //   65: putstatic 37	javax/mail/internet/MimeUtility:encodeEolStrict	Z
    //   68: ldc 63
    //   70: invokestatic 49	java/lang/System:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   73: astore_2
    //   74: aload_2
    //   75: ifnull +640 -> 715
    //   78: aload_2
    //   79: ldc 61
    //   81: invokevirtual 57	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   84: ifeq +631 -> 715
    //   87: iconst_1
    //   88: istore_0
    //   89: iload_0
    //   90: putstatic 39	javax/mail/internet/MimeUtility:foldEncodedWords	Z
    //   93: ldc 65
    //   95: invokestatic 49	java/lang/System:getProperty	(Ljava/lang/String;)Ljava/lang/String;
    //   98: astore_2
    //   99: aload_2
    //   100: ifnull +620 -> 720
    //   103: aload_2
    //   104: ldc 51
    //   106: invokevirtual 57	java/lang/String:equalsIgnoreCase	(Ljava/lang/String;)Z
    //   109: ifeq +611 -> 720
    //   112: iload_1
    //   113: istore_0
    //   114: iload_0
    //   115: putstatic 41	javax/mail/internet/MimeUtility:foldText	Z
    //   118: new 67	java/util/Hashtable
    //   121: dup
    //   122: bipush 40
    //   124: invokespecial 71	java/util/Hashtable:<init>	(I)V
    //   127: putstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   130: new 67	java/util/Hashtable
    //   133: dup
    //   134: bipush 10
    //   136: invokespecial 71	java/util/Hashtable:<init>	(I)V
    //   139: putstatic 75	javax/mail/internet/MimeUtility:mime2java	Ljava/util/Hashtable;
    //   142: ldc 2
    //   144: ldc 77
    //   146: invokevirtual 83	java/lang/Class:getResourceAsStream	(Ljava/lang/String;)Ljava/io/InputStream;
    //   149: astore_2
    //   150: aload_2
    //   151: ifnull +40 -> 191
    //   154: new 85	com/sun/mail/util/LineInputStream
    //   157: dup
    //   158: aload_2
    //   159: invokespecial 88	com/sun/mail/util/LineInputStream:<init>	(Ljava/io/InputStream;)V
    //   162: astore 4
    //   164: aload 4
    //   166: checkcast 85	com/sun/mail/util/LineInputStream
    //   169: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   172: invokestatic 92	javax/mail/internet/MimeUtility:loadMappings	(Lcom/sun/mail/util/LineInputStream;Ljava/util/Hashtable;)V
    //   175: aload 4
    //   177: checkcast 85	com/sun/mail/util/LineInputStream
    //   180: getstatic 75	javax/mail/internet/MimeUtility:mime2java	Ljava/util/Hashtable;
    //   183: invokestatic 92	javax/mail/internet/MimeUtility:loadMappings	(Lcom/sun/mail/util/LineInputStream;Ljava/util/Hashtable;)V
    //   186: aload 4
    //   188: invokevirtual 97	java/io/InputStream:close	()V
    //   191: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   194: invokevirtual 101	java/util/Hashtable:isEmpty	()Z
    //   197: ifeq +388 -> 585
    //   200: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   203: ldc 103
    //   205: ldc 105
    //   207: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   210: pop
    //   211: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   214: ldc 111
    //   216: ldc 105
    //   218: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   221: pop
    //   222: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   225: ldc 113
    //   227: ldc 105
    //   229: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   232: pop
    //   233: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   236: ldc 115
    //   238: ldc 117
    //   240: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   243: pop
    //   244: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   247: ldc 119
    //   249: ldc 117
    //   251: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   254: pop
    //   255: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   258: ldc 121
    //   260: ldc 117
    //   262: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   265: pop
    //   266: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   269: ldc 123
    //   271: ldc 125
    //   273: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   276: pop
    //   277: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   280: ldc 127
    //   282: ldc 125
    //   284: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   287: pop
    //   288: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   291: ldc -127
    //   293: ldc 125
    //   295: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   298: pop
    //   299: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   302: ldc -125
    //   304: ldc -123
    //   306: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   309: pop
    //   310: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   313: ldc -121
    //   315: ldc -123
    //   317: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   320: pop
    //   321: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   324: ldc -119
    //   326: ldc -123
    //   328: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   331: pop
    //   332: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   335: ldc -117
    //   337: ldc -115
    //   339: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   342: pop
    //   343: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   346: ldc -113
    //   348: ldc -115
    //   350: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   353: pop
    //   354: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   357: ldc -111
    //   359: ldc -115
    //   361: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   364: pop
    //   365: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   368: ldc -109
    //   370: ldc -107
    //   372: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   375: pop
    //   376: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   379: ldc -105
    //   381: ldc -107
    //   383: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   386: pop
    //   387: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   390: ldc -103
    //   392: ldc -107
    //   394: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   397: pop
    //   398: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   401: ldc -101
    //   403: ldc -99
    //   405: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   408: pop
    //   409: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   412: ldc -97
    //   414: ldc -99
    //   416: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   419: pop
    //   420: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   423: ldc -95
    //   425: ldc -99
    //   427: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   430: pop
    //   431: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   434: ldc -93
    //   436: ldc -91
    //   438: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   441: pop
    //   442: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   445: ldc -89
    //   447: ldc -91
    //   449: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   452: pop
    //   453: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   456: ldc -87
    //   458: ldc -91
    //   460: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   463: pop
    //   464: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   467: ldc -85
    //   469: ldc -83
    //   471: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   474: pop
    //   475: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   478: ldc -81
    //   480: ldc -83
    //   482: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   485: pop
    //   486: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   489: ldc -79
    //   491: ldc -83
    //   493: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   496: pop
    //   497: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   500: ldc -77
    //   502: ldc -75
    //   504: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   507: pop
    //   508: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   511: ldc -73
    //   513: ldc -71
    //   515: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   518: pop
    //   519: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   522: ldc -69
    //   524: ldc -71
    //   526: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   529: pop
    //   530: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   533: ldc -67
    //   535: ldc -65
    //   537: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   540: pop
    //   541: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   544: ldc -63
    //   546: ldc -61
    //   548: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   551: pop
    //   552: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   555: ldc -59
    //   557: ldc -57
    //   559: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   562: pop
    //   563: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   566: ldc -55
    //   568: ldc -53
    //   570: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   573: pop
    //   574: getstatic 73	javax/mail/internet/MimeUtility:java2mime	Ljava/util/Hashtable;
    //   577: ldc -51
    //   579: ldc -49
    //   581: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   584: pop
    //   585: getstatic 75	javax/mail/internet/MimeUtility:mime2java	Ljava/util/Hashtable;
    //   588: invokevirtual 101	java/util/Hashtable:isEmpty	()Z
    //   591: ifeq +113 -> 704
    //   594: getstatic 75	javax/mail/internet/MimeUtility:mime2java	Ljava/util/Hashtable;
    //   597: ldc -47
    //   599: ldc -45
    //   601: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   604: pop
    //   605: getstatic 75	javax/mail/internet/MimeUtility:mime2java	Ljava/util/Hashtable;
    //   608: ldc -43
    //   610: ldc -41
    //   612: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   615: pop
    //   616: getstatic 75	javax/mail/internet/MimeUtility:mime2java	Ljava/util/Hashtable;
    //   619: ldc -39
    //   621: ldc -37
    //   623: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   626: pop
    //   627: getstatic 75	javax/mail/internet/MimeUtility:mime2java	Ljava/util/Hashtable;
    //   630: ldc -35
    //   632: ldc -37
    //   634: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   637: pop
    //   638: getstatic 75	javax/mail/internet/MimeUtility:mime2java	Ljava/util/Hashtable;
    //   641: ldc -33
    //   643: ldc -31
    //   645: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   648: pop
    //   649: getstatic 75	javax/mail/internet/MimeUtility:mime2java	Ljava/util/Hashtable;
    //   652: ldc -29
    //   654: ldc -27
    //   656: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   659: pop
    //   660: getstatic 75	javax/mail/internet/MimeUtility:mime2java	Ljava/util/Hashtable;
    //   663: ldc -49
    //   665: ldc -25
    //   667: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   670: pop
    //   671: getstatic 75	javax/mail/internet/MimeUtility:mime2java	Ljava/util/Hashtable;
    //   674: ldc -23
    //   676: ldc -25
    //   678: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   681: pop
    //   682: getstatic 75	javax/mail/internet/MimeUtility:mime2java	Ljava/util/Hashtable;
    //   685: ldc -21
    //   687: ldc 105
    //   689: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   692: pop
    //   693: getstatic 75	javax/mail/internet/MimeUtility:mime2java	Ljava/util/Hashtable;
    //   696: ldc -19
    //   698: ldc 105
    //   700: invokevirtual 109	java/util/Hashtable:put	(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   703: pop
    //   704: return
    //   705: iconst_1
    //   706: istore_0
    //   707: goto -668 -> 39
    //   710: iconst_0
    //   711: istore_0
    //   712: goto -648 -> 64
    //   715: iconst_0
    //   716: istore_0
    //   717: goto -628 -> 89
    //   720: iconst_1
    //   721: istore_0
    //   722: goto -608 -> 114
    //   725: astore_3
    //   726: aload_2
    //   727: invokevirtual 97	java/io/InputStream:close	()V
    //   730: aload_3
    //   731: athrow
    //   732: astore_2
    //   733: goto -542 -> 191
    //   736: astore_2
    //   737: goto -7 -> 730
    //   740: astore_2
    //   741: goto -550 -> 191
    //   744: astore_3
    //   745: aload 4
    //   747: astore_2
    //   748: goto -22 -> 726
    //   751: astore_2
    //   752: goto -634 -> 118
    // Local variable table:
    //   start	length	slot	name	signature
    //   38	684	0	bool1	boolean
    //   1	112	1	bool2	boolean
    //   23	704	2	localObject1	Object
    //   732	1	2	localException1	Exception
    //   736	1	2	localException2	Exception
    //   740	1	2	localException3	Exception
    //   747	1	2	localObject2	Object
    //   751	1	2	localSecurityException	SecurityException
    //   725	6	3	localObject3	Object
    //   744	1	3	localObject4	Object
    //   162	584	4	localLineInputStream	LineInputStream
    // Exception table:
    //   from	to	target	type
    //   154	164	725	finally
    //   142	150	732	java/lang/Exception
    //   730	732	732	java/lang/Exception
    //   726	730	736	java/lang/Exception
    //   186	191	740	java/lang/Exception
    //   164	186	744	finally
    //   18	24	751	java/lang/SecurityException
    //   28	37	751	java/lang/SecurityException
    //   39	49	751	java/lang/SecurityException
    //   53	62	751	java/lang/SecurityException
    //   64	74	751	java/lang/SecurityException
    //   78	87	751	java/lang/SecurityException
    //   89	99	751	java/lang/SecurityException
    //   103	112	751	java/lang/SecurityException
    //   114	118	751	java/lang/SecurityException
  }
  
  static int checkAscii(InputStream paramInputStream, int paramInt, boolean paramBoolean)
  {
    int n = 0;
    int i1 = 0;
    int i6 = 4096;
    int i2 = 0;
    int i3 = 0;
    int i4 = 0;
    int i5;
    byte[] arrayOfByte;
    int m;
    int i8;
    int i;
    int j;
    int i7;
    if ((encodeEolStrict) && (paramBoolean))
    {
      i5 = 1;
      arrayOfByte = (byte[])null;
      k = n;
      m = i4;
      i8 = i2;
      i = i3;
      j = i1;
      i7 = paramInt;
      if (paramInt != 0) {
        if (paramInt != -1) {
          break label144;
        }
      }
    }
    label127:
    label144:
    for (int k = 4096;; k = Math.min(paramInt, 4096))
    {
      arrayOfByte = new byte[k];
      i7 = paramInt;
      j = i1;
      i = i3;
      i8 = i2;
      i6 = k;
      m = i4;
      k = n;
      if (i7 != 0) {
        break label156;
      }
      i1 = j;
      i2 = i;
      i3 = m;
      i4 = k;
      if ((i7 != 0) || (!paramBoolean)) {
        break label339;
      }
      return 3;
      i5 = 0;
      break;
    }
    label156:
    i4 = k;
    i3 = m;
    i2 = i;
    i1 = j;
    for (;;)
    {
      int i9;
      try
      {
        i9 = paramInputStream.read(arrayOfByte, 0, i6);
        i4 = k;
        i3 = m;
        i2 = i;
        i1 = j;
        if (i9 == -1) {
          break label127;
        }
        i4 = 0;
        n = 0;
        paramInt = k;
        i1 = m;
        m = n;
        i3 = i8;
        i2 = i;
        n = j;
      }
      catch (IOException paramInputStream) {}
      i4 = paramInt;
      i3 = i;
      i2 = k;
      i1 = n;
      boolean bool = nonascii(i8);
      if (bool)
      {
        if (paramBoolean)
        {
          return 3;
          i1 = i3 + 1;
          j = i1;
          k = i2;
          if (i1 <= 998) {
            continue;
          }
          k = 1;
          j = i1;
          continue;
        }
        n += 1;
        i4 = i8;
        m += 1;
        i1 = i;
        i3 = j;
        i2 = k;
      }
      else
      {
        paramInt += 1;
        continue;
        break label127;
        label339:
        if (i1 == 0)
        {
          if (i3 != 0) {
            return 3;
          }
          if (i2 != 0) {
            return 2;
          }
          return 1;
        }
        if (i4 > i1) {
          return 2;
        }
        return 3;
      }
      if (m >= i9)
      {
        k = paramInt;
        m = i1;
        i8 = i3;
        i = i2;
        j = n;
        if (i7 == -1) {
          break;
        }
        i7 -= i9;
        k = paramInt;
        m = i1;
        i8 = i3;
        i = i2;
        j = n;
        break;
      }
      i8 = arrayOfByte[m] & 0xFF;
      i = i1;
      if (i5 != 0) {
        if ((i4 != 13) || (i8 == 10))
        {
          i = i1;
          if (i4 != 13)
          {
            i = i1;
            if (i8 != 10) {}
          }
        }
        else
        {
          i = 1;
        }
      }
      if ((i8 == 13) || (i8 == 10))
      {
        j = 0;
        k = i2;
      }
    }
  }
  
  static int checkAscii(String paramString)
  {
    int k = 0;
    int j = 0;
    int m = paramString.length();
    int i = 0;
    if (i >= m)
    {
      if (j == 0) {
        return 1;
      }
    }
    else
    {
      if (nonascii(paramString.charAt(i))) {
        j += 1;
      }
      for (;;)
      {
        i += 1;
        break;
        k += 1;
      }
    }
    if (k > j) {
      return 2;
    }
    return 3;
  }
  
  static int checkAscii(byte[] paramArrayOfByte)
  {
    int k = 0;
    int j = 0;
    int i = 0;
    if (i >= paramArrayOfByte.length)
    {
      if (j == 0) {
        return 1;
      }
    }
    else
    {
      if (nonascii(paramArrayOfByte[i] & 0xFF)) {
        j += 1;
      }
      for (;;)
      {
        i += 1;
        break;
        k += 1;
      }
    }
    if (k > j) {
      return 2;
    }
    return 3;
  }
  
  public static InputStream decode(InputStream paramInputStream, String paramString)
    throws MessagingException
  {
    Object localObject;
    if (paramString.equalsIgnoreCase("base64")) {
      localObject = new BASE64DecoderStream(paramInputStream);
    }
    do
    {
      do
      {
        do
        {
          return (InputStream)localObject;
          if (paramString.equalsIgnoreCase("quoted-printable")) {
            return new QPDecoderStream(paramInputStream);
          }
          if ((paramString.equalsIgnoreCase("uuencode")) || (paramString.equalsIgnoreCase("x-uuencode")) || (paramString.equalsIgnoreCase("x-uue"))) {
            return new UUDecoderStream(paramInputStream);
          }
          localObject = paramInputStream;
        } while (paramString.equalsIgnoreCase("binary"));
        localObject = paramInputStream;
      } while (paramString.equalsIgnoreCase("7bit"));
      localObject = paramInputStream;
    } while (paramString.equalsIgnoreCase("8bit"));
    throw new MessagingException("Unknown encoding: " + paramString);
  }
  
  private static String decodeInnerWords(String paramString)
    throws UnsupportedEncodingException
  {
    int i = 0;
    StringBuffer localStringBuffer = new StringBuffer();
    for (;;)
    {
      int j = paramString.indexOf("=?", i);
      if (j < 0) {}
      int k;
      do
      {
        do
        {
          do
          {
            if (i != 0) {
              break;
            }
            return paramString;
            localStringBuffer.append(paramString.substring(i, j));
            k = paramString.indexOf('?', j + 2);
          } while (k < 0);
          k = paramString.indexOf('?', k + 1);
        } while (k < 0);
        k = paramString.indexOf("?=", k + 1);
      } while (k < 0);
      Object localObject = paramString.substring(j, k + 2);
      try
      {
        String str = decodeWord((String)localObject);
        localObject = str;
      }
      catch (ParseException localParseException)
      {
        for (;;) {}
      }
      localStringBuffer.append((String)localObject);
      i = k + 2;
    }
    if (i < paramString.length()) {
      localStringBuffer.append(paramString.substring(i));
    }
    return localStringBuffer.toString();
  }
  
  public static String decodeText(String paramString)
    throws UnsupportedEncodingException
  {
    if (paramString.indexOf("=?") == -1) {
      return paramString;
    }
    StringTokenizer localStringTokenizer = new StringTokenizer(paramString, " \t\n\r", true);
    localStringBuffer1 = new StringBuffer();
    localStringBuffer2 = new StringBuffer();
    bool = false;
    for (;;)
    {
      if (!localStringTokenizer.hasMoreTokens())
      {
        localStringBuffer1.append(localStringBuffer2);
        return localStringBuffer1.toString();
      }
      paramString = localStringTokenizer.nextToken();
      char c = paramString.charAt(0);
      if ((c == ' ') || (c == '\t') || (c == '\r') || (c == '\n')) {
        localStringBuffer2.append(c);
      }
      try
      {
        String str1 = decodeWord(paramString);
        if ((!bool) && (localStringBuffer2.length() > 0)) {
          localStringBuffer1.append(localStringBuffer2);
        }
        bool = true;
        paramString = str1;
      }
      catch (ParseException localParseException)
      {
        for (;;)
        {
          if (!decodeStrict)
          {
            String str2 = decodeInnerWords(paramString);
            if (str2 != paramString)
            {
              if (((!bool) || (!paramString.startsWith("=?"))) && (localStringBuffer2.length() > 0)) {
                localStringBuffer1.append(localStringBuffer2);
              }
              bool = paramString.endsWith("?=");
              paramString = str2;
            }
            else
            {
              if (localStringBuffer2.length() > 0) {
                localStringBuffer1.append(localStringBuffer2);
              }
              bool = false;
            }
          }
          else
          {
            if (localStringBuffer2.length() > 0) {
              localStringBuffer1.append(localStringBuffer2);
            }
            bool = false;
          }
        }
      }
      localStringBuffer1.append(paramString);
      localStringBuffer2.setLength(0);
    }
  }
  
  public static String decodeWord(String paramString)
    throws ParseException, UnsupportedEncodingException
  {
    if (!paramString.startsWith("=?")) {
      throw new ParseException("encoded word does not start with \"=?\": " + paramString);
    }
    int i = paramString.indexOf('?', 2);
    if (i == -1) {
      throw new ParseException("encoded word does not include charset: " + paramString);
    }
    String str = javaCharset(paramString.substring(2, i));
    i += 1;
    int j = paramString.indexOf('?', i);
    if (j == -1) {
      throw new ParseException("encoded word does not include encoding: " + paramString);
    }
    Object localObject1 = paramString.substring(i, j);
    j += 1;
    i = paramString.indexOf("?=", j);
    if (i == -1) {
      throw new ParseException("encoded word does not end with \"?=\": " + paramString);
    }
    Object localObject2 = paramString.substring(j, i);
    for (;;)
    {
      try
      {
        if (((String)localObject2).length() <= 0) {
          continue;
        }
        localObject2 = new ByteArrayInputStream(ASCIIUtility.getBytes((String)localObject2));
        if (!((String)localObject1).equalsIgnoreCase("B")) {
          continue;
        }
        localObject1 = new BASE64DecoderStream((InputStream)localObject2);
        j = ((ByteArrayInputStream)localObject2).available();
        localObject2 = new byte[j];
        j = ((InputStream)localObject1).read((byte[])localObject2, 0, j);
        if (j > 0) {
          continue;
        }
        localObject1 = "";
      }
      catch (UnsupportedEncodingException paramString)
      {
        throw paramString;
        localObject1 = new String((byte[])localObject2, 0, j, str);
        continue;
      }
      catch (IOException paramString)
      {
        throw new ParseException(paramString.toString());
        localObject1 = "";
        continue;
      }
      catch (IllegalArgumentException paramString)
      {
        throw new UnsupportedEncodingException(str);
      }
      if (i + 2 >= paramString.length()) {
        return localObject1;
      }
      localObject2 = paramString.substring(i + 2);
      paramString = (String)localObject2;
      if (!decodeStrict) {
        paramString = decodeInnerWords((String)localObject2);
      }
      return localObject1 + paramString;
      if (!((String)localObject1).equalsIgnoreCase("Q")) {
        continue;
      }
      localObject1 = new QDecoderStream((InputStream)localObject2);
    }
    throw new UnsupportedEncodingException("unknown encoding: " + (String)localObject1);
    return (String)localObject1;
  }
  
  private static void doEncode(String paramString1, boolean paramBoolean1, String paramString2, int paramInt, String paramString3, boolean paramBoolean2, boolean paramBoolean3, StringBuffer paramStringBuffer)
    throws UnsupportedEncodingException
  {
    byte[] arrayOfByte = paramString1.getBytes(paramString2);
    if (paramBoolean1) {}
    for (int i = BEncoderStream.encodedLength(arrayOfByte); i > paramInt; i = QEncoderStream.encodedLength(arrayOfByte, paramBoolean3))
    {
      i = paramString1.length();
      if (i <= 1) {
        break;
      }
      doEncode(paramString1.substring(0, i / 2), paramBoolean1, paramString2, paramInt, paramString3, paramBoolean2, paramBoolean3, paramStringBuffer);
      doEncode(paramString1.substring(i / 2, i), paramBoolean1, paramString2, paramInt, paramString3, false, paramBoolean3, paramStringBuffer);
      return;
    }
    paramString2 = new ByteArrayOutputStream();
    if (paramBoolean1) {
      paramString1 = new BEncoderStream(paramString2);
    }
    try
    {
      paramString1.write(arrayOfByte);
      paramString1.close();
      paramString1 = paramString2.toByteArray();
      if (!paramBoolean2)
      {
        if (foldEncodedWords) {
          paramStringBuffer.append("\r\n ");
        }
      }
      else
      {
        label151:
        paramStringBuffer.append(paramString3);
        paramInt = 0;
      }
      for (;;)
      {
        if (paramInt >= paramString1.length)
        {
          paramStringBuffer.append("?=");
          return;
          paramString1 = new QEncoderStream(paramString2, paramBoolean3);
          break;
          paramStringBuffer.append(" ");
          break label151;
        }
        paramStringBuffer.append((char)paramString1[paramInt]);
        paramInt += 1;
      }
    }
    catch (IOException paramString1)
    {
      for (;;) {}
    }
  }
  
  public static OutputStream encode(OutputStream paramOutputStream, String paramString)
    throws MessagingException
  {
    if (paramString == null) {}
    do
    {
      return paramOutputStream;
      if (paramString.equalsIgnoreCase("base64")) {
        return new BASE64EncoderStream(paramOutputStream);
      }
      if (paramString.equalsIgnoreCase("quoted-printable")) {
        return new QPEncoderStream(paramOutputStream);
      }
      if ((paramString.equalsIgnoreCase("uuencode")) || (paramString.equalsIgnoreCase("x-uuencode")) || (paramString.equalsIgnoreCase("x-uue"))) {
        return new UUEncoderStream(paramOutputStream);
      }
    } while ((paramString.equalsIgnoreCase("binary")) || (paramString.equalsIgnoreCase("7bit")) || (paramString.equalsIgnoreCase("8bit")));
    throw new MessagingException("Unknown encoding: " + paramString);
  }
  
  public static OutputStream encode(OutputStream paramOutputStream, String paramString1, String paramString2)
    throws MessagingException
  {
    if (paramString1 == null) {}
    do
    {
      return paramOutputStream;
      if (paramString1.equalsIgnoreCase("base64")) {
        return new BASE64EncoderStream(paramOutputStream);
      }
      if (paramString1.equalsIgnoreCase("quoted-printable")) {
        return new QPEncoderStream(paramOutputStream);
      }
      if ((paramString1.equalsIgnoreCase("uuencode")) || (paramString1.equalsIgnoreCase("x-uuencode")) || (paramString1.equalsIgnoreCase("x-uue"))) {
        return new UUEncoderStream(paramOutputStream, paramString2);
      }
    } while ((paramString1.equalsIgnoreCase("binary")) || (paramString1.equalsIgnoreCase("7bit")) || (paramString1.equalsIgnoreCase("8bit")));
    throw new MessagingException("Unknown encoding: " + paramString1);
  }
  
  public static String encodeText(String paramString)
    throws UnsupportedEncodingException
  {
    return encodeText(paramString, null, null);
  }
  
  public static String encodeText(String paramString1, String paramString2, String paramString3)
    throws UnsupportedEncodingException
  {
    return encodeWord(paramString1, paramString2, paramString3, false);
  }
  
  public static String encodeWord(String paramString)
    throws UnsupportedEncodingException
  {
    return encodeWord(paramString, null, null);
  }
  
  public static String encodeWord(String paramString1, String paramString2, String paramString3)
    throws UnsupportedEncodingException
  {
    return encodeWord(paramString1, paramString2, paramString3, true);
  }
  
  private static String encodeWord(String paramString1, String paramString2, String paramString3, boolean paramBoolean)
    throws UnsupportedEncodingException
  {
    int i = checkAscii(paramString1);
    if (i == 1) {
      return paramString1;
    }
    String str1;
    String str2;
    if (paramString2 == null)
    {
      str1 = getDefaultJavaCharset();
      str2 = getDefaultMIMECharset();
      paramString2 = paramString3;
      if (paramString3 == null)
      {
        if (i == 3) {
          break label135;
        }
        paramString2 = "Q";
      }
      label44:
      if (!paramString2.equalsIgnoreCase("B")) {
        break label142;
      }
    }
    for (boolean bool = true;; bool = false)
    {
      paramString3 = new StringBuffer();
      doEncode(paramString1, bool, str1, 68 - str2.length(), "=?" + str2 + "?" + paramString2 + "?", true, paramBoolean, paramString3);
      return paramString3.toString();
      str1 = javaCharset(paramString2);
      str2 = paramString2;
      break;
      label135:
      paramString2 = "B";
      break label44;
      label142:
      if (!paramString2.equalsIgnoreCase("Q")) {
        break label158;
      }
    }
    label158:
    throw new UnsupportedEncodingException("Unknown transfer encoding: " + paramString2);
  }
  
  public static String fold(int paramInt, String paramString)
  {
    if (!foldText) {
      return paramString;
    }
    int i = paramString.length() - 1;
    String str;
    int j;
    for (;;)
    {
      if (i < 0) {}
      do
      {
        str = paramString;
        if (i != paramString.length() - 1) {
          str = paramString.substring(0, i + 1);
        }
        if (str.length() + paramInt > 76) {
          break;
        }
        return str;
        j = paramString.charAt(i);
      } while ((j != 32) && (j != 9) && (j != 13) && (j != 10));
      i -= 1;
    }
    paramString = new StringBuffer(str.length() + 4);
    int m = 0;
    i = paramInt;
    for (;;)
    {
      if (str.length() + i <= 76)
      {
        paramString.append(str);
        return paramString.toString();
      }
      j = -1;
      paramInt = 0;
      for (;;)
      {
        if (paramInt >= str.length()) {}
        while ((j != -1) && (i + paramInt > 76))
        {
          if (j != -1) {
            break label258;
          }
          paramString.append(str);
          str = "";
          break;
        }
        int n = str.charAt(paramInt);
        int k;
        if (n != 32)
        {
          k = j;
          if (n != 9) {}
        }
        else
        {
          k = j;
          if (m != 32)
          {
            k = j;
            if (m != 9) {
              k = paramInt;
            }
          }
        }
        m = n;
        paramInt += 1;
        j = k;
      }
      label258:
      paramString.append(str.substring(0, j));
      paramString.append("\r\n");
      char c = str.charAt(j);
      paramString.append(c);
      str = str.substring(j + 1);
      i = 1;
      m = c;
    }
  }
  
  public static String getDefaultJavaCharset()
  {
    Object localObject;
    if (defaultJavaCharset == null) {
      localObject = null;
    }
    try
    {
      String str = System.getProperty("mail.mime.charset");
      localObject = str;
    }
    catch (SecurityException localSecurityException2)
    {
      for (;;) {}
    }
    if ((localObject != null) && (((String)localObject).length() > 0))
    {
      defaultJavaCharset = javaCharset((String)localObject);
      return defaultJavaCharset;
    }
    try
    {
      defaultJavaCharset = System.getProperty("file.encoding", "8859_1");
      return defaultJavaCharset;
    }
    catch (SecurityException localSecurityException1)
    {
      for (;;)
      {
        defaultJavaCharset = new InputStreamReader(new InputStream()
        {
          public int read()
          {
            return 0;
          }
        }).getEncoding();
        if (defaultJavaCharset == null) {
          defaultJavaCharset = "8859_1";
        }
      }
    }
  }
  
  static String getDefaultMIMECharset()
  {
    if (defaultMIMECharset == null) {}
    try
    {
      defaultMIMECharset = System.getProperty("mail.mime.charset");
      if (defaultMIMECharset == null) {
        defaultMIMECharset = mimeCharset(getDefaultJavaCharset());
      }
      return defaultMIMECharset;
    }
    catch (SecurityException localSecurityException)
    {
      for (;;) {}
    }
  }
  
  /* Error */
  public static String getEncoding(javax.activation.DataHandler paramDataHandler)
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 537	javax/activation/DataHandler:getName	()Ljava/lang/String;
    //   4: ifnull +11 -> 15
    //   7: aload_0
    //   8: invokevirtual 541	javax/activation/DataHandler:getDataSource	()Ljavax/activation/DataSource;
    //   11: invokestatic 544	javax/mail/internet/MimeUtility:getEncoding	(Ljavax/activation/DataSource;)Ljava/lang/String;
    //   14: areturn
    //   15: new 546	javax/mail/internet/ContentType
    //   18: dup
    //   19: aload_0
    //   20: invokevirtual 549	javax/activation/DataHandler:getContentType	()Ljava/lang/String;
    //   23: invokespecial 550	javax/mail/internet/ContentType:<init>	(Ljava/lang/String;)V
    //   26: astore_1
    //   27: aload_1
    //   28: ldc_w 552
    //   31: invokevirtual 555	javax/mail/internet/ContentType:match	(Ljava/lang/String;)Z
    //   34: ifeq +71 -> 105
    //   37: new 557	javax/mail/internet/AsciiOutputStream
    //   40: dup
    //   41: iconst_0
    //   42: iconst_0
    //   43: invokespecial 560	javax/mail/internet/AsciiOutputStream:<init>	(ZZ)V
    //   46: astore_1
    //   47: aload_0
    //   48: aload_1
    //   49: invokevirtual 563	javax/activation/DataHandler:writeTo	(Ljava/io/OutputStream;)V
    //   52: aload_1
    //   53: invokevirtual 566	javax/mail/internet/AsciiOutputStream:getAscii	()I
    //   56: tableswitch	default:+24->80, 1:+35->91, 2:+42->98
    //   80: ldc_w 276
    //   83: astore_0
    //   84: aload_0
    //   85: areturn
    //   86: astore_0
    //   87: ldc_w 276
    //   90: areturn
    //   91: ldc_w 297
    //   94: astore_0
    //   95: goto -11 -> 84
    //   98: ldc_w 281
    //   101: astore_0
    //   102: goto -18 -> 84
    //   105: new 557	javax/mail/internet/AsciiOutputStream
    //   108: dup
    //   109: iconst_1
    //   110: getstatic 37	javax/mail/internet/MimeUtility:encodeEolStrict	Z
    //   113: invokespecial 560	javax/mail/internet/AsciiOutputStream:<init>	(ZZ)V
    //   116: astore_1
    //   117: aload_0
    //   118: aload_1
    //   119: invokevirtual 563	javax/activation/DataHandler:writeTo	(Ljava/io/OutputStream;)V
    //   122: aload_1
    //   123: invokevirtual 566	javax/mail/internet/AsciiOutputStream:getAscii	()I
    //   126: iconst_1
    //   127: if_icmpne +10 -> 137
    //   130: ldc_w 297
    //   133: astore_0
    //   134: goto -50 -> 84
    //   137: ldc_w 276
    //   140: astore_0
    //   141: goto -57 -> 84
    //   144: astore_0
    //   145: goto -93 -> 52
    //   148: astore_0
    //   149: goto -27 -> 122
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	152	0	paramDataHandler	javax.activation.DataHandler
    //   26	97	1	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   15	27	86	java/lang/Exception
    //   47	52	144	java/io/IOException
    //   117	122	148	java/io/IOException
  }
  
  /* Error */
  public static String getEncoding(javax.activation.DataSource paramDataSource)
  {
    // Byte code:
    //   0: new 546	javax/mail/internet/ContentType
    //   3: dup
    //   4: aload_0
    //   5: invokeinterface 569 1 0
    //   10: invokespecial 550	javax/mail/internet/ContentType:<init>	(Ljava/lang/String;)V
    //   13: astore_3
    //   14: aload_0
    //   15: invokeinterface 573 1 0
    //   20: astore_2
    //   21: aload_3
    //   22: ldc_w 552
    //   25: invokevirtual 555	javax/mail/internet/ContentType:match	(Ljava/lang/String;)Z
    //   28: ifeq +47 -> 75
    //   31: iconst_0
    //   32: istore_1
    //   33: aload_2
    //   34: iconst_m1
    //   35: iload_1
    //   36: invokestatic 575	javax/mail/internet/MimeUtility:checkAscii	(Ljava/io/InputStream;IZ)I
    //   39: tableswitch	default:+21->60, 1:+41->80, 2:+48->87
    //   60: ldc_w 276
    //   63: astore_0
    //   64: aload_2
    //   65: invokevirtual 97	java/io/InputStream:close	()V
    //   68: aload_0
    //   69: areturn
    //   70: astore_0
    //   71: ldc_w 276
    //   74: areturn
    //   75: iconst_1
    //   76: istore_1
    //   77: goto -44 -> 33
    //   80: ldc_w 297
    //   83: astore_0
    //   84: goto -20 -> 64
    //   87: ldc_w 281
    //   90: astore_0
    //   91: goto -27 -> 64
    //   94: astore_2
    //   95: goto -27 -> 68
    //   98: astore_0
    //   99: goto -28 -> 71
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	102	0	paramDataSource	javax.activation.DataSource
    //   32	45	1	bool	boolean
    //   20	45	2	localInputStream	InputStream
    //   94	1	2	localIOException	IOException
    //   13	9	3	localContentType	ContentType
    // Exception table:
    //   from	to	target	type
    //   0	14	70	java/lang/Exception
    //   64	68	94	java/io/IOException
    //   14	21	98	java/lang/Exception
  }
  
  private static int indexOfAny(String paramString1, String paramString2)
  {
    return indexOfAny(paramString1, paramString2, 0);
  }
  
  private static int indexOfAny(String paramString1, String paramString2, int paramInt)
  {
    int j;
    do
    {
      try
      {
        j = paramString1.length();
      }
      catch (StringIndexOutOfBoundsException paramString1)
      {
        int k;
        return -1;
      }
      k = paramString2.indexOf(paramString1.charAt(paramInt));
      i = paramInt;
      if (k >= 0) {
        break;
      }
      paramInt += 1;
    } while (paramInt < j);
    int i = -1;
    return i;
  }
  
  public static String javaCharset(String paramString)
  {
    if ((mime2java == null) || (paramString == null)) {}
    String str;
    do
    {
      return paramString;
      str = (String)mime2java.get(paramString.toLowerCase(Locale.ENGLISH));
    } while (str == null);
    return str;
  }
  
  private static void loadMappings(LineInputStream paramLineInputStream, Hashtable paramHashtable)
  {
    for (;;)
    {
      String str;
      try
      {
        str = paramLineInputStream.readLine();
        if (str == null) {
          return;
        }
      }
      catch (IOException paramLineInputStream)
      {
        return;
      }
      if ((!str.startsWith("--")) || (!str.endsWith("--"))) {
        if ((str.trim().length() != 0) && (!str.startsWith("#")))
        {
          Object localObject = new StringTokenizer(str, " \t");
          try
          {
            str = ((StringTokenizer)localObject).nextToken();
            localObject = ((StringTokenizer)localObject).nextToken();
            paramHashtable.put(str.toLowerCase(Locale.ENGLISH), localObject);
          }
          catch (NoSuchElementException localNoSuchElementException) {}
        }
      }
    }
  }
  
  public static String mimeCharset(String paramString)
  {
    if ((java2mime == null) || (paramString == null)) {}
    String str;
    do
    {
      return paramString;
      str = (String)java2mime.get(paramString.toLowerCase(Locale.ENGLISH));
    } while (str == null);
    return str;
  }
  
  static final boolean nonascii(int paramInt)
  {
    return (paramInt >= 127) || ((paramInt < 32) && (paramInt != 13) && (paramInt != 10) && (paramInt != 9));
  }
  
  public static String quote(String paramString1, String paramString2)
  {
    int k = paramString1.length();
    int j = 0;
    int i = 0;
    for (;;)
    {
      if (i >= k)
      {
        paramString2 = paramString1;
        if (j != 0)
        {
          paramString2 = new StringBuffer(k + 2);
          paramString2.append('"').append(paramString1).append('"');
          paramString2 = paramString2.toString();
        }
        return paramString2;
      }
      int m = paramString1.charAt(i);
      if ((m == 34) || (m == 92) || (m == 13) || (m == 10))
      {
        paramString2 = new StringBuffer(k + 3);
        paramString2.append('"');
        paramString2.append(paramString1.substring(0, i));
        j = 0;
        if (i >= k)
        {
          paramString2.append('"');
          return paramString2.toString();
        }
        char c = paramString1.charAt(i);
        if (((c != '"') && (c != '\\') && (c != '\r') && (c != '\n')) || ((c == '\n') && (j == 13))) {}
        for (;;)
        {
          paramString2.append(c);
          j = c;
          i += 1;
          break;
          paramString2.append('\\');
        }
      }
      if ((m < 32) || (m >= 127) || (paramString2.indexOf(m) >= 0)) {
        j = 1;
      }
      i += 1;
    }
  }
  
  public static String unfold(String paramString)
  {
    Object localObject2;
    if (!foldText)
    {
      localObject2 = paramString;
      return (String)localObject2;
    }
    Object localObject1 = null;
    for (;;)
    {
      int k = indexOfAny(paramString, "\r\n");
      if (k < 0)
      {
        localObject2 = paramString;
        if (localObject1 == null) {
          break;
        }
        ((StringBuffer)localObject1).append(paramString);
        return ((StringBuffer)localObject1).toString();
      }
      int m = paramString.length();
      int j = k + 1;
      int i = j;
      if (j < m)
      {
        i = j;
        if (paramString.charAt(j - 1) == '\r')
        {
          i = j;
          if (paramString.charAt(j) == '\n') {
            i = j + 1;
          }
        }
      }
      if ((k == 0) || (paramString.charAt(k - 1) != '\\'))
      {
        if (i < m)
        {
          j = paramString.charAt(i);
          if ((j == 32) || (j == 9))
          {
            i += 1;
            for (;;)
            {
              if (i < m)
              {
                j = paramString.charAt(i);
                if ((j == 32) || (j == 9)) {}
              }
              else
              {
                localObject2 = localObject1;
                if (localObject1 == null) {
                  localObject2 = new StringBuffer(paramString.length());
                }
                if (k != 0)
                {
                  ((StringBuffer)localObject2).append(paramString.substring(0, k));
                  ((StringBuffer)localObject2).append(' ');
                }
                paramString = paramString.substring(i);
                localObject1 = localObject2;
                break;
              }
              i += 1;
            }
          }
        }
        localObject2 = localObject1;
        if (localObject1 == null) {
          localObject2 = new StringBuffer(paramString.length());
        }
        ((StringBuffer)localObject2).append(paramString.substring(0, i));
        paramString = paramString.substring(i);
        localObject1 = localObject2;
      }
      else
      {
        localObject2 = localObject1;
        if (localObject1 == null) {
          localObject2 = new StringBuffer(paramString.length());
        }
        ((StringBuffer)localObject2).append(paramString.substring(0, k - 1));
        ((StringBuffer)localObject2).append(paramString.substring(k, i));
        paramString = paramString.substring(i);
        localObject1 = localObject2;
      }
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/internet/MimeUtility.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */