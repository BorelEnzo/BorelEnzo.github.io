package javax.mail.internet;

public class ContentType
{
  private ParameterList list;
  private String primaryType;
  private String subType;
  
  public ContentType() {}
  
  public ContentType(String paramString)
    throws ParseException
  {
    paramString = new HeaderTokenizer(paramString, "()<>@,;:\\\"\t []/?=");
    HeaderTokenizer.Token localToken = paramString.next();
    if (localToken.getType() != -1) {
      throw new ParseException();
    }
    this.primaryType = localToken.getValue();
    if ((char)paramString.next().getType() != '/') {
      throw new ParseException();
    }
    localToken = paramString.next();
    if (localToken.getType() != -1) {
      throw new ParseException();
    }
    this.subType = localToken.getValue();
    paramString = paramString.getRemainder();
    if (paramString != null) {
      this.list = new ParameterList(paramString);
    }
  }
  
  public ContentType(String paramString1, String paramString2, ParameterList paramParameterList)
  {
    this.primaryType = paramString1;
    this.subType = paramString2;
    this.list = paramParameterList;
  }
  
  public String getBaseType()
  {
    return this.primaryType + '/' + this.subType;
  }
  
  public String getParameter(String paramString)
  {
    if (this.list == null) {
      return null;
    }
    return this.list.get(paramString);
  }
  
  public ParameterList getParameterList()
  {
    return this.list;
  }
  
  public String getPrimaryType()
  {
    return this.primaryType;
  }
  
  public String getSubType()
  {
    return this.subType;
  }
  
  public boolean match(String paramString)
  {
    try
    {
      boolean bool = match(new ContentType(paramString));
      return bool;
    }
    catch (ParseException paramString) {}
    return false;
  }
  
  public boolean match(ContentType paramContentType)
  {
    if (!this.primaryType.equalsIgnoreCase(paramContentType.getPrimaryType())) {}
    do
    {
      return false;
      paramContentType = paramContentType.getSubType();
      if ((this.subType.charAt(0) == '*') || (paramContentType.charAt(0) == '*')) {
        return true;
      }
    } while (!this.subType.equalsIgnoreCase(paramContentType));
    return true;
  }
  
  public void setParameter(String paramString1, String paramString2)
  {
    if (this.list == null) {
      this.list = new ParameterList();
    }
    this.list.set(paramString1, paramString2);
  }
  
  public void setParameterList(ParameterList paramParameterList)
  {
    this.list = paramParameterList;
  }
  
  public void setPrimaryType(String paramString)
  {
    this.primaryType = paramString;
  }
  
  public void setSubType(String paramString)
  {
    this.subType = paramString;
  }
  
  public String toString()
  {
    if ((this.primaryType == null) || (this.subType == null)) {
      return null;
    }
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append(this.primaryType).append('/').append(this.subType);
    if (this.list != null) {
      localStringBuffer.append(this.list.toString(localStringBuffer.length() + 14));
    }
    return localStringBuffer.toString();
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/internet/ContentType.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */