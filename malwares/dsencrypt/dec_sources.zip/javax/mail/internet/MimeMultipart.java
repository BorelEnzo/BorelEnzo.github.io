package javax.mail.internet;

import com.sun.mail.util.ASCIIUtility;
import com.sun.mail.util.LineOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Vector;
import javax.activation.DataSource;
import javax.mail.BodyPart;
import javax.mail.MessageAware;
import javax.mail.MessageContext;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.MultipartDataSource;

public class MimeMultipart
  extends Multipart
{
  private static boolean bmparse = true;
  private static boolean ignoreMissingBoundaryParameter;
  private static boolean ignoreMissingEndBoundary;
  private boolean complete = true;
  protected DataSource ds = null;
  protected boolean parsed = true;
  private String preamble = null;
  
  static
  {
    boolean bool2 = false;
    ignoreMissingEndBoundary = true;
    ignoreMissingBoundaryParameter = true;
    try
    {
      String str = System.getProperty("mail.mime.multipart.ignoremissingendboundary");
      if ((str != null) && (str.equalsIgnoreCase("false")))
      {
        bool1 = false;
        ignoreMissingEndBoundary = bool1;
        str = System.getProperty("mail.mime.multipart.ignoremissingboundaryparameter");
        if ((str == null) || (!str.equalsIgnoreCase("false"))) {
          break label95;
        }
        bool1 = false;
        label60:
        ignoreMissingBoundaryParameter = bool1;
        str = System.getProperty("mail.mime.multipart.bmparse");
        if ((str == null) || (!str.equalsIgnoreCase("false"))) {
          break label100;
        }
      }
      label95:
      label100:
      for (boolean bool1 = bool2;; bool1 = true)
      {
        bmparse = bool1;
        return;
        bool1 = true;
        break;
        bool1 = true;
        break label60;
      }
      return;
    }
    catch (SecurityException localSecurityException) {}
  }
  
  public MimeMultipart()
  {
    this("mixed");
  }
  
  public MimeMultipart(String paramString)
  {
    String str = UniqueValue.getUniqueBoundaryValue();
    paramString = new ContentType("multipart", paramString, null);
    paramString.setParameter("boundary", str);
    this.contentType = paramString.toString();
  }
  
  public MimeMultipart(DataSource paramDataSource)
    throws MessagingException
  {
    if ((paramDataSource instanceof MessageAware)) {
      setParent(((MessageAware)paramDataSource).getMessageContext().getPart());
    }
    if ((paramDataSource instanceof MultipartDataSource))
    {
      setMultipartDataSource((MultipartDataSource)paramDataSource);
      return;
    }
    this.parsed = false;
    this.ds = paramDataSource;
    this.contentType = paramDataSource.getContentType();
  }
  
  /* Error */
  private void parsebm()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 57	javax/mail/internet/MimeMultipart:parsed	Z
    //   6: istore 9
    //   8: iload 9
    //   10: ifeq +6 -> 16
    //   13: aload_0
    //   14: monitorexit
    //   15: return
    //   16: aconst_null
    //   17: astore 19
    //   19: lconst_0
    //   20: lstore 14
    //   22: lconst_0
    //   23: lstore 10
    //   25: aload_0
    //   26: getfield 55	javax/mail/internet/MimeMultipart:ds	Ljavax/activation/DataSource;
    //   29: invokeinterface 126 1 0
    //   34: astore 16
    //   36: aload 16
    //   38: astore 18
    //   40: aload 16
    //   42: instanceof 128
    //   45: ifne +38 -> 83
    //   48: aload 16
    //   50: astore 18
    //   52: aload 16
    //   54: instanceof 130
    //   57: ifne +26 -> 83
    //   60: aload 16
    //   62: astore 18
    //   64: aload 16
    //   66: instanceof 132
    //   69: ifne +14 -> 83
    //   72: new 130	java/io/BufferedInputStream
    //   75: dup
    //   76: aload 16
    //   78: invokespecial 135	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
    //   81: astore 18
    //   83: aload 18
    //   85: instanceof 132
    //   88: ifeq +10 -> 98
    //   91: aload 18
    //   93: checkcast 132	javax/mail/internet/SharedInputStream
    //   96: astore 19
    //   98: new 69	javax/mail/internet/ContentType
    //   101: dup
    //   102: aload_0
    //   103: getfield 86	javax/mail/internet/MimeMultipart:contentType	Ljava/lang/String;
    //   106: invokespecial 136	javax/mail/internet/ContentType:<init>	(Ljava/lang/String;)V
    //   109: astore 17
    //   111: aconst_null
    //   112: astore 16
    //   114: aload 17
    //   116: ldc 76
    //   118: invokevirtual 139	javax/mail/internet/ContentType:getParameter	(Ljava/lang/String;)Ljava/lang/String;
    //   121: astore 17
    //   123: aload 17
    //   125: ifnull +115 -> 240
    //   128: new 141	java/lang/StringBuilder
    //   131: dup
    //   132: ldc -113
    //   134: invokespecial 144	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   137: aload 17
    //   139: invokevirtual 148	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   142: invokevirtual 149	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   145: astore 16
    //   147: new 151	com/sun/mail/util/LineInputStream
    //   150: dup
    //   151: aload 18
    //   153: invokespecial 152	com/sun/mail/util/LineInputStream:<init>	(Ljava/io/InputStream;)V
    //   156: astore 24
    //   158: aconst_null
    //   159: astore 20
    //   161: aconst_null
    //   162: astore 22
    //   164: aload 24
    //   166: invokevirtual 155	com/sun/mail/util/LineInputStream:readLine	()Ljava/lang/String;
    //   169: astore 23
    //   171: aload 23
    //   173: ifnonnull +83 -> 256
    //   176: aload 16
    //   178: astore 17
    //   180: aload 23
    //   182: ifnonnull +239 -> 421
    //   185: new 89	javax/mail/MessagingException
    //   188: dup
    //   189: ldc -99
    //   191: invokespecial 158	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   194: athrow
    //   195: astore 16
    //   197: new 89	javax/mail/MessagingException
    //   200: dup
    //   201: ldc -96
    //   203: aload 16
    //   205: invokespecial 163	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   208: athrow
    //   209: astore 16
    //   211: aload 18
    //   213: invokevirtual 168	java/io/InputStream:close	()V
    //   216: aload 16
    //   218: athrow
    //   219: astore 16
    //   221: aload_0
    //   222: monitorexit
    //   223: aload 16
    //   225: athrow
    //   226: astore 16
    //   228: new 89	javax/mail/MessagingException
    //   231: dup
    //   232: ldc -86
    //   234: aload 16
    //   236: invokespecial 163	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   239: athrow
    //   240: getstatic 22	javax/mail/internet/MimeMultipart:ignoreMissingBoundaryParameter	Z
    //   243: ifne -96 -> 147
    //   246: new 89	javax/mail/MessagingException
    //   249: dup
    //   250: ldc -84
    //   252: invokespecial 158	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   255: athrow
    //   256: aload 23
    //   258: invokevirtual 176	java/lang/String:length	()I
    //   261: iconst_1
    //   262: isub
    //   263: istore_1
    //   264: goto +874 -> 1138
    //   267: aload 23
    //   269: iconst_0
    //   270: iload_1
    //   271: iconst_1
    //   272: iadd
    //   273: invokevirtual 180	java/lang/String:substring	(II)Ljava/lang/String;
    //   276: astore 21
    //   278: aload 16
    //   280: ifnull +120 -> 400
    //   283: aload 16
    //   285: astore 17
    //   287: aload 21
    //   289: astore 23
    //   291: aload 21
    //   293: aload 16
    //   295: invokevirtual 184	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   298: ifne -118 -> 180
    //   301: aload 21
    //   303: invokevirtual 176	java/lang/String:length	()I
    //   306: istore_1
    //   307: iload_1
    //   308: ifle -144 -> 164
    //   311: aload 22
    //   313: astore 17
    //   315: aload 22
    //   317: ifnonnull +12 -> 329
    //   320: ldc -70
    //   322: ldc -68
    //   324: invokestatic 191	java/lang/System:getProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   327: astore 17
    //   329: aload 20
    //   331: astore 23
    //   333: aload 20
    //   335: ifnonnull +19 -> 354
    //   338: new 193	java/lang/StringBuffer
    //   341: dup
    //   342: aload 21
    //   344: invokevirtual 176	java/lang/String:length	()I
    //   347: iconst_2
    //   348: iadd
    //   349: invokespecial 196	java/lang/StringBuffer:<init>	(I)V
    //   352: astore 23
    //   354: aload 23
    //   356: aload 21
    //   358: invokevirtual 199	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   361: aload 17
    //   363: invokevirtual 199	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   366: pop
    //   367: aload 17
    //   369: astore 22
    //   371: aload 23
    //   373: astore 20
    //   375: goto -211 -> 164
    //   378: aload 23
    //   380: iload_1
    //   381: invokevirtual 203	java/lang/String:charAt	(I)C
    //   384: istore_2
    //   385: iload_2
    //   386: bipush 32
    //   388: if_icmpeq +757 -> 1145
    //   391: iload_2
    //   392: bipush 9
    //   394: if_icmpne -127 -> 267
    //   397: goto +748 -> 1145
    //   400: aload 21
    //   402: ldc -113
    //   404: invokevirtual 206	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   407: ifeq -106 -> 301
    //   410: aload 21
    //   412: astore 17
    //   414: aload 21
    //   416: astore 23
    //   418: goto -238 -> 180
    //   421: aload 20
    //   423: ifnull +12 -> 435
    //   426: aload_0
    //   427: aload 20
    //   429: invokevirtual 207	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   432: putfield 61	javax/mail/internet/MimeMultipart:preamble	Ljava/lang/String;
    //   435: aload 17
    //   437: invokestatic 213	com/sun/mail/util/ASCIIUtility:getBytes	(Ljava/lang/String;)[B
    //   440: astore 23
    //   442: aload 23
    //   444: arraylength
    //   445: istore 7
    //   447: sipush 256
    //   450: newarray <illegal type>
    //   452: astore 25
    //   454: iconst_0
    //   455: istore_1
    //   456: iload_1
    //   457: iload 7
    //   459: if_icmplt +43 -> 502
    //   462: iload 7
    //   464: newarray <illegal type>
    //   466: astore 26
    //   468: iload 7
    //   470: istore_2
    //   471: iload_2
    //   472: ifgt +689 -> 1161
    //   475: aload 26
    //   477: iload 7
    //   479: iconst_1
    //   480: isub
    //   481: iconst_1
    //   482: iastore
    //   483: iconst_0
    //   484: istore_3
    //   485: iload_3
    //   486: ifeq +33 -> 519
    //   489: aload 18
    //   491: invokevirtual 168	java/io/InputStream:close	()V
    //   494: aload_0
    //   495: iconst_1
    //   496: putfield 57	javax/mail/internet/MimeMultipart:parsed	Z
    //   499: goto -486 -> 13
    //   502: aload 25
    //   504: aload 23
    //   506: iload_1
    //   507: baload
    //   508: iload_1
    //   509: iconst_1
    //   510: iadd
    //   511: iastore
    //   512: iload_1
    //   513: iconst_1
    //   514: iadd
    //   515: istore_1
    //   516: goto -60 -> 456
    //   519: aconst_null
    //   520: astore 20
    //   522: aload 19
    //   524: ifnull +61 -> 585
    //   527: aload 19
    //   529: invokeinterface 217 1 0
    //   534: lstore 14
    //   536: aload 24
    //   538: invokevirtual 155	com/sun/mail/util/LineInputStream:readLine	()Ljava/lang/String;
    //   541: astore 16
    //   543: aload 16
    //   545: ifnull +11 -> 556
    //   548: aload 16
    //   550: invokevirtual 176	java/lang/String:length	()I
    //   553: ifgt -17 -> 536
    //   556: aload 16
    //   558: ifnonnull +35 -> 593
    //   561: getstatic 20	javax/mail/internet/MimeMultipart:ignoreMissingEndBoundary	Z
    //   564: ifne +13 -> 577
    //   567: new 89	javax/mail/MessagingException
    //   570: dup
    //   571: ldc -37
    //   573: invokespecial 158	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   576: athrow
    //   577: aload_0
    //   578: iconst_0
    //   579: putfield 59	javax/mail/internet/MimeMultipart:complete	Z
    //   582: goto -93 -> 489
    //   585: aload_0
    //   586: aload 18
    //   588: invokevirtual 223	javax/mail/internet/MimeMultipart:createInternetHeaders	(Ljava/io/InputStream;)Ljavax/mail/internet/InternetHeaders;
    //   591: astore 20
    //   593: aload 18
    //   595: invokevirtual 227	java/io/InputStream:markSupported	()Z
    //   598: ifne +13 -> 611
    //   601: new 89	javax/mail/MessagingException
    //   604: dup
    //   605: ldc -27
    //   607: invokespecial 158	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   610: athrow
    //   611: aconst_null
    //   612: astore 21
    //   614: aload 19
    //   616: ifnonnull +80 -> 696
    //   619: new 231	java/io/ByteArrayOutputStream
    //   622: dup
    //   623: invokespecial 232	java/io/ByteArrayOutputStream:<init>	()V
    //   626: astore 21
    //   628: iload 7
    //   630: newarray <illegal type>
    //   632: astore 16
    //   634: iload 7
    //   636: newarray <illegal type>
    //   638: astore 17
    //   640: iconst_0
    //   641: istore 4
    //   643: iconst_1
    //   644: istore_2
    //   645: aload 18
    //   647: iload 7
    //   649: iconst_4
    //   650: iadd
    //   651: sipush 1000
    //   654: iadd
    //   655: invokevirtual 235	java/io/InputStream:mark	(I)V
    //   658: iconst_0
    //   659: istore 5
    //   661: aload 18
    //   663: aload 16
    //   665: iconst_0
    //   666: iload 7
    //   668: invokestatic 239	javax/mail/internet/MimeMultipart:readFully	(Ljava/io/InputStream;[BII)I
    //   671: istore 8
    //   673: iload 8
    //   675: iload 7
    //   677: if_icmpge +544 -> 1221
    //   680: getstatic 20	javax/mail/internet/MimeMultipart:ignoreMissingEndBoundary	Z
    //   683: ifne +25 -> 708
    //   686: new 89	javax/mail/MessagingException
    //   689: dup
    //   690: ldc -37
    //   692: invokespecial 158	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   695: athrow
    //   696: aload 19
    //   698: invokeinterface 217 1 0
    //   703: lstore 10
    //   705: goto -77 -> 628
    //   708: aload 19
    //   710: ifnull +12 -> 722
    //   713: aload 19
    //   715: invokeinterface 217 1 0
    //   720: lstore 10
    //   722: aload_0
    //   723: iconst_0
    //   724: putfield 59	javax/mail/internet/MimeMultipart:complete	Z
    //   727: iconst_1
    //   728: istore_2
    //   729: lload 10
    //   731: lstore 12
    //   733: aload 19
    //   735: ifnull +334 -> 1069
    //   738: aload_0
    //   739: aload 19
    //   741: lload 14
    //   743: lload 12
    //   745: invokeinterface 243 5 0
    //   750: invokevirtual 247	javax/mail/internet/MimeMultipart:createMimeBodyPart	(Ljava/io/InputStream;)Ljavax/mail/internet/MimeBodyPart;
    //   753: astore 16
    //   755: aload_0
    //   756: aload 16
    //   758: invokespecial 251	javax/mail/Multipart:addBodyPart	(Ljavax/mail/BodyPart;)V
    //   761: iload_2
    //   762: istore_3
    //   763: lload 12
    //   765: lstore 10
    //   767: goto -282 -> 485
    //   770: aload 19
    //   772: ifnull +19 -> 791
    //   775: aload 19
    //   777: invokeinterface 217 1 0
    //   782: iload 7
    //   784: i2l
    //   785: lsub
    //   786: iload_1
    //   787: i2l
    //   788: lsub
    //   789: lstore 10
    //   791: aload 18
    //   793: invokevirtual 254	java/io/InputStream:read	()I
    //   796: istore_2
    //   797: iload_2
    //   798: istore 6
    //   800: iload_2
    //   801: bipush 45
    //   803: if_icmpne +40 -> 843
    //   806: iload_2
    //   807: istore 6
    //   809: aload 18
    //   811: invokevirtual 254	java/io/InputStream:read	()I
    //   814: bipush 45
    //   816: if_icmpne +27 -> 843
    //   819: aload_0
    //   820: iconst_1
    //   821: putfield 59	javax/mail/internet/MimeMultipart:complete	Z
    //   824: iconst_1
    //   825: istore_2
    //   826: lload 10
    //   828: lstore 12
    //   830: iload_1
    //   831: istore 5
    //   833: goto -100 -> 733
    //   836: aload 18
    //   838: invokevirtual 254	java/io/InputStream:read	()I
    //   841: istore 6
    //   843: iload 6
    //   845: bipush 32
    //   847: if_icmpeq -11 -> 836
    //   850: iload 6
    //   852: bipush 9
    //   854: if_icmpeq -18 -> 836
    //   857: iload_3
    //   858: istore_2
    //   859: lload 10
    //   861: lstore 12
    //   863: iload_1
    //   864: istore 5
    //   866: iload 6
    //   868: bipush 10
    //   870: if_icmpeq -137 -> 733
    //   873: lload 10
    //   875: lstore 12
    //   877: iload 6
    //   879: bipush 13
    //   881: if_icmpne +468 -> 1349
    //   884: aload 18
    //   886: iconst_1
    //   887: invokevirtual 235	java/io/InputStream:mark	(I)V
    //   890: iload_3
    //   891: istore_2
    //   892: lload 10
    //   894: lstore 12
    //   896: iload_1
    //   897: istore 5
    //   899: aload 18
    //   901: invokevirtual 254	java/io/InputStream:read	()I
    //   904: bipush 10
    //   906: if_icmpeq -173 -> 733
    //   909: aload 18
    //   911: invokevirtual 257	java/io/InputStream:reset	()V
    //   914: iload_3
    //   915: istore_2
    //   916: lload 10
    //   918: lstore 12
    //   920: iload_1
    //   921: istore 5
    //   923: goto -190 -> 733
    //   926: iload 5
    //   928: iconst_1
    //   929: iadd
    //   930: aload 25
    //   932: aload 16
    //   934: iload 5
    //   936: baload
    //   937: bipush 127
    //   939: iand
    //   940: iaload
    //   941: isub
    //   942: aload 26
    //   944: iload 5
    //   946: iaload
    //   947: invokestatic 263	java/lang/Math:max	(II)I
    //   950: istore_1
    //   951: iload_1
    //   952: iconst_2
    //   953: if_icmpge +68 -> 1021
    //   956: aload 19
    //   958: ifnonnull +21 -> 979
    //   961: iload 4
    //   963: iconst_1
    //   964: if_icmple +15 -> 979
    //   967: aload 21
    //   969: aload 17
    //   971: iconst_0
    //   972: iload 4
    //   974: iconst_1
    //   975: isub
    //   976: invokevirtual 267	java/io/ByteArrayOutputStream:write	([BII)V
    //   979: aload 18
    //   981: invokevirtual 257	java/io/InputStream:reset	()V
    //   984: aload_0
    //   985: aload 18
    //   987: lconst_1
    //   988: invokespecial 271	javax/mail/internet/MimeMultipart:skipFully	(Ljava/io/InputStream;J)V
    //   991: iload 4
    //   993: iconst_1
    //   994: if_icmplt +373 -> 1367
    //   997: aload 17
    //   999: iconst_0
    //   1000: aload 17
    //   1002: iload 4
    //   1004: iconst_1
    //   1005: isub
    //   1006: baload
    //   1007: bastore
    //   1008: aload 17
    //   1010: iconst_1
    //   1011: aload 16
    //   1013: iconst_0
    //   1014: baload
    //   1015: bastore
    //   1016: iconst_2
    //   1017: istore_1
    //   1018: goto +337 -> 1355
    //   1021: iload 4
    //   1023: ifle +18 -> 1041
    //   1026: aload 19
    //   1028: ifnonnull +13 -> 1041
    //   1031: aload 21
    //   1033: aload 17
    //   1035: iconst_0
    //   1036: iload 4
    //   1038: invokevirtual 267	java/io/ByteArrayOutputStream:write	([BII)V
    //   1041: aload 18
    //   1043: invokevirtual 257	java/io/InputStream:reset	()V
    //   1046: aload_0
    //   1047: aload 18
    //   1049: iload_1
    //   1050: i2l
    //   1051: invokespecial 271	javax/mail/internet/MimeMultipart:skipFully	(Ljava/io/InputStream;J)V
    //   1054: aload 16
    //   1056: astore 22
    //   1058: aload 17
    //   1060: astore 16
    //   1062: aload 22
    //   1064: astore 17
    //   1066: goto +289 -> 1355
    //   1069: iload 4
    //   1071: iload 5
    //   1073: isub
    //   1074: ifle +16 -> 1090
    //   1077: aload 21
    //   1079: aload 17
    //   1081: iconst_0
    //   1082: iload 4
    //   1084: iload 5
    //   1086: isub
    //   1087: invokevirtual 267	java/io/ByteArrayOutputStream:write	([BII)V
    //   1090: aload_0
    //   1091: getfield 59	javax/mail/internet/MimeMultipart:complete	Z
    //   1094: ifne +18 -> 1112
    //   1097: iload 8
    //   1099: ifle +13 -> 1112
    //   1102: aload 21
    //   1104: aload 16
    //   1106: iconst_0
    //   1107: iload 8
    //   1109: invokevirtual 267	java/io/ByteArrayOutputStream:write	([BII)V
    //   1112: aload_0
    //   1113: aload 20
    //   1115: aload 21
    //   1117: invokevirtual 275	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   1120: invokevirtual 278	javax/mail/internet/MimeMultipart:createMimeBodyPart	(Ljavax/mail/internet/InternetHeaders;[B)Ljavax/mail/internet/MimeBodyPart;
    //   1123: astore 16
    //   1125: goto -370 -> 755
    //   1128: astore 17
    //   1130: goto -914 -> 216
    //   1133: astore 16
    //   1135: goto -641 -> 494
    //   1138: iload_1
    //   1139: ifge -761 -> 378
    //   1142: goto -875 -> 267
    //   1145: iload_1
    //   1146: iconst_1
    //   1147: isub
    //   1148: istore_1
    //   1149: goto -11 -> 1138
    //   1152: astore 17
    //   1154: ldc -68
    //   1156: astore 17
    //   1158: goto -829 -> 329
    //   1161: iload 7
    //   1163: iconst_1
    //   1164: isub
    //   1165: istore_1
    //   1166: iload_1
    //   1167: iload_2
    //   1168: if_icmpge +14 -> 1182
    //   1171: iload_1
    //   1172: ifgt +37 -> 1209
    //   1175: iload_2
    //   1176: iconst_1
    //   1177: isub
    //   1178: istore_2
    //   1179: goto -708 -> 471
    //   1182: aload 23
    //   1184: iload_1
    //   1185: baload
    //   1186: aload 23
    //   1188: iload_1
    //   1189: iload_2
    //   1190: isub
    //   1191: baload
    //   1192: if_icmpne -17 -> 1175
    //   1195: aload 26
    //   1197: iload_1
    //   1198: iconst_1
    //   1199: isub
    //   1200: iload_2
    //   1201: iastore
    //   1202: iload_1
    //   1203: iconst_1
    //   1204: isub
    //   1205: istore_1
    //   1206: goto -40 -> 1166
    //   1209: iload_1
    //   1210: iconst_1
    //   1211: isub
    //   1212: istore_1
    //   1213: aload 26
    //   1215: iload_1
    //   1216: iload_2
    //   1217: iastore
    //   1218: goto -47 -> 1171
    //   1221: iload 7
    //   1223: iconst_1
    //   1224: isub
    //   1225: istore_1
    //   1226: iload_1
    //   1227: ifge +104 -> 1331
    //   1230: lload 10
    //   1232: lstore 12
    //   1234: iload_1
    //   1235: istore 5
    //   1237: iload_1
    //   1238: ifge -312 -> 926
    //   1241: iconst_0
    //   1242: istore 5
    //   1244: iload 5
    //   1246: istore_1
    //   1247: iload_2
    //   1248: ifne +68 -> 1316
    //   1251: aload 17
    //   1253: iload 4
    //   1255: iconst_1
    //   1256: isub
    //   1257: baload
    //   1258: istore 6
    //   1260: iload 6
    //   1262: bipush 13
    //   1264: if_icmpeq +13 -> 1277
    //   1267: iload 5
    //   1269: istore_1
    //   1270: iload 6
    //   1272: bipush 10
    //   1274: if_icmpne +42 -> 1316
    //   1277: iconst_1
    //   1278: istore 5
    //   1280: iload 5
    //   1282: istore_1
    //   1283: iload 6
    //   1285: bipush 10
    //   1287: if_icmpne +29 -> 1316
    //   1290: iload 5
    //   1292: istore_1
    //   1293: iload 4
    //   1295: iconst_2
    //   1296: if_icmplt +20 -> 1316
    //   1299: iload 5
    //   1301: istore_1
    //   1302: aload 17
    //   1304: iload 4
    //   1306: iconst_2
    //   1307: isub
    //   1308: baload
    //   1309: bipush 13
    //   1311: if_icmpne +5 -> 1316
    //   1314: iconst_2
    //   1315: istore_1
    //   1316: iload_2
    //   1317: ifne -547 -> 770
    //   1320: lload 10
    //   1322: lstore 12
    //   1324: iload_1
    //   1325: ifle +24 -> 1349
    //   1328: goto -558 -> 770
    //   1331: aload 16
    //   1333: iload_1
    //   1334: baload
    //   1335: aload 23
    //   1337: iload_1
    //   1338: baload
    //   1339: if_icmpne -109 -> 1230
    //   1342: iload_1
    //   1343: iconst_1
    //   1344: isub
    //   1345: istore_1
    //   1346: goto -120 -> 1226
    //   1349: iconst_0
    //   1350: istore 5
    //   1352: goto -426 -> 926
    //   1355: iconst_0
    //   1356: istore_2
    //   1357: lload 12
    //   1359: lstore 10
    //   1361: iload_1
    //   1362: istore 4
    //   1364: goto -719 -> 645
    //   1367: aload 17
    //   1369: iconst_0
    //   1370: aload 16
    //   1372: iconst_0
    //   1373: baload
    //   1374: bastore
    //   1375: iconst_1
    //   1376: istore_1
    //   1377: goto -22 -> 1355
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	1380	0	this	MimeMultipart
    //   263	1114	1	i	int
    //   384	973	2	j	int
    //   484	431	3	k	int
    //   641	722	4	m	int
    //   659	692	5	n	int
    //   798	490	6	i1	int
    //   445	780	7	i2	int
    //   671	437	8	i3	int
    //   6	3	9	bool	boolean
    //   23	1337	10	l1	long
    //   731	627	12	l2	long
    //   20	722	14	l3	long
    //   34	143	16	localObject1	Object
    //   195	9	16	localIOException1	IOException
    //   209	8	16	localObject2	Object
    //   219	5	16	localObject3	Object
    //   226	68	16	localException	Exception
    //   541	583	16	localObject4	Object
    //   1133	238	16	localIOException2	IOException
    //   109	971	17	localObject5	Object
    //   1128	1	17	localIOException3	IOException
    //   1152	1	17	localSecurityException	SecurityException
    //   1156	212	17	str	String
    //   38	1010	18	localObject6	Object
    //   17	1010	19	localSharedInputStream	SharedInputStream
    //   159	955	20	localObject7	Object
    //   276	840	21	localObject8	Object
    //   162	901	22	localObject9	Object
    //   169	1167	23	localObject10	Object
    //   156	381	24	localLineInputStream	com.sun.mail.util.LineInputStream
    //   452	479	25	arrayOfInt1	int[]
    //   466	748	26	arrayOfInt2	int[]
    // Exception table:
    //   from	to	target	type
    //   147	158	195	java/io/IOException
    //   164	171	195	java/io/IOException
    //   185	195	195	java/io/IOException
    //   256	264	195	java/io/IOException
    //   267	278	195	java/io/IOException
    //   291	301	195	java/io/IOException
    //   301	307	195	java/io/IOException
    //   320	329	195	java/io/IOException
    //   338	354	195	java/io/IOException
    //   354	367	195	java/io/IOException
    //   378	385	195	java/io/IOException
    //   400	410	195	java/io/IOException
    //   426	435	195	java/io/IOException
    //   435	454	195	java/io/IOException
    //   462	468	195	java/io/IOException
    //   527	536	195	java/io/IOException
    //   536	543	195	java/io/IOException
    //   548	556	195	java/io/IOException
    //   561	577	195	java/io/IOException
    //   577	582	195	java/io/IOException
    //   585	593	195	java/io/IOException
    //   593	611	195	java/io/IOException
    //   619	628	195	java/io/IOException
    //   628	640	195	java/io/IOException
    //   645	658	195	java/io/IOException
    //   661	673	195	java/io/IOException
    //   680	696	195	java/io/IOException
    //   696	705	195	java/io/IOException
    //   713	722	195	java/io/IOException
    //   722	727	195	java/io/IOException
    //   738	755	195	java/io/IOException
    //   755	761	195	java/io/IOException
    //   775	791	195	java/io/IOException
    //   791	797	195	java/io/IOException
    //   809	824	195	java/io/IOException
    //   836	843	195	java/io/IOException
    //   884	890	195	java/io/IOException
    //   899	914	195	java/io/IOException
    //   926	951	195	java/io/IOException
    //   967	979	195	java/io/IOException
    //   979	991	195	java/io/IOException
    //   1031	1041	195	java/io/IOException
    //   1041	1054	195	java/io/IOException
    //   1077	1090	195	java/io/IOException
    //   1090	1097	195	java/io/IOException
    //   1102	1112	195	java/io/IOException
    //   1112	1125	195	java/io/IOException
    //   147	158	209	finally
    //   164	171	209	finally
    //   185	195	209	finally
    //   197	209	209	finally
    //   256	264	209	finally
    //   267	278	209	finally
    //   291	301	209	finally
    //   301	307	209	finally
    //   320	329	209	finally
    //   338	354	209	finally
    //   354	367	209	finally
    //   378	385	209	finally
    //   400	410	209	finally
    //   426	435	209	finally
    //   435	454	209	finally
    //   462	468	209	finally
    //   527	536	209	finally
    //   536	543	209	finally
    //   548	556	209	finally
    //   561	577	209	finally
    //   577	582	209	finally
    //   585	593	209	finally
    //   593	611	209	finally
    //   619	628	209	finally
    //   628	640	209	finally
    //   645	658	209	finally
    //   661	673	209	finally
    //   680	696	209	finally
    //   696	705	209	finally
    //   713	722	209	finally
    //   722	727	209	finally
    //   738	755	209	finally
    //   755	761	209	finally
    //   775	791	209	finally
    //   791	797	209	finally
    //   809	824	209	finally
    //   836	843	209	finally
    //   884	890	209	finally
    //   899	914	209	finally
    //   926	951	209	finally
    //   967	979	209	finally
    //   979	991	209	finally
    //   1031	1041	209	finally
    //   1041	1054	209	finally
    //   1077	1090	209	finally
    //   1090	1097	209	finally
    //   1102	1112	209	finally
    //   1112	1125	209	finally
    //   2	8	219	finally
    //   25	36	219	finally
    //   40	48	219	finally
    //   52	60	219	finally
    //   64	83	219	finally
    //   83	98	219	finally
    //   98	111	219	finally
    //   114	123	219	finally
    //   128	147	219	finally
    //   211	216	219	finally
    //   216	219	219	finally
    //   228	240	219	finally
    //   240	256	219	finally
    //   489	494	219	finally
    //   494	499	219	finally
    //   25	36	226	java/lang/Exception
    //   40	48	226	java/lang/Exception
    //   52	60	226	java/lang/Exception
    //   64	83	226	java/lang/Exception
    //   211	216	1128	java/io/IOException
    //   489	494	1133	java/io/IOException
    //   320	329	1152	java/lang/SecurityException
  }
  
  private static int readFully(InputStream paramInputStream, byte[] paramArrayOfByte, int paramInt1, int paramInt2)
    throws IOException
  {
    if (paramInt2 == 0)
    {
      paramInt2 = 0;
      return paramInt2;
    }
    int j = 0;
    int i = paramInt1;
    paramInt1 = j;
    for (;;)
    {
      if (paramInt2 <= 0) {}
      do
      {
        paramInt2 = paramInt1;
        if (paramInt1 > 0) {
          break;
        }
        return -1;
        j = paramInputStream.read(paramArrayOfByte, i, paramInt2);
      } while (j <= 0);
      i += j;
      paramInt1 += j;
      paramInt2 -= j;
    }
  }
  
  private void skipFully(InputStream paramInputStream, long paramLong)
    throws IOException
  {
    for (;;)
    {
      if (paramLong <= 0L) {
        return;
      }
      long l = paramInputStream.skip(paramLong);
      if (l <= 0L) {
        throw new EOFException("can't skip");
      }
      paramLong -= l;
    }
  }
  
  public void addBodyPart(BodyPart paramBodyPart)
    throws MessagingException
  {
    try
    {
      parse();
      super.addBodyPart(paramBodyPart);
      return;
    }
    finally
    {
      paramBodyPart = finally;
      throw paramBodyPart;
    }
  }
  
  public void addBodyPart(BodyPart paramBodyPart, int paramInt)
    throws MessagingException
  {
    try
    {
      parse();
      super.addBodyPart(paramBodyPart, paramInt);
      return;
    }
    finally
    {
      paramBodyPart = finally;
      throw paramBodyPart;
    }
  }
  
  protected InternetHeaders createInternetHeaders(InputStream paramInputStream)
    throws MessagingException
  {
    return new InternetHeaders(paramInputStream);
  }
  
  protected MimeBodyPart createMimeBodyPart(InputStream paramInputStream)
    throws MessagingException
  {
    return new MimeBodyPart(paramInputStream);
  }
  
  protected MimeBodyPart createMimeBodyPart(InternetHeaders paramInternetHeaders, byte[] paramArrayOfByte)
    throws MessagingException
  {
    return new MimeBodyPart(paramInternetHeaders, paramArrayOfByte);
  }
  
  public BodyPart getBodyPart(int paramInt)
    throws MessagingException
  {
    try
    {
      parse();
      BodyPart localBodyPart = super.getBodyPart(paramInt);
      return localBodyPart;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  /* Error */
  public BodyPart getBodyPart(String paramString)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual 293	javax/mail/internet/MimeMultipart:parse	()V
    //   6: aload_0
    //   7: invokevirtual 313	javax/mail/internet/MimeMultipart:getCount	()I
    //   10: istore_3
    //   11: iconst_0
    //   12: istore_2
    //   13: iload_2
    //   14: iload_3
    //   15: if_icmplt +11 -> 26
    //   18: aconst_null
    //   19: astore 5
    //   21: aload_0
    //   22: monitorexit
    //   23: aload 5
    //   25: areturn
    //   26: aload_0
    //   27: iload_2
    //   28: invokevirtual 314	javax/mail/internet/MimeMultipart:getBodyPart	(I)Ljavax/mail/BodyPart;
    //   31: checkcast 301	javax/mail/internet/MimeBodyPart
    //   34: astore 5
    //   36: aload 5
    //   38: invokevirtual 317	javax/mail/internet/MimeBodyPart:getContentID	()Ljava/lang/String;
    //   41: astore 6
    //   43: aload 6
    //   45: ifnull +16 -> 61
    //   48: aload 6
    //   50: aload_1
    //   51: invokevirtual 184	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   54: istore 4
    //   56: iload 4
    //   58: ifne -37 -> 21
    //   61: iload_2
    //   62: iconst_1
    //   63: iadd
    //   64: istore_2
    //   65: goto -52 -> 13
    //   68: astore_1
    //   69: aload_0
    //   70: monitorexit
    //   71: aload_1
    //   72: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	73	0	this	MimeMultipart
    //   0	73	1	paramString	String
    //   12	53	2	i	int
    //   10	6	3	j	int
    //   54	3	4	bool	boolean
    //   19	18	5	localObject	Object
    //   41	8	6	str	String
    // Exception table:
    //   from	to	target	type
    //   2	11	68	finally
    //   26	43	68	finally
    //   48	56	68	finally
  }
  
  public int getCount()
    throws MessagingException
  {
    try
    {
      parse();
      int i = super.getCount();
      return i;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public String getPreamble()
    throws MessagingException
  {
    try
    {
      parse();
      String str = this.preamble;
      return str;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public boolean isComplete()
    throws MessagingException
  {
    try
    {
      parse();
      boolean bool = this.complete;
      return bool;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  /* Error */
  protected void parse()
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 57	javax/mail/internet/MimeMultipart:parsed	Z
    //   6: istore 10
    //   8: iload 10
    //   10: ifeq +6 -> 16
    //   13: aload_0
    //   14: monitorexit
    //   15: return
    //   16: getstatic 24	javax/mail/internet/MimeMultipart:bmparse	Z
    //   19: ifeq +17 -> 36
    //   22: aload_0
    //   23: invokespecial 322	javax/mail/internet/MimeMultipart:parsebm	()V
    //   26: goto -13 -> 13
    //   29: astore 17
    //   31: aload_0
    //   32: monitorexit
    //   33: aload 17
    //   35: athrow
    //   36: aconst_null
    //   37: astore 20
    //   39: lconst_0
    //   40: lstore 13
    //   42: lconst_0
    //   43: lstore 11
    //   45: aload_0
    //   46: getfield 55	javax/mail/internet/MimeMultipart:ds	Ljavax/activation/DataSource;
    //   49: invokeinterface 126 1 0
    //   54: astore 17
    //   56: aload 17
    //   58: astore 19
    //   60: aload 17
    //   62: instanceof 128
    //   65: ifne +38 -> 103
    //   68: aload 17
    //   70: astore 19
    //   72: aload 17
    //   74: instanceof 130
    //   77: ifne +26 -> 103
    //   80: aload 17
    //   82: astore 19
    //   84: aload 17
    //   86: instanceof 132
    //   89: ifne +14 -> 103
    //   92: new 130	java/io/BufferedInputStream
    //   95: dup
    //   96: aload 17
    //   98: invokespecial 135	java/io/BufferedInputStream:<init>	(Ljava/io/InputStream;)V
    //   101: astore 19
    //   103: aload 19
    //   105: instanceof 132
    //   108: ifeq +10 -> 118
    //   111: aload 19
    //   113: checkcast 132	javax/mail/internet/SharedInputStream
    //   116: astore 20
    //   118: new 69	javax/mail/internet/ContentType
    //   121: dup
    //   122: aload_0
    //   123: getfield 86	javax/mail/internet/MimeMultipart:contentType	Ljava/lang/String;
    //   126: invokespecial 136	javax/mail/internet/ContentType:<init>	(Ljava/lang/String;)V
    //   129: astore 18
    //   131: aconst_null
    //   132: astore 17
    //   134: aload 18
    //   136: ldc 76
    //   138: invokevirtual 139	javax/mail/internet/ContentType:getParameter	(Ljava/lang/String;)Ljava/lang/String;
    //   141: astore 18
    //   143: aload 18
    //   145: ifnull +108 -> 253
    //   148: new 141	java/lang/StringBuilder
    //   151: dup
    //   152: ldc -113
    //   154: invokespecial 144	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   157: aload 18
    //   159: invokevirtual 148	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   162: invokevirtual 149	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   165: astore 17
    //   167: new 151	com/sun/mail/util/LineInputStream
    //   170: dup
    //   171: aload 19
    //   173: invokespecial 152	com/sun/mail/util/LineInputStream:<init>	(Ljava/io/InputStream;)V
    //   176: astore 25
    //   178: aconst_null
    //   179: astore 21
    //   181: aconst_null
    //   182: astore 23
    //   184: aload 25
    //   186: invokevirtual 155	com/sun/mail/util/LineInputStream:readLine	()Ljava/lang/String;
    //   189: astore 24
    //   191: aload 24
    //   193: ifnonnull +76 -> 269
    //   196: aload 17
    //   198: astore 18
    //   200: aload 24
    //   202: ifnonnull +232 -> 434
    //   205: new 89	javax/mail/MessagingException
    //   208: dup
    //   209: ldc -99
    //   211: invokespecial 158	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   214: athrow
    //   215: astore 17
    //   217: new 89	javax/mail/MessagingException
    //   220: dup
    //   221: ldc -96
    //   223: aload 17
    //   225: invokespecial 163	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   228: athrow
    //   229: astore 17
    //   231: aload 19
    //   233: invokevirtual 168	java/io/InputStream:close	()V
    //   236: aload 17
    //   238: athrow
    //   239: astore 17
    //   241: new 89	javax/mail/MessagingException
    //   244: dup
    //   245: ldc -86
    //   247: aload 17
    //   249: invokespecial 163	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   252: athrow
    //   253: getstatic 22	javax/mail/internet/MimeMultipart:ignoreMissingBoundaryParameter	Z
    //   256: ifne -89 -> 167
    //   259: new 89	javax/mail/MessagingException
    //   262: dup
    //   263: ldc -84
    //   265: invokespecial 158	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   268: athrow
    //   269: aload 24
    //   271: invokevirtual 176	java/lang/String:length	()I
    //   274: iconst_1
    //   275: isub
    //   276: istore_1
    //   277: goto +768 -> 1045
    //   280: aload 24
    //   282: iconst_0
    //   283: iload_1
    //   284: iconst_1
    //   285: iadd
    //   286: invokevirtual 180	java/lang/String:substring	(II)Ljava/lang/String;
    //   289: astore 22
    //   291: aload 17
    //   293: ifnull +120 -> 413
    //   296: aload 17
    //   298: astore 18
    //   300: aload 22
    //   302: astore 24
    //   304: aload 22
    //   306: aload 17
    //   308: invokevirtual 184	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   311: ifne -111 -> 200
    //   314: aload 22
    //   316: invokevirtual 176	java/lang/String:length	()I
    //   319: istore_1
    //   320: iload_1
    //   321: ifle -137 -> 184
    //   324: aload 23
    //   326: astore 18
    //   328: aload 23
    //   330: ifnonnull +12 -> 342
    //   333: ldc -70
    //   335: ldc -68
    //   337: invokestatic 191	java/lang/System:getProperty	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   340: astore 18
    //   342: aload 21
    //   344: astore 24
    //   346: aload 21
    //   348: ifnonnull +19 -> 367
    //   351: new 193	java/lang/StringBuffer
    //   354: dup
    //   355: aload 22
    //   357: invokevirtual 176	java/lang/String:length	()I
    //   360: iconst_2
    //   361: iadd
    //   362: invokespecial 196	java/lang/StringBuffer:<init>	(I)V
    //   365: astore 24
    //   367: aload 24
    //   369: aload 22
    //   371: invokevirtual 199	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   374: aload 18
    //   376: invokevirtual 199	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   379: pop
    //   380: aload 18
    //   382: astore 23
    //   384: aload 24
    //   386: astore 21
    //   388: goto -204 -> 184
    //   391: aload 24
    //   393: iload_1
    //   394: invokevirtual 203	java/lang/String:charAt	(I)C
    //   397: istore_2
    //   398: iload_2
    //   399: bipush 32
    //   401: if_icmpeq +651 -> 1052
    //   404: iload_2
    //   405: bipush 9
    //   407: if_icmpne -127 -> 280
    //   410: goto +642 -> 1052
    //   413: aload 22
    //   415: ldc -113
    //   417: invokevirtual 206	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   420: ifeq -106 -> 314
    //   423: aload 22
    //   425: astore 18
    //   427: aload 22
    //   429: astore 24
    //   431: goto -231 -> 200
    //   434: aload 21
    //   436: ifnull +12 -> 448
    //   439: aload_0
    //   440: aload 21
    //   442: invokevirtual 207	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   445: putfield 61	javax/mail/internet/MimeMultipart:preamble	Ljava/lang/String;
    //   448: aload 18
    //   450: invokestatic 213	com/sun/mail/util/ASCIIUtility:getBytes	(Ljava/lang/String;)[B
    //   453: astore 21
    //   455: aload 21
    //   457: arraylength
    //   458: istore 9
    //   460: iconst_0
    //   461: istore 4
    //   463: iload 4
    //   465: ifeq +16 -> 481
    //   468: aload 19
    //   470: invokevirtual 168	java/io/InputStream:close	()V
    //   473: aload_0
    //   474: iconst_1
    //   475: putfield 57	javax/mail/internet/MimeMultipart:parsed	Z
    //   478: goto -465 -> 13
    //   481: aconst_null
    //   482: astore 17
    //   484: aload 20
    //   486: ifnull +61 -> 547
    //   489: aload 20
    //   491: invokeinterface 217 1 0
    //   496: lstore 13
    //   498: aload 25
    //   500: invokevirtual 155	com/sun/mail/util/LineInputStream:readLine	()Ljava/lang/String;
    //   503: astore 18
    //   505: aload 18
    //   507: ifnull +11 -> 518
    //   510: aload 18
    //   512: invokevirtual 176	java/lang/String:length	()I
    //   515: ifgt -17 -> 498
    //   518: aload 18
    //   520: ifnonnull +35 -> 555
    //   523: getstatic 20	javax/mail/internet/MimeMultipart:ignoreMissingEndBoundary	Z
    //   526: ifne +13 -> 539
    //   529: new 89	javax/mail/MessagingException
    //   532: dup
    //   533: ldc -37
    //   535: invokespecial 158	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   538: athrow
    //   539: aload_0
    //   540: iconst_0
    //   541: putfield 59	javax/mail/internet/MimeMultipart:complete	Z
    //   544: goto -76 -> 468
    //   547: aload_0
    //   548: aload 19
    //   550: invokevirtual 223	javax/mail/internet/MimeMultipart:createInternetHeaders	(Ljava/io/InputStream;)Ljavax/mail/internet/InternetHeaders;
    //   553: astore 17
    //   555: aload 19
    //   557: invokevirtual 227	java/io/InputStream:markSupported	()Z
    //   560: ifne +13 -> 573
    //   563: new 89	javax/mail/MessagingException
    //   566: dup
    //   567: ldc -27
    //   569: invokespecial 158	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   572: athrow
    //   573: aconst_null
    //   574: astore 18
    //   576: aload 20
    //   578: ifnonnull +118 -> 696
    //   581: new 231	java/io/ByteArrayOutputStream
    //   584: dup
    //   585: invokespecial 232	java/io/ByteArrayOutputStream:<init>	()V
    //   588: astore 18
    //   590: goto +478 -> 1068
    //   593: iload_1
    //   594: istore 6
    //   596: iload_2
    //   597: istore 5
    //   599: iload_3
    //   600: ifeq +246 -> 846
    //   603: aload 19
    //   605: iload 9
    //   607: iconst_4
    //   608: iadd
    //   609: sipush 1000
    //   612: iadd
    //   613: invokevirtual 235	java/io/InputStream:mark	(I)V
    //   616: iconst_0
    //   617: istore_3
    //   618: goto +459 -> 1077
    //   621: iload_3
    //   622: iload 9
    //   624: if_icmpne +175 -> 799
    //   627: aload 19
    //   629: invokevirtual 254	java/io/InputStream:read	()I
    //   632: istore_3
    //   633: iload_3
    //   634: istore 5
    //   636: iload_3
    //   637: bipush 45
    //   639: if_icmpne +99 -> 738
    //   642: iload_3
    //   643: istore 5
    //   645: aload 19
    //   647: invokevirtual 254	java/io/InputStream:read	()I
    //   650: bipush 45
    //   652: if_icmpne +86 -> 738
    //   655: aload_0
    //   656: iconst_1
    //   657: putfield 59	javax/mail/internet/MimeMultipart:complete	Z
    //   660: iconst_1
    //   661: istore_3
    //   662: aload 20
    //   664: ifnull +355 -> 1019
    //   667: aload_0
    //   668: aload 20
    //   670: lload 13
    //   672: lload 11
    //   674: invokeinterface 243 5 0
    //   679: invokevirtual 247	javax/mail/internet/MimeMultipart:createMimeBodyPart	(Ljava/io/InputStream;)Ljavax/mail/internet/MimeBodyPart;
    //   682: astore 17
    //   684: aload_0
    //   685: aload 17
    //   687: invokespecial 251	javax/mail/Multipart:addBodyPart	(Ljavax/mail/BodyPart;)V
    //   690: iload_3
    //   691: istore 4
    //   693: goto -230 -> 463
    //   696: aload 20
    //   698: invokeinterface 217 1 0
    //   703: lstore 11
    //   705: goto +363 -> 1068
    //   708: aload 19
    //   710: invokevirtual 254	java/io/InputStream:read	()I
    //   713: aload 21
    //   715: iload_3
    //   716: baload
    //   717: sipush 255
    //   720: iand
    //   721: if_icmpne -100 -> 621
    //   724: iload_3
    //   725: iconst_1
    //   726: iadd
    //   727: istore_3
    //   728: goto +349 -> 1077
    //   731: aload 19
    //   733: invokevirtual 254	java/io/InputStream:read	()I
    //   736: istore 5
    //   738: iload 5
    //   740: bipush 32
    //   742: if_icmpeq -11 -> 731
    //   745: iload 5
    //   747: bipush 9
    //   749: if_icmpeq -18 -> 731
    //   752: iload 4
    //   754: istore_3
    //   755: iload 5
    //   757: bipush 10
    //   759: if_icmpeq -97 -> 662
    //   762: iload 5
    //   764: bipush 13
    //   766: if_icmpne +33 -> 799
    //   769: aload 19
    //   771: iconst_1
    //   772: invokevirtual 235	java/io/InputStream:mark	(I)V
    //   775: iload 4
    //   777: istore_3
    //   778: aload 19
    //   780: invokevirtual 254	java/io/InputStream:read	()I
    //   783: bipush 10
    //   785: if_icmpeq -123 -> 662
    //   788: aload 19
    //   790: invokevirtual 257	java/io/InputStream:reset	()V
    //   793: iload 4
    //   795: istore_3
    //   796: goto -134 -> 662
    //   799: aload 19
    //   801: invokevirtual 257	java/io/InputStream:reset	()V
    //   804: iload_1
    //   805: istore 6
    //   807: iload_2
    //   808: istore 5
    //   810: aload 18
    //   812: ifnull +34 -> 846
    //   815: iload_1
    //   816: istore 6
    //   818: iload_2
    //   819: istore 5
    //   821: iload_1
    //   822: iconst_m1
    //   823: if_icmpeq +23 -> 846
    //   826: aload 18
    //   828: iload_1
    //   829: invokevirtual 324	java/io/ByteArrayOutputStream:write	(I)V
    //   832: iload_2
    //   833: iconst_m1
    //   834: if_icmpeq +252 -> 1086
    //   837: aload 18
    //   839: iload_2
    //   840: invokevirtual 324	java/io/ByteArrayOutputStream:write	(I)V
    //   843: goto +243 -> 1086
    //   846: aload 19
    //   848: invokevirtual 254	java/io/InputStream:read	()I
    //   851: istore 7
    //   853: iload 7
    //   855: ifge +240 -> 1095
    //   858: getstatic 20	javax/mail/internet/MimeMultipart:ignoreMissingEndBoundary	Z
    //   861: ifne +13 -> 874
    //   864: new 89	javax/mail/MessagingException
    //   867: dup
    //   868: ldc -37
    //   870: invokespecial 158	javax/mail/MessagingException:<init>	(Ljava/lang/String;)V
    //   873: athrow
    //   874: aload_0
    //   875: iconst_0
    //   876: putfield 59	javax/mail/internet/MimeMultipart:complete	Z
    //   879: iconst_1
    //   880: istore_3
    //   881: goto -219 -> 662
    //   884: iconst_1
    //   885: istore 8
    //   887: lload 11
    //   889: lstore 15
    //   891: aload 20
    //   893: ifnull +14 -> 907
    //   896: aload 20
    //   898: invokeinterface 217 1 0
    //   903: lconst_1
    //   904: lsub
    //   905: lstore 15
    //   907: iload 7
    //   909: istore 6
    //   911: iload 8
    //   913: istore_3
    //   914: lload 15
    //   916: lstore 11
    //   918: iload 6
    //   920: istore_1
    //   921: iload 5
    //   923: istore_2
    //   924: iload 7
    //   926: bipush 13
    //   928: if_icmpne -335 -> 593
    //   931: aload 19
    //   933: iconst_1
    //   934: invokevirtual 235	java/io/InputStream:mark	(I)V
    //   937: aload 19
    //   939: invokevirtual 254	java/io/InputStream:read	()I
    //   942: istore_2
    //   943: iload_2
    //   944: bipush 10
    //   946: if_icmpne +16 -> 962
    //   949: iload 8
    //   951: istore_3
    //   952: lload 15
    //   954: lstore 11
    //   956: iload 6
    //   958: istore_1
    //   959: goto -366 -> 593
    //   962: aload 19
    //   964: invokevirtual 257	java/io/InputStream:reset	()V
    //   967: iload 8
    //   969: istore_3
    //   970: lload 15
    //   972: lstore 11
    //   974: iload 6
    //   976: istore_1
    //   977: iload 5
    //   979: istore_2
    //   980: goto -387 -> 593
    //   983: iconst_0
    //   984: istore 8
    //   986: iload 8
    //   988: istore_3
    //   989: iload 6
    //   991: istore_1
    //   992: iload 5
    //   994: istore_2
    //   995: aload 18
    //   997: ifnull -404 -> 593
    //   1000: aload 18
    //   1002: iload 7
    //   1004: invokevirtual 324	java/io/ByteArrayOutputStream:write	(I)V
    //   1007: iload 8
    //   1009: istore_3
    //   1010: iload 6
    //   1012: istore_1
    //   1013: iload 5
    //   1015: istore_2
    //   1016: goto -423 -> 593
    //   1019: aload_0
    //   1020: aload 17
    //   1022: aload 18
    //   1024: invokevirtual 275	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   1027: invokevirtual 278	javax/mail/internet/MimeMultipart:createMimeBodyPart	(Ljavax/mail/internet/InternetHeaders;[B)Ljavax/mail/internet/MimeBodyPart;
    //   1030: astore 17
    //   1032: goto -348 -> 684
    //   1035: astore 18
    //   1037: goto -801 -> 236
    //   1040: astore 17
    //   1042: goto -569 -> 473
    //   1045: iload_1
    //   1046: ifge -655 -> 391
    //   1049: goto -769 -> 280
    //   1052: iload_1
    //   1053: iconst_1
    //   1054: isub
    //   1055: istore_1
    //   1056: goto -11 -> 1045
    //   1059: astore 18
    //   1061: ldc -68
    //   1063: astore 18
    //   1065: goto -723 -> 342
    //   1068: iconst_1
    //   1069: istore_3
    //   1070: iconst_m1
    //   1071: istore_1
    //   1072: iconst_m1
    //   1073: istore_2
    //   1074: goto -481 -> 593
    //   1077: iload_3
    //   1078: iload 9
    //   1080: if_icmplt -372 -> 708
    //   1083: goto -462 -> 621
    //   1086: iconst_m1
    //   1087: istore 5
    //   1089: iconst_m1
    //   1090: istore 6
    //   1092: goto -246 -> 846
    //   1095: iload 7
    //   1097: bipush 13
    //   1099: if_icmpeq -215 -> 884
    //   1102: iload 7
    //   1104: bipush 10
    //   1106: if_icmpne -123 -> 983
    //   1109: goto -225 -> 884
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	1112	0	this	MimeMultipart
    //   276	796	1	i	int
    //   397	677	2	j	int
    //   599	482	3	k	int
    //   461	333	4	m	int
    //   597	491	5	n	int
    //   594	497	6	i1	int
    //   851	256	7	i2	int
    //   885	123	8	i3	int
    //   458	623	9	i4	int
    //   6	3	10	bool	boolean
    //   43	930	11	l1	long
    //   40	631	13	l2	long
    //   889	82	15	l3	long
    //   29	5	17	localObject1	Object
    //   54	143	17	localObject2	Object
    //   215	9	17	localIOException1	IOException
    //   229	8	17	localObject3	Object
    //   239	68	17	localException	Exception
    //   482	549	17	localObject4	Object
    //   1040	1	17	localIOException2	IOException
    //   129	894	18	localObject5	Object
    //   1035	1	18	localIOException3	IOException
    //   1059	1	18	localSecurityException	SecurityException
    //   1063	1	18	str1	String
    //   58	905	19	localObject6	Object
    //   37	860	20	localSharedInputStream	SharedInputStream
    //   179	535	21	localObject7	Object
    //   289	139	22	str2	String
    //   182	201	23	localObject8	Object
    //   189	241	24	localObject9	Object
    //   176	323	25	localLineInputStream	com.sun.mail.util.LineInputStream
    // Exception table:
    //   from	to	target	type
    //   2	8	29	finally
    //   16	26	29	finally
    //   45	56	29	finally
    //   60	68	29	finally
    //   72	80	29	finally
    //   84	103	29	finally
    //   103	118	29	finally
    //   118	131	29	finally
    //   134	143	29	finally
    //   148	167	29	finally
    //   231	236	29	finally
    //   236	239	29	finally
    //   241	253	29	finally
    //   253	269	29	finally
    //   468	473	29	finally
    //   473	478	29	finally
    //   167	178	215	java/io/IOException
    //   184	191	215	java/io/IOException
    //   205	215	215	java/io/IOException
    //   269	277	215	java/io/IOException
    //   280	291	215	java/io/IOException
    //   304	314	215	java/io/IOException
    //   314	320	215	java/io/IOException
    //   333	342	215	java/io/IOException
    //   351	367	215	java/io/IOException
    //   367	380	215	java/io/IOException
    //   391	398	215	java/io/IOException
    //   413	423	215	java/io/IOException
    //   439	448	215	java/io/IOException
    //   448	460	215	java/io/IOException
    //   489	498	215	java/io/IOException
    //   498	505	215	java/io/IOException
    //   510	518	215	java/io/IOException
    //   523	539	215	java/io/IOException
    //   539	544	215	java/io/IOException
    //   547	555	215	java/io/IOException
    //   555	573	215	java/io/IOException
    //   581	590	215	java/io/IOException
    //   603	616	215	java/io/IOException
    //   627	633	215	java/io/IOException
    //   645	660	215	java/io/IOException
    //   667	684	215	java/io/IOException
    //   684	690	215	java/io/IOException
    //   696	705	215	java/io/IOException
    //   708	724	215	java/io/IOException
    //   731	738	215	java/io/IOException
    //   769	775	215	java/io/IOException
    //   778	793	215	java/io/IOException
    //   799	804	215	java/io/IOException
    //   826	832	215	java/io/IOException
    //   837	843	215	java/io/IOException
    //   846	853	215	java/io/IOException
    //   858	874	215	java/io/IOException
    //   874	879	215	java/io/IOException
    //   896	907	215	java/io/IOException
    //   931	943	215	java/io/IOException
    //   962	967	215	java/io/IOException
    //   1000	1007	215	java/io/IOException
    //   1019	1032	215	java/io/IOException
    //   167	178	229	finally
    //   184	191	229	finally
    //   205	215	229	finally
    //   217	229	229	finally
    //   269	277	229	finally
    //   280	291	229	finally
    //   304	314	229	finally
    //   314	320	229	finally
    //   333	342	229	finally
    //   351	367	229	finally
    //   367	380	229	finally
    //   391	398	229	finally
    //   413	423	229	finally
    //   439	448	229	finally
    //   448	460	229	finally
    //   489	498	229	finally
    //   498	505	229	finally
    //   510	518	229	finally
    //   523	539	229	finally
    //   539	544	229	finally
    //   547	555	229	finally
    //   555	573	229	finally
    //   581	590	229	finally
    //   603	616	229	finally
    //   627	633	229	finally
    //   645	660	229	finally
    //   667	684	229	finally
    //   684	690	229	finally
    //   696	705	229	finally
    //   708	724	229	finally
    //   731	738	229	finally
    //   769	775	229	finally
    //   778	793	229	finally
    //   799	804	229	finally
    //   826	832	229	finally
    //   837	843	229	finally
    //   846	853	229	finally
    //   858	874	229	finally
    //   874	879	229	finally
    //   896	907	229	finally
    //   931	943	229	finally
    //   962	967	229	finally
    //   1000	1007	229	finally
    //   1019	1032	229	finally
    //   45	56	239	java/lang/Exception
    //   60	68	239	java/lang/Exception
    //   72	80	239	java/lang/Exception
    //   84	103	239	java/lang/Exception
    //   231	236	1035	java/io/IOException
    //   468	473	1040	java/io/IOException
    //   333	342	1059	java/lang/SecurityException
  }
  
  public void removeBodyPart(int paramInt)
    throws MessagingException
  {
    parse();
    super.removeBodyPart(paramInt);
  }
  
  public boolean removeBodyPart(BodyPart paramBodyPart)
    throws MessagingException
  {
    parse();
    return super.removeBodyPart(paramBodyPart);
  }
  
  public void setPreamble(String paramString)
    throws MessagingException
  {
    try
    {
      this.preamble = paramString;
      return;
    }
    finally
    {
      paramString = finally;
      throw paramString;
    }
  }
  
  public void setSubType(String paramString)
    throws MessagingException
  {
    try
    {
      ContentType localContentType = new ContentType(this.contentType);
      localContentType.setSubType(paramString);
      this.contentType = localContentType.toString();
      return;
    }
    finally
    {
      paramString = finally;
      throw paramString;
    }
  }
  
  protected void updateHeaders()
    throws MessagingException
  {
    int i = 0;
    for (;;)
    {
      if (i >= this.parts.size()) {
        return;
      }
      ((MimeBodyPart)this.parts.elementAt(i)).updateHeaders();
      i += 1;
    }
  }
  
  public void writeTo(OutputStream paramOutputStream)
    throws IOException, MessagingException
  {
    for (;;)
    {
      String str;
      LineOutputStream localLineOutputStream;
      try
      {
        parse();
        str = "--" + new ContentType(this.contentType).getParameter("boundary");
        localLineOutputStream = new LineOutputStream(paramOutputStream);
        if (this.preamble == null) {
          break label187;
        }
        byte[] arrayOfByte = ASCIIUtility.getBytes(this.preamble);
        localLineOutputStream.write(arrayOfByte);
        if ((arrayOfByte.length <= 0) || (arrayOfByte[(arrayOfByte.length - 1)] == 13) || (arrayOfByte[(arrayOfByte.length - 1)] == 10)) {
          break label187;
        }
        localLineOutputStream.writeln();
      }
      finally {}
      if (i >= this.parts.size())
      {
        localLineOutputStream.writeln(str + "--");
        return;
      }
      localLineOutputStream.writeln(str);
      ((MimeBodyPart)this.parts.elementAt(i)).writeTo(paramOutputStream);
      localLineOutputStream.writeln();
      i += 1;
      continue;
      label187:
      int i = 0;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/internet/MimeMultipart.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */