package javax.mail.internet;

import java.io.PrintStream;
import java.text.FieldPosition;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.TimeZone;

public class MailDateFormat
  extends SimpleDateFormat
{
  private static Calendar cal = new GregorianCalendar(tz);
  static boolean debug = false;
  private static final long serialVersionUID = -8148227605210628779L;
  private static TimeZone tz = TimeZone.getTimeZone("GMT");
  
  public MailDateFormat()
  {
    super("EEE, d MMM yyyy HH:mm:ss 'XXXXX' (z)", Locale.US);
  }
  
  private static Date ourUTC(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean)
  {
    try
    {
      cal.clear();
      cal.setLenient(paramBoolean);
      cal.set(1, paramInt1);
      cal.set(2, paramInt2);
      cal.set(5, paramInt3);
      cal.set(11, paramInt4);
      cal.set(12, paramInt5 + paramInt7);
      cal.set(13, paramInt6);
      Date localDate = cal.getTime();
      return localDate;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  private static Date parseDate(char[] paramArrayOfChar, ParsePosition paramParsePosition, boolean paramBoolean)
  {
    int j = 0;
    int m = 0;
    for (;;)
    {
      int k;
      int i;
      try
      {
        MailDateParser localMailDateParser = new MailDateParser(paramArrayOfChar);
        localMailDateParser.skipUntilNumber();
        int n = localMailDateParser.parseNumber();
        if (!localMailDateParser.skipIfChar('-')) {
          localMailDateParser.skipWhiteSpace();
        }
        int i1 = localMailDateParser.parseMonth();
        if (!localMailDateParser.skipIfChar('-')) {
          localMailDateParser.skipWhiteSpace();
        }
        k = localMailDateParser.parseNumber();
        if (k < 50)
        {
          i = k + 2000;
          localMailDateParser.skipWhiteSpace();
          int i2 = localMailDateParser.parseNumber();
          localMailDateParser.skipChar(':');
          int i3 = localMailDateParser.parseNumber();
          if (localMailDateParser.skipIfChar(':')) {
            j = localMailDateParser.parseNumber();
          }
          try
          {
            localMailDateParser.skipWhiteSpace();
            k = localMailDateParser.parseTimeZone();
            paramParsePosition.setIndex(localMailDateParser.getIndex());
            return ourUTC(i, i1, n, i2, i3, j, k, paramBoolean);
          }
          catch (ParseException localParseException)
          {
            k = m;
            if (!debug) {
              continue;
            }
            System.out.println("No timezone? : '" + new String(paramArrayOfChar) + "'");
            k = m;
            continue;
          }
        }
        i = k;
      }
      catch (Exception localException)
      {
        if (debug)
        {
          System.out.println("Bad date: '" + new String(paramArrayOfChar) + "'");
          localException.printStackTrace();
        }
        paramParsePosition.setIndex(1);
        return null;
      }
      if (k < 100) {
        i = k + 1900;
      }
    }
  }
  
  public StringBuffer format(Date paramDate, StringBuffer paramStringBuffer, FieldPosition paramFieldPosition)
  {
    int i = paramStringBuffer.length();
    super.format(paramDate, paramStringBuffer, paramFieldPosition);
    i += 25;
    int j;
    if (paramStringBuffer.charAt(i) == 'X')
    {
      this.calendar.clear();
      this.calendar.setTime(paramDate);
      j = this.calendar.get(15) + this.calendar.get(16);
      if (j >= 0) {
        break label210;
      }
      paramStringBuffer.setCharAt(i, '-');
      j = -j;
      i += 1;
    }
    for (;;)
    {
      int k = j / 60 / 1000;
      j = k / 60;
      k %= 60;
      int m = i + 1;
      paramStringBuffer.setCharAt(i, Character.forDigit(j / 10, 10));
      i = m + 1;
      paramStringBuffer.setCharAt(m, Character.forDigit(j % 10, 10));
      j = i + 1;
      paramStringBuffer.setCharAt(i, Character.forDigit(k / 10, 10));
      paramStringBuffer.setCharAt(j, Character.forDigit(k % 10, 10));
      return paramStringBuffer;
      i += 1;
      break;
      label210:
      paramStringBuffer.setCharAt(i, '+');
      i += 1;
    }
  }
  
  public Date parse(String paramString, ParsePosition paramParsePosition)
  {
    return parseDate(paramString.toCharArray(), paramParsePosition, isLenient());
  }
  
  public void setCalendar(Calendar paramCalendar)
  {
    throw new RuntimeException("Method setCalendar() shouldn't be called");
  }
  
  public void setNumberFormat(NumberFormat paramNumberFormat)
  {
    throw new RuntimeException("Method setNumberFormat() shouldn't be called");
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/internet/MailDateFormat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */