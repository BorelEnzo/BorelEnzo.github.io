package javax.mail.internet;

public class ContentDisposition
{
  private String disposition;
  private ParameterList list;
  
  public ContentDisposition() {}
  
  public ContentDisposition(String paramString)
    throws ParseException
  {
    paramString = new HeaderTokenizer(paramString, "()<>@,;:\\\"\t []/?=");
    HeaderTokenizer.Token localToken = paramString.next();
    if (localToken.getType() != -1) {
      throw new ParseException();
    }
    this.disposition = localToken.getValue();
    paramString = paramString.getRemainder();
    if (paramString != null) {
      this.list = new ParameterList(paramString);
    }
  }
  
  public ContentDisposition(String paramString, ParameterList paramParameterList)
  {
    this.disposition = paramString;
    this.list = paramParameterList;
  }
  
  public String getDisposition()
  {
    return this.disposition;
  }
  
  public String getParameter(String paramString)
  {
    if (this.list == null) {
      return null;
    }
    return this.list.get(paramString);
  }
  
  public ParameterList getParameterList()
  {
    return this.list;
  }
  
  public void setDisposition(String paramString)
  {
    this.disposition = paramString;
  }
  
  public void setParameter(String paramString1, String paramString2)
  {
    if (this.list == null) {
      this.list = new ParameterList();
    }
    this.list.set(paramString1, paramString2);
  }
  
  public void setParameterList(ParameterList paramParameterList)
  {
    this.list = paramParameterList;
  }
  
  public String toString()
  {
    if (this.disposition == null) {
      return null;
    }
    if (this.list == null) {
      return this.disposition;
    }
    StringBuffer localStringBuffer = new StringBuffer(this.disposition);
    localStringBuffer.append(this.list.toString(localStringBuffer.length() + 21));
    return localStringBuffer.toString();
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/internet/ContentDisposition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */