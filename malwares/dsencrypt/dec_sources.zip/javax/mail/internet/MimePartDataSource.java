package javax.mail.internet;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.UnknownServiceException;
import javax.activation.DataSource;
import javax.mail.MessageAware;
import javax.mail.MessageContext;
import javax.mail.MessagingException;

public class MimePartDataSource
  implements DataSource, MessageAware
{
  private static boolean ignoreMultipartEncoding;
  private MessageContext context;
  protected MimePart part;
  
  static
  {
    boolean bool2 = true;
    ignoreMultipartEncoding = true;
    try
    {
      String str = System.getProperty("mail.mime.ignoremultipartencoding");
      boolean bool1 = bool2;
      if (str != null)
      {
        bool1 = bool2;
        if (str.equalsIgnoreCase("false")) {
          bool1 = false;
        }
      }
      ignoreMultipartEncoding = bool1;
      return;
    }
    catch (SecurityException localSecurityException) {}
  }
  
  public MimePartDataSource(MimePart paramMimePart)
  {
    this.part = paramMimePart;
  }
  
  private static String restrictEncoding(String paramString, MimePart paramMimePart)
    throws MessagingException
  {
    if ((!ignoreMultipartEncoding) || (paramString == null)) {}
    for (;;)
    {
      return paramString;
      if ((!paramString.equalsIgnoreCase("7bit")) && (!paramString.equalsIgnoreCase("8bit")) && (!paramString.equalsIgnoreCase("binary")))
      {
        paramMimePart = paramMimePart.getContentType();
        if (paramMimePart != null) {
          try
          {
            paramMimePart = new ContentType(paramMimePart);
            if (!paramMimePart.match("multipart/*"))
            {
              boolean bool = paramMimePart.match("message/*");
              if (!bool) {}
            }
            else
            {
              return null;
            }
          }
          catch (ParseException paramMimePart) {}
        }
      }
    }
    return paramString;
  }
  
  public String getContentType()
  {
    try
    {
      String str = this.part.getContentType();
      return str;
    }
    catch (MessagingException localMessagingException) {}
    return "application/octet-stream";
  }
  
  public InputStream getInputStream()
    throws IOException
  {
    try
    {
      if ((this.part instanceof MimeBodyPart)) {}
      for (InputStream localInputStream = ((MimeBodyPart)this.part).getContentStream();; localInputStream = ((MimeMessage)this.part).getContentStream())
      {
        String str = restrictEncoding(this.part.getEncoding(), this.part);
        if (str == null) {
          return localInputStream;
        }
        return MimeUtility.decode(localInputStream, str);
        if (!(this.part instanceof MimeMessage)) {
          break;
        }
      }
      throw new MessagingException("Unknown part");
    }
    catch (MessagingException localMessagingException)
    {
      throw new IOException(localMessagingException.getMessage());
    }
    return localMessagingException;
  }
  
  public MessageContext getMessageContext()
  {
    try
    {
      if (this.context == null) {
        this.context = new MessageContext(this.part);
      }
      MessageContext localMessageContext = this.context;
      return localMessageContext;
    }
    finally {}
  }
  
  public String getName()
  {
    try
    {
      if ((this.part instanceof MimeBodyPart))
      {
        String str = ((MimeBodyPart)this.part).getFileName();
        return str;
      }
    }
    catch (MessagingException localMessagingException) {}
    return "";
  }
  
  public OutputStream getOutputStream()
    throws IOException
  {
    throw new UnknownServiceException();
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/internet/MimePartDataSource.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */