package javax.mail.internet;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class ParameterList
{
  private static boolean applehack = false;
  private static boolean decodeParameters;
  private static boolean decodeParametersStrict;
  private static boolean encodeParameters;
  private static final char[] hex;
  private String lastName = null;
  private Map list = new LinkedHashMap();
  private Set multisegmentNames;
  private Map slist;
  
  static
  {
    boolean bool2 = true;
    encodeParameters = false;
    decodeParameters = false;
    decodeParametersStrict = false;
    for (;;)
    {
      try
      {
        String str = System.getProperty("mail.mime.encodeparameters");
        if ((str == null) || (!str.equalsIgnoreCase("true"))) {
          continue;
        }
        bool1 = true;
        encodeParameters = bool1;
        str = System.getProperty("mail.mime.decodeparameters");
        if ((str == null) || (!str.equalsIgnoreCase("true"))) {
          continue;
        }
        bool1 = true;
        decodeParameters = bool1;
        str = System.getProperty("mail.mime.decodeparameters.strict");
        if ((str == null) || (!str.equalsIgnoreCase("true"))) {
          continue;
        }
        bool1 = true;
        decodeParametersStrict = bool1;
        str = System.getProperty("mail.mime.applefilenames");
        if ((str == null) || (!str.equalsIgnoreCase("true"))) {
          continue;
        }
        bool1 = bool2;
        applehack = bool1;
      }
      catch (SecurityException localSecurityException)
      {
        boolean bool1;
        continue;
      }
      hex = new char[] { 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 65, 66, 67, 68, 69, 70 };
      return;
      bool1 = false;
      continue;
      bool1 = false;
      continue;
      bool1 = false;
      continue;
      bool1 = false;
    }
  }
  
  public ParameterList()
  {
    if (decodeParameters)
    {
      this.multisegmentNames = new HashSet();
      this.slist = new HashMap();
    }
  }
  
  public ParameterList(String paramString)
    throws ParseException
  {
    this();
    paramString = new HeaderTokenizer(paramString, "()<>@,;:\\\"\t []/?=");
    Object localObject1;
    for (;;)
    {
      localObject1 = paramString.next();
      int i = ((HeaderTokenizer.Token)localObject1).getType();
      if (i == -4) {}
      do
      {
        if (decodeParameters) {
          combineMultisegmentNames(false);
        }
        return;
        if ((char)i != ';') {
          break;
        }
        localObject1 = paramString.next();
      } while (((HeaderTokenizer.Token)localObject1).getType() == -4);
      if (((HeaderTokenizer.Token)localObject1).getType() != -1) {
        throw new ParseException("Expected parameter name, got \"" + ((HeaderTokenizer.Token)localObject1).getValue() + "\"");
      }
      localObject1 = ((HeaderTokenizer.Token)localObject1).getValue().toLowerCase(Locale.ENGLISH);
      Object localObject2 = paramString.next();
      if ((char)((HeaderTokenizer.Token)localObject2).getType() != '=') {
        throw new ParseException("Expected '=', got \"" + ((HeaderTokenizer.Token)localObject2).getValue() + "\"");
      }
      localObject2 = paramString.next();
      i = ((HeaderTokenizer.Token)localObject2).getType();
      if ((i != -1) && (i != -2)) {
        throw new ParseException("Expected parameter value, got \"" + ((HeaderTokenizer.Token)localObject2).getValue() + "\"");
      }
      localObject2 = ((HeaderTokenizer.Token)localObject2).getValue();
      this.lastName = ((String)localObject1);
      if (decodeParameters)
      {
        putEncodedName((String)localObject1, (String)localObject2);
      }
      else
      {
        this.list.put(localObject1, localObject2);
        continue;
        if ((!applehack) || (i != -1) || (this.lastName == null) || ((!this.lastName.equals("name")) && (!this.lastName.equals("filename")))) {
          break;
        }
        localObject1 = (String)this.list.get(this.lastName) + " " + ((HeaderTokenizer.Token)localObject1).getValue();
        this.list.put(this.lastName, localObject1);
      }
    }
    throw new ParseException("Expected ';', got \"" + ((HeaderTokenizer.Token)localObject1).getValue() + "\"");
  }
  
  /* Error */
  private void combineMultisegmentNames(boolean paramBoolean)
    throws ParseException
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 98	javax/mail/internet/ParameterList:multisegmentNames	Ljava/util/Set;
    //   4: invokeinterface 208 1 0
    //   9: astore 11
    //   11: aload 11
    //   13: invokeinterface 214 1 0
    //   18: istore_3
    //   19: iload_3
    //   20: ifne +81 -> 101
    //   23: iload_1
    //   24: ifne +7 -> 31
    //   27: iconst_1
    //   28: ifeq +72 -> 100
    //   31: aload_0
    //   32: getfield 103	javax/mail/internet/ParameterList:slist	Ljava/util/Map;
    //   35: invokeinterface 217 1 0
    //   40: ifle +42 -> 82
    //   43: aload_0
    //   44: getfield 103	javax/mail/internet/ParameterList:slist	Ljava/util/Map;
    //   47: invokeinterface 221 1 0
    //   52: invokeinterface 224 1 0
    //   57: astore 4
    //   59: aload 4
    //   61: invokeinterface 214 1 0
    //   66: ifne +669 -> 735
    //   69: aload_0
    //   70: getfield 91	javax/mail/internet/ParameterList:list	Ljava/util/Map;
    //   73: aload_0
    //   74: getfield 103	javax/mail/internet/ParameterList:slist	Ljava/util/Map;
    //   77: invokeinterface 228 2 0
    //   82: aload_0
    //   83: getfield 98	javax/mail/internet/ParameterList:multisegmentNames	Ljava/util/Set;
    //   86: invokeinterface 231 1 0
    //   91: aload_0
    //   92: getfield 103	javax/mail/internet/ParameterList:slist	Ljava/util/Map;
    //   95: invokeinterface 232 1 0
    //   100: return
    //   101: aload 11
    //   103: invokeinterface 235 1 0
    //   108: checkcast 54	java/lang/String
    //   111: astore 12
    //   113: new 237	java/lang/StringBuffer
    //   116: dup
    //   117: invokespecial 238	java/lang/StringBuffer:<init>	()V
    //   120: astore 13
    //   122: new 6	javax/mail/internet/ParameterList$MultiValue
    //   125: dup
    //   126: aconst_null
    //   127: invokespecial 241	javax/mail/internet/ParameterList$MultiValue:<init>	(Ljavax/mail/internet/ParameterList$MultiValue;)V
    //   130: astore 14
    //   132: iconst_0
    //   133: istore_2
    //   134: aconst_null
    //   135: astore 5
    //   137: new 130	java/lang/StringBuilder
    //   140: dup
    //   141: aload 12
    //   143: invokestatic 187	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   146: invokespecial 134	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   149: ldc -13
    //   151: invokevirtual 142	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   154: iload_2
    //   155: invokevirtual 246	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   158: invokevirtual 147	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   161: astore 15
    //   163: aload_0
    //   164: getfield 103	javax/mail/internet/ParameterList:slist	Ljava/util/Map;
    //   167: aload 15
    //   169: invokeinterface 183 2 0
    //   174: astore 16
    //   176: aload 16
    //   178: ifnonnull +104 -> 282
    //   181: iload_2
    //   182: ifne +469 -> 651
    //   185: aload_0
    //   186: getfield 91	javax/mail/internet/ParameterList:list	Ljava/util/Map;
    //   189: aload 12
    //   191: invokeinterface 249 2 0
    //   196: pop
    //   197: goto -186 -> 11
    //   200: astore 4
    //   202: iload_1
    //   203: ifne +7 -> 210
    //   206: iconst_0
    //   207: ifeq +72 -> 279
    //   210: aload_0
    //   211: getfield 103	javax/mail/internet/ParameterList:slist	Ljava/util/Map;
    //   214: invokeinterface 217 1 0
    //   219: ifle +42 -> 261
    //   222: aload_0
    //   223: getfield 103	javax/mail/internet/ParameterList:slist	Ljava/util/Map;
    //   226: invokeinterface 221 1 0
    //   231: invokeinterface 224 1 0
    //   236: astore 5
    //   238: aload 5
    //   240: invokeinterface 214 1 0
    //   245: ifne +433 -> 678
    //   248: aload_0
    //   249: getfield 91	javax/mail/internet/ParameterList:list	Ljava/util/Map;
    //   252: aload_0
    //   253: getfield 103	javax/mail/internet/ParameterList:slist	Ljava/util/Map;
    //   256: invokeinterface 228 2 0
    //   261: aload_0
    //   262: getfield 98	javax/mail/internet/ParameterList:multisegmentNames	Ljava/util/Set;
    //   265: invokeinterface 231 1 0
    //   270: aload_0
    //   271: getfield 103	javax/mail/internet/ParameterList:slist	Ljava/util/Map;
    //   274: invokeinterface 232 1 0
    //   279: aload 4
    //   281: athrow
    //   282: aload 14
    //   284: aload 16
    //   286: invokevirtual 252	javax/mail/internet/ParameterList$MultiValue:add	(Ljava/lang/Object;)Z
    //   289: pop
    //   290: aconst_null
    //   291: astore 6
    //   293: aconst_null
    //   294: astore 10
    //   296: aconst_null
    //   297: astore 4
    //   299: aload 16
    //   301: instanceof 15
    //   304: istore_3
    //   305: iload_3
    //   306: ifeq +327 -> 633
    //   309: aload 4
    //   311: astore 8
    //   313: aload 6
    //   315: astore 9
    //   317: aload 10
    //   319: astore 7
    //   321: aload 16
    //   323: checkcast 15	javax/mail/internet/ParameterList$Value
    //   326: astore 16
    //   328: aload 4
    //   330: astore 8
    //   332: aload 6
    //   334: astore 9
    //   336: aload 10
    //   338: astore 7
    //   340: aload 16
    //   342: getfield 255	javax/mail/internet/ParameterList$Value:encodedValue	Ljava/lang/String;
    //   345: astore 6
    //   347: aload 6
    //   349: astore 4
    //   351: iload_2
    //   352: ifne +109 -> 461
    //   355: aload 4
    //   357: astore 8
    //   359: aload 4
    //   361: astore 9
    //   363: aload 4
    //   365: astore 7
    //   367: aload 6
    //   369: invokestatic 259	javax/mail/internet/ParameterList:decodeValue	(Ljava/lang/String;)Ljavax/mail/internet/ParameterList$Value;
    //   372: astore 10
    //   374: aload 4
    //   376: astore 8
    //   378: aload 4
    //   380: astore 9
    //   382: aload 4
    //   384: astore 7
    //   386: aload 10
    //   388: getfield 262	javax/mail/internet/ParameterList$Value:charset	Ljava/lang/String;
    //   391: astore 6
    //   393: aload 4
    //   395: astore 8
    //   397: aload 4
    //   399: astore 9
    //   401: aload 4
    //   403: astore 7
    //   405: aload 16
    //   407: aload 6
    //   409: putfield 262	javax/mail/internet/ParameterList$Value:charset	Ljava/lang/String;
    //   412: aload 10
    //   414: getfield 265	javax/mail/internet/ParameterList$Value:value	Ljava/lang/String;
    //   417: astore 5
    //   419: aload 16
    //   421: aload 5
    //   423: putfield 265	javax/mail/internet/ParameterList$Value:value	Ljava/lang/String;
    //   426: aload 6
    //   428: astore 4
    //   430: aload 13
    //   432: aload 5
    //   434: invokevirtual 268	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   437: pop
    //   438: aload_0
    //   439: getfield 103	javax/mail/internet/ParameterList:slist	Ljava/util/Map;
    //   442: aload 15
    //   444: invokeinterface 249 2 0
    //   449: pop
    //   450: iload_2
    //   451: iconst_1
    //   452: iadd
    //   453: istore_2
    //   454: aload 4
    //   456: astore 5
    //   458: goto -321 -> 137
    //   461: aload 5
    //   463: ifnonnull +63 -> 526
    //   466: aload 4
    //   468: astore 8
    //   470: aload 4
    //   472: astore 9
    //   474: aload 4
    //   476: astore 7
    //   478: aload_0
    //   479: getfield 98	javax/mail/internet/ParameterList:multisegmentNames	Ljava/util/Set;
    //   482: aload 12
    //   484: invokeinterface 270 2 0
    //   489: pop
    //   490: goto -309 -> 181
    //   493: astore 7
    //   495: aload 5
    //   497: astore 6
    //   499: aload 8
    //   501: astore 5
    //   503: aload 6
    //   505: astore 4
    //   507: getstatic 40	javax/mail/internet/ParameterList:decodeParametersStrict	Z
    //   510: ifeq -80 -> 430
    //   513: new 106	javax/mail/internet/ParseException
    //   516: dup
    //   517: aload 7
    //   519: invokevirtual 271	java/lang/NumberFormatException:toString	()Ljava/lang/String;
    //   522: invokespecial 148	javax/mail/internet/ParseException:<init>	(Ljava/lang/String;)V
    //   525: athrow
    //   526: aload 4
    //   528: astore 8
    //   530: aload 4
    //   532: astore 9
    //   534: aload 4
    //   536: astore 7
    //   538: aload 6
    //   540: aload 5
    //   542: invokestatic 275	javax/mail/internet/ParameterList:decodeBytes	(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   545: astore 6
    //   547: aload 4
    //   549: astore 8
    //   551: aload 4
    //   553: astore 9
    //   555: aload 4
    //   557: astore 7
    //   559: aload 16
    //   561: aload 6
    //   563: putfield 265	javax/mail/internet/ParameterList$Value:value	Ljava/lang/String;
    //   566: aload 5
    //   568: astore 4
    //   570: aload 6
    //   572: astore 5
    //   574: goto -144 -> 430
    //   577: astore 7
    //   579: aload 5
    //   581: astore 6
    //   583: aload 9
    //   585: astore 5
    //   587: aload 6
    //   589: astore 4
    //   591: getstatic 40	javax/mail/internet/ParameterList:decodeParametersStrict	Z
    //   594: ifeq -164 -> 430
    //   597: new 106	javax/mail/internet/ParseException
    //   600: dup
    //   601: aload 7
    //   603: invokevirtual 276	java/io/UnsupportedEncodingException:toString	()Ljava/lang/String;
    //   606: invokespecial 148	javax/mail/internet/ParseException:<init>	(Ljava/lang/String;)V
    //   609: athrow
    //   610: aload 6
    //   612: astore 4
    //   614: getstatic 40	javax/mail/internet/ParameterList:decodeParametersStrict	Z
    //   617: ifeq -187 -> 430
    //   620: new 106	javax/mail/internet/ParseException
    //   623: dup
    //   624: aload 8
    //   626: invokevirtual 277	java/lang/StringIndexOutOfBoundsException:toString	()Ljava/lang/String;
    //   629: invokespecial 148	javax/mail/internet/ParseException:<init>	(Ljava/lang/String;)V
    //   632: athrow
    //   633: aload 16
    //   635: checkcast 54	java/lang/String
    //   638: astore 6
    //   640: aload 5
    //   642: astore 4
    //   644: aload 6
    //   646: astore 5
    //   648: goto -218 -> 430
    //   651: aload 14
    //   653: aload 13
    //   655: invokevirtual 278	java/lang/StringBuffer:toString	()Ljava/lang/String;
    //   658: putfield 279	javax/mail/internet/ParameterList$MultiValue:value	Ljava/lang/String;
    //   661: aload_0
    //   662: getfield 91	javax/mail/internet/ParameterList:list	Ljava/util/Map;
    //   665: aload 12
    //   667: aload 14
    //   669: invokeinterface 171 3 0
    //   674: pop
    //   675: goto -664 -> 11
    //   678: aload 5
    //   680: invokeinterface 235 1 0
    //   685: astore 6
    //   687: aload 6
    //   689: instanceof 15
    //   692: ifeq -454 -> 238
    //   695: aload 6
    //   697: checkcast 15	javax/mail/internet/ParameterList$Value
    //   700: astore 6
    //   702: aload 6
    //   704: getfield 255	javax/mail/internet/ParameterList$Value:encodedValue	Ljava/lang/String;
    //   707: invokestatic 259	javax/mail/internet/ParameterList:decodeValue	(Ljava/lang/String;)Ljavax/mail/internet/ParameterList$Value;
    //   710: astore 7
    //   712: aload 6
    //   714: aload 7
    //   716: getfield 262	javax/mail/internet/ParameterList$Value:charset	Ljava/lang/String;
    //   719: putfield 262	javax/mail/internet/ParameterList$Value:charset	Ljava/lang/String;
    //   722: aload 6
    //   724: aload 7
    //   726: getfield 265	javax/mail/internet/ParameterList$Value:value	Ljava/lang/String;
    //   729: putfield 265	javax/mail/internet/ParameterList$Value:value	Ljava/lang/String;
    //   732: goto -494 -> 238
    //   735: aload 4
    //   737: invokeinterface 235 1 0
    //   742: astore 5
    //   744: aload 5
    //   746: instanceof 15
    //   749: ifeq -690 -> 59
    //   752: aload 5
    //   754: checkcast 15	javax/mail/internet/ParameterList$Value
    //   757: astore 5
    //   759: aload 5
    //   761: getfield 255	javax/mail/internet/ParameterList$Value:encodedValue	Ljava/lang/String;
    //   764: invokestatic 259	javax/mail/internet/ParameterList:decodeValue	(Ljava/lang/String;)Ljavax/mail/internet/ParameterList$Value;
    //   767: astore 6
    //   769: aload 5
    //   771: aload 6
    //   773: getfield 262	javax/mail/internet/ParameterList$Value:charset	Ljava/lang/String;
    //   776: putfield 262	javax/mail/internet/ParameterList$Value:charset	Ljava/lang/String;
    //   779: aload 5
    //   781: aload 6
    //   783: getfield 265	javax/mail/internet/ParameterList$Value:value	Ljava/lang/String;
    //   786: putfield 265	javax/mail/internet/ParameterList$Value:value	Ljava/lang/String;
    //   789: goto -730 -> 59
    //   792: astore 8
    //   794: aload 4
    //   796: astore 5
    //   798: goto -188 -> 610
    //   801: astore 7
    //   803: aload 4
    //   805: astore 5
    //   807: goto -220 -> 587
    //   810: astore 7
    //   812: aload 4
    //   814: astore 5
    //   816: goto -313 -> 503
    //   819: astore 8
    //   821: aload 5
    //   823: astore 6
    //   825: aload 7
    //   827: astore 5
    //   829: goto -219 -> 610
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	832	0	this	ParameterList
    //   0	832	1	paramBoolean	boolean
    //   133	321	2	i	int
    //   18	288	3	bool	boolean
    //   57	3	4	localIterator1	Iterator
    //   200	80	4	localObject1	Object
    //   297	516	4	localObject2	Object
    //   135	693	5	localObject3	Object
    //   291	533	6	localObject4	Object
    //   319	158	7	localObject5	Object
    //   493	25	7	localNumberFormatException1	NumberFormatException
    //   536	22	7	localObject6	Object
    //   577	25	7	localUnsupportedEncodingException1	UnsupportedEncodingException
    //   710	15	7	localValue1	Value
    //   801	1	7	localUnsupportedEncodingException2	UnsupportedEncodingException
    //   810	16	7	localNumberFormatException2	NumberFormatException
    //   311	314	8	localObject7	Object
    //   792	1	8	localStringIndexOutOfBoundsException1	StringIndexOutOfBoundsException
    //   819	1	8	localStringIndexOutOfBoundsException2	StringIndexOutOfBoundsException
    //   315	269	9	localObject8	Object
    //   294	119	10	localValue2	Value
    //   9	93	11	localIterator2	Iterator
    //   111	555	12	str1	String
    //   120	534	13	localStringBuffer	StringBuffer
    //   130	538	14	localMultiValue	MultiValue
    //   161	282	15	str2	String
    //   174	460	16	localObject9	Object
    // Exception table:
    //   from	to	target	type
    //   0	11	200	finally
    //   11	19	200	finally
    //   101	132	200	finally
    //   137	176	200	finally
    //   185	197	200	finally
    //   282	290	200	finally
    //   299	305	200	finally
    //   321	328	200	finally
    //   340	347	200	finally
    //   367	374	200	finally
    //   386	393	200	finally
    //   405	412	200	finally
    //   412	426	200	finally
    //   430	450	200	finally
    //   478	490	200	finally
    //   507	526	200	finally
    //   538	547	200	finally
    //   559	566	200	finally
    //   591	610	200	finally
    //   614	633	200	finally
    //   633	640	200	finally
    //   651	675	200	finally
    //   321	328	493	java/lang/NumberFormatException
    //   340	347	493	java/lang/NumberFormatException
    //   367	374	493	java/lang/NumberFormatException
    //   386	393	493	java/lang/NumberFormatException
    //   405	412	493	java/lang/NumberFormatException
    //   478	490	493	java/lang/NumberFormatException
    //   538	547	493	java/lang/NumberFormatException
    //   559	566	493	java/lang/NumberFormatException
    //   321	328	577	java/io/UnsupportedEncodingException
    //   340	347	577	java/io/UnsupportedEncodingException
    //   367	374	577	java/io/UnsupportedEncodingException
    //   386	393	577	java/io/UnsupportedEncodingException
    //   405	412	577	java/io/UnsupportedEncodingException
    //   478	490	577	java/io/UnsupportedEncodingException
    //   538	547	577	java/io/UnsupportedEncodingException
    //   559	566	577	java/io/UnsupportedEncodingException
    //   412	426	792	java/lang/StringIndexOutOfBoundsException
    //   412	426	801	java/io/UnsupportedEncodingException
    //   412	426	810	java/lang/NumberFormatException
    //   321	328	819	java/lang/StringIndexOutOfBoundsException
    //   340	347	819	java/lang/StringIndexOutOfBoundsException
    //   367	374	819	java/lang/StringIndexOutOfBoundsException
    //   386	393	819	java/lang/StringIndexOutOfBoundsException
    //   405	412	819	java/lang/StringIndexOutOfBoundsException
    //   478	490	819	java/lang/StringIndexOutOfBoundsException
    //   538	547	819	java/lang/StringIndexOutOfBoundsException
    //   559	566	819	java/lang/StringIndexOutOfBoundsException
  }
  
  private static String decodeBytes(String paramString1, String paramString2)
    throws UnsupportedEncodingException
  {
    byte[] arrayOfByte = new byte[paramString1.length()];
    int i = 0;
    int j = 0;
    for (;;)
    {
      if (i >= paramString1.length()) {
        return new String(arrayOfByte, 0, j, MimeUtility.javaCharset(paramString2));
      }
      int n = paramString1.charAt(i);
      int m = n;
      int k = i;
      if (n == 37)
      {
        m = (char)Integer.parseInt(paramString1.substring(i + 1, i + 3), 16);
        k = i + 2;
      }
      arrayOfByte[j] = ((byte)m);
      i = k + 1;
      j += 1;
    }
  }
  
  private static Value decodeValue(String paramString)
    throws ParseException
  {
    Value localValue = new Value(null);
    localValue.encodedValue = paramString;
    localValue.value = paramString;
    try
    {
      i = paramString.indexOf('\'');
      if (i <= 0)
      {
        if (!decodeParametersStrict) {
          break label185;
        }
        throw new ParseException("Missing charset in encoded value: " + paramString);
      }
    }
    catch (NumberFormatException paramString)
    {
      if (decodeParametersStrict)
      {
        throw new ParseException(paramString.toString());
        str = paramString.substring(0, i);
        j = paramString.indexOf('\'', i + 1);
        if (j < 0)
        {
          if (!decodeParametersStrict) {
            break label185;
          }
          throw new ParseException("Missing language in encoded value: " + paramString);
        }
      }
    }
    catch (UnsupportedEncodingException paramString)
    {
      int i;
      String str;
      int j;
      if (decodeParametersStrict)
      {
        throw new ParseException(paramString.toString());
        paramString.substring(i + 1, j);
        paramString = paramString.substring(j + 1);
        localValue.charset = str;
        localValue.value = decodeBytes(paramString, str);
      }
      return localValue;
    }
    catch (StringIndexOutOfBoundsException paramString)
    {
      label185:
      while (!decodeParametersStrict) {}
      throw new ParseException(paramString.toString());
    }
  }
  
  private static Value encodeValue(String paramString1, String paramString2)
  {
    if (MimeUtility.checkAscii(paramString1) == 1) {
      return null;
    }
    Object localObject;
    StringBuffer localStringBuffer;
    int i;
    try
    {
      localObject = paramString1.getBytes(MimeUtility.javaCharset(paramString2));
      localStringBuffer = new StringBuffer(localObject.length + paramString2.length() + 2);
      localStringBuffer.append(paramString2).append("''");
      i = 0;
      if (i >= localObject.length)
      {
        localObject = new Value(null);
        ((Value)localObject).charset = paramString2;
        ((Value)localObject).value = paramString1;
        ((Value)localObject).encodedValue = localStringBuffer.toString();
        return (Value)localObject;
      }
    }
    catch (UnsupportedEncodingException paramString1)
    {
      return null;
    }
    char c = (char)(localObject[i] & 0xFF);
    if ((c <= ' ') || (c >= '') || (c == '*') || (c == '\'') || (c == '%') || ("()<>@,;:\\\"\t []/?=".indexOf(c) >= 0)) {
      localStringBuffer.append('%').append(hex[(c >> '\004')]).append(hex[(c & 0xF)]);
    }
    for (;;)
    {
      i += 1;
      break;
      localStringBuffer.append(c);
    }
  }
  
  private void putEncodedName(String paramString1, String paramString2)
    throws ParseException
  {
    int i = paramString1.indexOf('*');
    if (i < 0)
    {
      this.list.put(paramString1, paramString2);
      return;
    }
    if (i == paramString1.length() - 1)
    {
      paramString1 = paramString1.substring(0, i);
      this.list.put(paramString1, decodeValue(paramString2));
      return;
    }
    Object localObject = paramString1.substring(0, i);
    this.multisegmentNames.add(localObject);
    this.list.put(localObject, "");
    if (paramString1.endsWith("*"))
    {
      localObject = new Value(null);
      ((Value)localObject).encodedValue = paramString2;
      ((Value)localObject).value = paramString2;
      paramString1 = paramString1.substring(0, paramString1.length() - 1);
      paramString2 = (String)localObject;
    }
    for (;;)
    {
      this.slist.put(paramString1, paramString2);
      return;
    }
  }
  
  private static String quote(String paramString)
  {
    return MimeUtility.quote(paramString, "()<>@,;:\\\"\t []/?=");
  }
  
  public String get(String paramString)
  {
    paramString = this.list.get(paramString.trim().toLowerCase(Locale.ENGLISH));
    if ((paramString instanceof MultiValue)) {
      return ((MultiValue)paramString).value;
    }
    if ((paramString instanceof Value)) {
      return ((Value)paramString).value;
    }
    return (String)paramString;
  }
  
  public Enumeration getNames()
  {
    return new ParamEnum(this.list.keySet().iterator());
  }
  
  public void remove(String paramString)
  {
    this.list.remove(paramString.trim().toLowerCase(Locale.ENGLISH));
  }
  
  public void set(String paramString1, String paramString2)
  {
    if ((paramString1 != null) || (paramString2 == null) || (!paramString2.equals("DONE")) || ((decodeParameters) && (this.multisegmentNames.size() > 0))) {}
    try
    {
      combineMultisegmentNames(true);
      return;
    }
    catch (ParseException paramString1) {}
    paramString1 = paramString1.trim().toLowerCase(Locale.ENGLISH);
    if (decodeParameters) {
      try
      {
        putEncodedName(paramString1, paramString2);
        return;
      }
      catch (ParseException localParseException)
      {
        this.list.put(paramString1, paramString2);
        return;
      }
    }
    this.list.put(paramString1, paramString2);
    return;
  }
  
  public void set(String paramString1, String paramString2, String paramString3)
  {
    if (encodeParameters)
    {
      paramString3 = encodeValue(paramString2, paramString3);
      if (paramString3 != null)
      {
        this.list.put(paramString1.trim().toLowerCase(Locale.ENGLISH), paramString3);
        return;
      }
      set(paramString1, paramString2);
      return;
    }
    set(paramString1, paramString2);
  }
  
  public int size()
  {
    return this.list.size();
  }
  
  public String toString()
  {
    return toString(0);
  }
  
  public String toString(int paramInt)
  {
    ToStringBuffer localToStringBuffer = new ToStringBuffer(paramInt);
    Iterator localIterator = this.list.keySet().iterator();
    for (;;)
    {
      if (!localIterator.hasNext()) {
        return localToStringBuffer.toString();
      }
      String str = (String)localIterator.next();
      Object localObject1 = this.list.get(str);
      if ((localObject1 instanceof MultiValue))
      {
        localObject1 = (MultiValue)localObject1;
        str = str + "*";
        paramInt = 0;
        label101:
        Object localObject2;
        if (paramInt < ((MultiValue)localObject1).size())
        {
          localObject2 = ((MultiValue)localObject1).get(paramInt);
          if (!(localObject2 instanceof Value)) {
            break label169;
          }
          localToStringBuffer.addNV(str + paramInt + "*", ((Value)localObject2).encodedValue);
        }
        for (;;)
        {
          paramInt += 1;
          break label101;
          break;
          label169:
          localToStringBuffer.addNV(str + paramInt, (String)localObject2);
        }
      }
      if ((localObject1 instanceof Value)) {
        localToStringBuffer.addNV(str + "*", ((Value)localObject1).encodedValue);
      } else {
        localToStringBuffer.addNV(str, (String)localObject1);
      }
    }
  }
  
  private static class MultiValue
    extends ArrayList
  {
    String value;
  }
  
  private static class ParamEnum
    implements Enumeration
  {
    private Iterator it;
    
    ParamEnum(Iterator paramIterator)
    {
      this.it = paramIterator;
    }
    
    public boolean hasMoreElements()
    {
      return this.it.hasNext();
    }
    
    public Object nextElement()
    {
      return this.it.next();
    }
  }
  
  private static class ToStringBuffer
  {
    private StringBuffer sb = new StringBuffer();
    private int used;
    
    public ToStringBuffer(int paramInt)
    {
      this.used = paramInt;
    }
    
    public void addNV(String paramString1, String paramString2)
    {
      paramString2 = ParameterList.quote(paramString2);
      this.sb.append("; ");
      this.used += 2;
      int i = paramString1.length();
      int j = paramString2.length();
      if (this.used + (i + j + 1) > 76)
      {
        this.sb.append("\r\n\t");
        this.used = 8;
      }
      this.sb.append(paramString1).append('=');
      this.used += paramString1.length() + 1;
      if (this.used + paramString2.length() > 76)
      {
        paramString1 = MimeUtility.fold(this.used, paramString2);
        this.sb.append(paramString1);
        i = paramString1.lastIndexOf('\n');
        if (i >= 0)
        {
          this.used += paramString1.length() - i - 1;
          return;
        }
        this.used += paramString1.length();
        return;
      }
      this.sb.append(paramString2);
      this.used += paramString2.length();
    }
    
    public String toString()
    {
      return this.sb.toString();
    }
  }
  
  private static class Value
  {
    String charset;
    String encodedValue;
    String value;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/internet/ParameterList.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */