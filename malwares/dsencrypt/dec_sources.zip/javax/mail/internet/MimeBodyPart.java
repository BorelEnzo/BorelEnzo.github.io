package javax.mail.internet;

import com.sun.mail.util.ASCIIUtility;
import com.sun.mail.util.FolderClosedIOException;
import com.sun.mail.util.LineOutputStream;
import com.sun.mail.util.MessageRemovedIOException;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.Vector;
import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.FolderClosedException;
import javax.mail.Message;
import javax.mail.MessageRemovedException;
import javax.mail.MessagingException;
import javax.mail.Multipart;

public class MimeBodyPart
  extends BodyPart
  implements MimePart
{
  static boolean cacheMultipart = true;
  private static boolean decodeFileName;
  private static boolean encodeFileName;
  private static boolean setContentTypeFileName;
  private static boolean setDefaultTextCharset;
  private Object cachedContent;
  protected byte[] content;
  protected InputStream contentStream;
  protected DataHandler dh;
  protected InternetHeaders headers;
  
  static
  {
    boolean bool2 = false;
    setDefaultTextCharset = true;
    setContentTypeFileName = true;
    encodeFileName = false;
    decodeFileName = false;
    try
    {
      String str = System.getProperty("mail.mime.setdefaulttextcharset");
      if ((str != null) && (str.equalsIgnoreCase("false")))
      {
        bool1 = false;
        setDefaultTextCharset = bool1;
        str = System.getProperty("mail.mime.setcontenttypefilename");
        if ((str == null) || (!str.equalsIgnoreCase("false"))) {
          break label153;
        }
        bool1 = false;
        label68:
        setContentTypeFileName = bool1;
        str = System.getProperty("mail.mime.encodefilename");
        if ((str == null) || (str.equalsIgnoreCase("false"))) {
          break label158;
        }
        bool1 = true;
        label93:
        encodeFileName = bool1;
        str = System.getProperty("mail.mime.decodefilename");
        if ((str == null) || (str.equalsIgnoreCase("false"))) {
          break label163;
        }
        bool1 = true;
        label118:
        decodeFileName = bool1;
        str = System.getProperty("mail.mime.cachemultipart");
        if ((str == null) || (!str.equalsIgnoreCase("false"))) {
          break label168;
        }
      }
      label153:
      label158:
      label163:
      label168:
      for (boolean bool1 = bool2;; bool1 = true)
      {
        cacheMultipart = bool1;
        return;
        bool1 = true;
        break;
        bool1 = true;
        break label68;
        bool1 = false;
        break label93;
        bool1 = false;
        break label118;
      }
      return;
    }
    catch (SecurityException localSecurityException) {}
  }
  
  public MimeBodyPart()
  {
    this.headers = new InternetHeaders();
  }
  
  public MimeBodyPart(InputStream paramInputStream)
    throws MessagingException
  {
    Object localObject = paramInputStream;
    if (!(paramInputStream instanceof ByteArrayInputStream))
    {
      localObject = paramInputStream;
      if (!(paramInputStream instanceof BufferedInputStream))
      {
        localObject = paramInputStream;
        if (!(paramInputStream instanceof SharedInputStream)) {
          localObject = new BufferedInputStream(paramInputStream);
        }
      }
    }
    this.headers = new InternetHeaders((InputStream)localObject);
    if ((localObject instanceof SharedInputStream))
    {
      paramInputStream = (SharedInputStream)localObject;
      this.contentStream = paramInputStream.newStream(paramInputStream.getPosition(), -1L);
      return;
    }
    try
    {
      this.content = ASCIIUtility.getBytes((InputStream)localObject);
      return;
    }
    catch (IOException paramInputStream)
    {
      throw new MessagingException("Error reading input stream", paramInputStream);
    }
  }
  
  public MimeBodyPart(InternetHeaders paramInternetHeaders, byte[] paramArrayOfByte)
    throws MessagingException
  {
    this.headers = paramInternetHeaders;
    this.content = paramArrayOfByte;
  }
  
  static String[] getContentLanguage(MimePart paramMimePart)
    throws MessagingException
  {
    paramMimePart = paramMimePart.getHeader("Content-Language", null);
    if (paramMimePart == null) {
      return null;
    }
    Object localObject = new HeaderTokenizer(paramMimePart, "()<>@,;:\\\"\t []/?=");
    paramMimePart = new Vector();
    for (;;)
    {
      HeaderTokenizer.Token localToken = ((HeaderTokenizer)localObject).next();
      int i = localToken.getType();
      if (i == -4)
      {
        if (paramMimePart.size() == 0) {
          break;
        }
        localObject = new String[paramMimePart.size()];
        paramMimePart.copyInto((Object[])localObject);
        return (String[])localObject;
      }
      if (i == -1) {
        paramMimePart.addElement(localToken.getValue());
      }
    }
  }
  
  static String getDescription(MimePart paramMimePart)
    throws MessagingException
  {
    paramMimePart = paramMimePart.getHeader("Content-Description", null);
    if (paramMimePart == null) {
      return null;
    }
    try
    {
      String str = MimeUtility.decodeText(MimeUtility.unfold(paramMimePart));
      return str;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException) {}
    return paramMimePart;
  }
  
  static String getDisposition(MimePart paramMimePart)
    throws MessagingException
  {
    paramMimePart = paramMimePart.getHeader("Content-Disposition", null);
    if (paramMimePart == null) {
      return null;
    }
    return new ContentDisposition(paramMimePart).getDisposition();
  }
  
  static String getEncoding(MimePart paramMimePart)
    throws MessagingException
  {
    paramMimePart = paramMimePart.getHeader("Content-Transfer-Encoding", null);
    if (paramMimePart == null) {
      return null;
    }
    paramMimePart = paramMimePart.trim();
    if ((paramMimePart.equalsIgnoreCase("7bit")) || (paramMimePart.equalsIgnoreCase("8bit")) || (paramMimePart.equalsIgnoreCase("quoted-printable")) || (paramMimePart.equalsIgnoreCase("binary")) || (paramMimePart.equalsIgnoreCase("base64"))) {
      return paramMimePart;
    }
    HeaderTokenizer localHeaderTokenizer = new HeaderTokenizer(paramMimePart, "()<>@,;:\\\"\t []/?=");
    HeaderTokenizer.Token localToken;
    int i;
    do
    {
      localToken = localHeaderTokenizer.next();
      i = localToken.getType();
      if (i == -4) {
        return paramMimePart;
      }
    } while (i != -1);
    return localToken.getValue();
  }
  
  static String getFileName(MimePart paramMimePart)
    throws MessagingException
  {
    String str1 = null;
    String str2 = paramMimePart.getHeader("Content-Disposition", null);
    if (str2 != null) {
      str1 = new ContentDisposition(str2).getParameter("filename");
    }
    str2 = str1;
    if (str1 == null)
    {
      paramMimePart = paramMimePart.getHeader("Content-Type", null);
      str2 = str1;
      if (paramMimePart == null) {}
    }
    try
    {
      str2 = new ContentType(paramMimePart).getParameter("name");
      paramMimePart = str2;
      if (decodeFileName)
      {
        paramMimePart = str2;
        if (str2 == null) {}
      }
      try
      {
        paramMimePart = MimeUtility.decodeText(str2);
        return paramMimePart;
      }
      catch (UnsupportedEncodingException paramMimePart)
      {
        throw new MessagingException("Can't decode filename", paramMimePart);
      }
    }
    catch (ParseException paramMimePart)
    {
      for (;;)
      {
        str2 = str1;
      }
    }
  }
  
  static void invalidateContentHeaders(MimePart paramMimePart)
    throws MessagingException
  {
    paramMimePart.removeHeader("Content-Type");
    paramMimePart.removeHeader("Content-Transfer-Encoding");
  }
  
  static boolean isMimeType(MimePart paramMimePart, String paramString)
    throws MessagingException
  {
    try
    {
      boolean bool = new ContentType(paramMimePart.getContentType()).match(paramString);
      return bool;
    }
    catch (ParseException localParseException) {}
    return paramMimePart.getContentType().equalsIgnoreCase(paramString);
  }
  
  static void setContentLanguage(MimePart paramMimePart, String[] paramArrayOfString)
    throws MessagingException
  {
    StringBuffer localStringBuffer = new StringBuffer(paramArrayOfString[0]);
    int i = 1;
    for (;;)
    {
      if (i >= paramArrayOfString.length)
      {
        paramMimePart.setHeader("Content-Language", localStringBuffer.toString());
        return;
      }
      localStringBuffer.append(',').append(paramArrayOfString[i]);
      i += 1;
    }
  }
  
  static void setDescription(MimePart paramMimePart, String paramString1, String paramString2)
    throws MessagingException
  {
    if (paramString1 == null)
    {
      paramMimePart.removeHeader("Content-Description");
      return;
    }
    try
    {
      paramMimePart.setHeader("Content-Description", MimeUtility.fold(21, MimeUtility.encodeText(paramString1, paramString2, null)));
      return;
    }
    catch (UnsupportedEncodingException paramMimePart)
    {
      throw new MessagingException("Encoding error", paramMimePart);
    }
  }
  
  static void setDisposition(MimePart paramMimePart, String paramString)
    throws MessagingException
  {
    if (paramString == null)
    {
      paramMimePart.removeHeader("Content-Disposition");
      return;
    }
    String str = paramMimePart.getHeader("Content-Disposition", null);
    Object localObject = paramString;
    if (str != null)
    {
      localObject = new ContentDisposition(str);
      ((ContentDisposition)localObject).setDisposition(paramString);
      localObject = ((ContentDisposition)localObject).toString();
    }
    paramMimePart.setHeader("Content-Disposition", (String)localObject);
  }
  
  static void setEncoding(MimePart paramMimePart, String paramString)
    throws MessagingException
  {
    paramMimePart.setHeader("Content-Transfer-Encoding", paramString);
  }
  
  /* Error */
  static void setFileName(MimePart paramMimePart, String paramString)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_1
    //   1: astore_2
    //   2: getstatic 32	javax/mail/internet/MimeBodyPart:encodeFileName	Z
    //   5: ifeq +14 -> 19
    //   8: aload_1
    //   9: astore_2
    //   10: aload_1
    //   11: ifnull +8 -> 19
    //   14: aload_1
    //   15: invokestatic 263	javax/mail/internet/MimeUtility:encodeText	(Ljava/lang/String;)Ljava/lang/String;
    //   18: astore_2
    //   19: aload_0
    //   20: ldc -86
    //   22: aconst_null
    //   23: invokeinterface 118 3 0
    //   28: astore_1
    //   29: aload_1
    //   30: ifnonnull +97 -> 127
    //   33: ldc_w 265
    //   36: astore_1
    //   37: new 172	javax/mail/internet/ContentDisposition
    //   40: dup
    //   41: aload_1
    //   42: invokespecial 175	javax/mail/internet/ContentDisposition:<init>	(Ljava/lang/String;)V
    //   45: astore_1
    //   46: aload_1
    //   47: ldc -58
    //   49: aload_2
    //   50: invokevirtual 268	javax/mail/internet/ContentDisposition:setParameter	(Ljava/lang/String;Ljava/lang/String;)V
    //   53: aload_0
    //   54: ldc -86
    //   56: aload_1
    //   57: invokevirtual 259	javax/mail/internet/ContentDisposition:toString	()Ljava/lang/String;
    //   60: invokeinterface 235 3 0
    //   65: getstatic 30	javax/mail/internet/MimeBodyPart:setContentTypeFileName	Z
    //   68: ifeq +45 -> 113
    //   71: aload_0
    //   72: ldc -53
    //   74: aconst_null
    //   75: invokeinterface 118 3 0
    //   80: astore_1
    //   81: aload_1
    //   82: ifnull +31 -> 113
    //   85: new 205	javax/mail/internet/ContentType
    //   88: dup
    //   89: aload_1
    //   90: invokespecial 206	javax/mail/internet/ContentType:<init>	(Ljava/lang/String;)V
    //   93: astore_1
    //   94: aload_1
    //   95: ldc -48
    //   97: aload_2
    //   98: invokevirtual 269	javax/mail/internet/ContentType:setParameter	(Ljava/lang/String;Ljava/lang/String;)V
    //   101: aload_0
    //   102: ldc -53
    //   104: aload_1
    //   105: invokevirtual 270	javax/mail/internet/ContentType:toString	()Ljava/lang/String;
    //   108: invokeinterface 235 3 0
    //   113: return
    //   114: astore_0
    //   115: new 72	javax/mail/MessagingException
    //   118: dup
    //   119: ldc_w 272
    //   122: aload_0
    //   123: invokespecial 108	javax/mail/MessagingException:<init>	(Ljava/lang/String;Ljava/lang/Exception;)V
    //   126: athrow
    //   127: goto -90 -> 37
    //   130: astore_0
    //   131: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	132	0	paramMimePart	MimePart
    //   0	132	1	paramString	String
    //   1	97	2	str	String
    // Exception table:
    //   from	to	target	type
    //   14	19	114	java/io/UnsupportedEncodingException
    //   85	113	130	javax/mail/internet/ParseException
  }
  
  static void setText(MimePart paramMimePart, String paramString1, String paramString2, String paramString3)
    throws MessagingException
  {
    String str = paramString2;
    if (paramString2 == null) {
      if (MimeUtility.checkAscii(paramString1) == 1) {
        break label61;
      }
    }
    label61:
    for (str = MimeUtility.getDefaultMIMECharset();; str = "us-ascii")
    {
      paramMimePart.setContent(paramString1, "text/" + paramString3 + "; charset=" + MimeUtility.quote(str, "()<>@,;:\\\"\t []/?="));
      return;
    }
  }
  
  static void updateHeaders(MimePart paramMimePart)
    throws MessagingException
  {
    Object localObject3 = paramMimePart.getDataHandler();
    if (localObject3 == null) {
      return;
    }
    for (;;)
    {
      Object localObject2;
      int i;
      ContentType localContentType;
      try
      {
        localObject2 = ((DataHandler)localObject3).getContentType();
        i = 0;
        if (paramMimePart.getHeader("Content-Type") == null)
        {
          j = 1;
          localContentType = new ContentType((String)localObject2);
          if (!localContentType.match("multipart/*")) {
            break label402;
          }
          i = 1;
          if (!(paramMimePart instanceof MimeBodyPart)) {
            break label309;
          }
          localObject1 = (MimeBodyPart)paramMimePart;
          if (((MimeBodyPart)localObject1).cachedContent == null) {
            break label300;
          }
          localObject1 = ((MimeBodyPart)localObject1).cachedContent;
          if (!(localObject1 instanceof MimeMultipart)) {
            break label354;
          }
          ((MimeMultipart)localObject1).updateHeaders();
          localObject1 = localObject2;
          if (i == 0)
          {
            if (paramMimePart.getHeader("Content-Transfer-Encoding") == null) {
              setEncoding(paramMimePart, MimeUtility.getEncoding((DataHandler)localObject3));
            }
            localObject1 = localObject2;
            if (j != 0)
            {
              localObject1 = localObject2;
              if (setDefaultTextCharset)
              {
                localObject1 = localObject2;
                if (localContentType.match("text/*"))
                {
                  localObject1 = localObject2;
                  if (localContentType.getParameter("charset") == null)
                  {
                    localObject1 = paramMimePart.getEncoding();
                    if ((localObject1 == null) || (!((String)localObject1).equalsIgnoreCase("7bit"))) {
                      break label418;
                    }
                    localObject1 = "us-ascii";
                    localContentType.setParameter("charset", (String)localObject1);
                    localObject1 = localContentType.toString();
                  }
                }
              }
            }
          }
          if (j == 0) {
            break;
          }
          localObject3 = paramMimePart.getHeader("Content-Disposition", null);
          localObject2 = localObject1;
          if (localObject3 != null)
          {
            localObject3 = new ContentDisposition((String)localObject3).getParameter("filename");
            localObject2 = localObject1;
            if (localObject3 != null)
            {
              localContentType.setParameter("name", (String)localObject3);
              localObject2 = localContentType.toString();
            }
          }
          paramMimePart.setHeader("Content-Type", (String)localObject2);
          return;
        }
      }
      catch (IOException paramMimePart)
      {
        throw new MessagingException("IOException updating headers", paramMimePart);
      }
      int j = 0;
      continue;
      label300:
      Object localObject1 = ((DataHandler)localObject3).getContent();
      continue;
      label309:
      if ((paramMimePart instanceof MimeMessage))
      {
        localObject1 = (MimeMessage)paramMimePart;
        if (((MimeMessage)localObject1).cachedContent != null) {
          localObject1 = ((MimeMessage)localObject1).cachedContent;
        } else {
          localObject1 = ((DataHandler)localObject3).getContent();
        }
      }
      else
      {
        localObject1 = ((DataHandler)localObject3).getContent();
        continue;
        label354:
        throw new MessagingException("MIME part of type \"" + (String)localObject2 + "\" contains object of type " + localObject1.getClass().getName() + " instead of MimeMultipart");
        label402:
        if (localContentType.match("message/rfc822"))
        {
          i = 1;
          continue;
          label418:
          localObject1 = MimeUtility.getDefaultMIMECharset();
        }
      }
    }
  }
  
  static void writeTo(MimePart paramMimePart, OutputStream paramOutputStream, String[] paramArrayOfString)
    throws IOException, MessagingException
  {
    LineOutputStream localLineOutputStream;
    if ((paramOutputStream instanceof LineOutputStream))
    {
      localLineOutputStream = (LineOutputStream)paramOutputStream;
      paramArrayOfString = paramMimePart.getNonMatchingHeaderLines(paramArrayOfString);
    }
    for (;;)
    {
      if (!paramArrayOfString.hasMoreElements())
      {
        localLineOutputStream.writeln();
        paramOutputStream = MimeUtility.encode(paramOutputStream, paramMimePart.getEncoding());
        paramMimePart.getDataHandler().writeTo(paramOutputStream);
        paramOutputStream.flush();
        return;
        localLineOutputStream = new LineOutputStream(paramOutputStream);
        break;
      }
      localLineOutputStream.writeln((String)paramArrayOfString.nextElement());
    }
  }
  
  public void addHeader(String paramString1, String paramString2)
    throws MessagingException
  {
    this.headers.addHeader(paramString1, paramString2);
  }
  
  public void addHeaderLine(String paramString)
    throws MessagingException
  {
    this.headers.addHeaderLine(paramString);
  }
  
  public void attachFile(File paramFile)
    throws IOException, MessagingException
  {
    paramFile = new FileDataSource(paramFile);
    setDataHandler(new DataHandler(paramFile));
    setFileName(paramFile.getName());
  }
  
  public void attachFile(String paramString)
    throws IOException, MessagingException
  {
    attachFile(new File(paramString));
  }
  
  public Enumeration getAllHeaderLines()
    throws MessagingException
  {
    return this.headers.getAllHeaderLines();
  }
  
  public Enumeration getAllHeaders()
    throws MessagingException
  {
    return this.headers.getAllHeaders();
  }
  
  public Object getContent()
    throws IOException, MessagingException
  {
    Object localObject1;
    if (this.cachedContent != null) {
      localObject1 = this.cachedContent;
    }
    for (;;)
    {
      return localObject1;
      try
      {
        Object localObject2 = getDataHandler().getContent();
        localObject1 = localObject2;
        if (!cacheMultipart) {
          continue;
        }
        if (!(localObject2 instanceof Multipart))
        {
          localObject1 = localObject2;
          if (!(localObject2 instanceof Message)) {
            continue;
          }
        }
        if (this.content == null)
        {
          localObject1 = localObject2;
          if (this.contentStream == null) {
            continue;
          }
        }
        this.cachedContent = localObject2;
        return localObject2;
      }
      catch (FolderClosedIOException localFolderClosedIOException)
      {
        throw new FolderClosedException(localFolderClosedIOException.getFolder(), localFolderClosedIOException.getMessage());
      }
      catch (MessageRemovedIOException localMessageRemovedIOException)
      {
        throw new MessageRemovedException(localMessageRemovedIOException.getMessage());
      }
    }
  }
  
  public String getContentID()
    throws MessagingException
  {
    return getHeader("Content-Id", null);
  }
  
  public String[] getContentLanguage()
    throws MessagingException
  {
    return getContentLanguage(this);
  }
  
  public String getContentMD5()
    throws MessagingException
  {
    return getHeader("Content-MD5", null);
  }
  
  protected InputStream getContentStream()
    throws MessagingException
  {
    if (this.contentStream != null) {
      return ((SharedInputStream)this.contentStream).newStream(0L, -1L);
    }
    if (this.content != null) {
      return new ByteArrayInputStream(this.content);
    }
    throw new MessagingException("No content");
  }
  
  public String getContentType()
    throws MessagingException
  {
    String str2 = getHeader("Content-Type", null);
    String str1 = str2;
    if (str2 == null) {
      str1 = "text/plain";
    }
    return str1;
  }
  
  public DataHandler getDataHandler()
    throws MessagingException
  {
    if (this.dh == null) {
      this.dh = new DataHandler(new MimePartDataSource(this));
    }
    return this.dh;
  }
  
  public String getDescription()
    throws MessagingException
  {
    return getDescription(this);
  }
  
  public String getDisposition()
    throws MessagingException
  {
    return getDisposition(this);
  }
  
  public String getEncoding()
    throws MessagingException
  {
    return getEncoding(this);
  }
  
  public String getFileName()
    throws MessagingException
  {
    return getFileName(this);
  }
  
  public String getHeader(String paramString1, String paramString2)
    throws MessagingException
  {
    return this.headers.getHeader(paramString1, paramString2);
  }
  
  public String[] getHeader(String paramString)
    throws MessagingException
  {
    return this.headers.getHeader(paramString);
  }
  
  public InputStream getInputStream()
    throws IOException, MessagingException
  {
    return getDataHandler().getInputStream();
  }
  
  public int getLineCount()
    throws MessagingException
  {
    return -1;
  }
  
  public Enumeration getMatchingHeaderLines(String[] paramArrayOfString)
    throws MessagingException
  {
    return this.headers.getMatchingHeaderLines(paramArrayOfString);
  }
  
  public Enumeration getMatchingHeaders(String[] paramArrayOfString)
    throws MessagingException
  {
    return this.headers.getMatchingHeaders(paramArrayOfString);
  }
  
  public Enumeration getNonMatchingHeaderLines(String[] paramArrayOfString)
    throws MessagingException
  {
    return this.headers.getNonMatchingHeaderLines(paramArrayOfString);
  }
  
  public Enumeration getNonMatchingHeaders(String[] paramArrayOfString)
    throws MessagingException
  {
    return this.headers.getNonMatchingHeaders(paramArrayOfString);
  }
  
  public InputStream getRawInputStream()
    throws MessagingException
  {
    return getContentStream();
  }
  
  public int getSize()
    throws MessagingException
  {
    int i;
    if (this.content != null) {
      i = this.content.length;
    }
    for (;;)
    {
      return i;
      if (this.contentStream != null) {}
      try
      {
        int j = this.contentStream.available();
        i = j;
        if (j > 0) {}
      }
      catch (IOException localIOException)
      {
        for (;;) {}
      }
    }
    return -1;
  }
  
  public boolean isMimeType(String paramString)
    throws MessagingException
  {
    return isMimeType(this, paramString);
  }
  
  public void removeHeader(String paramString)
    throws MessagingException
  {
    this.headers.removeHeader(paramString);
  }
  
  /* Error */
  public void saveFile(File paramFile)
    throws IOException, MessagingException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_3
    //   2: aconst_null
    //   3: astore 5
    //   5: aconst_null
    //   6: astore 6
    //   8: new 519	java/io/BufferedOutputStream
    //   11: dup
    //   12: new 521	java/io/FileOutputStream
    //   15: dup
    //   16: aload_1
    //   17: invokespecial 522	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   20: invokespecial 523	java/io/BufferedOutputStream:<init>	(Ljava/io/OutputStream;)V
    //   23: astore 4
    //   25: aload 6
    //   27: astore_1
    //   28: aload_0
    //   29: invokevirtual 524	javax/mail/internet/MimeBodyPart:getInputStream	()Ljava/io/InputStream;
    //   32: astore_3
    //   33: aload_3
    //   34: astore_1
    //   35: sipush 8192
    //   38: newarray <illegal type>
    //   40: astore 5
    //   42: aload_3
    //   43: astore_1
    //   44: aload_3
    //   45: aload 5
    //   47: invokevirtual 528	java/io/InputStream:read	([B)I
    //   50: istore_2
    //   51: iload_2
    //   52: ifgt +22 -> 74
    //   55: aload_3
    //   56: ifnull +7 -> 63
    //   59: aload_3
    //   60: invokevirtual 531	java/io/InputStream:close	()V
    //   63: aload 4
    //   65: ifnull +8 -> 73
    //   68: aload 4
    //   70: invokevirtual 532	java/io/OutputStream:close	()V
    //   73: return
    //   74: aload_3
    //   75: astore_1
    //   76: aload 4
    //   78: aload 5
    //   80: iconst_0
    //   81: iload_2
    //   82: invokevirtual 536	java/io/OutputStream:write	([BII)V
    //   85: goto -43 -> 42
    //   88: astore_3
    //   89: aload_1
    //   90: ifnull +7 -> 97
    //   93: aload_1
    //   94: invokevirtual 531	java/io/InputStream:close	()V
    //   97: aload 4
    //   99: ifnull +8 -> 107
    //   102: aload 4
    //   104: invokevirtual 532	java/io/OutputStream:close	()V
    //   107: aload_3
    //   108: athrow
    //   109: astore_1
    //   110: goto -13 -> 97
    //   113: astore_1
    //   114: goto -7 -> 107
    //   117: astore_1
    //   118: goto -55 -> 63
    //   121: astore_1
    //   122: return
    //   123: astore 6
    //   125: aload 5
    //   127: astore_1
    //   128: aload_3
    //   129: astore 4
    //   131: aload 6
    //   133: astore_3
    //   134: goto -45 -> 89
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	137	0	this	MimeBodyPart
    //   0	137	1	paramFile	File
    //   50	32	2	i	int
    //   1	74	3	localInputStream	InputStream
    //   88	41	3	localObject1	Object
    //   133	1	3	localObject2	Object
    //   23	107	4	localObject3	Object
    //   3	123	5	arrayOfByte	byte[]
    //   6	20	6	localObject4	Object
    //   123	9	6	localObject5	Object
    // Exception table:
    //   from	to	target	type
    //   28	33	88	finally
    //   35	42	88	finally
    //   44	51	88	finally
    //   76	85	88	finally
    //   93	97	109	java/io/IOException
    //   102	107	113	java/io/IOException
    //   59	63	117	java/io/IOException
    //   68	73	121	java/io/IOException
    //   8	25	123	finally
  }
  
  public void saveFile(String paramString)
    throws IOException, MessagingException
  {
    saveFile(new File(paramString));
  }
  
  public void setContent(Object paramObject, String paramString)
    throws MessagingException
  {
    if ((paramObject instanceof Multipart))
    {
      setContent((Multipart)paramObject);
      return;
    }
    setDataHandler(new DataHandler(paramObject, paramString));
  }
  
  public void setContent(Multipart paramMultipart)
    throws MessagingException
  {
    setDataHandler(new DataHandler(paramMultipart, paramMultipart.getContentType()));
    paramMultipart.setParent(this);
  }
  
  public void setContentID(String paramString)
    throws MessagingException
  {
    if (paramString == null)
    {
      removeHeader("Content-ID");
      return;
    }
    setHeader("Content-ID", paramString);
  }
  
  public void setContentLanguage(String[] paramArrayOfString)
    throws MessagingException
  {
    setContentLanguage(this, paramArrayOfString);
  }
  
  public void setContentMD5(String paramString)
    throws MessagingException
  {
    setHeader("Content-MD5", paramString);
  }
  
  public void setDataHandler(DataHandler paramDataHandler)
    throws MessagingException
  {
    this.dh = paramDataHandler;
    this.cachedContent = null;
    invalidateContentHeaders(this);
  }
  
  public void setDescription(String paramString)
    throws MessagingException
  {
    setDescription(paramString, null);
  }
  
  public void setDescription(String paramString1, String paramString2)
    throws MessagingException
  {
    setDescription(this, paramString1, paramString2);
  }
  
  public void setDisposition(String paramString)
    throws MessagingException
  {
    setDisposition(this, paramString);
  }
  
  public void setFileName(String paramString)
    throws MessagingException
  {
    setFileName(this, paramString);
  }
  
  public void setHeader(String paramString1, String paramString2)
    throws MessagingException
  {
    this.headers.setHeader(paramString1, paramString2);
  }
  
  public void setText(String paramString)
    throws MessagingException
  {
    setText(paramString, null);
  }
  
  public void setText(String paramString1, String paramString2)
    throws MessagingException
  {
    setText(this, paramString1, paramString2, "plain");
  }
  
  public void setText(String paramString1, String paramString2, String paramString3)
    throws MessagingException
  {
    setText(this, paramString1, paramString2, paramString3);
  }
  
  protected void updateHeaders()
    throws MessagingException
  {
    updateHeaders(this);
    if (this.cachedContent != null)
    {
      this.dh = new DataHandler(this.cachedContent, getContentType());
      this.cachedContent = null;
      this.content = null;
      if (this.contentStream == null) {}
    }
    try
    {
      this.contentStream.close();
      this.contentStream = null;
      return;
    }
    catch (IOException localIOException)
    {
      for (;;) {}
    }
  }
  
  public void writeTo(OutputStream paramOutputStream)
    throws IOException, MessagingException
  {
    writeTo(this, paramOutputStream, null);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/internet/MimeBodyPart.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */