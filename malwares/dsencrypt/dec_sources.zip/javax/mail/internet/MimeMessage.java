package javax.mail.internet;

import com.sun.mail.util.ASCIIUtility;
import com.sun.mail.util.FolderClosedIOException;
import com.sun.mail.util.LineOutputStream;
import com.sun.mail.util.MessageRemovedIOException;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectStreamException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.util.Date;
import java.util.Enumeration;
import java.util.Vector;
import javax.activation.DataHandler;
import javax.mail.Address;
import javax.mail.Flags;
import javax.mail.Flags.Flag;
import javax.mail.Folder;
import javax.mail.FolderClosedException;
import javax.mail.Message;
import javax.mail.Message.RecipientType;
import javax.mail.MessageRemovedException;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.util.SharedByteArrayInputStream;

public class MimeMessage
  extends Message
  implements MimePart
{
  private static final Flags answeredFlag = new Flags(Flags.Flag.ANSWERED);
  private static MailDateFormat mailDateFormat = new MailDateFormat();
  Object cachedContent;
  protected byte[] content;
  protected InputStream contentStream;
  protected DataHandler dh;
  protected Flags flags;
  protected InternetHeaders headers;
  protected boolean modified = false;
  protected boolean saved = false;
  private boolean strict = true;
  
  protected MimeMessage(Folder paramFolder, int paramInt)
  {
    super(paramFolder, paramInt);
    this.flags = new Flags();
    this.saved = true;
    initStrict();
  }
  
  protected MimeMessage(Folder paramFolder, InputStream paramInputStream, int paramInt)
    throws MessagingException
  {
    this(paramFolder, paramInt);
    initStrict();
    parse(paramInputStream);
  }
  
  protected MimeMessage(Folder paramFolder, InternetHeaders paramInternetHeaders, byte[] paramArrayOfByte, int paramInt)
    throws MessagingException
  {
    this(paramFolder, paramInt);
    this.headers = paramInternetHeaders;
    this.content = paramArrayOfByte;
    initStrict();
  }
  
  public MimeMessage(Session paramSession)
  {
    super(paramSession);
    this.modified = true;
    this.headers = new InternetHeaders();
    this.flags = new Flags();
    initStrict();
  }
  
  public MimeMessage(Session paramSession, InputStream paramInputStream)
    throws MessagingException
  {
    super(paramSession);
    this.flags = new Flags();
    initStrict();
    parse(paramInputStream);
    this.saved = true;
  }
  
  public MimeMessage(MimeMessage paramMimeMessage)
    throws MessagingException
  {
    super(paramMimeMessage.session);
    this.flags = paramMimeMessage.getFlags();
    int i = paramMimeMessage.getSize();
    if (i > 0) {}
    for (ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream(i);; localByteArrayOutputStream = new ByteArrayOutputStream()) {
      try
      {
        this.strict = paramMimeMessage.strict;
        paramMimeMessage.writeTo(localByteArrayOutputStream);
        localByteArrayOutputStream.close();
        paramMimeMessage = new SharedByteArrayInputStream(localByteArrayOutputStream.toByteArray());
        parse(paramMimeMessage);
        paramMimeMessage.close();
        this.saved = true;
        return;
      }
      catch (IOException paramMimeMessage)
      {
        throw new MessagingException("IOException while copying message", paramMimeMessage);
      }
    }
  }
  
  private void addAddressHeader(String paramString, Address[] paramArrayOfAddress)
    throws MessagingException
  {
    paramArrayOfAddress = InternetAddress.toString(paramArrayOfAddress);
    if (paramArrayOfAddress == null) {
      return;
    }
    addHeader(paramString, paramArrayOfAddress);
  }
  
  private Address[] eliminateDuplicates(Vector paramVector, Address[] paramArrayOfAddress)
  {
    if (paramArrayOfAddress == null) {
      return null;
    }
    int j = 0;
    int i = 0;
    if (i >= paramArrayOfAddress.length)
    {
      paramVector = paramArrayOfAddress;
      if (j != 0)
      {
        if (!(paramArrayOfAddress instanceof InternetAddress[])) {
          break label134;
        }
        paramVector = new InternetAddress[paramArrayOfAddress.length - j];
        label40:
        i = 0;
      }
    }
    int k;
    for (j = 0;; j = k)
    {
      if (i >= paramArrayOfAddress.length)
      {
        return paramVector;
        int m = 0;
        k = 0;
        for (;;)
        {
          if (k >= paramVector.size()) {
            k = m;
          }
          for (;;)
          {
            if (k == 0) {
              paramVector.addElement(paramArrayOfAddress[i]);
            }
            i += 1;
            break;
            if (!((InternetAddress)paramVector.elementAt(k)).equals(paramArrayOfAddress[i])) {
              break label125;
            }
            k = 1;
            j += 1;
            paramArrayOfAddress[i] = null;
          }
          label125:
          k += 1;
        }
        label134:
        paramVector = new Address[paramArrayOfAddress.length - j];
        break label40;
      }
      k = j;
      if (paramArrayOfAddress[i] != null)
      {
        paramVector[j] = paramArrayOfAddress[i];
        k = j + 1;
      }
      i += 1;
    }
  }
  
  private Address[] getAddressHeader(String paramString)
    throws MessagingException
  {
    paramString = getHeader(paramString, ",");
    if (paramString == null) {
      return null;
    }
    return InternetAddress.parseHeader(paramString, this.strict);
  }
  
  private String getHeaderName(Message.RecipientType paramRecipientType)
    throws MessagingException
  {
    if (paramRecipientType == Message.RecipientType.TO) {
      return "To";
    }
    if (paramRecipientType == Message.RecipientType.CC) {
      return "Cc";
    }
    if (paramRecipientType == Message.RecipientType.BCC) {
      return "Bcc";
    }
    if (paramRecipientType == RecipientType.NEWSGROUPS) {
      return "Newsgroups";
    }
    throw new MessagingException("Invalid Recipient Type");
  }
  
  private void initStrict()
  {
    if (this.session != null)
    {
      String str = this.session.getProperty("mail.mime.address.strict");
      if ((str == null) || (!str.equalsIgnoreCase("false"))) {
        break label38;
      }
    }
    label38:
    for (boolean bool = false;; bool = true)
    {
      this.strict = bool;
      return;
    }
  }
  
  private void setAddressHeader(String paramString, Address[] paramArrayOfAddress)
    throws MessagingException
  {
    paramArrayOfAddress = InternetAddress.toString(paramArrayOfAddress);
    if (paramArrayOfAddress == null)
    {
      removeHeader(paramString);
      return;
    }
    setHeader(paramString, paramArrayOfAddress);
  }
  
  public void addFrom(Address[] paramArrayOfAddress)
    throws MessagingException
  {
    addAddressHeader("From", paramArrayOfAddress);
  }
  
  public void addHeader(String paramString1, String paramString2)
    throws MessagingException
  {
    this.headers.addHeader(paramString1, paramString2);
  }
  
  public void addHeaderLine(String paramString)
    throws MessagingException
  {
    this.headers.addHeaderLine(paramString);
  }
  
  public void addRecipients(Message.RecipientType paramRecipientType, String paramString)
    throws MessagingException
  {
    if (paramRecipientType == RecipientType.NEWSGROUPS)
    {
      if ((paramString != null) && (paramString.length() != 0)) {
        addHeader("Newsgroups", paramString);
      }
      return;
    }
    addAddressHeader(getHeaderName(paramRecipientType), InternetAddress.parse(paramString));
  }
  
  public void addRecipients(Message.RecipientType paramRecipientType, Address[] paramArrayOfAddress)
    throws MessagingException
  {
    if (paramRecipientType == RecipientType.NEWSGROUPS)
    {
      paramRecipientType = NewsAddress.toString(paramArrayOfAddress);
      if (paramRecipientType != null) {
        addHeader("Newsgroups", paramRecipientType);
      }
      return;
    }
    addAddressHeader(getHeaderName(paramRecipientType), paramArrayOfAddress);
  }
  
  protected InternetHeaders createInternetHeaders(InputStream paramInputStream)
    throws MessagingException
  {
    return new InternetHeaders(paramInputStream);
  }
  
  protected MimeMessage createMimeMessage(Session paramSession)
    throws MessagingException
  {
    return new MimeMessage(paramSession);
  }
  
  public Enumeration getAllHeaderLines()
    throws MessagingException
  {
    return this.headers.getAllHeaderLines();
  }
  
  public Enumeration getAllHeaders()
    throws MessagingException
  {
    return this.headers.getAllHeaders();
  }
  
  public Address[] getAllRecipients()
    throws MessagingException
  {
    Address[] arrayOfAddress1 = super.getAllRecipients();
    Address[] arrayOfAddress2 = getRecipients(RecipientType.NEWSGROUPS);
    if (arrayOfAddress2 == null) {
      return arrayOfAddress1;
    }
    if (arrayOfAddress1 == null) {
      return arrayOfAddress2;
    }
    Address[] arrayOfAddress3 = new Address[arrayOfAddress1.length + arrayOfAddress2.length];
    System.arraycopy(arrayOfAddress1, 0, arrayOfAddress3, 0, arrayOfAddress1.length);
    System.arraycopy(arrayOfAddress2, 0, arrayOfAddress3, arrayOfAddress1.length, arrayOfAddress2.length);
    return arrayOfAddress3;
  }
  
  public Object getContent()
    throws IOException, MessagingException
  {
    Object localObject1;
    if (this.cachedContent != null) {
      localObject1 = this.cachedContent;
    }
    for (;;)
    {
      return localObject1;
      try
      {
        Object localObject2 = getDataHandler().getContent();
        localObject1 = localObject2;
        if (!MimeBodyPart.cacheMultipart) {
          continue;
        }
        if (!(localObject2 instanceof Multipart))
        {
          localObject1 = localObject2;
          if (!(localObject2 instanceof Message)) {
            continue;
          }
        }
        if (this.content == null)
        {
          localObject1 = localObject2;
          if (this.contentStream == null) {
            continue;
          }
        }
        this.cachedContent = localObject2;
        return localObject2;
      }
      catch (FolderClosedIOException localFolderClosedIOException)
      {
        throw new FolderClosedException(localFolderClosedIOException.getFolder(), localFolderClosedIOException.getMessage());
      }
      catch (MessageRemovedIOException localMessageRemovedIOException)
      {
        throw new MessageRemovedException(localMessageRemovedIOException.getMessage());
      }
    }
  }
  
  public String getContentID()
    throws MessagingException
  {
    return getHeader("Content-Id", null);
  }
  
  public String[] getContentLanguage()
    throws MessagingException
  {
    return MimeBodyPart.getContentLanguage(this);
  }
  
  public String getContentMD5()
    throws MessagingException
  {
    return getHeader("Content-MD5", null);
  }
  
  protected InputStream getContentStream()
    throws MessagingException
  {
    if (this.contentStream != null) {
      return ((SharedInputStream)this.contentStream).newStream(0L, -1L);
    }
    if (this.content != null) {
      return new SharedByteArrayInputStream(this.content);
    }
    throw new MessagingException("No content");
  }
  
  public String getContentType()
    throws MessagingException
  {
    String str2 = getHeader("Content-Type", null);
    String str1 = str2;
    if (str2 == null) {
      str1 = "text/plain";
    }
    return str1;
  }
  
  public DataHandler getDataHandler()
    throws MessagingException
  {
    try
    {
      if (this.dh == null) {
        this.dh = new DataHandler(new MimePartDataSource(this));
      }
      DataHandler localDataHandler = this.dh;
      return localDataHandler;
    }
    finally {}
  }
  
  public String getDescription()
    throws MessagingException
  {
    return MimeBodyPart.getDescription(this);
  }
  
  public String getDisposition()
    throws MessagingException
  {
    return MimeBodyPart.getDisposition(this);
  }
  
  public String getEncoding()
    throws MessagingException
  {
    return MimeBodyPart.getEncoding(this);
  }
  
  public String getFileName()
    throws MessagingException
  {
    return MimeBodyPart.getFileName(this);
  }
  
  public Flags getFlags()
    throws MessagingException
  {
    try
    {
      Flags localFlags = (Flags)this.flags.clone();
      return localFlags;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public Address[] getFrom()
    throws MessagingException
  {
    Address[] arrayOfAddress2 = getAddressHeader("From");
    Address[] arrayOfAddress1 = arrayOfAddress2;
    if (arrayOfAddress2 == null) {
      arrayOfAddress1 = getAddressHeader("Sender");
    }
    return arrayOfAddress1;
  }
  
  public String getHeader(String paramString1, String paramString2)
    throws MessagingException
  {
    return this.headers.getHeader(paramString1, paramString2);
  }
  
  public String[] getHeader(String paramString)
    throws MessagingException
  {
    return this.headers.getHeader(paramString);
  }
  
  public InputStream getInputStream()
    throws IOException, MessagingException
  {
    return getDataHandler().getInputStream();
  }
  
  public int getLineCount()
    throws MessagingException
  {
    return -1;
  }
  
  public Enumeration getMatchingHeaderLines(String[] paramArrayOfString)
    throws MessagingException
  {
    return this.headers.getMatchingHeaderLines(paramArrayOfString);
  }
  
  public Enumeration getMatchingHeaders(String[] paramArrayOfString)
    throws MessagingException
  {
    return this.headers.getMatchingHeaders(paramArrayOfString);
  }
  
  public String getMessageID()
    throws MessagingException
  {
    return getHeader("Message-ID", null);
  }
  
  public Enumeration getNonMatchingHeaderLines(String[] paramArrayOfString)
    throws MessagingException
  {
    return this.headers.getNonMatchingHeaderLines(paramArrayOfString);
  }
  
  public Enumeration getNonMatchingHeaders(String[] paramArrayOfString)
    throws MessagingException
  {
    return this.headers.getNonMatchingHeaders(paramArrayOfString);
  }
  
  public InputStream getRawInputStream()
    throws MessagingException
  {
    return getContentStream();
  }
  
  public Date getReceivedDate()
    throws MessagingException
  {
    return null;
  }
  
  public Address[] getRecipients(Message.RecipientType paramRecipientType)
    throws MessagingException
  {
    if (paramRecipientType == RecipientType.NEWSGROUPS)
    {
      paramRecipientType = getHeader("Newsgroups", ",");
      if (paramRecipientType == null) {
        return null;
      }
      return NewsAddress.parse(paramRecipientType);
    }
    return getAddressHeader(getHeaderName(paramRecipientType));
  }
  
  public Address[] getReplyTo()
    throws MessagingException
  {
    Address[] arrayOfAddress2 = getAddressHeader("Reply-To");
    Address[] arrayOfAddress1 = arrayOfAddress2;
    if (arrayOfAddress2 == null) {
      arrayOfAddress1 = getFrom();
    }
    return arrayOfAddress1;
  }
  
  public Address getSender()
    throws MessagingException
  {
    Address[] arrayOfAddress = getAddressHeader("Sender");
    if ((arrayOfAddress == null) || (arrayOfAddress.length == 0)) {
      return null;
    }
    return arrayOfAddress[0];
  }
  
  public Date getSentDate()
    throws MessagingException
  {
    Object localObject1 = getHeader("Date", null);
    if (localObject1 != null) {
      try
      {
        synchronized (mailDateFormat)
        {
          localObject1 = mailDateFormat.parse((String)localObject1);
          return (Date)localObject1;
        }
        return null;
      }
      catch (ParseException localParseException)
      {
        return null;
      }
    }
  }
  
  public int getSize()
    throws MessagingException
  {
    int i;
    if (this.content != null) {
      i = this.content.length;
    }
    for (;;)
    {
      return i;
      if (this.contentStream != null) {}
      try
      {
        int j = this.contentStream.available();
        i = j;
        if (j > 0) {}
      }
      catch (IOException localIOException)
      {
        for (;;) {}
      }
    }
    return -1;
  }
  
  public String getSubject()
    throws MessagingException
  {
    String str1 = getHeader("Subject", null);
    if (str1 == null) {
      return null;
    }
    try
    {
      String str2 = MimeUtility.decodeText(MimeUtility.unfold(str1));
      return str2;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException) {}
    return str1;
  }
  
  public boolean isMimeType(String paramString)
    throws MessagingException
  {
    return MimeBodyPart.isMimeType(this, paramString);
  }
  
  public boolean isSet(Flags.Flag paramFlag)
    throws MessagingException
  {
    try
    {
      boolean bool = this.flags.contains(paramFlag);
      return bool;
    }
    finally
    {
      paramFlag = finally;
      throw paramFlag;
    }
  }
  
  protected void parse(InputStream paramInputStream)
    throws MessagingException
  {
    Object localObject = paramInputStream;
    if (!(paramInputStream instanceof ByteArrayInputStream))
    {
      localObject = paramInputStream;
      if (!(paramInputStream instanceof BufferedInputStream))
      {
        localObject = paramInputStream;
        if (!(paramInputStream instanceof SharedInputStream)) {
          localObject = new BufferedInputStream(paramInputStream);
        }
      }
    }
    this.headers = createInternetHeaders((InputStream)localObject);
    if ((localObject instanceof SharedInputStream))
    {
      paramInputStream = (SharedInputStream)localObject;
      this.contentStream = paramInputStream.newStream(paramInputStream.getPosition(), -1L);
    }
    for (;;)
    {
      this.modified = false;
      return;
      try
      {
        this.content = ASCIIUtility.getBytes((InputStream)localObject);
      }
      catch (IOException paramInputStream)
      {
        throw new MessagingException("IOException", paramInputStream);
      }
    }
  }
  
  public void removeHeader(String paramString)
    throws MessagingException
  {
    this.headers.removeHeader(paramString);
  }
  
  public Message reply(boolean paramBoolean)
    throws MessagingException
  {
    MimeMessage localMimeMessage = createMimeMessage(this.session);
    Object localObject2 = getHeader("Subject", null);
    if (localObject2 != null)
    {
      localObject1 = localObject2;
      if (!((String)localObject2).regionMatches(true, 0, "Re: ", 0, 4)) {
        localObject1 = "Re: " + (String)localObject2;
      }
      localMimeMessage.setHeader("Subject", (String)localObject1);
    }
    Object localObject3 = getReplyTo();
    localMimeMessage.setRecipients(Message.RecipientType.TO, (Address[])localObject3);
    int i;
    if (paramBoolean)
    {
      localObject2 = new Vector();
      localObject1 = InternetAddress.getLocalAddress(this.session);
      if (localObject1 != null) {
        ((Vector)localObject2).addElement(localObject1);
      }
      localObject1 = null;
      if (this.session != null) {
        localObject1 = this.session.getProperty("mail.alternates");
      }
      if (localObject1 != null) {
        eliminateDuplicates((Vector)localObject2, InternetAddress.parse((String)localObject1, false));
      }
      localObject1 = null;
      if (this.session != null) {
        localObject1 = this.session.getProperty("mail.replyallcc");
      }
      if ((localObject1 == null) || (!((String)localObject1).equalsIgnoreCase("true"))) {
        break label422;
      }
      i = 1;
      eliminateDuplicates((Vector)localObject2, (Address[])localObject3);
      localObject1 = eliminateDuplicates((Vector)localObject2, getRecipients(Message.RecipientType.TO));
      if ((localObject1 != null) && (localObject1.length > 0))
      {
        if (i == 0) {
          break label427;
        }
        localMimeMessage.addRecipients(Message.RecipientType.CC, (Address[])localObject1);
      }
      label235:
      localObject1 = eliminateDuplicates((Vector)localObject2, getRecipients(Message.RecipientType.CC));
      if ((localObject1 != null) && (localObject1.length > 0)) {
        localMimeMessage.addRecipients(Message.RecipientType.CC, (Address[])localObject1);
      }
      localObject1 = getRecipients(RecipientType.NEWSGROUPS);
      if ((localObject1 != null) && (localObject1.length > 0)) {
        localMimeMessage.setRecipients(RecipientType.NEWSGROUPS, (Address[])localObject1);
      }
    }
    localObject3 = getHeader("Message-Id", null);
    if (localObject3 != null) {
      localMimeMessage.setHeader("In-Reply-To", (String)localObject3);
    }
    localObject2 = getHeader("References", " ");
    Object localObject1 = localObject2;
    if (localObject2 == null) {
      localObject1 = getHeader("In-Reply-To", " ");
    }
    localObject2 = localObject1;
    if (localObject3 != null) {
      if (localObject1 == null) {
        break label439;
      }
    }
    label422:
    label427:
    label439:
    for (localObject2 = MimeUtility.unfold((String)localObject1) + " " + (String)localObject3;; localObject2 = localObject3)
    {
      if (localObject2 != null) {
        localMimeMessage.setHeader("References", MimeUtility.fold(12, (String)localObject2));
      }
      try
      {
        setFlags(answeredFlag, true);
        return localMimeMessage;
      }
      catch (MessagingException localMessagingException) {}
      i = 0;
      break;
      localMimeMessage.addRecipients(Message.RecipientType.TO, (Address[])localObject1);
      break label235;
    }
    return localMimeMessage;
  }
  
  public void saveChanges()
    throws MessagingException
  {
    this.modified = true;
    this.saved = true;
    updateHeaders();
  }
  
  public void setContent(Object paramObject, String paramString)
    throws MessagingException
  {
    if ((paramObject instanceof Multipart))
    {
      setContent((Multipart)paramObject);
      return;
    }
    setDataHandler(new DataHandler(paramObject, paramString));
  }
  
  public void setContent(Multipart paramMultipart)
    throws MessagingException
  {
    setDataHandler(new DataHandler(paramMultipart, paramMultipart.getContentType()));
    paramMultipart.setParent(this);
  }
  
  public void setContentID(String paramString)
    throws MessagingException
  {
    if (paramString == null)
    {
      removeHeader("Content-ID");
      return;
    }
    setHeader("Content-ID", paramString);
  }
  
  public void setContentLanguage(String[] paramArrayOfString)
    throws MessagingException
  {
    MimeBodyPart.setContentLanguage(this, paramArrayOfString);
  }
  
  public void setContentMD5(String paramString)
    throws MessagingException
  {
    setHeader("Content-MD5", paramString);
  }
  
  public void setDataHandler(DataHandler paramDataHandler)
    throws MessagingException
  {
    try
    {
      this.dh = paramDataHandler;
      this.cachedContent = null;
      MimeBodyPart.invalidateContentHeaders(this);
      return;
    }
    finally
    {
      paramDataHandler = finally;
      throw paramDataHandler;
    }
  }
  
  public void setDescription(String paramString)
    throws MessagingException
  {
    setDescription(paramString, null);
  }
  
  public void setDescription(String paramString1, String paramString2)
    throws MessagingException
  {
    MimeBodyPart.setDescription(this, paramString1, paramString2);
  }
  
  public void setDisposition(String paramString)
    throws MessagingException
  {
    MimeBodyPart.setDisposition(this, paramString);
  }
  
  public void setFileName(String paramString)
    throws MessagingException
  {
    MimeBodyPart.setFileName(this, paramString);
  }
  
  public void setFlags(Flags paramFlags, boolean paramBoolean)
    throws MessagingException
  {
    if (paramBoolean) {}
    for (;;)
    {
      try
      {
        this.flags.add(paramFlags);
        return;
      }
      finally {}
      this.flags.remove(paramFlags);
    }
  }
  
  public void setFrom()
    throws MessagingException
  {
    InternetAddress localInternetAddress = InternetAddress.getLocalAddress(this.session);
    if (localInternetAddress != null)
    {
      setFrom(localInternetAddress);
      return;
    }
    throw new MessagingException("No From address");
  }
  
  public void setFrom(Address paramAddress)
    throws MessagingException
  {
    if (paramAddress == null)
    {
      removeHeader("From");
      return;
    }
    setHeader("From", paramAddress.toString());
  }
  
  public void setHeader(String paramString1, String paramString2)
    throws MessagingException
  {
    this.headers.setHeader(paramString1, paramString2);
  }
  
  public void setRecipients(Message.RecipientType paramRecipientType, String paramString)
    throws MessagingException
  {
    if (paramRecipientType == RecipientType.NEWSGROUPS)
    {
      if ((paramString == null) || (paramString.length() == 0))
      {
        removeHeader("Newsgroups");
        return;
      }
      setHeader("Newsgroups", paramString);
      return;
    }
    setAddressHeader(getHeaderName(paramRecipientType), InternetAddress.parse(paramString));
  }
  
  public void setRecipients(Message.RecipientType paramRecipientType, Address[] paramArrayOfAddress)
    throws MessagingException
  {
    if (paramRecipientType == RecipientType.NEWSGROUPS)
    {
      if ((paramArrayOfAddress == null) || (paramArrayOfAddress.length == 0))
      {
        removeHeader("Newsgroups");
        return;
      }
      setHeader("Newsgroups", NewsAddress.toString(paramArrayOfAddress));
      return;
    }
    setAddressHeader(getHeaderName(paramRecipientType), paramArrayOfAddress);
  }
  
  public void setReplyTo(Address[] paramArrayOfAddress)
    throws MessagingException
  {
    setAddressHeader("Reply-To", paramArrayOfAddress);
  }
  
  public void setSender(Address paramAddress)
    throws MessagingException
  {
    if (paramAddress == null)
    {
      removeHeader("Sender");
      return;
    }
    setHeader("Sender", paramAddress.toString());
  }
  
  public void setSentDate(Date paramDate)
    throws MessagingException
  {
    if (paramDate == null)
    {
      removeHeader("Date");
      return;
    }
    synchronized (mailDateFormat)
    {
      setHeader("Date", mailDateFormat.format(paramDate));
      return;
    }
  }
  
  public void setSubject(String paramString)
    throws MessagingException
  {
    setSubject(paramString, null);
  }
  
  public void setSubject(String paramString1, String paramString2)
    throws MessagingException
  {
    if (paramString1 == null)
    {
      removeHeader("Subject");
      return;
    }
    try
    {
      setHeader("Subject", MimeUtility.fold(9, MimeUtility.encodeText(paramString1, paramString2, null)));
      return;
    }
    catch (UnsupportedEncodingException paramString1)
    {
      throw new MessagingException("Encoding error", paramString1);
    }
  }
  
  public void setText(String paramString)
    throws MessagingException
  {
    setText(paramString, null);
  }
  
  public void setText(String paramString1, String paramString2)
    throws MessagingException
  {
    MimeBodyPart.setText(this, paramString1, paramString2, "plain");
  }
  
  public void setText(String paramString1, String paramString2, String paramString3)
    throws MessagingException
  {
    MimeBodyPart.setText(this, paramString1, paramString2, paramString3);
  }
  
  protected void updateHeaders()
    throws MessagingException
  {
    MimeBodyPart.updateHeaders(this);
    setHeader("MIME-Version", "1.0");
    updateMessageID();
    if (this.cachedContent != null)
    {
      this.dh = new DataHandler(this.cachedContent, getContentType());
      this.cachedContent = null;
      this.content = null;
      if (this.contentStream == null) {}
    }
    try
    {
      this.contentStream.close();
      this.contentStream = null;
      return;
    }
    catch (IOException localIOException)
    {
      for (;;) {}
    }
  }
  
  protected void updateMessageID()
    throws MessagingException
  {
    setHeader("Message-ID", "<" + UniqueValue.getUniqueMessageIDValue(this.session) + ">");
  }
  
  public void writeTo(OutputStream paramOutputStream)
    throws IOException, MessagingException
  {
    writeTo(paramOutputStream, null);
  }
  
  public void writeTo(OutputStream paramOutputStream, String[] paramArrayOfString)
    throws IOException, MessagingException
  {
    if (!this.saved) {
      saveChanges();
    }
    if (this.modified)
    {
      MimeBodyPart.writeTo(this, paramOutputStream, paramArrayOfString);
      return;
    }
    paramArrayOfString = getNonMatchingHeaderLines(paramArrayOfString);
    Object localObject = new LineOutputStream(paramOutputStream);
    label74:
    int i;
    if (!paramArrayOfString.hasMoreElements())
    {
      ((LineOutputStream)localObject).writeln();
      if (this.content != null) {
        break label127;
      }
      paramArrayOfString = getContentStream();
      localObject = new byte[' '];
      i = paramArrayOfString.read((byte[])localObject);
      if (i > 0) {
        break label116;
      }
      paramArrayOfString.close();
      paramArrayOfString = (byte[])null;
    }
    for (;;)
    {
      paramOutputStream.flush();
      return;
      ((LineOutputStream)localObject).writeln((String)paramArrayOfString.nextElement());
      break;
      label116:
      paramOutputStream.write((byte[])localObject, 0, i);
      break label74;
      label127:
      paramOutputStream.write(this.content);
    }
  }
  
  public static class RecipientType
    extends Message.RecipientType
  {
    public static final RecipientType NEWSGROUPS = new RecipientType("Newsgroups");
    private static final long serialVersionUID = -5468290701714395543L;
    
    protected RecipientType(String paramString)
    {
      super();
    }
    
    protected Object readResolve()
      throws ObjectStreamException
    {
      if (this.type.equals("Newsgroups")) {
        return NEWSGROUPS;
      }
      return super.readResolve();
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/internet/MimeMessage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */