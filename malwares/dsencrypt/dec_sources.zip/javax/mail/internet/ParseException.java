package javax.mail.internet;

import javax.mail.MessagingException;

public class ParseException
  extends MessagingException
{
  private static final long serialVersionUID = 7649991205183658089L;
  
  public ParseException() {}
  
  public ParseException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/internet/ParseException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */