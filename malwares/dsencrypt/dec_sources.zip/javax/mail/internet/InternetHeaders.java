package javax.mail.internet;

import com.sun.mail.util.LineInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import javax.mail.Header;
import javax.mail.MessagingException;

public class InternetHeaders
{
  protected List headers = new ArrayList(40);
  
  public InternetHeaders()
  {
    this.headers.add(new InternetHeader("Return-Path", null));
    this.headers.add(new InternetHeader("Received", null));
    this.headers.add(new InternetHeader("Resent-Date", null));
    this.headers.add(new InternetHeader("Resent-From", null));
    this.headers.add(new InternetHeader("Resent-Sender", null));
    this.headers.add(new InternetHeader("Resent-To", null));
    this.headers.add(new InternetHeader("Resent-Cc", null));
    this.headers.add(new InternetHeader("Resent-Bcc", null));
    this.headers.add(new InternetHeader("Resent-Message-Id", null));
    this.headers.add(new InternetHeader("Date", null));
    this.headers.add(new InternetHeader("From", null));
    this.headers.add(new InternetHeader("Sender", null));
    this.headers.add(new InternetHeader("Reply-To", null));
    this.headers.add(new InternetHeader("To", null));
    this.headers.add(new InternetHeader("Cc", null));
    this.headers.add(new InternetHeader("Bcc", null));
    this.headers.add(new InternetHeader("Message-Id", null));
    this.headers.add(new InternetHeader("In-Reply-To", null));
    this.headers.add(new InternetHeader("References", null));
    this.headers.add(new InternetHeader("Subject", null));
    this.headers.add(new InternetHeader("Comments", null));
    this.headers.add(new InternetHeader("Keywords", null));
    this.headers.add(new InternetHeader("Errors-To", null));
    this.headers.add(new InternetHeader("MIME-Version", null));
    this.headers.add(new InternetHeader("Content-Type", null));
    this.headers.add(new InternetHeader("Content-Transfer-Encoding", null));
    this.headers.add(new InternetHeader("Content-MD5", null));
    this.headers.add(new InternetHeader(":", null));
    this.headers.add(new InternetHeader("Content-Length", null));
    this.headers.add(new InternetHeader("Status", null));
  }
  
  public InternetHeaders(InputStream paramInputStream)
    throws MessagingException
  {
    load(paramInputStream);
  }
  
  public void addHeader(String paramString1, String paramString2)
  {
    int j = this.headers.size();
    int k;
    int i;
    if ((!paramString1.equalsIgnoreCase("Received")) && (!paramString1.equalsIgnoreCase("Return-Path")))
    {
      k = 0;
      if (k != 0) {
        j = 0;
      }
      i = this.headers.size() - 1;
    }
    for (;;)
    {
      if (i < 0)
      {
        this.headers.add(j, new InternetHeader(paramString1, paramString2));
        return;
        k = 1;
        break;
      }
      InternetHeader localInternetHeader = (InternetHeader)this.headers.get(i);
      if (paramString1.equalsIgnoreCase(localInternetHeader.getName()))
      {
        if (k == 0) {
          break label141;
        }
        j = i;
      }
      if (localInternetHeader.getName().equals(":")) {
        j = i;
      }
      i -= 1;
    }
    label141:
    this.headers.add(i + 1, new InternetHeader(paramString1, paramString2));
  }
  
  public void addHeaderLine(String paramString)
  {
    try
    {
      int i = paramString.charAt(0);
      if ((i == 32) || (i == 9))
      {
        InternetHeader localInternetHeader = (InternetHeader)this.headers.get(this.headers.size() - 1);
        localInternetHeader.line = (localInternetHeader.line + "\r\n" + paramString);
        return;
      }
      this.headers.add(new InternetHeader(paramString));
      return;
    }
    catch (StringIndexOutOfBoundsException paramString) {}catch (NoSuchElementException paramString) {}
  }
  
  public Enumeration getAllHeaderLines()
  {
    return getNonMatchingHeaderLines(null);
  }
  
  public Enumeration getAllHeaders()
  {
    return new matchEnum(this.headers, null, false, false);
  }
  
  public String getHeader(String paramString1, String paramString2)
  {
    paramString1 = getHeader(paramString1);
    if (paramString1 == null) {
      return null;
    }
    if ((paramString1.length == 1) || (paramString2 == null)) {
      return paramString1[0];
    }
    StringBuffer localStringBuffer = new StringBuffer(paramString1[0]);
    int i = 1;
    for (;;)
    {
      if (i >= paramString1.length) {
        return localStringBuffer.toString();
      }
      localStringBuffer.append(paramString2);
      localStringBuffer.append(paramString1[i]);
      i += 1;
    }
  }
  
  public String[] getHeader(String paramString)
  {
    Iterator localIterator = this.headers.iterator();
    ArrayList localArrayList = new ArrayList();
    for (;;)
    {
      if (!localIterator.hasNext())
      {
        if (localArrayList.size() != 0) {
          break;
        }
        return null;
      }
      InternetHeader localInternetHeader = (InternetHeader)localIterator.next();
      if ((paramString.equalsIgnoreCase(localInternetHeader.getName())) && (localInternetHeader.line != null)) {
        localArrayList.add(localInternetHeader.getValue());
      }
    }
    return (String[])localArrayList.toArray(new String[localArrayList.size()]);
  }
  
  public Enumeration getMatchingHeaderLines(String[] paramArrayOfString)
  {
    return new matchEnum(this.headers, paramArrayOfString, true, true);
  }
  
  public Enumeration getMatchingHeaders(String[] paramArrayOfString)
  {
    return new matchEnum(this.headers, paramArrayOfString, true, false);
  }
  
  public Enumeration getNonMatchingHeaderLines(String[] paramArrayOfString)
  {
    return new matchEnum(this.headers, paramArrayOfString, false, true);
  }
  
  public Enumeration getNonMatchingHeaders(String[] paramArrayOfString)
  {
    return new matchEnum(this.headers, paramArrayOfString, false, false);
  }
  
  public void load(InputStream paramInputStream)
    throws MessagingException
  {
    LineInputStream localLineInputStream = new LineInputStream(paramInputStream);
    paramInputStream = null;
    StringBuffer localStringBuffer = new StringBuffer();
    for (;;)
    {
      String str;
      try
      {
        str = localLineInputStream.readLine();
        if ((str != null) && ((str.startsWith(" ")) || (str.startsWith("\t"))))
        {
          InputStream localInputStream = paramInputStream;
          if (paramInputStream != null)
          {
            localStringBuffer.append(paramInputStream);
            localInputStream = null;
          }
          localStringBuffer.append("\r\n");
          localStringBuffer.append(str);
          paramInputStream = localInputStream;
          if (str != null) {
            if (str.length() > 0) {
              continue;
            }
          }
        }
        else if (paramInputStream != null)
        {
          addHeaderLine(paramInputStream);
        }
        else if (localStringBuffer.length() > 0)
        {
          addHeaderLine(localStringBuffer.toString());
          localStringBuffer.setLength(0);
        }
      }
      catch (IOException paramInputStream)
      {
        throw new MessagingException("Error in input stream", paramInputStream);
      }
      return;
      paramInputStream = str;
    }
  }
  
  public void removeHeader(String paramString)
  {
    int i = 0;
    for (;;)
    {
      if (i >= this.headers.size()) {
        return;
      }
      InternetHeader localInternetHeader = (InternetHeader)this.headers.get(i);
      if (paramString.equalsIgnoreCase(localInternetHeader.getName())) {
        localInternetHeader.line = null;
      }
      i += 1;
    }
  }
  
  public void setHeader(String paramString1, String paramString2)
  {
    int j = 0;
    int i = 0;
    if (i >= this.headers.size())
    {
      if (j == 0) {
        addHeader(paramString1, paramString2);
      }
      return;
    }
    InternetHeader localInternetHeader = (InternetHeader)this.headers.get(i);
    int k = j;
    int m = i;
    if (paramString1.equalsIgnoreCase(localInternetHeader.getName()))
    {
      if (j != 0) {
        break label183;
      }
      if (localInternetHeader.line == null) {
        break label152;
      }
      j = localInternetHeader.line.indexOf(':');
      if (j < 0) {
        break label152;
      }
      localInternetHeader.line = (localInternetHeader.line.substring(0, j + 1) + " " + paramString2);
      label134:
      k = 1;
      m = i;
    }
    for (;;)
    {
      i = m + 1;
      j = k;
      break;
      label152:
      localInternetHeader.line = (paramString1 + ": " + paramString2);
      break label134;
      label183:
      this.headers.remove(i);
      m = i - 1;
      k = j;
    }
  }
  
  protected static final class InternetHeader
    extends Header
  {
    String line;
    
    public InternetHeader(String paramString)
    {
      super("");
      int i = paramString.indexOf(':');
      if (i < 0) {}
      for (this.name = paramString.trim();; this.name = paramString.substring(0, i).trim())
      {
        this.line = paramString;
        return;
      }
    }
    
    public InternetHeader(String paramString1, String paramString2)
    {
      super("");
      if (paramString2 != null)
      {
        this.line = (paramString1 + ": " + paramString2);
        return;
      }
      this.line = null;
    }
    
    public String getValue()
    {
      int i = this.line.indexOf(':');
      if (i < 0) {
        return this.line;
      }
      i += 1;
      for (;;)
      {
        if (i >= this.line.length()) {}
        int j;
        do
        {
          return this.line.substring(i);
          j = this.line.charAt(i);
        } while ((j != 32) && (j != 9) && (j != 13) && (j != 10));
        i += 1;
      }
    }
  }
  
  static class matchEnum
    implements Enumeration
  {
    private Iterator e;
    private boolean match;
    private String[] names;
    private InternetHeaders.InternetHeader next_header;
    private boolean want_line;
    
    matchEnum(List paramList, String[] paramArrayOfString, boolean paramBoolean1, boolean paramBoolean2)
    {
      this.e = paramList.iterator();
      this.names = paramArrayOfString;
      this.match = paramBoolean1;
      this.want_line = paramBoolean2;
      this.next_header = null;
    }
    
    private InternetHeaders.InternetHeader nextMatch()
    {
      InternetHeaders.InternetHeader localInternetHeader;
      if (!this.e.hasNext()) {
        localInternetHeader = null;
      }
      do
      {
        return localInternetHeader;
        localInternetHeader = (InternetHeaders.InternetHeader)this.e.next();
        if (localInternetHeader.line == null) {
          break;
        }
        if (this.names != null) {
          break label52;
        }
      } while (!this.match);
      return null;
      label52:
      int i = 0;
      for (;;)
      {
        if (i >= this.names.length)
        {
          if (this.match) {
            break;
          }
          return localInternetHeader;
        }
        if (this.names[i].equalsIgnoreCase(localInternetHeader.getName()))
        {
          if (!this.match) {
            break;
          }
          return localInternetHeader;
        }
        i += 1;
      }
    }
    
    public boolean hasMoreElements()
    {
      if (this.next_header == null) {
        this.next_header = nextMatch();
      }
      return this.next_header != null;
    }
    
    public Object nextElement()
    {
      if (this.next_header == null) {
        this.next_header = nextMatch();
      }
      if (this.next_header == null) {
        throw new NoSuchElementException("No more headers");
      }
      InternetHeaders.InternetHeader localInternetHeader = this.next_header;
      this.next_header = null;
      if (this.want_line) {
        return localInternetHeader.line;
      }
      return new Header(localInternetHeader.getName(), localInternetHeader.getValue());
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/internet/InternetHeaders.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */