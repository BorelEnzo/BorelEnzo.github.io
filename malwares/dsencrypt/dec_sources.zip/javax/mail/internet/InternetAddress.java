package javax.mail.internet;

import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.Locale;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.mail.Address;
import javax.mail.Session;

public class InternetAddress
  extends Address
  implements Cloneable
{
  private static final String rfc822phrase = "()<>@,;:\\\"\t .[]".replace(' ', '\000').replace('\t', '\000');
  private static final long serialVersionUID = -7507595530758302903L;
  private static final String specialsNoDot = "()<>,;:\\\"[]@";
  private static final String specialsNoDotNoAt = "()<>,;:\\\"[]";
  protected String address;
  protected String encodedPersonal;
  protected String personal;
  
  public InternetAddress() {}
  
  public InternetAddress(String paramString)
    throws AddressException
  {
    InternetAddress[] arrayOfInternetAddress = parse(paramString, true);
    if (arrayOfInternetAddress.length != 1) {
      throw new AddressException("Illegal address", paramString);
    }
    this.address = arrayOfInternetAddress[0].address;
    this.personal = arrayOfInternetAddress[0].personal;
    this.encodedPersonal = arrayOfInternetAddress[0].encodedPersonal;
  }
  
  public InternetAddress(String paramString1, String paramString2)
    throws UnsupportedEncodingException
  {
    this(paramString1, paramString2, null);
  }
  
  public InternetAddress(String paramString1, String paramString2, String paramString3)
    throws UnsupportedEncodingException
  {
    this.address = paramString1;
    setPersonal(paramString2, paramString3);
  }
  
  public InternetAddress(String paramString, boolean paramBoolean)
    throws AddressException
  {
    this(paramString);
    if (paramBoolean) {
      checkAddress(this.address, true, true);
    }
  }
  
  private static void checkAddress(String paramString, boolean paramBoolean1, boolean paramBoolean2)
    throws AddressException
  {
    int i = 0;
    if (paramString.indexOf('"') >= 0) {}
    label111:
    String str1;
    label172:
    do
    {
      return;
      if (paramBoolean1) {}
      int j;
      for (i = 0;; i = j + 1)
      {
        j = indexOfAny(paramString, ",:", i);
        if (j < 0) {}
        for (;;)
        {
          j = paramString.indexOf('@', i);
          if (j < 0) {
            break label172;
          }
          if (j != i) {
            break label111;
          }
          throw new AddressException("Missing local name", paramString);
          if (paramString.charAt(i) != '@') {
            throw new AddressException("Illegal route-addr", paramString);
          }
          if (paramString.charAt(j) != ':') {
            break;
          }
          i = j + 1;
        }
      }
      if (j == paramString.length() - 1) {
        throw new AddressException("Missing domain", paramString);
      }
      String str2 = paramString.substring(i, j);
      for (str1 = paramString.substring(j + 1); indexOfAny(paramString, " \t\n\r") >= 0; str1 = null)
      {
        throw new AddressException("Illegal whitespace in address", paramString);
        if (paramBoolean2) {
          throw new AddressException("Missing final '@domain'", paramString);
        }
        str2 = paramString;
      }
      if (indexOfAny(str2, "()<>,;:\\\"[]@") >= 0) {
        throw new AddressException("Illegal character in local name", paramString);
      }
    } while ((str1 == null) || (str1.indexOf('[') >= 0) || (indexOfAny(str1, "()<>,;:\\\"[]@") < 0));
    throw new AddressException("Illegal character in domain", paramString);
  }
  
  public static InternetAddress getLocalAddress(Session paramSession)
  {
    Object localObject3 = null;
    Object localObject1 = null;
    Object localObject2 = null;
    if (paramSession == null) {}
    for (;;)
    {
      try
      {
        localObject3 = System.getProperty("user.name");
        localObject1 = InetAddress.getLocalHost().getHostName();
        paramSession = (Session)localObject2;
        if (localObject2 == null)
        {
          paramSession = (Session)localObject2;
          if (localObject3 != null)
          {
            paramSession = (Session)localObject2;
            if (((String)localObject3).length() != 0)
            {
              paramSession = (Session)localObject2;
              if (localObject1 != null)
              {
                paramSession = (Session)localObject2;
                if (((String)localObject1).length() != 0) {
                  paramSession = localObject3 + "@" + (String)localObject1;
                }
              }
            }
          }
        }
        if (paramSession == null) {
          continue;
        }
        return new InternetAddress(paramSession);
      }
      catch (UnknownHostException paramSession)
      {
        String str;
        Object localObject4;
        InetAddress localInetAddress;
        return null;
      }
      catch (AddressException paramSession)
      {
        continue;
      }
      catch (SecurityException paramSession)
      {
        continue;
      }
      str = paramSession.getProperty("mail.from");
      localObject2 = str;
      if (str == null)
      {
        localObject2 = paramSession.getProperty("mail.user");
        if (localObject2 != null)
        {
          localObject1 = localObject2;
          if (((String)localObject2).length() != 0) {}
        }
        else
        {
          localObject1 = paramSession.getProperty("user.name");
        }
        if (localObject1 != null)
        {
          localObject4 = localObject1;
          if (((String)localObject1).length() != 0) {}
        }
        else
        {
          localObject4 = System.getProperty("user.name");
        }
        paramSession = paramSession.getProperty("mail.host");
        if (paramSession != null)
        {
          localObject2 = str;
          localObject1 = paramSession;
          localObject3 = localObject4;
          if (paramSession.length() != 0) {}
        }
        else
        {
          localInetAddress = InetAddress.getLocalHost();
          localObject2 = str;
          localObject1 = paramSession;
          localObject3 = localObject4;
          if (localInetAddress != null)
          {
            localObject1 = localInetAddress.getHostName();
            localObject2 = str;
            localObject3 = localObject4;
          }
        }
      }
    }
  }
  
  private static int indexOfAny(String paramString1, String paramString2)
  {
    return indexOfAny(paramString1, paramString2, 0);
  }
  
  private static int indexOfAny(String paramString1, String paramString2, int paramInt)
  {
    int j;
    do
    {
      try
      {
        j = paramString1.length();
      }
      catch (StringIndexOutOfBoundsException paramString1)
      {
        int k;
        return -1;
      }
      k = paramString2.indexOf(paramString1.charAt(paramInt));
      i = paramInt;
      if (k >= 0) {
        break;
      }
      paramInt += 1;
    } while (paramInt < j);
    int i = -1;
    return i;
  }
  
  private boolean isSimple()
  {
    return (this.address == null) || (indexOfAny(this.address, "()<>,;:\\\"[]") < 0);
  }
  
  private static int lengthOfFirstSegment(String paramString)
  {
    int i = paramString.indexOf("\r\n");
    if (i != -1) {
      return i;
    }
    return paramString.length();
  }
  
  private static int lengthOfLastSegment(String paramString, int paramInt)
  {
    int i = paramString.lastIndexOf("\r\n");
    if (i != -1) {
      return paramString.length() - i - 2;
    }
    return paramString.length() + paramInt;
  }
  
  public static InternetAddress[] parse(String paramString)
    throws AddressException
  {
    return parse(paramString, true);
  }
  
  public static InternetAddress[] parse(String paramString, boolean paramBoolean)
    throws AddressException
  {
    return parse(paramString, paramBoolean, false);
  }
  
  private static InternetAddress[] parse(String paramString, boolean paramBoolean1, boolean paramBoolean2)
    throws AddressException
  {
    int n = -1;
    int m = -1;
    int i11 = paramString.length();
    int i9 = 0;
    boolean bool2 = false;
    int i8 = 0;
    Vector localVector = new Vector();
    int i3 = -1;
    int i1 = -1;
    int i = 0;
    int j;
    Object localObject1;
    Object localObject2;
    if (i >= i11) {
      if (i1 >= 0)
      {
        j = i3;
        if (i3 == -1) {
          j = i;
        }
        localObject1 = paramString.substring(i1, j).trim();
        if ((i8 == 0) && (!paramBoolean1) && (!paramBoolean2)) {
          break label1564;
        }
        if ((paramBoolean1) || (!paramBoolean2)) {
          checkAddress((String)localObject1, bool2, false);
        }
        localObject2 = new InternetAddress();
        ((InternetAddress)localObject2).setAddress((String)localObject1);
        if (n >= 0) {
          ((InternetAddress)localObject2).encodedPersonal = unquote(paramString.substring(n, m).trim());
        }
        localVector.addElement(localObject2);
      }
    }
    for (;;)
    {
      paramString = new InternetAddress[localVector.size()];
      localVector.copyInto(paramString);
      return paramString;
      int i2 = i3;
      int i5 = m;
      int i7 = i9;
      int i4 = i;
      j = i8;
      boolean bool1 = bool2;
      int k = i1;
      int i6 = n;
      switch (paramString.charAt(i))
      {
      default: 
        i2 = i3;
        i5 = m;
        i7 = i9;
        i4 = i;
        j = i8;
        bool1 = bool2;
        k = i1;
        i6 = n;
        if (i1 == -1)
        {
          k = i;
          i6 = n;
          bool1 = bool2;
          j = i8;
          i4 = i;
          i7 = i9;
          i5 = m;
          i2 = i3;
        }
        break;
      }
      for (;;)
      {
        i = i4 + 1;
        i3 = i2;
        m = i5;
        i9 = i7;
        i8 = j;
        bool2 = bool1;
        i1 = k;
        n = i6;
        break;
        int i10 = 1;
        i8 = i3;
        if (i1 >= 0)
        {
          i8 = i3;
          if (i3 == -1) {
            i8 = i;
          }
        }
        i3 = n;
        if (n == -1) {
          i3 = i + 1;
        }
        i += 1;
        j = 1;
        if ((i >= i11) || (j <= 0))
        {
          if (j > 0) {
            throw new AddressException("Missing ')'", paramString, i);
          }
        }
        else
        {
          switch (paramString.charAt(i))
          {
          }
          for (;;)
          {
            i += 1;
            break;
            i += 1;
            continue;
            j += 1;
            continue;
            j -= 1;
          }
        }
        i -= 1;
        i2 = i8;
        i5 = m;
        i7 = i9;
        i4 = i;
        j = i10;
        bool1 = bool2;
        k = i1;
        i6 = i3;
        if (m == -1)
        {
          i5 = i;
          i2 = i8;
          i7 = i9;
          i4 = i;
          j = i10;
          bool1 = bool2;
          k = i1;
          i6 = i3;
          continue;
          throw new AddressException("Missing '('", paramString, i);
          j = 1;
          if (bool2) {
            throw new AddressException("Extra route-addr", paramString, i);
          }
          i5 = m;
          k = i1;
          if (i9 == 0)
          {
            n = i1;
            if (n >= 0) {
              m = i;
            }
            k = i + 1;
            i5 = m;
          }
          m = 0;
          i4 = i + 1;
          i = m;
          if (i4 >= i11)
          {
            label726:
            if (i4 < i11) {
              break label844;
            }
            if (i != 0) {
              throw new AddressException("Missing '\"'", paramString, i4);
            }
          }
          else
          {
            switch (paramString.charAt(i4))
            {
            }
            for (;;)
            {
              i4 += 1;
              break;
              i4 += 1;
              continue;
              if (i != 0) {}
              for (i = 0;; i = 1) {
                break;
              }
              if (i == 0) {
                break label726;
              }
            }
          }
          throw new AddressException("Missing '>'", paramString, i4);
          label844:
          bool1 = true;
          i2 = i4;
          i7 = i9;
          i6 = n;
          continue;
          throw new AddressException("Missing '<'", paramString, i);
          j = 1;
          k = i1;
          if (i1 == -1) {
            k = i;
          }
          i += 1;
          if (i >= i11)
          {
            i2 = i3;
            i5 = m;
            i7 = i9;
            i4 = i;
            bool1 = bool2;
            i6 = n;
            if (i >= i11) {
              throw new AddressException("Missing '\"'", paramString, i);
            }
          }
          else
          {
            switch (paramString.charAt(i))
            {
            }
            for (;;)
            {
              i += 1;
              break;
              i += 1;
            }
            j = 1;
            i += 1;
            if (i >= i11)
            {
              i2 = i3;
              i5 = m;
              i7 = i9;
              i4 = i;
              bool1 = bool2;
              k = i1;
              i6 = n;
              if (i >= i11) {
                throw new AddressException("Missing ']'", paramString, i);
              }
            }
            else
            {
              switch (paramString.charAt(i))
              {
              }
              for (;;)
              {
                i += 1;
                break;
                i += 1;
              }
              if (i1 == -1)
              {
                bool1 = false;
                j = 0;
                i2 = -1;
                k = -1;
                i5 = m;
                i7 = i9;
                i4 = i;
                i6 = n;
              }
              else if (i9 != 0)
              {
                bool1 = false;
                i2 = i3;
                i5 = m;
                i7 = i9;
                i4 = i;
                j = i8;
                k = i1;
                i6 = n;
              }
              else
              {
                j = i3;
                if (i3 == -1) {
                  j = i;
                }
                localObject1 = paramString.substring(i1, j).trim();
                if ((i8 != 0) || (paramBoolean1) || (paramBoolean2))
                {
                  if ((paramBoolean1) || (!paramBoolean2)) {
                    checkAddress((String)localObject1, bool2, false);
                  }
                  localObject2 = new InternetAddress();
                  ((InternetAddress)localObject2).setAddress((String)localObject1);
                  i5 = m;
                  i6 = n;
                  if (n >= 0)
                  {
                    ((InternetAddress)localObject2).encodedPersonal = unquote(paramString.substring(n, m).trim());
                    i5 = -1;
                    i6 = -1;
                  }
                  localVector.addElement(localObject2);
                  bool1 = false;
                  j = 0;
                  i2 = -1;
                  k = -1;
                  i7 = i9;
                  i4 = i;
                }
                else
                {
                  localObject1 = new StringTokenizer((String)localObject1);
                  for (;;)
                  {
                    i5 = m;
                    i6 = n;
                    if (!((StringTokenizer)localObject1).hasMoreTokens()) {
                      break;
                    }
                    localObject2 = ((StringTokenizer)localObject1).nextToken();
                    checkAddress((String)localObject2, false, false);
                    InternetAddress localInternetAddress = new InternetAddress();
                    localInternetAddress.setAddress((String)localObject2);
                    localVector.addElement(localInternetAddress);
                  }
                  i8 = 1;
                  if (i9 != 0) {
                    throw new AddressException("Nested group", paramString, i);
                  }
                  i9 = 1;
                  i2 = i3;
                  i5 = m;
                  i7 = i9;
                  i4 = i;
                  j = i8;
                  bool1 = bool2;
                  k = i1;
                  i6 = n;
                  if (i1 == -1)
                  {
                    k = i;
                    i2 = i3;
                    i5 = m;
                    i7 = i9;
                    i4 = i;
                    j = i8;
                    bool1 = bool2;
                    i6 = n;
                    continue;
                    j = i1;
                    if (i1 == -1) {
                      j = i;
                    }
                    if (i9 == 0) {
                      throw new AddressException("Illegal semicolon, not in group", paramString, i);
                    }
                    i7 = 0;
                    k = j;
                    if (j == -1) {
                      k = i;
                    }
                    localObject1 = new InternetAddress();
                    ((InternetAddress)localObject1).setAddress(paramString.substring(k, i + 1).trim());
                    localVector.addElement(localObject1);
                    bool1 = false;
                    i2 = -1;
                    k = -1;
                    i5 = m;
                    i4 = i;
                    j = i8;
                    i6 = n;
                  }
                }
              }
            }
          }
        }
      }
      label1564:
      paramString = new StringTokenizer((String)localObject1);
      while (paramString.hasMoreTokens())
      {
        localObject1 = paramString.nextToken();
        checkAddress((String)localObject1, false, false);
        localObject2 = new InternetAddress();
        ((InternetAddress)localObject2).setAddress((String)localObject1);
        localVector.addElement(localObject2);
      }
    }
  }
  
  public static InternetAddress[] parseHeader(String paramString, boolean paramBoolean)
    throws AddressException
  {
    return parse(paramString, paramBoolean, true);
  }
  
  private static String quotePhrase(String paramString)
  {
    int k = paramString.length();
    int j = 0;
    int i = 0;
    for (;;)
    {
      Object localObject;
      if (i >= k)
      {
        localObject = paramString;
        if (j != 0)
        {
          localObject = new StringBuffer(k + 2);
          ((StringBuffer)localObject).append('"').append(paramString).append('"');
          localObject = ((StringBuffer)localObject).toString();
        }
        return (String)localObject;
      }
      int m = paramString.charAt(i);
      if ((m == 34) || (m == 92))
      {
        localObject = new StringBuffer(k + 3);
        ((StringBuffer)localObject).append('"');
        i = 0;
        for (;;)
        {
          if (i >= k)
          {
            ((StringBuffer)localObject).append('"');
            return ((StringBuffer)localObject).toString();
          }
          char c = paramString.charAt(i);
          if ((c == '"') || (c == '\\')) {
            ((StringBuffer)localObject).append('\\');
          }
          ((StringBuffer)localObject).append(c);
          i += 1;
        }
      }
      if (((m < 32) && (m != 13) && (m != 10) && (m != 9)) || (m >= 127) || (rfc822phrase.indexOf(m) >= 0)) {
        j = 1;
      }
      i += 1;
    }
  }
  
  public static String toString(Address[] paramArrayOfAddress)
  {
    return toString(paramArrayOfAddress, 0);
  }
  
  public static String toString(Address[] paramArrayOfAddress, int paramInt)
  {
    if ((paramArrayOfAddress == null) || (paramArrayOfAddress.length == 0)) {
      return null;
    }
    StringBuffer localStringBuffer = new StringBuffer();
    int j = 0;
    for (;;)
    {
      if (j >= paramArrayOfAddress.length) {
        return localStringBuffer.toString();
      }
      int i = paramInt;
      if (j != 0)
      {
        localStringBuffer.append(", ");
        i = paramInt + 2;
      }
      String str = paramArrayOfAddress[j].toString();
      paramInt = i;
      if (i + lengthOfFirstSegment(str) > 76)
      {
        localStringBuffer.append("\r\n\t");
        paramInt = 8;
      }
      localStringBuffer.append(str);
      paramInt = lengthOfLastSegment(str, paramInt);
      j += 1;
    }
  }
  
  private static String unquote(String paramString)
  {
    Object localObject = paramString;
    if (paramString.startsWith("\""))
    {
      localObject = paramString;
      if (paramString.endsWith("\""))
      {
        paramString = paramString.substring(1, paramString.length() - 1);
        localObject = paramString;
        if (paramString.indexOf('\\') >= 0) {
          localObject = new StringBuffer(paramString.length());
        }
      }
    }
    int j;
    for (int i = 0;; i = j + 1)
    {
      if (i >= paramString.length())
      {
        localObject = ((StringBuffer)localObject).toString();
        return (String)localObject;
      }
      char c2 = paramString.charAt(i);
      char c1 = c2;
      j = i;
      if (c2 == '\\')
      {
        c1 = c2;
        j = i;
        if (i < paramString.length() - 1)
        {
          j = i + 1;
          c1 = paramString.charAt(j);
        }
      }
      ((StringBuffer)localObject).append(c1);
    }
  }
  
  public Object clone()
  {
    try
    {
      InternetAddress localInternetAddress = (InternetAddress)super.clone();
      return localInternetAddress;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException) {}
    return null;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof InternetAddress)) {}
    do
    {
      return false;
      paramObject = ((InternetAddress)paramObject).getAddress();
      if (paramObject == this.address) {
        return true;
      }
    } while ((this.address == null) || (!this.address.equalsIgnoreCase((String)paramObject)));
    return true;
  }
  
  public String getAddress()
  {
    return this.address;
  }
  
  public InternetAddress[] getGroup(boolean paramBoolean)
    throws AddressException
  {
    String str = getAddress();
    if (!str.endsWith(";")) {}
    int i;
    do
    {
      return null;
      i = str.indexOf(':');
    } while (i < 0);
    return parseHeader(str.substring(i + 1, str.length() - 1), paramBoolean);
  }
  
  public String getPersonal()
  {
    if (this.personal != null) {
      return this.personal;
    }
    if (this.encodedPersonal != null) {
      try
      {
        this.personal = MimeUtility.decodeText(this.encodedPersonal);
        String str = this.personal;
        return str;
      }
      catch (Exception localException)
      {
        return this.encodedPersonal;
      }
    }
    return null;
  }
  
  public String getType()
  {
    return "rfc822";
  }
  
  public int hashCode()
  {
    if (this.address == null) {
      return 0;
    }
    return this.address.toLowerCase(Locale.ENGLISH).hashCode();
  }
  
  public boolean isGroup()
  {
    return (this.address != null) && (this.address.endsWith(";")) && (this.address.indexOf(':') > 0);
  }
  
  public void setAddress(String paramString)
  {
    this.address = paramString;
  }
  
  public void setPersonal(String paramString)
    throws UnsupportedEncodingException
  {
    this.personal = paramString;
    if (paramString != null)
    {
      this.encodedPersonal = MimeUtility.encodeWord(paramString);
      return;
    }
    this.encodedPersonal = null;
  }
  
  public void setPersonal(String paramString1, String paramString2)
    throws UnsupportedEncodingException
  {
    this.personal = paramString1;
    if (paramString1 != null)
    {
      this.encodedPersonal = MimeUtility.encodeWord(paramString1, paramString2, null);
      return;
    }
    this.encodedPersonal = null;
  }
  
  public String toString()
  {
    if ((this.encodedPersonal == null) && (this.personal != null)) {}
    try
    {
      this.encodedPersonal = MimeUtility.encodeWord(this.personal);
      if (this.encodedPersonal != null) {
        return quotePhrase(this.encodedPersonal) + " <" + this.address + ">";
      }
      if ((isGroup()) || (isSimple())) {
        return this.address;
      }
      return "<" + this.address + ">";
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      for (;;) {}
    }
  }
  
  public String toUnicodeString()
  {
    String str = getPersonal();
    if (str != null) {
      return quotePhrase(str) + " <" + this.address + ">";
    }
    if ((isGroup()) || (isSimple())) {
      return this.address;
    }
    return "<" + this.address + ">";
  }
  
  public void validate()
    throws AddressException
  {
    checkAddress(getAddress(), true, true);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/internet/InternetAddress.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */