package javax.mail.internet;

import java.util.Locale;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.mail.Address;

public class NewsAddress
  extends Address
{
  private static final long serialVersionUID = -4203797299824684143L;
  protected String host;
  protected String newsgroup;
  
  public NewsAddress() {}
  
  public NewsAddress(String paramString)
  {
    this(paramString, null);
  }
  
  public NewsAddress(String paramString1, String paramString2)
  {
    this.newsgroup = paramString1;
    this.host = paramString2;
  }
  
  public static NewsAddress[] parse(String paramString)
    throws AddressException
  {
    Object localObject = new StringTokenizer(paramString, ",");
    paramString = new Vector();
    for (;;)
    {
      if (!((StringTokenizer)localObject).hasMoreTokens())
      {
        int i = paramString.size();
        localObject = new NewsAddress[i];
        if (i > 0) {
          paramString.copyInto((Object[])localObject);
        }
        return (NewsAddress[])localObject;
      }
      paramString.addElement(new NewsAddress(((StringTokenizer)localObject).nextToken()));
    }
  }
  
  public static String toString(Address[] paramArrayOfAddress)
  {
    if ((paramArrayOfAddress == null) || (paramArrayOfAddress.length == 0)) {
      return null;
    }
    StringBuffer localStringBuffer = new StringBuffer(((NewsAddress)paramArrayOfAddress[0]).toString());
    int i = 1;
    for (;;)
    {
      if (i >= paramArrayOfAddress.length) {
        return localStringBuffer.toString();
      }
      localStringBuffer.append(",").append(((NewsAddress)paramArrayOfAddress[i]).toString());
      i += 1;
    }
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof NewsAddress)) {}
    do
    {
      return false;
      paramObject = (NewsAddress)paramObject;
    } while ((!this.newsgroup.equals(((NewsAddress)paramObject).newsgroup)) || (((this.host != null) || (((NewsAddress)paramObject).host != null)) && ((this.host == null) || (((NewsAddress)paramObject).host == null) || (!this.host.equalsIgnoreCase(((NewsAddress)paramObject).host)))));
    return true;
  }
  
  public String getHost()
  {
    return this.host;
  }
  
  public String getNewsgroup()
  {
    return this.newsgroup;
  }
  
  public String getType()
  {
    return "news";
  }
  
  public int hashCode()
  {
    int i = 0;
    if (this.newsgroup != null) {
      i = 0 + this.newsgroup.hashCode();
    }
    int j = i;
    if (this.host != null) {
      j = i + this.host.toLowerCase(Locale.ENGLISH).hashCode();
    }
    return j;
  }
  
  public void setHost(String paramString)
  {
    this.host = paramString;
  }
  
  public void setNewsgroup(String paramString)
  {
    this.newsgroup = paramString;
  }
  
  public String toString()
  {
    return this.newsgroup;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/internet/NewsAddress.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */