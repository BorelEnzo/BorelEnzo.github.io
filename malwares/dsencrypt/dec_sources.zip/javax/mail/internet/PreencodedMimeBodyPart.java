package javax.mail.internet;

import com.sun.mail.util.LineOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Enumeration;
import javax.activation.DataHandler;
import javax.mail.MessagingException;

public class PreencodedMimeBodyPart
  extends MimeBodyPart
{
  private String encoding;
  
  public PreencodedMimeBodyPart(String paramString)
  {
    this.encoding = paramString;
  }
  
  public String getEncoding()
    throws MessagingException
  {
    return this.encoding;
  }
  
  protected void updateHeaders()
    throws MessagingException
  {
    super.updateHeaders();
    MimeBodyPart.setEncoding(this, this.encoding);
  }
  
  public void writeTo(OutputStream paramOutputStream)
    throws IOException, MessagingException
  {
    LineOutputStream localLineOutputStream;
    Enumeration localEnumeration;
    if ((paramOutputStream instanceof LineOutputStream))
    {
      localLineOutputStream = (LineOutputStream)paramOutputStream;
      localEnumeration = getAllHeaderLines();
    }
    for (;;)
    {
      if (!localEnumeration.hasMoreElements())
      {
        localLineOutputStream.writeln();
        getDataHandler().writeTo(paramOutputStream);
        paramOutputStream.flush();
        return;
        localLineOutputStream = new LineOutputStream(paramOutputStream);
        break;
      }
      localLineOutputStream.writeln((String)localEnumeration.nextElement());
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/internet/PreencodedMimeBodyPart.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */