package javax.mail;

public class IllegalWriteException
  extends MessagingException
{
  private static final long serialVersionUID = 3974370223328268013L;
  
  public IllegalWriteException() {}
  
  public IllegalWriteException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/IllegalWriteException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */