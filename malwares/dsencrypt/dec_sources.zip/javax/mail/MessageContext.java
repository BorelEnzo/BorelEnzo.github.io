package javax.mail;

public class MessageContext
{
  private Part part;
  
  public MessageContext(Part paramPart)
  {
    this.part = paramPart;
  }
  
  private static Message getMessage(Part paramPart)
    throws MessagingException
  {
    for (;;)
    {
      if (paramPart == null) {
        return null;
      }
      if ((paramPart instanceof Message)) {
        return (Message)paramPart;
      }
      paramPart = ((BodyPart)paramPart).getParent();
      if (paramPart == null) {
        return null;
      }
      paramPart = paramPart.getParent();
    }
  }
  
  public Message getMessage()
  {
    try
    {
      Message localMessage = getMessage(this.part);
      return localMessage;
    }
    catch (MessagingException localMessagingException) {}
    return null;
  }
  
  public Part getPart()
  {
    return this.part;
  }
  
  public Session getSession()
  {
    Message localMessage = getMessage();
    if (localMessage != null) {
      return localMessage.session;
    }
    return null;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/MessageContext.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */