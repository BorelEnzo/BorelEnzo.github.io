package javax.mail;

public class FolderNotFoundException
  extends MessagingException
{
  private static final long serialVersionUID = 472612108891249403L;
  private transient Folder folder;
  
  public FolderNotFoundException() {}
  
  public FolderNotFoundException(String paramString, Folder paramFolder)
  {
    super(paramString);
    this.folder = paramFolder;
  }
  
  public FolderNotFoundException(Folder paramFolder)
  {
    this.folder = paramFolder;
  }
  
  public FolderNotFoundException(Folder paramFolder, String paramString)
  {
    super(paramString);
    this.folder = paramFolder;
  }
  
  public Folder getFolder()
  {
    return this.folder;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/FolderNotFoundException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */