package javax.mail;

import java.io.InvalidObjectException;
import java.io.ObjectStreamException;
import java.io.Serializable;
import java.util.Date;
import javax.mail.search.SearchTerm;

public abstract class Message
  implements Part
{
  protected boolean expunged = false;
  protected Folder folder = null;
  protected int msgnum = 0;
  protected Session session = null;
  
  protected Message() {}
  
  protected Message(Folder paramFolder, int paramInt)
  {
    this.folder = paramFolder;
    this.msgnum = paramInt;
    this.session = paramFolder.store.session;
  }
  
  protected Message(Session paramSession)
  {
    this.session = paramSession;
  }
  
  public abstract void addFrom(Address[] paramArrayOfAddress)
    throws MessagingException;
  
  public void addRecipient(RecipientType paramRecipientType, Address paramAddress)
    throws MessagingException
  {
    addRecipients(paramRecipientType, new Address[] { paramAddress });
  }
  
  public abstract void addRecipients(RecipientType paramRecipientType, Address[] paramArrayOfAddress)
    throws MessagingException;
  
  public Address[] getAllRecipients()
    throws MessagingException
  {
    Address[] arrayOfAddress1 = getRecipients(RecipientType.TO);
    Address[] arrayOfAddress2 = getRecipients(RecipientType.CC);
    Address[] arrayOfAddress3 = getRecipients(RecipientType.BCC);
    if ((arrayOfAddress2 == null) && (arrayOfAddress3 == null)) {
      return arrayOfAddress1;
    }
    int i;
    int j;
    if (arrayOfAddress1 != null)
    {
      i = arrayOfAddress1.length;
      if (arrayOfAddress2 == null) {
        break label156;
      }
      j = arrayOfAddress2.length;
      label58:
      if (arrayOfAddress3 == null) {
        break label161;
      }
    }
    label156:
    label161:
    for (int k = arrayOfAddress3.length;; k = 0)
    {
      Address[] arrayOfAddress4 = new Address[i + j + k];
      i = 0;
      if (arrayOfAddress1 != null)
      {
        System.arraycopy(arrayOfAddress1, 0, arrayOfAddress4, 0, arrayOfAddress1.length);
        i = 0 + arrayOfAddress1.length;
      }
      j = i;
      if (arrayOfAddress2 != null)
      {
        System.arraycopy(arrayOfAddress2, 0, arrayOfAddress4, i, arrayOfAddress2.length);
        j = i + arrayOfAddress2.length;
      }
      if (arrayOfAddress3 != null)
      {
        System.arraycopy(arrayOfAddress3, 0, arrayOfAddress4, j, arrayOfAddress3.length);
        i = arrayOfAddress3.length;
      }
      return arrayOfAddress4;
      i = 0;
      break;
      j = 0;
      break label58;
    }
  }
  
  public abstract Flags getFlags()
    throws MessagingException;
  
  public Folder getFolder()
  {
    return this.folder;
  }
  
  public abstract Address[] getFrom()
    throws MessagingException;
  
  public int getMessageNumber()
  {
    return this.msgnum;
  }
  
  public abstract Date getReceivedDate()
    throws MessagingException;
  
  public abstract Address[] getRecipients(RecipientType paramRecipientType)
    throws MessagingException;
  
  public Address[] getReplyTo()
    throws MessagingException
  {
    return getFrom();
  }
  
  public abstract Date getSentDate()
    throws MessagingException;
  
  public abstract String getSubject()
    throws MessagingException;
  
  public boolean isExpunged()
  {
    return this.expunged;
  }
  
  public boolean isSet(Flags.Flag paramFlag)
    throws MessagingException
  {
    return getFlags().contains(paramFlag);
  }
  
  public boolean match(SearchTerm paramSearchTerm)
    throws MessagingException
  {
    return paramSearchTerm.match(this);
  }
  
  public abstract Message reply(boolean paramBoolean)
    throws MessagingException;
  
  public abstract void saveChanges()
    throws MessagingException;
  
  protected void setExpunged(boolean paramBoolean)
  {
    this.expunged = paramBoolean;
  }
  
  public void setFlag(Flags.Flag paramFlag, boolean paramBoolean)
    throws MessagingException
  {
    setFlags(new Flags(paramFlag), paramBoolean);
  }
  
  public abstract void setFlags(Flags paramFlags, boolean paramBoolean)
    throws MessagingException;
  
  public abstract void setFrom()
    throws MessagingException;
  
  public abstract void setFrom(Address paramAddress)
    throws MessagingException;
  
  protected void setMessageNumber(int paramInt)
  {
    this.msgnum = paramInt;
  }
  
  public void setRecipient(RecipientType paramRecipientType, Address paramAddress)
    throws MessagingException
  {
    setRecipients(paramRecipientType, new Address[] { paramAddress });
  }
  
  public abstract void setRecipients(RecipientType paramRecipientType, Address[] paramArrayOfAddress)
    throws MessagingException;
  
  public void setReplyTo(Address[] paramArrayOfAddress)
    throws MessagingException
  {
    throw new MethodNotSupportedException("setReplyTo not supported");
  }
  
  public abstract void setSentDate(Date paramDate)
    throws MessagingException;
  
  public abstract void setSubject(String paramString)
    throws MessagingException;
  
  public static class RecipientType
    implements Serializable
  {
    public static final RecipientType BCC = new RecipientType("Bcc");
    public static final RecipientType CC;
    public static final RecipientType TO = new RecipientType("To");
    private static final long serialVersionUID = -7479791750606340008L;
    protected String type;
    
    static
    {
      CC = new RecipientType("Cc");
    }
    
    protected RecipientType(String paramString)
    {
      this.type = paramString;
    }
    
    protected Object readResolve()
      throws ObjectStreamException
    {
      if (this.type.equals("To")) {
        return TO;
      }
      if (this.type.equals("Cc")) {
        return CC;
      }
      if (this.type.equals("Bcc")) {
        return BCC;
      }
      throw new InvalidObjectException("Attempt to resolve unknown RecipientType: " + this.type);
    }
    
    public String toString()
    {
      return this.type;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/Message.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */