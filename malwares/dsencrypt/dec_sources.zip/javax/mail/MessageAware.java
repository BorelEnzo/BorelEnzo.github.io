package javax.mail;

public abstract interface MessageAware
{
  public abstract MessageContext getMessageContext();
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/MessageAware.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */