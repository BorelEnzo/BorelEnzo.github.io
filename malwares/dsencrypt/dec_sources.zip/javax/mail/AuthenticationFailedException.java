package javax.mail;

public class AuthenticationFailedException
  extends MessagingException
{
  private static final long serialVersionUID = 492080754054436511L;
  
  public AuthenticationFailedException() {}
  
  public AuthenticationFailedException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/AuthenticationFailedException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */