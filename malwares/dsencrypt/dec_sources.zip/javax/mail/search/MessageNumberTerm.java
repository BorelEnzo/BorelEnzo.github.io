package javax.mail.search;

import javax.mail.Message;

public final class MessageNumberTerm
  extends IntegerComparisonTerm
{
  private static final long serialVersionUID = -5379625829658623812L;
  
  public MessageNumberTerm(int paramInt)
  {
    super(3, paramInt);
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof MessageNumberTerm)) {
      return false;
    }
    return super.equals(paramObject);
  }
  
  public boolean match(Message paramMessage)
  {
    try
    {
      int i = paramMessage.getMessageNumber();
      return super.match(i);
    }
    catch (Exception paramMessage) {}
    return false;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/search/MessageNumberTerm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */