package javax.mail.search;

import java.util.Date;
import javax.mail.Message;

public final class SentDateTerm
  extends DateTerm
{
  private static final long serialVersionUID = 5647755030530907263L;
  
  public SentDateTerm(int paramInt, Date paramDate)
  {
    super(paramInt, paramDate);
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof SentDateTerm)) {
      return false;
    }
    return super.equals(paramObject);
  }
  
  public boolean match(Message paramMessage)
  {
    try
    {
      paramMessage = paramMessage.getSentDate();
      if (paramMessage == null) {
        return false;
      }
    }
    catch (Exception paramMessage)
    {
      return false;
    }
    return super.match(paramMessage);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/search/SentDateTerm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */