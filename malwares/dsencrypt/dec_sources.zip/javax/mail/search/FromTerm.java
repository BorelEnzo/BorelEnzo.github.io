package javax.mail.search;

import javax.mail.Address;
import javax.mail.Message;

public final class FromTerm
  extends AddressTerm
{
  private static final long serialVersionUID = 5214730291502658665L;
  
  public FromTerm(Address paramAddress)
  {
    super(paramAddress);
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof FromTerm)) {
      return false;
    }
    return super.equals(paramObject);
  }
  
  public boolean match(Message paramMessage)
  {
    try
    {
      paramMessage = paramMessage.getFrom();
      if (paramMessage == null) {
        return false;
      }
    }
    catch (Exception paramMessage)
    {
      return false;
    }
    int i = 0;
    while (i < paramMessage.length)
    {
      if (super.match(paramMessage[i])) {
        return true;
      }
      i += 1;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/search/FromTerm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */