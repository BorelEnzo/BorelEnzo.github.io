package javax.mail.search;

public abstract class IntegerComparisonTerm
  extends ComparisonTerm
{
  private static final long serialVersionUID = -6963571240154302484L;
  protected int number;
  
  protected IntegerComparisonTerm(int paramInt1, int paramInt2)
  {
    this.comparison = paramInt1;
    this.number = paramInt2;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof IntegerComparisonTerm)) {}
    while ((((IntegerComparisonTerm)paramObject).number != this.number) || (!super.equals(paramObject))) {
      return false;
    }
    return true;
  }
  
  public int getComparison()
  {
    return this.comparison;
  }
  
  public int getNumber()
  {
    return this.number;
  }
  
  public int hashCode()
  {
    return this.number + super.hashCode();
  }
  
  protected boolean match(int paramInt)
  {
    boolean bool = true;
    switch (this.comparison)
    {
    default: 
      bool = false;
    }
    do
    {
      do
      {
        do
        {
          do
          {
            do
            {
              do
              {
                return bool;
              } while (paramInt <= this.number);
              return false;
            } while (paramInt < this.number);
            return false;
          } while (paramInt == this.number);
          return false;
        } while (paramInt != this.number);
        return false;
      } while (paramInt > this.number);
      return false;
    } while (paramInt >= this.number);
    return false;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/search/IntegerComparisonTerm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */