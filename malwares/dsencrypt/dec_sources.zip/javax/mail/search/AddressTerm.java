package javax.mail.search;

import javax.mail.Address;

public abstract class AddressTerm
  extends SearchTerm
{
  private static final long serialVersionUID = 2005405551929769980L;
  protected Address address;
  
  protected AddressTerm(Address paramAddress)
  {
    this.address = paramAddress;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof AddressTerm)) {
      return false;
    }
    return ((AddressTerm)paramObject).address.equals(this.address);
  }
  
  public Address getAddress()
  {
    return this.address;
  }
  
  public int hashCode()
  {
    return this.address.hashCode();
  }
  
  protected boolean match(Address paramAddress)
  {
    return paramAddress.equals(this.address);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/search/AddressTerm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */