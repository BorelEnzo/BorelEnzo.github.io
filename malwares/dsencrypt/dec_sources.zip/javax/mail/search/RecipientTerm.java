package javax.mail.search;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.Message.RecipientType;

public final class RecipientTerm
  extends AddressTerm
{
  private static final long serialVersionUID = 6548700653122680468L;
  protected Message.RecipientType type;
  
  public RecipientTerm(Message.RecipientType paramRecipientType, Address paramAddress)
  {
    super(paramAddress);
    this.type = paramRecipientType;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof RecipientTerm)) {}
    while ((!((RecipientTerm)paramObject).type.equals(this.type)) || (!super.equals(paramObject))) {
      return false;
    }
    return true;
  }
  
  public Message.RecipientType getRecipientType()
  {
    return this.type;
  }
  
  public int hashCode()
  {
    return this.type.hashCode() + super.hashCode();
  }
  
  public boolean match(Message paramMessage)
  {
    try
    {
      paramMessage = paramMessage.getRecipients(this.type);
      if (paramMessage == null) {
        return false;
      }
    }
    catch (Exception paramMessage)
    {
      return false;
    }
    int i = 0;
    while (i < paramMessage.length)
    {
      if (super.match(paramMessage[i])) {
        return true;
      }
      i += 1;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/search/RecipientTerm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */