package javax.mail.search;

import javax.mail.MessagingException;

public class SearchException
  extends MessagingException
{
  private static final long serialVersionUID = -7092886778226268686L;
  
  public SearchException() {}
  
  public SearchException(String paramString)
  {
    super(paramString);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/search/SearchException.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */