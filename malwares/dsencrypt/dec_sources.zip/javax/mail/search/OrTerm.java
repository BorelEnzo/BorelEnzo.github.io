package javax.mail.search;

import javax.mail.Message;

public final class OrTerm
  extends SearchTerm
{
  private static final long serialVersionUID = 5380534067523646936L;
  protected SearchTerm[] terms;
  
  public OrTerm(SearchTerm paramSearchTerm1, SearchTerm paramSearchTerm2)
  {
    this.terms = new SearchTerm[2];
    this.terms[0] = paramSearchTerm1;
    this.terms[1] = paramSearchTerm2;
  }
  
  public OrTerm(SearchTerm[] paramArrayOfSearchTerm)
  {
    this.terms = new SearchTerm[paramArrayOfSearchTerm.length];
    int i = 0;
    for (;;)
    {
      if (i >= paramArrayOfSearchTerm.length) {
        return;
      }
      this.terms[i] = paramArrayOfSearchTerm[i];
      i += 1;
    }
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof OrTerm)) {}
    do
    {
      return false;
      paramObject = (OrTerm)paramObject;
    } while (((OrTerm)paramObject).terms.length != this.terms.length);
    int i = 0;
    for (;;)
    {
      if (i >= this.terms.length) {
        return true;
      }
      if (!this.terms[i].equals(paramObject.terms[i])) {
        break;
      }
      i += 1;
    }
  }
  
  public SearchTerm[] getTerms()
  {
    return (SearchTerm[])this.terms.clone();
  }
  
  public int hashCode()
  {
    int j = 0;
    int i = 0;
    for (;;)
    {
      if (i >= this.terms.length) {
        return j;
      }
      j += this.terms[i].hashCode();
      i += 1;
    }
  }
  
  public boolean match(Message paramMessage)
  {
    int i = 0;
    for (;;)
    {
      if (i >= this.terms.length) {
        return false;
      }
      if (this.terms[i].match(paramMessage)) {
        return true;
      }
      i += 1;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/search/OrTerm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */