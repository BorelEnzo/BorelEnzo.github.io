package javax.mail.search;

import javax.mail.Flags;
import javax.mail.Message;

public final class FlagTerm
  extends SearchTerm
{
  private static final long serialVersionUID = -142991500302030647L;
  protected Flags flags;
  protected boolean set;
  
  public FlagTerm(Flags paramFlags, boolean paramBoolean)
  {
    this.flags = paramFlags;
    this.set = paramBoolean;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof FlagTerm)) {}
    do
    {
      return false;
      paramObject = (FlagTerm)paramObject;
    } while ((((FlagTerm)paramObject).set != this.set) || (!((FlagTerm)paramObject).flags.equals(this.flags)));
    return true;
  }
  
  public Flags getFlags()
  {
    return (Flags)this.flags.clone();
  }
  
  public boolean getTestSet()
  {
    return this.set;
  }
  
  public int hashCode()
  {
    if (this.set) {
      return this.flags.hashCode();
    }
    return this.flags.hashCode() ^ 0xFFFFFFFF;
  }
  
  public boolean match(Message paramMessage)
  {
    boolean bool2 = true;
    try
    {
      paramMessage = paramMessage.getFlags();
      if (this.set)
      {
        if (paramMessage.contains(this.flags)) {
          return true;
        }
      }
      else
      {
        Object localObject = this.flags.getSystemFlags();
        int i = 0;
        if (i >= localObject.length)
        {
          localObject = this.flags.getUserFlags();
          i = 0;
        }
        boolean bool1;
        for (;;)
        {
          bool1 = bool2;
          if (i >= localObject.length) {
            break label112;
          }
          if (paramMessage.contains(localObject[i]))
          {
            return false;
            bool1 = paramMessage.contains(localObject[i]);
            if (bool1) {
              return false;
            }
            i += 1;
            break;
          }
          i += 1;
        }
        return bool1;
      }
    }
    catch (Exception paramMessage)
    {
      bool1 = false;
    }
    label112:
    return false;
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/search/FlagTerm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */