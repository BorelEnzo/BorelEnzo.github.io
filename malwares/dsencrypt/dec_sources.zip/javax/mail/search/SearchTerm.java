package javax.mail.search;

import java.io.Serializable;
import javax.mail.Message;

public abstract class SearchTerm
  implements Serializable
{
  private static final long serialVersionUID = -6652358452205992789L;
  
  public abstract boolean match(Message paramMessage);
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/search/SearchTerm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */