package javax.mail.search;

import javax.mail.Message;
import javax.mail.Message.RecipientType;

public final class RecipientStringTerm
  extends AddressStringTerm
{
  private static final long serialVersionUID = -8293562089611618849L;
  private Message.RecipientType type;
  
  public RecipientStringTerm(Message.RecipientType paramRecipientType, String paramString)
  {
    super(paramString);
    this.type = paramRecipientType;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof RecipientStringTerm)) {}
    while ((!((RecipientStringTerm)paramObject).type.equals(this.type)) || (!super.equals(paramObject))) {
      return false;
    }
    return true;
  }
  
  public Message.RecipientType getRecipientType()
  {
    return this.type;
  }
  
  public int hashCode()
  {
    return this.type.hashCode() + super.hashCode();
  }
  
  public boolean match(Message paramMessage)
  {
    try
    {
      paramMessage = paramMessage.getRecipients(this.type);
      if (paramMessage == null) {
        return false;
      }
    }
    catch (Exception paramMessage)
    {
      return false;
    }
    int i = 0;
    while (i < paramMessage.length)
    {
      if (super.match(paramMessage[i])) {
        return true;
      }
      i += 1;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/search/RecipientStringTerm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */