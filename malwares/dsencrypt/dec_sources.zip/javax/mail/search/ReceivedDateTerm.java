package javax.mail.search;

import java.util.Date;
import javax.mail.Message;

public final class ReceivedDateTerm
  extends DateTerm
{
  private static final long serialVersionUID = -2756695246195503170L;
  
  public ReceivedDateTerm(int paramInt, Date paramDate)
  {
    super(paramInt, paramDate);
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof ReceivedDateTerm)) {
      return false;
    }
    return super.equals(paramObject);
  }
  
  public boolean match(Message paramMessage)
  {
    try
    {
      paramMessage = paramMessage.getReceivedDate();
      if (paramMessage == null) {
        return false;
      }
    }
    catch (Exception paramMessage)
    {
      return false;
    }
    return super.match(paramMessage);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/search/ReceivedDateTerm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */