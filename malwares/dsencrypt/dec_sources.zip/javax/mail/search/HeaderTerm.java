package javax.mail.search;

import java.util.Locale;
import javax.mail.Message;

public final class HeaderTerm
  extends StringTerm
{
  private static final long serialVersionUID = 8342514650333389122L;
  protected String headerName;
  
  public HeaderTerm(String paramString1, String paramString2)
  {
    super(paramString2);
    this.headerName = paramString1;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof HeaderTerm)) {}
    do
    {
      return false;
      paramObject = (HeaderTerm)paramObject;
    } while ((!((HeaderTerm)paramObject).headerName.equalsIgnoreCase(this.headerName)) || (!super.equals(paramObject)));
    return true;
  }
  
  public String getHeaderName()
  {
    return this.headerName;
  }
  
  public int hashCode()
  {
    return this.headerName.toLowerCase(Locale.ENGLISH).hashCode() + super.hashCode();
  }
  
  public boolean match(Message paramMessage)
  {
    try
    {
      paramMessage = paramMessage.getHeader(this.headerName);
      if (paramMessage == null) {
        return false;
      }
    }
    catch (Exception paramMessage)
    {
      return false;
    }
    int i = 0;
    while (i < paramMessage.length)
    {
      if (super.match(paramMessage[i])) {
        return true;
      }
      i += 1;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/search/HeaderTerm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */