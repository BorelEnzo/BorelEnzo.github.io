package javax.mail.search;

public abstract class StringTerm
  extends SearchTerm
{
  private static final long serialVersionUID = 1274042129007696269L;
  protected boolean ignoreCase;
  protected String pattern;
  
  protected StringTerm(String paramString)
  {
    this.pattern = paramString;
    this.ignoreCase = true;
  }
  
  protected StringTerm(String paramString, boolean paramBoolean)
  {
    this.pattern = paramString;
    this.ignoreCase = paramBoolean;
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof StringTerm)) {}
    do
    {
      do
      {
        return false;
        paramObject = (StringTerm)paramObject;
        if (!this.ignoreCase) {
          break;
        }
      } while ((!((StringTerm)paramObject).pattern.equalsIgnoreCase(this.pattern)) || (((StringTerm)paramObject).ignoreCase != this.ignoreCase));
      return true;
    } while ((!((StringTerm)paramObject).pattern.equals(this.pattern)) || (((StringTerm)paramObject).ignoreCase != this.ignoreCase));
    return true;
  }
  
  public boolean getIgnoreCase()
  {
    return this.ignoreCase;
  }
  
  public String getPattern()
  {
    return this.pattern;
  }
  
  public int hashCode()
  {
    if (this.ignoreCase) {
      return this.pattern.hashCode();
    }
    return this.pattern.hashCode() ^ 0xFFFFFFFF;
  }
  
  protected boolean match(String paramString)
  {
    int j = paramString.length();
    int k = this.pattern.length();
    int i = 0;
    for (;;)
    {
      if (i > j - k) {
        return false;
      }
      if (paramString.regionMatches(this.ignoreCase, i, this.pattern, 0, this.pattern.length())) {
        return true;
      }
      i += 1;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/search/StringTerm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */