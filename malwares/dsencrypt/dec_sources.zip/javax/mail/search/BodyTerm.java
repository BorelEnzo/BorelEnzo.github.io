package javax.mail.search;

import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Part;

public final class BodyTerm
  extends StringTerm
{
  private static final long serialVersionUID = -4888862527916911385L;
  
  public BodyTerm(String paramString)
  {
    super(paramString);
  }
  
  private boolean matchPart(Part paramPart)
  {
    int j;
    int i;
    try
    {
      if (paramPart.isMimeType("text/*"))
      {
        paramPart = (String)paramPart.getContent();
        if (paramPart == null) {
          return false;
        }
        return super.match(paramPart);
      }
      if (paramPart.isMimeType("multipart/*"))
      {
        paramPart = (Multipart)paramPart.getContent();
        j = paramPart.getCount();
        i = 0;
        break label111;
        if (!matchPart(paramPart.getBodyPart(i))) {
          break label118;
        }
        return true;
      }
      else
      {
        if (!paramPart.isMimeType("message/rfc822")) {
          break label116;
        }
        boolean bool = matchPart((Part)paramPart.getContent());
        return bool;
      }
    }
    catch (Exception paramPart) {}
    label111:
    while (i >= j)
    {
      label116:
      return false;
      label118:
      i += 1;
    }
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof BodyTerm)) {
      return false;
    }
    return super.equals(paramObject);
  }
  
  public boolean match(Message paramMessage)
  {
    return matchPart(paramMessage);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/search/BodyTerm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */