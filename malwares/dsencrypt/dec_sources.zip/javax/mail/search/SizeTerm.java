package javax.mail.search;

import javax.mail.Message;

public final class SizeTerm
  extends IntegerComparisonTerm
{
  private static final long serialVersionUID = -2556219451005103709L;
  
  public SizeTerm(int paramInt1, int paramInt2)
  {
    super(paramInt1, paramInt2);
  }
  
  public boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof SizeTerm)) {
      return false;
    }
    return super.equals(paramObject);
  }
  
  public boolean match(Message paramMessage)
  {
    int i;
    try
    {
      i = paramMessage.getSize();
      if (i == -1) {
        return false;
      }
    }
    catch (Exception paramMessage)
    {
      return false;
    }
    return super.match(i);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/search/SizeTerm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */