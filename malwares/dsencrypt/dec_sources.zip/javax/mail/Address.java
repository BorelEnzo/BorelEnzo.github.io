package javax.mail;

import java.io.Serializable;

public abstract class Address
  implements Serializable
{
  private static final long serialVersionUID = -5822459626751992278L;
  
  public abstract boolean equals(Object paramObject);
  
  public abstract String getType();
  
  public abstract String toString();
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/Address.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */