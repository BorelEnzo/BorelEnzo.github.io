package javax.mail;

import java.util.Vector;
import javax.mail.event.ConnectionEvent;
import javax.mail.event.ConnectionListener;
import javax.mail.event.FolderEvent;
import javax.mail.event.FolderListener;
import javax.mail.event.MailEvent;
import javax.mail.event.MessageChangedEvent;
import javax.mail.event.MessageChangedListener;
import javax.mail.event.MessageCountEvent;
import javax.mail.event.MessageCountListener;
import javax.mail.search.SearchTerm;

public abstract class Folder
{
  public static final int HOLDS_FOLDERS = 2;
  public static final int HOLDS_MESSAGES = 1;
  public static final int READ_ONLY = 1;
  public static final int READ_WRITE = 2;
  private volatile Vector connectionListeners = null;
  private volatile Vector folderListeners = null;
  private volatile Vector messageChangedListeners = null;
  private volatile Vector messageCountListeners = null;
  protected int mode = -1;
  private EventQueue q;
  private Object qLock = new Object();
  protected Store store;
  
  protected Folder(Store paramStore)
  {
    this.store = paramStore;
  }
  
  private void queueEvent(MailEvent paramMailEvent, Vector paramVector)
  {
    synchronized (this.qLock)
    {
      if (this.q == null) {
        this.q = new EventQueue();
      }
      paramVector = (Vector)paramVector.clone();
      this.q.enqueue(paramMailEvent, paramVector);
      return;
    }
  }
  
  private void terminateQueue()
  {
    synchronized (this.qLock)
    {
      if (this.q != null)
      {
        Vector localVector = new Vector();
        localVector.setSize(1);
        this.q.enqueue(new TerminatorEvent(), localVector);
        this.q = null;
      }
      return;
    }
  }
  
  public void addConnectionListener(ConnectionListener paramConnectionListener)
  {
    try
    {
      if (this.connectionListeners == null) {
        this.connectionListeners = new Vector();
      }
      this.connectionListeners.addElement(paramConnectionListener);
      return;
    }
    finally {}
  }
  
  public void addFolderListener(FolderListener paramFolderListener)
  {
    try
    {
      if (this.folderListeners == null) {
        this.folderListeners = new Vector();
      }
      this.folderListeners.addElement(paramFolderListener);
      return;
    }
    finally {}
  }
  
  public void addMessageChangedListener(MessageChangedListener paramMessageChangedListener)
  {
    try
    {
      if (this.messageChangedListeners == null) {
        this.messageChangedListeners = new Vector();
      }
      this.messageChangedListeners.addElement(paramMessageChangedListener);
      return;
    }
    finally {}
  }
  
  public void addMessageCountListener(MessageCountListener paramMessageCountListener)
  {
    try
    {
      if (this.messageCountListeners == null) {
        this.messageCountListeners = new Vector();
      }
      this.messageCountListeners.addElement(paramMessageCountListener);
      return;
    }
    finally {}
  }
  
  public abstract void appendMessages(Message[] paramArrayOfMessage)
    throws MessagingException;
  
  public abstract void close(boolean paramBoolean)
    throws MessagingException;
  
  public void copyMessages(Message[] paramArrayOfMessage, Folder paramFolder)
    throws MessagingException
  {
    if (!paramFolder.exists()) {
      throw new FolderNotFoundException(paramFolder.getFullName() + " does not exist", paramFolder);
    }
    paramFolder.appendMessages(paramArrayOfMessage);
  }
  
  public abstract boolean create(int paramInt)
    throws MessagingException;
  
  public abstract boolean delete(boolean paramBoolean)
    throws MessagingException;
  
  public abstract boolean exists()
    throws MessagingException;
  
  public abstract Message[] expunge()
    throws MessagingException;
  
  public void fetch(Message[] paramArrayOfMessage, FetchProfile paramFetchProfile)
    throws MessagingException
  {}
  
  protected void finalize()
    throws Throwable
  {
    super.finalize();
    terminateQueue();
  }
  
  public int getDeletedMessageCount()
    throws MessagingException
  {
    for (;;)
    {
      boolean bool;
      int j;
      try
      {
        bool = isOpen();
        if (!bool)
        {
          k = -1;
          return k;
        }
        i = 0;
        int m = getMessageCount();
        j = 1;
        k = i;
        if (j > m) {
          continue;
        }
      }
      finally {}
      try
      {
        bool = getMessage(j).isSet(Flags.Flag.DELETED);
        k = i;
        if (bool) {
          k = i + 1;
        }
      }
      catch (MessageRemovedException localMessageRemovedException)
      {
        k = i;
        continue;
      }
      j += 1;
      i = k;
    }
  }
  
  public abstract Folder getFolder(String paramString)
    throws MessagingException;
  
  public abstract String getFullName();
  
  public abstract Message getMessage(int paramInt)
    throws MessagingException;
  
  public abstract int getMessageCount()
    throws MessagingException;
  
  public Message[] getMessages()
    throws MessagingException
  {
    try
    {
      if (!isOpen()) {
        throw new IllegalStateException("Folder not open");
      }
    }
    finally {}
    int j = getMessageCount();
    Message[] arrayOfMessage = new Message[j];
    int i = 1;
    for (;;)
    {
      if (i > j) {
        return arrayOfMessage;
      }
      arrayOfMessage[(i - 1)] = getMessage(i);
      i += 1;
    }
  }
  
  /* Error */
  public Message[] getMessages(int paramInt1, int paramInt2)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iload_2
    //   3: iload_1
    //   4: isub
    //   5: iconst_1
    //   6: iadd
    //   7: anewarray 162	javax/mail/Message
    //   10: astore 4
    //   12: iload_1
    //   13: istore_3
    //   14: iload_3
    //   15: iload_2
    //   16: if_icmple +8 -> 24
    //   19: aload_0
    //   20: monitorexit
    //   21: aload 4
    //   23: areturn
    //   24: aload 4
    //   26: iload_3
    //   27: iload_1
    //   28: isub
    //   29: aload_0
    //   30: iload_3
    //   31: invokevirtual 154	javax/mail/Folder:getMessage	(I)Ljavax/mail/Message;
    //   34: aastore
    //   35: iload_3
    //   36: iconst_1
    //   37: iadd
    //   38: istore_3
    //   39: goto -25 -> 14
    //   42: astore 4
    //   44: aload_0
    //   45: monitorexit
    //   46: aload 4
    //   48: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	49	0	this	Folder
    //   0	49	1	paramInt1	int
    //   0	49	2	paramInt2	int
    //   13	26	3	i	int
    //   10	15	4	arrayOfMessage	Message[]
    //   42	5	4	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   2	12	42	finally
    //   24	35	42	finally
  }
  
  /* Error */
  public Message[] getMessages(int[] paramArrayOfInt)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_1
    //   3: arraylength
    //   4: istore_3
    //   5: iload_3
    //   6: anewarray 162	javax/mail/Message
    //   9: astore 4
    //   11: iconst_0
    //   12: istore_2
    //   13: iload_2
    //   14: iload_3
    //   15: if_icmplt +8 -> 23
    //   18: aload_0
    //   19: monitorexit
    //   20: aload 4
    //   22: areturn
    //   23: aload 4
    //   25: iload_2
    //   26: aload_0
    //   27: aload_1
    //   28: iload_2
    //   29: iaload
    //   30: invokevirtual 154	javax/mail/Folder:getMessage	(I)Ljavax/mail/Message;
    //   33: aastore
    //   34: iload_2
    //   35: iconst_1
    //   36: iadd
    //   37: istore_2
    //   38: goto -25 -> 13
    //   41: astore_1
    //   42: aload_0
    //   43: monitorexit
    //   44: aload_1
    //   45: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	46	0	this	Folder
    //   0	46	1	paramArrayOfInt	int[]
    //   12	26	2	i	int
    //   4	12	3	j	int
    //   9	15	4	arrayOfMessage	Message[]
    // Exception table:
    //   from	to	target	type
    //   2	11	41	finally
    //   23	34	41	finally
  }
  
  public int getMode()
  {
    if (!isOpen()) {
      throw new IllegalStateException("Folder not open");
    }
    return this.mode;
  }
  
  public abstract String getName();
  
  public int getNewMessageCount()
    throws MessagingException
  {
    for (;;)
    {
      boolean bool;
      int j;
      try
      {
        bool = isOpen();
        if (!bool)
        {
          k = -1;
          return k;
        }
        i = 0;
        int m = getMessageCount();
        j = 1;
        k = i;
        if (j > m) {
          continue;
        }
      }
      finally {}
      try
      {
        bool = getMessage(j).isSet(Flags.Flag.RECENT);
        k = i;
        if (bool) {
          k = i + 1;
        }
      }
      catch (MessageRemovedException localMessageRemovedException)
      {
        k = i;
        continue;
      }
      j += 1;
      i = k;
    }
  }
  
  public abstract Folder getParent()
    throws MessagingException;
  
  public abstract Flags getPermanentFlags();
  
  public abstract char getSeparator()
    throws MessagingException;
  
  public Store getStore()
  {
    return this.store;
  }
  
  public abstract int getType()
    throws MessagingException;
  
  public URLName getURLName()
    throws MessagingException
  {
    URLName localURLName = getStore().getURLName();
    String str = getFullName();
    StringBuffer localStringBuffer = new StringBuffer();
    getSeparator();
    if (str != null) {
      localStringBuffer.append(str);
    }
    return new URLName(localURLName.getProtocol(), localURLName.getHost(), localURLName.getPort(), localStringBuffer.toString(), localURLName.getUsername(), null);
  }
  
  public int getUnreadMessageCount()
    throws MessagingException
  {
    for (;;)
    {
      boolean bool;
      int j;
      try
      {
        bool = isOpen();
        if (!bool)
        {
          k = -1;
          return k;
        }
        i = 0;
        int m = getMessageCount();
        j = 1;
        k = i;
        if (j > m) {
          continue;
        }
      }
      finally {}
      try
      {
        bool = getMessage(j).isSet(Flags.Flag.SEEN);
        k = i;
        if (!bool) {
          k = i + 1;
        }
      }
      catch (MessageRemovedException localMessageRemovedException)
      {
        k = i;
        continue;
      }
      j += 1;
      i = k;
    }
  }
  
  public abstract boolean hasNewMessages()
    throws MessagingException;
  
  public abstract boolean isOpen();
  
  public boolean isSubscribed()
  {
    return true;
  }
  
  public Folder[] list()
    throws MessagingException
  {
    return list("%");
  }
  
  public abstract Folder[] list(String paramString)
    throws MessagingException;
  
  public Folder[] listSubscribed()
    throws MessagingException
  {
    return listSubscribed("%");
  }
  
  public Folder[] listSubscribed(String paramString)
    throws MessagingException
  {
    return list(paramString);
  }
  
  protected void notifyConnectionListeners(int paramInt)
  {
    if (this.connectionListeners != null) {
      queueEvent(new ConnectionEvent(this, paramInt), this.connectionListeners);
    }
    if (paramInt == 3) {
      terminateQueue();
    }
  }
  
  protected void notifyFolderListeners(int paramInt)
  {
    if (this.folderListeners != null) {
      queueEvent(new FolderEvent(this, this, paramInt), this.folderListeners);
    }
    this.store.notifyFolderListeners(paramInt, this);
  }
  
  protected void notifyFolderRenamedListeners(Folder paramFolder)
  {
    if (this.folderListeners != null) {
      queueEvent(new FolderEvent(this, this, paramFolder, 3), this.folderListeners);
    }
    this.store.notifyFolderRenamedListeners(this, paramFolder);
  }
  
  protected void notifyMessageAddedListeners(Message[] paramArrayOfMessage)
  {
    if (this.messageCountListeners == null) {
      return;
    }
    queueEvent(new MessageCountEvent(this, 1, false, paramArrayOfMessage), this.messageCountListeners);
  }
  
  protected void notifyMessageChangedListeners(int paramInt, Message paramMessage)
  {
    if (this.messageChangedListeners == null) {
      return;
    }
    queueEvent(new MessageChangedEvent(this, paramInt, paramMessage), this.messageChangedListeners);
  }
  
  protected void notifyMessageRemovedListeners(boolean paramBoolean, Message[] paramArrayOfMessage)
  {
    if (this.messageCountListeners == null) {
      return;
    }
    queueEvent(new MessageCountEvent(this, 2, paramBoolean, paramArrayOfMessage), this.messageCountListeners);
  }
  
  public abstract void open(int paramInt)
    throws MessagingException;
  
  public void removeConnectionListener(ConnectionListener paramConnectionListener)
  {
    try
    {
      if (this.connectionListeners != null) {
        this.connectionListeners.removeElement(paramConnectionListener);
      }
      return;
    }
    finally
    {
      paramConnectionListener = finally;
      throw paramConnectionListener;
    }
  }
  
  public void removeFolderListener(FolderListener paramFolderListener)
  {
    try
    {
      if (this.folderListeners != null) {
        this.folderListeners.removeElement(paramFolderListener);
      }
      return;
    }
    finally
    {
      paramFolderListener = finally;
      throw paramFolderListener;
    }
  }
  
  public void removeMessageChangedListener(MessageChangedListener paramMessageChangedListener)
  {
    try
    {
      if (this.messageChangedListeners != null) {
        this.messageChangedListeners.removeElement(paramMessageChangedListener);
      }
      return;
    }
    finally
    {
      paramMessageChangedListener = finally;
      throw paramMessageChangedListener;
    }
  }
  
  public void removeMessageCountListener(MessageCountListener paramMessageCountListener)
  {
    try
    {
      if (this.messageCountListeners != null) {
        this.messageCountListeners.removeElement(paramMessageCountListener);
      }
      return;
    }
    finally
    {
      paramMessageCountListener = finally;
      throw paramMessageCountListener;
    }
  }
  
  public abstract boolean renameTo(Folder paramFolder)
    throws MessagingException;
  
  public Message[] search(SearchTerm paramSearchTerm)
    throws MessagingException
  {
    return search(paramSearchTerm, getMessages());
  }
  
  public Message[] search(SearchTerm paramSearchTerm, Message[] paramArrayOfMessage)
    throws MessagingException
  {
    Vector localVector = new Vector();
    int i = 0;
    for (;;)
    {
      if (i >= paramArrayOfMessage.length)
      {
        paramSearchTerm = new Message[localVector.size()];
        localVector.copyInto(paramSearchTerm);
        return paramSearchTerm;
      }
      try
      {
        if (paramArrayOfMessage[i].match(paramSearchTerm)) {
          localVector.addElement(paramArrayOfMessage[i]);
        }
        i += 1;
      }
      catch (MessageRemovedException localMessageRemovedException)
      {
        for (;;) {}
      }
    }
  }
  
  /* Error */
  public void setFlags(int paramInt1, int paramInt2, Flags paramFlags, boolean paramBoolean)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iload_1
    //   3: iload_2
    //   4: if_icmple +6 -> 10
    //   7: aload_0
    //   8: monitorexit
    //   9: return
    //   10: aload_0
    //   11: iload_1
    //   12: invokevirtual 154	javax/mail/Folder:getMessage	(I)Ljavax/mail/Message;
    //   15: aload_3
    //   16: iload 4
    //   18: invokevirtual 315	javax/mail/Message:setFlags	(Ljavax/mail/Flags;Z)V
    //   21: iload_1
    //   22: iconst_1
    //   23: iadd
    //   24: istore_1
    //   25: goto -23 -> 2
    //   28: astore_3
    //   29: aload_0
    //   30: monitorexit
    //   31: aload_3
    //   32: athrow
    //   33: astore 5
    //   35: goto -14 -> 21
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	38	0	this	Folder
    //   0	38	1	paramInt1	int
    //   0	38	2	paramInt2	int
    //   0	38	3	paramFlags	Flags
    //   0	38	4	paramBoolean	boolean
    //   33	1	5	localMessageRemovedException	MessageRemovedException
    // Exception table:
    //   from	to	target	type
    //   10	21	28	finally
    //   10	21	33	javax/mail/MessageRemovedException
  }
  
  /* Error */
  public void setFlags(int[] paramArrayOfInt, Flags paramFlags, boolean paramBoolean)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iconst_0
    //   3: istore 4
    //   5: aload_1
    //   6: arraylength
    //   7: istore 5
    //   9: iload 4
    //   11: iload 5
    //   13: if_icmplt +6 -> 19
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: aload_0
    //   20: aload_1
    //   21: iload 4
    //   23: iaload
    //   24: invokevirtual 154	javax/mail/Folder:getMessage	(I)Ljavax/mail/Message;
    //   27: aload_2
    //   28: iload_3
    //   29: invokevirtual 315	javax/mail/Message:setFlags	(Ljavax/mail/Flags;Z)V
    //   32: iload 4
    //   34: iconst_1
    //   35: iadd
    //   36: istore 4
    //   38: goto -33 -> 5
    //   41: astore_1
    //   42: aload_0
    //   43: monitorexit
    //   44: aload_1
    //   45: athrow
    //   46: astore 6
    //   48: goto -16 -> 32
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	51	0	this	Folder
    //   0	51	1	paramArrayOfInt	int[]
    //   0	51	2	paramFlags	Flags
    //   0	51	3	paramBoolean	boolean
    //   3	34	4	i	int
    //   7	7	5	j	int
    //   46	1	6	localMessageRemovedException	MessageRemovedException
    // Exception table:
    //   from	to	target	type
    //   5	9	41	finally
    //   19	32	41	finally
    //   19	32	46	javax/mail/MessageRemovedException
  }
  
  /* Error */
  public void setFlags(Message[] paramArrayOfMessage, Flags paramFlags, boolean paramBoolean)
    throws MessagingException
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: iconst_0
    //   3: istore 4
    //   5: aload_1
    //   6: arraylength
    //   7: istore 5
    //   9: iload 4
    //   11: iload 5
    //   13: if_icmplt +6 -> 19
    //   16: aload_0
    //   17: monitorexit
    //   18: return
    //   19: aload_1
    //   20: iload 4
    //   22: aaload
    //   23: aload_2
    //   24: iload_3
    //   25: invokevirtual 315	javax/mail/Message:setFlags	(Ljavax/mail/Flags;Z)V
    //   28: iload 4
    //   30: iconst_1
    //   31: iadd
    //   32: istore 4
    //   34: goto -29 -> 5
    //   37: astore_1
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_1
    //   41: athrow
    //   42: astore 6
    //   44: goto -16 -> 28
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	47	0	this	Folder
    //   0	47	1	paramArrayOfMessage	Message[]
    //   0	47	2	paramFlags	Flags
    //   0	47	3	paramBoolean	boolean
    //   3	30	4	i	int
    //   7	7	5	j	int
    //   42	1	6	localMessageRemovedException	MessageRemovedException
    // Exception table:
    //   from	to	target	type
    //   5	9	37	finally
    //   19	28	37	finally
    //   19	28	42	javax/mail/MessageRemovedException
  }
  
  public void setSubscribed(boolean paramBoolean)
    throws MessagingException
  {
    throw new MethodNotSupportedException();
  }
  
  public String toString()
  {
    String str = getFullName();
    if (str != null) {
      return str;
    }
    return super.toString();
  }
  
  static class TerminatorEvent
    extends MailEvent
  {
    private static final long serialVersionUID = 3765761925441296565L;
    
    TerminatorEvent()
    {
      super();
    }
    
    public void dispatch(Object paramObject)
    {
      Thread.currentThread().interrupt();
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/Folder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */