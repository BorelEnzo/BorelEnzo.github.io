package javax.mail;

import java.util.Vector;

public class FetchProfile
{
  private Vector headers = null;
  private Vector specials = null;
  
  public void add(String paramString)
  {
    if (this.headers == null) {
      this.headers = new Vector();
    }
    this.headers.addElement(paramString);
  }
  
  public void add(Item paramItem)
  {
    if (this.specials == null) {
      this.specials = new Vector();
    }
    this.specials.addElement(paramItem);
  }
  
  public boolean contains(String paramString)
  {
    return (this.headers != null) && (this.headers.contains(paramString));
  }
  
  public boolean contains(Item paramItem)
  {
    return (this.specials != null) && (this.specials.contains(paramItem));
  }
  
  public String[] getHeaderNames()
  {
    if (this.headers == null) {
      return new String[0];
    }
    String[] arrayOfString = new String[this.headers.size()];
    this.headers.copyInto(arrayOfString);
    return arrayOfString;
  }
  
  public Item[] getItems()
  {
    if (this.specials == null) {
      return new Item[0];
    }
    Item[] arrayOfItem = new Item[this.specials.size()];
    this.specials.copyInto(arrayOfItem);
    return arrayOfItem;
  }
  
  public static class Item
  {
    public static final Item CONTENT_INFO = new Item("CONTENT_INFO");
    public static final Item ENVELOPE = new Item("ENVELOPE");
    public static final Item FLAGS = new Item("FLAGS");
    private String name;
    
    protected Item(String paramString)
    {
      this.name = paramString;
    }
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/javax/mail/FetchProfile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */