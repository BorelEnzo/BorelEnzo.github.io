package android.support.v4.view;

import android.graphics.Paint;
import android.view.View;

class ViewCompatJellybeanMr1
{
  public static int getLabelFor(View paramView)
  {
    return paramView.getLabelFor();
  }
  
  public static int getLayoutDirection(View paramView)
  {
    return paramView.getLayoutDirection();
  }
  
  public static void setLabelFor(View paramView, int paramInt)
  {
    paramView.setLabelFor(paramInt);
  }
  
  public static void setLayerPaint(View paramView, Paint paramPaint)
  {
    paramView.setLayerPaint(paramPaint);
  }
  
  public static void setLayoutDirection(View paramView, int paramInt)
  {
    paramView.setLayoutDirection(paramInt);
  }
}


/* Location:              /home/enzo/Documents/BorelEnzo.github.io/malwares/dsencrypt/payload.jar!/android/support/v4/view/ViewCompatJellybeanMr1.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */