import android.text.Html;
import android.view.MenuItem;

public final class T
  extends S
{
  public final String a(CharSequence paramCharSequence)
  {
    return Html.escapeHtml(paramCharSequence);
  }
  
  final boolean a(MenuItem paramMenuItem)
  {
    return false;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/T.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */