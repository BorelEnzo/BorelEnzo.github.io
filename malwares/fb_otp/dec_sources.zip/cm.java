import android.app.SearchManager;
import android.content.ComponentName;
import android.content.Context;
import android.support.v4.widget.SearchViewCompat.OnCloseListenerCompat;
import android.support.v4.widget.SearchViewCompat.OnQueryTextListenerCompat;
import android.view.View;
import android.widget.SearchView;
import android.widget.SearchView.OnCloseListener;
import android.widget.SearchView.OnQueryTextListener;

public class cm
  extends cr
{
  public View a(Context paramContext)
  {
    return new SearchView(paramContext);
  }
  
  public final CharSequence a(View paramView)
  {
    return ((SearchView)paramView).getQuery();
  }
  
  public final Object a(SearchViewCompat.OnCloseListenerCompat paramOnCloseListenerCompat)
  {
    return new cu(new co(this, paramOnCloseListenerCompat));
  }
  
  public final Object a(SearchViewCompat.OnQueryTextListenerCompat paramOnQueryTextListenerCompat)
  {
    return new ct(new cn(this, paramOnQueryTextListenerCompat));
  }
  
  public final void a(View paramView, int paramInt)
  {
    ((SearchView)paramView).setMaxWidth(paramInt);
  }
  
  public final void a(View paramView, ComponentName paramComponentName)
  {
    paramView = (SearchView)paramView;
    paramView.setSearchableInfo(((SearchManager)paramView.getContext().getSystemService("search")).getSearchableInfo(paramComponentName));
  }
  
  public final void a(View paramView, CharSequence paramCharSequence)
  {
    ((SearchView)paramView).setQueryHint(paramCharSequence);
  }
  
  public final void a(View paramView, CharSequence paramCharSequence, boolean paramBoolean)
  {
    ((SearchView)paramView).setQuery(paramCharSequence, paramBoolean);
  }
  
  public final void a(View paramView, boolean paramBoolean)
  {
    ((SearchView)paramView).setIconified(paramBoolean);
  }
  
  public final void a(Object paramObject1, Object paramObject2)
  {
    ((SearchView)paramObject1).setOnQueryTextListener((SearchView.OnQueryTextListener)paramObject2);
  }
  
  public final boolean a(View paramView)
  {
    return ((SearchView)paramView).isIconified();
  }
  
  public final void b(View paramView, boolean paramBoolean)
  {
    ((SearchView)paramView).setSubmitButtonEnabled(paramBoolean);
  }
  
  public final void b(Object paramObject1, Object paramObject2)
  {
    ((SearchView)paramObject1).setOnCloseListener((SearchView.OnCloseListener)paramObject2);
  }
  
  public final boolean b(View paramView)
  {
    return ((SearchView)paramView).isSubmitButtonEnabled();
  }
  
  public final void c(View paramView, boolean paramBoolean)
  {
    ((SearchView)paramView).setQueryRefinementEnabled(paramBoolean);
  }
  
  public final boolean c(View paramView)
  {
    return ((SearchView)paramView).isQueryRefinementEnabled();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */