import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

final class dn
  implements DialogInterface.OnClickListener
{
  dn(dm paramdm) {}
  
  public final void onClick(DialogInterface paramDialogInterface, int paramInt) {}
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/dn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */