import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.LoaderManager.LoaderCallbacks;
import android.support.v4.content.Loader;
import android.support.v4.content.Loader.OnLoadCompleteListener;
import android.support.v4.util.DebugUtils;
import android.support.v4.util.SparseArrayCompat;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.reflect.Modifier;

final class F
  implements Loader.OnLoadCompleteListener
{
  final int jdField_a_of_type_Int;
  F jdField_a_of_type_F;
  final Bundle jdField_a_of_type_AndroidOsBundle;
  LoaderManager.LoaderCallbacks jdField_a_of_type_AndroidSupportV4AppLoaderManager$LoaderCallbacks;
  Loader jdField_a_of_type_AndroidSupportV4ContentLoader;
  Object jdField_a_of_type_JavaLangObject;
  boolean jdField_a_of_type_Boolean;
  boolean b;
  boolean c;
  boolean d;
  boolean e;
  boolean f;
  boolean g;
  boolean h;
  
  public F(E paramE, int paramInt, Bundle paramBundle, LoaderManager.LoaderCallbacks paramLoaderCallbacks)
  {
    this.jdField_a_of_type_Int = paramInt;
    this.jdField_a_of_type_AndroidOsBundle = paramBundle;
    this.jdField_a_of_type_AndroidSupportV4AppLoaderManager$LoaderCallbacks = paramLoaderCallbacks;
  }
  
  final void a()
  {
    if ((this.d) && (this.e)) {
      this.c = true;
    }
    do
    {
      do
      {
        return;
      } while (this.c);
      this.c = true;
      if (E.jdField_a_of_type_Boolean) {
        new StringBuilder("  Starting: ").append(this).toString();
      }
      if ((this.jdField_a_of_type_AndroidSupportV4ContentLoader == null) && (this.jdField_a_of_type_AndroidSupportV4AppLoaderManager$LoaderCallbacks != null)) {
        this.jdField_a_of_type_AndroidSupportV4ContentLoader = this.jdField_a_of_type_AndroidSupportV4AppLoaderManager$LoaderCallbacks.onCreateLoader(this.jdField_a_of_type_Int, this.jdField_a_of_type_AndroidOsBundle);
      }
    } while (this.jdField_a_of_type_AndroidSupportV4ContentLoader == null);
    if ((this.jdField_a_of_type_AndroidSupportV4ContentLoader.getClass().isMemberClass()) && (!Modifier.isStatic(this.jdField_a_of_type_AndroidSupportV4ContentLoader.getClass().getModifiers()))) {
      throw new IllegalArgumentException("Object returned from onCreateLoader must not be a non-static inner member class: " + this.jdField_a_of_type_AndroidSupportV4ContentLoader);
    }
    if (!this.h)
    {
      this.jdField_a_of_type_AndroidSupportV4ContentLoader.registerListener(this.jdField_a_of_type_Int, this);
      this.h = true;
    }
    this.jdField_a_of_type_AndroidSupportV4ContentLoader.startLoading();
  }
  
  final void a(Loader paramLoader, Object paramObject)
  {
    String str;
    if (this.jdField_a_of_type_AndroidSupportV4AppLoaderManager$LoaderCallbacks != null)
    {
      if (this.jdField_a_of_type_E.jdField_a_of_type_AndroidSupportV4AppFragmentActivity == null) {
        break label150;
      }
      str = this.jdField_a_of_type_E.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.a.a;
      this.jdField_a_of_type_E.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.a.a = "onLoadFinished";
    }
    for (;;)
    {
      try
      {
        if (E.jdField_a_of_type_Boolean) {
          new StringBuilder("  onLoadFinished in ").append(paramLoader).append(": ").append(paramLoader.dataToString(paramObject)).toString();
        }
        this.jdField_a_of_type_AndroidSupportV4AppLoaderManager$LoaderCallbacks.onLoadFinished(paramLoader, paramObject);
        if (this.jdField_a_of_type_E.jdField_a_of_type_AndroidSupportV4AppFragmentActivity != null) {
          this.jdField_a_of_type_E.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.a.a = str;
        }
        this.b = true;
        return;
      }
      finally
      {
        if (this.jdField_a_of_type_E.jdField_a_of_type_AndroidSupportV4AppFragmentActivity != null) {
          this.jdField_a_of_type_E.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.a.a = str;
        }
      }
      label150:
      str = null;
    }
  }
  
  public final void a(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    String str = paramString;
    paramString = this;
    for (;;)
    {
      paramPrintWriter.print(str);
      paramPrintWriter.print("mId=");
      paramPrintWriter.print(paramString.jdField_a_of_type_Int);
      paramPrintWriter.print(" mArgs=");
      paramPrintWriter.println(paramString.jdField_a_of_type_AndroidOsBundle);
      paramPrintWriter.print(str);
      paramPrintWriter.print("mCallbacks=");
      paramPrintWriter.println(paramString.jdField_a_of_type_AndroidSupportV4AppLoaderManager$LoaderCallbacks);
      paramPrintWriter.print(str);
      paramPrintWriter.print("mLoader=");
      paramPrintWriter.println(paramString.jdField_a_of_type_AndroidSupportV4ContentLoader);
      if (paramString.jdField_a_of_type_AndroidSupportV4ContentLoader != null) {
        paramString.jdField_a_of_type_AndroidSupportV4ContentLoader.dump(str + "  ", paramFileDescriptor, paramPrintWriter, paramArrayOfString);
      }
      if ((paramString.jdField_a_of_type_Boolean) || (paramString.b))
      {
        paramPrintWriter.print(str);
        paramPrintWriter.print("mHaveData=");
        paramPrintWriter.print(paramString.jdField_a_of_type_Boolean);
        paramPrintWriter.print("  mDeliveredData=");
        paramPrintWriter.println(paramString.b);
        paramPrintWriter.print(str);
        paramPrintWriter.print("mData=");
        paramPrintWriter.println(paramString.jdField_a_of_type_JavaLangObject);
      }
      paramPrintWriter.print(str);
      paramPrintWriter.print("mStarted=");
      paramPrintWriter.print(paramString.c);
      paramPrintWriter.print(" mReportNextStart=");
      paramPrintWriter.print(paramString.f);
      paramPrintWriter.print(" mDestroyed=");
      paramPrintWriter.println(paramString.g);
      paramPrintWriter.print(str);
      paramPrintWriter.print("mRetaining=");
      paramPrintWriter.print(paramString.d);
      paramPrintWriter.print(" mRetainingStarted=");
      paramPrintWriter.print(paramString.e);
      paramPrintWriter.print(" mListenerRegistered=");
      paramPrintWriter.println(paramString.h);
      if (paramString.jdField_a_of_type_F == null) {
        break;
      }
      paramPrintWriter.print(str);
      paramPrintWriter.println("Pending Loader ");
      paramPrintWriter.print(paramString.jdField_a_of_type_F);
      paramPrintWriter.println(":");
      paramString = paramString.jdField_a_of_type_F;
      str = str + "  ";
    }
  }
  
  final void b()
  {
    if (E.jdField_a_of_type_Boolean) {
      new StringBuilder("  Retaining: ").append(this).toString();
    }
    this.d = true;
    this.e = this.c;
    this.c = false;
    this.jdField_a_of_type_AndroidSupportV4AppLoaderManager$LoaderCallbacks = null;
  }
  
  final void c()
  {
    if (this.d)
    {
      if (E.jdField_a_of_type_Boolean) {
        new StringBuilder("  Finished Retaining: ").append(this).toString();
      }
      this.d = false;
      if ((this.c != this.e) && (!this.c)) {
        e();
      }
    }
    if ((this.c) && (this.jdField_a_of_type_Boolean) && (!this.f)) {
      a(this.jdField_a_of_type_AndroidSupportV4ContentLoader, this.jdField_a_of_type_JavaLangObject);
    }
  }
  
  final void d()
  {
    if ((this.c) && (this.f))
    {
      this.f = false;
      if (this.jdField_a_of_type_Boolean) {
        a(this.jdField_a_of_type_AndroidSupportV4ContentLoader, this.jdField_a_of_type_JavaLangObject);
      }
    }
  }
  
  final void e()
  {
    if (E.jdField_a_of_type_Boolean) {
      new StringBuilder("  Stopping: ").append(this).toString();
    }
    this.c = false;
    if ((!this.d) && (this.jdField_a_of_type_AndroidSupportV4ContentLoader != null) && (this.h))
    {
      this.h = false;
      this.jdField_a_of_type_AndroidSupportV4ContentLoader.unregisterListener(this);
      this.jdField_a_of_type_AndroidSupportV4ContentLoader.stopLoading();
    }
  }
  
  /* Error */
  final void f()
  {
    // Byte code:
    //   0: aload_0
    //   1: astore_2
    //   2: getstatic 46	E:jdField_a_of_type_Boolean	Z
    //   5: ifeq +20 -> 25
    //   8: new 48	java/lang/StringBuilder
    //   11: dup
    //   12: ldc -34
    //   14: invokespecial 53	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   17: aload_2
    //   18: invokevirtual 57	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   21: invokevirtual 61	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   24: pop
    //   25: aload_2
    //   26: iconst_1
    //   27: putfield 187	F:g	Z
    //   30: aload_2
    //   31: getfield 136	F:b	Z
    //   34: istore_1
    //   35: aload_2
    //   36: iconst_0
    //   37: putfield 136	F:b	Z
    //   40: aload_2
    //   41: getfield 35	F:jdField_a_of_type_AndroidSupportV4AppLoaderManager$LoaderCallbacks	Landroid/support/v4/app/LoaderManager$LoaderCallbacks;
    //   44: ifnull +120 -> 164
    //   47: aload_2
    //   48: getfield 63	F:jdField_a_of_type_AndroidSupportV4ContentLoader	Landroid/support/v4/content/Loader;
    //   51: ifnull +113 -> 164
    //   54: aload_2
    //   55: getfield 164	F:jdField_a_of_type_Boolean	Z
    //   58: ifeq +106 -> 164
    //   61: iload_1
    //   62: ifeq +102 -> 164
    //   65: getstatic 46	E:jdField_a_of_type_Boolean	Z
    //   68: ifeq +20 -> 88
    //   71: new 48	java/lang/StringBuilder
    //   74: dup
    //   75: ldc -32
    //   77: invokespecial 53	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   80: aload_2
    //   81: invokevirtual 57	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   84: invokevirtual 61	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   87: pop
    //   88: aload_2
    //   89: getfield 26	F:jdField_a_of_type_E	LE;
    //   92: getfield 109	E:jdField_a_of_type_AndroidSupportV4AppFragmentActivity	Landroid/support/v4/app/FragmentActivity;
    //   95: ifnull +163 -> 258
    //   98: aload_2
    //   99: getfield 26	F:jdField_a_of_type_E	LE;
    //   102: getfield 109	E:jdField_a_of_type_AndroidSupportV4AppFragmentActivity	Landroid/support/v4/app/FragmentActivity;
    //   105: getfield 114	android/support/v4/app/FragmentActivity:a	Lo;
    //   108: getfield 119	o:a	Ljava/lang/String;
    //   111: astore_3
    //   112: aload_2
    //   113: getfield 26	F:jdField_a_of_type_E	LE;
    //   116: getfield 109	E:jdField_a_of_type_AndroidSupportV4AppFragmentActivity	Landroid/support/v4/app/FragmentActivity;
    //   119: getfield 114	android/support/v4/app/FragmentActivity:a	Lo;
    //   122: ldc -30
    //   124: putfield 119	o:a	Ljava/lang/String;
    //   127: aload_2
    //   128: getfield 35	F:jdField_a_of_type_AndroidSupportV4AppLoaderManager$LoaderCallbacks	Landroid/support/v4/app/LoaderManager$LoaderCallbacks;
    //   131: aload_2
    //   132: getfield 63	F:jdField_a_of_type_AndroidSupportV4ContentLoader	Landroid/support/v4/content/Loader;
    //   135: invokeinterface 229 2 0
    //   140: aload_2
    //   141: getfield 26	F:jdField_a_of_type_E	LE;
    //   144: getfield 109	E:jdField_a_of_type_AndroidSupportV4AppFragmentActivity	Landroid/support/v4/app/FragmentActivity;
    //   147: ifnull +17 -> 164
    //   150: aload_2
    //   151: getfield 26	F:jdField_a_of_type_E	LE;
    //   154: getfield 109	E:jdField_a_of_type_AndroidSupportV4AppFragmentActivity	Landroid/support/v4/app/FragmentActivity;
    //   157: getfield 114	android/support/v4/app/FragmentActivity:a	Lo;
    //   160: aload_3
    //   161: putfield 119	o:a	Ljava/lang/String;
    //   164: aload_2
    //   165: aconst_null
    //   166: putfield 35	F:jdField_a_of_type_AndroidSupportV4AppLoaderManager$LoaderCallbacks	Landroid/support/v4/app/LoaderManager$LoaderCallbacks;
    //   169: aload_2
    //   170: aconst_null
    //   171: putfield 177	F:jdField_a_of_type_JavaLangObject	Ljava/lang/Object;
    //   174: aload_2
    //   175: iconst_0
    //   176: putfield 164	F:jdField_a_of_type_Boolean	Z
    //   179: aload_2
    //   180: getfield 63	F:jdField_a_of_type_AndroidSupportV4ContentLoader	Landroid/support/v4/content/Loader;
    //   183: ifnull +30 -> 213
    //   186: aload_2
    //   187: getfield 96	F:h	Z
    //   190: ifeq +16 -> 206
    //   193: aload_2
    //   194: iconst_0
    //   195: putfield 96	F:h	Z
    //   198: aload_2
    //   199: getfield 63	F:jdField_a_of_type_AndroidSupportV4ContentLoader	Landroid/support/v4/content/Loader;
    //   202: aload_2
    //   203: invokevirtual 217	android/support/v4/content/Loader:unregisterListener	(Landroid/support/v4/content/Loader$OnLoadCompleteListener;)V
    //   206: aload_2
    //   207: getfield 63	F:jdField_a_of_type_AndroidSupportV4ContentLoader	Landroid/support/v4/content/Loader;
    //   210: invokevirtual 232	android/support/v4/content/Loader:reset	()V
    //   213: aload_2
    //   214: getfield 195	F:jdField_a_of_type_F	LF;
    //   217: ifnull +40 -> 257
    //   220: aload_2
    //   221: getfield 195	F:jdField_a_of_type_F	LF;
    //   224: astore_2
    //   225: goto -223 -> 2
    //   228: astore 4
    //   230: aload_2
    //   231: getfield 26	F:jdField_a_of_type_E	LE;
    //   234: getfield 109	E:jdField_a_of_type_AndroidSupportV4AppFragmentActivity	Landroid/support/v4/app/FragmentActivity;
    //   237: ifnull +17 -> 254
    //   240: aload_2
    //   241: getfield 26	F:jdField_a_of_type_E	LE;
    //   244: getfield 109	E:jdField_a_of_type_AndroidSupportV4AppFragmentActivity	Landroid/support/v4/app/FragmentActivity;
    //   247: getfield 114	android/support/v4/app/FragmentActivity:a	Lo;
    //   250: aload_3
    //   251: putfield 119	o:a	Ljava/lang/String;
    //   254: aload 4
    //   256: athrow
    //   257: return
    //   258: aconst_null
    //   259: astore_3
    //   260: goto -133 -> 127
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	263	0	this	F
    //   34	28	1	bool	boolean
    //   1	240	2	localF	F
    //   111	149	3	str	String
    //   228	27	4	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   127	140	228	finally
  }
  
  public final void onLoadComplete(Loader paramLoader, Object paramObject)
  {
    if (E.jdField_a_of_type_Boolean) {
      new StringBuilder("onLoadComplete: ").append(this).toString();
    }
    boolean bool;
    if (this.g) {
      bool = E.jdField_a_of_type_Boolean;
    }
    do
    {
      return;
      if (this.jdField_a_of_type_E.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.get(this.jdField_a_of_type_Int) != this)
      {
        bool = E.jdField_a_of_type_Boolean;
        return;
      }
      F localF = this.jdField_a_of_type_F;
      if (localF != null)
      {
        if (E.jdField_a_of_type_Boolean) {
          new StringBuilder("  Switching to pending loader: ").append(localF).toString();
        }
        this.jdField_a_of_type_F = null;
        this.jdField_a_of_type_E.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.put(this.jdField_a_of_type_Int, null);
        f();
        this.jdField_a_of_type_E.a(localF);
        return;
      }
      if ((this.jdField_a_of_type_JavaLangObject != paramObject) || (!this.jdField_a_of_type_Boolean))
      {
        this.jdField_a_of_type_JavaLangObject = paramObject;
        this.jdField_a_of_type_Boolean = true;
        if (this.c) {
          a(paramLoader, paramObject);
        }
      }
      paramLoader = (F)this.jdField_a_of_type_E.b.get(this.jdField_a_of_type_Int);
      if ((paramLoader != null) && (paramLoader != this))
      {
        paramLoader.b = false;
        paramLoader.f();
        this.jdField_a_of_type_E.b.remove(this.jdField_a_of_type_Int);
      }
    } while ((this.jdField_a_of_type_E.jdField_a_of_type_AndroidSupportV4AppFragmentActivity == null) || (this.jdField_a_of_type_E.hasRunningLoaders()));
    this.jdField_a_of_type_E.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.a.a();
  }
  
  public final String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(64);
    localStringBuilder.append("LoaderInfo{");
    localStringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    localStringBuilder.append(" #");
    localStringBuilder.append(this.jdField_a_of_type_Int);
    localStringBuilder.append(" : ");
    DebugUtils.buildShortClassTag(this.jdField_a_of_type_AndroidSupportV4ContentLoader, localStringBuilder);
    localStringBuilder.append("}}");
    return localStringBuilder.toString();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/F.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */