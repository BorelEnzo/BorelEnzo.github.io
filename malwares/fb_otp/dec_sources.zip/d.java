import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager.BackStackEntry;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.util.LogWriter;
import java.io.PrintWriter;
import java.util.ArrayList;

final class d
  extends FragmentTransaction
  implements FragmentManager.BackStackEntry, Runnable
{
  int jdField_a_of_type_Int;
  e jdField_a_of_type_E;
  CharSequence jdField_a_of_type_JavaLangCharSequence;
  String jdField_a_of_type_JavaLangString;
  final o jdField_a_of_type_O;
  boolean jdField_a_of_type_Boolean;
  int jdField_b_of_type_Int;
  e jdField_b_of_type_E;
  CharSequence jdField_b_of_type_JavaLangCharSequence;
  boolean jdField_b_of_type_Boolean = true;
  int jdField_c_of_type_Int;
  boolean jdField_c_of_type_Boolean;
  int d;
  int e;
  int f;
  int g;
  int h = -1;
  int i;
  int j;
  
  public d(o paramo)
  {
    this.jdField_a_of_type_O = paramo;
  }
  
  private int a(boolean paramBoolean)
  {
    if (this.jdField_c_of_type_Boolean) {
      throw new IllegalStateException("commit already called");
    }
    if (o.jdField_a_of_type_Boolean)
    {
      new StringBuilder("Commit: ").append(this).toString();
      a("  ", new PrintWriter(new LogWriter("FragmentManager")));
    }
    this.jdField_c_of_type_Boolean = true;
    if (this.jdField_a_of_type_Boolean) {}
    for (this.h = this.jdField_a_of_type_O.a(this);; this.h = -1)
    {
      this.jdField_a_of_type_O.a(this, paramBoolean);
      return this.h;
    }
  }
  
  private void a(int paramInt1, Fragment paramFragment, String paramString, int paramInt2)
  {
    paramFragment.jdField_a_of_type_O = this.jdField_a_of_type_O;
    if (paramString != null)
    {
      if ((paramFragment.b != null) && (!paramString.equals(paramFragment.b))) {
        throw new IllegalStateException("Can't change tag of fragment " + paramFragment + ": was " + paramFragment.b + " now " + paramString);
      }
      paramFragment.b = paramString;
    }
    if (paramInt1 != 0)
    {
      if ((paramFragment.j != 0) && (paramFragment.j != paramInt1)) {
        throw new IllegalStateException("Can't change container ID of fragment " + paramFragment + ": was " + paramFragment.j + " now " + paramInt1);
      }
      paramFragment.j = paramInt1;
      paramFragment.k = paramInt1;
    }
    paramString = new e();
    paramString.jdField_a_of_type_Int = paramInt2;
    paramString.jdField_a_of_type_AndroidSupportV4AppFragment = paramFragment;
    a(paramString);
  }
  
  final void a(int paramInt)
  {
    if (!this.jdField_a_of_type_Boolean) {}
    for (;;)
    {
      return;
      if (o.jdField_a_of_type_Boolean) {
        new StringBuilder("Bump nesting in ").append(this).append(" by ").append(paramInt).toString();
      }
      for (e locale = this.jdField_a_of_type_E; locale != null; locale = locale.jdField_a_of_type_E)
      {
        Fragment localFragment;
        if (locale.jdField_a_of_type_AndroidSupportV4AppFragment != null)
        {
          localFragment = locale.jdField_a_of_type_AndroidSupportV4AppFragment;
          localFragment.i += paramInt;
          if (o.jdField_a_of_type_Boolean) {
            new StringBuilder("Bump nesting of ").append(locale.jdField_a_of_type_AndroidSupportV4AppFragment).append(" to ").append(locale.jdField_a_of_type_AndroidSupportV4AppFragment.i).toString();
          }
        }
        if (locale.jdField_a_of_type_JavaUtilArrayList != null)
        {
          int k = locale.jdField_a_of_type_JavaUtilArrayList.size() - 1;
          while (k >= 0)
          {
            localFragment = (Fragment)locale.jdField_a_of_type_JavaUtilArrayList.get(k);
            localFragment.i += paramInt;
            if (o.jdField_a_of_type_Boolean) {
              new StringBuilder("Bump nesting of ").append(localFragment).append(" to ").append(localFragment.i).toString();
            }
            k -= 1;
          }
        }
      }
    }
  }
  
  final void a(e parame)
  {
    if (this.jdField_a_of_type_E == null)
    {
      this.jdField_b_of_type_E = parame;
      this.jdField_a_of_type_E = parame;
    }
    for (;;)
    {
      parame.jdField_b_of_type_Int = this.jdField_b_of_type_Int;
      parame.jdField_c_of_type_Int = this.jdField_c_of_type_Int;
      parame.d = this.d;
      parame.e = this.e;
      this.jdField_a_of_type_Int += 1;
      return;
      parame.jdField_b_of_type_E = this.jdField_b_of_type_E;
      this.jdField_b_of_type_E.jdField_a_of_type_E = parame;
      this.jdField_b_of_type_E = parame;
    }
  }
  
  public final void a(String paramString, PrintWriter paramPrintWriter)
  {
    a(paramString, paramPrintWriter, true);
  }
  
  public final void a(String paramString, PrintWriter paramPrintWriter, boolean paramBoolean)
  {
    if (paramBoolean)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mName=");
      paramPrintWriter.print(this.jdField_a_of_type_JavaLangString);
      paramPrintWriter.print(" mIndex=");
      paramPrintWriter.print(this.h);
      paramPrintWriter.print(" mCommitted=");
      paramPrintWriter.println(this.jdField_c_of_type_Boolean);
      if (this.f != 0)
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mTransition=#");
        paramPrintWriter.print(Integer.toHexString(this.f));
        paramPrintWriter.print(" mTransitionStyle=#");
        paramPrintWriter.println(Integer.toHexString(this.g));
      }
      if ((this.jdField_b_of_type_Int != 0) || (this.jdField_c_of_type_Int != 0))
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.jdField_b_of_type_Int));
        paramPrintWriter.print(" mExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.jdField_c_of_type_Int));
      }
      if ((this.d != 0) || (this.e != 0))
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mPopEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.d));
        paramPrintWriter.print(" mPopExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.e));
      }
      if ((this.i != 0) || (this.jdField_a_of_type_JavaLangCharSequence != null))
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.i));
        paramPrintWriter.print(" mBreadCrumbTitleText=");
        paramPrintWriter.println(this.jdField_a_of_type_JavaLangCharSequence);
      }
      if ((this.j != 0) || (this.jdField_b_of_type_JavaLangCharSequence != null))
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbShortTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.j));
        paramPrintWriter.print(" mBreadCrumbShortTitleText=");
        paramPrintWriter.println(this.jdField_b_of_type_JavaLangCharSequence);
      }
    }
    if (this.jdField_a_of_type_E != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Operations:");
      String str2 = paramString + "    ";
      e locale = this.jdField_a_of_type_E;
      int k = 0;
      while (locale != null)
      {
        String str1;
        int m;
        switch (locale.jdField_a_of_type_Int)
        {
        default: 
          str1 = "cmd=" + locale.jdField_a_of_type_Int;
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  Op #");
          paramPrintWriter.print(k);
          paramPrintWriter.print(": ");
          paramPrintWriter.print(str1);
          paramPrintWriter.print(" ");
          paramPrintWriter.println(locale.jdField_a_of_type_AndroidSupportV4AppFragment);
          if (paramBoolean)
          {
            if ((locale.jdField_b_of_type_Int != 0) || (locale.jdField_c_of_type_Int != 0))
            {
              paramPrintWriter.print(paramString);
              paramPrintWriter.print("enterAnim=#");
              paramPrintWriter.print(Integer.toHexString(locale.jdField_b_of_type_Int));
              paramPrintWriter.print(" exitAnim=#");
              paramPrintWriter.println(Integer.toHexString(locale.jdField_c_of_type_Int));
            }
            if ((locale.d != 0) || (locale.e != 0))
            {
              paramPrintWriter.print(paramString);
              paramPrintWriter.print("popEnterAnim=#");
              paramPrintWriter.print(Integer.toHexString(locale.d));
              paramPrintWriter.print(" popExitAnim=#");
              paramPrintWriter.println(Integer.toHexString(locale.e));
            }
          }
          if ((locale.jdField_a_of_type_JavaUtilArrayList == null) || (locale.jdField_a_of_type_JavaUtilArrayList.size() <= 0)) {
            break label777;
          }
          m = 0;
          label614:
          if (m >= locale.jdField_a_of_type_JavaUtilArrayList.size()) {
            break label777;
          }
          paramPrintWriter.print(str2);
          if (locale.jdField_a_of_type_JavaUtilArrayList.size() == 1) {
            paramPrintWriter.print("Removed: ");
          }
          break;
        }
        for (;;)
        {
          paramPrintWriter.println(locale.jdField_a_of_type_JavaUtilArrayList.get(m));
          m += 1;
          break label614;
          str1 = "NULL";
          break;
          str1 = "ADD";
          break;
          str1 = "REPLACE";
          break;
          str1 = "REMOVE";
          break;
          str1 = "HIDE";
          break;
          str1 = "SHOW";
          break;
          str1 = "DETACH";
          break;
          str1 = "ATTACH";
          break;
          if (m == 0) {
            paramPrintWriter.println("Removed:");
          }
          paramPrintWriter.print(str2);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(m);
          paramPrintWriter.print(": ");
        }
        label777:
        locale = locale.jdField_a_of_type_E;
        k += 1;
      }
    }
  }
  
  public final void a(boolean paramBoolean)
  {
    if (o.jdField_a_of_type_Boolean)
    {
      new StringBuilder("popFromBackStack: ").append(this).toString();
      a("  ", new PrintWriter(new LogWriter("FragmentManager")));
    }
    a(-1);
    e locale = this.jdField_b_of_type_E;
    if (locale != null)
    {
      Fragment localFragment;
      switch (locale.jdField_a_of_type_Int)
      {
      default: 
        throw new IllegalArgumentException("Unknown cmd: " + locale.jdField_a_of_type_Int);
      case 1: 
        localFragment = locale.jdField_a_of_type_AndroidSupportV4AppFragment;
        localFragment.l = locale.e;
        this.jdField_a_of_type_O.a(localFragment, o.a(this.f), this.g);
      }
      for (;;)
      {
        locale = locale.jdField_b_of_type_E;
        break;
        localFragment = locale.jdField_a_of_type_AndroidSupportV4AppFragment;
        if (localFragment != null)
        {
          localFragment.l = locale.e;
          this.jdField_a_of_type_O.a(localFragment, o.a(this.f), this.g);
        }
        if (locale.jdField_a_of_type_JavaUtilArrayList != null)
        {
          int k = 0;
          while (k < locale.jdField_a_of_type_JavaUtilArrayList.size())
          {
            localFragment = (Fragment)locale.jdField_a_of_type_JavaUtilArrayList.get(k);
            localFragment.l = locale.d;
            this.jdField_a_of_type_O.a(localFragment, false);
            k += 1;
          }
          localFragment = locale.jdField_a_of_type_AndroidSupportV4AppFragment;
          localFragment.l = locale.d;
          this.jdField_a_of_type_O.a(localFragment, false);
          continue;
          localFragment = locale.jdField_a_of_type_AndroidSupportV4AppFragment;
          localFragment.l = locale.d;
          this.jdField_a_of_type_O.c(localFragment, o.a(this.f), this.g);
          continue;
          localFragment = locale.jdField_a_of_type_AndroidSupportV4AppFragment;
          localFragment.l = locale.e;
          this.jdField_a_of_type_O.b(localFragment, o.a(this.f), this.g);
          continue;
          localFragment = locale.jdField_a_of_type_AndroidSupportV4AppFragment;
          localFragment.l = locale.d;
          this.jdField_a_of_type_O.e(localFragment, o.a(this.f), this.g);
          continue;
          localFragment = locale.jdField_a_of_type_AndroidSupportV4AppFragment;
          localFragment.l = locale.d;
          this.jdField_a_of_type_O.d(localFragment, o.a(this.f), this.g);
        }
      }
    }
    if (paramBoolean) {
      this.jdField_a_of_type_O.a(this.jdField_a_of_type_O.jdField_a_of_type_Int, o.a(this.f), this.g, true);
    }
    if (this.h >= 0)
    {
      this.jdField_a_of_type_O.a(this.h);
      this.h = -1;
    }
  }
  
  public final FragmentTransaction add(int paramInt, Fragment paramFragment)
  {
    a(paramInt, paramFragment, null, 1);
    return this;
  }
  
  public final FragmentTransaction add(int paramInt, Fragment paramFragment, String paramString)
  {
    a(paramInt, paramFragment, paramString, 1);
    return this;
  }
  
  public final FragmentTransaction add(Fragment paramFragment, String paramString)
  {
    a(0, paramFragment, paramString, 1);
    return this;
  }
  
  public final FragmentTransaction addToBackStack(String paramString)
  {
    if (!this.jdField_b_of_type_Boolean) {
      throw new IllegalStateException("This FragmentTransaction is not allowed to be added to the back stack.");
    }
    this.jdField_a_of_type_Boolean = true;
    this.jdField_a_of_type_JavaLangString = paramString;
    return this;
  }
  
  public final FragmentTransaction attach(Fragment paramFragment)
  {
    e locale = new e();
    locale.jdField_a_of_type_Int = 7;
    locale.jdField_a_of_type_AndroidSupportV4AppFragment = paramFragment;
    a(locale);
    return this;
  }
  
  public final int commit()
  {
    return a(false);
  }
  
  public final int commitAllowingStateLoss()
  {
    return a(true);
  }
  
  public final FragmentTransaction detach(Fragment paramFragment)
  {
    e locale = new e();
    locale.jdField_a_of_type_Int = 6;
    locale.jdField_a_of_type_AndroidSupportV4AppFragment = paramFragment;
    a(locale);
    return this;
  }
  
  public final FragmentTransaction disallowAddToBackStack()
  {
    if (this.jdField_a_of_type_Boolean) {
      throw new IllegalStateException("This transaction is already being added to the back stack");
    }
    this.jdField_b_of_type_Boolean = false;
    return this;
  }
  
  public final CharSequence getBreadCrumbShortTitle()
  {
    if (this.j != 0) {
      return this.jdField_a_of_type_O.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.getText(this.j);
    }
    return this.jdField_b_of_type_JavaLangCharSequence;
  }
  
  public final int getBreadCrumbShortTitleRes()
  {
    return this.j;
  }
  
  public final CharSequence getBreadCrumbTitle()
  {
    if (this.i != 0) {
      return this.jdField_a_of_type_O.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.getText(this.i);
    }
    return this.jdField_a_of_type_JavaLangCharSequence;
  }
  
  public final int getBreadCrumbTitleRes()
  {
    return this.i;
  }
  
  public final int getId()
  {
    return this.h;
  }
  
  public final String getName()
  {
    return this.jdField_a_of_type_JavaLangString;
  }
  
  public final FragmentTransaction hide(Fragment paramFragment)
  {
    e locale = new e();
    locale.jdField_a_of_type_Int = 4;
    locale.jdField_a_of_type_AndroidSupportV4AppFragment = paramFragment;
    a(locale);
    return this;
  }
  
  public final boolean isAddToBackStackAllowed()
  {
    return this.jdField_b_of_type_Boolean;
  }
  
  public final boolean isEmpty()
  {
    return this.jdField_a_of_type_Int == 0;
  }
  
  public final FragmentTransaction remove(Fragment paramFragment)
  {
    e locale = new e();
    locale.jdField_a_of_type_Int = 3;
    locale.jdField_a_of_type_AndroidSupportV4AppFragment = paramFragment;
    a(locale);
    return this;
  }
  
  public final FragmentTransaction replace(int paramInt, Fragment paramFragment)
  {
    return replace(paramInt, paramFragment, null);
  }
  
  public final FragmentTransaction replace(int paramInt, Fragment paramFragment, String paramString)
  {
    if (paramInt == 0) {
      throw new IllegalArgumentException("Must use non-zero containerViewId");
    }
    a(paramInt, paramFragment, paramString, 2);
    return this;
  }
  
  public final void run()
  {
    if (o.jdField_a_of_type_Boolean) {
      new StringBuilder("Run: ").append(this).toString();
    }
    if ((this.jdField_a_of_type_Boolean) && (this.h < 0)) {
      throw new IllegalStateException("addToBackStack() called after commit()");
    }
    a(1);
    e locale = this.jdField_a_of_type_E;
    if (locale != null)
    {
      Object localObject1;
      switch (locale.jdField_a_of_type_Int)
      {
      default: 
        throw new IllegalArgumentException("Unknown cmd: " + locale.jdField_a_of_type_Int);
      case 1: 
        localObject1 = locale.jdField_a_of_type_AndroidSupportV4AppFragment;
        ((Fragment)localObject1).l = locale.jdField_b_of_type_Int;
        this.jdField_a_of_type_O.a((Fragment)localObject1, false);
      }
      for (;;)
      {
        locale = locale.jdField_a_of_type_E;
        break;
        localObject1 = locale.jdField_a_of_type_AndroidSupportV4AppFragment;
        Object localObject2;
        if (this.jdField_a_of_type_O.c != null)
        {
          int k = 0;
          localObject2 = localObject1;
          if (k < this.jdField_a_of_type_O.c.size())
          {
            Fragment localFragment = (Fragment)this.jdField_a_of_type_O.c.get(k);
            if (o.jdField_a_of_type_Boolean) {
              new StringBuilder("OP_REPLACE: adding=").append(localObject1).append(" old=").append(localFragment).toString();
            }
            if (localObject1 != null)
            {
              localObject2 = localObject1;
              if (localFragment.k != ((Fragment)localObject1).k) {}
            }
            else
            {
              if (localFragment != localObject1) {
                break label294;
              }
              localObject2 = null;
              locale.jdField_a_of_type_AndroidSupportV4AppFragment = null;
            }
            for (;;)
            {
              k += 1;
              localObject1 = localObject2;
              break;
              label294:
              if (locale.jdField_a_of_type_JavaUtilArrayList == null) {
                locale.jdField_a_of_type_JavaUtilArrayList = new ArrayList();
              }
              locale.jdField_a_of_type_JavaUtilArrayList.add(localFragment);
              localFragment.l = locale.jdField_c_of_type_Int;
              if (this.jdField_a_of_type_Boolean)
              {
                localFragment.i += 1;
                if (o.jdField_a_of_type_Boolean) {
                  new StringBuilder("Bump nesting of ").append(localFragment).append(" to ").append(localFragment.i).toString();
                }
              }
              this.jdField_a_of_type_O.a(localFragment, this.f, this.g);
              localObject2 = localObject1;
            }
          }
        }
        else
        {
          localObject2 = localObject1;
        }
        if (localObject2 != null)
        {
          ((Fragment)localObject2).l = locale.jdField_b_of_type_Int;
          this.jdField_a_of_type_O.a((Fragment)localObject2, false);
          continue;
          localObject1 = locale.jdField_a_of_type_AndroidSupportV4AppFragment;
          ((Fragment)localObject1).l = locale.jdField_c_of_type_Int;
          this.jdField_a_of_type_O.a((Fragment)localObject1, this.f, this.g);
          continue;
          localObject1 = locale.jdField_a_of_type_AndroidSupportV4AppFragment;
          ((Fragment)localObject1).l = locale.jdField_c_of_type_Int;
          this.jdField_a_of_type_O.b((Fragment)localObject1, this.f, this.g);
          continue;
          localObject1 = locale.jdField_a_of_type_AndroidSupportV4AppFragment;
          ((Fragment)localObject1).l = locale.jdField_b_of_type_Int;
          this.jdField_a_of_type_O.c((Fragment)localObject1, this.f, this.g);
          continue;
          localObject1 = locale.jdField_a_of_type_AndroidSupportV4AppFragment;
          ((Fragment)localObject1).l = locale.jdField_c_of_type_Int;
          this.jdField_a_of_type_O.d((Fragment)localObject1, this.f, this.g);
          continue;
          localObject1 = locale.jdField_a_of_type_AndroidSupportV4AppFragment;
          ((Fragment)localObject1).l = locale.jdField_b_of_type_Int;
          this.jdField_a_of_type_O.e((Fragment)localObject1, this.f, this.g);
        }
      }
    }
    this.jdField_a_of_type_O.a(this.jdField_a_of_type_O.jdField_a_of_type_Int, this.f, this.g, true);
    if (this.jdField_a_of_type_Boolean) {
      this.jdField_a_of_type_O.a(this);
    }
  }
  
  public final FragmentTransaction setBreadCrumbShortTitle(int paramInt)
  {
    this.j = paramInt;
    this.jdField_b_of_type_JavaLangCharSequence = null;
    return this;
  }
  
  public final FragmentTransaction setBreadCrumbShortTitle(CharSequence paramCharSequence)
  {
    this.j = 0;
    this.jdField_b_of_type_JavaLangCharSequence = paramCharSequence;
    return this;
  }
  
  public final FragmentTransaction setBreadCrumbTitle(int paramInt)
  {
    this.i = paramInt;
    this.jdField_a_of_type_JavaLangCharSequence = null;
    return this;
  }
  
  public final FragmentTransaction setBreadCrumbTitle(CharSequence paramCharSequence)
  {
    this.i = 0;
    this.jdField_a_of_type_JavaLangCharSequence = paramCharSequence;
    return this;
  }
  
  public final FragmentTransaction setCustomAnimations(int paramInt1, int paramInt2)
  {
    return setCustomAnimations(paramInt1, paramInt2, 0, 0);
  }
  
  public final FragmentTransaction setCustomAnimations(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.jdField_b_of_type_Int = paramInt1;
    this.jdField_c_of_type_Int = paramInt2;
    this.d = paramInt3;
    this.e = paramInt4;
    return this;
  }
  
  public final FragmentTransaction setTransition(int paramInt)
  {
    this.f = paramInt;
    return this;
  }
  
  public final FragmentTransaction setTransitionStyle(int paramInt)
  {
    this.g = paramInt;
    return this;
  }
  
  public final FragmentTransaction show(Fragment paramFragment)
  {
    e locale = new e();
    locale.jdField_a_of_type_Int = 5;
    locale.jdField_a_of_type_AndroidSupportV4AppFragment = paramFragment;
    a(locale);
    return this;
  }
  
  public final String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(128);
    localStringBuilder.append("BackStackEntry{");
    localStringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    if (this.h >= 0)
    {
      localStringBuilder.append(" #");
      localStringBuilder.append(this.h);
    }
    if (this.jdField_a_of_type_JavaLangString != null)
    {
      localStringBuilder.append(" ");
      localStringBuilder.append(this.jdField_a_of_type_JavaLangString);
    }
    localStringBuilder.append("}");
    return localStringBuilder.toString();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/d.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */