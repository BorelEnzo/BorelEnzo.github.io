import android.os.AsyncTask;
import android.view.View;
import android.view.animation.ScaleAnimation;
import com.soft360.iService.MainActivity;
import java.util.concurrent.TimeUnit;

public final class dw
  extends AsyncTask
{
  private dw(MainActivity paramMainActivity) {}
  
  private static Void a()
  {
    try
    {
      TimeUnit.SECONDS.sleep(5L);
      return null;
    }
    catch (InterruptedException localInterruptedException)
    {
      for (;;)
      {
        localInterruptedException.printStackTrace();
      }
    }
  }
  
  protected final void onPreExecute()
  {
    this.a.findViewById(2131427347).setVisibility(8);
    this.a.findViewById(2131427438).setVisibility(0);
    this.a.findViewById(2131427353).setVisibility(8);
    this.a.findViewById(2131427350).setVisibility(0);
    ScaleAnimation localScaleAnimation = new ScaleAnimation(0.0F, 1.0F, 0.0F, 1.0F, 1, 0.5F, 1, 0.5F);
    localScaleAnimation.setDuration(1000L);
    this.a.findViewById(2131427438).setAnimation(localScaleAnimation);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/dw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */