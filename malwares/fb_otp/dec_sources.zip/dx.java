import android.os.AsyncTask;
import android.view.View;
import com.soft360.iService.MainActivity;
import java.util.concurrent.TimeUnit;

public final class dx
  extends AsyncTask
{
  private dx(MainActivity paramMainActivity) {}
  
  private static Void a()
  {
    try
    {
      TimeUnit.SECONDS.sleep(5L);
      return null;
    }
    catch (InterruptedException localInterruptedException)
    {
      for (;;)
      {
        localInterruptedException.printStackTrace();
      }
    }
  }
  
  protected final void onPreExecute()
  {
    this.a.findViewById(2131427361).setVisibility(8);
    this.a.findViewById(2131427351).setVisibility(0);
    this.a.findViewById(2131427403).setVisibility(4);
    this.a.findViewById(2131427439).setEnabled(false);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/dx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */