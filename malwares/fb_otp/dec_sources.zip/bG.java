import android.view.accessibility.AccessibilityEvent;

public class bG
  implements bH
{
  public int a(AccessibilityEvent paramAccessibilityEvent)
  {
    return 0;
  }
  
  public Object a(AccessibilityEvent paramAccessibilityEvent, int paramInt)
  {
    return null;
  }
  
  public void a(AccessibilityEvent paramAccessibilityEvent, Object paramObject) {}
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bG.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */