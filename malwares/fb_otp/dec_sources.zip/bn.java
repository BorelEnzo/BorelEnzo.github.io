import android.support.v4.view.ViewCompatJellybeanMr1;
import android.view.View;

public final class bn
  extends bm
{
  public final void c(View paramView, int paramInt)
  {
    ViewCompatJellybeanMr1.setLabelFor(paramView, paramInt);
  }
  
  public final int d(View paramView)
  {
    return ViewCompatJellybeanMr1.getLabelFor(paramView);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */