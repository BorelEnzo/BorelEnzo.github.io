import android.os.Parcelable;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.view.View;
import java.util.List;

public abstract interface cc
{
  public abstract int a(Object paramObject);
  
  public abstract Parcelable a(Object paramObject);
  
  public abstract AccessibilityNodeInfoCompat a(Object paramObject);
  
  public abstract CharSequence a(Object paramObject);
  
  public abstract Object a();
  
  public abstract Object a(Object paramObject);
  
  public abstract List a(Object paramObject);
  
  public abstract void a(Object paramObject);
  
  public abstract void a(Object paramObject, int paramInt);
  
  public abstract void a(Object paramObject, Parcelable paramParcelable);
  
  public abstract void a(Object paramObject, View paramView);
  
  public abstract void a(Object paramObject, View paramView, int paramInt);
  
  public abstract void a(Object paramObject, CharSequence paramCharSequence);
  
  public abstract void a(Object paramObject, boolean paramBoolean);
  
  public abstract boolean a(Object paramObject);
  
  public abstract int b(Object paramObject);
  
  public abstract CharSequence b(Object paramObject);
  
  public abstract void b(Object paramObject, int paramInt);
  
  public abstract void b(Object paramObject, CharSequence paramCharSequence);
  
  public abstract void b(Object paramObject, boolean paramBoolean);
  
  public abstract boolean b(Object paramObject);
  
  public abstract int c(Object paramObject);
  
  public abstract CharSequence c(Object paramObject);
  
  public abstract void c(Object paramObject, int paramInt);
  
  public abstract void c(Object paramObject, CharSequence paramCharSequence);
  
  public abstract void c(Object paramObject, boolean paramBoolean);
  
  public abstract boolean c(Object paramObject);
  
  public abstract int d(Object paramObject);
  
  public abstract void d(Object paramObject, int paramInt);
  
  public abstract void d(Object paramObject, boolean paramBoolean);
  
  public abstract boolean d(Object paramObject);
  
  public abstract int e(Object paramObject);
  
  public abstract void e(Object paramObject, int paramInt);
  
  public abstract void e(Object paramObject, boolean paramBoolean);
  
  public abstract boolean e(Object paramObject);
  
  public abstract int f(Object paramObject);
  
  public abstract void f(Object paramObject, int paramInt);
  
  public abstract int g(Object paramObject);
  
  public abstract void g(Object paramObject, int paramInt);
  
  public abstract int h(Object paramObject);
  
  public abstract void h(Object paramObject, int paramInt);
  
  public abstract int i(Object paramObject);
  
  public abstract void i(Object paramObject, int paramInt);
  
  public abstract int j(Object paramObject);
  
  public abstract void j(Object paramObject, int paramInt);
  
  public abstract int k(Object paramObject);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */