import android.os.AsyncTask;
import android.view.View;
import com.soft360.iService.MainActivity;
import java.util.concurrent.TimeUnit;

public final class cZ
  extends AsyncTask
{
  private cZ(MainActivity paramMainActivity) {}
  
  private Void a()
  {
    int i = 0;
    if (i >= 5) {}
    for (;;)
    {
      return null;
      i += 1;
      try
      {
        publishProgress(new Integer[] { Integer.valueOf(i) });
        TimeUnit.SECONDS.sleep(1L);
      }
      catch (InterruptedException localInterruptedException)
      {
        localInterruptedException.printStackTrace();
      }
    }
  }
  
  protected final void onPreExecute()
  {
    this.a.findViewById(2131427347).setVisibility(8);
    this.a.findViewById(2131427353).setVisibility(0);
    this.a.findViewById(2131427371).setVisibility(0);
    this.a.findViewById(2131427370).setVisibility(8);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cZ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */