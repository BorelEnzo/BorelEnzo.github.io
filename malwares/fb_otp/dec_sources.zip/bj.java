import android.view.View;

public class bj
  extends bi
{
  public final int a(View paramView)
  {
    return paramView.getOverScrollMode();
  }
  
  public final void a(View paramView, int paramInt)
  {
    paramView.setOverScrollMode(paramInt);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */