import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;

public abstract interface G
{
  public abstract Intent a(Activity paramActivity);
  
  public abstract String a(Context paramContext, ActivityInfo paramActivityInfo);
  
  public abstract void a(Activity paramActivity, Intent paramIntent);
  
  public abstract boolean a(Activity paramActivity, Intent paramIntent);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/G.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */