import android.support.v4.view.ViewPager;

public final class bx
  implements Runnable
{
  public bx(ViewPager paramViewPager) {}
  
  public final void run()
  {
    ViewPager.a(this.a);
    this.a.b();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */