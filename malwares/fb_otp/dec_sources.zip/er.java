final class er
  implements Runnable
{
  er(eq parameq) {}
  
  public final void run()
  {
    eq.a(this.a);
    eq.b(this.a);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/er.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */