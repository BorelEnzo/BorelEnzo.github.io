import android.app.Activity;
import android.content.Intent;
import android.support.v4.app.ShareCompat.IntentBuilder;
import android.view.ActionProvider;
import android.view.MenuItem;
import android.widget.ShareActionProvider;

public class S
  extends R
{
  public final void a(MenuItem paramMenuItem, ShareCompat.IntentBuilder paramIntentBuilder)
  {
    Activity localActivity = paramIntentBuilder.a();
    Intent localIntent = paramIntentBuilder.getIntent();
    Object localObject = paramMenuItem.getActionProvider();
    if (!(localObject instanceof ShareActionProvider)) {}
    for (localObject = new ShareActionProvider(localActivity);; localObject = (ShareActionProvider)localObject)
    {
      ((ShareActionProvider)localObject).setShareHistoryFileName(".sharecompat_" + localActivity.getClass().getName());
      ((ShareActionProvider)localObject).setShareIntent(localIntent);
      paramMenuItem.setActionProvider((ActionProvider)localObject);
      if (a(paramMenuItem)) {
        paramMenuItem.setIntent(paramIntentBuilder.createChooserIntent());
      }
      return;
    }
  }
  
  boolean a(MenuItem paramMenuItem)
  {
    return !paramMenuItem.hasSubMenu();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/S.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */