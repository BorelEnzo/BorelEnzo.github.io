import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.pm.ResolveInfo;

public class b
  implements c
{
  public ResolveInfo a(AccessibilityServiceInfo paramAccessibilityServiceInfo)
  {
    return null;
  }
  
  public String a(AccessibilityServiceInfo paramAccessibilityServiceInfo)
  {
    return null;
  }
  
  public boolean a(AccessibilityServiceInfo paramAccessibilityServiceInfo)
  {
    return false;
  }
  
  public String b(AccessibilityServiceInfo paramAccessibilityServiceInfo)
  {
    return null;
  }
  
  public String c(AccessibilityServiceInfo paramAccessibilityServiceInfo)
  {
    return null;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/b.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */