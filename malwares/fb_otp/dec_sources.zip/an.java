import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public final class an
  implements ao
{
  public final boolean a(ConnectivityManager paramConnectivityManager)
  {
    paramConnectivityManager = paramConnectivityManager.getActiveNetworkInfo();
    if (paramConnectivityManager == null) {
      return true;
    }
    switch (paramConnectivityManager.getType())
    {
    case 0: 
    default: 
      return true;
    }
    return false;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/an.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */