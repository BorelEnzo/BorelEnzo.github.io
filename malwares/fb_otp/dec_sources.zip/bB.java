import android.support.v4.view.PagerAdapter;

public abstract interface bB
{
  public abstract void a(PagerAdapter paramPagerAdapter1, PagerAdapter paramPagerAdapter2);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */