import android.view.MenuItem;
import android.view.View;

public final class aR
  implements aT
{
  public final MenuItem a(MenuItem paramMenuItem, View paramView)
  {
    return paramMenuItem;
  }
  
  public final boolean a(MenuItem paramMenuItem, int paramInt)
  {
    return false;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/aR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */