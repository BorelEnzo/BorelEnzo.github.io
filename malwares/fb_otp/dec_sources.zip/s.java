import android.os.Handler;
import android.support.v4.app.FragmentActivity;

final class s
  implements Runnable
{
  s(o paramo, int paramInt1, int paramInt2) {}
  
  public final void run()
  {
    o localo = this.jdField_a_of_type_O;
    Handler localHandler = this.jdField_a_of_type_O.a.a;
    localo.a(null, this.jdField_a_of_type_Int, this.b);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/s.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */