import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.support.v4.app.Fragment;
import android.support.v4.app.Fragment.SavedState;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentManager.BackStackEntry;
import android.support.v4.app.FragmentManager.OnBackStackChangedListener;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.util.DebugUtils;
import android.support.v4.util.LogWriter;
import android.util.SparseArray;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager.LayoutParams;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;

public final class o
  extends FragmentManager
{
  static final Interpolator jdField_a_of_type_AndroidViewAnimationInterpolator = new DecelerateInterpolator(2.5F);
  public static boolean a;
  static final Interpolator jdField_b_of_type_AndroidViewAnimationInterpolator = new DecelerateInterpolator(1.5F);
  static final boolean jdField_b_of_type_Boolean;
  static final Interpolator jdField_c_of_type_AndroidViewAnimationInterpolator = new AccelerateInterpolator(2.5F);
  static final Interpolator jdField_d_of_type_AndroidViewAnimationInterpolator = new AccelerateInterpolator(1.5F);
  int jdField_a_of_type_Int = 0;
  Bundle jdField_a_of_type_AndroidOsBundle = null;
  Fragment jdField_a_of_type_AndroidSupportV4AppFragment;
  FragmentActivity jdField_a_of_type_AndroidSupportV4AppFragmentActivity;
  SparseArray jdField_a_of_type_AndroidUtilSparseArray = null;
  Runnable jdField_a_of_type_JavaLangRunnable = new p(this);
  String jdField_a_of_type_JavaLangString;
  ArrayList jdField_a_of_type_JavaUtilArrayList;
  n jdField_a_of_type_N;
  Runnable[] jdField_a_of_type_ArrayOfJavaLangRunnable;
  public ArrayList b;
  ArrayList jdField_c_of_type_JavaUtilArrayList;
  boolean jdField_c_of_type_Boolean;
  ArrayList jdField_d_of_type_JavaUtilArrayList;
  boolean jdField_d_of_type_Boolean;
  ArrayList jdField_e_of_type_JavaUtilArrayList;
  boolean jdField_e_of_type_Boolean;
  ArrayList jdField_f_of_type_JavaUtilArrayList;
  boolean jdField_f_of_type_Boolean;
  ArrayList jdField_g_of_type_JavaUtilArrayList;
  boolean jdField_g_of_type_Boolean;
  ArrayList h;
  ArrayList i;
  
  static
  {
    boolean bool = false;
    jdField_a_of_type_Boolean = false;
    if (Build.VERSION.SDK_INT >= 11) {
      bool = true;
    }
    jdField_b_of_type_Boolean = bool;
  }
  
  public static int a(int paramInt)
  {
    switch (paramInt)
    {
    default: 
      return 0;
    case 4097: 
      return 8194;
    case 8194: 
      return 4097;
    }
    return 4099;
  }
  
  private Bundle a(Fragment paramFragment)
  {
    if (this.jdField_a_of_type_AndroidOsBundle == null) {
      this.jdField_a_of_type_AndroidOsBundle = new Bundle();
    }
    paramFragment.d(this.jdField_a_of_type_AndroidOsBundle);
    Object localObject2;
    if (!this.jdField_a_of_type_AndroidOsBundle.isEmpty())
    {
      localObject2 = this.jdField_a_of_type_AndroidOsBundle;
      this.jdField_a_of_type_AndroidOsBundle = null;
    }
    for (;;)
    {
      if (paramFragment.jdField_b_of_type_AndroidViewView != null) {
        c(paramFragment);
      }
      Object localObject1 = localObject2;
      if (paramFragment.jdField_a_of_type_AndroidUtilSparseArray != null)
      {
        localObject1 = localObject2;
        if (localObject2 == null) {
          localObject1 = new Bundle();
        }
        ((Bundle)localObject1).putSparseParcelableArray("android:view_state", paramFragment.jdField_a_of_type_AndroidUtilSparseArray);
      }
      localObject2 = localObject1;
      if (!paramFragment.t)
      {
        localObject2 = localObject1;
        if (localObject1 == null) {
          localObject2 = new Bundle();
        }
        ((Bundle)localObject2).putBoolean("android:user_visible_hint", paramFragment.t);
      }
      return (Bundle)localObject2;
      localObject2 = null;
    }
  }
  
  private static Animation a(float paramFloat1, float paramFloat2)
  {
    AlphaAnimation localAlphaAnimation = new AlphaAnimation(paramFloat1, paramFloat2);
    localAlphaAnimation.setInterpolator(jdField_b_of_type_AndroidViewAnimationInterpolator);
    localAlphaAnimation.setDuration(220L);
    return localAlphaAnimation;
  }
  
  private static Animation a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4)
  {
    AnimationSet localAnimationSet = new AnimationSet(false);
    Object localObject = new ScaleAnimation(paramFloat1, paramFloat2, paramFloat1, paramFloat2, 1, 0.5F, 1, 0.5F);
    ((ScaleAnimation)localObject).setInterpolator(jdField_a_of_type_AndroidViewAnimationInterpolator);
    ((ScaleAnimation)localObject).setDuration(220L);
    localAnimationSet.addAnimation((Animation)localObject);
    localObject = new AlphaAnimation(paramFloat3, paramFloat4);
    ((AlphaAnimation)localObject).setInterpolator(jdField_b_of_type_AndroidViewAnimationInterpolator);
    ((AlphaAnimation)localObject).setDuration(220L);
    localAnimationSet.addAnimation((Animation)localObject);
    return localAnimationSet;
  }
  
  private Animation a(Fragment paramFragment, int paramInt1, boolean paramBoolean, int paramInt2)
  {
    Animation localAnimation = paramFragment.onCreateAnimation(paramInt1, paramBoolean, paramFragment.jdField_l_of_type_Int);
    if (localAnimation != null) {
      paramFragment = localAnimation;
    }
    do
    {
      return paramFragment;
      if (paramFragment.jdField_l_of_type_Int == 0) {
        break;
      }
      localAnimation = AnimationUtils.loadAnimation(this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity, paramFragment.jdField_l_of_type_Int);
      paramFragment = localAnimation;
    } while (localAnimation != null);
    if (paramInt1 == 0) {
      return null;
    }
    int j = -1;
    switch (paramInt1)
    {
    default: 
      paramInt1 = j;
    }
    while (paramInt1 < 0)
    {
      return null;
      if (paramBoolean)
      {
        paramInt1 = 1;
      }
      else
      {
        paramInt1 = 2;
        continue;
        if (paramBoolean)
        {
          paramInt1 = 3;
        }
        else
        {
          paramInt1 = 4;
          continue;
          if (paramBoolean) {
            paramInt1 = 5;
          } else {
            paramInt1 = 6;
          }
        }
      }
    }
    switch (paramInt1)
    {
    default: 
      paramInt1 = paramInt2;
      if (paramInt2 == 0)
      {
        paramInt1 = paramInt2;
        if (this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.getWindow() != null) {
          paramInt1 = this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.getWindow().getAttributes().windowAnimations;
        }
      }
      if (paramInt1 == 0) {
        return null;
      }
      break;
    case 1: 
      paramFragment = this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity;
      return a(1.125F, 1.0F, 0.0F, 1.0F);
    case 2: 
      paramFragment = this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity;
      return a(1.0F, 0.975F, 1.0F, 0.0F);
    case 3: 
      paramFragment = this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity;
      return a(0.975F, 1.0F, 0.0F, 1.0F);
    case 4: 
      paramFragment = this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity;
      return a(1.0F, 1.075F, 1.0F, 0.0F);
    case 5: 
      paramFragment = this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity;
      return a(0.0F, 1.0F);
    case 6: 
      paramFragment = this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity;
      return a(1.0F, 0.0F);
    }
    return null;
  }
  
  /* Error */
  private void a(int paramInt, d paramd)
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 184	o:jdField_g_of_type_JavaUtilArrayList	Ljava/util/ArrayList;
    //   6: ifnonnull +14 -> 20
    //   9: aload_0
    //   10: new 186	java/util/ArrayList
    //   13: dup
    //   14: invokespecial 187	java/util/ArrayList:<init>	()V
    //   17: putfield 184	o:jdField_g_of_type_JavaUtilArrayList	Ljava/util/ArrayList;
    //   20: aload_0
    //   21: getfield 184	o:jdField_g_of_type_JavaUtilArrayList	Ljava/util/ArrayList;
    //   24: invokevirtual 191	java/util/ArrayList:size	()I
    //   27: istore 4
    //   29: iload 4
    //   31: istore_3
    //   32: iload_1
    //   33: iload 4
    //   35: if_icmpge +48 -> 83
    //   38: getstatic 29	o:jdField_a_of_type_Boolean	Z
    //   41: ifeq +29 -> 70
    //   44: new 193	java/lang/StringBuilder
    //   47: dup
    //   48: ldc -61
    //   50: invokespecial 198	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   53: iload_1
    //   54: invokevirtual 202	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   57: ldc -52
    //   59: invokevirtual 207	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   62: aload_2
    //   63: invokevirtual 210	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   66: invokevirtual 214	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   69: pop
    //   70: aload_0
    //   71: getfield 184	o:jdField_g_of_type_JavaUtilArrayList	Ljava/util/ArrayList;
    //   74: iload_1
    //   75: aload_2
    //   76: invokevirtual 218	java/util/ArrayList:set	(ILjava/lang/Object;)Ljava/lang/Object;
    //   79: pop
    //   80: aload_0
    //   81: monitorexit
    //   82: return
    //   83: iload_3
    //   84: iload_1
    //   85: if_icmpge +72 -> 157
    //   88: aload_0
    //   89: getfield 184	o:jdField_g_of_type_JavaUtilArrayList	Ljava/util/ArrayList;
    //   92: aconst_null
    //   93: invokevirtual 222	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   96: pop
    //   97: aload_0
    //   98: getfield 224	o:h	Ljava/util/ArrayList;
    //   101: ifnonnull +14 -> 115
    //   104: aload_0
    //   105: new 186	java/util/ArrayList
    //   108: dup
    //   109: invokespecial 187	java/util/ArrayList:<init>	()V
    //   112: putfield 224	o:h	Ljava/util/ArrayList;
    //   115: getstatic 29	o:jdField_a_of_type_Boolean	Z
    //   118: ifeq +20 -> 138
    //   121: new 193	java/lang/StringBuilder
    //   124: dup
    //   125: ldc -30
    //   127: invokespecial 198	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   130: iload_3
    //   131: invokevirtual 202	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   134: invokevirtual 214	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   137: pop
    //   138: aload_0
    //   139: getfield 224	o:h	Ljava/util/ArrayList;
    //   142: iload_3
    //   143: invokestatic 232	java/lang/Integer:valueOf	(I)Ljava/lang/Integer;
    //   146: invokevirtual 222	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   149: pop
    //   150: iload_3
    //   151: iconst_1
    //   152: iadd
    //   153: istore_3
    //   154: goto -71 -> 83
    //   157: getstatic 29	o:jdField_a_of_type_Boolean	Z
    //   160: ifeq +29 -> 189
    //   163: new 193	java/lang/StringBuilder
    //   166: dup
    //   167: ldc -22
    //   169: invokespecial 198	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   172: iload_1
    //   173: invokevirtual 202	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   176: ldc -20
    //   178: invokevirtual 207	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   181: aload_2
    //   182: invokevirtual 210	java/lang/StringBuilder:append	(Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   185: invokevirtual 214	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   188: pop
    //   189: aload_0
    //   190: getfield 184	o:jdField_g_of_type_JavaUtilArrayList	Ljava/util/ArrayList;
    //   193: aload_2
    //   194: invokevirtual 222	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   197: pop
    //   198: goto -118 -> 80
    //   201: astore_2
    //   202: aload_0
    //   203: monitorexit
    //   204: aload_2
    //   205: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	206	0	this	o
    //   0	206	1	paramInt	int
    //   0	206	2	paramd	d
    //   31	123	3	j	int
    //   27	9	4	k	int
    // Exception table:
    //   from	to	target	type
    //   2	20	201	finally
    //   20	29	201	finally
    //   38	70	201	finally
    //   70	80	201	finally
    //   80	82	201	finally
    //   88	115	201	finally
    //   115	138	201	finally
    //   138	150	201	finally
    //   157	189	201	finally
    //   189	198	201	finally
  }
  
  private void a(RuntimeException paramRuntimeException)
  {
    paramRuntimeException.getMessage();
    PrintWriter localPrintWriter = new PrintWriter(new LogWriter("FragmentManager"));
    if (this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity != null) {}
    try
    {
      this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.dump("  ", null, localPrintWriter, new String[0]);
      for (;;)
      {
        throw paramRuntimeException;
        try
        {
          dump("  ", null, localPrintWriter, new String[0]);
        }
        catch (Exception localException1) {}
      }
    }
    catch (Exception localException2)
    {
      for (;;) {}
    }
  }
  
  private void b(int paramInt)
  {
    a(paramInt, 0, 0, false);
  }
  
  private void c(Fragment paramFragment)
  {
    if (paramFragment.c == null) {
      return;
    }
    if (this.jdField_a_of_type_AndroidUtilSparseArray == null) {
      this.jdField_a_of_type_AndroidUtilSparseArray = new SparseArray();
    }
    for (;;)
    {
      paramFragment.c.saveHierarchyState(this.jdField_a_of_type_AndroidUtilSparseArray);
      if (this.jdField_a_of_type_AndroidUtilSparseArray.size() <= 0) {
        break;
      }
      paramFragment.jdField_a_of_type_AndroidUtilSparseArray = this.jdField_a_of_type_AndroidUtilSparseArray;
      this.jdField_a_of_type_AndroidUtilSparseArray = null;
      return;
      this.jdField_a_of_type_AndroidUtilSparseArray.clear();
    }
  }
  
  private void m()
  {
    if (this.jdField_e_of_type_Boolean) {
      throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
    }
    if (this.jdField_a_of_type_JavaLangString != null) {
      throw new IllegalStateException("Can not perform this action inside of " + this.jdField_a_of_type_JavaLangString);
    }
  }
  
  private void n()
  {
    if (this.i != null)
    {
      int j = 0;
      while (j < this.i.size())
      {
        ((FragmentManager.OnBackStackChangedListener)this.i.get(j)).onBackStackChanged();
        j += 1;
      }
    }
  }
  
  public final int a(d paramd)
  {
    try
    {
      if ((this.h == null) || (this.h.size() <= 0))
      {
        if (this.jdField_g_of_type_JavaUtilArrayList == null) {
          this.jdField_g_of_type_JavaUtilArrayList = new ArrayList();
        }
        j = this.jdField_g_of_type_JavaUtilArrayList.size();
        if (jdField_a_of_type_Boolean) {
          new StringBuilder("Setting back stack index ").append(j).append(" to ").append(paramd).toString();
        }
        this.jdField_g_of_type_JavaUtilArrayList.add(paramd);
        return j;
      }
      int j = ((Integer)this.h.remove(this.h.size() - 1)).intValue();
      if (jdField_a_of_type_Boolean) {
        new StringBuilder("Adding back stack index ").append(j).append(" with ").append(paramd).toString();
      }
      this.jdField_g_of_type_JavaUtilArrayList.set(j, paramd);
      return j;
    }
    finally {}
  }
  
  public final Parcelable a()
  {
    Object localObject3 = null;
    a();
    if (jdField_b_of_type_Boolean) {
      this.jdField_e_of_type_Boolean = true;
    }
    if ((this.jdField_b_of_type_JavaUtilArrayList == null) || (this.jdField_b_of_type_JavaUtilArrayList.size() <= 0)) {
      return null;
    }
    int m = this.jdField_b_of_type_JavaUtilArrayList.size();
    w[] arrayOfw = new w[m];
    int k = 0;
    int j = 0;
    Object localObject1;
    Object localObject2;
    if (k < m)
    {
      localObject1 = (Fragment)this.jdField_b_of_type_JavaUtilArrayList.get(k);
      if (localObject1 == null) {
        break label675;
      }
      if (((Fragment)localObject1).jdField_f_of_type_Int < 0) {
        a(new IllegalStateException("Failure saving state: active " + localObject1 + " has cleared index: " + ((Fragment)localObject1).jdField_f_of_type_Int));
      }
      localObject2 = new w((Fragment)localObject1);
      arrayOfw[k] = localObject2;
      if ((((Fragment)localObject1).d > 0) && (((w)localObject2).b == null))
      {
        ((w)localObject2).b = a((Fragment)localObject1);
        if (((Fragment)localObject1).jdField_a_of_type_AndroidSupportV4AppFragment != null)
        {
          if (((Fragment)localObject1).jdField_a_of_type_AndroidSupportV4AppFragment.jdField_f_of_type_Int < 0) {
            a(new IllegalStateException("Failure saving state: " + localObject1 + " has target not in fragment manager: " + ((Fragment)localObject1).jdField_a_of_type_AndroidSupportV4AppFragment));
          }
          if (((w)localObject2).b == null) {
            ((w)localObject2).b = new Bundle();
          }
          putFragment(((w)localObject2).b, "android:target_state", ((Fragment)localObject1).jdField_a_of_type_AndroidSupportV4AppFragment);
          if (((Fragment)localObject1).jdField_h_of_type_Int != 0) {
            ((w)localObject2).b.putInt("android:target_req_state", ((Fragment)localObject1).jdField_h_of_type_Int);
          }
        }
        label297:
        if (jdField_a_of_type_Boolean) {
          new StringBuilder("Saved state of ").append(localObject1).append(": ").append(((w)localObject2).b).toString();
        }
        j = 1;
      }
    }
    label675:
    for (;;)
    {
      k += 1;
      break;
      ((w)localObject2).b = ((Fragment)localObject1).jdField_a_of_type_AndroidOsBundle;
      break label297;
      if (j == 0)
      {
        boolean bool = jdField_a_of_type_Boolean;
        return null;
      }
      if (this.jdField_c_of_type_JavaUtilArrayList != null)
      {
        k = this.jdField_c_of_type_JavaUtilArrayList.size();
        if (k > 0)
        {
          localObject2 = new int[k];
          j = 0;
          for (;;)
          {
            localObject1 = localObject2;
            if (j >= k) {
              break;
            }
            localObject2[j] = ((Fragment)this.jdField_c_of_type_JavaUtilArrayList.get(j)).jdField_f_of_type_Int;
            if (localObject2[j] < 0) {
              a(new IllegalStateException("Failure saving state: active " + this.jdField_c_of_type_JavaUtilArrayList.get(j) + " has cleared index: " + localObject2[j]));
            }
            if (jdField_a_of_type_Boolean) {
              new StringBuilder("saveAllState: adding fragment #").append(j).append(": ").append(this.jdField_c_of_type_JavaUtilArrayList.get(j)).toString();
            }
            j += 1;
          }
        }
      }
      localObject1 = null;
      localObject2 = localObject3;
      if (this.jdField_e_of_type_JavaUtilArrayList != null)
      {
        k = this.jdField_e_of_type_JavaUtilArrayList.size();
        localObject2 = localObject3;
        if (k > 0)
        {
          localObject3 = new f[k];
          j = 0;
          for (;;)
          {
            localObject2 = localObject3;
            if (j >= k) {
              break;
            }
            localObject3[j] = new f((d)this.jdField_e_of_type_JavaUtilArrayList.get(j));
            if (jdField_a_of_type_Boolean) {
              new StringBuilder("saveAllState: adding back stack #").append(j).append(": ").append(this.jdField_e_of_type_JavaUtilArrayList.get(j)).toString();
            }
            j += 1;
          }
        }
      }
      localObject3 = new u();
      ((u)localObject3).jdField_a_of_type_ArrayOfW = arrayOfw;
      ((u)localObject3).jdField_a_of_type_ArrayOfInt = ((int[])localObject1);
      ((u)localObject3).jdField_a_of_type_ArrayOfF = ((f[])localObject2);
      return (Parcelable)localObject3;
    }
  }
  
  public final ArrayList a()
  {
    Object localObject2 = null;
    Object localObject1 = null;
    if (this.jdField_b_of_type_JavaUtilArrayList != null)
    {
      int j = 0;
      localObject2 = localObject1;
      if (j < this.jdField_b_of_type_JavaUtilArrayList.size())
      {
        Fragment localFragment = (Fragment)this.jdField_b_of_type_JavaUtilArrayList.get(j);
        Object localObject3 = localObject1;
        if (localFragment != null)
        {
          localObject3 = localObject1;
          if (localFragment.n)
          {
            localObject2 = localObject1;
            if (localObject1 == null) {
              localObject2 = new ArrayList();
            }
            ((ArrayList)localObject2).add(localFragment);
            localFragment.o = true;
            if (localFragment.jdField_a_of_type_AndroidSupportV4AppFragment == null) {
              break label156;
            }
          }
        }
        label156:
        for (int k = localFragment.jdField_a_of_type_AndroidSupportV4AppFragment.jdField_f_of_type_Int;; k = -1)
        {
          localFragment.jdField_g_of_type_Int = k;
          localObject3 = localObject2;
          if (jdField_a_of_type_Boolean)
          {
            new StringBuilder("retainNonConfig: keeping retained ").append(localFragment).toString();
            localObject3 = localObject2;
          }
          j += 1;
          localObject1 = localObject3;
          break;
        }
      }
    }
    return (ArrayList)localObject2;
  }
  
  final void a()
  {
    if (this.jdField_b_of_type_JavaUtilArrayList == null) {}
    for (;;)
    {
      return;
      int j = 0;
      while (j < this.jdField_b_of_type_JavaUtilArrayList.size())
      {
        Fragment localFragment = (Fragment)this.jdField_b_of_type_JavaUtilArrayList.get(j);
        if (localFragment != null) {
          a(localFragment);
        }
        j += 1;
      }
    }
  }
  
  public final void a(int paramInt)
  {
    try
    {
      this.jdField_g_of_type_JavaUtilArrayList.set(paramInt, null);
      if (this.h == null) {
        this.h = new ArrayList();
      }
      if (jdField_a_of_type_Boolean) {
        new StringBuilder("Freeing back stack index ").append(paramInt).toString();
      }
      this.h.add(Integer.valueOf(paramInt));
      return;
    }
    finally {}
  }
  
  final void a(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    if ((this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity == null) && (paramInt1 != 0)) {
      throw new IllegalStateException("No activity");
    }
    if ((!paramBoolean) && (this.jdField_a_of_type_Int == paramInt1)) {}
    do
    {
      return;
      this.jdField_a_of_type_Int = paramInt1;
    } while (this.jdField_b_of_type_JavaUtilArrayList == null);
    int j = 0;
    boolean bool = false;
    label54:
    if (j < this.jdField_b_of_type_JavaUtilArrayList.size())
    {
      Fragment localFragment = (Fragment)this.jdField_b_of_type_JavaUtilArrayList.get(j);
      if (localFragment == null) {
        break label169;
      }
      a(localFragment, paramInt1, paramInt2, paramInt3, false);
      if (localFragment.jdField_a_of_type_E == null) {
        break label169;
      }
      bool |= localFragment.jdField_a_of_type_E.hasRunningLoaders();
    }
    label169:
    for (;;)
    {
      j += 1;
      break label54;
      if (!bool) {
        a();
      }
      if ((!this.jdField_d_of_type_Boolean) || (this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity == null) || (this.jdField_a_of_type_Int != 5)) {
        break;
      }
      this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.supportInvalidateOptionsMenu();
      this.jdField_d_of_type_Boolean = false;
      return;
    }
  }
  
  public final void a(Configuration paramConfiguration)
  {
    if (this.jdField_c_of_type_JavaUtilArrayList != null)
    {
      int j = 0;
      while (j < this.jdField_c_of_type_JavaUtilArrayList.size())
      {
        Fragment localFragment = (Fragment)this.jdField_c_of_type_JavaUtilArrayList.get(j);
        if (localFragment != null) {
          localFragment.a(paramConfiguration);
        }
        j += 1;
      }
    }
  }
  
  public final void a(Parcelable paramParcelable, ArrayList paramArrayList)
  {
    if (paramParcelable == null) {}
    for (;;)
    {
      return;
      paramParcelable = (u)paramParcelable;
      if (paramParcelable.jdField_a_of_type_ArrayOfW != null)
      {
        Object localObject1;
        Object localObject2;
        if (paramArrayList != null)
        {
          j = 0;
          while (j < paramArrayList.size())
          {
            localObject1 = (Fragment)paramArrayList.get(j);
            if (jdField_a_of_type_Boolean) {
              new StringBuilder("restoreAllState: re-attaching retained ").append(localObject1).toString();
            }
            localObject2 = paramParcelable.jdField_a_of_type_ArrayOfW[localObject1.jdField_f_of_type_Int];
            ((w)localObject2).jdField_a_of_type_AndroidSupportV4AppFragment = ((Fragment)localObject1);
            ((Fragment)localObject1).jdField_a_of_type_AndroidUtilSparseArray = null;
            ((Fragment)localObject1).jdField_i_of_type_Int = 0;
            ((Fragment)localObject1).jdField_j_of_type_Boolean = false;
            ((Fragment)localObject1).jdField_f_of_type_Boolean = false;
            ((Fragment)localObject1).jdField_a_of_type_AndroidSupportV4AppFragment = null;
            if (((w)localObject2).b != null)
            {
              ((w)localObject2).b.setClassLoader(this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.getClassLoader());
              ((Fragment)localObject1).jdField_a_of_type_AndroidUtilSparseArray = ((w)localObject2).b.getSparseParcelableArray("android:view_state");
            }
            j += 1;
          }
        }
        this.jdField_b_of_type_JavaUtilArrayList = new ArrayList(paramParcelable.jdField_a_of_type_ArrayOfW.length);
        if (this.jdField_d_of_type_JavaUtilArrayList != null) {
          this.jdField_d_of_type_JavaUtilArrayList.clear();
        }
        int j = 0;
        if (j < paramParcelable.jdField_a_of_type_ArrayOfW.length)
        {
          localObject1 = paramParcelable.jdField_a_of_type_ArrayOfW[j];
          if (localObject1 != null)
          {
            localObject2 = ((w)localObject1).a(this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity, this.jdField_a_of_type_AndroidSupportV4AppFragment);
            if (jdField_a_of_type_Boolean) {
              new StringBuilder("restoreAllState: active #").append(j).append(": ").append(localObject2).toString();
            }
            this.jdField_b_of_type_JavaUtilArrayList.add(localObject2);
            ((w)localObject1).jdField_a_of_type_AndroidSupportV4AppFragment = null;
          }
          for (;;)
          {
            j += 1;
            break;
            this.jdField_b_of_type_JavaUtilArrayList.add(null);
            if (this.jdField_d_of_type_JavaUtilArrayList == null) {
              this.jdField_d_of_type_JavaUtilArrayList = new ArrayList();
            }
            if (jdField_a_of_type_Boolean) {
              new StringBuilder("restoreAllState: avail #").append(j).toString();
            }
            this.jdField_d_of_type_JavaUtilArrayList.add(Integer.valueOf(j));
          }
        }
        if (paramArrayList != null)
        {
          j = 0;
          if (j < paramArrayList.size())
          {
            localObject1 = (Fragment)paramArrayList.get(j);
            if (((Fragment)localObject1).jdField_g_of_type_Int >= 0) {
              if (((Fragment)localObject1).jdField_g_of_type_Int >= this.jdField_b_of_type_JavaUtilArrayList.size()) {
                break label427;
              }
            }
            for (((Fragment)localObject1).jdField_a_of_type_AndroidSupportV4AppFragment = ((Fragment)this.jdField_b_of_type_JavaUtilArrayList.get(((Fragment)localObject1).jdField_g_of_type_Int));; ((Fragment)localObject1).jdField_a_of_type_AndroidSupportV4AppFragment = null)
            {
              j += 1;
              break;
              label427:
              new StringBuilder("Re-attaching retained fragment ").append(localObject1).append(" target no longer exists: ").append(((Fragment)localObject1).jdField_g_of_type_Int).toString();
            }
          }
        }
        if (paramParcelable.jdField_a_of_type_ArrayOfInt != null)
        {
          this.jdField_c_of_type_JavaUtilArrayList = new ArrayList(paramParcelable.jdField_a_of_type_ArrayOfInt.length);
          j = 0;
          while (j < paramParcelable.jdField_a_of_type_ArrayOfInt.length)
          {
            paramArrayList = (Fragment)this.jdField_b_of_type_JavaUtilArrayList.get(paramParcelable.jdField_a_of_type_ArrayOfInt[j]);
            if (paramArrayList == null) {
              a(new IllegalStateException("No instantiated fragment for index #" + paramParcelable.jdField_a_of_type_ArrayOfInt[j]));
            }
            paramArrayList.jdField_f_of_type_Boolean = true;
            if (jdField_a_of_type_Boolean) {
              new StringBuilder("restoreAllState: added #").append(j).append(": ").append(paramArrayList).toString();
            }
            if (this.jdField_c_of_type_JavaUtilArrayList.contains(paramArrayList)) {
              throw new IllegalStateException("Already added!");
            }
            this.jdField_c_of_type_JavaUtilArrayList.add(paramArrayList);
            j += 1;
          }
        }
        this.jdField_c_of_type_JavaUtilArrayList = null;
        if (paramParcelable.jdField_a_of_type_ArrayOfF == null) {
          break;
        }
        this.jdField_e_of_type_JavaUtilArrayList = new ArrayList(paramParcelable.jdField_a_of_type_ArrayOfF.length);
        j = 0;
        while (j < paramParcelable.jdField_a_of_type_ArrayOfF.length)
        {
          paramArrayList = paramParcelable.jdField_a_of_type_ArrayOfF[j].a(this);
          if (jdField_a_of_type_Boolean)
          {
            new StringBuilder("restoreAllState: back stack #").append(j).append(" (index ").append(paramArrayList.jdField_h_of_type_Int).append("): ").append(paramArrayList).toString();
            paramArrayList.a("  ", new PrintWriter(new LogWriter("FragmentManager")), false);
          }
          this.jdField_e_of_type_JavaUtilArrayList.add(paramArrayList);
          if (paramArrayList.jdField_h_of_type_Int >= 0) {
            a(paramArrayList.jdField_h_of_type_Int, paramArrayList);
          }
          j += 1;
        }
      }
    }
    this.jdField_e_of_type_JavaUtilArrayList = null;
  }
  
  public final void a(Fragment paramFragment)
  {
    if (paramFragment.s)
    {
      if (this.jdField_c_of_type_Boolean) {
        this.jdField_g_of_type_Boolean = true;
      }
    }
    else {
      return;
    }
    paramFragment.s = false;
    a(paramFragment, this.jdField_a_of_type_Int, 0, 0, false);
  }
  
  public final void a(Fragment paramFragment, int paramInt1, int paramInt2)
  {
    if (jdField_a_of_type_Boolean) {
      new StringBuilder("remove: ").append(paramFragment).append(" nesting=").append(paramFragment.jdField_i_of_type_Int).toString();
    }
    if (!paramFragment.a())
    {
      j = 1;
      if ((!paramFragment.m) || (j != 0))
      {
        if (this.jdField_c_of_type_JavaUtilArrayList != null) {
          this.jdField_c_of_type_JavaUtilArrayList.remove(paramFragment);
        }
        if ((paramFragment.p) && (paramFragment.q)) {
          this.jdField_d_of_type_Boolean = true;
        }
        paramFragment.jdField_f_of_type_Boolean = false;
        paramFragment.jdField_g_of_type_Boolean = true;
        if (j == 0) {
          break label129;
        }
      }
    }
    label129:
    for (int j = 0;; j = 1)
    {
      a(paramFragment, j, paramInt1, paramInt2, false);
      return;
      j = 0;
      break;
    }
  }
  
  final void a(Fragment paramFragment, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean)
  {
    int j;
    if (paramFragment.jdField_f_of_type_Boolean)
    {
      j = paramInt1;
      if (!paramFragment.m) {}
    }
    else
    {
      j = paramInt1;
      if (paramInt1 > 1) {
        j = 1;
      }
    }
    int k = j;
    if (paramFragment.jdField_g_of_type_Boolean)
    {
      k = j;
      if (j > paramFragment.d) {
        k = paramFragment.d;
      }
    }
    paramInt1 = k;
    if (paramFragment.s)
    {
      paramInt1 = k;
      if (paramFragment.d < 4)
      {
        paramInt1 = k;
        if (k > 3) {
          paramInt1 = 3;
        }
      }
    }
    int m;
    label544:
    Object localObject2;
    if (paramFragment.d < paramInt1)
    {
      if ((paramFragment.jdField_i_of_type_Boolean) && (!paramFragment.jdField_j_of_type_Boolean)) {
        return;
      }
      if (paramFragment.jdField_a_of_type_AndroidViewView != null)
      {
        paramFragment.jdField_a_of_type_AndroidViewView = null;
        a(paramFragment, paramFragment.e, 0, 0, true);
      }
      j = paramInt1;
      m = paramInt1;
      k = paramInt1;
      switch (paramFragment.d)
      {
      default: 
        j = paramInt1;
        paramFragment.d = j;
        return;
      case 0: 
        if (jdField_a_of_type_Boolean) {
          new StringBuilder("moveto CREATED: ").append(paramFragment).toString();
        }
        k = paramInt1;
        if (paramFragment.jdField_a_of_type_AndroidOsBundle != null)
        {
          paramFragment.jdField_a_of_type_AndroidUtilSparseArray = paramFragment.jdField_a_of_type_AndroidOsBundle.getSparseParcelableArray("android:view_state");
          paramFragment.jdField_a_of_type_AndroidSupportV4AppFragment = getFragment(paramFragment.jdField_a_of_type_AndroidOsBundle, "android:target_state");
          if (paramFragment.jdField_a_of_type_AndroidSupportV4AppFragment != null) {
            paramFragment.jdField_h_of_type_Int = paramFragment.jdField_a_of_type_AndroidOsBundle.getInt("android:target_req_state", 0);
          }
          paramFragment.t = paramFragment.jdField_a_of_type_AndroidOsBundle.getBoolean("android:user_visible_hint", true);
          k = paramInt1;
          if (!paramFragment.t)
          {
            paramFragment.s = true;
            k = paramInt1;
            if (paramInt1 > 3) {
              k = 3;
            }
          }
        }
        paramFragment.jdField_a_of_type_AndroidSupportV4AppFragmentActivity = this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity;
        paramFragment.jdField_b_of_type_AndroidSupportV4AppFragment = this.jdField_a_of_type_AndroidSupportV4AppFragment;
        if (this.jdField_a_of_type_AndroidSupportV4AppFragment != null) {}
        for (localObject1 = this.jdField_a_of_type_AndroidSupportV4AppFragment.jdField_b_of_type_O;; localObject1 = this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.jdField_a_of_type_O)
        {
          paramFragment.jdField_a_of_type_O = ((o)localObject1);
          paramFragment.r = false;
          paramFragment.onAttach(this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity);
          if (paramFragment.r) {
            break;
          }
          throw new U("Fragment " + paramFragment + " did not call through to super.onAttach()");
        }
        if (paramFragment.jdField_b_of_type_AndroidSupportV4AppFragment == null) {
          this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.onAttachFragment(paramFragment);
        }
        if (!paramFragment.o) {
          paramFragment.b(paramFragment.jdField_a_of_type_AndroidOsBundle);
        }
        paramFragment.o = false;
        j = k;
        if (paramFragment.jdField_i_of_type_Boolean)
        {
          paramFragment.jdField_b_of_type_AndroidViewView = paramFragment.a(paramFragment.getLayoutInflater(paramFragment.jdField_a_of_type_AndroidOsBundle), null, paramFragment.jdField_a_of_type_AndroidOsBundle);
          if (paramFragment.jdField_b_of_type_AndroidViewView == null) {
            break label953;
          }
          paramFragment.c = paramFragment.jdField_b_of_type_AndroidViewView;
          paramFragment.jdField_b_of_type_AndroidViewView = J.a(paramFragment.jdField_b_of_type_AndroidViewView);
          if (paramFragment.jdField_l_of_type_Boolean) {
            paramFragment.jdField_b_of_type_AndroidViewView.setVisibility(8);
          }
          paramFragment.onViewCreated(paramFragment.jdField_b_of_type_AndroidViewView, paramFragment.jdField_a_of_type_AndroidOsBundle);
          j = k;
        }
      case 1: 
        m = j;
        if (j > 1)
        {
          if (jdField_a_of_type_Boolean) {
            new StringBuilder("moveto ACTIVITY_CREATED: ").append(paramFragment).toString();
          }
          if (!paramFragment.jdField_i_of_type_Boolean)
          {
            if (paramFragment.jdField_k_of_type_Int == 0) {
              break label1580;
            }
            localObject2 = (ViewGroup)this.jdField_a_of_type_N.a(paramFragment.jdField_k_of_type_Int);
            localObject1 = localObject2;
            if (localObject2 == null)
            {
              localObject1 = localObject2;
              if (!paramFragment.jdField_k_of_type_Boolean) {
                a(new IllegalArgumentException("No view found for id 0x" + Integer.toHexString(paramFragment.jdField_k_of_type_Int) + " (" + paramFragment.getResources().getResourceName(paramFragment.jdField_k_of_type_Int) + ") for fragment " + paramFragment));
              }
            }
          }
        }
        break;
      }
    }
    label953:
    label1030:
    label1360:
    label1574:
    label1580:
    for (Object localObject1 = localObject2;; localObject1 = null)
    {
      paramFragment.jdField_a_of_type_AndroidViewViewGroup = ((ViewGroup)localObject1);
      paramFragment.jdField_b_of_type_AndroidViewView = paramFragment.a(paramFragment.getLayoutInflater(paramFragment.jdField_a_of_type_AndroidOsBundle), (ViewGroup)localObject1, paramFragment.jdField_a_of_type_AndroidOsBundle);
      if (paramFragment.jdField_b_of_type_AndroidViewView != null)
      {
        paramFragment.c = paramFragment.jdField_b_of_type_AndroidViewView;
        paramFragment.jdField_b_of_type_AndroidViewView = J.a(paramFragment.jdField_b_of_type_AndroidViewView);
        if (localObject1 != null)
        {
          localObject2 = a(paramFragment, paramInt2, true, paramInt3);
          if (localObject2 != null) {
            paramFragment.jdField_b_of_type_AndroidViewView.startAnimation((Animation)localObject2);
          }
          ((ViewGroup)localObject1).addView(paramFragment.jdField_b_of_type_AndroidViewView);
        }
        if (paramFragment.jdField_l_of_type_Boolean) {
          paramFragment.jdField_b_of_type_AndroidViewView.setVisibility(8);
        }
        paramFragment.onViewCreated(paramFragment.jdField_b_of_type_AndroidViewView, paramFragment.jdField_a_of_type_AndroidOsBundle);
      }
      for (;;)
      {
        paramFragment.c(paramFragment.jdField_a_of_type_AndroidOsBundle);
        if (paramFragment.jdField_b_of_type_AndroidViewView != null) {
          paramFragment.a(paramFragment.jdField_a_of_type_AndroidOsBundle);
        }
        paramFragment.jdField_a_of_type_AndroidOsBundle = null;
        m = j;
        k = m;
        if (m > 3)
        {
          if (jdField_a_of_type_Boolean) {
            new StringBuilder("moveto STARTED: ").append(paramFragment).toString();
          }
          paramFragment.b();
          k = m;
        }
        j = k;
        if (k <= 4) {
          break;
        }
        if (jdField_a_of_type_Boolean) {
          new StringBuilder("moveto RESUMED: ").append(paramFragment).toString();
        }
        paramFragment.jdField_h_of_type_Boolean = true;
        paramFragment.c();
        paramFragment.jdField_a_of_type_AndroidOsBundle = null;
        paramFragment.jdField_a_of_type_AndroidUtilSparseArray = null;
        j = k;
        break;
        paramFragment.c = null;
        j = k;
        break label544;
        paramFragment.c = null;
      }
      j = paramInt1;
      if (paramFragment.d <= paramInt1) {
        break;
      }
      switch (paramFragment.d)
      {
      default: 
        j = paramInt1;
        break;
      case 1: 
      case 5: 
      case 4: 
      case 3: 
      case 2: 
        do
        {
          j = paramInt1;
          if (paramInt1 > 0) {
            break;
          }
          if ((this.jdField_f_of_type_Boolean) && (paramFragment.jdField_a_of_type_AndroidViewView != null))
          {
            localObject1 = paramFragment.jdField_a_of_type_AndroidViewView;
            paramFragment.jdField_a_of_type_AndroidViewView = null;
            ((View)localObject1).clearAnimation();
          }
          if (paramFragment.jdField_a_of_type_AndroidViewView == null) {
            break label1360;
          }
          paramFragment.e = paramInt1;
          j = 1;
          break;
          if (paramInt1 < 5)
          {
            if (jdField_a_of_type_Boolean) {
              new StringBuilder("movefrom RESUMED: ").append(paramFragment).toString();
            }
            paramFragment.e();
            paramFragment.jdField_h_of_type_Boolean = false;
          }
          if (paramInt1 < 4)
          {
            if (jdField_a_of_type_Boolean) {
              new StringBuilder("movefrom STARTED: ").append(paramFragment).toString();
            }
            paramFragment.f();
          }
          if (paramInt1 < 3)
          {
            if (jdField_a_of_type_Boolean) {
              new StringBuilder("movefrom STOPPED: ").append(paramFragment).toString();
            }
            paramFragment.g();
          }
        } while (paramInt1 >= 2);
        if (jdField_a_of_type_Boolean) {
          new StringBuilder("movefrom ACTIVITY_CREATED: ").append(paramFragment).toString();
        }
        if ((paramFragment.jdField_b_of_type_AndroidViewView != null) && (!this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.isFinishing()) && (paramFragment.jdField_a_of_type_AndroidUtilSparseArray == null)) {
          c(paramFragment);
        }
        paramFragment.h();
        if ((paramFragment.jdField_b_of_type_AndroidViewView != null) && (paramFragment.jdField_a_of_type_AndroidViewViewGroup != null)) {
          if ((this.jdField_a_of_type_Int <= 0) || (this.jdField_f_of_type_Boolean)) {
            break label1574;
          }
        }
        for (localObject1 = a(paramFragment, paramInt2, false, paramInt3);; localObject1 = null)
        {
          if (localObject1 != null)
          {
            paramFragment.jdField_a_of_type_AndroidViewView = paramFragment.jdField_b_of_type_AndroidViewView;
            paramFragment.e = paramInt1;
            ((Animation)localObject1).setAnimationListener(new t(this, paramFragment));
            paramFragment.jdField_b_of_type_AndroidViewView.startAnimation((Animation)localObject1);
          }
          paramFragment.jdField_a_of_type_AndroidViewViewGroup.removeView(paramFragment.jdField_b_of_type_AndroidViewView);
          paramFragment.jdField_a_of_type_AndroidViewViewGroup = null;
          paramFragment.jdField_b_of_type_AndroidViewView = null;
          paramFragment.c = null;
          break label1030;
          if (jdField_a_of_type_Boolean) {
            new StringBuilder("movefrom CREATED: ").append(paramFragment).toString();
          }
          if (!paramFragment.o) {
            paramFragment.i();
          }
          paramFragment.r = false;
          paramFragment.onDetach();
          if (!paramFragment.r) {
            throw new U("Fragment " + paramFragment + " did not call through to super.onDetach()");
          }
          j = paramInt1;
          if (paramBoolean) {
            break;
          }
          if (!paramFragment.o)
          {
            j = paramInt1;
            if (paramFragment.jdField_f_of_type_Int < 0) {
              break;
            }
            if (jdField_a_of_type_Boolean) {
              new StringBuilder("Freeing fragment index ").append(paramFragment).toString();
            }
            this.jdField_b_of_type_JavaUtilArrayList.set(paramFragment.jdField_f_of_type_Int, null);
            if (this.jdField_d_of_type_JavaUtilArrayList == null) {
              this.jdField_d_of_type_JavaUtilArrayList = new ArrayList();
            }
            this.jdField_d_of_type_JavaUtilArrayList.add(Integer.valueOf(paramFragment.jdField_f_of_type_Int));
            this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.a(paramFragment.jdField_a_of_type_JavaLangString);
            paramFragment.a();
            j = paramInt1;
            break;
          }
          paramFragment.jdField_a_of_type_AndroidSupportV4AppFragmentActivity = null;
          paramFragment.jdField_a_of_type_O = null;
          j = paramInt1;
          break;
        }
      }
    }
  }
  
  public final void a(Fragment paramFragment, boolean paramBoolean)
  {
    if (this.jdField_c_of_type_JavaUtilArrayList == null) {
      this.jdField_c_of_type_JavaUtilArrayList = new ArrayList();
    }
    if (jdField_a_of_type_Boolean) {
      new StringBuilder("add: ").append(paramFragment).toString();
    }
    if (paramFragment.jdField_f_of_type_Int < 0)
    {
      if ((this.jdField_d_of_type_JavaUtilArrayList != null) && (this.jdField_d_of_type_JavaUtilArrayList.size() > 0)) {
        break label175;
      }
      if (this.jdField_b_of_type_JavaUtilArrayList == null) {
        this.jdField_b_of_type_JavaUtilArrayList = new ArrayList();
      }
      paramFragment.a(this.jdField_b_of_type_JavaUtilArrayList.size(), this.jdField_a_of_type_AndroidSupportV4AppFragment);
      this.jdField_b_of_type_JavaUtilArrayList.add(paramFragment);
    }
    for (;;)
    {
      if (jdField_a_of_type_Boolean) {
        new StringBuilder("Allocated fragment index ").append(paramFragment).toString();
      }
      if (paramFragment.m) {
        return;
      }
      if (!this.jdField_c_of_type_JavaUtilArrayList.contains(paramFragment)) {
        break;
      }
      throw new IllegalStateException("Fragment already added: " + paramFragment);
      label175:
      paramFragment.a(((Integer)this.jdField_d_of_type_JavaUtilArrayList.remove(this.jdField_d_of_type_JavaUtilArrayList.size() - 1)).intValue(), this.jdField_a_of_type_AndroidSupportV4AppFragment);
      this.jdField_b_of_type_JavaUtilArrayList.set(paramFragment.jdField_f_of_type_Int, paramFragment);
    }
    this.jdField_c_of_type_JavaUtilArrayList.add(paramFragment);
    paramFragment.jdField_f_of_type_Boolean = true;
    paramFragment.jdField_g_of_type_Boolean = false;
    if ((paramFragment.p) && (paramFragment.q)) {
      this.jdField_d_of_type_Boolean = true;
    }
    if (paramBoolean) {
      b(paramFragment);
    }
  }
  
  public final void a(FragmentActivity paramFragmentActivity, n paramn, Fragment paramFragment)
  {
    if (this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity != null) {
      throw new IllegalStateException("Already attached");
    }
    this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity = paramFragmentActivity;
    this.jdField_a_of_type_N = paramn;
    this.jdField_a_of_type_AndroidSupportV4AppFragment = paramFragment;
  }
  
  public final void a(Menu paramMenu)
  {
    if (this.jdField_c_of_type_JavaUtilArrayList != null)
    {
      int j = 0;
      while (j < this.jdField_c_of_type_JavaUtilArrayList.size())
      {
        Fragment localFragment = (Fragment)this.jdField_c_of_type_JavaUtilArrayList.get(j);
        if (localFragment != null) {
          localFragment.a(paramMenu);
        }
        j += 1;
      }
    }
  }
  
  final void a(d paramd)
  {
    if (this.jdField_e_of_type_JavaUtilArrayList == null) {
      this.jdField_e_of_type_JavaUtilArrayList = new ArrayList();
    }
    this.jdField_e_of_type_JavaUtilArrayList.add(paramd);
    n();
  }
  
  public final void a(Runnable paramRunnable, boolean paramBoolean)
  {
    if (!paramBoolean) {
      m();
    }
    try
    {
      if (this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity == null) {
        throw new IllegalStateException("Activity has been destroyed");
      }
    }
    finally {}
    if (this.jdField_a_of_type_JavaUtilArrayList == null) {
      this.jdField_a_of_type_JavaUtilArrayList = new ArrayList();
    }
    this.jdField_a_of_type_JavaUtilArrayList.add(paramRunnable);
    if (this.jdField_a_of_type_JavaUtilArrayList.size() == 1)
    {
      this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.jdField_a_of_type_AndroidOsHandler.removeCallbacks(this.jdField_a_of_type_JavaLangRunnable);
      this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.jdField_a_of_type_AndroidOsHandler.post(this.jdField_a_of_type_JavaLangRunnable);
    }
  }
  
  public final boolean a()
  {
    if (this.jdField_c_of_type_Boolean) {
      throw new IllegalStateException("Recursive entry to executePendingTransactions");
    }
    if (Looper.myLooper() != this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.jdField_a_of_type_AndroidOsHandler.getLooper()) {
      throw new IllegalStateException("Must be called from main thread of process");
    }
    int k;
    for (boolean bool = false;; bool = true) {
      try
      {
        if ((this.jdField_a_of_type_JavaUtilArrayList == null) || (this.jdField_a_of_type_JavaUtilArrayList.size() == 0))
        {
          if (!this.jdField_g_of_type_Boolean) {
            break label276;
          }
          j = 0;
          int n;
          for (k = 0; j < this.jdField_b_of_type_JavaUtilArrayList.size(); k = n)
          {
            Fragment localFragment = (Fragment)this.jdField_b_of_type_JavaUtilArrayList.get(j);
            int m = k;
            if (localFragment != null)
            {
              m = k;
              if (localFragment.jdField_a_of_type_E != null) {
                n = k | localFragment.jdField_a_of_type_E.hasRunningLoaders();
              }
            }
            j += 1;
          }
        }
        k = this.jdField_a_of_type_JavaUtilArrayList.size();
        if ((this.jdField_a_of_type_ArrayOfJavaLangRunnable == null) || (this.jdField_a_of_type_ArrayOfJavaLangRunnable.length < k)) {
          this.jdField_a_of_type_ArrayOfJavaLangRunnable = new Runnable[k];
        }
        this.jdField_a_of_type_JavaUtilArrayList.toArray(this.jdField_a_of_type_ArrayOfJavaLangRunnable);
        this.jdField_a_of_type_JavaUtilArrayList.clear();
        this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.jdField_a_of_type_AndroidOsHandler.removeCallbacks(this.jdField_a_of_type_JavaLangRunnable);
        this.jdField_c_of_type_Boolean = true;
        int j = 0;
        while (j < k)
        {
          this.jdField_a_of_type_ArrayOfJavaLangRunnable[j].run();
          this.jdField_a_of_type_ArrayOfJavaLangRunnable[j] = null;
          j += 1;
        }
        this.jdField_c_of_type_Boolean = false;
      }
      finally {}
    }
    if (k == 0)
    {
      this.jdField_g_of_type_Boolean = false;
      a();
    }
    label276:
    return bool;
  }
  
  public final boolean a(Menu paramMenu)
  {
    if (this.jdField_c_of_type_JavaUtilArrayList != null)
    {
      int j = 0;
      for (boolean bool1 = false;; bool1 = bool2)
      {
        bool2 = bool1;
        if (j >= this.jdField_c_of_type_JavaUtilArrayList.size()) {
          break;
        }
        Fragment localFragment = (Fragment)this.jdField_c_of_type_JavaUtilArrayList.get(j);
        bool2 = bool1;
        if (localFragment != null)
        {
          bool2 = bool1;
          if (localFragment.a(paramMenu)) {
            bool2 = true;
          }
        }
        j += 1;
      }
    }
    boolean bool2 = false;
    return bool2;
  }
  
  public final boolean a(Menu paramMenu, MenuInflater paramMenuInflater)
  {
    int k = 0;
    Object localObject2 = null;
    Object localObject1 = null;
    int j;
    if (this.jdField_c_of_type_JavaUtilArrayList != null)
    {
      j = 0;
      boolean bool1 = false;
      for (;;)
      {
        localObject2 = localObject1;
        bool2 = bool1;
        if (j >= this.jdField_c_of_type_JavaUtilArrayList.size()) {
          break;
        }
        Fragment localFragment = (Fragment)this.jdField_c_of_type_JavaUtilArrayList.get(j);
        localObject2 = localObject1;
        bool2 = bool1;
        if (localFragment != null)
        {
          localObject2 = localObject1;
          bool2 = bool1;
          if (localFragment.a(paramMenu, paramMenuInflater))
          {
            bool2 = true;
            localObject2 = localObject1;
            if (localObject1 == null) {
              localObject2 = new ArrayList();
            }
            ((ArrayList)localObject2).add(localFragment);
          }
        }
        j += 1;
        bool1 = bool2;
        localObject1 = localObject2;
      }
    }
    boolean bool2 = false;
    if (this.jdField_f_of_type_JavaUtilArrayList != null)
    {
      j = k;
      while (j < this.jdField_f_of_type_JavaUtilArrayList.size())
      {
        paramMenu = (Fragment)this.jdField_f_of_type_JavaUtilArrayList.get(j);
        if ((localObject2 == null) || (!((ArrayList)localObject2).contains(paramMenu))) {
          paramMenu.onDestroyOptionsMenu();
        }
        j += 1;
      }
    }
    this.jdField_f_of_type_JavaUtilArrayList = ((ArrayList)localObject2);
    return bool2;
  }
  
  public final boolean a(MenuItem paramMenuItem)
  {
    boolean bool2 = false;
    boolean bool1 = bool2;
    int j;
    if (this.jdField_c_of_type_JavaUtilArrayList != null) {
      j = 0;
    }
    for (;;)
    {
      bool1 = bool2;
      if (j < this.jdField_c_of_type_JavaUtilArrayList.size())
      {
        Fragment localFragment = (Fragment)this.jdField_c_of_type_JavaUtilArrayList.get(j);
        if ((localFragment != null) && (localFragment.a(paramMenuItem))) {
          bool1 = true;
        }
      }
      else
      {
        return bool1;
      }
      j += 1;
    }
  }
  
  final boolean a(String paramString, int paramInt1, int paramInt2)
  {
    if (this.jdField_e_of_type_JavaUtilArrayList == null) {}
    int j;
    d locald;
    do
    {
      int k;
      do
      {
        do
        {
          return false;
          if ((paramString != null) || (paramInt1 >= 0) || ((paramInt2 & 0x1) != 0)) {
            break;
          }
          paramInt1 = this.jdField_e_of_type_JavaUtilArrayList.size() - 1;
        } while (paramInt1 < 0);
        ((d)this.jdField_e_of_type_JavaUtilArrayList.remove(paramInt1)).a(true);
        n();
        return true;
        j = -1;
        if ((paramString == null) && (paramInt1 < 0)) {
          break;
        }
        k = this.jdField_e_of_type_JavaUtilArrayList.size() - 1;
        while (k >= 0)
        {
          locald = (d)this.jdField_e_of_type_JavaUtilArrayList.get(k);
          if (((paramString != null) && (paramString.equals(locald.getName()))) || ((paramInt1 >= 0) && (paramInt1 == locald.jdField_h_of_type_Int))) {
            break;
          }
          k -= 1;
        }
      } while (k < 0);
      j = k;
      if ((paramInt2 & 0x1) != 0)
      {
        paramInt2 = k - 1;
        for (;;)
        {
          j = paramInt2;
          if (paramInt2 < 0) {
            break;
          }
          locald = (d)this.jdField_e_of_type_JavaUtilArrayList.get(paramInt2);
          if ((paramString == null) || (!paramString.equals(locald.getName())))
          {
            j = paramInt2;
            if (paramInt1 < 0) {
              break;
            }
            j = paramInt2;
            if (paramInt1 != locald.jdField_h_of_type_Int) {
              break;
            }
          }
          paramInt2 -= 1;
        }
      }
    } while (j == this.jdField_e_of_type_JavaUtilArrayList.size() - 1);
    paramString = new ArrayList();
    paramInt1 = this.jdField_e_of_type_JavaUtilArrayList.size() - 1;
    while (paramInt1 > j)
    {
      paramString.add(this.jdField_e_of_type_JavaUtilArrayList.remove(paramInt1));
      paramInt1 -= 1;
    }
    paramInt2 = paramString.size() - 1;
    paramInt1 = 0;
    label286:
    if (paramInt1 <= paramInt2)
    {
      if (jdField_a_of_type_Boolean) {
        new StringBuilder("Popping back stack state: ").append(paramString.get(paramInt1)).toString();
      }
      locald = (d)paramString.get(paramInt1);
      if (paramInt1 != paramInt2) {
        break label351;
      }
    }
    label351:
    for (boolean bool = true;; bool = false)
    {
      locald.a(bool);
      paramInt1 += 1;
      break label286;
      break;
    }
  }
  
  public final void addOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener paramOnBackStackChangedListener)
  {
    if (this.i == null) {
      this.i = new ArrayList();
    }
    this.i.add(paramOnBackStackChangedListener);
  }
  
  public final void b()
  {
    this.jdField_e_of_type_Boolean = false;
  }
  
  public final void b(Fragment paramFragment)
  {
    a(paramFragment, this.jdField_a_of_type_Int, 0, 0, false);
  }
  
  public final void b(Fragment paramFragment, int paramInt1, int paramInt2)
  {
    if (jdField_a_of_type_Boolean) {
      new StringBuilder("hide: ").append(paramFragment).toString();
    }
    if (!paramFragment.jdField_l_of_type_Boolean)
    {
      paramFragment.jdField_l_of_type_Boolean = true;
      if (paramFragment.jdField_b_of_type_AndroidViewView != null)
      {
        Animation localAnimation = a(paramFragment, paramInt1, true, paramInt2);
        if (localAnimation != null) {
          paramFragment.jdField_b_of_type_AndroidViewView.startAnimation(localAnimation);
        }
        paramFragment.jdField_b_of_type_AndroidViewView.setVisibility(8);
      }
      if ((paramFragment.jdField_f_of_type_Boolean) && (paramFragment.p) && (paramFragment.q)) {
        this.jdField_d_of_type_Boolean = true;
      }
      paramFragment.onHiddenChanged(true);
    }
  }
  
  public final boolean b(MenuItem paramMenuItem)
  {
    boolean bool2 = false;
    boolean bool1 = bool2;
    int j;
    if (this.jdField_c_of_type_JavaUtilArrayList != null) {
      j = 0;
    }
    for (;;)
    {
      bool1 = bool2;
      if (j < this.jdField_c_of_type_JavaUtilArrayList.size())
      {
        Fragment localFragment = (Fragment)this.jdField_c_of_type_JavaUtilArrayList.get(j);
        if ((localFragment != null) && (localFragment.b(paramMenuItem))) {
          bool1 = true;
        }
      }
      else
      {
        return bool1;
      }
      j += 1;
    }
  }
  
  public final FragmentTransaction beginTransaction()
  {
    return new d(this);
  }
  
  public final void c()
  {
    this.jdField_e_of_type_Boolean = false;
    b(1);
  }
  
  public final void c(Fragment paramFragment, int paramInt1, int paramInt2)
  {
    if (jdField_a_of_type_Boolean) {
      new StringBuilder("show: ").append(paramFragment).toString();
    }
    if (paramFragment.jdField_l_of_type_Boolean)
    {
      paramFragment.jdField_l_of_type_Boolean = false;
      if (paramFragment.jdField_b_of_type_AndroidViewView != null)
      {
        Animation localAnimation = a(paramFragment, paramInt1, true, paramInt2);
        if (localAnimation != null) {
          paramFragment.jdField_b_of_type_AndroidViewView.startAnimation(localAnimation);
        }
        paramFragment.jdField_b_of_type_AndroidViewView.setVisibility(0);
      }
      if ((paramFragment.jdField_f_of_type_Boolean) && (paramFragment.p) && (paramFragment.q)) {
        this.jdField_d_of_type_Boolean = true;
      }
      paramFragment.onHiddenChanged(false);
    }
  }
  
  public final void d()
  {
    this.jdField_e_of_type_Boolean = false;
    b(2);
  }
  
  public final void d(Fragment paramFragment, int paramInt1, int paramInt2)
  {
    if (jdField_a_of_type_Boolean) {
      new StringBuilder("detach: ").append(paramFragment).toString();
    }
    if (!paramFragment.m)
    {
      paramFragment.m = true;
      if (paramFragment.jdField_f_of_type_Boolean)
      {
        if (this.jdField_c_of_type_JavaUtilArrayList != null)
        {
          if (jdField_a_of_type_Boolean) {
            new StringBuilder("remove from detach: ").append(paramFragment).toString();
          }
          this.jdField_c_of_type_JavaUtilArrayList.remove(paramFragment);
        }
        if ((paramFragment.p) && (paramFragment.q)) {
          this.jdField_d_of_type_Boolean = true;
        }
        paramFragment.jdField_f_of_type_Boolean = false;
        a(paramFragment, 1, paramInt1, paramInt2, false);
      }
    }
  }
  
  public final void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    int k = 0;
    String str = paramString + "    ";
    int m;
    int j;
    if (this.jdField_b_of_type_JavaUtilArrayList != null)
    {
      m = this.jdField_b_of_type_JavaUtilArrayList.size();
      if (m > 0)
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("Active Fragments in ");
        paramPrintWriter.print(Integer.toHexString(System.identityHashCode(this)));
        paramPrintWriter.println(":");
        j = 0;
        while (j < m)
        {
          Fragment localFragment = (Fragment)this.jdField_b_of_type_JavaUtilArrayList.get(j);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(j);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(localFragment);
          if (localFragment != null) {
            localFragment.dump(str, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
          }
          j += 1;
        }
      }
    }
    if (this.jdField_c_of_type_JavaUtilArrayList != null)
    {
      m = this.jdField_c_of_type_JavaUtilArrayList.size();
      if (m > 0)
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Added Fragments:");
        j = 0;
        while (j < m)
        {
          paramFileDescriptor = (Fragment)this.jdField_c_of_type_JavaUtilArrayList.get(j);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(j);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(paramFileDescriptor.toString());
          j += 1;
        }
      }
    }
    if (this.jdField_f_of_type_JavaUtilArrayList != null)
    {
      m = this.jdField_f_of_type_JavaUtilArrayList.size();
      if (m > 0)
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Fragments Created Menus:");
        j = 0;
        while (j < m)
        {
          paramFileDescriptor = (Fragment)this.jdField_f_of_type_JavaUtilArrayList.get(j);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(j);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(paramFileDescriptor.toString());
          j += 1;
        }
      }
    }
    if (this.jdField_e_of_type_JavaUtilArrayList != null)
    {
      m = this.jdField_e_of_type_JavaUtilArrayList.size();
      if (m > 0)
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.println("Back Stack:");
        j = 0;
        while (j < m)
        {
          paramFileDescriptor = (d)this.jdField_e_of_type_JavaUtilArrayList.get(j);
          paramPrintWriter.print(paramString);
          paramPrintWriter.print("  #");
          paramPrintWriter.print(j);
          paramPrintWriter.print(": ");
          paramPrintWriter.println(paramFileDescriptor.toString());
          paramFileDescriptor.a(str, paramPrintWriter);
          j += 1;
        }
      }
    }
    try
    {
      if (this.jdField_g_of_type_JavaUtilArrayList != null)
      {
        m = this.jdField_g_of_type_JavaUtilArrayList.size();
        if (m > 0)
        {
          paramPrintWriter.print(paramString);
          paramPrintWriter.println("Back Stack Indices:");
          j = 0;
          while (j < m)
          {
            paramFileDescriptor = (d)this.jdField_g_of_type_JavaUtilArrayList.get(j);
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("  #");
            paramPrintWriter.print(j);
            paramPrintWriter.print(": ");
            paramPrintWriter.println(paramFileDescriptor);
            j += 1;
          }
        }
      }
      if ((this.h != null) && (this.h.size() > 0))
      {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mAvailBackStackIndices: ");
        paramPrintWriter.println(Arrays.toString(this.h.toArray()));
      }
      if (this.jdField_a_of_type_JavaUtilArrayList != null)
      {
        m = this.jdField_a_of_type_JavaUtilArrayList.size();
        if (m > 0)
        {
          paramPrintWriter.print(paramString);
          paramPrintWriter.println("Pending Actions:");
          j = k;
          while (j < m)
          {
            paramFileDescriptor = (Runnable)this.jdField_a_of_type_JavaUtilArrayList.get(j);
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("  #");
            paramPrintWriter.print(j);
            paramPrintWriter.print(": ");
            paramPrintWriter.println(paramFileDescriptor);
            j += 1;
          }
        }
      }
      paramPrintWriter.print(paramString);
    }
    finally {}
    paramPrintWriter.println("FragmentManager misc state:");
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("  mActivity=");
    paramPrintWriter.println(this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("  mContainer=");
    paramPrintWriter.println(this.jdField_a_of_type_N);
    if (this.jdField_a_of_type_AndroidSupportV4AppFragment != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mParent=");
      paramPrintWriter.println(this.jdField_a_of_type_AndroidSupportV4AppFragment);
    }
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("  mCurState=");
    paramPrintWriter.print(this.jdField_a_of_type_Int);
    paramPrintWriter.print(" mStateSaved=");
    paramPrintWriter.print(this.jdField_e_of_type_Boolean);
    paramPrintWriter.print(" mDestroyed=");
    paramPrintWriter.println(this.jdField_f_of_type_Boolean);
    if (this.jdField_d_of_type_Boolean)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mNeedMenuInvalidate=");
      paramPrintWriter.println(this.jdField_d_of_type_Boolean);
    }
    if (this.jdField_a_of_type_JavaLangString != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mNoTransactionsBecause=");
      paramPrintWriter.println(this.jdField_a_of_type_JavaLangString);
    }
    if ((this.jdField_d_of_type_JavaUtilArrayList != null) && (this.jdField_d_of_type_JavaUtilArrayList.size() > 0))
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("  mAvailIndices: ");
      paramPrintWriter.println(Arrays.toString(this.jdField_d_of_type_JavaUtilArrayList.toArray()));
    }
  }
  
  public final void e()
  {
    this.jdField_e_of_type_Boolean = false;
    b(4);
  }
  
  public final void e(Fragment paramFragment, int paramInt1, int paramInt2)
  {
    if (jdField_a_of_type_Boolean) {
      new StringBuilder("attach: ").append(paramFragment).toString();
    }
    if (paramFragment.m)
    {
      paramFragment.m = false;
      if (!paramFragment.jdField_f_of_type_Boolean)
      {
        if (this.jdField_c_of_type_JavaUtilArrayList == null) {
          this.jdField_c_of_type_JavaUtilArrayList = new ArrayList();
        }
        if (this.jdField_c_of_type_JavaUtilArrayList.contains(paramFragment)) {
          throw new IllegalStateException("Fragment already added: " + paramFragment);
        }
        if (jdField_a_of_type_Boolean) {
          new StringBuilder("add from attach: ").append(paramFragment).toString();
        }
        this.jdField_c_of_type_JavaUtilArrayList.add(paramFragment);
        paramFragment.jdField_f_of_type_Boolean = true;
        if ((paramFragment.p) && (paramFragment.q)) {
          this.jdField_d_of_type_Boolean = true;
        }
        a(paramFragment, this.jdField_a_of_type_Int, paramInt1, paramInt2, false);
      }
    }
  }
  
  public final boolean executePendingTransactions()
  {
    return a();
  }
  
  public final void f()
  {
    this.jdField_e_of_type_Boolean = false;
    b(5);
  }
  
  public final Fragment findFragmentById(int paramInt)
  {
    int j;
    Object localObject;
    if (this.jdField_c_of_type_JavaUtilArrayList != null)
    {
      j = this.jdField_c_of_type_JavaUtilArrayList.size() - 1;
      while (j >= 0)
      {
        localObject = (Fragment)this.jdField_c_of_type_JavaUtilArrayList.get(j);
        if ((localObject != null) && (((Fragment)localObject).jdField_j_of_type_Int == paramInt)) {
          return (Fragment)localObject;
        }
        j -= 1;
      }
    }
    if (this.jdField_b_of_type_JavaUtilArrayList != null)
    {
      j = this.jdField_b_of_type_JavaUtilArrayList.size() - 1;
      for (;;)
      {
        if (j < 0) {
          break label112;
        }
        Fragment localFragment = (Fragment)this.jdField_b_of_type_JavaUtilArrayList.get(j);
        if (localFragment != null)
        {
          localObject = localFragment;
          if (localFragment.jdField_j_of_type_Int == paramInt) {
            break;
          }
        }
        j -= 1;
      }
    }
    label112:
    return null;
  }
  
  public final Fragment findFragmentByTag(String paramString)
  {
    int j;
    Object localObject;
    if ((this.jdField_c_of_type_JavaUtilArrayList != null) && (paramString != null))
    {
      j = this.jdField_c_of_type_JavaUtilArrayList.size() - 1;
      while (j >= 0)
      {
        localObject = (Fragment)this.jdField_c_of_type_JavaUtilArrayList.get(j);
        if ((localObject != null) && (paramString.equals(((Fragment)localObject).jdField_b_of_type_JavaLangString))) {
          return (Fragment)localObject;
        }
        j -= 1;
      }
    }
    if ((this.jdField_b_of_type_JavaUtilArrayList != null) && (paramString != null))
    {
      j = this.jdField_b_of_type_JavaUtilArrayList.size() - 1;
      for (;;)
      {
        if (j < 0) {
          break label126;
        }
        Fragment localFragment = (Fragment)this.jdField_b_of_type_JavaUtilArrayList.get(j);
        if (localFragment != null)
        {
          localObject = localFragment;
          if (paramString.equals(localFragment.jdField_b_of_type_JavaLangString)) {
            break;
          }
        }
        j -= 1;
      }
    }
    label126:
    return null;
  }
  
  public final void g()
  {
    b(4);
  }
  
  public final FragmentManager.BackStackEntry getBackStackEntryAt(int paramInt)
  {
    return (FragmentManager.BackStackEntry)this.jdField_e_of_type_JavaUtilArrayList.get(paramInt);
  }
  
  public final int getBackStackEntryCount()
  {
    if (this.jdField_e_of_type_JavaUtilArrayList != null) {
      return this.jdField_e_of_type_JavaUtilArrayList.size();
    }
    return 0;
  }
  
  public final Fragment getFragment(Bundle paramBundle, String paramString)
  {
    int j = paramBundle.getInt(paramString, -1);
    if (j == -1) {
      paramBundle = null;
    }
    Fragment localFragment;
    do
    {
      return paramBundle;
      if (j >= this.jdField_b_of_type_JavaUtilArrayList.size()) {
        a(new IllegalStateException("Fragement no longer exists for key " + paramString + ": index " + j));
      }
      localFragment = (Fragment)this.jdField_b_of_type_JavaUtilArrayList.get(j);
      paramBundle = localFragment;
    } while (localFragment != null);
    a(new IllegalStateException("Fragement no longer exists for key " + paramString + ": index " + j));
    return localFragment;
  }
  
  public final void h()
  {
    this.jdField_e_of_type_Boolean = true;
    b(3);
  }
  
  public final void i()
  {
    b(2);
  }
  
  public final void j()
  {
    b(1);
  }
  
  public final void k()
  {
    this.jdField_f_of_type_Boolean = true;
    a();
    b(0);
    this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity = null;
    this.jdField_a_of_type_N = null;
    this.jdField_a_of_type_AndroidSupportV4AppFragment = null;
  }
  
  public final void l()
  {
    if (this.jdField_c_of_type_JavaUtilArrayList != null)
    {
      int j = 0;
      while (j < this.jdField_c_of_type_JavaUtilArrayList.size())
      {
        Fragment localFragment = (Fragment)this.jdField_c_of_type_JavaUtilArrayList.get(j);
        if (localFragment != null) {
          localFragment.d();
        }
        j += 1;
      }
    }
  }
  
  public final void popBackStack()
  {
    a(new q(this), false);
  }
  
  public final void popBackStack(int paramInt1, int paramInt2)
  {
    if (paramInt1 < 0) {
      throw new IllegalArgumentException("Bad id: " + paramInt1);
    }
    a(new s(this, paramInt1, paramInt2), false);
  }
  
  public final void popBackStack(String paramString, int paramInt)
  {
    a(new r(this, paramString, paramInt), false);
  }
  
  public final boolean popBackStackImmediate()
  {
    m();
    executePendingTransactions();
    Handler localHandler = this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.jdField_a_of_type_AndroidOsHandler;
    return a(null, -1, 0);
  }
  
  public final boolean popBackStackImmediate(int paramInt1, int paramInt2)
  {
    m();
    executePendingTransactions();
    if (paramInt1 < 0) {
      throw new IllegalArgumentException("Bad id: " + paramInt1);
    }
    Handler localHandler = this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.jdField_a_of_type_AndroidOsHandler;
    return a(null, paramInt1, paramInt2);
  }
  
  public final boolean popBackStackImmediate(String paramString, int paramInt)
  {
    m();
    executePendingTransactions();
    Handler localHandler = this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.jdField_a_of_type_AndroidOsHandler;
    return a(paramString, -1, paramInt);
  }
  
  public final void putFragment(Bundle paramBundle, String paramString, Fragment paramFragment)
  {
    if (paramFragment.jdField_f_of_type_Int < 0) {
      a(new IllegalStateException("Fragment " + paramFragment + " is not currently in the FragmentManager"));
    }
    paramBundle.putInt(paramString, paramFragment.jdField_f_of_type_Int);
  }
  
  public final void removeOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener paramOnBackStackChangedListener)
  {
    if (this.i != null) {
      this.i.remove(paramOnBackStackChangedListener);
    }
  }
  
  public final Fragment.SavedState saveFragmentInstanceState(Fragment paramFragment)
  {
    Object localObject2 = null;
    if (paramFragment.jdField_f_of_type_Int < 0) {
      a(new IllegalStateException("Fragment " + paramFragment + " is not currently in the FragmentManager"));
    }
    Object localObject1 = localObject2;
    if (paramFragment.d > 0)
    {
      paramFragment = a(paramFragment);
      localObject1 = localObject2;
      if (paramFragment != null) {
        localObject1 = new Fragment.SavedState(paramFragment);
      }
    }
    return (Fragment.SavedState)localObject1;
  }
  
  public final String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(128);
    localStringBuilder.append("FragmentManager{");
    localStringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    localStringBuilder.append(" in ");
    if (this.jdField_a_of_type_AndroidSupportV4AppFragment != null) {
      DebugUtils.buildShortClassTag(this.jdField_a_of_type_AndroidSupportV4AppFragment, localStringBuilder);
    }
    for (;;)
    {
      localStringBuilder.append("}}");
      return localStringBuilder.toString();
      DebugUtils.buildShortClassTag(this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity, localStringBuilder);
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/o.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */