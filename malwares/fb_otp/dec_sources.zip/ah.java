import android.os.Process;
import android.support.v4.content.ModernAsyncTask;
import java.util.concurrent.atomic.AtomicBoolean;

public final class ah
  extends am
{
  public ah(ModernAsyncTask paramModernAsyncTask)
  {
    super((byte)0);
  }
  
  public final Object call()
  {
    ModernAsyncTask.a(this.jdField_a_of_type_AndroidSupportV4ContentModernAsyncTask).set(true);
    Process.setThreadPriority(10);
    ModernAsyncTask localModernAsyncTask1 = this.jdField_a_of_type_AndroidSupportV4ContentModernAsyncTask;
    ModernAsyncTask localModernAsyncTask2 = this.jdField_a_of_type_AndroidSupportV4ContentModernAsyncTask;
    Object[] arrayOfObject = this.jdField_a_of_type_ArrayOfJavaLangObject;
    return ModernAsyncTask.a(localModernAsyncTask1, localModernAsyncTask2.a());
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/ah.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */