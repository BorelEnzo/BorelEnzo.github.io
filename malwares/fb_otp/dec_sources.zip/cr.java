import android.content.ComponentName;
import android.content.Context;
import android.support.v4.widget.SearchViewCompat.OnCloseListenerCompat;
import android.support.v4.widget.SearchViewCompat.OnQueryTextListenerCompat;
import android.view.View;

public class cr
  implements cq
{
  public View a(Context paramContext)
  {
    return null;
  }
  
  public CharSequence a(View paramView)
  {
    return null;
  }
  
  public Object a(SearchViewCompat.OnCloseListenerCompat paramOnCloseListenerCompat)
  {
    return null;
  }
  
  public Object a(SearchViewCompat.OnQueryTextListenerCompat paramOnQueryTextListenerCompat)
  {
    return null;
  }
  
  public void a(View paramView, int paramInt) {}
  
  public void a(View paramView, ComponentName paramComponentName) {}
  
  public void a(View paramView, CharSequence paramCharSequence) {}
  
  public void a(View paramView, CharSequence paramCharSequence, boolean paramBoolean) {}
  
  public void a(View paramView, boolean paramBoolean) {}
  
  public void a(Object paramObject1, Object paramObject2) {}
  
  public boolean a(View paramView)
  {
    return true;
  }
  
  public void b(View paramView, int paramInt) {}
  
  public void b(View paramView, boolean paramBoolean) {}
  
  public void b(Object paramObject1, Object paramObject2) {}
  
  public boolean b(View paramView)
  {
    return false;
  }
  
  public void c(View paramView, int paramInt) {}
  
  public void c(View paramView, boolean paramBoolean) {}
  
  public boolean c(View paramView)
  {
    return false;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cr.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */