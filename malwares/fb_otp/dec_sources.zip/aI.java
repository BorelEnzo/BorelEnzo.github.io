import android.content.Context;
import android.os.Handler;
import android.support.v4.view.MotionEventCompat;
import android.support.v4.view.VelocityTrackerCompat;
import android.view.GestureDetector.OnDoubleTapListener;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;

public final class aI
  implements aH
{
  private static final int jdField_e_of_type_Int = ;
  private static final int jdField_f_of_type_Int = ViewConfiguration.getTapTimeout();
  private static final int g = ViewConfiguration.getDoubleTapTimeout();
  private float jdField_a_of_type_Float;
  private int jdField_a_of_type_Int;
  private final Handler jdField_a_of_type_AndroidOsHandler;
  private GestureDetector.OnDoubleTapListener jdField_a_of_type_AndroidViewGestureDetector$OnDoubleTapListener;
  private final GestureDetector.OnGestureListener jdField_a_of_type_AndroidViewGestureDetector$OnGestureListener;
  private MotionEvent jdField_a_of_type_AndroidViewMotionEvent;
  private VelocityTracker jdField_a_of_type_AndroidViewVelocityTracker;
  private boolean jdField_a_of_type_Boolean;
  private float jdField_b_of_type_Float;
  private int jdField_b_of_type_Int;
  private MotionEvent jdField_b_of_type_AndroidViewMotionEvent;
  private boolean jdField_b_of_type_Boolean;
  private float jdField_c_of_type_Float;
  private int jdField_c_of_type_Int;
  private boolean jdField_c_of_type_Boolean;
  private float jdField_d_of_type_Float;
  private int jdField_d_of_type_Int;
  private boolean jdField_d_of_type_Boolean;
  private boolean jdField_e_of_type_Boolean;
  private boolean jdField_f_of_type_Boolean;
  
  public aI(Context paramContext, GestureDetector.OnGestureListener paramOnGestureListener, Handler paramHandler)
  {
    if (paramHandler != null) {}
    for (this.jdField_a_of_type_AndroidOsHandler = new aJ(this, paramHandler);; this.jdField_a_of_type_AndroidOsHandler = new aJ(this))
    {
      this.jdField_a_of_type_AndroidViewGestureDetector$OnGestureListener = paramOnGestureListener;
      if ((paramOnGestureListener instanceof GestureDetector.OnDoubleTapListener)) {
        this.jdField_a_of_type_AndroidViewGestureDetector$OnDoubleTapListener = ((GestureDetector.OnDoubleTapListener)paramOnGestureListener);
      }
      if (paramContext != null) {
        break;
      }
      throw new IllegalArgumentException("Context must not be null");
    }
    if (this.jdField_a_of_type_AndroidViewGestureDetector$OnGestureListener == null) {
      throw new IllegalArgumentException("OnGestureListener must not be null");
    }
    this.jdField_f_of_type_Boolean = true;
    paramContext = ViewConfiguration.get(paramContext);
    int i = paramContext.getScaledTouchSlop();
    int j = paramContext.getScaledDoubleTapSlop();
    this.jdField_c_of_type_Int = paramContext.getScaledMinimumFlingVelocity();
    this.jdField_d_of_type_Int = paramContext.getScaledMaximumFlingVelocity();
    this.jdField_a_of_type_Int = (i * i);
    this.jdField_b_of_type_Int = (j * j);
  }
  
  public final void a(GestureDetector.OnDoubleTapListener paramOnDoubleTapListener)
  {
    this.jdField_a_of_type_AndroidViewGestureDetector$OnDoubleTapListener = paramOnDoubleTapListener;
  }
  
  public final void a(boolean paramBoolean)
  {
    this.jdField_f_of_type_Boolean = paramBoolean;
  }
  
  public final boolean a()
  {
    return this.jdField_f_of_type_Boolean;
  }
  
  public final boolean a(MotionEvent paramMotionEvent)
  {
    int i1 = paramMotionEvent.getAction();
    if (this.jdField_a_of_type_AndroidViewVelocityTracker == null) {
      this.jdField_a_of_type_AndroidViewVelocityTracker = VelocityTracker.obtain();
    }
    this.jdField_a_of_type_AndroidViewVelocityTracker.addMovement(paramMotionEvent);
    int i;
    if ((i1 & 0xFF) == 6)
    {
      i = 1;
      if (i == 0) {
        break label127;
      }
    }
    int n;
    int m;
    float f1;
    float f2;
    float f4;
    float f3;
    label127:
    for (int k = MotionEventCompat.getActionIndex(paramMotionEvent);; k = -1)
    {
      n = MotionEventCompat.getPointerCount(paramMotionEvent);
      m = 0;
      f1 = 0.0F;
      for (f2 = 0.0F; m < n; f2 = f3)
      {
        f4 = f1;
        f3 = f2;
        if (k != m)
        {
          f3 = f2 + MotionEventCompat.getX(paramMotionEvent, m);
          f4 = f1 + MotionEventCompat.getY(paramMotionEvent, m);
        }
        m += 1;
        f1 = f4;
      }
      i = 0;
      break;
    }
    if (i != 0)
    {
      i = n - 1;
      f2 /= i;
      f1 /= i;
    }
    boolean bool2;
    MotionEvent localMotionEvent;
    Object localObject;
    label747:
    int j;
    switch (i1 & 0xFF)
    {
    case 4: 
    default: 
    case 5: 
    case 6: 
    case 0: 
    case 2: 
      do
      {
        do
        {
          return false;
          i = n;
          break;
          this.jdField_a_of_type_Float = f2;
          this.jdField_c_of_type_Float = f2;
          this.jdField_b_of_type_Float = f1;
          this.jdField_d_of_type_Float = f1;
          this.jdField_a_of_type_AndroidOsHandler.removeMessages(1);
          this.jdField_a_of_type_AndroidOsHandler.removeMessages(2);
          this.jdField_a_of_type_AndroidOsHandler.removeMessages(3);
          this.jdField_e_of_type_Boolean = false;
          this.jdField_c_of_type_Boolean = false;
          this.jdField_d_of_type_Boolean = false;
        } while (!this.jdField_b_of_type_Boolean);
        this.jdField_b_of_type_Boolean = false;
        return false;
        this.jdField_a_of_type_Float = f2;
        this.jdField_c_of_type_Float = f2;
        this.jdField_b_of_type_Float = f1;
        this.jdField_d_of_type_Float = f1;
        this.jdField_a_of_type_AndroidViewVelocityTracker.computeCurrentVelocity(1000, this.jdField_d_of_type_Int);
        k = MotionEventCompat.getActionIndex(paramMotionEvent);
        i = MotionEventCompat.getPointerId(paramMotionEvent, k);
        f1 = VelocityTrackerCompat.getXVelocity(this.jdField_a_of_type_AndroidViewVelocityTracker, i);
        f2 = VelocityTrackerCompat.getYVelocity(this.jdField_a_of_type_AndroidViewVelocityTracker, i);
        i = 0;
        while (i < n)
        {
          if (i != k)
          {
            m = MotionEventCompat.getPointerId(paramMotionEvent, i);
            f3 = VelocityTrackerCompat.getXVelocity(this.jdField_a_of_type_AndroidViewVelocityTracker, m);
            if (VelocityTrackerCompat.getYVelocity(this.jdField_a_of_type_AndroidViewVelocityTracker, m) * f2 + f3 * f1 < 0.0F)
            {
              this.jdField_a_of_type_AndroidViewVelocityTracker.clear();
              return false;
            }
          }
          i += 1;
        }
        if (this.jdField_a_of_type_AndroidViewGestureDetector$OnDoubleTapListener != null)
        {
          bool2 = this.jdField_a_of_type_AndroidOsHandler.hasMessages(3);
          if (bool2) {
            this.jdField_a_of_type_AndroidOsHandler.removeMessages(3);
          }
          if ((this.jdField_a_of_type_AndroidViewMotionEvent != null) && (this.jdField_b_of_type_AndroidViewMotionEvent != null) && (bool2))
          {
            localMotionEvent = this.jdField_a_of_type_AndroidViewMotionEvent;
            localObject = this.jdField_b_of_type_AndroidViewMotionEvent;
            if ((this.jdField_d_of_type_Boolean) && (paramMotionEvent.getEventTime() - ((MotionEvent)localObject).getEventTime() <= g))
            {
              i = (int)localMotionEvent.getX() - (int)paramMotionEvent.getX();
              k = (int)localMotionEvent.getY() - (int)paramMotionEvent.getY();
              if (k * k + i * i < this.jdField_b_of_type_Int)
              {
                i = 1;
                if (i == 0) {
                  break label747;
                }
                this.jdField_e_of_type_Boolean = true;
              }
            }
          }
        }
        for (boolean bool1 = this.jdField_a_of_type_AndroidViewGestureDetector$OnDoubleTapListener.onDoubleTap(this.jdField_a_of_type_AndroidViewMotionEvent) | false | this.jdField_a_of_type_AndroidViewGestureDetector$OnDoubleTapListener.onDoubleTapEvent(paramMotionEvent);; bool1 = false)
        {
          this.jdField_a_of_type_Float = f2;
          this.jdField_c_of_type_Float = f2;
          this.jdField_b_of_type_Float = f1;
          this.jdField_d_of_type_Float = f1;
          if (this.jdField_a_of_type_AndroidViewMotionEvent != null) {
            this.jdField_a_of_type_AndroidViewMotionEvent.recycle();
          }
          this.jdField_a_of_type_AndroidViewMotionEvent = MotionEvent.obtain(paramMotionEvent);
          this.jdField_c_of_type_Boolean = true;
          this.jdField_d_of_type_Boolean = true;
          this.jdField_a_of_type_Boolean = true;
          this.jdField_b_of_type_Boolean = false;
          if (this.jdField_f_of_type_Boolean)
          {
            this.jdField_a_of_type_AndroidOsHandler.removeMessages(2);
            this.jdField_a_of_type_AndroidOsHandler.sendEmptyMessageAtTime(2, this.jdField_a_of_type_AndroidViewMotionEvent.getDownTime() + jdField_f_of_type_Int + jdField_e_of_type_Int);
          }
          this.jdField_a_of_type_AndroidOsHandler.sendEmptyMessageAtTime(1, this.jdField_a_of_type_AndroidViewMotionEvent.getDownTime() + jdField_f_of_type_Int);
          return bool1 | this.jdField_a_of_type_AndroidViewGestureDetector$OnGestureListener.onDown(paramMotionEvent);
          bool1 = false;
          break;
          this.jdField_a_of_type_AndroidOsHandler.sendEmptyMessageDelayed(3, g);
        }
      } while (this.jdField_b_of_type_Boolean);
      f3 = this.jdField_a_of_type_Float - f2;
      f4 = this.jdField_b_of_type_Float - f1;
      if (this.jdField_e_of_type_Boolean) {
        return this.jdField_a_of_type_AndroidViewGestureDetector$OnDoubleTapListener.onDoubleTapEvent(paramMotionEvent) | false;
      }
      if (this.jdField_c_of_type_Boolean)
      {
        j = (int)(f2 - this.jdField_c_of_type_Float);
        k = (int)(f1 - this.jdField_d_of_type_Float);
        j = j * j + k * k;
        if (j <= this.jdField_a_of_type_Int) {
          break label1293;
        }
        bool2 = this.jdField_a_of_type_AndroidViewGestureDetector$OnGestureListener.onScroll(this.jdField_a_of_type_AndroidViewMotionEvent, paramMotionEvent, f3, f4);
        this.jdField_a_of_type_Float = f2;
        this.jdField_b_of_type_Float = f1;
        this.jdField_c_of_type_Boolean = false;
        this.jdField_a_of_type_AndroidOsHandler.removeMessages(3);
        this.jdField_a_of_type_AndroidOsHandler.removeMessages(1);
        this.jdField_a_of_type_AndroidOsHandler.removeMessages(2);
      }
      break;
    }
    for (;;)
    {
      if (j > this.jdField_a_of_type_Int) {
        this.jdField_d_of_type_Boolean = false;
      }
      return bool2;
      if ((Math.abs(f3) < 1.0F) && (Math.abs(f4) < 1.0F)) {
        break;
      }
      bool2 = this.jdField_a_of_type_AndroidViewGestureDetector$OnGestureListener.onScroll(this.jdField_a_of_type_AndroidViewMotionEvent, paramMotionEvent, f3, f4);
      this.jdField_a_of_type_Float = f2;
      this.jdField_b_of_type_Float = f1;
      return bool2;
      this.jdField_a_of_type_Boolean = false;
      localMotionEvent = MotionEvent.obtain(paramMotionEvent);
      if (this.jdField_e_of_type_Boolean) {
        bool2 = this.jdField_a_of_type_AndroidViewGestureDetector$OnDoubleTapListener.onDoubleTapEvent(paramMotionEvent) | false;
      }
      for (;;)
      {
        if (this.jdField_b_of_type_AndroidViewMotionEvent != null) {
          this.jdField_b_of_type_AndroidViewMotionEvent.recycle();
        }
        this.jdField_b_of_type_AndroidViewMotionEvent = localMotionEvent;
        if (this.jdField_a_of_type_AndroidViewVelocityTracker != null)
        {
          this.jdField_a_of_type_AndroidViewVelocityTracker.recycle();
          this.jdField_a_of_type_AndroidViewVelocityTracker = null;
        }
        this.jdField_e_of_type_Boolean = false;
        this.jdField_a_of_type_AndroidOsHandler.removeMessages(1);
        this.jdField_a_of_type_AndroidOsHandler.removeMessages(2);
        return bool2;
        if (this.jdField_b_of_type_Boolean)
        {
          this.jdField_a_of_type_AndroidOsHandler.removeMessages(3);
          this.jdField_b_of_type_Boolean = false;
          bool2 = false;
        }
        else if (this.jdField_c_of_type_Boolean)
        {
          bool2 = this.jdField_a_of_type_AndroidViewGestureDetector$OnGestureListener.onSingleTapUp(paramMotionEvent);
        }
        else
        {
          localObject = this.jdField_a_of_type_AndroidViewVelocityTracker;
          j = MotionEventCompat.getPointerId(paramMotionEvent, 0);
          ((VelocityTracker)localObject).computeCurrentVelocity(1000, this.jdField_d_of_type_Int);
          f1 = VelocityTrackerCompat.getYVelocity((VelocityTracker)localObject, j);
          f2 = VelocityTrackerCompat.getXVelocity((VelocityTracker)localObject, j);
          if ((Math.abs(f1) > this.jdField_c_of_type_Int) || (Math.abs(f2) > this.jdField_c_of_type_Int))
          {
            bool2 = this.jdField_a_of_type_AndroidViewGestureDetector$OnGestureListener.onFling(this.jdField_a_of_type_AndroidViewMotionEvent, paramMotionEvent, f2, f1);
            continue;
            this.jdField_a_of_type_AndroidOsHandler.removeMessages(1);
            this.jdField_a_of_type_AndroidOsHandler.removeMessages(2);
            this.jdField_a_of_type_AndroidOsHandler.removeMessages(3);
            this.jdField_a_of_type_AndroidViewVelocityTracker.recycle();
            this.jdField_a_of_type_AndroidViewVelocityTracker = null;
            this.jdField_e_of_type_Boolean = false;
            this.jdField_a_of_type_Boolean = false;
            this.jdField_c_of_type_Boolean = false;
            this.jdField_d_of_type_Boolean = false;
            if (!this.jdField_b_of_type_Boolean) {
              break;
            }
            this.jdField_b_of_type_Boolean = false;
            return false;
          }
          bool2 = false;
        }
      }
      label1293:
      bool2 = false;
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/aI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */