import android.animation.ValueAnimator;
import android.graphics.Paint;
import android.view.View;

public class bk
  extends bj
{
  final long a()
  {
    return ValueAnimator.getFrameDelay();
  }
  
  public final void a(View paramView, int paramInt, Paint paramPaint)
  {
    paramView.setLayerType(paramInt, paramPaint);
  }
  
  public final int c(View paramView)
  {
    return paramView.getLayerType();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bk.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */