import android.database.DataSetObserver;
import android.support.v4.widget.CursorAdapter;

public final class cg
  extends DataSetObserver
{
  private cg(CursorAdapter paramCursorAdapter) {}
  
  public final void onChanged()
  {
    this.a.mDataValid = true;
    this.a.notifyDataSetChanged();
  }
  
  public final void onInvalidated()
  {
    this.a.mDataValid = false;
    this.a.notifyDataSetInvalidated();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */