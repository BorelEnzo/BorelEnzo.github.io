import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;

public final class eh
{
  LocationListener jdField_a_of_type_AndroidLocationLocationListener = new ei(this);
  LocationManager jdField_a_of_type_AndroidLocationLocationManager;
  ek jdField_a_of_type_Ek;
  boolean jdField_a_of_type_Boolean = false;
  LocationListener jdField_b_of_type_AndroidLocationLocationListener = new ej(this);
  boolean jdField_b_of_type_Boolean = false;
  
  public final boolean a(Context paramContext, ek paramek)
  {
    this.jdField_a_of_type_Ek = paramek;
    if (this.jdField_a_of_type_AndroidLocationLocationManager == null) {
      this.jdField_a_of_type_AndroidLocationLocationManager = ((LocationManager)paramContext.getSystemService("location"));
    }
    try
    {
      this.jdField_a_of_type_Boolean = this.jdField_a_of_type_AndroidLocationLocationManager.isProviderEnabled("gps");
      try
      {
        this.jdField_b_of_type_Boolean = this.jdField_a_of_type_AndroidLocationLocationManager.isProviderEnabled("network");
        if ((!this.jdField_a_of_type_Boolean) && (!this.jdField_b_of_type_Boolean)) {
          return false;
        }
        this.jdField_a_of_type_AndroidLocationLocationManager.removeUpdates(this.jdField_a_of_type_AndroidLocationLocationListener);
        this.jdField_a_of_type_AndroidLocationLocationManager.removeUpdates(this.jdField_b_of_type_AndroidLocationLocationListener);
        if (this.jdField_a_of_type_Boolean)
        {
          paramContext = this.jdField_a_of_type_AndroidLocationLocationManager.getLastKnownLocation("gps");
          if (this.jdField_b_of_type_Boolean)
          {
            paramek = this.jdField_a_of_type_AndroidLocationLocationManager.getLastKnownLocation("network");
            if ((paramContext != null) && (paramek != null)) {
              if (paramContext.getTime() > paramek.getTime()) {
                this.jdField_a_of_type_Ek.a(paramContext);
              }
            }
            for (;;)
            {
              return true;
              this.jdField_a_of_type_Ek.a(paramek);
              continue;
              if (paramContext != null) {
                this.jdField_a_of_type_Ek.a(paramContext);
              } else if (paramek != null) {
                this.jdField_a_of_type_Ek.a(paramek);
              } else {
                this.jdField_a_of_type_Ek.a(null);
              }
            }
          }
        }
      }
      catch (Exception paramContext)
      {
        for (;;) {}
      }
    }
    catch (Exception paramContext)
    {
      for (;;)
      {
        continue;
        paramek = null;
        continue;
        paramContext = null;
      }
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/eh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */