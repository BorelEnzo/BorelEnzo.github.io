import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

final class dp
  implements DialogInterface.OnClickListener
{
  dp(do paramdo) {}
  
  public final void onClick(DialogInterface paramDialogInterface, int paramInt) {}
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/dp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */