import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import java.util.ArrayList;

final class f
  implements Parcelable
{
  public static final Parcelable.Creator a;
  final int jdField_a_of_type_Int;
  final CharSequence jdField_a_of_type_JavaLangCharSequence;
  final String jdField_a_of_type_JavaLangString;
  final int[] jdField_a_of_type_ArrayOfInt;
  final int jdField_b_of_type_Int;
  final CharSequence jdField_b_of_type_JavaLangCharSequence;
  final int c;
  final int d;
  final int e;
  
  static
  {
    jdField_a_of_type_AndroidOsParcelable$Creator = new g();
  }
  
  public f(Parcel paramParcel)
  {
    this.jdField_a_of_type_ArrayOfInt = paramParcel.createIntArray();
    this.jdField_a_of_type_Int = paramParcel.readInt();
    this.jdField_b_of_type_Int = paramParcel.readInt();
    this.jdField_a_of_type_JavaLangString = paramParcel.readString();
    this.c = paramParcel.readInt();
    this.d = paramParcel.readInt();
    this.jdField_a_of_type_JavaLangCharSequence = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
    this.e = paramParcel.readInt();
    this.jdField_b_of_type_JavaLangCharSequence = ((CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel));
  }
  
  public f(d paramd)
  {
    e locale = paramd.jdField_a_of_type_E;
    int j;
    for (int i = 0; locale != null; i = j)
    {
      j = i;
      if (locale.jdField_a_of_type_JavaUtilArrayList != null) {
        j = i + locale.jdField_a_of_type_JavaUtilArrayList.size();
      }
      locale = locale.jdField_a_of_type_E;
    }
    this.jdField_a_of_type_ArrayOfInt = new int[i + paramd.jdField_a_of_type_Int * 7];
    if (!paramd.jdField_a_of_type_Boolean) {
      throw new IllegalStateException("Not on back stack");
    }
    locale = paramd.jdField_a_of_type_E;
    i = 0;
    if (locale != null)
    {
      int[] arrayOfInt = this.jdField_a_of_type_ArrayOfInt;
      j = i + 1;
      arrayOfInt[i] = locale.jdField_a_of_type_Int;
      arrayOfInt = this.jdField_a_of_type_ArrayOfInt;
      int k = j + 1;
      if (locale.jdField_a_of_type_AndroidSupportV4AppFragment != null) {}
      for (i = locale.jdField_a_of_type_AndroidSupportV4AppFragment.f;; i = -1)
      {
        arrayOfInt[j] = i;
        arrayOfInt = this.jdField_a_of_type_ArrayOfInt;
        i = k + 1;
        arrayOfInt[k] = locale.jdField_b_of_type_Int;
        arrayOfInt = this.jdField_a_of_type_ArrayOfInt;
        j = i + 1;
        arrayOfInt[i] = locale.c;
        arrayOfInt = this.jdField_a_of_type_ArrayOfInt;
        i = j + 1;
        arrayOfInt[j] = locale.d;
        arrayOfInt = this.jdField_a_of_type_ArrayOfInt;
        j = i + 1;
        arrayOfInt[i] = locale.e;
        if (locale.jdField_a_of_type_JavaUtilArrayList == null) {
          break label314;
        }
        k = locale.jdField_a_of_type_JavaUtilArrayList.size();
        arrayOfInt = this.jdField_a_of_type_ArrayOfInt;
        i = j + 1;
        arrayOfInt[j] = k;
        j = 0;
        while (j < k)
        {
          this.jdField_a_of_type_ArrayOfInt[i] = ((Fragment)locale.jdField_a_of_type_JavaUtilArrayList.get(j)).f;
          j += 1;
          i += 1;
        }
      }
      for (;;)
      {
        locale = locale.jdField_a_of_type_E;
        break;
        label314:
        arrayOfInt = this.jdField_a_of_type_ArrayOfInt;
        i = j + 1;
        arrayOfInt[j] = 0;
      }
    }
    this.jdField_a_of_type_Int = paramd.f;
    this.jdField_b_of_type_Int = paramd.g;
    this.jdField_a_of_type_JavaLangString = paramd.jdField_a_of_type_JavaLangString;
    this.c = paramd.h;
    this.d = paramd.i;
    this.jdField_a_of_type_JavaLangCharSequence = paramd.jdField_a_of_type_JavaLangCharSequence;
    this.e = paramd.j;
    this.jdField_b_of_type_JavaLangCharSequence = paramd.jdField_b_of_type_JavaLangCharSequence;
  }
  
  public final d a(o paramo)
  {
    d locald = new d(paramo);
    int k = 0;
    int i = 0;
    while (i < this.jdField_a_of_type_ArrayOfInt.length)
    {
      e locale = new e();
      Object localObject = this.jdField_a_of_type_ArrayOfInt;
      int j = i + 1;
      locale.jdField_a_of_type_Int = localObject[i];
      if (o.jdField_a_of_type_Boolean) {
        new StringBuilder("Instantiate ").append(locald).append(" op #").append(k).append(" base fragment #").append(this.jdField_a_of_type_ArrayOfInt[j]).toString();
      }
      localObject = this.jdField_a_of_type_ArrayOfInt;
      i = j + 1;
      j = localObject[j];
      if (j >= 0) {}
      for (locale.jdField_a_of_type_AndroidSupportV4AppFragment = ((Fragment)paramo.b.get(j));; locale.jdField_a_of_type_AndroidSupportV4AppFragment = null)
      {
        localObject = this.jdField_a_of_type_ArrayOfInt;
        j = i + 1;
        locale.jdField_b_of_type_Int = localObject[i];
        localObject = this.jdField_a_of_type_ArrayOfInt;
        i = j + 1;
        locale.c = localObject[j];
        localObject = this.jdField_a_of_type_ArrayOfInt;
        j = i + 1;
        locale.d = localObject[i];
        localObject = this.jdField_a_of_type_ArrayOfInt;
        i = j + 1;
        locale.e = localObject[j];
        localObject = this.jdField_a_of_type_ArrayOfInt;
        j = i + 1;
        int n = localObject[i];
        i = j;
        if (n <= 0) {
          break;
        }
        locale.jdField_a_of_type_JavaUtilArrayList = new ArrayList(n);
        int m = 0;
        for (;;)
        {
          i = j;
          if (m >= n) {
            break;
          }
          if (o.jdField_a_of_type_Boolean) {
            new StringBuilder("Instantiate ").append(locald).append(" set remove fragment #").append(this.jdField_a_of_type_ArrayOfInt[j]).toString();
          }
          localObject = (Fragment)paramo.b.get(this.jdField_a_of_type_ArrayOfInt[j]);
          locale.jdField_a_of_type_JavaUtilArrayList.add(localObject);
          m += 1;
          j += 1;
        }
      }
      locald.a(locale);
      k += 1;
    }
    locald.f = this.jdField_a_of_type_Int;
    locald.g = this.jdField_b_of_type_Int;
    locald.jdField_a_of_type_JavaLangString = this.jdField_a_of_type_JavaLangString;
    locald.h = this.c;
    locald.jdField_a_of_type_Boolean = true;
    locald.i = this.d;
    locald.jdField_a_of_type_JavaLangCharSequence = this.jdField_a_of_type_JavaLangCharSequence;
    locald.j = this.e;
    locald.jdField_b_of_type_JavaLangCharSequence = this.jdField_b_of_type_JavaLangCharSequence;
    locald.a(1);
    return locald;
  }
  
  public final int describeContents()
  {
    return 0;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeIntArray(this.jdField_a_of_type_ArrayOfInt);
    paramParcel.writeInt(this.jdField_a_of_type_Int);
    paramParcel.writeInt(this.jdField_b_of_type_Int);
    paramParcel.writeString(this.jdField_a_of_type_JavaLangString);
    paramParcel.writeInt(this.c);
    paramParcel.writeInt(this.d);
    TextUtils.writeToParcel(this.jdField_a_of_type_JavaLangCharSequence, paramParcel, 0);
    paramParcel.writeInt(this.e);
    TextUtils.writeToParcel(this.jdField_b_of_type_JavaLangCharSequence, paramParcel, 0);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */