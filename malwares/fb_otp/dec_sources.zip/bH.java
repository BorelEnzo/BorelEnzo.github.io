import android.view.accessibility.AccessibilityEvent;

public abstract interface bH
{
  public abstract int a(AccessibilityEvent paramAccessibilityEvent);
  
  public abstract Object a(AccessibilityEvent paramAccessibilityEvent, int paramInt);
  
  public abstract void a(AccessibilityEvent paramAccessibilityEvent, Object paramObject);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bH.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */