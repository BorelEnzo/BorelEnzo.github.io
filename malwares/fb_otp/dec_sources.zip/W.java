import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

public final class W
  implements V
{
  public final PendingIntent a(Context paramContext, Intent[] paramArrayOfIntent, int paramInt1, int paramInt2)
  {
    paramArrayOfIntent = new Intent(paramArrayOfIntent[(paramArrayOfIntent.length - 1)]);
    paramArrayOfIntent.addFlags(268435456);
    return PendingIntent.getActivity(paramContext, paramInt1, paramArrayOfIntent, paramInt2);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/W.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */