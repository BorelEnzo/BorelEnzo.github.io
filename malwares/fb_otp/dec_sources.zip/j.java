import android.os.Handler;
import android.os.Message;
import android.support.v4.app.FragmentActivity;

public final class j
  extends Handler
{
  public j(FragmentActivity paramFragmentActivity) {}
  
  public final void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    default: 
      super.handleMessage(paramMessage);
    case 1: 
      do
      {
        return;
      } while (!this.a.c);
      this.a.a(false);
      return;
    }
    this.a.onResumeFragments();
    this.a.a.a();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/j.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */