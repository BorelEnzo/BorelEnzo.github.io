import android.view.accessibility.AccessibilityManager.AccessibilityStateChangeListener;

final class bN
  implements AccessibilityManager.AccessibilityStateChangeListener
{
  bN(bO parambO) {}
  
  public final void onAccessibilityStateChanged(boolean paramBoolean)
  {
    this.a.a(paramBoolean);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bN.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */