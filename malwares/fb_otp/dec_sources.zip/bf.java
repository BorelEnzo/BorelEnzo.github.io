import android.view.VelocityTracker;

public final class bf
  implements bh
{
  public final float a(VelocityTracker paramVelocityTracker, int paramInt)
  {
    return paramVelocityTracker.getXVelocity();
  }
  
  public final float b(VelocityTracker paramVelocityTracker, int paramInt)
  {
    return paramVelocityTracker.getYVelocity();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */