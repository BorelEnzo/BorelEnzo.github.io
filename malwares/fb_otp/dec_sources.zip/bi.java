import android.graphics.Paint;
import android.os.Bundle;
import android.support.v4.view.AccessibilityDelegateCompat;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.v4.view.accessibility.AccessibilityNodeProviderCompat;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;

public class bi
  implements bo
{
  public int a(View paramView)
  {
    return 2;
  }
  
  long a()
  {
    return 10L;
  }
  
  public AccessibilityNodeProviderCompat a(View paramView)
  {
    return null;
  }
  
  public void a(View paramView)
  {
    paramView.postInvalidateDelayed(a());
  }
  
  public void a(View paramView, int paramInt) {}
  
  public void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    paramView.postInvalidateDelayed(a(), paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public void a(View paramView, int paramInt, Paint paramPaint) {}
  
  public void a(View paramView, AccessibilityDelegateCompat paramAccessibilityDelegateCompat) {}
  
  public void a(View paramView, AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat) {}
  
  public void a(View paramView, AccessibilityEvent paramAccessibilityEvent) {}
  
  public void a(View paramView, Runnable paramRunnable)
  {
    paramView.postDelayed(paramRunnable, a());
  }
  
  public void a(View paramView, Runnable paramRunnable, long paramLong)
  {
    paramView.postDelayed(paramRunnable, a() + paramLong);
  }
  
  public void a(View paramView, boolean paramBoolean) {}
  
  public boolean a(View paramView)
  {
    return false;
  }
  
  public boolean a(View paramView, int paramInt)
  {
    return false;
  }
  
  public boolean a(View paramView, int paramInt, Bundle paramBundle)
  {
    return false;
  }
  
  public int b(View paramView)
  {
    return 0;
  }
  
  public void b(View paramView, int paramInt) {}
  
  public void b(View paramView, AccessibilityEvent paramAccessibilityEvent) {}
  
  public boolean b(View paramView, int paramInt)
  {
    return false;
  }
  
  public int c(View paramView)
  {
    return 0;
  }
  
  public void c(View paramView, int paramInt) {}
  
  public int d(View paramView)
  {
    return 0;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bi.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */