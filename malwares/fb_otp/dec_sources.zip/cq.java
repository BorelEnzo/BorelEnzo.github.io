import android.content.ComponentName;
import android.content.Context;
import android.support.v4.widget.SearchViewCompat.OnCloseListenerCompat;
import android.support.v4.widget.SearchViewCompat.OnQueryTextListenerCompat;
import android.view.View;

public abstract interface cq
{
  public abstract View a(Context paramContext);
  
  public abstract CharSequence a(View paramView);
  
  public abstract Object a(SearchViewCompat.OnCloseListenerCompat paramOnCloseListenerCompat);
  
  public abstract Object a(SearchViewCompat.OnQueryTextListenerCompat paramOnQueryTextListenerCompat);
  
  public abstract void a(View paramView, int paramInt);
  
  public abstract void a(View paramView, ComponentName paramComponentName);
  
  public abstract void a(View paramView, CharSequence paramCharSequence);
  
  public abstract void a(View paramView, CharSequence paramCharSequence, boolean paramBoolean);
  
  public abstract void a(View paramView, boolean paramBoolean);
  
  public abstract void a(Object paramObject1, Object paramObject2);
  
  public abstract boolean a(View paramView);
  
  public abstract void b(View paramView, int paramInt);
  
  public abstract void b(View paramView, boolean paramBoolean);
  
  public abstract void b(Object paramObject1, Object paramObject2);
  
  public abstract boolean b(View paramView);
  
  public abstract void c(View paramView, int paramInt);
  
  public abstract void c(View paramView, boolean paramBoolean);
  
  public abstract boolean c(View paramView);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */