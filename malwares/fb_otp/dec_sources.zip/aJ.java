import android.os.Handler;
import android.os.Message;
import android.view.GestureDetector.OnDoubleTapListener;
import android.view.GestureDetector.OnGestureListener;

final class aJ
  extends Handler
{
  aJ(aI paramaI) {}
  
  aJ(aI paramaI, Handler paramHandler)
  {
    super(paramHandler.getLooper());
  }
  
  public final void handleMessage(Message paramMessage)
  {
    switch (paramMessage.what)
    {
    default: 
      throw new RuntimeException("Unknown message " + paramMessage);
    case 1: 
      aI.a(this.a).onShowPress(aI.a(this.a));
    }
    do
    {
      return;
      aI.a(this.a);
      return;
    } while ((aI.a(this.a) == null) || (aI.a(this.a)));
    aI.a(this.a).onSingleTapConfirmed(aI.a(this.a));
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/aJ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */