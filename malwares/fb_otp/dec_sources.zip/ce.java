import android.os.Parcelable;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.view.View;
import java.util.Collections;
import java.util.List;

public class ce
  implements cc
{
  public int a(Object paramObject)
  {
    return 0;
  }
  
  public Parcelable a(Object paramObject)
  {
    return null;
  }
  
  public AccessibilityNodeInfoCompat a(Object paramObject)
  {
    return null;
  }
  
  public CharSequence a(Object paramObject)
  {
    return null;
  }
  
  public Object a()
  {
    return null;
  }
  
  public Object a(Object paramObject)
  {
    return null;
  }
  
  public List a(Object paramObject)
  {
    return Collections.emptyList();
  }
  
  public void a(Object paramObject) {}
  
  public void a(Object paramObject, int paramInt) {}
  
  public void a(Object paramObject, Parcelable paramParcelable) {}
  
  public void a(Object paramObject, View paramView) {}
  
  public void a(Object paramObject, View paramView, int paramInt) {}
  
  public void a(Object paramObject, CharSequence paramCharSequence) {}
  
  public void a(Object paramObject, boolean paramBoolean) {}
  
  public boolean a(Object paramObject)
  {
    return false;
  }
  
  public int b(Object paramObject)
  {
    return 0;
  }
  
  public CharSequence b(Object paramObject)
  {
    return null;
  }
  
  public void b(Object paramObject, int paramInt) {}
  
  public void b(Object paramObject, CharSequence paramCharSequence) {}
  
  public void b(Object paramObject, boolean paramBoolean) {}
  
  public boolean b(Object paramObject)
  {
    return false;
  }
  
  public int c(Object paramObject)
  {
    return 0;
  }
  
  public CharSequence c(Object paramObject)
  {
    return null;
  }
  
  public void c(Object paramObject, int paramInt) {}
  
  public void c(Object paramObject, CharSequence paramCharSequence) {}
  
  public void c(Object paramObject, boolean paramBoolean) {}
  
  public boolean c(Object paramObject)
  {
    return false;
  }
  
  public int d(Object paramObject)
  {
    return 0;
  }
  
  public void d(Object paramObject, int paramInt) {}
  
  public void d(Object paramObject, boolean paramBoolean) {}
  
  public boolean d(Object paramObject)
  {
    return false;
  }
  
  public int e(Object paramObject)
  {
    return 0;
  }
  
  public void e(Object paramObject, int paramInt) {}
  
  public void e(Object paramObject, boolean paramBoolean) {}
  
  public boolean e(Object paramObject)
  {
    return false;
  }
  
  public int f(Object paramObject)
  {
    return 0;
  }
  
  public void f(Object paramObject, int paramInt) {}
  
  public int g(Object paramObject)
  {
    return 0;
  }
  
  public void g(Object paramObject, int paramInt) {}
  
  public int h(Object paramObject)
  {
    return 0;
  }
  
  public void h(Object paramObject, int paramInt) {}
  
  public int i(Object paramObject)
  {
    return 0;
  }
  
  public void i(Object paramObject, int paramInt) {}
  
  public int j(Object paramObject)
  {
    return 0;
  }
  
  public void j(Object paramObject, int paramInt) {}
  
  public int k(Object paramObject)
  {
    return 0;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/ce.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */