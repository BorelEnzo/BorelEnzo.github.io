import android.support.v4.app.ShareCompat.IntentBuilder;
import android.view.MenuItem;

public class R
  implements Q
{
  private static void a(StringBuilder paramStringBuilder, CharSequence paramCharSequence, int paramInt)
  {
    int i = 0;
    if (i < paramInt)
    {
      char c = paramCharSequence.charAt(i);
      if (c == '<') {
        paramStringBuilder.append("&lt;");
      }
      for (;;)
      {
        i += 1;
        break;
        if (c == '>')
        {
          paramStringBuilder.append("&gt;");
        }
        else if (c == '&')
        {
          paramStringBuilder.append("&amp;");
        }
        else if ((c > '~') || (c < ' '))
        {
          paramStringBuilder.append("&#" + c + ";");
        }
        else if (c == ' ')
        {
          while ((i + 1 < paramInt) && (paramCharSequence.charAt(i + 1) == ' '))
          {
            paramStringBuilder.append("&nbsp;");
            i += 1;
          }
          paramStringBuilder.append(' ');
        }
        else
        {
          paramStringBuilder.append(c);
        }
      }
    }
  }
  
  public String a(CharSequence paramCharSequence)
  {
    StringBuilder localStringBuilder = new StringBuilder();
    a(localStringBuilder, paramCharSequence, paramCharSequence.length());
    return localStringBuilder.toString();
  }
  
  public void a(MenuItem paramMenuItem, ShareCompat.IntentBuilder paramIntentBuilder)
  {
    paramMenuItem.setIntent(paramIntentBuilder.createChooserIntent());
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/R.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */