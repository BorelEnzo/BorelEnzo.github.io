import android.graphics.Rect;
import android.os.Bundle;
import android.view.View;
import java.util.List;

public abstract interface bQ
{
  public abstract int a(Object paramObject);
  
  public abstract CharSequence a(Object paramObject);
  
  public abstract Object a();
  
  public abstract Object a(View paramView);
  
  public abstract Object a(View paramView, int paramInt);
  
  public abstract Object a(Object paramObject);
  
  public abstract Object a(Object paramObject, int paramInt);
  
  public abstract List a(Object paramObject, String paramString);
  
  public abstract void a(Object paramObject);
  
  public abstract void a(Object paramObject, int paramInt);
  
  public abstract void a(Object paramObject, Rect paramRect);
  
  public abstract void a(Object paramObject, View paramView);
  
  public abstract void a(Object paramObject, View paramView, int paramInt);
  
  public abstract void a(Object paramObject, CharSequence paramCharSequence);
  
  public abstract void a(Object paramObject, boolean paramBoolean);
  
  public abstract boolean a(Object paramObject);
  
  public abstract boolean a(Object paramObject, int paramInt);
  
  public abstract boolean a(Object paramObject, int paramInt, Bundle paramBundle);
  
  public abstract int b(Object paramObject);
  
  public abstract CharSequence b(Object paramObject);
  
  public abstract Object b(Object paramObject);
  
  public abstract Object b(Object paramObject, int paramInt);
  
  public abstract void b(Object paramObject, int paramInt);
  
  public abstract void b(Object paramObject, Rect paramRect);
  
  public abstract void b(Object paramObject, View paramView);
  
  public abstract void b(Object paramObject, View paramView, int paramInt);
  
  public abstract void b(Object paramObject, CharSequence paramCharSequence);
  
  public abstract void b(Object paramObject, boolean paramBoolean);
  
  public abstract boolean b(Object paramObject);
  
  public abstract int c(Object paramObject);
  
  public abstract CharSequence c(Object paramObject);
  
  public abstract Object c(Object paramObject, int paramInt);
  
  public abstract void c(Object paramObject, Rect paramRect);
  
  public abstract void c(Object paramObject, View paramView);
  
  public abstract void c(Object paramObject, View paramView, int paramInt);
  
  public abstract void c(Object paramObject, CharSequence paramCharSequence);
  
  public abstract void c(Object paramObject, boolean paramBoolean);
  
  public abstract boolean c(Object paramObject);
  
  public abstract int d(Object paramObject);
  
  public abstract CharSequence d(Object paramObject);
  
  public abstract void d(Object paramObject, Rect paramRect);
  
  public abstract void d(Object paramObject, CharSequence paramCharSequence);
  
  public abstract void d(Object paramObject, boolean paramBoolean);
  
  public abstract boolean d(Object paramObject);
  
  public abstract void e(Object paramObject, boolean paramBoolean);
  
  public abstract boolean e(Object paramObject);
  
  public abstract void f(Object paramObject, boolean paramBoolean);
  
  public abstract boolean f(Object paramObject);
  
  public abstract void g(Object paramObject, boolean paramBoolean);
  
  public abstract boolean g(Object paramObject);
  
  public abstract void h(Object paramObject, boolean paramBoolean);
  
  public abstract boolean h(Object paramObject);
  
  public abstract void i(Object paramObject, boolean paramBoolean);
  
  public abstract boolean i(Object paramObject);
  
  public abstract void j(Object paramObject, boolean paramBoolean);
  
  public abstract boolean j(Object paramObject);
  
  public abstract void k(Object paramObject, boolean paramBoolean);
  
  public abstract boolean k(Object paramObject);
  
  public abstract void l(Object paramObject, boolean paramBoolean);
  
  public abstract boolean l(Object paramObject);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bQ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */