import android.app.Notification;
import android.app.Notification.BigPictureStyle;
import android.app.Notification.BigTextStyle;
import android.app.Notification.Builder;
import android.app.PendingIntent;
import android.graphics.Bitmap;
import android.support.v4.app.NotificationCompat.Action;
import android.support.v4.app.NotificationCompat.BigPictureStyle;
import android.support.v4.app.NotificationCompat.BigTextStyle;
import android.support.v4.app.NotificationCompat.Builder;
import android.support.v4.app.NotificationCompat.InboxStyle;
import java.util.ArrayList;
import java.util.Iterator;

public final class O
  implements K
{
  public final Notification a(NotificationCompat.Builder paramBuilder)
  {
    P localP = new P(paramBuilder.jdField_a_of_type_AndroidContentContext, paramBuilder.jdField_a_of_type_AndroidAppNotification, paramBuilder.jdField_a_of_type_JavaLangCharSequence, paramBuilder.jdField_b_of_type_JavaLangCharSequence, paramBuilder.jdField_c_of_type_JavaLangCharSequence, paramBuilder.jdField_a_of_type_AndroidWidgetRemoteViews, paramBuilder.jdField_a_of_type_Int, paramBuilder.jdField_a_of_type_AndroidAppPendingIntent, paramBuilder.jdField_b_of_type_AndroidAppPendingIntent, paramBuilder.jdField_a_of_type_AndroidGraphicsBitmap, paramBuilder.jdField_c_of_type_Int, paramBuilder.jdField_d_of_type_Int, paramBuilder.jdField_b_of_type_Boolean, paramBuilder.jdField_a_of_type_Boolean, paramBuilder.jdField_b_of_type_Int, paramBuilder.jdField_d_of_type_JavaLangCharSequence);
    Object localObject1 = paramBuilder.jdField_a_of_type_JavaUtilArrayList.iterator();
    Object localObject2;
    while (((Iterator)localObject1).hasNext())
    {
      Object localObject3 = (NotificationCompat.Action)((Iterator)localObject1).next();
      int i = ((NotificationCompat.Action)localObject3).icon;
      localObject2 = ((NotificationCompat.Action)localObject3).title;
      localObject3 = ((NotificationCompat.Action)localObject3).actionIntent;
      localP.a.addAction(i, (CharSequence)localObject2, (PendingIntent)localObject3);
    }
    boolean bool;
    if (paramBuilder.jdField_a_of_type_AndroidSupportV4AppNotificationCompat$Style != null)
    {
      if (!(paramBuilder.jdField_a_of_type_AndroidSupportV4AppNotificationCompat$Style instanceof NotificationCompat.BigTextStyle)) {
        break label237;
      }
      localObject2 = (NotificationCompat.BigTextStyle)paramBuilder.jdField_a_of_type_AndroidSupportV4AppNotificationCompat$Style;
      localObject1 = ((NotificationCompat.BigTextStyle)localObject2).jdField_b_of_type_JavaLangCharSequence;
      bool = ((NotificationCompat.BigTextStyle)localObject2).jdField_a_of_type_Boolean;
      paramBuilder = ((NotificationCompat.BigTextStyle)localObject2).jdField_c_of_type_JavaLangCharSequence;
      localObject2 = ((NotificationCompat.BigTextStyle)localObject2).jdField_a_of_type_JavaLangCharSequence;
      localObject1 = new Notification.BigTextStyle(localP.a).setBigContentTitle((CharSequence)localObject1).bigText((CharSequence)localObject2);
      if (bool) {
        ((Notification.BigTextStyle)localObject1).setSummaryText(paramBuilder);
      }
    }
    for (;;)
    {
      return localP.a.build();
      label237:
      if ((paramBuilder.jdField_a_of_type_AndroidSupportV4AppNotificationCompat$Style instanceof NotificationCompat.InboxStyle))
      {
        paramBuilder = (NotificationCompat.InboxStyle)paramBuilder.jdField_a_of_type_AndroidSupportV4AppNotificationCompat$Style;
        localP.a(paramBuilder.jdField_b_of_type_JavaLangCharSequence, paramBuilder.jdField_a_of_type_Boolean, paramBuilder.jdField_c_of_type_JavaLangCharSequence, paramBuilder.jdField_a_of_type_JavaUtilArrayList);
      }
      else if ((paramBuilder.jdField_a_of_type_AndroidSupportV4AppNotificationCompat$Style instanceof NotificationCompat.BigPictureStyle))
      {
        localObject2 = (NotificationCompat.BigPictureStyle)paramBuilder.jdField_a_of_type_AndroidSupportV4AppNotificationCompat$Style;
        localObject1 = ((NotificationCompat.BigPictureStyle)localObject2).jdField_b_of_type_JavaLangCharSequence;
        bool = ((NotificationCompat.BigPictureStyle)localObject2).jdField_a_of_type_Boolean;
        paramBuilder = ((NotificationCompat.BigPictureStyle)localObject2).jdField_c_of_type_JavaLangCharSequence;
        localObject2 = ((NotificationCompat.BigPictureStyle)localObject2).jdField_a_of_type_AndroidGraphicsBitmap;
        localObject1 = new Notification.BigPictureStyle(localP.a).setBigContentTitle((CharSequence)localObject1).bigPicture((Bitmap)localObject2);
        if (bool) {
          ((Notification.BigPictureStyle)localObject1).setSummaryText(paramBuilder);
        }
      }
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/O.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */