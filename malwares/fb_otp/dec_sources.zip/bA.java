import android.os.Bundle;
import android.support.v4.view.AccessibilityDelegateCompat;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;

public final class bA
  extends AccessibilityDelegateCompat
{
  public bA(ViewPager paramViewPager) {}
  
  public final void onInitializeAccessibilityEvent(View paramView, AccessibilityEvent paramAccessibilityEvent)
  {
    super.onInitializeAccessibilityEvent(paramView, paramAccessibilityEvent);
    paramAccessibilityEvent.setClassName(ViewPager.class.getName());
  }
  
  public final void onInitializeAccessibilityNodeInfo(View paramView, AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat)
  {
    boolean bool = true;
    super.onInitializeAccessibilityNodeInfo(paramView, paramAccessibilityNodeInfoCompat);
    paramAccessibilityNodeInfoCompat.setClassName(ViewPager.class.getName());
    if ((ViewPager.a(this.a) != null) && (ViewPager.a(this.a).getCount() > 1)) {}
    for (;;)
    {
      paramAccessibilityNodeInfoCompat.setScrollable(bool);
      if ((ViewPager.a(this.a) != null) && (ViewPager.a(this.a) >= 0) && (ViewPager.a(this.a) < ViewPager.a(this.a).getCount() - 1)) {
        paramAccessibilityNodeInfoCompat.addAction(4096);
      }
      if ((ViewPager.a(this.a) != null) && (ViewPager.a(this.a) > 0) && (ViewPager.a(this.a) < ViewPager.a(this.a).getCount())) {
        paramAccessibilityNodeInfoCompat.addAction(8192);
      }
      return;
      bool = false;
    }
  }
  
  public final boolean performAccessibilityAction(View paramView, int paramInt, Bundle paramBundle)
  {
    if (super.performAccessibilityAction(paramView, paramInt, paramBundle)) {
      return true;
    }
    switch (paramInt)
    {
    default: 
      return false;
    case 4096: 
      if ((ViewPager.a(this.a) != null) && (ViewPager.a(this.a) >= 0) && (ViewPager.a(this.a) < ViewPager.a(this.a).getCount() - 1))
      {
        this.a.setCurrentItem(ViewPager.a(this.a) + 1);
        return true;
      }
      return false;
    }
    if ((ViewPager.a(this.a) != null) && (ViewPager.a(this.a) > 0) && (ViewPager.a(this.a) < ViewPager.a(this.a).getCount()))
    {
      this.a.setCurrentItem(ViewPager.a(this.a) - 1);
      return true;
    }
    return false;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bA.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */