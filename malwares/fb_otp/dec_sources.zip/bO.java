abstract interface bO
{
  public abstract void a(boolean paramBoolean);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bO.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */