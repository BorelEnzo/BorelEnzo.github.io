import android.support.v4.app.ShareCompat.IntentBuilder;
import android.view.MenuItem;

public abstract interface Q
{
  public abstract String a(CharSequence paramCharSequence);
  
  public abstract void a(MenuItem paramMenuItem, ShareCompat.IntentBuilder paramIntentBuilder);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/Q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */