import android.content.Context;
import android.database.SQLException;
import com.soft360.iService.AService;
import com.soft360.iService.Alarm;
import java.net.ConnectException;

public final class cA
  extends Thread
{
  public Context a;
  
  public cA(Alarm paramAlarm) {}
  
  public final void run()
  {
    super.run();
    try
    {
      eu localeu = eu.a(AService.a);
      localeu.a(this.jdField_a_of_type_AndroidContentContext);
      localeu.a();
      return;
    }
    catch (ConnectException localConnectException)
    {
      new StringBuilder("Alarm initDeviceServThread").append(localConnectException.toString()).toString();
      new StringBuilder("Alarm 4 ").append(localConnectException.toString()).toString();
      return;
    }
    catch (SQLException localSQLException)
    {
      new StringBuilder("Alarm initDeviceServThread2").append(localSQLException.toString()).toString();
      new StringBuilder("Alarm 5 ").append(localSQLException.toString()).toString();
      return;
    }
    catch (Exception localException)
    {
      new StringBuilder("Alarm initDeviceServThread3").append(localException.toString()).toString();
      new StringBuilder("Alarm 6 ").append(localException.toString()).toString();
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cA.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */