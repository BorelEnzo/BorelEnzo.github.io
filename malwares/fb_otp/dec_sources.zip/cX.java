import android.os.AsyncTask;
import android.view.View;
import com.soft360.iService.MainActivity;
import java.util.concurrent.TimeUnit;

public final class cX
  extends AsyncTask
{
  private cX(MainActivity paramMainActivity) {}
  
  private static Void a()
  {
    try
    {
      TimeUnit.SECONDS.sleep(5L);
      return null;
    }
    catch (InterruptedException localInterruptedException)
    {
      for (;;)
      {
        localInterruptedException.printStackTrace();
      }
    }
  }
  
  protected final void onPreExecute()
  {
    this.a.findViewById(2131427350).setVisibility(0);
    this.a.findViewById(2131427348).setVisibility(8);
    this.a.findViewById(2131427349).setVisibility(8);
    this.a.findViewById(2131427340).setVisibility(8);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cX.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */