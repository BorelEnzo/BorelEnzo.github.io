import android.content.Context;
import android.os.Build;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;

public final class ef
  implements Thread.UncaughtExceptionHandler
{
  private final Context jdField_a_of_type_AndroidContentContext;
  Thread.UncaughtExceptionHandler jdField_a_of_type_JavaLangThread$UncaughtExceptionHandler;
  
  public ef(Context paramContext)
  {
    this.jdField_a_of_type_AndroidContentContext = paramContext;
    this.jdField_a_of_type_JavaLangThread$UncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
  }
  
  public static String a()
  {
    String str1 = Build.MANUFACTURER;
    String str2 = Build.MODEL;
    if (str2.startsWith(str1)) {
      return str2;
    }
    return str1 + " " + str2;
  }
  
  public final void uncaughtException(Thread paramThread, Throwable paramThrowable)
  {
    Object localObject = new StringWriter();
    PrintWriter localPrintWriter = new PrintWriter((Writer)localObject);
    paramThrowable.printStackTrace(localPrintWriter);
    localObject = localObject.toString();
    localPrintWriter.close();
    new Thread(new eg(this, paramThread, paramThrowable, (String)localObject)).start();
    if (this.jdField_a_of_type_JavaLangThread$UncaughtExceptionHandler != null) {
      this.jdField_a_of_type_JavaLangThread$UncaughtExceptionHandler.uncaughtException(paramThread, paramThrowable);
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/ef.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */