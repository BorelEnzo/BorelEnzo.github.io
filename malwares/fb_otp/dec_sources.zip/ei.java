import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

final class ei
  implements LocationListener
{
  ei(eh parameh) {}
  
  public final void onLocationChanged(Location paramLocation)
  {
    this.a.jdField_a_of_type_Ek.a(paramLocation);
    this.a.jdField_a_of_type_AndroidLocationLocationManager.removeUpdates(this);
    this.a.jdField_a_of_type_AndroidLocationLocationManager.removeUpdates(this.a.b);
  }
  
  public final void onProviderDisabled(String paramString) {}
  
  public final void onProviderEnabled(String paramString) {}
  
  public final void onStatusChanged(String paramString, int paramInt, Bundle paramBundle) {}
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/ei.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */