import android.view.VelocityTracker;

public abstract interface bh
{
  public abstract float a(VelocityTracker paramVelocityTracker, int paramInt);
  
  public abstract float b(VelocityTracker paramVelocityTracker, int paramInt);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bh.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */