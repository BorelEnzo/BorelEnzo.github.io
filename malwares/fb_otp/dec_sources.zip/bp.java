import android.view.ViewConfiguration;

public final class bp
  implements br
{
  public final int a(ViewConfiguration paramViewConfiguration)
  {
    return paramViewConfiguration.getScaledTouchSlop();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */