import android.os.Parcelable.Creator;

public final class i
  implements Parcelable.Creator
{}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/i.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */