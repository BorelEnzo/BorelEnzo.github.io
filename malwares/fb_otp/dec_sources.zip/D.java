import android.support.v4.app.ListFragment;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;

public final class D
  implements AdapterView.OnItemClickListener
{
  public D(ListFragment paramListFragment) {}
  
  public final void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    this.a.onListItemClick((ListView)paramAdapterView, paramView, paramInt, paramLong);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/D.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */