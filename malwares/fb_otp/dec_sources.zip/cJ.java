import android.os.AsyncTask;
import com.soft360.iService.MainActivity;
import java.util.concurrent.TimeUnit;

public final class cJ
  extends AsyncTask
{
  private cJ(MainActivity paramMainActivity) {}
  
  private Void a()
  {
    try
    {
      this.a.a.p();
      TimeUnit.SECONDS.sleep(3L);
      return null;
    }
    catch (InterruptedException localInterruptedException)
    {
      for (;;)
      {
        localInterruptedException.printStackTrace();
      }
    }
  }
  
  protected final void onPreExecute() {}
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cJ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */