import android.util.AndroidRuntimeException;

public final class U
  extends AndroidRuntimeException
{
  public U(String paramString)
  {
    super(paramString);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/U.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */