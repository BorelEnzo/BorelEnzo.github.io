import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.ModernAsyncTask;
import java.util.concurrent.CountDownLatch;

public final class Y
  extends ModernAsyncTask
  implements Runnable
{
  Object jdField_a_of_type_JavaLangObject;
  private CountDownLatch jdField_a_of_type_JavaUtilConcurrentCountDownLatch = new CountDownLatch(1);
  public boolean a;
  
  public Y(AsyncTaskLoader paramAsyncTaskLoader) {}
  
  protected final void a()
  {
    try
    {
      this.jdField_a_of_type_AndroidSupportV4ContentAsyncTaskLoader.a(this, this.jdField_a_of_type_JavaLangObject);
      return;
    }
    finally
    {
      this.jdField_a_of_type_JavaUtilConcurrentCountDownLatch.countDown();
    }
  }
  
  protected final void a(Object paramObject)
  {
    try
    {
      this.jdField_a_of_type_AndroidSupportV4ContentAsyncTaskLoader.b(this, paramObject);
      return;
    }
    finally
    {
      this.jdField_a_of_type_JavaUtilConcurrentCountDownLatch.countDown();
    }
  }
  
  public final void run()
  {
    this.jdField_a_of_type_Boolean = false;
    this.jdField_a_of_type_AndroidSupportV4ContentAsyncTaskLoader.a();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/Y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */