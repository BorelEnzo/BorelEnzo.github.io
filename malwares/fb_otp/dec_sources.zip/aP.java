import android.view.MenuItem;

public final class aP
  implements aQ
{
  public final boolean a(MenuItem paramMenuItem, int paramInt)
  {
    paramMenuItem.setShowAsAction(paramInt);
    return true;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/aP.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */