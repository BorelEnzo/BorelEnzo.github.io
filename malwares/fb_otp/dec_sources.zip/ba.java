import android.widget.TextView;

public abstract interface ba
{
  public abstract void a(TextView paramTextView);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/ba.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */