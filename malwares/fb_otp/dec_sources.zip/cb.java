import android.view.accessibility.AccessibilityRecord;

public class cb
  extends ca
{
  public final void i(Object paramObject, int paramInt)
  {
    ((AccessibilityRecord)paramObject).setMaxScrollX(paramInt);
  }
  
  public final int j(Object paramObject)
  {
    return ((AccessibilityRecord)paramObject).getMaxScrollX();
  }
  
  public final void j(Object paramObject, int paramInt)
  {
    ((AccessibilityRecord)paramObject).setMaxScrollY(paramInt);
  }
  
  public final int k(Object paramObject)
  {
    return ((AccessibilityRecord)paramObject).getMaxScrollY();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */