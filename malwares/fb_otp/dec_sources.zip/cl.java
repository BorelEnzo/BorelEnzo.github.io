import android.content.Context;
import android.graphics.Canvas;

public abstract interface cl
{
  public abstract Object a(Context paramContext);
  
  public abstract void a(Object paramObject);
  
  public abstract void a(Object paramObject, int paramInt1, int paramInt2);
  
  public abstract boolean a(Object paramObject);
  
  public abstract boolean a(Object paramObject, float paramFloat);
  
  public abstract boolean a(Object paramObject, int paramInt);
  
  public abstract boolean a(Object paramObject, Canvas paramCanvas);
  
  public abstract boolean b(Object paramObject);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */