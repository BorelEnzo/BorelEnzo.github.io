import android.view.MenuItem;

public abstract interface aQ
{
  public abstract boolean a(MenuItem paramMenuItem, int paramInt);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/aQ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */