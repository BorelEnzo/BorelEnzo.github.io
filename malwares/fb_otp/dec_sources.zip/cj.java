import android.content.Context;
import android.graphics.Canvas;

public final class cj
  implements cl
{
  public final Object a(Context paramContext)
  {
    return null;
  }
  
  public final void a(Object paramObject) {}
  
  public final void a(Object paramObject, int paramInt1, int paramInt2) {}
  
  public final boolean a(Object paramObject)
  {
    return true;
  }
  
  public final boolean a(Object paramObject, float paramFloat)
  {
    return false;
  }
  
  public final boolean a(Object paramObject, int paramInt)
  {
    return false;
  }
  
  public final boolean a(Object paramObject, Canvas paramCanvas)
  {
    return false;
  }
  
  public final boolean b(Object paramObject)
  {
    return false;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cj.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */