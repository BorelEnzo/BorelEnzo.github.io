import android.support.v4.view.PagerTabStrip;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.View.OnClickListener;

public final class aX
  implements View.OnClickListener
{
  public aX(PagerTabStrip paramPagerTabStrip) {}
  
  public final void onClick(View paramView)
  {
    this.a.a.setCurrentItem(this.a.a.getCurrentItem() - 1);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/aX.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */