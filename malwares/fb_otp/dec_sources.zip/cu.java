import android.widget.SearchView.OnCloseListener;

final class cu
  implements SearchView.OnCloseListener
{
  cu(cv paramcv) {}
  
  public final boolean onClose()
  {
    return this.a.a();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */