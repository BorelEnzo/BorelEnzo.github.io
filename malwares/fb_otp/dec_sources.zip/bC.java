import android.database.DataSetObserver;
import android.support.v4.view.ViewPager;

public final class bC
  extends DataSetObserver
{
  private bC(ViewPager paramViewPager) {}
  
  public final void onChanged()
  {
    this.a.a();
  }
  
  public final void onInvalidated()
  {
    this.a.a();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bC.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */