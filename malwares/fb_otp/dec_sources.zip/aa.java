import android.content.ComponentName;
import android.content.Intent;

public class aa
  implements Z
{
  public Intent a(ComponentName paramComponentName)
  {
    Intent localIntent = new Intent("android.intent.action.MAIN");
    localIntent.setComponent(paramComponentName);
    localIntent.addCategory("android.intent.category.LAUNCHER");
    return localIntent;
  }
  
  public Intent a(String paramString1, String paramString2)
  {
    paramString1 = new Intent(paramString1);
    paramString1.addCategory(paramString2);
    return paramString1;
  }
  
  public Intent b(ComponentName paramComponentName)
  {
    paramComponentName = a(paramComponentName);
    paramComponentName.addFlags(268468224);
    return paramComponentName;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/aa.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */