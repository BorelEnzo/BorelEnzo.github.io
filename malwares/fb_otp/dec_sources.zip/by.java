public abstract interface by {}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/by.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */