import android.os.Handler;
import android.support.v4.app.FragmentActivity;

final class r
  implements Runnable
{
  r(o paramo, String paramString, int paramInt) {}
  
  public final void run()
  {
    o localo = this.jdField_a_of_type_O;
    Handler localHandler = this.jdField_a_of_type_O.a.a;
    localo.a(this.jdField_a_of_type_JavaLangString, -1, this.jdField_a_of_type_Int);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/r.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */