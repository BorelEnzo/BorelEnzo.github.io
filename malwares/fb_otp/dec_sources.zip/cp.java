import android.content.Context;
import android.support.v4.widget.SearchViewCompatIcs.MySearchView;
import android.view.View;
import android.widget.SearchView;

public final class cp
  extends cm
{
  public final View a(Context paramContext)
  {
    return new SearchViewCompatIcs.MySearchView(paramContext);
  }
  
  public final void b(View paramView, int paramInt)
  {
    ((SearchView)paramView).setImeOptions(paramInt);
  }
  
  public final void c(View paramView, int paramInt)
  {
    ((SearchView)paramView).setInputType(paramInt);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */