import android.support.v4.view.accessibility.AccessibilityNodeProviderCompat;

public final class bU
  extends bW
{
  public final Object a(AccessibilityNodeProviderCompat paramAccessibilityNodeProviderCompat)
  {
    return new bY(new bV(this, paramAccessibilityNodeProviderCompat));
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bU.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */