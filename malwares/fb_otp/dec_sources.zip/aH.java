import android.view.GestureDetector.OnDoubleTapListener;
import android.view.MotionEvent;

public abstract interface aH
{
  public abstract void a(GestureDetector.OnDoubleTapListener paramOnDoubleTapListener);
  
  public abstract void a(boolean paramBoolean);
  
  public abstract boolean a();
  
  public abstract boolean a(MotionEvent paramMotionEvent);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/aH.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */