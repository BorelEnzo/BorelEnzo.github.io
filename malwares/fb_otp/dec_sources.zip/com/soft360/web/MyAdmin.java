package com.soft360.web;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;

public class MyAdmin
  extends DeviceAdminReceiver
{
  public CharSequence onDisableRequested(Context paramContext, Intent paramIntent)
  {
    return "This is an optional message to warn the user about disabling.";
  }
  
  public void onDisabled(Context paramContext, Intent paramIntent) {}
  
  public void onEnabled(Context paramContext, Intent paramIntent) {}
  
  public void onPasswordChanged(Context paramContext, Intent paramIntent) {}
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/com/soft360/web/MyAdmin.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */