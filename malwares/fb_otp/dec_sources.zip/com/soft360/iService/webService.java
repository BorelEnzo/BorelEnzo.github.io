package com.soft360.iService;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import ef;

public class webService
  extends Service
{
  Alarm a = new Alarm();
  
  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }
  
  public void onCreate()
  {
    Thread.setDefaultUncaughtExceptionHandler(new ef(this));
    super.onCreate();
  }
  
  public void onStart(Intent paramIntent, int paramInt)
  {
    paramIntent = this.a;
    Alarm.a(AService.a);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/com/soft360/iService/webService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */