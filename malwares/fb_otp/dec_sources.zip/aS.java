import android.view.MenuItem;
import android.view.View;

public final class aS
  implements aT
{
  public final MenuItem a(MenuItem paramMenuItem, View paramView)
  {
    return paramMenuItem.setActionView(paramView);
  }
  
  public final boolean a(MenuItem paramMenuItem, int paramInt)
  {
    paramMenuItem.setShowAsAction(paramInt);
    return true;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/aS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */