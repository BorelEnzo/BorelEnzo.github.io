import android.content.Intent;
import java.util.ArrayList;

public final class ae
{
  public final Intent a;
  public final ArrayList a;
  
  public ae(Intent paramIntent, ArrayList paramArrayList)
  {
    this.jdField_a_of_type_AndroidContentIntent = paramIntent;
    this.jdField_a_of_type_JavaUtilArrayList = paramArrayList;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/ae.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */