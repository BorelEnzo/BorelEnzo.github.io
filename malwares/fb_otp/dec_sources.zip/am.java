import java.util.concurrent.Callable;

public abstract class am
  implements Callable
{
  public Object[] a;
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/am.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */