import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

public abstract interface V
{
  public abstract PendingIntent a(Context paramContext, Intent[] paramArrayOfIntent, int paramInt1, int paramInt2);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/V.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */