import android.content.Context;
import android.os.Handler;
import android.view.GestureDetector;
import android.view.GestureDetector.OnDoubleTapListener;
import android.view.GestureDetector.OnGestureListener;
import android.view.MotionEvent;

public final class aK
  implements aH
{
  private final GestureDetector a;
  
  public aK(Context paramContext, GestureDetector.OnGestureListener paramOnGestureListener, Handler paramHandler)
  {
    this.a = new GestureDetector(paramContext, paramOnGestureListener, paramHandler);
  }
  
  public final void a(GestureDetector.OnDoubleTapListener paramOnDoubleTapListener)
  {
    this.a.setOnDoubleTapListener(paramOnDoubleTapListener);
  }
  
  public final void a(boolean paramBoolean)
  {
    this.a.setIsLongpressEnabled(paramBoolean);
  }
  
  public final boolean a()
  {
    return this.a.isLongpressEnabled();
  }
  
  public final boolean a(MotionEvent paramMotionEvent)
  {
    return this.a.onTouchEvent(paramMotionEvent);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/aK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */