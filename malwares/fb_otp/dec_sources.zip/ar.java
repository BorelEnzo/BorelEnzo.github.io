import android.net.ConnectivityManager;

public final class ar
  implements ao
{
  public final boolean a(ConnectivityManager paramConnectivityManager)
  {
    return paramConnectivityManager.isActiveNetworkMetered();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/ar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */