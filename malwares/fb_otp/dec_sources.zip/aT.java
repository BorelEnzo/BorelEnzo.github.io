import android.view.MenuItem;
import android.view.View;

public abstract interface aT
{
  public abstract MenuItem a(MenuItem paramMenuItem, View paramView);
  
  public abstract boolean a(MenuItem paramMenuItem, int paramInt);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/aT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */