import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.os.ParcelableCompatCreatorCallbacks;

public final class ax
  implements Parcelable.Creator
{
  final ParcelableCompatCreatorCallbacks a;
  
  public ax(ParcelableCompatCreatorCallbacks paramParcelableCompatCreatorCallbacks)
  {
    this.a = paramParcelableCompatCreatorCallbacks;
  }
  
  public final Object createFromParcel(Parcel paramParcel)
  {
    return this.a.createFromParcel(paramParcel, null);
  }
  
  public final Object[] newArray(int paramInt)
  {
    return this.a.newArray(paramInt);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/ax.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */