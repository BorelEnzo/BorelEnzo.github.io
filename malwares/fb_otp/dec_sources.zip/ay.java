import android.os.Parcel;
import android.os.Parcelable.ClassLoaderCreator;
import android.support.v4.os.ParcelableCompatCreatorCallbacks;

public final class ay
  implements Parcelable.ClassLoaderCreator
{
  private final ParcelableCompatCreatorCallbacks a;
  
  public ay(ParcelableCompatCreatorCallbacks paramParcelableCompatCreatorCallbacks)
  {
    this.a = paramParcelableCompatCreatorCallbacks;
  }
  
  public final Object createFromParcel(Parcel paramParcel)
  {
    return this.a.createFromParcel(paramParcel, null);
  }
  
  public final Object createFromParcel(Parcel paramParcel, ClassLoader paramClassLoader)
  {
    return this.a.createFromParcel(paramParcel, paramClassLoader);
  }
  
  public final Object[] newArray(int paramInt)
  {
    return this.a.newArray(paramInt);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/ay.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */