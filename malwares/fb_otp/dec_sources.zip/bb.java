import android.widget.TextView;

public final class bb
  implements ba
{
  public final void a(TextView paramTextView)
  {
    paramTextView.setSingleLine();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */