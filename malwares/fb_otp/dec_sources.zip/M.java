import android.app.Notification;
import android.app.Notification.Builder;
import android.app.PendingIntent;
import android.content.Context;
import android.support.v4.app.NotificationCompat.Builder;
import android.widget.RemoteViews;

public final class M
  implements K
{
  public final Notification a(NotificationCompat.Builder paramBuilder)
  {
    Object localObject2 = paramBuilder.jdField_a_of_type_AndroidContentContext;
    Notification localNotification = paramBuilder.jdField_a_of_type_AndroidAppNotification;
    Object localObject1 = paramBuilder.jdField_a_of_type_JavaLangCharSequence;
    CharSequence localCharSequence1 = paramBuilder.jdField_b_of_type_JavaLangCharSequence;
    CharSequence localCharSequence2 = paramBuilder.c;
    RemoteViews localRemoteViews = paramBuilder.jdField_a_of_type_AndroidWidgetRemoteViews;
    int i = paramBuilder.jdField_a_of_type_Int;
    PendingIntent localPendingIntent2 = paramBuilder.jdField_a_of_type_AndroidAppPendingIntent;
    PendingIntent localPendingIntent1 = paramBuilder.jdField_b_of_type_AndroidAppPendingIntent;
    paramBuilder = paramBuilder.jdField_a_of_type_AndroidGraphicsBitmap;
    localObject2 = new Notification.Builder((Context)localObject2).setWhen(localNotification.when).setSmallIcon(localNotification.icon, localNotification.iconLevel).setContent(localNotification.contentView).setTicker(localNotification.tickerText, localRemoteViews).setSound(localNotification.sound, localNotification.audioStreamType).setVibrate(localNotification.vibrate).setLights(localNotification.ledARGB, localNotification.ledOnMS, localNotification.ledOffMS);
    if ((localNotification.flags & 0x2) != 0)
    {
      bool = true;
      localObject2 = ((Notification.Builder)localObject2).setOngoing(bool);
      if ((localNotification.flags & 0x8) == 0) {
        break label284;
      }
      bool = true;
      label180:
      localObject2 = ((Notification.Builder)localObject2).setOnlyAlertOnce(bool);
      if ((localNotification.flags & 0x10) == 0) {
        break label289;
      }
      bool = true;
      label201:
      localObject1 = ((Notification.Builder)localObject2).setAutoCancel(bool).setDefaults(localNotification.defaults).setContentTitle((CharSequence)localObject1).setContentText(localCharSequence1).setContentInfo(localCharSequence2).setContentIntent(localPendingIntent2).setDeleteIntent(localNotification.deleteIntent);
      if ((localNotification.flags & 0x80) == 0) {
        break label294;
      }
    }
    label284:
    label289:
    label294:
    for (boolean bool = true;; bool = false)
    {
      return ((Notification.Builder)localObject1).setFullScreenIntent(localPendingIntent1, bool).setLargeIcon(paramBuilder).setNumber(i).getNotification();
      bool = false;
      break;
      bool = false;
      break label180;
      bool = false;
      break label201;
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/M.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */