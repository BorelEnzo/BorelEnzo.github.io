import android.support.v4.widget.SearchViewCompat.OnQueryTextListenerCompat;

final class cn
  implements cw
{
  cn(cm paramcm, SearchViewCompat.OnQueryTextListenerCompat paramOnQueryTextListenerCompat) {}
  
  public final boolean a(String paramString)
  {
    return this.jdField_a_of_type_AndroidSupportV4WidgetSearchViewCompat$OnQueryTextListenerCompat.onQueryTextSubmit(paramString);
  }
  
  public final boolean b(String paramString)
  {
    return this.jdField_a_of_type_AndroidSupportV4WidgetSearchViewCompat$OnQueryTextListenerCompat.onQueryTextChange(paramString);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cn.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */