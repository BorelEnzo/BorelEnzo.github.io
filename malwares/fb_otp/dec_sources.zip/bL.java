import android.support.v4.view.accessibility.AccessibilityManagerCompat.AccessibilityStateChangeListenerCompat;
import android.view.accessibility.AccessibilityManager;
import java.util.List;

public abstract interface bL
{
  public abstract Object a(AccessibilityManagerCompat.AccessibilityStateChangeListenerCompat paramAccessibilityStateChangeListenerCompat);
  
  public abstract List a(AccessibilityManager paramAccessibilityManager);
  
  public abstract List a(AccessibilityManager paramAccessibilityManager, int paramInt);
  
  public abstract boolean a(AccessibilityManager paramAccessibilityManager);
  
  public abstract boolean a(AccessibilityManager paramAccessibilityManager, AccessibilityManagerCompat.AccessibilityStateChangeListenerCompat paramAccessibilityStateChangeListenerCompat);
  
  public abstract boolean b(AccessibilityManager paramAccessibilityManager, AccessibilityManagerCompat.AccessibilityStateChangeListenerCompat paramAccessibilityStateChangeListenerCompat);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bL.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */