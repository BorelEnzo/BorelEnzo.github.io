import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;

final class w
  implements Parcelable
{
  public static final Parcelable.Creator a;
  final int jdField_a_of_type_Int;
  final Bundle jdField_a_of_type_AndroidOsBundle;
  Fragment jdField_a_of_type_AndroidSupportV4AppFragment;
  final String jdField_a_of_type_JavaLangString;
  final boolean jdField_a_of_type_Boolean;
  final int jdField_b_of_type_Int;
  Bundle jdField_b_of_type_AndroidOsBundle;
  final String jdField_b_of_type_JavaLangString;
  final boolean jdField_b_of_type_Boolean;
  final int jdField_c_of_type_Int;
  final boolean jdField_c_of_type_Boolean;
  
  static
  {
    jdField_a_of_type_AndroidOsParcelable$Creator = new x();
  }
  
  public w(Parcel paramParcel)
  {
    this.jdField_a_of_type_JavaLangString = paramParcel.readString();
    this.jdField_a_of_type_Int = paramParcel.readInt();
    if (paramParcel.readInt() != 0)
    {
      bool1 = true;
      this.jdField_a_of_type_Boolean = bool1;
      this.jdField_b_of_type_Int = paramParcel.readInt();
      this.jdField_c_of_type_Int = paramParcel.readInt();
      this.jdField_b_of_type_JavaLangString = paramParcel.readString();
      if (paramParcel.readInt() == 0) {
        break label110;
      }
      bool1 = true;
      label69:
      this.jdField_b_of_type_Boolean = bool1;
      if (paramParcel.readInt() == 0) {
        break label115;
      }
    }
    label110:
    label115:
    for (boolean bool1 = bool2;; bool1 = false)
    {
      this.jdField_c_of_type_Boolean = bool1;
      this.jdField_a_of_type_AndroidOsBundle = paramParcel.readBundle();
      this.jdField_b_of_type_AndroidOsBundle = paramParcel.readBundle();
      return;
      bool1 = false;
      break;
      bool1 = false;
      break label69;
    }
  }
  
  public w(Fragment paramFragment)
  {
    this.jdField_a_of_type_JavaLangString = paramFragment.getClass().getName();
    this.jdField_a_of_type_Int = paramFragment.f;
    this.jdField_a_of_type_Boolean = paramFragment.i;
    this.jdField_b_of_type_Int = paramFragment.j;
    this.jdField_c_of_type_Int = paramFragment.jdField_k_of_type_Int;
    this.jdField_b_of_type_JavaLangString = paramFragment.jdField_b_of_type_JavaLangString;
    this.jdField_b_of_type_Boolean = paramFragment.n;
    this.jdField_c_of_type_Boolean = paramFragment.m;
    this.jdField_a_of_type_AndroidOsBundle = paramFragment.jdField_b_of_type_AndroidOsBundle;
  }
  
  public final Fragment a(FragmentActivity paramFragmentActivity, Fragment paramFragment)
  {
    if (this.jdField_a_of_type_AndroidSupportV4AppFragment != null) {
      return this.jdField_a_of_type_AndroidSupportV4AppFragment;
    }
    if (this.jdField_a_of_type_AndroidOsBundle != null) {
      this.jdField_a_of_type_AndroidOsBundle.setClassLoader(paramFragmentActivity.getClassLoader());
    }
    this.jdField_a_of_type_AndroidSupportV4AppFragment = Fragment.instantiate(paramFragmentActivity, this.jdField_a_of_type_JavaLangString, this.jdField_a_of_type_AndroidOsBundle);
    if (this.jdField_b_of_type_AndroidOsBundle != null)
    {
      this.jdField_b_of_type_AndroidOsBundle.setClassLoader(paramFragmentActivity.getClassLoader());
      this.jdField_a_of_type_AndroidSupportV4AppFragment.jdField_a_of_type_AndroidOsBundle = this.jdField_b_of_type_AndroidOsBundle;
    }
    this.jdField_a_of_type_AndroidSupportV4AppFragment.a(this.jdField_a_of_type_Int, paramFragment);
    this.jdField_a_of_type_AndroidSupportV4AppFragment.i = this.jdField_a_of_type_Boolean;
    this.jdField_a_of_type_AndroidSupportV4AppFragment.jdField_k_of_type_Boolean = true;
    this.jdField_a_of_type_AndroidSupportV4AppFragment.j = this.jdField_b_of_type_Int;
    this.jdField_a_of_type_AndroidSupportV4AppFragment.jdField_k_of_type_Int = this.jdField_c_of_type_Int;
    this.jdField_a_of_type_AndroidSupportV4AppFragment.jdField_b_of_type_JavaLangString = this.jdField_b_of_type_JavaLangString;
    this.jdField_a_of_type_AndroidSupportV4AppFragment.n = this.jdField_b_of_type_Boolean;
    this.jdField_a_of_type_AndroidSupportV4AppFragment.m = this.jdField_c_of_type_Boolean;
    this.jdField_a_of_type_AndroidSupportV4AppFragment.jdField_a_of_type_O = paramFragmentActivity.jdField_a_of_type_O;
    if (o.jdField_a_of_type_Boolean) {
      new StringBuilder("Instantiated fragment ").append(this.jdField_a_of_type_AndroidSupportV4AppFragment).toString();
    }
    return this.jdField_a_of_type_AndroidSupportV4AppFragment;
  }
  
  public final int describeContents()
  {
    return 0;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt)
  {
    int i = 1;
    paramParcel.writeString(this.jdField_a_of_type_JavaLangString);
    paramParcel.writeInt(this.jdField_a_of_type_Int);
    if (this.jdField_a_of_type_Boolean)
    {
      paramInt = 1;
      paramParcel.writeInt(paramInt);
      paramParcel.writeInt(this.jdField_b_of_type_Int);
      paramParcel.writeInt(this.jdField_c_of_type_Int);
      paramParcel.writeString(this.jdField_b_of_type_JavaLangString);
      if (!this.jdField_b_of_type_Boolean) {
        break label106;
      }
      paramInt = 1;
      label65:
      paramParcel.writeInt(paramInt);
      if (!this.jdField_c_of_type_Boolean) {
        break label111;
      }
    }
    label106:
    label111:
    for (paramInt = i;; paramInt = 0)
    {
      paramParcel.writeInt(paramInt);
      paramParcel.writeBundle(this.jdField_a_of_type_AndroidOsBundle);
      paramParcel.writeBundle(this.jdField_b_of_type_AndroidOsBundle);
      return;
      paramInt = 0;
      break;
      paramInt = 0;
      break label65;
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/w.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */