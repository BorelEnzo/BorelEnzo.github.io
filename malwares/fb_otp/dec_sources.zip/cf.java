import android.database.ContentObserver;
import android.os.Handler;
import android.support.v4.widget.CursorAdapter;

public final class cf
  extends ContentObserver
{
  public cf(CursorAdapter paramCursorAdapter)
  {
    super(new Handler());
  }
  
  public final boolean deliverSelfNotifications()
  {
    return true;
  }
  
  public final void onChange(boolean paramBoolean)
  {
    this.a.onContentChanged();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cf.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */