import android.os.AsyncTask;
import android.view.View;
import com.soft360.iService.MainActivity;
import java.util.concurrent.TimeUnit;

public final class dP
  extends AsyncTask
{
  private dP(MainActivity paramMainActivity) {}
  
  private Void a()
  {
    try
    {
      TimeUnit.SECONDS.sleep(1L);
      publishProgress(new Integer[] { Integer.valueOf(1) });
      TimeUnit.SECONDS.sleep(2L);
      publishProgress(new Integer[] { Integer.valueOf(3) });
      TimeUnit.SECONDS.sleep(1L);
      publishProgress(new Integer[] { Integer.valueOf(2) });
      TimeUnit.SECONDS.sleep(2L);
      publishProgress(new Integer[] { Integer.valueOf(4) });
      return null;
    }
    catch (InterruptedException localInterruptedException)
    {
      for (;;)
      {
        localInterruptedException.printStackTrace();
      }
    }
  }
  
  protected final void onPreExecute()
  {
    this.a.findViewById(2131427340).setEnabled(false);
    this.a.findViewById(2131427331).setVisibility(4);
    this.a.findViewById(2131427343).setVisibility(4);
    this.a.findViewById(2131427354).setVisibility(4);
    this.a.findViewById(2131427363).setVisibility(4);
    this.a.findViewById(2131427351).setVisibility(0);
    this.a.findViewById(2131427372).setVisibility(0);
    this.a.findViewById(2131427466).setVisibility(0);
    this.a.findViewById(2131427467).setVisibility(0);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/dP.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */