import android.app.Notification;
import android.support.v4.app.NotificationCompat.Builder;

public final class L
  implements K
{
  public final Notification a(NotificationCompat.Builder paramBuilder)
  {
    Notification localNotification = paramBuilder.jdField_a_of_type_AndroidAppNotification;
    localNotification.setLatestEventInfo(paramBuilder.jdField_a_of_type_AndroidContentContext, paramBuilder.jdField_a_of_type_JavaLangCharSequence, paramBuilder.jdField_b_of_type_JavaLangCharSequence, paramBuilder.jdField_a_of_type_AndroidAppPendingIntent);
    if (paramBuilder.jdField_b_of_type_Int > 0) {
      localNotification.flags |= 0x80;
    }
    return localNotification;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/L.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */