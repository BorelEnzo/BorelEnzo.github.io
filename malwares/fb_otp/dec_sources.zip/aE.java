import android.os.Bundle;
import android.support.v4.view.AccessibilityDelegateCompat;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.v4.view.accessibility.AccessibilityNodeProviderCompat;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;

public class aE
  implements aB
{
  public AccessibilityNodeProviderCompat a(Object paramObject, View paramView)
  {
    return null;
  }
  
  public Object a()
  {
    return null;
  }
  
  public Object a(AccessibilityDelegateCompat paramAccessibilityDelegateCompat)
  {
    return null;
  }
  
  public void a(Object paramObject, View paramView, int paramInt) {}
  
  public void a(Object paramObject, View paramView, AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat) {}
  
  public void a(Object paramObject, View paramView, AccessibilityEvent paramAccessibilityEvent) {}
  
  public boolean a(Object paramObject, View paramView, int paramInt, Bundle paramBundle)
  {
    return false;
  }
  
  public boolean a(Object paramObject, View paramView, AccessibilityEvent paramAccessibilityEvent)
  {
    return false;
  }
  
  public boolean a(Object paramObject, ViewGroup paramViewGroup, View paramView, AccessibilityEvent paramAccessibilityEvent)
  {
    return true;
  }
  
  public void b(Object paramObject, View paramView, AccessibilityEvent paramAccessibilityEvent) {}
  
  public void c(Object paramObject, View paramView, AccessibilityEvent paramAccessibilityEvent) {}
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/aE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */