import android.view.MotionEvent;

public abstract interface aW
{
  public abstract float a(MotionEvent paramMotionEvent, int paramInt);
  
  public abstract int a(MotionEvent paramMotionEvent);
  
  public abstract int a(MotionEvent paramMotionEvent, int paramInt);
  
  public abstract float b(MotionEvent paramMotionEvent, int paramInt);
  
  public abstract int b(MotionEvent paramMotionEvent, int paramInt);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/aW.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */