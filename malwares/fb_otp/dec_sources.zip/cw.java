abstract interface cw
{
  public abstract boolean a(String paramString);
  
  public abstract boolean b(String paramString);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */