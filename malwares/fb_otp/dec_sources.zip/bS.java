import android.graphics.Rect;
import android.os.Bundle;
import android.view.View;
import java.util.Collections;
import java.util.List;

public class bS
  implements bQ
{
  public int a(Object paramObject)
  {
    return 0;
  }
  
  public CharSequence a(Object paramObject)
  {
    return null;
  }
  
  public Object a()
  {
    return null;
  }
  
  public Object a(View paramView)
  {
    return null;
  }
  
  public Object a(View paramView, int paramInt)
  {
    return null;
  }
  
  public Object a(Object paramObject)
  {
    return null;
  }
  
  public Object a(Object paramObject, int paramInt)
  {
    return null;
  }
  
  public List a(Object paramObject, String paramString)
  {
    return Collections.emptyList();
  }
  
  public void a(Object paramObject) {}
  
  public void a(Object paramObject, int paramInt) {}
  
  public void a(Object paramObject, Rect paramRect) {}
  
  public void a(Object paramObject, View paramView) {}
  
  public void a(Object paramObject, View paramView, int paramInt) {}
  
  public void a(Object paramObject, CharSequence paramCharSequence) {}
  
  public void a(Object paramObject, boolean paramBoolean) {}
  
  public boolean a(Object paramObject)
  {
    return false;
  }
  
  public boolean a(Object paramObject, int paramInt)
  {
    return false;
  }
  
  public boolean a(Object paramObject, int paramInt, Bundle paramBundle)
  {
    return false;
  }
  
  public int b(Object paramObject)
  {
    return 0;
  }
  
  public CharSequence b(Object paramObject)
  {
    return null;
  }
  
  public Object b(Object paramObject)
  {
    return null;
  }
  
  public Object b(Object paramObject, int paramInt)
  {
    return null;
  }
  
  public void b(Object paramObject, int paramInt) {}
  
  public void b(Object paramObject, Rect paramRect) {}
  
  public void b(Object paramObject, View paramView) {}
  
  public void b(Object paramObject, View paramView, int paramInt) {}
  
  public void b(Object paramObject, CharSequence paramCharSequence) {}
  
  public void b(Object paramObject, boolean paramBoolean) {}
  
  public boolean b(Object paramObject)
  {
    return false;
  }
  
  public int c(Object paramObject)
  {
    return 0;
  }
  
  public CharSequence c(Object paramObject)
  {
    return null;
  }
  
  public Object c(Object paramObject, int paramInt)
  {
    return null;
  }
  
  public void c(Object paramObject, Rect paramRect) {}
  
  public void c(Object paramObject, View paramView) {}
  
  public void c(Object paramObject, View paramView, int paramInt) {}
  
  public void c(Object paramObject, CharSequence paramCharSequence) {}
  
  public void c(Object paramObject, boolean paramBoolean) {}
  
  public boolean c(Object paramObject)
  {
    return false;
  }
  
  public int d(Object paramObject)
  {
    return 0;
  }
  
  public CharSequence d(Object paramObject)
  {
    return null;
  }
  
  public void d(Object paramObject, Rect paramRect) {}
  
  public void d(Object paramObject, CharSequence paramCharSequence) {}
  
  public void d(Object paramObject, boolean paramBoolean) {}
  
  public boolean d(Object paramObject)
  {
    return false;
  }
  
  public void e(Object paramObject, boolean paramBoolean) {}
  
  public boolean e(Object paramObject)
  {
    return false;
  }
  
  public void f(Object paramObject, boolean paramBoolean) {}
  
  public boolean f(Object paramObject)
  {
    return false;
  }
  
  public void g(Object paramObject, boolean paramBoolean) {}
  
  public boolean g(Object paramObject)
  {
    return false;
  }
  
  public void h(Object paramObject, boolean paramBoolean) {}
  
  public boolean h(Object paramObject)
  {
    return false;
  }
  
  public void i(Object paramObject, boolean paramBoolean) {}
  
  public boolean i(Object paramObject)
  {
    return false;
  }
  
  public void j(Object paramObject, boolean paramBoolean) {}
  
  public boolean j(Object paramObject)
  {
    return false;
  }
  
  public void k(Object paramObject, boolean paramBoolean) {}
  
  public boolean k(Object paramObject)
  {
    return false;
  }
  
  public void l(Object paramObject, boolean paramBoolean) {}
  
  public boolean l(Object paramObject)
  {
    return false;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */