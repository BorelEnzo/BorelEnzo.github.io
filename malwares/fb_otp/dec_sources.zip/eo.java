final class eo
  implements Runnable
{
  eo(en paramen) {}
  
  public final void run()
  {
    en.a(this.a);
    en.b(this.a);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/eo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */