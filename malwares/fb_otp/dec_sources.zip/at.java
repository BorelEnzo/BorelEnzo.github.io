final class at
  extends ThreadLocal
{
  at(as paramas) {}
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/at.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */