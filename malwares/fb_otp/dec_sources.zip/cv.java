abstract interface cv
{
  public abstract boolean a();
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */