import java.util.Comparator;

public final class bv
  implements Comparator
{}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bv.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */