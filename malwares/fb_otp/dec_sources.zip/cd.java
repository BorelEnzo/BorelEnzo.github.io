import android.view.View;
import android.view.accessibility.AccessibilityRecord;

public final class cd
  extends cb
{
  public final void a(Object paramObject, View paramView, int paramInt)
  {
    ((AccessibilityRecord)paramObject).setSource(paramView, paramInt);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */