import android.graphics.Paint;
import android.os.Bundle;
import android.support.v4.view.AccessibilityDelegateCompat;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.v4.view.accessibility.AccessibilityNodeProviderCompat;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;

public abstract interface bo
{
  public abstract int a(View paramView);
  
  public abstract AccessibilityNodeProviderCompat a(View paramView);
  
  public abstract void a(View paramView);
  
  public abstract void a(View paramView, int paramInt);
  
  public abstract void a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  public abstract void a(View paramView, int paramInt, Paint paramPaint);
  
  public abstract void a(View paramView, AccessibilityDelegateCompat paramAccessibilityDelegateCompat);
  
  public abstract void a(View paramView, AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat);
  
  public abstract void a(View paramView, AccessibilityEvent paramAccessibilityEvent);
  
  public abstract void a(View paramView, Runnable paramRunnable);
  
  public abstract void a(View paramView, Runnable paramRunnable, long paramLong);
  
  public abstract void a(View paramView, boolean paramBoolean);
  
  public abstract boolean a(View paramView);
  
  public abstract boolean a(View paramView, int paramInt);
  
  public abstract boolean a(View paramView, int paramInt, Bundle paramBundle);
  
  public abstract int b(View paramView);
  
  public abstract void b(View paramView, int paramInt);
  
  public abstract void b(View paramView, AccessibilityEvent paramAccessibilityEvent);
  
  public abstract boolean b(View paramView, int paramInt);
  
  public abstract int c(View paramView);
  
  public abstract void c(View paramView, int paramInt);
  
  public abstract int d(View paramView);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */