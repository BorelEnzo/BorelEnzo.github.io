import java.net.Socket;

public final class as
  implements aw
{
  private ThreadLocal a = new at(this);
  
  public final int a()
  {
    return ((au)this.a.get()).a;
  }
  
  public final void a()
  {
    ((au)this.a.get()).a = -1;
  }
  
  public final void a(int paramInt) {}
  
  public final void a(int paramInt1, int paramInt2) {}
  
  public final void a(Socket paramSocket) {}
  
  public final void b(int paramInt)
  {
    ((au)this.a.get()).a = paramInt;
  }
  
  public final void b(Socket paramSocket) {}
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/as.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */