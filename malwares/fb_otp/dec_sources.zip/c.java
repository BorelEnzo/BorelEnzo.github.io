import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.pm.ResolveInfo;

public abstract interface c
{
  public abstract ResolveInfo a(AccessibilityServiceInfo paramAccessibilityServiceInfo);
  
  public abstract String a(AccessibilityServiceInfo paramAccessibilityServiceInfo);
  
  public abstract boolean a(AccessibilityServiceInfo paramAccessibilityServiceInfo);
  
  public abstract String b(AccessibilityServiceInfo paramAccessibilityServiceInfo);
  
  public abstract String c(AccessibilityServiceInfo paramAccessibilityServiceInfo);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */