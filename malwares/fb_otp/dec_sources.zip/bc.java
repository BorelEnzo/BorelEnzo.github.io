import android.widget.TextView;

public final class bc
  implements ba
{
  public final void a(TextView paramTextView)
  {
    paramTextView.setTransformationMethod(new be(paramTextView.getContext()));
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bc.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */