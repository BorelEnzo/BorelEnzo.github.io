package android.support.v4.widget;

import cq;

public abstract class SearchViewCompat$OnQueryTextListenerCompat
{
  final Object a = SearchViewCompat.a().a(this);
  
  public boolean onQueryTextChange(String paramString)
  {
    return false;
  }
  
  public boolean onQueryTextSubmit(String paramString)
  {
    return false;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/widget/SearchViewCompat$OnQueryTextListenerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */