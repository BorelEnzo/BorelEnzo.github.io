package android.support.v4.widget;

import cq;

public abstract class SearchViewCompat$OnCloseListenerCompat
{
  final Object a = SearchViewCompat.a().a(this);
  
  public boolean onClose()
  {
    return false;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/widget/SearchViewCompat$OnCloseListenerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */