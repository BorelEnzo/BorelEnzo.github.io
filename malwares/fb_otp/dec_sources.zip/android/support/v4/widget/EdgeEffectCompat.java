package android.support.v4.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.os.Build.VERSION;
import cj;
import ck;
import cl;

public class EdgeEffectCompat
{
  private static final cl jdField_a_of_type_Cl = new cj();
  private Object jdField_a_of_type_JavaLangObject;
  
  static
  {
    if (Build.VERSION.SDK_INT >= 14)
    {
      jdField_a_of_type_Cl = new ck();
      return;
    }
  }
  
  public EdgeEffectCompat(Context paramContext)
  {
    this.jdField_a_of_type_JavaLangObject = jdField_a_of_type_Cl.a(paramContext);
  }
  
  public boolean draw(Canvas paramCanvas)
  {
    return jdField_a_of_type_Cl.a(this.jdField_a_of_type_JavaLangObject, paramCanvas);
  }
  
  public void finish()
  {
    jdField_a_of_type_Cl.a(this.jdField_a_of_type_JavaLangObject);
  }
  
  public boolean isFinished()
  {
    return jdField_a_of_type_Cl.a(this.jdField_a_of_type_JavaLangObject);
  }
  
  public boolean onAbsorb(int paramInt)
  {
    return jdField_a_of_type_Cl.a(this.jdField_a_of_type_JavaLangObject, paramInt);
  }
  
  public boolean onPull(float paramFloat)
  {
    return jdField_a_of_type_Cl.a(this.jdField_a_of_type_JavaLangObject, paramFloat);
  }
  
  public boolean onRelease()
  {
    return jdField_a_of_type_Cl.b(this.jdField_a_of_type_JavaLangObject);
  }
  
  public void setSize(int paramInt1, int paramInt2)
  {
    jdField_a_of_type_Cl.a(this.jdField_a_of_type_JavaLangObject, paramInt1, paramInt2);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/widget/EdgeEffectCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */