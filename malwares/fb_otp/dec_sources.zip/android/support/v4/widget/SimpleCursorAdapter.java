package android.support.v4.widget;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class SimpleCursorAdapter
  extends ResourceCursorAdapter
{
  private int jdField_a_of_type_Int = -1;
  private SimpleCursorAdapter.CursorToStringConverter jdField_a_of_type_AndroidSupportV4WidgetSimpleCursorAdapter$CursorToStringConverter;
  private SimpleCursorAdapter.ViewBinder jdField_a_of_type_AndroidSupportV4WidgetSimpleCursorAdapter$ViewBinder;
  String[] jdField_a_of_type_ArrayOfJavaLangString;
  protected int[] mFrom;
  protected int[] mTo;
  
  public SimpleCursorAdapter(Context paramContext, int paramInt, Cursor paramCursor, String[] paramArrayOfString, int[] paramArrayOfInt)
  {
    super(paramContext, paramInt, paramCursor);
    this.mTo = paramArrayOfInt;
    this.jdField_a_of_type_ArrayOfJavaLangString = paramArrayOfString;
    a(paramArrayOfString);
  }
  
  public SimpleCursorAdapter(Context paramContext, int paramInt1, Cursor paramCursor, String[] paramArrayOfString, int[] paramArrayOfInt, int paramInt2)
  {
    super(paramContext, paramInt1, paramCursor, paramInt2);
    this.mTo = paramArrayOfInt;
    this.jdField_a_of_type_ArrayOfJavaLangString = paramArrayOfString;
    a(paramArrayOfString);
  }
  
  private void a(String[] paramArrayOfString)
  {
    if (this.mCursor != null)
    {
      int j = paramArrayOfString.length;
      if ((this.mFrom == null) || (this.mFrom.length != j)) {
        this.mFrom = new int[j];
      }
      int i = 0;
      while (i < j)
      {
        this.mFrom[i] = this.mCursor.getColumnIndexOrThrow(paramArrayOfString[i]);
        i += 1;
      }
    }
    this.mFrom = null;
  }
  
  public void bindView(View paramView, Context paramContext, Cursor paramCursor)
  {
    SimpleCursorAdapter.ViewBinder localViewBinder = this.jdField_a_of_type_AndroidSupportV4WidgetSimpleCursorAdapter$ViewBinder;
    int j = this.mTo.length;
    int[] arrayOfInt1 = this.mFrom;
    int[] arrayOfInt2 = this.mTo;
    int i = 0;
    View localView;
    if (i < j)
    {
      localView = paramView.findViewById(arrayOfInt2[i]);
      if (localView != null) {
        if (localViewBinder == null) {
          break label185;
        }
      }
    }
    label129:
    label150:
    label185:
    for (boolean bool = localViewBinder.setViewValue(localView, paramCursor, arrayOfInt1[i]);; bool = false)
    {
      if (!bool)
      {
        String str = paramCursor.getString(arrayOfInt1[i]);
        paramContext = str;
        if (str == null) {
          paramContext = "";
        }
        if (!(localView instanceof TextView)) {
          break label129;
        }
        setViewText((TextView)localView, paramContext);
      }
      for (;;)
      {
        i += 1;
        break;
        if (!(localView instanceof ImageView)) {
          break label150;
        }
        setViewImage((ImageView)localView, paramContext);
      }
      throw new IllegalStateException(localView.getClass().getName() + " is not a  view that can be bounds by this SimpleCursorAdapter");
      return;
    }
  }
  
  public void changeCursorAndColumns(Cursor paramCursor, String[] paramArrayOfString, int[] paramArrayOfInt)
  {
    this.jdField_a_of_type_ArrayOfJavaLangString = paramArrayOfString;
    this.mTo = paramArrayOfInt;
    super.changeCursor(paramCursor);
    a(this.jdField_a_of_type_ArrayOfJavaLangString);
  }
  
  public CharSequence convertToString(Cursor paramCursor)
  {
    if (this.jdField_a_of_type_AndroidSupportV4WidgetSimpleCursorAdapter$CursorToStringConverter != null) {
      return this.jdField_a_of_type_AndroidSupportV4WidgetSimpleCursorAdapter$CursorToStringConverter.convertToString(paramCursor);
    }
    if (this.jdField_a_of_type_Int >= 0) {
      return paramCursor.getString(this.jdField_a_of_type_Int);
    }
    return super.convertToString(paramCursor);
  }
  
  public SimpleCursorAdapter.CursorToStringConverter getCursorToStringConverter()
  {
    return this.jdField_a_of_type_AndroidSupportV4WidgetSimpleCursorAdapter$CursorToStringConverter;
  }
  
  public int getStringConversionColumn()
  {
    return this.jdField_a_of_type_Int;
  }
  
  public SimpleCursorAdapter.ViewBinder getViewBinder()
  {
    return this.jdField_a_of_type_AndroidSupportV4WidgetSimpleCursorAdapter$ViewBinder;
  }
  
  public void setCursorToStringConverter(SimpleCursorAdapter.CursorToStringConverter paramCursorToStringConverter)
  {
    this.jdField_a_of_type_AndroidSupportV4WidgetSimpleCursorAdapter$CursorToStringConverter = paramCursorToStringConverter;
  }
  
  public void setStringConversionColumn(int paramInt)
  {
    this.jdField_a_of_type_Int = paramInt;
  }
  
  public void setViewBinder(SimpleCursorAdapter.ViewBinder paramViewBinder)
  {
    this.jdField_a_of_type_AndroidSupportV4WidgetSimpleCursorAdapter$ViewBinder = paramViewBinder;
  }
  
  public void setViewImage(ImageView paramImageView, String paramString)
  {
    try
    {
      paramImageView.setImageResource(Integer.parseInt(paramString));
      return;
    }
    catch (NumberFormatException localNumberFormatException)
    {
      paramImageView.setImageURI(Uri.parse(paramString));
    }
  }
  
  public void setViewText(TextView paramTextView, String paramString)
  {
    paramTextView.setText(paramString);
  }
  
  public Cursor swapCursor(Cursor paramCursor)
  {
    paramCursor = super.swapCursor(paramCursor);
    a(this.jdField_a_of_type_ArrayOfJavaLangString);
    return paramCursor;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/widget/SimpleCursorAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */