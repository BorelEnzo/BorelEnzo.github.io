package android.support.v4.app;

import android.app.Notification;

public abstract class NotificationCompat$Style
{
  NotificationCompat.Builder a;
  public boolean a;
  public CharSequence b;
  public CharSequence c;
  
  public NotificationCompat$Style()
  {
    this.jdField_a_of_type_Boolean = false;
  }
  
  public Notification build()
  {
    Notification localNotification = null;
    if (this.jdField_a_of_type_AndroidSupportV4AppNotificationCompat$Builder != null) {
      localNotification = this.jdField_a_of_type_AndroidSupportV4AppNotificationCompat$Builder.build();
    }
    return localNotification;
  }
  
  public void setBuilder(NotificationCompat.Builder paramBuilder)
  {
    if (this.jdField_a_of_type_AndroidSupportV4AppNotificationCompat$Builder != paramBuilder)
    {
      this.jdField_a_of_type_AndroidSupportV4AppNotificationCompat$Builder = paramBuilder;
      if (this.jdField_a_of_type_AndroidSupportV4AppNotificationCompat$Builder != null) {
        this.jdField_a_of_type_AndroidSupportV4AppNotificationCompat$Builder.setStyle(this);
      }
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/app/NotificationCompat$Style.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */