package android.support.v4.app;

import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;

public abstract class FragmentPagerAdapter
  extends PagerAdapter
{
  private Fragment jdField_a_of_type_AndroidSupportV4AppFragment = null;
  private final FragmentManager jdField_a_of_type_AndroidSupportV4AppFragmentManager;
  private FragmentTransaction jdField_a_of_type_AndroidSupportV4AppFragmentTransaction = null;
  
  public FragmentPagerAdapter(FragmentManager paramFragmentManager)
  {
    this.jdField_a_of_type_AndroidSupportV4AppFragmentManager = paramFragmentManager;
  }
  
  private static String a(int paramInt, long paramLong)
  {
    return "android:switcher:" + paramInt + ":" + paramLong;
  }
  
  public void destroyItem(ViewGroup paramViewGroup, int paramInt, Object paramObject)
  {
    if (this.jdField_a_of_type_AndroidSupportV4AppFragmentTransaction == null) {
      this.jdField_a_of_type_AndroidSupportV4AppFragmentTransaction = this.jdField_a_of_type_AndroidSupportV4AppFragmentManager.beginTransaction();
    }
    this.jdField_a_of_type_AndroidSupportV4AppFragmentTransaction.detach((Fragment)paramObject);
  }
  
  public void finishUpdate(ViewGroup paramViewGroup)
  {
    if (this.jdField_a_of_type_AndroidSupportV4AppFragmentTransaction != null)
    {
      this.jdField_a_of_type_AndroidSupportV4AppFragmentTransaction.commitAllowingStateLoss();
      this.jdField_a_of_type_AndroidSupportV4AppFragmentTransaction = null;
      this.jdField_a_of_type_AndroidSupportV4AppFragmentManager.executePendingTransactions();
    }
  }
  
  public abstract Fragment getItem(int paramInt);
  
  public long getItemId(int paramInt)
  {
    return paramInt;
  }
  
  public Object instantiateItem(ViewGroup paramViewGroup, int paramInt)
  {
    if (this.jdField_a_of_type_AndroidSupportV4AppFragmentTransaction == null) {
      this.jdField_a_of_type_AndroidSupportV4AppFragmentTransaction = this.jdField_a_of_type_AndroidSupportV4AppFragmentManager.beginTransaction();
    }
    long l = getItemId(paramInt);
    Object localObject = a(paramViewGroup.getId(), l);
    localObject = this.jdField_a_of_type_AndroidSupportV4AppFragmentManager.findFragmentByTag((String)localObject);
    if (localObject != null) {
      this.jdField_a_of_type_AndroidSupportV4AppFragmentTransaction.attach((Fragment)localObject);
    }
    for (paramViewGroup = (ViewGroup)localObject;; paramViewGroup = (ViewGroup)localObject)
    {
      if (paramViewGroup != this.jdField_a_of_type_AndroidSupportV4AppFragment)
      {
        paramViewGroup.setMenuVisibility(false);
        paramViewGroup.setUserVisibleHint(false);
      }
      return paramViewGroup;
      localObject = getItem(paramInt);
      this.jdField_a_of_type_AndroidSupportV4AppFragmentTransaction.add(paramViewGroup.getId(), (Fragment)localObject, a(paramViewGroup.getId(), l));
    }
  }
  
  public boolean isViewFromObject(View paramView, Object paramObject)
  {
    return ((Fragment)paramObject).getView() == paramView;
  }
  
  public void restoreState(Parcelable paramParcelable, ClassLoader paramClassLoader) {}
  
  public Parcelable saveState()
  {
    return null;
  }
  
  public void setPrimaryItem(ViewGroup paramViewGroup, int paramInt, Object paramObject)
  {
    paramViewGroup = (Fragment)paramObject;
    if (paramViewGroup != this.jdField_a_of_type_AndroidSupportV4AppFragment)
    {
      if (this.jdField_a_of_type_AndroidSupportV4AppFragment != null)
      {
        this.jdField_a_of_type_AndroidSupportV4AppFragment.setMenuVisibility(false);
        this.jdField_a_of_type_AndroidSupportV4AppFragment.setUserVisibleHint(false);
      }
      if (paramViewGroup != null)
      {
        paramViewGroup.setMenuVisibility(true);
        paramViewGroup.setUserVisibleHint(true);
      }
      this.jdField_a_of_type_AndroidSupportV4AppFragment = paramViewGroup;
    }
  }
  
  public void startUpdate(ViewGroup paramViewGroup) {}
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/app/FragmentPagerAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */