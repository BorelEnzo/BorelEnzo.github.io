package android.support.v4.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Parcelable;
import android.text.Html;
import java.util.ArrayList;

public class ShareCompat$IntentBuilder
{
  private Activity jdField_a_of_type_AndroidAppActivity;
  private Intent jdField_a_of_type_AndroidContentIntent;
  private CharSequence jdField_a_of_type_JavaLangCharSequence;
  private ArrayList jdField_a_of_type_JavaUtilArrayList;
  private ArrayList b;
  private ArrayList c;
  private ArrayList d;
  
  private ShareCompat$IntentBuilder(Activity paramActivity)
  {
    this.jdField_a_of_type_AndroidAppActivity = paramActivity;
    this.jdField_a_of_type_AndroidContentIntent = new Intent().setAction("android.intent.action.SEND");
    this.jdField_a_of_type_AndroidContentIntent.putExtra("android.support.v4.app.EXTRA_CALLING_PACKAGE", paramActivity.getPackageName());
    this.jdField_a_of_type_AndroidContentIntent.putExtra("android.support.v4.app.EXTRA_CALLING_ACTIVITY", paramActivity.getComponentName());
    this.jdField_a_of_type_AndroidContentIntent.addFlags(524288);
  }
  
  private void a(String paramString, ArrayList paramArrayList)
  {
    String[] arrayOfString1 = this.jdField_a_of_type_AndroidContentIntent.getStringArrayExtra(paramString);
    if (arrayOfString1 != null) {}
    for (int i = arrayOfString1.length;; i = 0)
    {
      String[] arrayOfString2 = new String[paramArrayList.size() + i];
      paramArrayList.toArray(arrayOfString2);
      if (arrayOfString1 != null) {
        System.arraycopy(arrayOfString1, 0, arrayOfString2, paramArrayList.size(), i);
      }
      this.jdField_a_of_type_AndroidContentIntent.putExtra(paramString, arrayOfString2);
      return;
    }
  }
  
  private void a(String paramString, String[] paramArrayOfString)
  {
    Intent localIntent = getIntent();
    String[] arrayOfString1 = localIntent.getStringArrayExtra(paramString);
    if (arrayOfString1 != null) {}
    for (int i = arrayOfString1.length;; i = 0)
    {
      String[] arrayOfString2 = new String[paramArrayOfString.length + i];
      if (arrayOfString1 != null) {
        System.arraycopy(arrayOfString1, 0, arrayOfString2, 0, i);
      }
      System.arraycopy(paramArrayOfString, 0, arrayOfString2, i, paramArrayOfString.length);
      localIntent.putExtra(paramString, arrayOfString2);
      return;
    }
  }
  
  public static IntentBuilder from(Activity paramActivity)
  {
    return new IntentBuilder(paramActivity);
  }
  
  public final Activity a()
  {
    return this.jdField_a_of_type_AndroidAppActivity;
  }
  
  public IntentBuilder addEmailBcc(String paramString)
  {
    if (this.c == null) {
      this.c = new ArrayList();
    }
    this.c.add(paramString);
    return this;
  }
  
  public IntentBuilder addEmailBcc(String[] paramArrayOfString)
  {
    a("android.intent.extra.BCC", paramArrayOfString);
    return this;
  }
  
  public IntentBuilder addEmailCc(String paramString)
  {
    if (this.b == null) {
      this.b = new ArrayList();
    }
    this.b.add(paramString);
    return this;
  }
  
  public IntentBuilder addEmailCc(String[] paramArrayOfString)
  {
    a("android.intent.extra.CC", paramArrayOfString);
    return this;
  }
  
  public IntentBuilder addEmailTo(String paramString)
  {
    if (this.jdField_a_of_type_JavaUtilArrayList == null) {
      this.jdField_a_of_type_JavaUtilArrayList = new ArrayList();
    }
    this.jdField_a_of_type_JavaUtilArrayList.add(paramString);
    return this;
  }
  
  public IntentBuilder addEmailTo(String[] paramArrayOfString)
  {
    a("android.intent.extra.EMAIL", paramArrayOfString);
    return this;
  }
  
  public IntentBuilder addStream(Uri paramUri)
  {
    Uri localUri = (Uri)this.jdField_a_of_type_AndroidContentIntent.getParcelableExtra("android.intent.extra.STREAM");
    if (localUri == null) {
      return setStream(paramUri);
    }
    if (this.d == null) {
      this.d = new ArrayList();
    }
    if (localUri != null)
    {
      this.jdField_a_of_type_AndroidContentIntent.removeExtra("android.intent.extra.STREAM");
      this.d.add(localUri);
    }
    this.d.add(paramUri);
    return this;
  }
  
  public Intent createChooserIntent()
  {
    return Intent.createChooser(getIntent(), this.jdField_a_of_type_JavaLangCharSequence);
  }
  
  public Intent getIntent()
  {
    if (this.jdField_a_of_type_JavaUtilArrayList != null)
    {
      a("android.intent.extra.EMAIL", this.jdField_a_of_type_JavaUtilArrayList);
      this.jdField_a_of_type_JavaUtilArrayList = null;
    }
    if (this.b != null)
    {
      a("android.intent.extra.CC", this.b);
      this.b = null;
    }
    if (this.c != null)
    {
      a("android.intent.extra.BCC", this.c);
      this.c = null;
    }
    int i;
    if ((this.d != null) && (this.d.size() > 1))
    {
      i = 1;
      boolean bool = this.jdField_a_of_type_AndroidContentIntent.getAction().equals("android.intent.action.SEND_MULTIPLE");
      if ((i == 0) && (bool))
      {
        this.jdField_a_of_type_AndroidContentIntent.setAction("android.intent.action.SEND");
        if ((this.d == null) || (this.d.isEmpty())) {
          break label219;
        }
        this.jdField_a_of_type_AndroidContentIntent.putExtra("android.intent.extra.STREAM", (Parcelable)this.d.get(0));
        label155:
        this.d = null;
      }
      if ((i != 0) && (!bool))
      {
        this.jdField_a_of_type_AndroidContentIntent.setAction("android.intent.action.SEND_MULTIPLE");
        if ((this.d == null) || (this.d.isEmpty())) {
          break label231;
        }
        this.jdField_a_of_type_AndroidContentIntent.putParcelableArrayListExtra("android.intent.extra.STREAM", this.d);
      }
    }
    for (;;)
    {
      return this.jdField_a_of_type_AndroidContentIntent;
      i = 0;
      break;
      label219:
      this.jdField_a_of_type_AndroidContentIntent.removeExtra("android.intent.extra.STREAM");
      break label155;
      label231:
      this.jdField_a_of_type_AndroidContentIntent.removeExtra("android.intent.extra.STREAM");
    }
  }
  
  public IntentBuilder setChooserTitle(int paramInt)
  {
    return setChooserTitle(this.jdField_a_of_type_AndroidAppActivity.getText(paramInt));
  }
  
  public IntentBuilder setChooserTitle(CharSequence paramCharSequence)
  {
    this.jdField_a_of_type_JavaLangCharSequence = paramCharSequence;
    return this;
  }
  
  public IntentBuilder setEmailBcc(String[] paramArrayOfString)
  {
    this.jdField_a_of_type_AndroidContentIntent.putExtra("android.intent.extra.BCC", paramArrayOfString);
    return this;
  }
  
  public IntentBuilder setEmailCc(String[] paramArrayOfString)
  {
    this.jdField_a_of_type_AndroidContentIntent.putExtra("android.intent.extra.CC", paramArrayOfString);
    return this;
  }
  
  public IntentBuilder setEmailTo(String[] paramArrayOfString)
  {
    if (this.jdField_a_of_type_JavaUtilArrayList != null) {
      this.jdField_a_of_type_JavaUtilArrayList = null;
    }
    this.jdField_a_of_type_AndroidContentIntent.putExtra("android.intent.extra.EMAIL", paramArrayOfString);
    return this;
  }
  
  public IntentBuilder setHtmlText(String paramString)
  {
    this.jdField_a_of_type_AndroidContentIntent.putExtra("android.intent.extra.HTML_TEXT", paramString);
    if (!this.jdField_a_of_type_AndroidContentIntent.hasExtra("android.intent.extra.TEXT")) {
      setText(Html.fromHtml(paramString));
    }
    return this;
  }
  
  public IntentBuilder setStream(Uri paramUri)
  {
    if (!this.jdField_a_of_type_AndroidContentIntent.getAction().equals("android.intent.action.SEND")) {
      this.jdField_a_of_type_AndroidContentIntent.setAction("android.intent.action.SEND");
    }
    this.d = null;
    this.jdField_a_of_type_AndroidContentIntent.putExtra("android.intent.extra.STREAM", paramUri);
    return this;
  }
  
  public IntentBuilder setSubject(String paramString)
  {
    this.jdField_a_of_type_AndroidContentIntent.putExtra("android.intent.extra.SUBJECT", paramString);
    return this;
  }
  
  public IntentBuilder setText(CharSequence paramCharSequence)
  {
    this.jdField_a_of_type_AndroidContentIntent.putExtra("android.intent.extra.TEXT", paramCharSequence);
    return this;
  }
  
  public IntentBuilder setType(String paramString)
  {
    this.jdField_a_of_type_AndroidContentIntent.setType(paramString);
    return this;
  }
  
  public void startChooser()
  {
    this.jdField_a_of_type_AndroidAppActivity.startActivity(createChooserIntent());
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/app/ShareCompat$IntentBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */