package android.support.v4.app;

import E;
import U;
import android.app.Activity;
import android.content.ComponentCallbacks;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.util.DebugUtils;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnCreateContextMenuListener;
import android.view.ViewGroup;
import android.view.animation.Animation;
import h;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.HashMap;
import o;

public class Fragment
  implements ComponentCallbacks, View.OnCreateContextMenuListener
{
  private static final HashMap a;
  public E a;
  public Bundle a;
  public Fragment a;
  public FragmentActivity a;
  public SparseArray a;
  public View a;
  public ViewGroup a;
  public String a;
  public o a;
  public Bundle b;
  public Fragment b;
  public View b;
  public String b;
  public o b;
  public View c;
  public int d = 0;
  public int e;
  public int f;
  public boolean f;
  public int g;
  public boolean g;
  public int h;
  public boolean h;
  public int i;
  public boolean i;
  public int j;
  public boolean j;
  public int k;
  public boolean k;
  public int l;
  public boolean l;
  public boolean m;
  public boolean n;
  public boolean o;
  public boolean p;
  public boolean q = true;
  public boolean r;
  public boolean s;
  public boolean t = true;
  boolean u;
  boolean v;
  
  static
  {
    jdField_a_of_type_JavaUtilHashMap = new HashMap();
  }
  
  public Fragment()
  {
    this.jdField_f_of_type_Int = -1;
    this.jdField_g_of_type_Int = -1;
  }
  
  public static Fragment instantiate(Context paramContext, String paramString)
  {
    return instantiate(paramContext, paramString, null);
  }
  
  public static Fragment instantiate(Context paramContext, String paramString, Bundle paramBundle)
  {
    try
    {
      Class localClass2 = (Class)jdField_a_of_type_JavaUtilHashMap.get(paramString);
      Class localClass1 = localClass2;
      if (localClass2 == null)
      {
        localClass1 = paramContext.getClassLoader().loadClass(paramString);
        jdField_a_of_type_JavaUtilHashMap.put(paramString, localClass1);
      }
      paramContext = (Fragment)localClass1.newInstance();
      if (paramBundle != null)
      {
        paramBundle.setClassLoader(paramContext.getClass().getClassLoader());
        paramContext.jdField_b_of_type_AndroidOsBundle = paramBundle;
      }
      return paramContext;
    }
    catch (ClassNotFoundException paramContext)
    {
      throw new Fragment.InstantiationException("Unable to instantiate fragment " + paramString + ": make sure class name exists, is public, and has an empty constructor that is public", paramContext);
    }
    catch (InstantiationException paramContext)
    {
      throw new Fragment.InstantiationException("Unable to instantiate fragment " + paramString + ": make sure class name exists, is public, and has an empty constructor that is public", paramContext);
    }
    catch (IllegalAccessException paramContext)
    {
      throw new Fragment.InstantiationException("Unable to instantiate fragment " + paramString + ": make sure class name exists, is public, and has an empty constructor that is public", paramContext);
    }
  }
  
  private void j()
  {
    this.jdField_b_of_type_O = new o();
    this.jdField_b_of_type_O.a(this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity, new h(this), this);
  }
  
  public final View a(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle)
  {
    if (this.jdField_b_of_type_O != null) {
      this.jdField_b_of_type_O.b();
    }
    return onCreateView(paramLayoutInflater, paramViewGroup, paramBundle);
  }
  
  public final void a()
  {
    this.jdField_f_of_type_Int = -1;
    this.jdField_a_of_type_JavaLangString = null;
    this.jdField_f_of_type_Boolean = false;
    this.jdField_g_of_type_Boolean = false;
    this.jdField_h_of_type_Boolean = false;
    this.jdField_i_of_type_Boolean = false;
    this.jdField_j_of_type_Boolean = false;
    this.jdField_k_of_type_Boolean = false;
    this.jdField_i_of_type_Int = 0;
    this.jdField_a_of_type_O = null;
    this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity = null;
    this.jdField_j_of_type_Int = 0;
    this.jdField_k_of_type_Int = 0;
    this.jdField_b_of_type_JavaLangString = null;
    this.jdField_l_of_type_Boolean = false;
    this.m = false;
    this.o = false;
    this.jdField_a_of_type_E = null;
    this.u = false;
    this.v = false;
  }
  
  public final void a(int paramInt, Fragment paramFragment)
  {
    this.jdField_f_of_type_Int = paramInt;
    if (paramFragment != null)
    {
      this.jdField_a_of_type_JavaLangString = (paramFragment.jdField_a_of_type_JavaLangString + ":" + this.jdField_f_of_type_Int);
      return;
    }
    this.jdField_a_of_type_JavaLangString = ("android:fragment:" + this.jdField_f_of_type_Int);
  }
  
  public final void a(Configuration paramConfiguration)
  {
    onConfigurationChanged(paramConfiguration);
    if (this.jdField_b_of_type_O != null) {
      this.jdField_b_of_type_O.a(paramConfiguration);
    }
  }
  
  public final void a(Bundle paramBundle)
  {
    if (this.jdField_a_of_type_AndroidUtilSparseArray != null)
    {
      this.c.restoreHierarchyState(this.jdField_a_of_type_AndroidUtilSparseArray);
      this.jdField_a_of_type_AndroidUtilSparseArray = null;
    }
    this.r = false;
    onViewStateRestored(paramBundle);
    if (!this.r) {
      throw new U("Fragment " + this + " did not call through to super.onViewStateRestored()");
    }
  }
  
  public final void a(Menu paramMenu)
  {
    if (!this.jdField_l_of_type_Boolean)
    {
      if ((this.p) && (this.q)) {
        onOptionsMenuClosed(paramMenu);
      }
      if (this.jdField_b_of_type_O != null) {
        this.jdField_b_of_type_O.a(paramMenu);
      }
    }
  }
  
  public final boolean a()
  {
    return this.jdField_i_of_type_Int > 0;
  }
  
  public final boolean a(Menu paramMenu)
  {
    boolean bool2 = false;
    boolean bool3 = false;
    if (!this.jdField_l_of_type_Boolean)
    {
      boolean bool1 = bool3;
      if (this.p)
      {
        bool1 = bool3;
        if (this.q)
        {
          bool1 = true;
          onPrepareOptionsMenu(paramMenu);
        }
      }
      bool2 = bool1;
      if (this.jdField_b_of_type_O != null) {
        bool2 = bool1 | this.jdField_b_of_type_O.a(paramMenu);
      }
    }
    return bool2;
  }
  
  public final boolean a(Menu paramMenu, MenuInflater paramMenuInflater)
  {
    boolean bool2 = false;
    boolean bool3 = false;
    if (!this.jdField_l_of_type_Boolean)
    {
      boolean bool1 = bool3;
      if (this.p)
      {
        bool1 = bool3;
        if (this.q)
        {
          bool1 = true;
          onCreateOptionsMenu(paramMenu, paramMenuInflater);
        }
      }
      bool2 = bool1;
      if (this.jdField_b_of_type_O != null) {
        bool2 = bool1 | this.jdField_b_of_type_O.a(paramMenu, paramMenuInflater);
      }
    }
    return bool2;
  }
  
  public final boolean a(MenuItem paramMenuItem)
  {
    if (!this.jdField_l_of_type_Boolean)
    {
      if ((this.p) && (this.q) && (onOptionsItemSelected(paramMenuItem))) {}
      while ((this.jdField_b_of_type_O != null) && (this.jdField_b_of_type_O.a(paramMenuItem))) {
        return true;
      }
    }
    return false;
  }
  
  public final void b()
  {
    if (this.jdField_b_of_type_O != null)
    {
      this.jdField_b_of_type_O.b();
      this.jdField_b_of_type_O.a();
    }
    this.r = false;
    onStart();
    if (!this.r) {
      throw new U("Fragment " + this + " did not call through to super.onStart()");
    }
    if (this.jdField_b_of_type_O != null) {
      this.jdField_b_of_type_O.e();
    }
    if (this.jdField_a_of_type_E != null) {
      this.jdField_a_of_type_E.f();
    }
  }
  
  public final void b(Bundle paramBundle)
  {
    if (this.jdField_b_of_type_O != null) {
      this.jdField_b_of_type_O.b();
    }
    this.r = false;
    onCreate(paramBundle);
    if (!this.r) {
      throw new U("Fragment " + this + " did not call through to super.onCreate()");
    }
    if (paramBundle != null)
    {
      paramBundle = paramBundle.getParcelable("android:support:fragments");
      if (paramBundle != null)
      {
        if (this.jdField_b_of_type_O == null) {
          j();
        }
        this.jdField_b_of_type_O.a(paramBundle, null);
        this.jdField_b_of_type_O.c();
      }
    }
  }
  
  public final boolean b(MenuItem paramMenuItem)
  {
    if (!this.jdField_l_of_type_Boolean)
    {
      if (onContextItemSelected(paramMenuItem)) {}
      while ((this.jdField_b_of_type_O != null) && (this.jdField_b_of_type_O.b(paramMenuItem))) {
        return true;
      }
    }
    return false;
  }
  
  public final void c()
  {
    if (this.jdField_b_of_type_O != null)
    {
      this.jdField_b_of_type_O.b();
      this.jdField_b_of_type_O.a();
    }
    this.r = false;
    onResume();
    if (!this.r) {
      throw new U("Fragment " + this + " did not call through to super.onResume()");
    }
    if (this.jdField_b_of_type_O != null)
    {
      this.jdField_b_of_type_O.f();
      this.jdField_b_of_type_O.a();
    }
  }
  
  public final void c(Bundle paramBundle)
  {
    if (this.jdField_b_of_type_O != null) {
      this.jdField_b_of_type_O.b();
    }
    this.r = false;
    onActivityCreated(paramBundle);
    if (!this.r) {
      throw new U("Fragment " + this + " did not call through to super.onActivityCreated()");
    }
    if (this.jdField_b_of_type_O != null) {
      this.jdField_b_of_type_O.d();
    }
  }
  
  public final void d()
  {
    onLowMemory();
    if (this.jdField_b_of_type_O != null) {
      this.jdField_b_of_type_O.l();
    }
  }
  
  public final void d(Bundle paramBundle)
  {
    onSaveInstanceState(paramBundle);
    if (this.jdField_b_of_type_O != null)
    {
      Parcelable localParcelable = this.jdField_b_of_type_O.a();
      if (localParcelable != null) {
        paramBundle.putParcelable("android:support:fragments", localParcelable);
      }
    }
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mFragmentId=#");
    paramPrintWriter.print(Integer.toHexString(this.jdField_j_of_type_Int));
    paramPrintWriter.print(" mContainerId=#");
    paramPrintWriter.print(Integer.toHexString(this.jdField_k_of_type_Int));
    paramPrintWriter.print(" mTag=");
    paramPrintWriter.println(this.jdField_b_of_type_JavaLangString);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mState=");
    paramPrintWriter.print(this.d);
    paramPrintWriter.print(" mIndex=");
    paramPrintWriter.print(this.jdField_f_of_type_Int);
    paramPrintWriter.print(" mWho=");
    paramPrintWriter.print(this.jdField_a_of_type_JavaLangString);
    paramPrintWriter.print(" mBackStackNesting=");
    paramPrintWriter.println(this.jdField_i_of_type_Int);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mAdded=");
    paramPrintWriter.print(this.jdField_f_of_type_Boolean);
    paramPrintWriter.print(" mRemoving=");
    paramPrintWriter.print(this.jdField_g_of_type_Boolean);
    paramPrintWriter.print(" mResumed=");
    paramPrintWriter.print(this.jdField_h_of_type_Boolean);
    paramPrintWriter.print(" mFromLayout=");
    paramPrintWriter.print(this.jdField_i_of_type_Boolean);
    paramPrintWriter.print(" mInLayout=");
    paramPrintWriter.println(this.jdField_j_of_type_Boolean);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mHidden=");
    paramPrintWriter.print(this.jdField_l_of_type_Boolean);
    paramPrintWriter.print(" mDetached=");
    paramPrintWriter.print(this.m);
    paramPrintWriter.print(" mMenuVisible=");
    paramPrintWriter.print(this.q);
    paramPrintWriter.print(" mHasMenu=");
    paramPrintWriter.println(this.p);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mRetainInstance=");
    paramPrintWriter.print(this.n);
    paramPrintWriter.print(" mRetaining=");
    paramPrintWriter.print(this.o);
    paramPrintWriter.print(" mUserVisibleHint=");
    paramPrintWriter.println(this.t);
    if (this.jdField_a_of_type_O != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mFragmentManager=");
      paramPrintWriter.println(this.jdField_a_of_type_O);
    }
    if (this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mActivity=");
      paramPrintWriter.println(this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity);
    }
    if (this.jdField_b_of_type_AndroidSupportV4AppFragment != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mParentFragment=");
      paramPrintWriter.println(this.jdField_b_of_type_AndroidSupportV4AppFragment);
    }
    if (this.jdField_b_of_type_AndroidOsBundle != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mArguments=");
      paramPrintWriter.println(this.jdField_b_of_type_AndroidOsBundle);
    }
    if (this.jdField_a_of_type_AndroidOsBundle != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedFragmentState=");
      paramPrintWriter.println(this.jdField_a_of_type_AndroidOsBundle);
    }
    if (this.jdField_a_of_type_AndroidUtilSparseArray != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mSavedViewState=");
      paramPrintWriter.println(this.jdField_a_of_type_AndroidUtilSparseArray);
    }
    if (this.jdField_a_of_type_AndroidSupportV4AppFragment != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mTarget=");
      paramPrintWriter.print(this.jdField_a_of_type_AndroidSupportV4AppFragment);
      paramPrintWriter.print(" mTargetRequestCode=");
      paramPrintWriter.println(this.jdField_h_of_type_Int);
    }
    if (this.jdField_l_of_type_Int != 0)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mNextAnim=");
      paramPrintWriter.println(this.jdField_l_of_type_Int);
    }
    if (this.jdField_a_of_type_AndroidViewViewGroup != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mContainer=");
      paramPrintWriter.println(this.jdField_a_of_type_AndroidViewViewGroup);
    }
    if (this.jdField_b_of_type_AndroidViewView != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mView=");
      paramPrintWriter.println(this.jdField_b_of_type_AndroidViewView);
    }
    if (this.c != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mInnerView=");
      paramPrintWriter.println(this.jdField_b_of_type_AndroidViewView);
    }
    if (this.jdField_a_of_type_AndroidViewView != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mAnimatingAway=");
      paramPrintWriter.println(this.jdField_a_of_type_AndroidViewView);
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mStateAfterAnimating=");
      paramPrintWriter.println(this.e);
    }
    if (this.jdField_a_of_type_E != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Loader Manager:");
      this.jdField_a_of_type_E.dump(paramString + "  ", paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    }
    if (this.jdField_b_of_type_O != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Child " + this.jdField_b_of_type_O + ":");
      this.jdField_b_of_type_O.dump(paramString + "  ", paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    }
  }
  
  public final void e()
  {
    if (this.jdField_b_of_type_O != null) {
      this.jdField_b_of_type_O.g();
    }
    this.r = false;
    onPause();
    if (!this.r) {
      throw new U("Fragment " + this + " did not call through to super.onPause()");
    }
  }
  
  public final boolean equals(Object paramObject)
  {
    return super.equals(paramObject);
  }
  
  public final void f()
  {
    if (this.jdField_b_of_type_O != null) {
      this.jdField_b_of_type_O.h();
    }
    this.r = false;
    onStop();
    if (!this.r) {
      throw new U("Fragment " + this + " did not call through to super.onStop()");
    }
  }
  
  public final void g()
  {
    if (this.jdField_b_of_type_O != null) {
      this.jdField_b_of_type_O.i();
    }
    if (this.u)
    {
      this.u = false;
      if (!this.v)
      {
        this.v = true;
        this.jdField_a_of_type_E = this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.a(this.jdField_a_of_type_JavaLangString, this.u, false);
      }
      if (this.jdField_a_of_type_E != null)
      {
        if (this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.e) {
          break label83;
        }
        this.jdField_a_of_type_E.b();
      }
    }
    return;
    label83:
    this.jdField_a_of_type_E.c();
  }
  
  public final FragmentActivity getActivity()
  {
    return this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity;
  }
  
  public final Bundle getArguments()
  {
    return this.jdField_b_of_type_AndroidOsBundle;
  }
  
  public final FragmentManager getChildFragmentManager()
  {
    if (this.jdField_b_of_type_O == null)
    {
      j();
      if (this.d < 5) {
        break label31;
      }
      this.jdField_b_of_type_O.f();
    }
    for (;;)
    {
      return this.jdField_b_of_type_O;
      label31:
      if (this.d >= 4) {
        this.jdField_b_of_type_O.e();
      } else if (this.d >= 2) {
        this.jdField_b_of_type_O.d();
      } else if (this.d > 0) {
        this.jdField_b_of_type_O.c();
      }
    }
  }
  
  public final FragmentManager getFragmentManager()
  {
    return this.jdField_a_of_type_O;
  }
  
  public final int getId()
  {
    return this.jdField_j_of_type_Int;
  }
  
  public LayoutInflater getLayoutInflater(Bundle paramBundle)
  {
    return this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.getLayoutInflater();
  }
  
  public LoaderManager getLoaderManager()
  {
    if (this.jdField_a_of_type_E != null) {
      return this.jdField_a_of_type_E;
    }
    if (this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity == null) {
      throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    }
    this.v = true;
    this.jdField_a_of_type_E = this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.a(this.jdField_a_of_type_JavaLangString, this.u, true);
    return this.jdField_a_of_type_E;
  }
  
  public final Fragment getParentFragment()
  {
    return this.jdField_b_of_type_AndroidSupportV4AppFragment;
  }
  
  public final Resources getResources()
  {
    if (this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity == null) {
      throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    }
    return this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.getResources();
  }
  
  public final boolean getRetainInstance()
  {
    return this.n;
  }
  
  public final String getString(int paramInt)
  {
    return getResources().getString(paramInt);
  }
  
  public final String getString(int paramInt, Object... paramVarArgs)
  {
    return getResources().getString(paramInt, paramVarArgs);
  }
  
  public final String getTag()
  {
    return this.jdField_b_of_type_JavaLangString;
  }
  
  public final Fragment getTargetFragment()
  {
    return this.jdField_a_of_type_AndroidSupportV4AppFragment;
  }
  
  public final int getTargetRequestCode()
  {
    return this.jdField_h_of_type_Int;
  }
  
  public final CharSequence getText(int paramInt)
  {
    return getResources().getText(paramInt);
  }
  
  public boolean getUserVisibleHint()
  {
    return this.t;
  }
  
  public View getView()
  {
    return this.jdField_b_of_type_AndroidViewView;
  }
  
  public final void h()
  {
    if (this.jdField_b_of_type_O != null) {
      this.jdField_b_of_type_O.j();
    }
    this.r = false;
    onDestroyView();
    if (!this.r) {
      throw new U("Fragment " + this + " did not call through to super.onDestroyView()");
    }
    if (this.jdField_a_of_type_E != null) {
      this.jdField_a_of_type_E.e();
    }
  }
  
  public final int hashCode()
  {
    return super.hashCode();
  }
  
  public final void i()
  {
    if (this.jdField_b_of_type_O != null) {
      this.jdField_b_of_type_O.k();
    }
    this.r = false;
    onDestroy();
    if (!this.r) {
      throw new U("Fragment " + this + " did not call through to super.onDestroy()");
    }
  }
  
  public final boolean isAdded()
  {
    return (this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity != null) && (this.jdField_f_of_type_Boolean);
  }
  
  public final boolean isDetached()
  {
    return this.m;
  }
  
  public final boolean isHidden()
  {
    return this.jdField_l_of_type_Boolean;
  }
  
  public final boolean isInLayout()
  {
    return this.jdField_j_of_type_Boolean;
  }
  
  public final boolean isRemoving()
  {
    return this.jdField_g_of_type_Boolean;
  }
  
  public final boolean isResumed()
  {
    return this.jdField_h_of_type_Boolean;
  }
  
  public final boolean isVisible()
  {
    return (isAdded()) && (!isHidden()) && (this.jdField_b_of_type_AndroidViewView != null) && (this.jdField_b_of_type_AndroidViewView.getWindowToken() != null) && (this.jdField_b_of_type_AndroidViewView.getVisibility() == 0);
  }
  
  public void onActivityCreated(Bundle paramBundle)
  {
    this.r = true;
  }
  
  public void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent) {}
  
  public void onAttach(Activity paramActivity)
  {
    this.r = true;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    this.r = true;
  }
  
  public boolean onContextItemSelected(MenuItem paramMenuItem)
  {
    return false;
  }
  
  public void onCreate(Bundle paramBundle)
  {
    this.r = true;
  }
  
  public Animation onCreateAnimation(int paramInt1, boolean paramBoolean, int paramInt2)
  {
    return null;
  }
  
  public void onCreateContextMenu(ContextMenu paramContextMenu, View paramView, ContextMenu.ContextMenuInfo paramContextMenuInfo)
  {
    getActivity().onCreateContextMenu(paramContextMenu, paramView, paramContextMenuInfo);
  }
  
  public void onCreateOptionsMenu(Menu paramMenu, MenuInflater paramMenuInflater) {}
  
  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle)
  {
    return null;
  }
  
  public void onDestroy()
  {
    this.r = true;
    if (!this.v)
    {
      this.v = true;
      this.jdField_a_of_type_E = this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.a(this.jdField_a_of_type_JavaLangString, this.u, false);
    }
    if (this.jdField_a_of_type_E != null) {
      this.jdField_a_of_type_E.g();
    }
  }
  
  public void onDestroyOptionsMenu() {}
  
  public void onDestroyView()
  {
    this.r = true;
  }
  
  public void onDetach()
  {
    this.r = true;
  }
  
  public void onHiddenChanged(boolean paramBoolean) {}
  
  public void onInflate(Activity paramActivity, AttributeSet paramAttributeSet, Bundle paramBundle)
  {
    this.r = true;
  }
  
  public void onLowMemory()
  {
    this.r = true;
  }
  
  public boolean onOptionsItemSelected(MenuItem paramMenuItem)
  {
    return false;
  }
  
  public void onOptionsMenuClosed(Menu paramMenu) {}
  
  public void onPause()
  {
    this.r = true;
  }
  
  public void onPrepareOptionsMenu(Menu paramMenu) {}
  
  public void onResume()
  {
    this.r = true;
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {}
  
  public void onStart()
  {
    this.r = true;
    if (!this.u)
    {
      this.u = true;
      if (!this.v)
      {
        this.v = true;
        this.jdField_a_of_type_E = this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.a(this.jdField_a_of_type_JavaLangString, this.u, false);
      }
      if (this.jdField_a_of_type_E != null) {
        this.jdField_a_of_type_E.a();
      }
    }
  }
  
  public void onStop()
  {
    this.r = true;
  }
  
  public void onViewCreated(View paramView, Bundle paramBundle) {}
  
  public void onViewStateRestored(Bundle paramBundle)
  {
    this.r = true;
  }
  
  public void registerForContextMenu(View paramView)
  {
    paramView.setOnCreateContextMenuListener(this);
  }
  
  public void setArguments(Bundle paramBundle)
  {
    if (this.jdField_f_of_type_Int >= 0) {
      throw new IllegalStateException("Fragment already active");
    }
    this.jdField_b_of_type_AndroidOsBundle = paramBundle;
  }
  
  public void setHasOptionsMenu(boolean paramBoolean)
  {
    if (this.p != paramBoolean)
    {
      this.p = paramBoolean;
      if ((isAdded()) && (!isHidden())) {
        this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.supportInvalidateOptionsMenu();
      }
    }
  }
  
  public void setInitialSavedState(Fragment.SavedState paramSavedState)
  {
    if (this.jdField_f_of_type_Int >= 0) {
      throw new IllegalStateException("Fragment already active");
    }
    if ((paramSavedState != null) && (paramSavedState.jdField_a_of_type_AndroidOsBundle != null)) {}
    for (paramSavedState = paramSavedState.jdField_a_of_type_AndroidOsBundle;; paramSavedState = null)
    {
      this.jdField_a_of_type_AndroidOsBundle = paramSavedState;
      return;
    }
  }
  
  public void setMenuVisibility(boolean paramBoolean)
  {
    if (this.q != paramBoolean)
    {
      this.q = paramBoolean;
      if ((this.p) && (isAdded()) && (!isHidden())) {
        this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.supportInvalidateOptionsMenu();
      }
    }
  }
  
  public void setRetainInstance(boolean paramBoolean)
  {
    if ((paramBoolean) && (this.jdField_b_of_type_AndroidSupportV4AppFragment != null)) {
      throw new IllegalStateException("Can't retain fragements that are nested in other fragments");
    }
    this.n = paramBoolean;
  }
  
  public void setTargetFragment(Fragment paramFragment, int paramInt)
  {
    this.jdField_a_of_type_AndroidSupportV4AppFragment = paramFragment;
    this.jdField_h_of_type_Int = paramInt;
  }
  
  public void setUserVisibleHint(boolean paramBoolean)
  {
    if ((!this.t) && (paramBoolean) && (this.d < 4)) {
      this.jdField_a_of_type_O.a(this);
    }
    this.t = paramBoolean;
    if (!paramBoolean) {}
    for (paramBoolean = true;; paramBoolean = false)
    {
      this.s = paramBoolean;
      return;
    }
  }
  
  public void startActivity(Intent paramIntent)
  {
    if (this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity == null) {
      throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    }
    this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.startActivityFromFragment(this, paramIntent, -1);
  }
  
  public void startActivityForResult(Intent paramIntent, int paramInt)
  {
    if (this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity == null) {
      throw new IllegalStateException("Fragment " + this + " not attached to Activity");
    }
    this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.startActivityFromFragment(this, paramIntent, paramInt);
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(128);
    DebugUtils.buildShortClassTag(this, localStringBuilder);
    if (this.jdField_f_of_type_Int >= 0)
    {
      localStringBuilder.append(" #");
      localStringBuilder.append(this.jdField_f_of_type_Int);
    }
    if (this.jdField_j_of_type_Int != 0)
    {
      localStringBuilder.append(" id=0x");
      localStringBuilder.append(Integer.toHexString(this.jdField_j_of_type_Int));
    }
    if (this.jdField_b_of_type_JavaLangString != null)
    {
      localStringBuilder.append(" ");
      localStringBuilder.append(this.jdField_b_of_type_JavaLangString);
    }
    localStringBuilder.append('}');
    return localStringBuilder.toString();
  }
  
  public void unregisterForContextMenu(View paramView)
  {
    paramView.setOnCreateContextMenuListener(null);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/app/Fragment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */