package android.support.v4.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnDismissListener;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;

public class DialogFragment
  extends Fragment
  implements DialogInterface.OnCancelListener, DialogInterface.OnDismissListener
{
  public static final int STYLE_NORMAL = 0;
  public static final int STYLE_NO_FRAME = 2;
  public static final int STYLE_NO_INPUT = 3;
  public static final int STYLE_NO_TITLE = 1;
  int jdField_a_of_type_Int = 0;
  Dialog jdField_a_of_type_AndroidAppDialog;
  boolean jdField_a_of_type_Boolean = true;
  int jdField_b_of_type_Int = 0;
  boolean jdField_b_of_type_Boolean = true;
  int jdField_c_of_type_Int = -1;
  boolean jdField_c_of_type_Boolean;
  boolean d;
  boolean e;
  
  private void a(boolean paramBoolean)
  {
    if (this.d) {
      return;
    }
    this.d = true;
    this.e = false;
    if (this.jdField_a_of_type_AndroidAppDialog != null)
    {
      this.jdField_a_of_type_AndroidAppDialog.dismiss();
      this.jdField_a_of_type_AndroidAppDialog = null;
    }
    this.jdField_c_of_type_Boolean = true;
    if (this.jdField_c_of_type_Int >= 0)
    {
      getFragmentManager().popBackStack(this.jdField_c_of_type_Int, 1);
      this.jdField_c_of_type_Int = -1;
      return;
    }
    FragmentTransaction localFragmentTransaction = getFragmentManager().beginTransaction();
    localFragmentTransaction.remove(this);
    if (paramBoolean)
    {
      localFragmentTransaction.commitAllowingStateLoss();
      return;
    }
    localFragmentTransaction.commit();
  }
  
  public void dismiss()
  {
    a(false);
  }
  
  public void dismissAllowingStateLoss()
  {
    a(true);
  }
  
  public Dialog getDialog()
  {
    return this.jdField_a_of_type_AndroidAppDialog;
  }
  
  public LayoutInflater getLayoutInflater(Bundle paramBundle)
  {
    if (!this.jdField_b_of_type_Boolean) {
      return super.getLayoutInflater(paramBundle);
    }
    this.jdField_a_of_type_AndroidAppDialog = onCreateDialog(paramBundle);
    switch (this.jdField_a_of_type_Int)
    {
    }
    while (this.jdField_a_of_type_AndroidAppDialog != null)
    {
      return (LayoutInflater)this.jdField_a_of_type_AndroidAppDialog.getContext().getSystemService("layout_inflater");
      this.jdField_a_of_type_AndroidAppDialog.getWindow().addFlags(24);
      this.jdField_a_of_type_AndroidAppDialog.requestWindowFeature(1);
    }
    return (LayoutInflater)this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.getSystemService("layout_inflater");
  }
  
  public boolean getShowsDialog()
  {
    return this.jdField_b_of_type_Boolean;
  }
  
  public int getTheme()
  {
    return this.jdField_b_of_type_Int;
  }
  
  public boolean isCancelable()
  {
    return this.jdField_a_of_type_Boolean;
  }
  
  public void onActivityCreated(Bundle paramBundle)
  {
    super.onActivityCreated(paramBundle);
    if (!this.jdField_b_of_type_Boolean) {}
    do
    {
      do
      {
        return;
        View localView = getView();
        if (localView != null)
        {
          if (localView.getParent() != null) {
            throw new IllegalStateException("DialogFragment can not be attached to a container view");
          }
          this.jdField_a_of_type_AndroidAppDialog.setContentView(localView);
        }
        this.jdField_a_of_type_AndroidAppDialog.setOwnerActivity(getActivity());
        this.jdField_a_of_type_AndroidAppDialog.setCancelable(this.jdField_a_of_type_Boolean);
        this.jdField_a_of_type_AndroidAppDialog.setOnCancelListener(this);
        this.jdField_a_of_type_AndroidAppDialog.setOnDismissListener(this);
      } while (paramBundle == null);
      paramBundle = paramBundle.getBundle("android:savedDialogState");
    } while (paramBundle == null);
    this.jdField_a_of_type_AndroidAppDialog.onRestoreInstanceState(paramBundle);
  }
  
  public void onAttach(Activity paramActivity)
  {
    super.onAttach(paramActivity);
    if (!this.e) {
      this.d = false;
    }
  }
  
  public void onCancel(DialogInterface paramDialogInterface) {}
  
  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    if (this.k == 0) {}
    for (boolean bool = true;; bool = false)
    {
      this.jdField_b_of_type_Boolean = bool;
      if (paramBundle != null)
      {
        this.jdField_a_of_type_Int = paramBundle.getInt("android:style", 0);
        this.jdField_b_of_type_Int = paramBundle.getInt("android:theme", 0);
        this.jdField_a_of_type_Boolean = paramBundle.getBoolean("android:cancelable", true);
        this.jdField_b_of_type_Boolean = paramBundle.getBoolean("android:showsDialog", this.jdField_b_of_type_Boolean);
        this.jdField_c_of_type_Int = paramBundle.getInt("android:backStackId", -1);
      }
      return;
    }
  }
  
  public Dialog onCreateDialog(Bundle paramBundle)
  {
    return new Dialog(getActivity(), getTheme());
  }
  
  public void onDestroyView()
  {
    super.onDestroyView();
    if (this.jdField_a_of_type_AndroidAppDialog != null)
    {
      this.jdField_c_of_type_Boolean = true;
      this.jdField_a_of_type_AndroidAppDialog.dismiss();
      this.jdField_a_of_type_AndroidAppDialog = null;
    }
  }
  
  public void onDetach()
  {
    super.onDetach();
    if ((!this.e) && (!this.d)) {
      this.d = true;
    }
  }
  
  public void onDismiss(DialogInterface paramDialogInterface)
  {
    if (!this.jdField_c_of_type_Boolean) {
      a(true);
    }
  }
  
  public void onSaveInstanceState(Bundle paramBundle)
  {
    super.onSaveInstanceState(paramBundle);
    if (this.jdField_a_of_type_AndroidAppDialog != null)
    {
      Bundle localBundle = this.jdField_a_of_type_AndroidAppDialog.onSaveInstanceState();
      if (localBundle != null) {
        paramBundle.putBundle("android:savedDialogState", localBundle);
      }
    }
    if (this.jdField_a_of_type_Int != 0) {
      paramBundle.putInt("android:style", this.jdField_a_of_type_Int);
    }
    if (this.jdField_b_of_type_Int != 0) {
      paramBundle.putInt("android:theme", this.jdField_b_of_type_Int);
    }
    if (!this.jdField_a_of_type_Boolean) {
      paramBundle.putBoolean("android:cancelable", this.jdField_a_of_type_Boolean);
    }
    if (!this.jdField_b_of_type_Boolean) {
      paramBundle.putBoolean("android:showsDialog", this.jdField_b_of_type_Boolean);
    }
    if (this.jdField_c_of_type_Int != -1) {
      paramBundle.putInt("android:backStackId", this.jdField_c_of_type_Int);
    }
  }
  
  public void onStart()
  {
    super.onStart();
    if (this.jdField_a_of_type_AndroidAppDialog != null)
    {
      this.jdField_c_of_type_Boolean = false;
      this.jdField_a_of_type_AndroidAppDialog.show();
    }
  }
  
  public void onStop()
  {
    super.onStop();
    if (this.jdField_a_of_type_AndroidAppDialog != null) {
      this.jdField_a_of_type_AndroidAppDialog.hide();
    }
  }
  
  public void setCancelable(boolean paramBoolean)
  {
    this.jdField_a_of_type_Boolean = paramBoolean;
    if (this.jdField_a_of_type_AndroidAppDialog != null) {
      this.jdField_a_of_type_AndroidAppDialog.setCancelable(paramBoolean);
    }
  }
  
  public void setShowsDialog(boolean paramBoolean)
  {
    this.jdField_b_of_type_Boolean = paramBoolean;
  }
  
  public void setStyle(int paramInt1, int paramInt2)
  {
    this.jdField_a_of_type_Int = paramInt1;
    if ((this.jdField_a_of_type_Int == 2) || (this.jdField_a_of_type_Int == 3)) {
      this.jdField_b_of_type_Int = 16973913;
    }
    if (paramInt2 != 0) {
      this.jdField_b_of_type_Int = paramInt2;
    }
  }
  
  public int show(FragmentTransaction paramFragmentTransaction, String paramString)
  {
    this.d = false;
    this.e = true;
    paramFragmentTransaction.add(this, paramString);
    this.jdField_c_of_type_Boolean = false;
    this.jdField_c_of_type_Int = paramFragmentTransaction.commit();
    return this.jdField_c_of_type_Int;
  }
  
  public void show(FragmentManager paramFragmentManager, String paramString)
  {
    this.d = false;
    this.e = true;
    paramFragmentManager = paramFragmentManager.beginTransaction();
    paramFragmentManager.add(this, paramString);
    paramFragmentManager.commit();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/app/DialogFragment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */