package android.support.v4.app;

import K;
import L;
import M;
import N;
import O;
import android.os.Build.VERSION;

public class NotificationCompat
{
  public static final int FLAG_HIGH_PRIORITY = 128;
  public static final int PRIORITY_DEFAULT = 0;
  public static final int PRIORITY_HIGH = 1;
  public static final int PRIORITY_LOW = -1;
  public static final int PRIORITY_MAX = 2;
  public static final int PRIORITY_MIN = -2;
  private static final K a = new L();
  
  static
  {
    if (Build.VERSION.SDK_INT >= 16)
    {
      a = new O();
      return;
    }
    if (Build.VERSION.SDK_INT >= 14)
    {
      a = new N();
      return;
    }
    if (Build.VERSION.SDK_INT >= 11)
    {
      a = new M();
      return;
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/app/NotificationCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */