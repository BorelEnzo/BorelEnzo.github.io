package android.support.v4.app;

import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Iterator;

public abstract class FragmentStatePagerAdapter
  extends PagerAdapter
{
  private Fragment jdField_a_of_type_AndroidSupportV4AppFragment = null;
  private final FragmentManager jdField_a_of_type_AndroidSupportV4AppFragmentManager;
  private FragmentTransaction jdField_a_of_type_AndroidSupportV4AppFragmentTransaction = null;
  private ArrayList jdField_a_of_type_JavaUtilArrayList = new ArrayList();
  private ArrayList b = new ArrayList();
  
  public FragmentStatePagerAdapter(FragmentManager paramFragmentManager)
  {
    this.jdField_a_of_type_AndroidSupportV4AppFragmentManager = paramFragmentManager;
  }
  
  public void destroyItem(ViewGroup paramViewGroup, int paramInt, Object paramObject)
  {
    paramViewGroup = (Fragment)paramObject;
    if (this.jdField_a_of_type_AndroidSupportV4AppFragmentTransaction == null) {
      this.jdField_a_of_type_AndroidSupportV4AppFragmentTransaction = this.jdField_a_of_type_AndroidSupportV4AppFragmentManager.beginTransaction();
    }
    while (this.jdField_a_of_type_JavaUtilArrayList.size() <= paramInt) {
      this.jdField_a_of_type_JavaUtilArrayList.add(null);
    }
    this.jdField_a_of_type_JavaUtilArrayList.set(paramInt, this.jdField_a_of_type_AndroidSupportV4AppFragmentManager.saveFragmentInstanceState(paramViewGroup));
    this.b.set(paramInt, null);
    this.jdField_a_of_type_AndroidSupportV4AppFragmentTransaction.remove(paramViewGroup);
  }
  
  public void finishUpdate(ViewGroup paramViewGroup)
  {
    if (this.jdField_a_of_type_AndroidSupportV4AppFragmentTransaction != null)
    {
      this.jdField_a_of_type_AndroidSupportV4AppFragmentTransaction.commitAllowingStateLoss();
      this.jdField_a_of_type_AndroidSupportV4AppFragmentTransaction = null;
      this.jdField_a_of_type_AndroidSupportV4AppFragmentManager.executePendingTransactions();
    }
  }
  
  public abstract Fragment getItem(int paramInt);
  
  public Object instantiateItem(ViewGroup paramViewGroup, int paramInt)
  {
    if (this.b.size() > paramInt)
    {
      localFragment = (Fragment)this.b.get(paramInt);
      if (localFragment != null) {
        return localFragment;
      }
    }
    if (this.jdField_a_of_type_AndroidSupportV4AppFragmentTransaction == null) {
      this.jdField_a_of_type_AndroidSupportV4AppFragmentTransaction = this.jdField_a_of_type_AndroidSupportV4AppFragmentManager.beginTransaction();
    }
    Fragment localFragment = getItem(paramInt);
    if (this.jdField_a_of_type_JavaUtilArrayList.size() > paramInt)
    {
      Fragment.SavedState localSavedState = (Fragment.SavedState)this.jdField_a_of_type_JavaUtilArrayList.get(paramInt);
      if (localSavedState != null) {
        localFragment.setInitialSavedState(localSavedState);
      }
    }
    while (this.b.size() <= paramInt) {
      this.b.add(null);
    }
    localFragment.setMenuVisibility(false);
    localFragment.setUserVisibleHint(false);
    this.b.set(paramInt, localFragment);
    this.jdField_a_of_type_AndroidSupportV4AppFragmentTransaction.add(paramViewGroup.getId(), localFragment);
    return localFragment;
  }
  
  public boolean isViewFromObject(View paramView, Object paramObject)
  {
    return ((Fragment)paramObject).getView() == paramView;
  }
  
  public void restoreState(Parcelable paramParcelable, ClassLoader paramClassLoader)
  {
    if (paramParcelable != null)
    {
      paramParcelable = (Bundle)paramParcelable;
      paramParcelable.setClassLoader(paramClassLoader);
      paramClassLoader = paramParcelable.getParcelableArray("states");
      this.jdField_a_of_type_JavaUtilArrayList.clear();
      this.b.clear();
      int i;
      if (paramClassLoader != null)
      {
        i = 0;
        while (i < paramClassLoader.length)
        {
          this.jdField_a_of_type_JavaUtilArrayList.add((Fragment.SavedState)paramClassLoader[i]);
          i += 1;
        }
      }
      paramClassLoader = paramParcelable.keySet().iterator();
      while (paramClassLoader.hasNext())
      {
        String str = (String)paramClassLoader.next();
        if (str.startsWith("f"))
        {
          i = Integer.parseInt(str.substring(1));
          Fragment localFragment = this.jdField_a_of_type_AndroidSupportV4AppFragmentManager.getFragment(paramParcelable, str);
          if (localFragment != null)
          {
            while (this.b.size() <= i) {
              this.b.add(null);
            }
            localFragment.setMenuVisibility(false);
            this.b.set(i, localFragment);
          }
          else
          {
            new StringBuilder("Bad fragment at key ").append(str).toString();
          }
        }
      }
    }
  }
  
  public Parcelable saveState()
  {
    Object localObject1 = null;
    Object localObject2;
    if (this.jdField_a_of_type_JavaUtilArrayList.size() > 0)
    {
      localObject1 = new Bundle();
      localObject2 = new Fragment.SavedState[this.jdField_a_of_type_JavaUtilArrayList.size()];
      this.jdField_a_of_type_JavaUtilArrayList.toArray((Object[])localObject2);
      ((Bundle)localObject1).putParcelableArray("states", (Parcelable[])localObject2);
    }
    int i = 0;
    while (i < this.b.size())
    {
      Fragment localFragment = (Fragment)this.b.get(i);
      localObject2 = localObject1;
      if (localFragment != null)
      {
        localObject2 = localObject1;
        if (localObject1 == null) {
          localObject2 = new Bundle();
        }
        localObject1 = "f" + i;
        this.jdField_a_of_type_AndroidSupportV4AppFragmentManager.putFragment((Bundle)localObject2, (String)localObject1, localFragment);
      }
      i += 1;
      localObject1 = localObject2;
    }
    return (Parcelable)localObject1;
  }
  
  public void setPrimaryItem(ViewGroup paramViewGroup, int paramInt, Object paramObject)
  {
    paramViewGroup = (Fragment)paramObject;
    if (paramViewGroup != this.jdField_a_of_type_AndroidSupportV4AppFragment)
    {
      if (this.jdField_a_of_type_AndroidSupportV4AppFragment != null)
      {
        this.jdField_a_of_type_AndroidSupportV4AppFragment.setMenuVisibility(false);
        this.jdField_a_of_type_AndroidSupportV4AppFragment.setUserVisibleHint(false);
      }
      if (paramViewGroup != null)
      {
        paramViewGroup.setMenuVisibility(true);
        paramViewGroup.setUserVisibleHint(true);
      }
      this.jdField_a_of_type_AndroidSupportV4AppFragment = paramViewGroup;
    }
  }
  
  public void startUpdate(ViewGroup paramViewGroup) {}
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/app/FragmentStatePagerAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */