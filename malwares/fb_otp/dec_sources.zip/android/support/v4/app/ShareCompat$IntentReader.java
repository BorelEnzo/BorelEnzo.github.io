package android.support.v4.app;

import Q;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.text.Html;
import android.text.Spanned;
import java.util.ArrayList;

public class ShareCompat$IntentReader
{
  private Activity jdField_a_of_type_AndroidAppActivity;
  private ComponentName jdField_a_of_type_AndroidContentComponentName;
  private Intent jdField_a_of_type_AndroidContentIntent;
  private String jdField_a_of_type_JavaLangString;
  private ArrayList jdField_a_of_type_JavaUtilArrayList;
  
  private ShareCompat$IntentReader(Activity paramActivity)
  {
    this.jdField_a_of_type_AndroidAppActivity = paramActivity;
    this.jdField_a_of_type_AndroidContentIntent = paramActivity.getIntent();
    this.jdField_a_of_type_JavaLangString = ShareCompat.getCallingPackage(paramActivity);
    this.jdField_a_of_type_AndroidContentComponentName = ShareCompat.getCallingActivity(paramActivity);
  }
  
  public static IntentReader from(Activity paramActivity)
  {
    return new IntentReader(paramActivity);
  }
  
  public ComponentName getCallingActivity()
  {
    return this.jdField_a_of_type_AndroidContentComponentName;
  }
  
  public Drawable getCallingActivityIcon()
  {
    if (this.jdField_a_of_type_AndroidContentComponentName == null) {
      return null;
    }
    Object localObject = this.jdField_a_of_type_AndroidAppActivity.getPackageManager();
    try
    {
      localObject = ((PackageManager)localObject).getActivityIcon(this.jdField_a_of_type_AndroidContentComponentName);
      return (Drawable)localObject;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException) {}
    return null;
  }
  
  public Drawable getCallingApplicationIcon()
  {
    if (this.jdField_a_of_type_JavaLangString == null) {
      return null;
    }
    Object localObject = this.jdField_a_of_type_AndroidAppActivity.getPackageManager();
    try
    {
      localObject = ((PackageManager)localObject).getApplicationIcon(this.jdField_a_of_type_JavaLangString);
      return (Drawable)localObject;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException) {}
    return null;
  }
  
  public CharSequence getCallingApplicationLabel()
  {
    if (this.jdField_a_of_type_JavaLangString == null) {
      return null;
    }
    Object localObject = this.jdField_a_of_type_AndroidAppActivity.getPackageManager();
    try
    {
      localObject = ((PackageManager)localObject).getApplicationLabel(((PackageManager)localObject).getApplicationInfo(this.jdField_a_of_type_JavaLangString, 0));
      return (CharSequence)localObject;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException) {}
    return null;
  }
  
  public String getCallingPackage()
  {
    return this.jdField_a_of_type_JavaLangString;
  }
  
  public String[] getEmailBcc()
  {
    return this.jdField_a_of_type_AndroidContentIntent.getStringArrayExtra("android.intent.extra.BCC");
  }
  
  public String[] getEmailCc()
  {
    return this.jdField_a_of_type_AndroidContentIntent.getStringArrayExtra("android.intent.extra.CC");
  }
  
  public String[] getEmailTo()
  {
    return this.jdField_a_of_type_AndroidContentIntent.getStringArrayExtra("android.intent.extra.EMAIL");
  }
  
  public String getHtmlText()
  {
    String str = this.jdField_a_of_type_AndroidContentIntent.getStringExtra("android.intent.extra.HTML_TEXT");
    if (this.jdField_a_of_type_AndroidContentIntent == null)
    {
      CharSequence localCharSequence = getText();
      if ((localCharSequence instanceof Spanned)) {
        return Html.toHtml((Spanned)localCharSequence);
      }
      if (localCharSequence != null) {
        return ShareCompat.a().a(localCharSequence);
      }
    }
    return str;
  }
  
  public Uri getStream()
  {
    return (Uri)this.jdField_a_of_type_AndroidContentIntent.getParcelableExtra("android.intent.extra.STREAM");
  }
  
  public Uri getStream(int paramInt)
  {
    if ((this.jdField_a_of_type_JavaUtilArrayList == null) && (isMultipleShare())) {
      this.jdField_a_of_type_JavaUtilArrayList = this.jdField_a_of_type_AndroidContentIntent.getParcelableArrayListExtra("android.intent.extra.STREAM");
    }
    if (this.jdField_a_of_type_JavaUtilArrayList != null) {
      return (Uri)this.jdField_a_of_type_JavaUtilArrayList.get(paramInt);
    }
    if (paramInt == 0) {
      return (Uri)this.jdField_a_of_type_AndroidContentIntent.getParcelableExtra("android.intent.extra.STREAM");
    }
    throw new IndexOutOfBoundsException("Stream items available: " + getStreamCount() + " index requested: " + paramInt);
  }
  
  public int getStreamCount()
  {
    if ((this.jdField_a_of_type_JavaUtilArrayList == null) && (isMultipleShare())) {
      this.jdField_a_of_type_JavaUtilArrayList = this.jdField_a_of_type_AndroidContentIntent.getParcelableArrayListExtra("android.intent.extra.STREAM");
    }
    if (this.jdField_a_of_type_JavaUtilArrayList != null) {
      return this.jdField_a_of_type_JavaUtilArrayList.size();
    }
    if (this.jdField_a_of_type_AndroidContentIntent.hasExtra("android.intent.extra.STREAM")) {
      return 1;
    }
    return 0;
  }
  
  public String getSubject()
  {
    return this.jdField_a_of_type_AndroidContentIntent.getStringExtra("android.intent.extra.SUBJECT");
  }
  
  public CharSequence getText()
  {
    return this.jdField_a_of_type_AndroidContentIntent.getCharSequenceExtra("android.intent.extra.TEXT");
  }
  
  public String getType()
  {
    return this.jdField_a_of_type_AndroidContentIntent.getType();
  }
  
  public boolean isMultipleShare()
  {
    return this.jdField_a_of_type_AndroidContentIntent.getAction().equals("android.intent.action.SEND_MULTIPLE");
  }
  
  public boolean isShareIntent()
  {
    String str = this.jdField_a_of_type_AndroidContentIntent.getAction();
    return (str.equals("android.intent.action.SEND")) || (str.equals("android.intent.action.SEND_MULTIPLE"));
  }
  
  public boolean isSingleShare()
  {
    return this.jdField_a_of_type_AndroidContentIntent.getAction().equals("android.intent.action.SEND");
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/app/ShareCompat$IntentReader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */