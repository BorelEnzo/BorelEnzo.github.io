package android.support.v4.app;

import C;
import D;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class ListFragment
  extends Fragment
{
  private final Handler jdField_a_of_type_AndroidOsHandler = new Handler();
  private final AdapterView.OnItemClickListener jdField_a_of_type_AndroidWidgetAdapterView$OnItemClickListener = new D(this);
  ListAdapter jdField_a_of_type_AndroidWidgetListAdapter;
  public ListView a;
  TextView jdField_a_of_type_AndroidWidgetTextView;
  CharSequence jdField_a_of_type_JavaLangCharSequence;
  private final Runnable jdField_a_of_type_JavaLangRunnable = new C(this);
  boolean jdField_a_of_type_Boolean;
  View d;
  View e;
  View f;
  
  private void a(boolean paramBoolean1, boolean paramBoolean2)
  {
    j();
    if (this.e == null) {
      throw new IllegalStateException("Can't be used with a custom content view");
    }
    if (this.jdField_a_of_type_Boolean == paramBoolean1) {
      return;
    }
    this.jdField_a_of_type_Boolean = paramBoolean1;
    if (paramBoolean1)
    {
      if (paramBoolean2)
      {
        this.e.startAnimation(AnimationUtils.loadAnimation(getActivity(), 17432577));
        this.f.startAnimation(AnimationUtils.loadAnimation(getActivity(), 17432576));
      }
      for (;;)
      {
        this.e.setVisibility(8);
        this.f.setVisibility(0);
        return;
        this.e.clearAnimation();
        this.f.clearAnimation();
      }
    }
    if (paramBoolean2)
    {
      this.e.startAnimation(AnimationUtils.loadAnimation(getActivity(), 17432576));
      this.f.startAnimation(AnimationUtils.loadAnimation(getActivity(), 17432577));
    }
    for (;;)
    {
      this.e.setVisibility(0);
      this.f.setVisibility(8);
      return;
      this.e.clearAnimation();
      this.f.clearAnimation();
    }
  }
  
  private void j()
  {
    if (this.jdField_a_of_type_AndroidWidgetListView != null) {
      return;
    }
    Object localObject = getView();
    if (localObject == null) {
      throw new IllegalStateException("Content view not yet created");
    }
    if ((localObject instanceof ListView))
    {
      this.jdField_a_of_type_AndroidWidgetListView = ((ListView)localObject);
      this.jdField_a_of_type_Boolean = true;
      this.jdField_a_of_type_AndroidWidgetListView.setOnItemClickListener(this.jdField_a_of_type_AndroidWidgetAdapterView$OnItemClickListener);
      if (this.jdField_a_of_type_AndroidWidgetListAdapter == null) {
        break label254;
      }
      localObject = this.jdField_a_of_type_AndroidWidgetListAdapter;
      this.jdField_a_of_type_AndroidWidgetListAdapter = null;
      setListAdapter((ListAdapter)localObject);
    }
    for (;;)
    {
      this.jdField_a_of_type_AndroidOsHandler.post(this.jdField_a_of_type_JavaLangRunnable);
      return;
      this.jdField_a_of_type_AndroidWidgetTextView = ((TextView)((View)localObject).findViewById(16711681));
      if (this.jdField_a_of_type_AndroidWidgetTextView == null) {
        this.d = ((View)localObject).findViewById(16908292);
      }
      for (;;)
      {
        this.e = ((View)localObject).findViewById(16711682);
        this.f = ((View)localObject).findViewById(16711683);
        localObject = ((View)localObject).findViewById(16908298);
        if ((localObject instanceof ListView)) {
          break label193;
        }
        if (localObject != null) {
          break;
        }
        throw new RuntimeException("Your content must have a ListView whose id attribute is 'android.R.id.list'");
        this.jdField_a_of_type_AndroidWidgetTextView.setVisibility(8);
      }
      throw new RuntimeException("Content has view with id attribute 'android.R.id.list' that is not a ListView class");
      label193:
      this.jdField_a_of_type_AndroidWidgetListView = ((ListView)localObject);
      if (this.d != null)
      {
        this.jdField_a_of_type_AndroidWidgetListView.setEmptyView(this.d);
        break;
      }
      if (this.jdField_a_of_type_JavaLangCharSequence == null) {
        break;
      }
      this.jdField_a_of_type_AndroidWidgetTextView.setText(this.jdField_a_of_type_JavaLangCharSequence);
      this.jdField_a_of_type_AndroidWidgetListView.setEmptyView(this.jdField_a_of_type_AndroidWidgetTextView);
      break;
      label254:
      if (this.e != null) {
        a(false, false);
      }
    }
  }
  
  public ListAdapter getListAdapter()
  {
    return this.jdField_a_of_type_AndroidWidgetListAdapter;
  }
  
  public ListView getListView()
  {
    j();
    return this.jdField_a_of_type_AndroidWidgetListView;
  }
  
  public long getSelectedItemId()
  {
    j();
    return this.jdField_a_of_type_AndroidWidgetListView.getSelectedItemId();
  }
  
  public int getSelectedItemPosition()
  {
    j();
    return this.jdField_a_of_type_AndroidWidgetListView.getSelectedItemPosition();
  }
  
  public View onCreateView(LayoutInflater paramLayoutInflater, ViewGroup paramViewGroup, Bundle paramBundle)
  {
    paramViewGroup = getActivity();
    paramLayoutInflater = new FrameLayout(paramViewGroup);
    paramBundle = new LinearLayout(paramViewGroup);
    paramBundle.setId(16711682);
    paramBundle.setOrientation(1);
    paramBundle.setVisibility(8);
    paramBundle.setGravity(17);
    paramBundle.addView(new ProgressBar(paramViewGroup, null, 16842874), new FrameLayout.LayoutParams(-2, -2));
    paramLayoutInflater.addView(paramBundle, new FrameLayout.LayoutParams(-1, -1));
    paramViewGroup = new FrameLayout(paramViewGroup);
    paramViewGroup.setId(16711683);
    paramBundle = new TextView(getActivity());
    paramBundle.setId(16711681);
    paramBundle.setGravity(17);
    paramViewGroup.addView(paramBundle, new FrameLayout.LayoutParams(-1, -1));
    paramBundle = new ListView(getActivity());
    paramBundle.setId(16908298);
    paramBundle.setDrawSelectorOnTop(false);
    paramViewGroup.addView(paramBundle, new FrameLayout.LayoutParams(-1, -1));
    paramLayoutInflater.addView(paramViewGroup, new FrameLayout.LayoutParams(-1, -1));
    paramLayoutInflater.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
    return paramLayoutInflater;
  }
  
  public void onDestroyView()
  {
    this.jdField_a_of_type_AndroidOsHandler.removeCallbacks(this.jdField_a_of_type_JavaLangRunnable);
    this.jdField_a_of_type_AndroidWidgetListView = null;
    this.jdField_a_of_type_Boolean = false;
    this.f = null;
    this.e = null;
    this.d = null;
    this.jdField_a_of_type_AndroidWidgetTextView = null;
    super.onDestroyView();
  }
  
  public void onListItemClick(ListView paramListView, View paramView, int paramInt, long paramLong) {}
  
  public void onViewCreated(View paramView, Bundle paramBundle)
  {
    super.onViewCreated(paramView, paramBundle);
    j();
  }
  
  public void setEmptyText(CharSequence paramCharSequence)
  {
    j();
    if (this.jdField_a_of_type_AndroidWidgetTextView == null) {
      throw new IllegalStateException("Can't be used with a custom content view");
    }
    this.jdField_a_of_type_AndroidWidgetTextView.setText(paramCharSequence);
    if (this.jdField_a_of_type_JavaLangCharSequence == null) {
      this.jdField_a_of_type_AndroidWidgetListView.setEmptyView(this.jdField_a_of_type_AndroidWidgetTextView);
    }
    this.jdField_a_of_type_JavaLangCharSequence = paramCharSequence;
  }
  
  public void setListAdapter(ListAdapter paramListAdapter)
  {
    boolean bool = false;
    if (this.jdField_a_of_type_AndroidWidgetListAdapter != null) {}
    for (int i = 1;; i = 0)
    {
      this.jdField_a_of_type_AndroidWidgetListAdapter = paramListAdapter;
      if (this.jdField_a_of_type_AndroidWidgetListView != null)
      {
        this.jdField_a_of_type_AndroidWidgetListView.setAdapter(paramListAdapter);
        if ((!this.jdField_a_of_type_Boolean) && (i == 0))
        {
          if (getView().getWindowToken() != null) {
            bool = true;
          }
          a(true, bool);
        }
      }
      return;
    }
  }
  
  public void setListShown(boolean paramBoolean)
  {
    a(paramBoolean, true);
  }
  
  public void setListShownNoAnimation(boolean paramBoolean)
  {
    a(paramBoolean, false);
  }
  
  public void setSelection(int paramInt)
  {
    j();
    this.jdField_a_of_type_AndroidWidgetListView.setSelection(paramInt);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/app/ListFragment.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */