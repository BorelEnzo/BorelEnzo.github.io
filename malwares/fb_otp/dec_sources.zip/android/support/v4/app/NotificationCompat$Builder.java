package android.support.v4.app;

import K;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.widget.RemoteViews;
import java.util.ArrayList;

public class NotificationCompat$Builder
{
  public int a;
  public Notification a;
  public PendingIntent a;
  public Context a;
  public Bitmap a;
  public NotificationCompat.Style a;
  public RemoteViews a;
  public CharSequence a;
  public ArrayList a;
  public boolean a;
  public int b;
  public PendingIntent b;
  public CharSequence b;
  public boolean b;
  public int c;
  public CharSequence c;
  public int d;
  public CharSequence d;
  
  public NotificationCompat$Builder(Context paramContext)
  {
    this.jdField_a_of_type_JavaUtilArrayList = new ArrayList();
    this.jdField_a_of_type_AndroidAppNotification = new Notification();
    this.jdField_a_of_type_AndroidContentContext = paramContext;
    this.jdField_a_of_type_AndroidAppNotification.when = System.currentTimeMillis();
    this.jdField_a_of_type_AndroidAppNotification.audioStreamType = -1;
    this.jdField_b_of_type_Int = 0;
  }
  
  private void a(int paramInt, boolean paramBoolean)
  {
    if (paramBoolean)
    {
      localNotification = this.jdField_a_of_type_AndroidAppNotification;
      localNotification.flags |= paramInt;
      return;
    }
    Notification localNotification = this.jdField_a_of_type_AndroidAppNotification;
    localNotification.flags &= (paramInt ^ 0xFFFFFFFF);
  }
  
  public Builder addAction(int paramInt, CharSequence paramCharSequence, PendingIntent paramPendingIntent)
  {
    this.jdField_a_of_type_JavaUtilArrayList.add(new NotificationCompat.Action(paramInt, paramCharSequence, paramPendingIntent));
    return this;
  }
  
  public Notification build()
  {
    return NotificationCompat.a().a(this);
  }
  
  public Notification getNotification()
  {
    return NotificationCompat.a().a(this);
  }
  
  public Builder setAutoCancel(boolean paramBoolean)
  {
    a(16, paramBoolean);
    return this;
  }
  
  public Builder setContent(RemoteViews paramRemoteViews)
  {
    this.jdField_a_of_type_AndroidAppNotification.contentView = paramRemoteViews;
    return this;
  }
  
  public Builder setContentInfo(CharSequence paramCharSequence)
  {
    this.jdField_c_of_type_JavaLangCharSequence = paramCharSequence;
    return this;
  }
  
  public Builder setContentIntent(PendingIntent paramPendingIntent)
  {
    this.jdField_a_of_type_AndroidAppPendingIntent = paramPendingIntent;
    return this;
  }
  
  public Builder setContentText(CharSequence paramCharSequence)
  {
    this.jdField_b_of_type_JavaLangCharSequence = paramCharSequence;
    return this;
  }
  
  public Builder setContentTitle(CharSequence paramCharSequence)
  {
    this.jdField_a_of_type_JavaLangCharSequence = paramCharSequence;
    return this;
  }
  
  public Builder setDefaults(int paramInt)
  {
    this.jdField_a_of_type_AndroidAppNotification.defaults = paramInt;
    if ((paramInt & 0x4) != 0)
    {
      Notification localNotification = this.jdField_a_of_type_AndroidAppNotification;
      localNotification.flags |= 0x1;
    }
    return this;
  }
  
  public Builder setDeleteIntent(PendingIntent paramPendingIntent)
  {
    this.jdField_a_of_type_AndroidAppNotification.deleteIntent = paramPendingIntent;
    return this;
  }
  
  public Builder setFullScreenIntent(PendingIntent paramPendingIntent, boolean paramBoolean)
  {
    this.jdField_b_of_type_AndroidAppPendingIntent = paramPendingIntent;
    a(128, paramBoolean);
    return this;
  }
  
  public Builder setLargeIcon(Bitmap paramBitmap)
  {
    this.jdField_a_of_type_AndroidGraphicsBitmap = paramBitmap;
    return this;
  }
  
  public Builder setLights(int paramInt1, int paramInt2, int paramInt3)
  {
    int i = 1;
    this.jdField_a_of_type_AndroidAppNotification.ledARGB = paramInt1;
    this.jdField_a_of_type_AndroidAppNotification.ledOnMS = paramInt2;
    this.jdField_a_of_type_AndroidAppNotification.ledOffMS = paramInt3;
    Notification localNotification;
    if ((this.jdField_a_of_type_AndroidAppNotification.ledOnMS != 0) && (this.jdField_a_of_type_AndroidAppNotification.ledOffMS != 0))
    {
      paramInt1 = 1;
      localNotification = this.jdField_a_of_type_AndroidAppNotification;
      paramInt2 = this.jdField_a_of_type_AndroidAppNotification.flags;
      if (paramInt1 == 0) {
        break label88;
      }
    }
    label88:
    for (paramInt1 = i;; paramInt1 = 0)
    {
      localNotification.flags = (paramInt2 & 0xFFFFFFFE | paramInt1);
      return this;
      paramInt1 = 0;
      break;
    }
  }
  
  public Builder setNumber(int paramInt)
  {
    this.jdField_a_of_type_Int = paramInt;
    return this;
  }
  
  public Builder setOngoing(boolean paramBoolean)
  {
    a(2, paramBoolean);
    return this;
  }
  
  public Builder setOnlyAlertOnce(boolean paramBoolean)
  {
    a(8, paramBoolean);
    return this;
  }
  
  public Builder setPriority(int paramInt)
  {
    this.jdField_b_of_type_Int = paramInt;
    return this;
  }
  
  public Builder setProgress(int paramInt1, int paramInt2, boolean paramBoolean)
  {
    this.jdField_c_of_type_Int = paramInt1;
    this.jdField_d_of_type_Int = paramInt2;
    this.jdField_b_of_type_Boolean = paramBoolean;
    return this;
  }
  
  public Builder setSmallIcon(int paramInt)
  {
    this.jdField_a_of_type_AndroidAppNotification.icon = paramInt;
    return this;
  }
  
  public Builder setSmallIcon(int paramInt1, int paramInt2)
  {
    this.jdField_a_of_type_AndroidAppNotification.icon = paramInt1;
    this.jdField_a_of_type_AndroidAppNotification.iconLevel = paramInt2;
    return this;
  }
  
  public Builder setSound(Uri paramUri)
  {
    this.jdField_a_of_type_AndroidAppNotification.sound = paramUri;
    this.jdField_a_of_type_AndroidAppNotification.audioStreamType = -1;
    return this;
  }
  
  public Builder setSound(Uri paramUri, int paramInt)
  {
    this.jdField_a_of_type_AndroidAppNotification.sound = paramUri;
    this.jdField_a_of_type_AndroidAppNotification.audioStreamType = paramInt;
    return this;
  }
  
  public Builder setStyle(NotificationCompat.Style paramStyle)
  {
    if (this.jdField_a_of_type_AndroidSupportV4AppNotificationCompat$Style != paramStyle)
    {
      this.jdField_a_of_type_AndroidSupportV4AppNotificationCompat$Style = paramStyle;
      if (this.jdField_a_of_type_AndroidSupportV4AppNotificationCompat$Style != null) {
        this.jdField_a_of_type_AndroidSupportV4AppNotificationCompat$Style.setBuilder(this);
      }
    }
    return this;
  }
  
  public Builder setSubText(CharSequence paramCharSequence)
  {
    this.jdField_d_of_type_JavaLangCharSequence = paramCharSequence;
    return this;
  }
  
  public Builder setTicker(CharSequence paramCharSequence)
  {
    this.jdField_a_of_type_AndroidAppNotification.tickerText = paramCharSequence;
    return this;
  }
  
  public Builder setTicker(CharSequence paramCharSequence, RemoteViews paramRemoteViews)
  {
    this.jdField_a_of_type_AndroidAppNotification.tickerText = paramCharSequence;
    this.jdField_a_of_type_AndroidWidgetRemoteViews = paramRemoteViews;
    return this;
  }
  
  public Builder setUsesChronometer(boolean paramBoolean)
  {
    this.jdField_a_of_type_Boolean = paramBoolean;
    return this;
  }
  
  public Builder setVibrate(long[] paramArrayOfLong)
  {
    this.jdField_a_of_type_AndroidAppNotification.vibrate = paramArrayOfLong;
    return this;
  }
  
  public Builder setWhen(long paramLong)
  {
    this.jdField_a_of_type_AndroidAppNotification.when = paramLong;
    return this;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/app/NotificationCompat$Builder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */