package android.support.v4.app;

import B;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TabHost;
import android.widget.TabHost.OnTabChangeListener;
import android.widget.TabHost.TabSpec;
import android.widget.TabWidget;
import java.util.ArrayList;
import y;
import z;

public class FragmentTabHost
  extends TabHost
  implements TabHost.OnTabChangeListener
{
  private int jdField_a_of_type_Int;
  private B jdField_a_of_type_B;
  private Context jdField_a_of_type_AndroidContentContext;
  private FragmentManager jdField_a_of_type_AndroidSupportV4AppFragmentManager;
  private FrameLayout jdField_a_of_type_AndroidWidgetFrameLayout;
  private TabHost.OnTabChangeListener jdField_a_of_type_AndroidWidgetTabHost$OnTabChangeListener;
  private final ArrayList jdField_a_of_type_JavaUtilArrayList = new ArrayList();
  private boolean jdField_a_of_type_Boolean;
  
  public FragmentTabHost(Context paramContext)
  {
    super(paramContext, null);
    a(paramContext, null);
  }
  
  public FragmentTabHost(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    a(paramContext, paramAttributeSet);
  }
  
  private FragmentTransaction a(String paramString, FragmentTransaction paramFragmentTransaction)
  {
    Object localObject = null;
    int i = 0;
    if (i < this.jdField_a_of_type_JavaUtilArrayList.size())
    {
      B localB = (B)this.jdField_a_of_type_JavaUtilArrayList.get(i);
      if (!localB.jdField_a_of_type_JavaLangString.equals(paramString)) {
        break label213;
      }
      localObject = localB;
    }
    label200:
    label213:
    for (;;)
    {
      i += 1;
      break;
      if (localObject == null) {
        throw new IllegalStateException("No tab known for tag " + paramString);
      }
      paramString = paramFragmentTransaction;
      if (this.jdField_a_of_type_B != localObject)
      {
        paramString = paramFragmentTransaction;
        if (paramFragmentTransaction == null) {
          paramString = this.jdField_a_of_type_AndroidSupportV4AppFragmentManager.beginTransaction();
        }
        if ((this.jdField_a_of_type_B != null) && (this.jdField_a_of_type_B.jdField_a_of_type_AndroidSupportV4AppFragment != null)) {
          paramString.detach(this.jdField_a_of_type_B.jdField_a_of_type_AndroidSupportV4AppFragment);
        }
        if (localObject != null)
        {
          if (((B)localObject).jdField_a_of_type_AndroidSupportV4AppFragment != null) {
            break label200;
          }
          ((B)localObject).jdField_a_of_type_AndroidSupportV4AppFragment = Fragment.instantiate(this.jdField_a_of_type_AndroidContentContext, ((B)localObject).jdField_a_of_type_JavaLangClass.getName(), ((B)localObject).jdField_a_of_type_AndroidOsBundle);
          paramString.add(this.jdField_a_of_type_Int, ((B)localObject).jdField_a_of_type_AndroidSupportV4AppFragment, ((B)localObject).jdField_a_of_type_JavaLangString);
        }
      }
      for (;;)
      {
        this.jdField_a_of_type_B = ((B)localObject);
        return paramString;
        paramString.attach(((B)localObject).jdField_a_of_type_AndroidSupportV4AppFragment);
      }
    }
  }
  
  private void a()
  {
    if (this.jdField_a_of_type_AndroidWidgetFrameLayout == null)
    {
      this.jdField_a_of_type_AndroidWidgetFrameLayout = ((FrameLayout)findViewById(this.jdField_a_of_type_Int));
      if (this.jdField_a_of_type_AndroidWidgetFrameLayout == null) {
        throw new IllegalStateException("No tab content FrameLayout found for id " + this.jdField_a_of_type_Int);
      }
    }
  }
  
  private void a(Context paramContext, AttributeSet paramAttributeSet)
  {
    paramAttributeSet = paramContext.obtainStyledAttributes(paramAttributeSet, new int[] { 16842995 }, 0, 0);
    this.jdField_a_of_type_Int = paramAttributeSet.getResourceId(0, 0);
    paramAttributeSet.recycle();
    super.setOnTabChangedListener(this);
    if (findViewById(16908307) == null)
    {
      paramAttributeSet = new LinearLayout(paramContext);
      paramAttributeSet.setOrientation(1);
      addView(paramAttributeSet, new FrameLayout.LayoutParams(-1, -1));
      Object localObject = new TabWidget(paramContext);
      ((TabWidget)localObject).setId(16908307);
      ((TabWidget)localObject).setOrientation(0);
      paramAttributeSet.addView((View)localObject, new LinearLayout.LayoutParams(-1, -2, 0.0F));
      localObject = new FrameLayout(paramContext);
      ((FrameLayout)localObject).setId(16908305);
      paramAttributeSet.addView((View)localObject, new LinearLayout.LayoutParams(0, 0, 0.0F));
      paramContext = new FrameLayout(paramContext);
      this.jdField_a_of_type_AndroidWidgetFrameLayout = paramContext;
      this.jdField_a_of_type_AndroidWidgetFrameLayout.setId(this.jdField_a_of_type_Int);
      paramAttributeSet.addView(paramContext, new LinearLayout.LayoutParams(-1, 0, 1.0F));
    }
  }
  
  public void addTab(TabHost.TabSpec paramTabSpec, Class paramClass, Bundle paramBundle)
  {
    paramTabSpec.setContent(new y(this.jdField_a_of_type_AndroidContentContext));
    String str = paramTabSpec.getTag();
    paramClass = new B(str, paramClass, paramBundle);
    if (this.jdField_a_of_type_Boolean)
    {
      paramClass.jdField_a_of_type_AndroidSupportV4AppFragment = this.jdField_a_of_type_AndroidSupportV4AppFragmentManager.findFragmentByTag(str);
      if ((paramClass.jdField_a_of_type_AndroidSupportV4AppFragment != null) && (!paramClass.jdField_a_of_type_AndroidSupportV4AppFragment.isDetached()))
      {
        paramBundle = this.jdField_a_of_type_AndroidSupportV4AppFragmentManager.beginTransaction();
        paramBundle.detach(paramClass.jdField_a_of_type_AndroidSupportV4AppFragment);
        paramBundle.commit();
      }
    }
    this.jdField_a_of_type_JavaUtilArrayList.add(paramClass);
    addTab(paramTabSpec);
  }
  
  protected void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    String str = getCurrentTabTag();
    Object localObject1 = null;
    int i = 0;
    if (i < this.jdField_a_of_type_JavaUtilArrayList.size())
    {
      B localB = (B)this.jdField_a_of_type_JavaUtilArrayList.get(i);
      localB.jdField_a_of_type_AndroidSupportV4AppFragment = this.jdField_a_of_type_AndroidSupportV4AppFragmentManager.findFragmentByTag(localB.jdField_a_of_type_JavaLangString);
      Object localObject2 = localObject1;
      if (localB.jdField_a_of_type_AndroidSupportV4AppFragment != null)
      {
        localObject2 = localObject1;
        if (!localB.jdField_a_of_type_AndroidSupportV4AppFragment.isDetached())
        {
          if (!localB.jdField_a_of_type_JavaLangString.equals(str)) {
            break label108;
          }
          this.jdField_a_of_type_B = localB;
          localObject2 = localObject1;
        }
      }
      for (;;)
      {
        i += 1;
        localObject1 = localObject2;
        break;
        label108:
        localObject2 = localObject1;
        if (localObject1 == null) {
          localObject2 = this.jdField_a_of_type_AndroidSupportV4AppFragmentManager.beginTransaction();
        }
        ((FragmentTransaction)localObject2).detach(localB.jdField_a_of_type_AndroidSupportV4AppFragment);
      }
    }
    this.jdField_a_of_type_Boolean = true;
    localObject1 = a(str, (FragmentTransaction)localObject1);
    if (localObject1 != null)
    {
      ((FragmentTransaction)localObject1).commit();
      this.jdField_a_of_type_AndroidSupportV4AppFragmentManager.executePendingTransactions();
    }
  }
  
  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    this.jdField_a_of_type_Boolean = false;
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable)
  {
    paramParcelable = (z)paramParcelable;
    super.onRestoreInstanceState(paramParcelable.getSuperState());
    setCurrentTabByTag(paramParcelable.jdField_a_of_type_JavaLangString);
  }
  
  protected Parcelable onSaveInstanceState()
  {
    z localz = new z(super.onSaveInstanceState());
    localz.jdField_a_of_type_JavaLangString = getCurrentTabTag();
    return localz;
  }
  
  public void onTabChanged(String paramString)
  {
    if (this.jdField_a_of_type_Boolean)
    {
      FragmentTransaction localFragmentTransaction = a(paramString, null);
      if (localFragmentTransaction != null) {
        localFragmentTransaction.commit();
      }
    }
    if (this.jdField_a_of_type_AndroidWidgetTabHost$OnTabChangeListener != null) {
      this.jdField_a_of_type_AndroidWidgetTabHost$OnTabChangeListener.onTabChanged(paramString);
    }
  }
  
  public void setOnTabChangedListener(TabHost.OnTabChangeListener paramOnTabChangeListener)
  {
    this.jdField_a_of_type_AndroidWidgetTabHost$OnTabChangeListener = paramOnTabChangeListener;
  }
  
  public void setup()
  {
    throw new IllegalStateException("Must call setup() that takes a Context and FragmentManager");
  }
  
  public void setup(Context paramContext, FragmentManager paramFragmentManager)
  {
    super.setup();
    this.jdField_a_of_type_AndroidContentContext = paramContext;
    this.jdField_a_of_type_AndroidSupportV4AppFragmentManager = paramFragmentManager;
    a();
  }
  
  public void setup(Context paramContext, FragmentManager paramFragmentManager, int paramInt)
  {
    super.setup();
    this.jdField_a_of_type_AndroidContentContext = paramContext;
    this.jdField_a_of_type_AndroidSupportV4AppFragmentManager = paramFragmentManager;
    this.jdField_a_of_type_Int = paramInt;
    a();
    this.jdField_a_of_type_AndroidWidgetFrameLayout.setId(paramInt);
    if (getId() == -1) {
      setId(16908306);
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/app/FragmentTabHost.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */