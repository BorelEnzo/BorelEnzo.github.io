package android.support.v4.app;

import V;
import W;
import X;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import java.util.ArrayList;
import java.util.Iterator;

public class TaskStackBuilder
  implements Iterable
{
  private static final V jdField_a_of_type_V = new W();
  private final Context jdField_a_of_type_AndroidContentContext;
  private final ArrayList jdField_a_of_type_JavaUtilArrayList = new ArrayList();
  
  static
  {
    if (Build.VERSION.SDK_INT >= 11)
    {
      jdField_a_of_type_V = new X();
      return;
    }
  }
  
  private TaskStackBuilder(Context paramContext)
  {
    this.jdField_a_of_type_AndroidContentContext = paramContext;
  }
  
  public static TaskStackBuilder create(Context paramContext)
  {
    return new TaskStackBuilder(paramContext);
  }
  
  public static TaskStackBuilder from(Context paramContext)
  {
    return create(paramContext);
  }
  
  public TaskStackBuilder addNextIntent(Intent paramIntent)
  {
    this.jdField_a_of_type_JavaUtilArrayList.add(paramIntent);
    return this;
  }
  
  public TaskStackBuilder addNextIntentWithParentStack(Intent paramIntent)
  {
    ComponentName localComponentName2 = paramIntent.getComponent();
    ComponentName localComponentName1 = localComponentName2;
    if (localComponentName2 == null) {
      localComponentName1 = paramIntent.resolveActivity(this.jdField_a_of_type_AndroidContentContext.getPackageManager());
    }
    if (localComponentName1 != null) {
      addParentStack(localComponentName1);
    }
    addNextIntent(paramIntent);
    return this;
  }
  
  public TaskStackBuilder addParentStack(Activity paramActivity)
  {
    Intent localIntent = NavUtils.getParentActivityIntent(paramActivity);
    if (localIntent != null)
    {
      ComponentName localComponentName = localIntent.getComponent();
      paramActivity = localComponentName;
      if (localComponentName == null) {
        paramActivity = localIntent.resolveActivity(this.jdField_a_of_type_AndroidContentContext.getPackageManager());
      }
      addParentStack(paramActivity);
      addNextIntent(localIntent);
    }
    return this;
  }
  
  public TaskStackBuilder addParentStack(ComponentName paramComponentName)
  {
    int i = this.jdField_a_of_type_JavaUtilArrayList.size();
    try
    {
      for (paramComponentName = NavUtils.getParentActivityIntent(this.jdField_a_of_type_AndroidContentContext, paramComponentName); paramComponentName != null; paramComponentName = NavUtils.getParentActivityIntent(this.jdField_a_of_type_AndroidContentContext, paramComponentName.getComponent())) {
        this.jdField_a_of_type_JavaUtilArrayList.add(i, paramComponentName);
      }
      return this;
    }
    catch (PackageManager.NameNotFoundException paramComponentName)
    {
      throw new IllegalArgumentException(paramComponentName);
    }
  }
  
  public TaskStackBuilder addParentStack(Class paramClass)
  {
    return addParentStack(new ComponentName(this.jdField_a_of_type_AndroidContentContext, paramClass));
  }
  
  public Intent editIntentAt(int paramInt)
  {
    return (Intent)this.jdField_a_of_type_JavaUtilArrayList.get(paramInt);
  }
  
  public Intent getIntent(int paramInt)
  {
    return editIntentAt(paramInt);
  }
  
  public int getIntentCount()
  {
    return this.jdField_a_of_type_JavaUtilArrayList.size();
  }
  
  public Intent[] getIntents()
  {
    Intent[] arrayOfIntent = new Intent[this.jdField_a_of_type_JavaUtilArrayList.size()];
    if (arrayOfIntent.length == 0) {
      return arrayOfIntent;
    }
    arrayOfIntent[0] = new Intent((Intent)this.jdField_a_of_type_JavaUtilArrayList.get(0)).addFlags(268484608);
    int i = 1;
    while (i < arrayOfIntent.length)
    {
      arrayOfIntent[i] = new Intent((Intent)this.jdField_a_of_type_JavaUtilArrayList.get(i));
      i += 1;
    }
    return arrayOfIntent;
  }
  
  public PendingIntent getPendingIntent(int paramInt1, int paramInt2)
  {
    return getPendingIntent(paramInt1, paramInt2, null);
  }
  
  public PendingIntent getPendingIntent(int paramInt1, int paramInt2, Bundle paramBundle)
  {
    if (this.jdField_a_of_type_JavaUtilArrayList.isEmpty()) {
      throw new IllegalStateException("No intents added to TaskStackBuilder; cannot getPendingIntent");
    }
    paramBundle = (Intent[])this.jdField_a_of_type_JavaUtilArrayList.toArray(new Intent[this.jdField_a_of_type_JavaUtilArrayList.size()]);
    paramBundle[0] = new Intent(paramBundle[0]).addFlags(268484608);
    return jdField_a_of_type_V.a(this.jdField_a_of_type_AndroidContentContext, paramBundle, paramInt1, paramInt2);
  }
  
  public Iterator iterator()
  {
    return this.jdField_a_of_type_JavaUtilArrayList.iterator();
  }
  
  public void startActivities()
  {
    startActivities(null);
  }
  
  public void startActivities(Bundle paramBundle)
  {
    if (this.jdField_a_of_type_JavaUtilArrayList.isEmpty()) {
      throw new IllegalStateException("No intents added to TaskStackBuilder; cannot startActivities");
    }
    Intent[] arrayOfIntent = (Intent[])this.jdField_a_of_type_JavaUtilArrayList.toArray(new Intent[this.jdField_a_of_type_JavaUtilArrayList.size()]);
    arrayOfIntent[0] = new Intent(arrayOfIntent[0]).addFlags(268484608);
    if (!ContextCompat.startActivities(this.jdField_a_of_type_AndroidContentContext, arrayOfIntent, paramBundle))
    {
      paramBundle = new Intent(arrayOfIntent[(arrayOfIntent.length - 1)]);
      paramBundle.addFlags(268435456);
      this.jdField_a_of_type_AndroidContentContext.startActivity(paramBundle);
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/app/TaskStackBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */