package android.support.v4.app;

import java.util.ArrayList;

public class NotificationCompat$InboxStyle
  extends NotificationCompat.Style
{
  public ArrayList a;
  
  public NotificationCompat$InboxStyle()
  {
    this.jdField_a_of_type_JavaUtilArrayList = new ArrayList();
  }
  
  public NotificationCompat$InboxStyle(NotificationCompat.Builder paramBuilder)
  {
    this.jdField_a_of_type_JavaUtilArrayList = new ArrayList();
    setBuilder(paramBuilder);
  }
  
  public InboxStyle addLine(CharSequence paramCharSequence)
  {
    this.jdField_a_of_type_JavaUtilArrayList.add(paramCharSequence);
    return this;
  }
  
  public InboxStyle setBigContentTitle(CharSequence paramCharSequence)
  {
    this.b = paramCharSequence;
    return this;
  }
  
  public InboxStyle setSummaryText(CharSequence paramCharSequence)
  {
    this.c = paramCharSequence;
    this.jdField_a_of_type_Boolean = true;
    return this;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/app/NotificationCompat$InboxStyle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */