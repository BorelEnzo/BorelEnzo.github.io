package android.support.v4.app;

import E;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.TypedArray;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import j;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import k;
import l;
import m;
import n;
import o;

public class FragmentActivity
  extends Activity
{
  E jdField_a_of_type_E;
  public final Handler a;
  HashMap jdField_a_of_type_JavaUtilHashMap;
  final n jdField_a_of_type_N = new k(this);
  public final o a;
  boolean jdField_a_of_type_Boolean;
  boolean b;
  public boolean c;
  boolean d;
  boolean e;
  boolean f;
  boolean g;
  boolean h;
  
  public FragmentActivity()
  {
    this.jdField_a_of_type_AndroidOsHandler = new j(this);
    this.jdField_a_of_type_O = new o();
  }
  
  private static String a(View paramView)
  {
    char c3 = 'F';
    char c2 = '.';
    StringBuilder localStringBuilder = new StringBuilder(128);
    localStringBuilder.append(paramView.getClass().getName());
    localStringBuilder.append('{');
    localStringBuilder.append(Integer.toHexString(System.identityHashCode(paramView)));
    localStringBuilder.append(' ');
    char c1;
    label118:
    label135:
    label152:
    label169:
    label186:
    label203:
    label220:
    label244:
    label261:
    int i;
    Object localObject;
    switch (paramView.getVisibility())
    {
    default: 
      localStringBuilder.append('.');
      if (paramView.isFocusable())
      {
        c1 = 'F';
        localStringBuilder.append(c1);
        if (!paramView.isEnabled()) {
          break label562;
        }
        c1 = 'E';
        localStringBuilder.append(c1);
        if (!paramView.willNotDraw()) {
          break label568;
        }
        c1 = '.';
        localStringBuilder.append(c1);
        if (!paramView.isHorizontalScrollBarEnabled()) {
          break label574;
        }
        c1 = 'H';
        localStringBuilder.append(c1);
        if (!paramView.isVerticalScrollBarEnabled()) {
          break label580;
        }
        c1 = 'V';
        localStringBuilder.append(c1);
        if (!paramView.isClickable()) {
          break label586;
        }
        c1 = 'C';
        localStringBuilder.append(c1);
        if (!paramView.isLongClickable()) {
          break label592;
        }
        c1 = 'L';
        localStringBuilder.append(c1);
        localStringBuilder.append(' ');
        if (!paramView.isFocused()) {
          break label598;
        }
        c1 = c3;
        localStringBuilder.append(c1);
        if (!paramView.isSelected()) {
          break label604;
        }
        c1 = 'S';
        localStringBuilder.append(c1);
        c1 = c2;
        if (paramView.isPressed()) {
          c1 = 'P';
        }
        localStringBuilder.append(c1);
        localStringBuilder.append(' ');
        localStringBuilder.append(paramView.getLeft());
        localStringBuilder.append(',');
        localStringBuilder.append(paramView.getTop());
        localStringBuilder.append('-');
        localStringBuilder.append(paramView.getRight());
        localStringBuilder.append(',');
        localStringBuilder.append(paramView.getBottom());
        i = paramView.getId();
        if (i != -1)
        {
          localStringBuilder.append(" #");
          localStringBuilder.append(Integer.toHexString(i));
          localObject = paramView.getResources();
          if ((i != 0) && (localObject != null)) {
            switch (0xFF000000 & i)
            {
            }
          }
        }
      }
      break;
    }
    for (;;)
    {
      try
      {
        paramView = ((Resources)localObject).getResourcePackageName(i);
        String str = ((Resources)localObject).getResourceTypeName(i);
        localObject = ((Resources)localObject).getResourceEntryName(i);
        localStringBuilder.append(" ");
        localStringBuilder.append(paramView);
        localStringBuilder.append(":");
        localStringBuilder.append(str);
        localStringBuilder.append("/");
        localStringBuilder.append((String)localObject);
      }
      catch (Resources.NotFoundException paramView)
      {
        label562:
        label568:
        label574:
        label580:
        label586:
        label592:
        label598:
        label604:
        continue;
      }
      localStringBuilder.append("}");
      return localStringBuilder.toString();
      localStringBuilder.append('V');
      break;
      localStringBuilder.append('I');
      break;
      localStringBuilder.append('G');
      break;
      c1 = '.';
      break label118;
      c1 = '.';
      break label135;
      c1 = 'D';
      break label152;
      c1 = '.';
      break label169;
      c1 = '.';
      break label186;
      c1 = '.';
      break label203;
      c1 = '.';
      break label220;
      c1 = '.';
      break label244;
      c1 = '.';
      break label261;
      paramView = "app";
      continue;
      paramView = "android";
    }
  }
  
  private void a(String paramString, PrintWriter paramPrintWriter, View paramView)
  {
    paramPrintWriter.print(paramString);
    if (paramView == null) {
      paramPrintWriter.println("null");
    }
    for (;;)
    {
      return;
      paramPrintWriter.println(a(paramView));
      if ((paramView instanceof ViewGroup))
      {
        paramView = (ViewGroup)paramView;
        int j = paramView.getChildCount();
        if (j > 0)
        {
          paramString = paramString + "  ";
          int i = 0;
          while (i < j)
          {
            a(paramString, paramPrintWriter, paramView.getChildAt(i));
            i += 1;
          }
        }
      }
    }
  }
  
  final E a(String paramString, boolean paramBoolean1, boolean paramBoolean2)
  {
    if (this.jdField_a_of_type_JavaUtilHashMap == null) {
      this.jdField_a_of_type_JavaUtilHashMap = new HashMap();
    }
    E localE = (E)this.jdField_a_of_type_JavaUtilHashMap.get(paramString);
    if (localE == null)
    {
      if (paramBoolean2)
      {
        localE = new E(paramString, this, paramBoolean1);
        this.jdField_a_of_type_JavaUtilHashMap.put(paramString, localE);
      }
      return localE;
    }
    localE.a(this);
    return localE;
  }
  
  public final void a(String paramString)
  {
    if (this.jdField_a_of_type_JavaUtilHashMap != null)
    {
      E localE = (E)this.jdField_a_of_type_JavaUtilHashMap.get(paramString);
      if ((localE != null) && (!localE.c))
      {
        localE.g();
        this.jdField_a_of_type_JavaUtilHashMap.remove(paramString);
      }
    }
  }
  
  public final void a(boolean paramBoolean)
  {
    if (!this.d)
    {
      this.d = true;
      this.e = paramBoolean;
      this.jdField_a_of_type_AndroidOsHandler.removeMessages(1);
      if (this.h)
      {
        this.h = false;
        if (this.jdField_a_of_type_E != null)
        {
          if (this.e) {
            break label66;
          }
          this.jdField_a_of_type_E.b();
        }
      }
    }
    for (;;)
    {
      this.jdField_a_of_type_O.i();
      return;
      label66:
      this.jdField_a_of_type_E.c();
    }
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    int i = Build.VERSION.SDK_INT;
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("Local FragmentActivity ");
    paramPrintWriter.print(Integer.toHexString(System.identityHashCode(this)));
    paramPrintWriter.println(" State:");
    String str = paramString + "  ";
    paramPrintWriter.print(str);
    paramPrintWriter.print("mCreated=");
    paramPrintWriter.print(this.jdField_a_of_type_Boolean);
    paramPrintWriter.print("mResumed=");
    paramPrintWriter.print(this.b);
    paramPrintWriter.print(" mStopped=");
    paramPrintWriter.print(this.c);
    paramPrintWriter.print(" mReallyStopped=");
    paramPrintWriter.println(this.d);
    paramPrintWriter.print(str);
    paramPrintWriter.print("mLoadersStarted=");
    paramPrintWriter.println(this.h);
    if (this.jdField_a_of_type_E != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("Loader Manager ");
      paramPrintWriter.print(Integer.toHexString(System.identityHashCode(this.jdField_a_of_type_E)));
      paramPrintWriter.println(":");
      this.jdField_a_of_type_E.dump(paramString + "  ", paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    }
    this.jdField_a_of_type_O.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.print(paramString);
    paramPrintWriter.println("View Hierarchy:");
    a(paramString + "  ", paramPrintWriter, getWindow().getDecorView());
  }
  
  public Object getLastCustomNonConfigurationInstance()
  {
    m localm = (m)getLastNonConfigurationInstance();
    if (localm != null) {
      return localm.jdField_b_of_type_JavaLangObject;
    }
    return null;
  }
  
  public FragmentManager getSupportFragmentManager()
  {
    return this.jdField_a_of_type_O;
  }
  
  public LoaderManager getSupportLoaderManager()
  {
    if (this.jdField_a_of_type_E != null) {
      return this.jdField_a_of_type_E;
    }
    this.g = true;
    this.jdField_a_of_type_E = a(null, this.h, true);
    return this.jdField_a_of_type_E;
  }
  
  protected void onActivityResult(int paramInt1, int paramInt2, Intent paramIntent)
  {
    this.jdField_a_of_type_O.b();
    int i = paramInt1 >> 16;
    if (i != 0)
    {
      i -= 1;
      if ((this.jdField_a_of_type_O.b == null) || (i < 0) || (i >= this.jdField_a_of_type_O.b.size()))
      {
        new StringBuilder("Activity result fragment index out of range: 0x").append(Integer.toHexString(paramInt1)).toString();
        return;
      }
      Fragment localFragment = (Fragment)this.jdField_a_of_type_O.b.get(i);
      if (localFragment == null)
      {
        new StringBuilder("Activity result no fragment exists for index: 0x").append(Integer.toHexString(paramInt1)).toString();
        return;
      }
      localFragment.onActivityResult(0xFFFF & paramInt1, paramInt2, paramIntent);
      return;
    }
    super.onActivityResult(paramInt1, paramInt2, paramIntent);
  }
  
  public void onAttachFragment(Fragment paramFragment) {}
  
  public void onBackPressed()
  {
    if (!this.jdField_a_of_type_O.popBackStackImmediate()) {
      finish();
    }
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration)
  {
    super.onConfigurationChanged(paramConfiguration);
    this.jdField_a_of_type_O.a(paramConfiguration);
  }
  
  protected void onCreate(Bundle paramBundle)
  {
    this.jdField_a_of_type_O.a(this, this.jdField_a_of_type_N, null);
    if (getLayoutInflater().getFactory() == null) {
      getLayoutInflater().setFactory(this);
    }
    super.onCreate(paramBundle);
    m localm = (m)getLastNonConfigurationInstance();
    if (localm != null) {
      this.jdField_a_of_type_JavaUtilHashMap = localm.jdField_b_of_type_JavaUtilHashMap;
    }
    Parcelable localParcelable;
    o localo;
    if (paramBundle != null)
    {
      localParcelable = paramBundle.getParcelable("android:support:fragments");
      localo = this.jdField_a_of_type_O;
      if (localm == null) {
        break label101;
      }
    }
    label101:
    for (paramBundle = localm.jdField_a_of_type_JavaUtilArrayList;; paramBundle = null)
    {
      localo.a(localParcelable, paramBundle);
      this.jdField_a_of_type_O.c();
      return;
    }
  }
  
  public boolean onCreatePanelMenu(int paramInt, Menu paramMenu)
  {
    if (paramInt == 0)
    {
      boolean bool1 = super.onCreatePanelMenu(paramInt, paramMenu);
      boolean bool2 = this.jdField_a_of_type_O.a(paramMenu, getMenuInflater());
      if (Build.VERSION.SDK_INT >= 11) {
        return bool1 | bool2;
      }
      return true;
    }
    return super.onCreatePanelMenu(paramInt, paramMenu);
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet)
  {
    Object localObject = null;
    if (!"fragment".equals(paramString)) {
      return super.onCreateView(paramString, paramContext, paramAttributeSet);
    }
    paramString = paramAttributeSet.getAttributeValue(null, "class");
    paramContext = paramContext.obtainStyledAttributes(paramAttributeSet, l.a);
    String str1 = paramString;
    if (paramString == null) {
      str1 = paramContext.getString(0);
    }
    int j = paramContext.getResourceId(1, -1);
    String str2 = paramContext.getString(2);
    paramContext.recycle();
    paramContext = (Context)localObject;
    if (j != -1) {
      paramContext = this.jdField_a_of_type_O.findFragmentById(j);
    }
    paramString = paramContext;
    if (paramContext == null)
    {
      paramString = paramContext;
      if (str2 != null) {
        paramString = this.jdField_a_of_type_O.findFragmentByTag(str2);
      }
    }
    paramContext = paramString;
    if (paramString == null) {
      paramContext = this.jdField_a_of_type_O.findFragmentById(0);
    }
    if (o.jdField_a_of_type_Boolean) {
      new StringBuilder("onCreateView: id=0x").append(Integer.toHexString(j)).append(" fname=").append(str1).append(" existing=").append(paramContext).toString();
    }
    int i;
    if (paramContext == null)
    {
      paramString = Fragment.instantiate(this, str1);
      paramString.i = true;
      if (j != 0)
      {
        i = j;
        paramString.jdField_j_of_type_Int = i;
        paramString.k = 0;
        paramString.jdField_b_of_type_JavaLangString = str2;
        paramString.jdField_j_of_type_Boolean = true;
        paramString.jdField_a_of_type_O = this.jdField_a_of_type_O;
        paramString.onInflate(this, paramAttributeSet, paramString.jdField_a_of_type_AndroidOsBundle);
        this.jdField_a_of_type_O.a(paramString, true);
      }
    }
    for (;;)
    {
      if (paramString.jdField_b_of_type_AndroidViewView != null) {
        break label417;
      }
      throw new IllegalStateException("Fragment " + str1 + " did not create a view.");
      i = 0;
      break;
      if (paramContext.jdField_j_of_type_Boolean) {
        throw new IllegalArgumentException(paramAttributeSet.getPositionDescription() + ": Duplicate id 0x" + Integer.toHexString(j) + ", tag " + str2 + ", or parent id 0x" + Integer.toHexString(0) + " with another fragment for " + str1);
      }
      paramContext.jdField_j_of_type_Boolean = true;
      if (!paramContext.o) {
        paramContext.onInflate(this, paramAttributeSet, paramContext.jdField_a_of_type_AndroidOsBundle);
      }
      this.jdField_a_of_type_O.b(paramContext);
      paramString = paramContext;
    }
    label417:
    if (j != 0) {
      paramString.jdField_b_of_type_AndroidViewView.setId(j);
    }
    if (paramString.jdField_b_of_type_AndroidViewView.getTag() == null) {
      paramString.jdField_b_of_type_AndroidViewView.setTag(str2);
    }
    return paramString.jdField_b_of_type_AndroidViewView;
  }
  
  protected void onDestroy()
  {
    super.onDestroy();
    a(false);
    this.jdField_a_of_type_O.k();
    if (this.jdField_a_of_type_E != null) {
      this.jdField_a_of_type_E.g();
    }
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent)
  {
    if ((Build.VERSION.SDK_INT < 5) && (paramInt == 4) && (paramKeyEvent.getRepeatCount() == 0))
    {
      onBackPressed();
      return true;
    }
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public void onLowMemory()
  {
    super.onLowMemory();
    this.jdField_a_of_type_O.l();
  }
  
  public boolean onMenuItemSelected(int paramInt, MenuItem paramMenuItem)
  {
    if (super.onMenuItemSelected(paramInt, paramMenuItem)) {
      return true;
    }
    switch (paramInt)
    {
    default: 
      return false;
    case 0: 
      return this.jdField_a_of_type_O.a(paramMenuItem);
    }
    return this.jdField_a_of_type_O.b(paramMenuItem);
  }
  
  protected void onNewIntent(Intent paramIntent)
  {
    super.onNewIntent(paramIntent);
    this.jdField_a_of_type_O.b();
  }
  
  public void onPanelClosed(int paramInt, Menu paramMenu)
  {
    switch (paramInt)
    {
    }
    for (;;)
    {
      super.onPanelClosed(paramInt, paramMenu);
      return;
      this.jdField_a_of_type_O.a(paramMenu);
    }
  }
  
  protected void onPause()
  {
    super.onPause();
    this.b = false;
    if (this.jdField_a_of_type_AndroidOsHandler.hasMessages(2))
    {
      this.jdField_a_of_type_AndroidOsHandler.removeMessages(2);
      onResumeFragments();
    }
    this.jdField_a_of_type_O.g();
  }
  
  protected void onPostResume()
  {
    super.onPostResume();
    this.jdField_a_of_type_AndroidOsHandler.removeMessages(2);
    onResumeFragments();
    this.jdField_a_of_type_O.a();
  }
  
  public boolean onPreparePanel(int paramInt, View paramView, Menu paramMenu)
  {
    boolean bool2 = false;
    if ((paramInt == 0) && (paramMenu != null))
    {
      if (this.f)
      {
        this.f = false;
        paramMenu.clear();
        onCreatePanelMenu(paramInt, paramMenu);
      }
      boolean bool1 = bool2;
      if ((super.onPreparePanel(paramInt, paramView, paramMenu) | this.jdField_a_of_type_O.a(paramMenu)))
      {
        bool1 = bool2;
        if (paramMenu.hasVisibleItems()) {
          bool1 = true;
        }
      }
      return bool1;
    }
    return super.onPreparePanel(paramInt, paramView, paramMenu);
  }
  
  protected void onResume()
  {
    super.onResume();
    this.jdField_a_of_type_AndroidOsHandler.sendEmptyMessage(2);
    this.b = true;
    this.jdField_a_of_type_O.a();
  }
  
  public void onResumeFragments()
  {
    this.jdField_a_of_type_O.f();
  }
  
  public Object onRetainCustomNonConfigurationInstance()
  {
    return null;
  }
  
  public final Object onRetainNonConfigurationInstance()
  {
    int j = 0;
    if (this.c) {
      a(true);
    }
    Object localObject1 = onRetainCustomNonConfigurationInstance();
    ArrayList localArrayList = this.jdField_a_of_type_O.a();
    int k;
    if (this.jdField_a_of_type_JavaUtilHashMap != null)
    {
      localObject2 = new E[this.jdField_a_of_type_JavaUtilHashMap.size()];
      this.jdField_a_of_type_JavaUtilHashMap.values().toArray((Object[])localObject2);
      int i = 0;
      k = i;
      if (j < localObject2.length)
      {
        Object localObject3 = localObject2[j];
        if (((E)localObject3).c) {
          i = 1;
        }
        for (;;)
        {
          j += 1;
          break;
          ((E)localObject3).g();
          this.jdField_a_of_type_JavaUtilHashMap.remove(((E)localObject3).a);
        }
      }
    }
    else
    {
      k = 0;
    }
    if ((localArrayList == null) && (k == 0) && (localObject1 == null)) {
      return null;
    }
    Object localObject2 = new m();
    ((m)localObject2).jdField_a_of_type_JavaLangObject = null;
    ((m)localObject2).jdField_b_of_type_JavaLangObject = localObject1;
    ((m)localObject2).jdField_a_of_type_JavaUtilHashMap = null;
    ((m)localObject2).jdField_a_of_type_JavaUtilArrayList = localArrayList;
    ((m)localObject2).jdField_b_of_type_JavaUtilHashMap = this.jdField_a_of_type_JavaUtilHashMap;
    return localObject2;
  }
  
  protected void onSaveInstanceState(Bundle paramBundle)
  {
    super.onSaveInstanceState(paramBundle);
    Parcelable localParcelable = this.jdField_a_of_type_O.a();
    if (localParcelable != null) {
      paramBundle.putParcelable("android:support:fragments", localParcelable);
    }
  }
  
  protected void onStart()
  {
    int i = 0;
    super.onStart();
    this.c = false;
    this.d = false;
    this.jdField_a_of_type_AndroidOsHandler.removeMessages(1);
    if (!this.jdField_a_of_type_Boolean)
    {
      this.jdField_a_of_type_Boolean = true;
      this.jdField_a_of_type_O.d();
    }
    this.jdField_a_of_type_O.b();
    this.jdField_a_of_type_O.a();
    if (!this.h)
    {
      this.h = true;
      if (this.jdField_a_of_type_E == null) {
        break label153;
      }
      this.jdField_a_of_type_E.a();
    }
    for (;;)
    {
      this.g = true;
      this.jdField_a_of_type_O.e();
      if (this.jdField_a_of_type_JavaUtilHashMap == null) {
        break;
      }
      E[] arrayOfE = new E[this.jdField_a_of_type_JavaUtilHashMap.size()];
      this.jdField_a_of_type_JavaUtilHashMap.values().toArray(arrayOfE);
      while (i < arrayOfE.length)
      {
        E localE = arrayOfE[i];
        localE.d();
        localE.f();
        i += 1;
      }
      label153:
      if (!this.g)
      {
        this.jdField_a_of_type_E = a(null, this.h, false);
        if ((this.jdField_a_of_type_E != null) && (!this.jdField_a_of_type_E.b)) {
          this.jdField_a_of_type_E.a();
        }
      }
    }
  }
  
  protected void onStop()
  {
    super.onStop();
    this.c = true;
    this.jdField_a_of_type_AndroidOsHandler.sendEmptyMessage(1);
    this.jdField_a_of_type_O.h();
  }
  
  public void startActivityForResult(Intent paramIntent, int paramInt)
  {
    if ((paramInt != -1) && ((0xFFFF0000 & paramInt) != 0)) {
      throw new IllegalArgumentException("Can only use lower 16 bits for requestCode");
    }
    super.startActivityForResult(paramIntent, paramInt);
  }
  
  public void startActivityFromFragment(Fragment paramFragment, Intent paramIntent, int paramInt)
  {
    if (paramInt == -1)
    {
      super.startActivityForResult(paramIntent, -1);
      return;
    }
    if ((0xFFFF0000 & paramInt) != 0) {
      throw new IllegalArgumentException("Can only use lower 16 bits for requestCode");
    }
    super.startActivityForResult(paramIntent, (paramFragment.f + 1 << 16) + (0xFFFF & paramInt));
  }
  
  public void supportInvalidateOptionsMenu()
  {
    if (Build.VERSION.SDK_INT >= 11)
    {
      invalidateOptionsMenu();
      return;
    }
    this.f = true;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/app/FragmentActivity.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */