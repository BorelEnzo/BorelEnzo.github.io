package android.support.v4.util;

import java.io.Writer;

public class LogWriter
  extends Writer
{
  private final String jdField_a_of_type_JavaLangString;
  private StringBuilder jdField_a_of_type_JavaLangStringBuilder = new StringBuilder(128);
  
  public LogWriter(String paramString)
  {
    this.jdField_a_of_type_JavaLangString = paramString;
  }
  
  private void a()
  {
    if (this.jdField_a_of_type_JavaLangStringBuilder.length() > 0)
    {
      String str = this.jdField_a_of_type_JavaLangString;
      this.jdField_a_of_type_JavaLangStringBuilder.toString();
      this.jdField_a_of_type_JavaLangStringBuilder.delete(0, this.jdField_a_of_type_JavaLangStringBuilder.length());
    }
  }
  
  public void close()
  {
    a();
  }
  
  public void flush()
  {
    a();
  }
  
  public void write(char[] paramArrayOfChar, int paramInt1, int paramInt2)
  {
    int i = 0;
    if (i < paramInt2)
    {
      char c = paramArrayOfChar[(paramInt1 + i)];
      if (c == '\n') {
        a();
      }
      for (;;)
      {
        i += 1;
        break;
        this.jdField_a_of_type_JavaLangStringBuilder.append(c);
      }
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/util/LogWriter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */