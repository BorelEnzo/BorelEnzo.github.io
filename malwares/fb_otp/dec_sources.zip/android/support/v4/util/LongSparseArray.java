package android.support.v4.util;

public class LongSparseArray
  implements Cloneable
{
  private static final Object jdField_a_of_type_JavaLangObject = new Object();
  private int jdField_a_of_type_Int;
  private boolean jdField_a_of_type_Boolean = false;
  private long[] jdField_a_of_type_ArrayOfLong;
  private Object[] jdField_a_of_type_ArrayOfJavaLangObject;
  
  public LongSparseArray()
  {
    this(10);
  }
  
  public LongSparseArray(int paramInt)
  {
    paramInt = idealLongArraySize(paramInt);
    this.jdField_a_of_type_ArrayOfLong = new long[paramInt];
    this.jdField_a_of_type_ArrayOfJavaLangObject = new Object[paramInt];
    this.jdField_a_of_type_Int = 0;
  }
  
  private static int a(long[] paramArrayOfLong, int paramInt, long paramLong)
  {
    int j = -1;
    int i = paramInt + 0;
    while (i - j > 1)
    {
      int k = (i + j) / 2;
      if (paramArrayOfLong[k] < paramLong) {
        j = k;
      } else {
        i = k;
      }
    }
    if (i == paramInt + 0) {
      paramInt = paramInt + 0 ^ 0xFFFFFFFF;
    }
    do
    {
      return paramInt;
      paramInt = i;
    } while (paramArrayOfLong[i] == paramLong);
    return i ^ 0xFFFFFFFF;
  }
  
  private void a()
  {
    int m = this.jdField_a_of_type_Int;
    long[] arrayOfLong = this.jdField_a_of_type_ArrayOfLong;
    Object[] arrayOfObject = this.jdField_a_of_type_ArrayOfJavaLangObject;
    int i = 0;
    int k;
    for (int j = 0; i < m; j = k)
    {
      Object localObject = arrayOfObject[i];
      k = j;
      if (localObject != jdField_a_of_type_JavaLangObject)
      {
        if (i != j)
        {
          arrayOfLong[j] = arrayOfLong[i];
          arrayOfObject[j] = localObject;
          arrayOfObject[i] = null;
        }
        k = j + 1;
      }
      i += 1;
    }
    this.jdField_a_of_type_Boolean = false;
    this.jdField_a_of_type_Int = j;
  }
  
  public static int idealByteArraySize(int paramInt)
  {
    int i = 4;
    for (;;)
    {
      int j = paramInt;
      if (i < 32)
      {
        if (paramInt <= (1 << i) - 12) {
          j = (1 << i) - 12;
        }
      }
      else {
        return j;
      }
      i += 1;
    }
  }
  
  public static int idealLongArraySize(int paramInt)
  {
    return idealByteArraySize(paramInt * 8) / 8;
  }
  
  public void append(long paramLong, Object paramObject)
  {
    if ((this.jdField_a_of_type_Int != 0) && (paramLong <= this.jdField_a_of_type_ArrayOfLong[(this.jdField_a_of_type_Int - 1)]))
    {
      put(paramLong, paramObject);
      return;
    }
    if ((this.jdField_a_of_type_Boolean) && (this.jdField_a_of_type_Int >= this.jdField_a_of_type_ArrayOfLong.length)) {
      a();
    }
    int i = this.jdField_a_of_type_Int;
    if (i >= this.jdField_a_of_type_ArrayOfLong.length)
    {
      int j = idealLongArraySize(i + 1);
      long[] arrayOfLong = new long[j];
      Object[] arrayOfObject = new Object[j];
      System.arraycopy(this.jdField_a_of_type_ArrayOfLong, 0, arrayOfLong, 0, this.jdField_a_of_type_ArrayOfLong.length);
      System.arraycopy(this.jdField_a_of_type_ArrayOfJavaLangObject, 0, arrayOfObject, 0, this.jdField_a_of_type_ArrayOfJavaLangObject.length);
      this.jdField_a_of_type_ArrayOfLong = arrayOfLong;
      this.jdField_a_of_type_ArrayOfJavaLangObject = arrayOfObject;
    }
    this.jdField_a_of_type_ArrayOfLong[i] = paramLong;
    this.jdField_a_of_type_ArrayOfJavaLangObject[i] = paramObject;
    this.jdField_a_of_type_Int = (i + 1);
  }
  
  public void clear()
  {
    int j = this.jdField_a_of_type_Int;
    Object[] arrayOfObject = this.jdField_a_of_type_ArrayOfJavaLangObject;
    int i = 0;
    while (i < j)
    {
      arrayOfObject[i] = null;
      i += 1;
    }
    this.jdField_a_of_type_Int = 0;
    this.jdField_a_of_type_Boolean = false;
  }
  
  public LongSparseArray clone()
  {
    try
    {
      LongSparseArray localLongSparseArray = (LongSparseArray)super.clone();
      return localCloneNotSupportedException1;
    }
    catch (CloneNotSupportedException localCloneNotSupportedException1)
    {
      try
      {
        localLongSparseArray.jdField_a_of_type_ArrayOfLong = ((long[])this.jdField_a_of_type_ArrayOfLong.clone());
        localLongSparseArray.jdField_a_of_type_ArrayOfJavaLangObject = ((Object[])this.jdField_a_of_type_ArrayOfJavaLangObject.clone());
        return localLongSparseArray;
      }
      catch (CloneNotSupportedException localCloneNotSupportedException2) {}
      localCloneNotSupportedException1 = localCloneNotSupportedException1;
      return null;
    }
  }
  
  public void delete(long paramLong)
  {
    int i = a(this.jdField_a_of_type_ArrayOfLong, this.jdField_a_of_type_Int, paramLong);
    if ((i >= 0) && (this.jdField_a_of_type_ArrayOfJavaLangObject[i] != jdField_a_of_type_JavaLangObject))
    {
      this.jdField_a_of_type_ArrayOfJavaLangObject[i] = jdField_a_of_type_JavaLangObject;
      this.jdField_a_of_type_Boolean = true;
    }
  }
  
  public Object get(long paramLong)
  {
    return get(paramLong, null);
  }
  
  public Object get(long paramLong, Object paramObject)
  {
    int i = a(this.jdField_a_of_type_ArrayOfLong, this.jdField_a_of_type_Int, paramLong);
    if ((i < 0) || (this.jdField_a_of_type_ArrayOfJavaLangObject[i] == jdField_a_of_type_JavaLangObject)) {
      return paramObject;
    }
    return this.jdField_a_of_type_ArrayOfJavaLangObject[i];
  }
  
  public int indexOfKey(long paramLong)
  {
    if (this.jdField_a_of_type_Boolean) {
      a();
    }
    return a(this.jdField_a_of_type_ArrayOfLong, this.jdField_a_of_type_Int, paramLong);
  }
  
  public int indexOfValue(Object paramObject)
  {
    if (this.jdField_a_of_type_Boolean) {
      a();
    }
    int i = 0;
    while (i < this.jdField_a_of_type_Int)
    {
      if (this.jdField_a_of_type_ArrayOfJavaLangObject[i] == paramObject) {
        return i;
      }
      i += 1;
    }
    return -1;
  }
  
  public long keyAt(int paramInt)
  {
    if (this.jdField_a_of_type_Boolean) {
      a();
    }
    return this.jdField_a_of_type_ArrayOfLong[paramInt];
  }
  
  public void put(long paramLong, Object paramObject)
  {
    int i = a(this.jdField_a_of_type_ArrayOfLong, this.jdField_a_of_type_Int, paramLong);
    if (i >= 0)
    {
      this.jdField_a_of_type_ArrayOfJavaLangObject[i] = paramObject;
      return;
    }
    int j = i ^ 0xFFFFFFFF;
    if ((j < this.jdField_a_of_type_Int) && (this.jdField_a_of_type_ArrayOfJavaLangObject[j] == jdField_a_of_type_JavaLangObject))
    {
      this.jdField_a_of_type_ArrayOfLong[j] = paramLong;
      this.jdField_a_of_type_ArrayOfJavaLangObject[j] = paramObject;
      return;
    }
    i = j;
    if (this.jdField_a_of_type_Boolean)
    {
      i = j;
      if (this.jdField_a_of_type_Int >= this.jdField_a_of_type_ArrayOfLong.length)
      {
        a();
        i = a(this.jdField_a_of_type_ArrayOfLong, this.jdField_a_of_type_Int, paramLong) ^ 0xFFFFFFFF;
      }
    }
    if (this.jdField_a_of_type_Int >= this.jdField_a_of_type_ArrayOfLong.length)
    {
      j = idealLongArraySize(this.jdField_a_of_type_Int + 1);
      long[] arrayOfLong = new long[j];
      Object[] arrayOfObject = new Object[j];
      System.arraycopy(this.jdField_a_of_type_ArrayOfLong, 0, arrayOfLong, 0, this.jdField_a_of_type_ArrayOfLong.length);
      System.arraycopy(this.jdField_a_of_type_ArrayOfJavaLangObject, 0, arrayOfObject, 0, this.jdField_a_of_type_ArrayOfJavaLangObject.length);
      this.jdField_a_of_type_ArrayOfLong = arrayOfLong;
      this.jdField_a_of_type_ArrayOfJavaLangObject = arrayOfObject;
    }
    if (this.jdField_a_of_type_Int - i != 0)
    {
      System.arraycopy(this.jdField_a_of_type_ArrayOfLong, i, this.jdField_a_of_type_ArrayOfLong, i + 1, this.jdField_a_of_type_Int - i);
      System.arraycopy(this.jdField_a_of_type_ArrayOfJavaLangObject, i, this.jdField_a_of_type_ArrayOfJavaLangObject, i + 1, this.jdField_a_of_type_Int - i);
    }
    this.jdField_a_of_type_ArrayOfLong[i] = paramLong;
    this.jdField_a_of_type_ArrayOfJavaLangObject[i] = paramObject;
    this.jdField_a_of_type_Int += 1;
  }
  
  public void remove(long paramLong)
  {
    delete(paramLong);
  }
  
  public void removeAt(int paramInt)
  {
    if (this.jdField_a_of_type_ArrayOfJavaLangObject[paramInt] != jdField_a_of_type_JavaLangObject)
    {
      this.jdField_a_of_type_ArrayOfJavaLangObject[paramInt] = jdField_a_of_type_JavaLangObject;
      this.jdField_a_of_type_Boolean = true;
    }
  }
  
  public void setValueAt(int paramInt, Object paramObject)
  {
    if (this.jdField_a_of_type_Boolean) {
      a();
    }
    this.jdField_a_of_type_ArrayOfJavaLangObject[paramInt] = paramObject;
  }
  
  public int size()
  {
    if (this.jdField_a_of_type_Boolean) {
      a();
    }
    return this.jdField_a_of_type_Int;
  }
  
  public Object valueAt(int paramInt)
  {
    if (this.jdField_a_of_type_Boolean) {
      a();
    }
    return this.jdField_a_of_type_ArrayOfJavaLangObject[paramInt];
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/util/LongSparseArray.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */