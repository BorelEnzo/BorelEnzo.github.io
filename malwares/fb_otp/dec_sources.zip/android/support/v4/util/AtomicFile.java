package android.support.v4.util;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class AtomicFile
{
  private final File a;
  private final File b;
  
  public AtomicFile(File paramFile)
  {
    this.a = paramFile;
    this.b = new File(paramFile.getPath() + ".bak");
  }
  
  private static boolean a(FileOutputStream paramFileOutputStream)
  {
    if (paramFileOutputStream != null) {}
    try
    {
      paramFileOutputStream.getFD().sync();
      return true;
    }
    catch (IOException paramFileOutputStream) {}
    return false;
  }
  
  public void delete()
  {
    this.a.delete();
    this.b.delete();
  }
  
  public void failWrite(FileOutputStream paramFileOutputStream)
  {
    if (paramFileOutputStream != null) {
      a(paramFileOutputStream);
    }
    try
    {
      paramFileOutputStream.close();
      this.a.delete();
      this.b.renameTo(this.a);
      return;
    }
    catch (IOException paramFileOutputStream) {}
  }
  
  public void finishWrite(FileOutputStream paramFileOutputStream)
  {
    if (paramFileOutputStream != null) {
      a(paramFileOutputStream);
    }
    try
    {
      paramFileOutputStream.close();
      this.b.delete();
      return;
    }
    catch (IOException paramFileOutputStream) {}
  }
  
  public File getBaseFile()
  {
    return this.a;
  }
  
  public FileInputStream openRead()
  {
    if (this.b.exists())
    {
      this.a.delete();
      this.b.renameTo(this.a);
    }
    return new FileInputStream(this.a);
  }
  
  public byte[] readFully()
  {
    int i = 0;
    FileInputStream localFileInputStream = openRead();
    try
    {
      Object localObject1 = new byte[localFileInputStream.available()];
      int j = localFileInputStream.read((byte[])localObject1, i, localObject1.length - i);
      if (j <= 0) {
        return (byte[])localObject1;
      }
      i = j + i;
      j = localFileInputStream.available();
      if (j > localObject1.length - i)
      {
        byte[] arrayOfByte = new byte[j + i];
        System.arraycopy(localObject1, 0, arrayOfByte, 0, i);
        localObject1 = arrayOfByte;
      }
      for (;;)
      {
        break;
      }
    }
    finally
    {
      localFileInputStream.close();
    }
  }
  
  public FileOutputStream startWrite()
  {
    if (this.a.exists())
    {
      if (this.b.exists()) {
        break label80;
      }
      if (!this.a.renameTo(this.b)) {
        new StringBuilder("Couldn't rename file ").append(this.a).append(" to backup file ").append(this.b).toString();
      }
    }
    for (;;)
    {
      try
      {
        FileOutputStream localFileOutputStream1 = new FileOutputStream(this.a);
        return localFileOutputStream1;
      }
      catch (FileNotFoundException localFileNotFoundException1)
      {
        label80:
        if (this.a.getParentFile().mkdir()) {
          continue;
        }
        throw new IOException("Couldn't create directory " + this.a);
        try
        {
          FileOutputStream localFileOutputStream2 = new FileOutputStream(this.a);
          return localFileOutputStream2;
        }
        catch (FileNotFoundException localFileNotFoundException2)
        {
          throw new IOException("Couldn't create " + this.a);
        }
      }
      this.a.delete();
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/util/AtomicFile.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */