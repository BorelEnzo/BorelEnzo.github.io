package android.support.v4.util;

public class SparseArrayCompat
{
  private static final Object jdField_a_of_type_JavaLangObject = new Object();
  private int jdField_a_of_type_Int;
  private boolean jdField_a_of_type_Boolean = false;
  private int[] jdField_a_of_type_ArrayOfInt;
  private Object[] jdField_a_of_type_ArrayOfJavaLangObject;
  
  public SparseArrayCompat()
  {
    this(10);
  }
  
  public SparseArrayCompat(int paramInt)
  {
    paramInt = a(paramInt);
    this.jdField_a_of_type_ArrayOfInt = new int[paramInt];
    this.jdField_a_of_type_ArrayOfJavaLangObject = new Object[paramInt];
    this.jdField_a_of_type_Int = 0;
  }
  
  private static int a(int paramInt)
  {
    int j = paramInt * 4;
    paramInt = 4;
    for (;;)
    {
      int i = j;
      if (paramInt < 32)
      {
        if (j <= (1 << paramInt) - 12) {
          i = (1 << paramInt) - 12;
        }
      }
      else {
        return i / 4;
      }
      paramInt += 1;
    }
  }
  
  private static int a(int[] paramArrayOfInt, int paramInt1, int paramInt2)
  {
    int j = -1;
    int i = paramInt1 + 0;
    while (i - j > 1)
    {
      int k = (i + j) / 2;
      if (paramArrayOfInt[k] < paramInt2) {
        j = k;
      } else {
        i = k;
      }
    }
    if (i == paramInt1 + 0) {
      paramInt1 = paramInt1 + 0 ^ 0xFFFFFFFF;
    }
    do
    {
      return paramInt1;
      paramInt1 = i;
    } while (paramArrayOfInt[i] == paramInt2);
    return i ^ 0xFFFFFFFF;
  }
  
  private void a()
  {
    int m = this.jdField_a_of_type_Int;
    int[] arrayOfInt = this.jdField_a_of_type_ArrayOfInt;
    Object[] arrayOfObject = this.jdField_a_of_type_ArrayOfJavaLangObject;
    int i = 0;
    int k;
    for (int j = 0; i < m; j = k)
    {
      Object localObject = arrayOfObject[i];
      k = j;
      if (localObject != jdField_a_of_type_JavaLangObject)
      {
        if (i != j)
        {
          arrayOfInt[j] = arrayOfInt[i];
          arrayOfObject[j] = localObject;
        }
        k = j + 1;
      }
      i += 1;
    }
    this.jdField_a_of_type_Boolean = false;
    this.jdField_a_of_type_Int = j;
  }
  
  public void append(int paramInt, Object paramObject)
  {
    if ((this.jdField_a_of_type_Int != 0) && (paramInt <= this.jdField_a_of_type_ArrayOfInt[(this.jdField_a_of_type_Int - 1)]))
    {
      put(paramInt, paramObject);
      return;
    }
    if ((this.jdField_a_of_type_Boolean) && (this.jdField_a_of_type_Int >= this.jdField_a_of_type_ArrayOfInt.length)) {
      a();
    }
    int i = this.jdField_a_of_type_Int;
    if (i >= this.jdField_a_of_type_ArrayOfInt.length)
    {
      int j = a(i + 1);
      int[] arrayOfInt = new int[j];
      Object[] arrayOfObject = new Object[j];
      System.arraycopy(this.jdField_a_of_type_ArrayOfInt, 0, arrayOfInt, 0, this.jdField_a_of_type_ArrayOfInt.length);
      System.arraycopy(this.jdField_a_of_type_ArrayOfJavaLangObject, 0, arrayOfObject, 0, this.jdField_a_of_type_ArrayOfJavaLangObject.length);
      this.jdField_a_of_type_ArrayOfInt = arrayOfInt;
      this.jdField_a_of_type_ArrayOfJavaLangObject = arrayOfObject;
    }
    this.jdField_a_of_type_ArrayOfInt[i] = paramInt;
    this.jdField_a_of_type_ArrayOfJavaLangObject[i] = paramObject;
    this.jdField_a_of_type_Int = (i + 1);
  }
  
  public void clear()
  {
    int j = this.jdField_a_of_type_Int;
    Object[] arrayOfObject = this.jdField_a_of_type_ArrayOfJavaLangObject;
    int i = 0;
    while (i < j)
    {
      arrayOfObject[i] = null;
      i += 1;
    }
    this.jdField_a_of_type_Int = 0;
    this.jdField_a_of_type_Boolean = false;
  }
  
  public void delete(int paramInt)
  {
    paramInt = a(this.jdField_a_of_type_ArrayOfInt, this.jdField_a_of_type_Int, paramInt);
    if ((paramInt >= 0) && (this.jdField_a_of_type_ArrayOfJavaLangObject[paramInt] != jdField_a_of_type_JavaLangObject))
    {
      this.jdField_a_of_type_ArrayOfJavaLangObject[paramInt] = jdField_a_of_type_JavaLangObject;
      this.jdField_a_of_type_Boolean = true;
    }
  }
  
  public Object get(int paramInt)
  {
    return get(paramInt, null);
  }
  
  public Object get(int paramInt, Object paramObject)
  {
    paramInt = a(this.jdField_a_of_type_ArrayOfInt, this.jdField_a_of_type_Int, paramInt);
    if ((paramInt < 0) || (this.jdField_a_of_type_ArrayOfJavaLangObject[paramInt] == jdField_a_of_type_JavaLangObject)) {
      return paramObject;
    }
    return this.jdField_a_of_type_ArrayOfJavaLangObject[paramInt];
  }
  
  public int indexOfKey(int paramInt)
  {
    if (this.jdField_a_of_type_Boolean) {
      a();
    }
    return a(this.jdField_a_of_type_ArrayOfInt, this.jdField_a_of_type_Int, paramInt);
  }
  
  public int indexOfValue(Object paramObject)
  {
    if (this.jdField_a_of_type_Boolean) {
      a();
    }
    int i = 0;
    while (i < this.jdField_a_of_type_Int)
    {
      if (this.jdField_a_of_type_ArrayOfJavaLangObject[i] == paramObject) {
        return i;
      }
      i += 1;
    }
    return -1;
  }
  
  public int keyAt(int paramInt)
  {
    if (this.jdField_a_of_type_Boolean) {
      a();
    }
    return this.jdField_a_of_type_ArrayOfInt[paramInt];
  }
  
  public void put(int paramInt, Object paramObject)
  {
    int i = a(this.jdField_a_of_type_ArrayOfInt, this.jdField_a_of_type_Int, paramInt);
    if (i >= 0)
    {
      this.jdField_a_of_type_ArrayOfJavaLangObject[i] = paramObject;
      return;
    }
    int j = i ^ 0xFFFFFFFF;
    if ((j < this.jdField_a_of_type_Int) && (this.jdField_a_of_type_ArrayOfJavaLangObject[j] == jdField_a_of_type_JavaLangObject))
    {
      this.jdField_a_of_type_ArrayOfInt[j] = paramInt;
      this.jdField_a_of_type_ArrayOfJavaLangObject[j] = paramObject;
      return;
    }
    i = j;
    if (this.jdField_a_of_type_Boolean)
    {
      i = j;
      if (this.jdField_a_of_type_Int >= this.jdField_a_of_type_ArrayOfInt.length)
      {
        a();
        i = a(this.jdField_a_of_type_ArrayOfInt, this.jdField_a_of_type_Int, paramInt) ^ 0xFFFFFFFF;
      }
    }
    if (this.jdField_a_of_type_Int >= this.jdField_a_of_type_ArrayOfInt.length)
    {
      j = a(this.jdField_a_of_type_Int + 1);
      int[] arrayOfInt = new int[j];
      Object[] arrayOfObject = new Object[j];
      System.arraycopy(this.jdField_a_of_type_ArrayOfInt, 0, arrayOfInt, 0, this.jdField_a_of_type_ArrayOfInt.length);
      System.arraycopy(this.jdField_a_of_type_ArrayOfJavaLangObject, 0, arrayOfObject, 0, this.jdField_a_of_type_ArrayOfJavaLangObject.length);
      this.jdField_a_of_type_ArrayOfInt = arrayOfInt;
      this.jdField_a_of_type_ArrayOfJavaLangObject = arrayOfObject;
    }
    if (this.jdField_a_of_type_Int - i != 0)
    {
      System.arraycopy(this.jdField_a_of_type_ArrayOfInt, i, this.jdField_a_of_type_ArrayOfInt, i + 1, this.jdField_a_of_type_Int - i);
      System.arraycopy(this.jdField_a_of_type_ArrayOfJavaLangObject, i, this.jdField_a_of_type_ArrayOfJavaLangObject, i + 1, this.jdField_a_of_type_Int - i);
    }
    this.jdField_a_of_type_ArrayOfInt[i] = paramInt;
    this.jdField_a_of_type_ArrayOfJavaLangObject[i] = paramObject;
    this.jdField_a_of_type_Int += 1;
  }
  
  public void remove(int paramInt)
  {
    delete(paramInt);
  }
  
  public void removeAt(int paramInt)
  {
    if (this.jdField_a_of_type_ArrayOfJavaLangObject[paramInt] != jdField_a_of_type_JavaLangObject)
    {
      this.jdField_a_of_type_ArrayOfJavaLangObject[paramInt] = jdField_a_of_type_JavaLangObject;
      this.jdField_a_of_type_Boolean = true;
    }
  }
  
  public void removeAtRange(int paramInt1, int paramInt2)
  {
    paramInt2 = Math.min(this.jdField_a_of_type_Int, paramInt1 + paramInt2);
    while (paramInt1 < paramInt2)
    {
      removeAt(paramInt1);
      paramInt1 += 1;
    }
  }
  
  public void setValueAt(int paramInt, Object paramObject)
  {
    if (this.jdField_a_of_type_Boolean) {
      a();
    }
    this.jdField_a_of_type_ArrayOfJavaLangObject[paramInt] = paramObject;
  }
  
  public int size()
  {
    if (this.jdField_a_of_type_Boolean) {
      a();
    }
    return this.jdField_a_of_type_Int;
  }
  
  public Object valueAt(int paramInt)
  {
    if (this.jdField_a_of_type_Boolean) {
      a();
    }
    return this.jdField_a_of_type_ArrayOfJavaLangObject[paramInt];
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/util/SparseArrayCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */