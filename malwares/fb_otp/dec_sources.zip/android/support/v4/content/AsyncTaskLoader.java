package android.support.v4.content;

import Y;
import android.content.Context;
import android.os.Handler;
import android.os.SystemClock;
import android.support.v4.util.TimeUtils;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.concurrent.CountDownLatch;

public abstract class AsyncTaskLoader
  extends Loader
{
  long jdField_a_of_type_Long;
  volatile Y jdField_a_of_type_Y;
  Handler jdField_a_of_type_AndroidOsHandler;
  long jdField_b_of_type_Long = -10000L;
  volatile Y jdField_b_of_type_Y;
  
  public AsyncTaskLoader(Context paramContext)
  {
    super(paramContext);
  }
  
  public final void a()
  {
    if ((this.jdField_b_of_type_Y == null) && (this.jdField_a_of_type_Y != null))
    {
      if (this.jdField_a_of_type_Y.a)
      {
        this.jdField_a_of_type_Y.a = false;
        this.jdField_a_of_type_AndroidOsHandler.removeCallbacks(this.jdField_a_of_type_Y);
      }
      if ((this.jdField_a_of_type_Long > 0L) && (SystemClock.uptimeMillis() < this.jdField_b_of_type_Long + this.jdField_a_of_type_Long))
      {
        this.jdField_a_of_type_Y.a = true;
        this.jdField_a_of_type_AndroidOsHandler.postAtTime(this.jdField_a_of_type_Y, this.jdField_b_of_type_Long + this.jdField_a_of_type_Long);
      }
    }
    else
    {
      return;
    }
    this.jdField_a_of_type_Y.a(ModernAsyncTask.a);
  }
  
  public final void a(Y paramY, Object paramObject)
  {
    onCanceled(paramObject);
    if (this.jdField_b_of_type_Y == paramY)
    {
      this.jdField_b_of_type_Long = SystemClock.uptimeMillis();
      this.jdField_b_of_type_Y = null;
      a();
    }
  }
  
  public final void b(Y paramY, Object paramObject)
  {
    if (this.jdField_a_of_type_Y != paramY)
    {
      a(paramY, paramObject);
      return;
    }
    if (isAbandoned())
    {
      onCanceled(paramObject);
      return;
    }
    this.jdField_b_of_type_Long = SystemClock.uptimeMillis();
    this.jdField_a_of_type_Y = null;
    deliverResult(paramObject);
  }
  
  public boolean cancelLoad()
  {
    if (this.jdField_a_of_type_Y != null)
    {
      if (this.jdField_b_of_type_Y != null)
      {
        if (this.jdField_a_of_type_Y.a)
        {
          this.jdField_a_of_type_Y.a = false;
          this.jdField_a_of_type_AndroidOsHandler.removeCallbacks(this.jdField_a_of_type_Y);
        }
        this.jdField_a_of_type_Y = null;
      }
    }
    else {
      return false;
    }
    if (this.jdField_a_of_type_Y.a)
    {
      this.jdField_a_of_type_Y.a = false;
      this.jdField_a_of_type_AndroidOsHandler.removeCallbacks(this.jdField_a_of_type_Y);
      this.jdField_a_of_type_Y = null;
      return false;
    }
    boolean bool = this.jdField_a_of_type_Y.a();
    if (bool) {
      this.jdField_b_of_type_Y = this.jdField_a_of_type_Y;
    }
    this.jdField_a_of_type_Y = null;
    return bool;
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    super.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    if (this.jdField_a_of_type_Y != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mTask=");
      paramPrintWriter.print(this.jdField_a_of_type_Y);
      paramPrintWriter.print(" waiting=");
      paramPrintWriter.println(this.jdField_a_of_type_Y.a);
    }
    if (this.jdField_b_of_type_Y != null)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mCancellingTask=");
      paramPrintWriter.print(this.jdField_b_of_type_Y);
      paramPrintWriter.print(" waiting=");
      paramPrintWriter.println(this.jdField_b_of_type_Y.a);
    }
    if (this.jdField_a_of_type_Long != 0L)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mUpdateThrottle=");
      TimeUtils.formatDuration(this.jdField_a_of_type_Long, paramPrintWriter);
      paramPrintWriter.print(" mLastLoadCompleteTime=");
      TimeUtils.formatDuration(this.jdField_b_of_type_Long, SystemClock.uptimeMillis(), paramPrintWriter);
      paramPrintWriter.println();
    }
  }
  
  public abstract Object loadInBackground();
  
  public void onCanceled(Object paramObject) {}
  
  protected void onForceLoad()
  {
    super.onForceLoad();
    cancelLoad();
    this.jdField_a_of_type_Y = new Y(this);
    a();
  }
  
  public Object onLoadInBackground()
  {
    return loadInBackground();
  }
  
  public void setUpdateThrottle(long paramLong)
  {
    this.jdField_a_of_type_Long = paramLong;
    if (paramLong != 0L) {
      this.jdField_a_of_type_AndroidOsHandler = new Handler();
    }
  }
  
  public void waitForLoader()
  {
    Y localY = this.jdField_a_of_type_Y;
    if (localY != null) {}
    try
    {
      Y.a(localY).await();
      return;
    }
    catch (InterruptedException localInterruptedException) {}
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/content/AsyncTaskLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */