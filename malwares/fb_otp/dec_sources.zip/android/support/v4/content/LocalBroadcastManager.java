package android.support.v4.content;

import ad;
import ae;
import af;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Handler;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public class LocalBroadcastManager
{
  private static LocalBroadcastManager jdField_a_of_type_AndroidSupportV4ContentLocalBroadcastManager;
  private static final Object jdField_a_of_type_JavaLangObject = new Object();
  private final Context jdField_a_of_type_AndroidContentContext;
  private final Handler jdField_a_of_type_AndroidOsHandler;
  private final ArrayList jdField_a_of_type_JavaUtilArrayList = new ArrayList();
  private final HashMap jdField_a_of_type_JavaUtilHashMap = new HashMap();
  private final HashMap b = new HashMap();
  
  private LocalBroadcastManager(Context paramContext)
  {
    this.jdField_a_of_type_AndroidContentContext = paramContext;
    this.jdField_a_of_type_AndroidOsHandler = new ad(this, paramContext.getMainLooper());
  }
  
  private void a()
  {
    for (;;)
    {
      int i;
      synchronized (this.jdField_a_of_type_JavaUtilHashMap)
      {
        i = this.jdField_a_of_type_JavaUtilArrayList.size();
        if (i <= 0) {
          return;
        }
        ae[] arrayOfae = new ae[i];
        this.jdField_a_of_type_JavaUtilArrayList.toArray(arrayOfae);
        this.jdField_a_of_type_JavaUtilArrayList.clear();
        i = 0;
        if (i >= arrayOfae.length) {
          continue;
        }
        ??? = arrayOfae[i];
        int j = 0;
        if (j < ???.jdField_a_of_type_JavaUtilArrayList.size())
        {
          ((af)???.jdField_a_of_type_JavaUtilArrayList.get(j)).jdField_a_of_type_AndroidContentBroadcastReceiver.onReceive(this.jdField_a_of_type_AndroidContentContext, ???.jdField_a_of_type_AndroidContentIntent);
          j += 1;
        }
      }
      i += 1;
    }
  }
  
  public static LocalBroadcastManager getInstance(Context paramContext)
  {
    synchronized (jdField_a_of_type_JavaLangObject)
    {
      if (jdField_a_of_type_AndroidSupportV4ContentLocalBroadcastManager == null) {
        jdField_a_of_type_AndroidSupportV4ContentLocalBroadcastManager = new LocalBroadcastManager(paramContext.getApplicationContext());
      }
      paramContext = jdField_a_of_type_AndroidSupportV4ContentLocalBroadcastManager;
      return paramContext;
    }
  }
  
  public void registerReceiver(BroadcastReceiver paramBroadcastReceiver, IntentFilter paramIntentFilter)
  {
    synchronized (this.jdField_a_of_type_JavaUtilHashMap)
    {
      af localaf = new af(paramIntentFilter, paramBroadcastReceiver);
      Object localObject2 = (ArrayList)this.jdField_a_of_type_JavaUtilHashMap.get(paramBroadcastReceiver);
      Object localObject1 = localObject2;
      if (localObject2 == null)
      {
        localObject1 = new ArrayList(1);
        this.jdField_a_of_type_JavaUtilHashMap.put(paramBroadcastReceiver, localObject1);
      }
      ((ArrayList)localObject1).add(paramIntentFilter);
      int i = 0;
      while (i < paramIntentFilter.countActions())
      {
        localObject2 = paramIntentFilter.getAction(i);
        localObject1 = (ArrayList)this.b.get(localObject2);
        paramBroadcastReceiver = (BroadcastReceiver)localObject1;
        if (localObject1 == null)
        {
          paramBroadcastReceiver = new ArrayList(1);
          this.b.put(localObject2, paramBroadcastReceiver);
        }
        paramBroadcastReceiver.add(localaf);
        i += 1;
      }
      return;
    }
  }
  
  public boolean sendBroadcast(Intent paramIntent)
  {
    int i;
    label145:
    int j;
    Object localObject;
    int k;
    ArrayList localArrayList1;
    synchronized (this.jdField_a_of_type_JavaUtilHashMap)
    {
      String str1 = paramIntent.getAction();
      String str2 = paramIntent.resolveTypeIfNeeded(this.jdField_a_of_type_AndroidContentContext.getContentResolver());
      Uri localUri = paramIntent.getData();
      String str3 = paramIntent.getScheme();
      Set localSet = paramIntent.getCategories();
      if ((paramIntent.getFlags() & 0x8) == 0) {
        break label452;
      }
      i = 1;
      if (i != 0) {
        new StringBuilder("Resolving type ").append(str2).append(" scheme ").append(str3).append(" of intent ").append(paramIntent).toString();
      }
      ArrayList localArrayList2 = (ArrayList)this.b.get(paramIntent.getAction());
      if (localArrayList2 == null) {
        break label429;
      }
      if (i == 0) {
        break label437;
      }
      new StringBuilder("Action list: ").append(localArrayList2).toString();
      break label437;
      if (j >= localArrayList2.size()) {
        break label488;
      }
      localObject = (af)localArrayList2.get(j);
      if (i != 0) {
        new StringBuilder("Matching against filter ").append(((af)localObject).jdField_a_of_type_AndroidContentIntentFilter).toString();
      }
      if (((af)localObject).jdField_a_of_type_Boolean)
      {
        if (i == 0) {
          break label457;
        }
      }
      else
      {
        k = ((af)localObject).jdField_a_of_type_AndroidContentIntentFilter.match(str1, str2, str3, localUri, localSet, "LocalBroadcastManager");
        if (k >= 0)
        {
          if (i != 0) {
            new StringBuilder("  Filter matched!  match=0x").append(Integer.toHexString(k)).toString();
          }
          if (localArrayList1 != null) {
            break label434;
          }
          localArrayList1 = new ArrayList();
          label271:
          localArrayList1.add(localObject);
          ((af)localObject).jdField_a_of_type_Boolean = true;
        }
      }
    }
    if (i != 0) {
      switch (k)
      {
      default: 
        localObject = "unknown reason";
        label336:
        new StringBuilder("  Filter did not match: ").append((String)localObject).toString();
        break;
      }
    }
    for (;;)
    {
      if (i < localArrayList1.size())
      {
        ((af)localArrayList1.get(i)).jdField_a_of_type_Boolean = false;
        i += 1;
      }
      else
      {
        this.jdField_a_of_type_JavaUtilArrayList.add(new ae(paramIntent, localArrayList1));
        if (!this.jdField_a_of_type_AndroidOsHandler.hasMessages(1)) {
          this.jdField_a_of_type_AndroidOsHandler.sendEmptyMessage(1);
        }
        return true;
        label429:
        label434:
        label437:
        label452:
        label457:
        label488:
        do
        {
          return false;
          break label271;
          localArrayList1 = null;
          j = 0;
          break label145;
          for (;;)
          {
            j += 1;
            break label145;
            i = 0;
            break;
          }
          localObject = "action";
          break label336;
          localObject = "category";
          break label336;
          localObject = "data";
          break label336;
          localObject = "type";
          break label336;
        } while (localArrayList1 == null);
        i = 0;
      }
    }
  }
  
  public void sendBroadcastSync(Intent paramIntent)
  {
    if (sendBroadcast(paramIntent)) {
      a();
    }
  }
  
  public void unregisterReceiver(BroadcastReceiver paramBroadcastReceiver)
  {
    for (;;)
    {
      int k;
      int i;
      synchronized (this.jdField_a_of_type_JavaUtilHashMap)
      {
        ArrayList localArrayList1 = (ArrayList)this.jdField_a_of_type_JavaUtilHashMap.remove(paramBroadcastReceiver);
        if (localArrayList1 != null) {
          break label167;
        }
        return;
        if (j < localArrayList1.size())
        {
          IntentFilter localIntentFilter = (IntentFilter)localArrayList1.get(j);
          k = 0;
          if (k >= localIntentFilter.countActions()) {
            break label188;
          }
          String str = localIntentFilter.getAction(k);
          ArrayList localArrayList2 = (ArrayList)this.b.get(str);
          if (localArrayList2 == null) {
            break label179;
          }
          i = 0;
          if (i < localArrayList2.size())
          {
            if (((af)localArrayList2.get(i)).jdField_a_of_type_AndroidContentBroadcastReceiver == paramBroadcastReceiver)
            {
              localArrayList2.remove(i);
              i -= 1;
              break label172;
            }
          }
          else
          {
            if (localArrayList2.size() > 0) {
              break label179;
            }
            this.b.remove(str);
            break label179;
          }
        }
        else
        {
          return;
        }
      }
      break label172;
      label167:
      int j = 0;
      continue;
      label172:
      i += 1;
      continue;
      label179:
      k += 1;
      continue;
      label188:
      j += 1;
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/content/LocalBroadcastManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */