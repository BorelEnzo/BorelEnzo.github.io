package android.support.v4.content;

import android.content.Context;
import android.support.v4.util.DebugUtils;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class Loader
{
  int jdField_a_of_type_Int;
  Context jdField_a_of_type_AndroidContentContext;
  Loader.OnLoadCompleteListener jdField_a_of_type_AndroidSupportV4ContentLoader$OnLoadCompleteListener;
  boolean jdField_a_of_type_Boolean = false;
  boolean b = false;
  boolean c = true;
  boolean d = false;
  
  public Loader(Context paramContext)
  {
    this.jdField_a_of_type_AndroidContentContext = paramContext.getApplicationContext();
  }
  
  public void abandon()
  {
    this.b = true;
    onAbandon();
  }
  
  public String dataToString(Object paramObject)
  {
    StringBuilder localStringBuilder = new StringBuilder(64);
    DebugUtils.buildShortClassTag(paramObject, localStringBuilder);
    localStringBuilder.append("}");
    return localStringBuilder.toString();
  }
  
  public void deliverResult(Object paramObject)
  {
    if (this.jdField_a_of_type_AndroidSupportV4ContentLoader$OnLoadCompleteListener != null) {
      this.jdField_a_of_type_AndroidSupportV4ContentLoader$OnLoadCompleteListener.onLoadComplete(this, paramObject);
    }
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mId=");
    paramPrintWriter.print(this.jdField_a_of_type_Int);
    paramPrintWriter.print(" mListener=");
    paramPrintWriter.println(this.jdField_a_of_type_AndroidSupportV4ContentLoader$OnLoadCompleteListener);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mStarted=");
    paramPrintWriter.print(this.jdField_a_of_type_Boolean);
    paramPrintWriter.print(" mContentChanged=");
    paramPrintWriter.print(this.d);
    paramPrintWriter.print(" mAbandoned=");
    paramPrintWriter.print(this.b);
    paramPrintWriter.print(" mReset=");
    paramPrintWriter.println(this.c);
  }
  
  public void forceLoad()
  {
    onForceLoad();
  }
  
  public Context getContext()
  {
    return this.jdField_a_of_type_AndroidContentContext;
  }
  
  public int getId()
  {
    return this.jdField_a_of_type_Int;
  }
  
  public boolean isAbandoned()
  {
    return this.b;
  }
  
  public boolean isReset()
  {
    return this.c;
  }
  
  public boolean isStarted()
  {
    return this.jdField_a_of_type_Boolean;
  }
  
  protected void onAbandon() {}
  
  public void onContentChanged()
  {
    if (this.jdField_a_of_type_Boolean)
    {
      forceLoad();
      return;
    }
    this.d = true;
  }
  
  protected void onForceLoad() {}
  
  protected void onReset() {}
  
  protected void onStartLoading() {}
  
  protected void onStopLoading() {}
  
  public void registerListener(int paramInt, Loader.OnLoadCompleteListener paramOnLoadCompleteListener)
  {
    if (this.jdField_a_of_type_AndroidSupportV4ContentLoader$OnLoadCompleteListener != null) {
      throw new IllegalStateException("There is already a listener registered");
    }
    this.jdField_a_of_type_AndroidSupportV4ContentLoader$OnLoadCompleteListener = paramOnLoadCompleteListener;
    this.jdField_a_of_type_Int = paramInt;
  }
  
  public void reset()
  {
    onReset();
    this.c = true;
    this.jdField_a_of_type_Boolean = false;
    this.b = false;
    this.d = false;
  }
  
  public final void startLoading()
  {
    this.jdField_a_of_type_Boolean = true;
    this.c = false;
    this.b = false;
    onStartLoading();
  }
  
  public void stopLoading()
  {
    this.jdField_a_of_type_Boolean = false;
    onStopLoading();
  }
  
  public boolean takeContentChanged()
  {
    boolean bool = this.d;
    this.d = false;
    return bool;
  }
  
  public String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(64);
    DebugUtils.buildShortClassTag(this, localStringBuilder);
    localStringBuilder.append(" id=");
    localStringBuilder.append(this.jdField_a_of_type_Int);
    localStringBuilder.append("}");
    return localStringBuilder.toString();
  }
  
  public void unregisterListener(Loader.OnLoadCompleteListener paramOnLoadCompleteListener)
  {
    if (this.jdField_a_of_type_AndroidSupportV4ContentLoader$OnLoadCompleteListener == null) {
      throw new IllegalStateException("No listener register");
    }
    if (this.jdField_a_of_type_AndroidSupportV4ContentLoader$OnLoadCompleteListener != paramOnLoadCompleteListener) {
      throw new IllegalArgumentException("Attempting to unregister the wrong listener");
    }
    this.jdField_a_of_type_AndroidSupportV4ContentLoader$OnLoadCompleteListener = null;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/content/Loader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */