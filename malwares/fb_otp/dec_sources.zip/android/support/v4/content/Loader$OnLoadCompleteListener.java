package android.support.v4.content;

public abstract interface Loader$OnLoadCompleteListener
{
  public abstract void onLoadComplete(Loader paramLoader, Object paramObject);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/content/Loader$OnLoadCompleteListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */