package android.support.v4.content;

import ag;
import ah;
import ai;
import ak;
import al;
import am;
import android.os.Message;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executor;
import java.util.concurrent.FutureTask;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class ModernAsyncTask
{
  private static final al jdField_a_of_type_Al = new al((byte)0);
  private static final BlockingQueue jdField_a_of_type_JavaUtilConcurrentBlockingQueue;
  public static final Executor a;
  private static final ThreadFactory jdField_a_of_type_JavaUtilConcurrentThreadFactory = new ag();
  private static volatile Executor b = jdField_a_of_type_JavaUtilConcurrentExecutor;
  private final am jdField_a_of_type_Am = new ah(this);
  private volatile ModernAsyncTask.Status jdField_a_of_type_AndroidSupportV4ContentModernAsyncTask$Status = ModernAsyncTask.Status.PENDING;
  private final FutureTask jdField_a_of_type_JavaUtilConcurrentFutureTask = new ai(this, this.jdField_a_of_type_Am);
  private final AtomicBoolean jdField_a_of_type_JavaUtilConcurrentAtomicAtomicBoolean = new AtomicBoolean();
  
  static
  {
    jdField_a_of_type_JavaUtilConcurrentBlockingQueue = new LinkedBlockingQueue(10);
    jdField_a_of_type_JavaUtilConcurrentExecutor = new ThreadPoolExecutor(5, 128, 1L, TimeUnit.SECONDS, jdField_a_of_type_JavaUtilConcurrentBlockingQueue, jdField_a_of_type_JavaUtilConcurrentThreadFactory);
  }
  
  private Object a(Object paramObject)
  {
    jdField_a_of_type_Al.obtainMessage(1, new ak(this, new Object[] { paramObject })).sendToTarget();
    return paramObject;
  }
  
  public static void b() {}
  
  public final ModernAsyncTask a(Executor paramVarArgs)
  {
    if (this.jdField_a_of_type_AndroidSupportV4ContentModernAsyncTask$Status != ModernAsyncTask.Status.PENDING) {}
    switch (aj.a[this.jdField_a_of_type_AndroidSupportV4ContentModernAsyncTask$Status.ordinal()])
    {
    default: 
      this.jdField_a_of_type_AndroidSupportV4ContentModernAsyncTask$Status = ModernAsyncTask.Status.RUNNING;
      this.jdField_a_of_type_Am.a = null;
      paramVarArgs.execute(this.jdField_a_of_type_JavaUtilConcurrentFutureTask);
      return this;
    case 1: 
      throw new IllegalStateException("Cannot execute task: the task is already running.");
    }
    throw new IllegalStateException("Cannot execute task: the task has already been executed (a task can be executed only once)");
  }
  
  public abstract Object a();
  
  protected void a() {}
  
  protected void a(Object paramObject) {}
  
  public final boolean a()
  {
    return this.jdField_a_of_type_JavaUtilConcurrentFutureTask.cancel(false);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/content/ModernAsyncTask.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */