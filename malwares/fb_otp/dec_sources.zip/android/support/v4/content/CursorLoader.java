package android.support.v4.content;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Arrays;

public class CursorLoader
  extends AsyncTaskLoader
{
  Cursor jdField_a_of_type_AndroidDatabaseCursor;
  Uri jdField_a_of_type_AndroidNetUri;
  final Loader.ForceLoadContentObserver jdField_a_of_type_AndroidSupportV4ContentLoader$ForceLoadContentObserver = new Loader.ForceLoadContentObserver(this);
  String jdField_a_of_type_JavaLangString;
  String[] jdField_a_of_type_ArrayOfJavaLangString;
  String jdField_b_of_type_JavaLangString;
  String[] jdField_b_of_type_ArrayOfJavaLangString;
  
  public CursorLoader(Context paramContext)
  {
    super(paramContext);
  }
  
  public CursorLoader(Context paramContext, Uri paramUri, String[] paramArrayOfString1, String paramString1, String[] paramArrayOfString2, String paramString2)
  {
    super(paramContext);
    this.jdField_a_of_type_AndroidNetUri = paramUri;
    this.jdField_a_of_type_ArrayOfJavaLangString = paramArrayOfString1;
    this.jdField_a_of_type_JavaLangString = paramString1;
    this.jdField_b_of_type_ArrayOfJavaLangString = paramArrayOfString2;
    this.jdField_b_of_type_JavaLangString = paramString2;
  }
  
  public void deliverResult(Cursor paramCursor)
  {
    if (isReset()) {
      if (paramCursor != null) {
        paramCursor.close();
      }
    }
    Cursor localCursor;
    do
    {
      return;
      localCursor = this.jdField_a_of_type_AndroidDatabaseCursor;
      this.jdField_a_of_type_AndroidDatabaseCursor = paramCursor;
      if (isStarted()) {
        super.deliverResult(paramCursor);
      }
    } while ((localCursor == null) || (localCursor == paramCursor) || (localCursor.isClosed()));
    localCursor.close();
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    super.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mUri=");
    paramPrintWriter.println(this.jdField_a_of_type_AndroidNetUri);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mProjection=");
    paramPrintWriter.println(Arrays.toString(this.jdField_a_of_type_ArrayOfJavaLangString));
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mSelection=");
    paramPrintWriter.println(this.jdField_a_of_type_JavaLangString);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mSelectionArgs=");
    paramPrintWriter.println(Arrays.toString(this.jdField_b_of_type_ArrayOfJavaLangString));
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mSortOrder=");
    paramPrintWriter.println(this.jdField_b_of_type_JavaLangString);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mCursor=");
    paramPrintWriter.println(this.jdField_a_of_type_AndroidDatabaseCursor);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mContentChanged=");
    paramPrintWriter.println(this.d);
  }
  
  public String[] getProjection()
  {
    return this.jdField_a_of_type_ArrayOfJavaLangString;
  }
  
  public String getSelection()
  {
    return this.jdField_a_of_type_JavaLangString;
  }
  
  public String[] getSelectionArgs()
  {
    return this.jdField_b_of_type_ArrayOfJavaLangString;
  }
  
  public String getSortOrder()
  {
    return this.jdField_b_of_type_JavaLangString;
  }
  
  public Uri getUri()
  {
    return this.jdField_a_of_type_AndroidNetUri;
  }
  
  public Cursor loadInBackground()
  {
    Cursor localCursor = getContext().getContentResolver().query(this.jdField_a_of_type_AndroidNetUri, this.jdField_a_of_type_ArrayOfJavaLangString, this.jdField_a_of_type_JavaLangString, this.jdField_b_of_type_ArrayOfJavaLangString, this.jdField_b_of_type_JavaLangString);
    if (localCursor != null)
    {
      localCursor.getCount();
      Loader.ForceLoadContentObserver localForceLoadContentObserver = this.jdField_a_of_type_AndroidSupportV4ContentLoader$ForceLoadContentObserver;
      localCursor.registerContentObserver(this.jdField_a_of_type_AndroidSupportV4ContentLoader$ForceLoadContentObserver);
    }
    return localCursor;
  }
  
  public void onCanceled(Cursor paramCursor)
  {
    if ((paramCursor != null) && (!paramCursor.isClosed())) {
      paramCursor.close();
    }
  }
  
  protected void onReset()
  {
    super.onReset();
    onStopLoading();
    if ((this.jdField_a_of_type_AndroidDatabaseCursor != null) && (!this.jdField_a_of_type_AndroidDatabaseCursor.isClosed())) {
      this.jdField_a_of_type_AndroidDatabaseCursor.close();
    }
    this.jdField_a_of_type_AndroidDatabaseCursor = null;
  }
  
  protected void onStartLoading()
  {
    if (this.jdField_a_of_type_AndroidDatabaseCursor != null) {
      deliverResult(this.jdField_a_of_type_AndroidDatabaseCursor);
    }
    if ((takeContentChanged()) || (this.jdField_a_of_type_AndroidDatabaseCursor == null)) {
      forceLoad();
    }
  }
  
  protected void onStopLoading()
  {
    cancelLoad();
  }
  
  public void setProjection(String[] paramArrayOfString)
  {
    this.jdField_a_of_type_ArrayOfJavaLangString = paramArrayOfString;
  }
  
  public void setSelection(String paramString)
  {
    this.jdField_a_of_type_JavaLangString = paramString;
  }
  
  public void setSelectionArgs(String[] paramArrayOfString)
  {
    this.jdField_b_of_type_ArrayOfJavaLangString = paramArrayOfString;
  }
  
  public void setSortOrder(String paramString)
  {
    this.jdField_b_of_type_JavaLangString = paramString;
  }
  
  public void setUri(Uri paramUri)
  {
    this.jdField_a_of_type_AndroidNetUri = paramUri;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/content/CursorLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */