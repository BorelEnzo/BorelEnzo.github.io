package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.VelocityTracker;
import bf;
import bg;
import bh;

public class VelocityTrackerCompat
{
  static final bh a = new bf();
  
  static
  {
    if (Build.VERSION.SDK_INT >= 11)
    {
      a = new bg();
      return;
    }
  }
  
  public static float getXVelocity(VelocityTracker paramVelocityTracker, int paramInt)
  {
    return a.a(paramVelocityTracker, paramInt);
  }
  
  public static float getYVelocity(VelocityTracker paramVelocityTracker, int paramInt)
  {
    return a.b(paramVelocityTracker, paramInt);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/view/VelocityTrackerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */