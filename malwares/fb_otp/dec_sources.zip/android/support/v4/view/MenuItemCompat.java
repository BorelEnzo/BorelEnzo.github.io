package android.support.v4.view;

import aR;
import aS;
import aT;
import android.os.Build.VERSION;
import android.view.MenuItem;
import android.view.View;

public class MenuItemCompat
{
  public static final int SHOW_AS_ACTION_ALWAYS = 2;
  public static final int SHOW_AS_ACTION_COLLAPSE_ACTION_VIEW = 8;
  public static final int SHOW_AS_ACTION_IF_ROOM = 1;
  public static final int SHOW_AS_ACTION_NEVER = 0;
  public static final int SHOW_AS_ACTION_WITH_TEXT = 4;
  static final aT a = new aR();
  
  static
  {
    if (Build.VERSION.SDK_INT >= 11)
    {
      a = new aS();
      return;
    }
  }
  
  public static MenuItem setActionView(MenuItem paramMenuItem, View paramView)
  {
    return a.a(paramMenuItem, paramView);
  }
  
  public static boolean setShowAsAction(MenuItem paramMenuItem, int paramInt)
  {
    return a.a(paramMenuItem, paramInt);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/view/MenuItemCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */