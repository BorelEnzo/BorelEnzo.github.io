package android.support.v4.view;

import android.view.View;

public abstract interface ViewPager$PageTransformer
{
  public abstract void transformPage(View paramView, float paramFloat);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/view/ViewPager$PageTransformer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */