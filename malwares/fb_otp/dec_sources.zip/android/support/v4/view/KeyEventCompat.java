package android.support.v4.view;

import aL;
import aM;
import aN;
import android.os.Build.VERSION;
import android.view.KeyEvent;

public class KeyEventCompat
{
  static final aN a = new aL();
  
  static
  {
    if (Build.VERSION.SDK_INT >= 11)
    {
      a = new aM();
      return;
    }
  }
  
  public static boolean hasModifiers(KeyEvent paramKeyEvent, int paramInt)
  {
    return a.a(paramKeyEvent.getMetaState(), paramInt);
  }
  
  public static boolean hasNoModifiers(KeyEvent paramKeyEvent)
  {
    return a.a(paramKeyEvent.getMetaState());
  }
  
  public static boolean metaStateHasModifiers(int paramInt1, int paramInt2)
  {
    return a.a(paramInt1, paramInt2);
  }
  
  public static boolean metaStateHasNoModifiers(int paramInt)
  {
    return a.a(paramInt);
  }
  
  public static int normalizeMetaState(int paramInt)
  {
    return a.a(paramInt);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/view/KeyEventCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */