package android.support.v4.view;

import aX;
import aY;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.widget.TextView;

public class PagerTabStrip
  extends PagerTitleStrip
{
  private float jdField_a_of_type_Float;
  private final Paint jdField_a_of_type_AndroidGraphicsPaint = new Paint();
  private final Rect jdField_a_of_type_AndroidGraphicsRect = new Rect();
  private boolean jdField_a_of_type_Boolean = false;
  private float jdField_b_of_type_Float;
  private int jdField_b_of_type_Int = this.jdField_a_of_type_Int;
  private boolean jdField_b_of_type_Boolean = false;
  private int jdField_c_of_type_Int;
  private boolean jdField_c_of_type_Boolean;
  private int d;
  private int e;
  private int f;
  private int g;
  private int h = 255;
  private int i;
  private int j;
  
  public PagerTabStrip(Context paramContext)
  {
    this(paramContext, null);
  }
  
  public PagerTabStrip(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    this.jdField_a_of_type_AndroidGraphicsPaint.setColor(this.jdField_b_of_type_Int);
    float f1 = paramContext.getResources().getDisplayMetrics().density;
    this.jdField_c_of_type_Int = ((int)(3.0F * f1 + 0.5F));
    this.d = ((int)(6.0F * f1 + 0.5F));
    this.e = ((int)(64.0F * f1));
    this.g = ((int)(16.0F * f1 + 0.5F));
    this.i = ((int)(1.0F * f1 + 0.5F));
    this.f = ((int)(f1 * 32.0F + 0.5F));
    this.j = ViewConfiguration.get(paramContext).getScaledTouchSlop();
    setPadding(getPaddingLeft(), getPaddingTop(), getPaddingRight(), getPaddingBottom());
    setTextSpacing(getTextSpacing());
    setWillNotDraw(false);
    this.jdField_a_of_type_AndroidWidgetTextView.setFocusable(true);
    this.jdField_a_of_type_AndroidWidgetTextView.setOnClickListener(new aX(this));
    this.jdField_c_of_type_AndroidWidgetTextView.setFocusable(true);
    this.jdField_c_of_type_AndroidWidgetTextView.setOnClickListener(new aY(this));
    if (getBackground() == null) {
      this.jdField_a_of_type_Boolean = true;
    }
  }
  
  final int a()
  {
    return Math.max(super.a(), this.f);
  }
  
  final void a(int paramInt, float paramFloat, boolean paramBoolean)
  {
    Rect localRect = this.jdField_a_of_type_AndroidGraphicsRect;
    int k = getHeight();
    int m = this.jdField_b_of_type_AndroidWidgetTextView.getLeft();
    int n = this.g;
    int i1 = this.jdField_b_of_type_AndroidWidgetTextView.getRight();
    int i2 = this.g;
    int i3 = k - this.jdField_c_of_type_Int;
    localRect.set(m - n, i3, i1 + i2, k);
    super.a(paramInt, paramFloat, paramBoolean);
    this.h = ((int)(Math.abs(paramFloat - 0.5F) * 2.0F * 255.0F));
    localRect.union(this.jdField_b_of_type_AndroidWidgetTextView.getLeft() - this.g, i3, this.jdField_b_of_type_AndroidWidgetTextView.getRight() + this.g, k);
    invalidate(localRect);
  }
  
  public boolean getDrawFullUnderline()
  {
    return this.jdField_a_of_type_Boolean;
  }
  
  public int getTabIndicatorColor()
  {
    return this.jdField_b_of_type_Int;
  }
  
  protected void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
    int k = getHeight();
    int m = this.jdField_b_of_type_AndroidWidgetTextView.getLeft();
    int n = this.g;
    int i1 = this.jdField_b_of_type_AndroidWidgetTextView.getRight();
    int i2 = this.g;
    int i3 = this.jdField_c_of_type_Int;
    this.jdField_a_of_type_AndroidGraphicsPaint.setColor(this.h << 24 | this.jdField_b_of_type_Int & 0xFFFFFF);
    paramCanvas.drawRect(m - n, k - i3, i1 + i2, k, this.jdField_a_of_type_AndroidGraphicsPaint);
    if (this.jdField_a_of_type_Boolean)
    {
      this.jdField_a_of_type_AndroidGraphicsPaint.setColor(0xFF000000 | this.jdField_b_of_type_Int & 0xFFFFFF);
      paramCanvas.drawRect(getPaddingLeft(), k - this.i, getWidth() - getPaddingRight(), k, this.jdField_a_of_type_AndroidGraphicsPaint);
    }
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    int k = paramMotionEvent.getAction();
    if ((k != 0) && (this.jdField_c_of_type_Boolean)) {
      return false;
    }
    float f1 = paramMotionEvent.getX();
    float f2 = paramMotionEvent.getY();
    switch (k)
    {
    }
    for (;;)
    {
      return true;
      this.jdField_a_of_type_Float = f1;
      this.jdField_b_of_type_Float = f2;
      this.jdField_c_of_type_Boolean = false;
      continue;
      if ((Math.abs(f1 - this.jdField_a_of_type_Float) > this.j) || (Math.abs(f2 - this.jdField_b_of_type_Float) > this.j))
      {
        this.jdField_c_of_type_Boolean = true;
        continue;
        if (f1 < this.jdField_b_of_type_AndroidWidgetTextView.getLeft() - this.g) {
          this.jdField_a_of_type_AndroidSupportV4ViewViewPager.setCurrentItem(this.jdField_a_of_type_AndroidSupportV4ViewViewPager.getCurrentItem() - 1);
        } else if (f1 > this.jdField_b_of_type_AndroidWidgetTextView.getRight() + this.g) {
          this.jdField_a_of_type_AndroidSupportV4ViewViewPager.setCurrentItem(this.jdField_a_of_type_AndroidSupportV4ViewViewPager.getCurrentItem() + 1);
        }
      }
    }
  }
  
  public void setBackgroundColor(int paramInt)
  {
    super.setBackgroundColor(paramInt);
    if (!this.jdField_b_of_type_Boolean) {
      if ((0xFF000000 & paramInt) != 0) {
        break label27;
      }
    }
    label27:
    for (boolean bool = true;; bool = false)
    {
      this.jdField_a_of_type_Boolean = bool;
      return;
    }
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable)
  {
    super.setBackgroundDrawable(paramDrawable);
    if (!this.jdField_b_of_type_Boolean) {
      if (paramDrawable != null) {
        break label24;
      }
    }
    label24:
    for (boolean bool = true;; bool = false)
    {
      this.jdField_a_of_type_Boolean = bool;
      return;
    }
  }
  
  public void setBackgroundResource(int paramInt)
  {
    super.setBackgroundResource(paramInt);
    if (!this.jdField_b_of_type_Boolean) {
      if (paramInt != 0) {
        break label24;
      }
    }
    label24:
    for (boolean bool = true;; bool = false)
    {
      this.jdField_a_of_type_Boolean = bool;
      return;
    }
  }
  
  public void setDrawFullUnderline(boolean paramBoolean)
  {
    this.jdField_a_of_type_Boolean = paramBoolean;
    this.jdField_b_of_type_Boolean = true;
    invalidate();
  }
  
  public void setPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    int k = paramInt4;
    if (paramInt4 < this.d) {
      k = this.d;
    }
    super.setPadding(paramInt1, paramInt2, paramInt3, k);
  }
  
  public void setTabIndicatorColor(int paramInt)
  {
    this.jdField_b_of_type_Int = paramInt;
    this.jdField_a_of_type_AndroidGraphicsPaint.setColor(this.jdField_b_of_type_Int);
    invalidate();
  }
  
  public void setTabIndicatorColorResource(int paramInt)
  {
    setTabIndicatorColor(getContext().getResources().getColor(paramInt));
  }
  
  public void setTextSpacing(int paramInt)
  {
    int k = paramInt;
    if (paramInt < this.e) {
      k = this.e;
    }
    super.setTextSpacing(k);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/view/PagerTabStrip.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */