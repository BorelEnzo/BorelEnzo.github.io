package android.support.v4.view.accessibility;

import android.os.Build.VERSION;
import android.os.Bundle;
import bT;
import bU;
import bW;
import java.util.List;

public class AccessibilityNodeProviderCompat
{
  private static final bT jdField_a_of_type_BT = new bW();
  private final Object jdField_a_of_type_JavaLangObject;
  
  static
  {
    if (Build.VERSION.SDK_INT >= 16)
    {
      jdField_a_of_type_BT = new bU();
      return;
    }
  }
  
  public AccessibilityNodeProviderCompat()
  {
    this.jdField_a_of_type_JavaLangObject = jdField_a_of_type_BT.a(this);
  }
  
  public AccessibilityNodeProviderCompat(Object paramObject)
  {
    this.jdField_a_of_type_JavaLangObject = paramObject;
  }
  
  public AccessibilityNodeInfoCompat createAccessibilityNodeInfo(int paramInt)
  {
    return null;
  }
  
  public List findAccessibilityNodeInfosByText(String paramString, int paramInt)
  {
    return null;
  }
  
  public Object getProvider()
  {
    return this.jdField_a_of_type_JavaLangObject;
  }
  
  public boolean performAction(int paramInt1, int paramInt2, Bundle paramBundle)
  {
    return false;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/view/accessibility/AccessibilityNodeProviderCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */