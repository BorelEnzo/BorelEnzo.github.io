package android.support.v4.view.accessibility;

import android.os.Build.VERSION;
import android.os.Parcelable;
import android.view.View;
import ca;
import cb;
import cc;
import cd;
import ce;
import java.util.List;

public class AccessibilityRecordCompat
{
  private static final cc jdField_a_of_type_Cc = new ce();
  private final Object jdField_a_of_type_JavaLangObject;
  
  static
  {
    if (Build.VERSION.SDK_INT >= 16)
    {
      jdField_a_of_type_Cc = new cd();
      return;
    }
    if (Build.VERSION.SDK_INT >= 15)
    {
      jdField_a_of_type_Cc = new cb();
      return;
    }
    if (Build.VERSION.SDK_INT >= 14)
    {
      jdField_a_of_type_Cc = new ca();
      return;
    }
  }
  
  public AccessibilityRecordCompat(Object paramObject)
  {
    this.jdField_a_of_type_JavaLangObject = paramObject;
  }
  
  public static AccessibilityRecordCompat obtain()
  {
    return new AccessibilityRecordCompat(jdField_a_of_type_Cc.a());
  }
  
  public static AccessibilityRecordCompat obtain(AccessibilityRecordCompat paramAccessibilityRecordCompat)
  {
    return new AccessibilityRecordCompat(jdField_a_of_type_Cc.a(paramAccessibilityRecordCompat.jdField_a_of_type_JavaLangObject));
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {}
    do
    {
      do
      {
        return true;
        if (paramObject == null) {
          return false;
        }
        if (getClass() != paramObject.getClass()) {
          return false;
        }
        paramObject = (AccessibilityRecordCompat)paramObject;
        if (this.jdField_a_of_type_JavaLangObject != null) {
          break;
        }
      } while (((AccessibilityRecordCompat)paramObject).jdField_a_of_type_JavaLangObject == null);
      return false;
    } while (this.jdField_a_of_type_JavaLangObject.equals(((AccessibilityRecordCompat)paramObject).jdField_a_of_type_JavaLangObject));
    return false;
  }
  
  public int getAddedCount()
  {
    return jdField_a_of_type_Cc.a(this.jdField_a_of_type_JavaLangObject);
  }
  
  public CharSequence getBeforeText()
  {
    return jdField_a_of_type_Cc.a(this.jdField_a_of_type_JavaLangObject);
  }
  
  public CharSequence getClassName()
  {
    return jdField_a_of_type_Cc.b(this.jdField_a_of_type_JavaLangObject);
  }
  
  public CharSequence getContentDescription()
  {
    return jdField_a_of_type_Cc.c(this.jdField_a_of_type_JavaLangObject);
  }
  
  public int getCurrentItemIndex()
  {
    return jdField_a_of_type_Cc.b(this.jdField_a_of_type_JavaLangObject);
  }
  
  public int getFromIndex()
  {
    return jdField_a_of_type_Cc.c(this.jdField_a_of_type_JavaLangObject);
  }
  
  public Object getImpl()
  {
    return this.jdField_a_of_type_JavaLangObject;
  }
  
  public int getItemCount()
  {
    return jdField_a_of_type_Cc.d(this.jdField_a_of_type_JavaLangObject);
  }
  
  public int getMaxScrollX()
  {
    return jdField_a_of_type_Cc.j(this.jdField_a_of_type_JavaLangObject);
  }
  
  public int getMaxScrollY()
  {
    return jdField_a_of_type_Cc.k(this.jdField_a_of_type_JavaLangObject);
  }
  
  public Parcelable getParcelableData()
  {
    return jdField_a_of_type_Cc.a(this.jdField_a_of_type_JavaLangObject);
  }
  
  public int getRemovedCount()
  {
    return jdField_a_of_type_Cc.e(this.jdField_a_of_type_JavaLangObject);
  }
  
  public int getScrollX()
  {
    return jdField_a_of_type_Cc.f(this.jdField_a_of_type_JavaLangObject);
  }
  
  public int getScrollY()
  {
    return jdField_a_of_type_Cc.g(this.jdField_a_of_type_JavaLangObject);
  }
  
  public AccessibilityNodeInfoCompat getSource()
  {
    return jdField_a_of_type_Cc.a(this.jdField_a_of_type_JavaLangObject);
  }
  
  public List getText()
  {
    return jdField_a_of_type_Cc.a(this.jdField_a_of_type_JavaLangObject);
  }
  
  public int getToIndex()
  {
    return jdField_a_of_type_Cc.h(this.jdField_a_of_type_JavaLangObject);
  }
  
  public int getWindowId()
  {
    return jdField_a_of_type_Cc.i(this.jdField_a_of_type_JavaLangObject);
  }
  
  public int hashCode()
  {
    if (this.jdField_a_of_type_JavaLangObject == null) {
      return 0;
    }
    return this.jdField_a_of_type_JavaLangObject.hashCode();
  }
  
  public boolean isChecked()
  {
    return jdField_a_of_type_Cc.a(this.jdField_a_of_type_JavaLangObject);
  }
  
  public boolean isEnabled()
  {
    return jdField_a_of_type_Cc.b(this.jdField_a_of_type_JavaLangObject);
  }
  
  public boolean isFullScreen()
  {
    return jdField_a_of_type_Cc.c(this.jdField_a_of_type_JavaLangObject);
  }
  
  public boolean isPassword()
  {
    return jdField_a_of_type_Cc.d(this.jdField_a_of_type_JavaLangObject);
  }
  
  public boolean isScrollable()
  {
    return jdField_a_of_type_Cc.e(this.jdField_a_of_type_JavaLangObject);
  }
  
  public void recycle()
  {
    jdField_a_of_type_Cc.a(this.jdField_a_of_type_JavaLangObject);
  }
  
  public void setAddedCount(int paramInt)
  {
    jdField_a_of_type_Cc.a(this.jdField_a_of_type_JavaLangObject, paramInt);
  }
  
  public void setBeforeText(CharSequence paramCharSequence)
  {
    jdField_a_of_type_Cc.a(this.jdField_a_of_type_JavaLangObject, paramCharSequence);
  }
  
  public void setChecked(boolean paramBoolean)
  {
    jdField_a_of_type_Cc.a(this.jdField_a_of_type_JavaLangObject, paramBoolean);
  }
  
  public void setClassName(CharSequence paramCharSequence)
  {
    jdField_a_of_type_Cc.b(this.jdField_a_of_type_JavaLangObject, paramCharSequence);
  }
  
  public void setContentDescription(CharSequence paramCharSequence)
  {
    jdField_a_of_type_Cc.c(this.jdField_a_of_type_JavaLangObject, paramCharSequence);
  }
  
  public void setCurrentItemIndex(int paramInt)
  {
    jdField_a_of_type_Cc.b(this.jdField_a_of_type_JavaLangObject, paramInt);
  }
  
  public void setEnabled(boolean paramBoolean)
  {
    jdField_a_of_type_Cc.b(this.jdField_a_of_type_JavaLangObject, paramBoolean);
  }
  
  public void setFromIndex(int paramInt)
  {
    jdField_a_of_type_Cc.c(this.jdField_a_of_type_JavaLangObject, paramInt);
  }
  
  public void setFullScreen(boolean paramBoolean)
  {
    jdField_a_of_type_Cc.c(this.jdField_a_of_type_JavaLangObject, paramBoolean);
  }
  
  public void setItemCount(int paramInt)
  {
    jdField_a_of_type_Cc.d(this.jdField_a_of_type_JavaLangObject, paramInt);
  }
  
  public void setMaxScrollX(int paramInt)
  {
    jdField_a_of_type_Cc.i(this.jdField_a_of_type_JavaLangObject, paramInt);
  }
  
  public void setMaxScrollY(int paramInt)
  {
    jdField_a_of_type_Cc.j(this.jdField_a_of_type_JavaLangObject, paramInt);
  }
  
  public void setParcelableData(Parcelable paramParcelable)
  {
    jdField_a_of_type_Cc.a(this.jdField_a_of_type_JavaLangObject, paramParcelable);
  }
  
  public void setPassword(boolean paramBoolean)
  {
    jdField_a_of_type_Cc.d(this.jdField_a_of_type_JavaLangObject, paramBoolean);
  }
  
  public void setRemovedCount(int paramInt)
  {
    jdField_a_of_type_Cc.e(this.jdField_a_of_type_JavaLangObject, paramInt);
  }
  
  public void setScrollX(int paramInt)
  {
    jdField_a_of_type_Cc.f(this.jdField_a_of_type_JavaLangObject, paramInt);
  }
  
  public void setScrollY(int paramInt)
  {
    jdField_a_of_type_Cc.g(this.jdField_a_of_type_JavaLangObject, paramInt);
  }
  
  public void setScrollable(boolean paramBoolean)
  {
    jdField_a_of_type_Cc.e(this.jdField_a_of_type_JavaLangObject, paramBoolean);
  }
  
  public void setSource(View paramView)
  {
    jdField_a_of_type_Cc.a(this.jdField_a_of_type_JavaLangObject, paramView);
  }
  
  public void setSource(View paramView, int paramInt)
  {
    jdField_a_of_type_Cc.a(this.jdField_a_of_type_JavaLangObject, paramView, paramInt);
  }
  
  public void setToIndex(int paramInt)
  {
    jdField_a_of_type_Cc.h(this.jdField_a_of_type_JavaLangObject, paramInt);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/view/accessibility/AccessibilityRecordCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */