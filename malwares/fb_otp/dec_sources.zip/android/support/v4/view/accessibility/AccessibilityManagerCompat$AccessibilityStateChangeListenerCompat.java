package android.support.v4.view.accessibility;

import bL;

public abstract class AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat
{
  public final Object a = AccessibilityManagerCompat.a().a(this);
  
  public abstract void onAccessibilityStateChanged(boolean paramBoolean);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/view/accessibility/AccessibilityManagerCompat$AccessibilityStateChangeListenerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */