package android.support.v4.view.accessibility;

import android.graphics.Rect;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.view.View;
import bP;
import bQ;
import bR;
import bS;
import java.util.ArrayList;
import java.util.List;

public class AccessibilityNodeInfoCompat
{
  public static final int ACTION_ACCESSIBILITY_FOCUS = 64;
  public static final String ACTION_ARGUMENT_HTML_ELEMENT_STRING = "ACTION_ARGUMENT_HTML_ELEMENT_STRING";
  public static final String ACTION_ARGUMENT_MOVEMENT_GRANULARITY_INT = "ACTION_ARGUMENT_MOVEMENT_GRANULARITY_INT";
  public static final int ACTION_CLEAR_ACCESSIBILITY_FOCUS = 128;
  public static final int ACTION_CLEAR_FOCUS = 2;
  public static final int ACTION_CLEAR_SELECTION = 8;
  public static final int ACTION_CLICK = 16;
  public static final int ACTION_FOCUS = 1;
  public static final int ACTION_LONG_CLICK = 32;
  public static final int ACTION_NEXT_AT_MOVEMENT_GRANULARITY = 256;
  public static final int ACTION_NEXT_HTML_ELEMENT = 1024;
  public static final int ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY = 512;
  public static final int ACTION_PREVIOUS_HTML_ELEMENT = 2048;
  public static final int ACTION_SCROLL_BACKWARD = 8192;
  public static final int ACTION_SCROLL_FORWARD = 4096;
  public static final int ACTION_SELECT = 4;
  public static final int FOCUS_ACCESSIBILITY = 2;
  public static final int FOCUS_INPUT = 1;
  public static final int MOVEMENT_GRANULARITY_CHARACTER = 1;
  public static final int MOVEMENT_GRANULARITY_LINE = 4;
  public static final int MOVEMENT_GRANULARITY_PAGE = 16;
  public static final int MOVEMENT_GRANULARITY_PARAGRAPH = 8;
  public static final int MOVEMENT_GRANULARITY_WORD = 2;
  private static final bQ jdField_a_of_type_BQ = new bS();
  private final Object jdField_a_of_type_JavaLangObject;
  
  static
  {
    if (Build.VERSION.SDK_INT >= 16)
    {
      jdField_a_of_type_BQ = new bR();
      return;
    }
    if (Build.VERSION.SDK_INT >= 14)
    {
      jdField_a_of_type_BQ = new bP();
      return;
    }
  }
  
  public AccessibilityNodeInfoCompat(Object paramObject)
  {
    this.jdField_a_of_type_JavaLangObject = paramObject;
  }
  
  public static AccessibilityNodeInfoCompat a(Object paramObject)
  {
    if (paramObject != null) {
      return new AccessibilityNodeInfoCompat(paramObject);
    }
    return null;
  }
  
  public static AccessibilityNodeInfoCompat obtain()
  {
    return a(jdField_a_of_type_BQ.a());
  }
  
  public static AccessibilityNodeInfoCompat obtain(AccessibilityNodeInfoCompat paramAccessibilityNodeInfoCompat)
  {
    return a(jdField_a_of_type_BQ.a(paramAccessibilityNodeInfoCompat.jdField_a_of_type_JavaLangObject));
  }
  
  public static AccessibilityNodeInfoCompat obtain(View paramView)
  {
    return a(jdField_a_of_type_BQ.a(paramView));
  }
  
  public static AccessibilityNodeInfoCompat obtain(View paramView, int paramInt)
  {
    return a(jdField_a_of_type_BQ.a(paramView, paramInt));
  }
  
  public void addAction(int paramInt)
  {
    jdField_a_of_type_BQ.a(this.jdField_a_of_type_JavaLangObject, paramInt);
  }
  
  public void addChild(View paramView)
  {
    jdField_a_of_type_BQ.a(this.jdField_a_of_type_JavaLangObject, paramView);
  }
  
  public void addChild(View paramView, int paramInt)
  {
    jdField_a_of_type_BQ.b(this.jdField_a_of_type_JavaLangObject, paramView, paramInt);
  }
  
  public boolean equals(Object paramObject)
  {
    if (this == paramObject) {}
    do
    {
      do
      {
        return true;
        if (paramObject == null) {
          return false;
        }
        if (getClass() != paramObject.getClass()) {
          return false;
        }
        paramObject = (AccessibilityNodeInfoCompat)paramObject;
        if (this.jdField_a_of_type_JavaLangObject != null) {
          break;
        }
      } while (((AccessibilityNodeInfoCompat)paramObject).jdField_a_of_type_JavaLangObject == null);
      return false;
    } while (this.jdField_a_of_type_JavaLangObject.equals(((AccessibilityNodeInfoCompat)paramObject).jdField_a_of_type_JavaLangObject));
    return false;
  }
  
  public List findAccessibilityNodeInfosByText(String paramString)
  {
    ArrayList localArrayList = new ArrayList();
    paramString = jdField_a_of_type_BQ.a(this.jdField_a_of_type_JavaLangObject, paramString);
    int j = paramString.size();
    int i = 0;
    while (i < j)
    {
      localArrayList.add(new AccessibilityNodeInfoCompat(paramString.get(i)));
      i += 1;
    }
    return localArrayList;
  }
  
  public AccessibilityNodeInfoCompat findFocus(int paramInt)
  {
    return a(jdField_a_of_type_BQ.b(this.jdField_a_of_type_JavaLangObject, paramInt));
  }
  
  public AccessibilityNodeInfoCompat focusSearch(int paramInt)
  {
    return a(jdField_a_of_type_BQ.c(this.jdField_a_of_type_JavaLangObject, paramInt));
  }
  
  public int getActions()
  {
    return jdField_a_of_type_BQ.a(this.jdField_a_of_type_JavaLangObject);
  }
  
  public void getBoundsInParent(Rect paramRect)
  {
    jdField_a_of_type_BQ.a(this.jdField_a_of_type_JavaLangObject, paramRect);
  }
  
  public void getBoundsInScreen(Rect paramRect)
  {
    jdField_a_of_type_BQ.b(this.jdField_a_of_type_JavaLangObject, paramRect);
  }
  
  public AccessibilityNodeInfoCompat getChild(int paramInt)
  {
    return a(jdField_a_of_type_BQ.a(this.jdField_a_of_type_JavaLangObject, paramInt));
  }
  
  public int getChildCount()
  {
    return jdField_a_of_type_BQ.b(this.jdField_a_of_type_JavaLangObject);
  }
  
  public CharSequence getClassName()
  {
    return jdField_a_of_type_BQ.a(this.jdField_a_of_type_JavaLangObject);
  }
  
  public CharSequence getContentDescription()
  {
    return jdField_a_of_type_BQ.b(this.jdField_a_of_type_JavaLangObject);
  }
  
  public Object getInfo()
  {
    return this.jdField_a_of_type_JavaLangObject;
  }
  
  public int getMovementGranularities()
  {
    return jdField_a_of_type_BQ.d(this.jdField_a_of_type_JavaLangObject);
  }
  
  public CharSequence getPackageName()
  {
    return jdField_a_of_type_BQ.c(this.jdField_a_of_type_JavaLangObject);
  }
  
  public AccessibilityNodeInfoCompat getParent()
  {
    return a(jdField_a_of_type_BQ.b(this.jdField_a_of_type_JavaLangObject));
  }
  
  public CharSequence getText()
  {
    return jdField_a_of_type_BQ.d(this.jdField_a_of_type_JavaLangObject);
  }
  
  public int getWindowId()
  {
    return jdField_a_of_type_BQ.c(this.jdField_a_of_type_JavaLangObject);
  }
  
  public int hashCode()
  {
    if (this.jdField_a_of_type_JavaLangObject == null) {
      return 0;
    }
    return this.jdField_a_of_type_JavaLangObject.hashCode();
  }
  
  public boolean isAccessibilityFocused()
  {
    return jdField_a_of_type_BQ.l(this.jdField_a_of_type_JavaLangObject);
  }
  
  public boolean isCheckable()
  {
    return jdField_a_of_type_BQ.a(this.jdField_a_of_type_JavaLangObject);
  }
  
  public boolean isChecked()
  {
    return jdField_a_of_type_BQ.b(this.jdField_a_of_type_JavaLangObject);
  }
  
  public boolean isClickable()
  {
    return jdField_a_of_type_BQ.c(this.jdField_a_of_type_JavaLangObject);
  }
  
  public boolean isEnabled()
  {
    return jdField_a_of_type_BQ.d(this.jdField_a_of_type_JavaLangObject);
  }
  
  public boolean isFocusable()
  {
    return jdField_a_of_type_BQ.e(this.jdField_a_of_type_JavaLangObject);
  }
  
  public boolean isFocused()
  {
    return jdField_a_of_type_BQ.f(this.jdField_a_of_type_JavaLangObject);
  }
  
  public boolean isLongClickable()
  {
    return jdField_a_of_type_BQ.g(this.jdField_a_of_type_JavaLangObject);
  }
  
  public boolean isPassword()
  {
    return jdField_a_of_type_BQ.h(this.jdField_a_of_type_JavaLangObject);
  }
  
  public boolean isScrollable()
  {
    return jdField_a_of_type_BQ.i(this.jdField_a_of_type_JavaLangObject);
  }
  
  public boolean isSelected()
  {
    return jdField_a_of_type_BQ.j(this.jdField_a_of_type_JavaLangObject);
  }
  
  public boolean isVisibleToUser()
  {
    return jdField_a_of_type_BQ.k(this.jdField_a_of_type_JavaLangObject);
  }
  
  public boolean performAction(int paramInt)
  {
    return jdField_a_of_type_BQ.a(this.jdField_a_of_type_JavaLangObject, paramInt);
  }
  
  public boolean performAction(int paramInt, Bundle paramBundle)
  {
    return jdField_a_of_type_BQ.a(this.jdField_a_of_type_JavaLangObject, paramInt, paramBundle);
  }
  
  public void recycle()
  {
    jdField_a_of_type_BQ.a(this.jdField_a_of_type_JavaLangObject);
  }
  
  public void setAccessibilityFocused(boolean paramBoolean)
  {
    jdField_a_of_type_BQ.l(this.jdField_a_of_type_JavaLangObject, paramBoolean);
  }
  
  public void setBoundsInParent(Rect paramRect)
  {
    jdField_a_of_type_BQ.c(this.jdField_a_of_type_JavaLangObject, paramRect);
  }
  
  public void setBoundsInScreen(Rect paramRect)
  {
    jdField_a_of_type_BQ.d(this.jdField_a_of_type_JavaLangObject, paramRect);
  }
  
  public void setCheckable(boolean paramBoolean)
  {
    jdField_a_of_type_BQ.a(this.jdField_a_of_type_JavaLangObject, paramBoolean);
  }
  
  public void setChecked(boolean paramBoolean)
  {
    jdField_a_of_type_BQ.b(this.jdField_a_of_type_JavaLangObject, paramBoolean);
  }
  
  public void setClassName(CharSequence paramCharSequence)
  {
    jdField_a_of_type_BQ.a(this.jdField_a_of_type_JavaLangObject, paramCharSequence);
  }
  
  public void setClickable(boolean paramBoolean)
  {
    jdField_a_of_type_BQ.c(this.jdField_a_of_type_JavaLangObject, paramBoolean);
  }
  
  public void setContentDescription(CharSequence paramCharSequence)
  {
    jdField_a_of_type_BQ.b(this.jdField_a_of_type_JavaLangObject, paramCharSequence);
  }
  
  public void setEnabled(boolean paramBoolean)
  {
    jdField_a_of_type_BQ.d(this.jdField_a_of_type_JavaLangObject, paramBoolean);
  }
  
  public void setFocusable(boolean paramBoolean)
  {
    jdField_a_of_type_BQ.e(this.jdField_a_of_type_JavaLangObject, paramBoolean);
  }
  
  public void setFocused(boolean paramBoolean)
  {
    jdField_a_of_type_BQ.f(this.jdField_a_of_type_JavaLangObject, paramBoolean);
  }
  
  public void setLongClickable(boolean paramBoolean)
  {
    jdField_a_of_type_BQ.g(this.jdField_a_of_type_JavaLangObject, paramBoolean);
  }
  
  public void setMovementGranularities(int paramInt)
  {
    jdField_a_of_type_BQ.b(this.jdField_a_of_type_JavaLangObject, paramInt);
  }
  
  public void setPackageName(CharSequence paramCharSequence)
  {
    jdField_a_of_type_BQ.c(this.jdField_a_of_type_JavaLangObject, paramCharSequence);
  }
  
  public void setParent(View paramView)
  {
    jdField_a_of_type_BQ.b(this.jdField_a_of_type_JavaLangObject, paramView);
  }
  
  public void setParent(View paramView, int paramInt)
  {
    jdField_a_of_type_BQ.c(this.jdField_a_of_type_JavaLangObject, paramView, paramInt);
  }
  
  public void setPassword(boolean paramBoolean)
  {
    jdField_a_of_type_BQ.h(this.jdField_a_of_type_JavaLangObject, paramBoolean);
  }
  
  public void setScrollable(boolean paramBoolean)
  {
    jdField_a_of_type_BQ.i(this.jdField_a_of_type_JavaLangObject, paramBoolean);
  }
  
  public void setSelected(boolean paramBoolean)
  {
    jdField_a_of_type_BQ.j(this.jdField_a_of_type_JavaLangObject, paramBoolean);
  }
  
  public void setSource(View paramView)
  {
    jdField_a_of_type_BQ.c(this.jdField_a_of_type_JavaLangObject, paramView);
  }
  
  public void setSource(View paramView, int paramInt)
  {
    jdField_a_of_type_BQ.a(this.jdField_a_of_type_JavaLangObject, paramView, paramInt);
  }
  
  public void setText(CharSequence paramCharSequence)
  {
    jdField_a_of_type_BQ.d(this.jdField_a_of_type_JavaLangObject, paramCharSequence);
  }
  
  public void setVisibleToUser(boolean paramBoolean)
  {
    jdField_a_of_type_BQ.k(this.jdField_a_of_type_JavaLangObject, paramBoolean);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/view/accessibility/AccessibilityNodeInfoCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */