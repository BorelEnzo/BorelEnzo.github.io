package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.ViewConfiguration;
import bp;
import bq;
import br;

public class ViewConfigurationCompat
{
  static final br a = new bp();
  
  static
  {
    if (Build.VERSION.SDK_INT >= 11)
    {
      a = new bq();
      return;
    }
  }
  
  public static int getScaledPagingTouchSlop(ViewConfiguration paramViewConfiguration)
  {
    return a.a(paramViewConfiguration);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/view/ViewConfigurationCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */