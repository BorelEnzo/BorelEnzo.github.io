package android.support.v4.view;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Parcelable;
import android.os.SystemClock;
import android.support.v4.widget.EdgeEffectCompat;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SoundEffectConstants;
import android.view.VelocityTracker;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.Scroller;
import bA;
import bB;
import bC;
import bE;
import bv;
import bw;
import bx;
import by;
import bz;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ViewPager
  extends ViewGroup
{
  public static final int SCROLL_STATE_DRAGGING = 1;
  public static final int SCROLL_STATE_IDLE = 0;
  public static final int SCROLL_STATE_SETTLING = 2;
  private static final Interpolator jdField_a_of_type_AndroidViewAnimationInterpolator = new bw();
  private static final bE jdField_a_of_type_BE = new bE();
  private static final Comparator jdField_a_of_type_JavaUtilComparator;
  private static final int[] jdField_a_of_type_ArrayOfInt = { 16842931 };
  private float jdField_a_of_type_Float = -3.4028235E38F;
  private int jdField_a_of_type_Int;
  private long jdField_a_of_type_Long;
  private final Rect jdField_a_of_type_AndroidGraphicsRect = new Rect();
  private Drawable jdField_a_of_type_AndroidGraphicsDrawableDrawable;
  private Parcelable jdField_a_of_type_AndroidOsParcelable = null;
  private PagerAdapter jdField_a_of_type_AndroidSupportV4ViewPagerAdapter;
  private ViewPager.OnPageChangeListener jdField_a_of_type_AndroidSupportV4ViewViewPager$OnPageChangeListener;
  private ViewPager.PageTransformer jdField_a_of_type_AndroidSupportV4ViewViewPager$PageTransformer;
  private EdgeEffectCompat jdField_a_of_type_AndroidSupportV4WidgetEdgeEffectCompat;
  private VelocityTracker jdField_a_of_type_AndroidViewVelocityTracker;
  private Scroller jdField_a_of_type_AndroidWidgetScroller;
  private bB jdField_a_of_type_BB;
  private bC jdField_a_of_type_BC;
  private final bz jdField_a_of_type_Bz = new bz();
  private ClassLoader jdField_a_of_type_JavaLangClassLoader = null;
  private final Runnable jdField_a_of_type_JavaLangRunnable = new bx(this);
  private Method jdField_a_of_type_JavaLangReflectMethod;
  private final ArrayList jdField_a_of_type_JavaUtilArrayList = new ArrayList();
  private boolean jdField_a_of_type_Boolean;
  private float jdField_b_of_type_Float = Float.MAX_VALUE;
  private int jdField_b_of_type_Int = -1;
  private ViewPager.OnPageChangeListener jdField_b_of_type_AndroidSupportV4ViewViewPager$OnPageChangeListener;
  private EdgeEffectCompat jdField_b_of_type_AndroidSupportV4WidgetEdgeEffectCompat;
  private ArrayList jdField_b_of_type_JavaUtilArrayList;
  private boolean jdField_b_of_type_Boolean;
  private float jdField_c_of_type_Float;
  private int jdField_c_of_type_Int;
  private boolean jdField_c_of_type_Boolean;
  private float jdField_d_of_type_Float;
  private int jdField_d_of_type_Int;
  private boolean jdField_d_of_type_Boolean;
  private float jdField_e_of_type_Float;
  private int jdField_e_of_type_Int;
  private boolean jdField_e_of_type_Boolean;
  private float jdField_f_of_type_Float;
  private int jdField_f_of_type_Int;
  private boolean jdField_f_of_type_Boolean;
  private int jdField_g_of_type_Int;
  private boolean jdField_g_of_type_Boolean = true;
  private int jdField_h_of_type_Int = 1;
  private boolean jdField_h_of_type_Boolean = false;
  private int jdField_i_of_type_Int;
  private boolean jdField_i_of_type_Boolean;
  private int j;
  private int k;
  private int l = -1;
  private int m;
  private int n;
  private int o;
  private int p;
  private int q;
  private int r;
  private int s = 0;
  
  static
  {
    jdField_a_of_type_JavaUtilComparator = new bv();
  }
  
  public ViewPager(Context paramContext)
  {
    super(paramContext);
    c();
  }
  
  public ViewPager(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    c();
  }
  
  private int a(int paramInt1, float paramFloat, int paramInt2, int paramInt3)
  {
    if ((Math.abs(paramInt3) > this.o) && (Math.abs(paramInt2) > this.m))
    {
      if (paramInt2 > 0) {}
      for (;;)
      {
        paramInt2 = paramInt1;
        if (this.jdField_a_of_type_JavaUtilArrayList.size() > 0)
        {
          bz localbz1 = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(0);
          bz localbz2 = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(this.jdField_a_of_type_JavaUtilArrayList.size() - 1);
          paramInt2 = Math.max(localbz1.jdField_a_of_type_Int, Math.min(paramInt1, localbz2.jdField_a_of_type_Int));
        }
        return paramInt2;
        paramInt1 += 1;
      }
    }
    if (paramInt1 >= this.jdField_a_of_type_Int) {}
    for (float f1 = 0.4F;; f1 = 0.6F)
    {
      paramInt1 = (int)(f1 + (paramInt1 + paramFloat));
      break;
    }
  }
  
  private Rect a(Rect paramRect, View paramView)
  {
    if (paramRect == null) {
      paramRect = new Rect();
    }
    for (;;)
    {
      if (paramView == null)
      {
        paramRect.set(0, 0, 0, 0);
        return paramRect;
      }
      paramRect.left = paramView.getLeft();
      paramRect.right = paramView.getRight();
      paramRect.top = paramView.getTop();
      paramRect.bottom = paramView.getBottom();
      for (paramView = paramView.getParent(); ((paramView instanceof ViewGroup)) && (paramView != this); paramView = paramView.getParent())
      {
        paramView = (ViewGroup)paramView;
        paramRect.left += paramView.getLeft();
        paramRect.right += paramView.getRight();
        paramRect.top += paramView.getTop();
        paramRect.bottom += paramView.getBottom();
      }
      return paramRect;
    }
  }
  
  private bz a()
  {
    int i1 = getWidth();
    float f1;
    float f2;
    label36:
    float f4;
    float f3;
    int i3;
    int i2;
    Object localObject1;
    label53:
    Object localObject2;
    bz localbz;
    if (i1 > 0)
    {
      f1 = getScrollX() / i1;
      if (i1 <= 0) {
        break label214;
      }
      f2 = this.jdField_c_of_type_Int / i1;
      f4 = 0.0F;
      f3 = 0.0F;
      i3 = -1;
      i1 = 0;
      i2 = 1;
      localObject1 = null;
      localObject2 = localObject1;
      if (i1 < this.jdField_a_of_type_JavaUtilArrayList.size())
      {
        localbz = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(i1);
        if ((i2 != 0) || (localbz.jdField_a_of_type_Int == i3 + 1)) {
          break label249;
        }
        localbz = this.jdField_a_of_type_Bz;
        localbz.jdField_b_of_type_Float = (f4 + f3 + f2);
        localbz.jdField_a_of_type_Int = (i3 + 1);
        localbz.jdField_a_of_type_Float = this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.getPageWidth(localbz.jdField_a_of_type_Int);
        i1 -= 1;
      }
    }
    label214:
    label219:
    label249:
    for (;;)
    {
      f3 = localbz.jdField_b_of_type_Float;
      f4 = localbz.jdField_a_of_type_Float;
      if (i2 == 0)
      {
        localObject2 = localObject1;
        if (f1 < f3) {}
      }
      else
      {
        if ((f1 >= f4 + f3 + f2) && (i1 != this.jdField_a_of_type_JavaUtilArrayList.size() - 1)) {
          break label219;
        }
        localObject2 = localbz;
      }
      return (bz)localObject2;
      f1 = 0.0F;
      break;
      f2 = 0.0F;
      break label36;
      i3 = localbz.jdField_a_of_type_Int;
      f4 = localbz.jdField_a_of_type_Float;
      i2 = 0;
      i1 += 1;
      localObject1 = localbz;
      break label53;
    }
  }
  
  private bz a(int paramInt)
  {
    int i1 = 0;
    while (i1 < this.jdField_a_of_type_JavaUtilArrayList.size())
    {
      bz localbz = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(i1);
      if (localbz.jdField_a_of_type_Int == paramInt) {
        return localbz;
      }
      i1 += 1;
    }
    return null;
  }
  
  private bz a(int paramInt1, int paramInt2)
  {
    bz localbz = new bz();
    localbz.jdField_a_of_type_Int = paramInt1;
    localbz.jdField_a_of_type_JavaLangObject = this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.instantiateItem(this, paramInt1);
    localbz.jdField_a_of_type_Float = this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.getPageWidth(paramInt1);
    if ((paramInt2 < 0) || (paramInt2 >= this.jdField_a_of_type_JavaUtilArrayList.size()))
    {
      this.jdField_a_of_type_JavaUtilArrayList.add(localbz);
      return localbz;
    }
    this.jdField_a_of_type_JavaUtilArrayList.add(paramInt2, localbz);
    return localbz;
  }
  
  private bz a(View paramView)
  {
    int i1 = 0;
    while (i1 < this.jdField_a_of_type_JavaUtilArrayList.size())
    {
      bz localbz = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(i1);
      if (this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.isViewFromObject(paramView, localbz.jdField_a_of_type_JavaLangObject)) {
        return localbz;
      }
      i1 += 1;
    }
    return null;
  }
  
  private void a(int paramInt)
  {
    if (this.s == paramInt) {}
    label35:
    label71:
    do
    {
      return;
      this.s = paramInt;
      if (this.jdField_a_of_type_AndroidSupportV4ViewViewPager$PageTransformer != null)
      {
        int i1;
        int i2;
        if (paramInt != 0)
        {
          i1 = 1;
          int i4 = getChildCount();
          i2 = 0;
          if (i2 >= i4) {
            continue;
          }
          if (i1 == 0) {
            break label71;
          }
        }
        for (int i3 = 2;; i3 = 0)
        {
          ViewCompat.setLayerType(getChildAt(i2), i3, null);
          i2 += 1;
          break label35;
          i1 = 0;
          break;
        }
      }
    } while (this.jdField_a_of_type_AndroidSupportV4ViewViewPager$OnPageChangeListener == null);
    this.jdField_a_of_type_AndroidSupportV4ViewViewPager$OnPageChangeListener.onPageScrollStateChanged(paramInt);
  }
  
  private void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if ((paramInt2 > 0) && (!this.jdField_a_of_type_JavaUtilArrayList.isEmpty()))
    {
      f1 = getScrollX() / (paramInt2 + paramInt4);
      paramInt2 = (int)((paramInt1 + paramInt3) * f1);
      scrollTo(paramInt2, getScrollY());
      if (!this.jdField_a_of_type_AndroidWidgetScroller.isFinished())
      {
        paramInt3 = this.jdField_a_of_type_AndroidWidgetScroller.getDuration();
        paramInt4 = this.jdField_a_of_type_AndroidWidgetScroller.timePassed();
        localbz = a(this.jdField_a_of_type_Int);
        this.jdField_a_of_type_AndroidWidgetScroller.startScroll(paramInt2, 0, (int)(localbz.jdField_b_of_type_Float * paramInt1), 0, paramInt3 - paramInt4);
      }
      return;
    }
    bz localbz = a(this.jdField_a_of_type_Int);
    if (localbz != null) {}
    for (float f1 = Math.min(localbz.jdField_b_of_type_Float, this.jdField_b_of_type_Float);; f1 = 0.0F)
    {
      paramInt1 = (int)(f1 * paramInt1);
      if (paramInt1 == getScrollX()) {
        break;
      }
      a(false);
      scrollTo(paramInt1, getScrollY());
      return;
    }
  }
  
  private void a(int paramInt1, boolean paramBoolean1, int paramInt2, boolean paramBoolean2)
  {
    bz localbz = a(paramInt1);
    int i1 = 0;
    if (localbz != null) {
      i1 = (int)(getWidth() * Math.max(this.jdField_a_of_type_Float, Math.min(localbz.jdField_b_of_type_Float, this.jdField_b_of_type_Float)));
    }
    if (paramBoolean1)
    {
      if (getChildCount() == 0) {
        b(false);
      }
      int i2;
      int i3;
      int i4;
      for (;;)
      {
        if ((paramBoolean2) && (this.jdField_a_of_type_AndroidSupportV4ViewViewPager$OnPageChangeListener != null)) {
          this.jdField_a_of_type_AndroidSupportV4ViewViewPager$OnPageChangeListener.onPageSelected(paramInt1);
        }
        if ((paramBoolean2) && (this.jdField_b_of_type_AndroidSupportV4ViewViewPager$OnPageChangeListener != null)) {
          this.jdField_b_of_type_AndroidSupportV4ViewViewPager$OnPageChangeListener.onPageSelected(paramInt1);
        }
        return;
        i2 = getScrollX();
        i3 = getScrollY();
        i1 -= i2;
        i4 = 0 - i3;
        if ((i1 != 0) || (i4 != 0)) {
          break;
        }
        a(false);
        b();
        a(0);
      }
      b(true);
      a(2);
      int i5 = getWidth();
      int i6 = i5 / 2;
      float f3 = Math.min(1.0F, 1.0F * Math.abs(i1) / i5);
      float f1 = i6;
      float f2 = i6;
      f3 = (float)Math.sin((float)((f3 - 0.5F) * 0.4712389167638204D));
      paramInt2 = Math.abs(paramInt2);
      if (paramInt2 > 0) {}
      for (paramInt2 = Math.round(1000.0F * Math.abs((f2 * f3 + f1) / paramInt2)) * 4;; paramInt2 = (int)((Math.abs(i1) / (f1 * f2 + this.jdField_c_of_type_Int) + 1.0F) * 100.0F))
      {
        paramInt2 = Math.min(paramInt2, 600);
        this.jdField_a_of_type_AndroidWidgetScroller.startScroll(i2, i3, i1, i4, paramInt2);
        ViewCompat.postInvalidateOnAnimation(this);
        break;
        f1 = i5;
        f2 = this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.getPageWidth(this.jdField_a_of_type_Int);
      }
    }
    if ((paramBoolean2) && (this.jdField_a_of_type_AndroidSupportV4ViewViewPager$OnPageChangeListener != null)) {
      this.jdField_a_of_type_AndroidSupportV4ViewViewPager$OnPageChangeListener.onPageSelected(paramInt1);
    }
    if ((paramBoolean2) && (this.jdField_b_of_type_AndroidSupportV4ViewViewPager$OnPageChangeListener != null)) {
      this.jdField_b_of_type_AndroidSupportV4ViewViewPager$OnPageChangeListener.onPageSelected(paramInt1);
    }
    a(false);
    scrollTo(i1, 0);
  }
  
  private void a(int paramInt, boolean paramBoolean1, boolean paramBoolean2)
  {
    a(paramInt, paramBoolean1, paramBoolean2, 0);
  }
  
  private void a(int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2)
  {
    boolean bool = false;
    if ((this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter == null) || (this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.getCount() <= 0))
    {
      b(false);
      return;
    }
    if ((!paramBoolean2) && (this.jdField_a_of_type_Int == paramInt1) && (this.jdField_a_of_type_JavaUtilArrayList.size() != 0))
    {
      b(false);
      return;
    }
    int i1;
    if (paramInt1 < 0) {
      i1 = 0;
    }
    for (;;)
    {
      paramInt1 = this.jdField_h_of_type_Int;
      if ((i1 <= this.jdField_a_of_type_Int + paramInt1) && (i1 >= this.jdField_a_of_type_Int - paramInt1)) {
        break;
      }
      paramInt1 = 0;
      while (paramInt1 < this.jdField_a_of_type_JavaUtilArrayList.size())
      {
        ((bz)this.jdField_a_of_type_JavaUtilArrayList.get(paramInt1)).jdField_a_of_type_Boolean = true;
        paramInt1 += 1;
      }
      i1 = paramInt1;
      if (paramInt1 >= this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.getCount()) {
        i1 = this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.getCount() - 1;
      }
    }
    paramBoolean2 = bool;
    if (this.jdField_a_of_type_Int != i1) {
      paramBoolean2 = true;
    }
    b(i1);
    a(i1, paramBoolean1, paramInt2, paramBoolean2);
  }
  
  private void a(MotionEvent paramMotionEvent)
  {
    int i1 = MotionEventCompat.getActionIndex(paramMotionEvent);
    if (MotionEventCompat.getPointerId(paramMotionEvent, i1) == this.l) {
      if (i1 != 0) {
        break label56;
      }
    }
    label56:
    for (i1 = 1;; i1 = 0)
    {
      this.jdField_c_of_type_Float = MotionEventCompat.getX(paramMotionEvent, i1);
      this.l = MotionEventCompat.getPointerId(paramMotionEvent, i1);
      if (this.jdField_a_of_type_AndroidViewVelocityTracker != null) {
        this.jdField_a_of_type_AndroidViewVelocityTracker.clear();
      }
      return;
    }
  }
  
  private void a(boolean paramBoolean)
  {
    if (this.s == 2) {}
    int i2;
    for (int i1 = 1;; i1 = 0)
    {
      if (i1 != 0)
      {
        b(false);
        this.jdField_a_of_type_AndroidWidgetScroller.abortAnimation();
        i2 = getScrollX();
        i3 = getScrollY();
        int i4 = this.jdField_a_of_type_AndroidWidgetScroller.getCurrX();
        int i5 = this.jdField_a_of_type_AndroidWidgetScroller.getCurrY();
        if ((i2 != i4) || (i3 != i5)) {
          scrollTo(i4, i5);
        }
      }
      this.jdField_c_of_type_Boolean = false;
      int i3 = 0;
      i2 = i1;
      i1 = i3;
      while (i1 < this.jdField_a_of_type_JavaUtilArrayList.size())
      {
        bz localbz = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(i1);
        if (localbz.jdField_a_of_type_Boolean)
        {
          localbz.jdField_a_of_type_Boolean = false;
          i2 = 1;
        }
        i1 += 1;
      }
    }
    if (i2 != 0)
    {
      if (paramBoolean) {
        ViewCompat.postOnAnimation(this, this.jdField_a_of_type_JavaLangRunnable);
      }
    }
    else {
      return;
    }
    this.jdField_a_of_type_JavaLangRunnable.run();
  }
  
  private boolean a()
  {
    if (this.jdField_a_of_type_Int > 0)
    {
      setCurrentItem(this.jdField_a_of_type_Int - 1, true);
      return true;
    }
    return false;
  }
  
  private boolean a(float paramFloat)
  {
    int i2 = 1;
    boolean bool2 = false;
    boolean bool1 = false;
    float f1 = this.jdField_c_of_type_Float;
    this.jdField_c_of_type_Float = paramFloat;
    float f2 = getScrollX() + (f1 - paramFloat);
    int i3 = getWidth();
    paramFloat = i3 * this.jdField_a_of_type_Float;
    f1 = i3;
    float f3 = this.jdField_b_of_type_Float;
    bz localbz1 = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(0);
    bz localbz2 = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(this.jdField_a_of_type_JavaUtilArrayList.size() - 1);
    if (localbz1.jdField_a_of_type_Int != 0) {
      paramFloat = localbz1.jdField_b_of_type_Float * i3;
    }
    for (int i1 = 0;; i1 = 1)
    {
      if (localbz2.jdField_a_of_type_Int != this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.getCount() - 1)
      {
        f1 = localbz2.jdField_b_of_type_Float * i3;
        i2 = 0;
      }
      for (;;)
      {
        if (f2 < paramFloat)
        {
          f1 = paramFloat;
          if (i1 != 0)
          {
            bool1 = this.jdField_a_of_type_AndroidSupportV4WidgetEdgeEffectCompat.onPull(Math.abs(paramFloat - f2) / i3);
            f1 = paramFloat;
          }
        }
        for (;;)
        {
          this.jdField_c_of_type_Float += f1 - (int)f1;
          scrollTo((int)f1, getScrollY());
          a((int)f1);
          return bool1;
          if (f2 > f1)
          {
            bool1 = bool2;
            if (i2 != 0) {
              bool1 = this.jdField_b_of_type_AndroidSupportV4WidgetEdgeEffectCompat.onPull(Math.abs(f2 - f1) / i3);
            }
          }
          else
          {
            f1 = f2;
          }
        }
        f1 *= f3;
      }
    }
  }
  
  private boolean a(int paramInt)
  {
    boolean bool = false;
    if (this.jdField_a_of_type_JavaUtilArrayList.size() == 0)
    {
      this.jdField_i_of_type_Boolean = false;
      onPageScrolled(0, 0.0F, 0);
      if (!this.jdField_i_of_type_Boolean) {
        throw new IllegalStateException("onPageScrolled did not call superclass implementation");
      }
    }
    else
    {
      bz localbz = a();
      int i2 = getWidth();
      int i3 = this.jdField_c_of_type_Int;
      float f1 = this.jdField_c_of_type_Int / i2;
      int i1 = localbz.jdField_a_of_type_Int;
      f1 = (paramInt / i2 - localbz.jdField_b_of_type_Float) / (localbz.jdField_a_of_type_Float + f1);
      paramInt = (int)((i3 + i2) * f1);
      this.jdField_i_of_type_Boolean = false;
      onPageScrolled(i1, f1, paramInt);
      if (!this.jdField_i_of_type_Boolean) {
        throw new IllegalStateException("onPageScrolled did not call superclass implementation");
      }
      bool = true;
    }
    return bool;
  }
  
  private bz b(View paramView)
  {
    for (;;)
    {
      ViewParent localViewParent = paramView.getParent();
      if (localViewParent == this) {
        break;
      }
      if ((localViewParent == null) || (!(localViewParent instanceof View))) {
        return null;
      }
      paramView = (View)localViewParent;
    }
    return a(paramView);
  }
  
  private void b(int paramInt)
  {
    Object localObject3;
    if (this.jdField_a_of_type_Int != paramInt)
    {
      localObject3 = a(this.jdField_a_of_type_Int);
      this.jdField_a_of_type_Int = paramInt;
    }
    for (;;)
    {
      if (this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter == null) {
        label30:
        return;
      }
      int i7;
      int i5;
      int i6;
      Object localObject1;
      if ((!this.jdField_c_of_type_Boolean) && (getWindowToken() != null))
      {
        this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.startUpdate(this);
        paramInt = this.jdField_h_of_type_Int;
        i7 = Math.max(0, this.jdField_a_of_type_Int - paramInt);
        i5 = this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.getCount();
        i6 = Math.min(i5 - 1, paramInt + this.jdField_a_of_type_Int);
        paramInt = 0;
        if (paramInt >= this.jdField_a_of_type_JavaUtilArrayList.size()) {
          break label1847;
        }
        localObject1 = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(paramInt);
        if (((bz)localObject1).jdField_a_of_type_Int >= this.jdField_a_of_type_Int) {
          if (((bz)localObject1).jdField_a_of_type_Int != this.jdField_a_of_type_Int) {
            break label1847;
          }
        }
      }
      for (;;)
      {
        if ((localObject1 == null) && (i5 > 0)) {}
        for (Object localObject2 = a(this.jdField_a_of_type_Int, paramInt);; localObject2 = localObject1)
        {
          int i4;
          label194:
          float f3;
          int i1;
          float f2;
          int i3;
          int i2;
          label222:
          float f1;
          if (localObject2 != null)
          {
            i4 = paramInt - 1;
            Object localObject4;
            if (i4 >= 0)
            {
              localObject1 = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(i4);
              f3 = ((bz)localObject2).jdField_a_of_type_Float;
              i1 = this.jdField_a_of_type_Int;
              f2 = 0.0F;
              i3 = i1 - 1;
              i2 = paramInt;
              localObject4 = localObject1;
              if (i3 < 0) {
                break label508;
              }
              if ((f2 < 2.0F - f3) || (i3 >= i7)) {
                break label390;
              }
              if (localObject4 == null) {
                break label508;
              }
              localObject1 = localObject4;
              paramInt = i4;
              f1 = f2;
              i1 = i2;
              if (i3 == ((bz)localObject4).jdField_a_of_type_Int)
              {
                localObject1 = localObject4;
                paramInt = i4;
                f1 = f2;
                i1 = i2;
                if (!((bz)localObject4).jdField_a_of_type_Boolean)
                {
                  this.jdField_a_of_type_JavaUtilArrayList.remove(i4);
                  this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.destroyItem(this, i3, ((bz)localObject4).jdField_a_of_type_JavaLangObject);
                  paramInt = i4 - 1;
                  i1 = i2 - 1;
                  if (paramInt < 0) {
                    break label382;
                  }
                  localObject1 = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(paramInt);
                  f1 = f2;
                }
              }
            }
            for (;;)
            {
              i3 -= 1;
              localObject4 = localObject1;
              i4 = paramInt;
              f2 = f1;
              i2 = i1;
              break label222;
              paramInt += 1;
              break;
              localObject1 = null;
              break label194;
              label382:
              localObject1 = null;
              f1 = f2;
              continue;
              label390:
              if ((localObject4 != null) && (i3 == ((bz)localObject4).jdField_a_of_type_Int))
              {
                f1 = f2 + ((bz)localObject4).jdField_a_of_type_Float;
                paramInt = i4 - 1;
                if (paramInt >= 0)
                {
                  localObject1 = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(paramInt);
                  i1 = i2;
                }
                else
                {
                  localObject1 = null;
                  i1 = i2;
                }
              }
              else
              {
                f1 = f2 + a(i3, i4 + 1).jdField_a_of_type_Float;
                i1 = i2 + 1;
                if (i4 >= 0)
                {
                  localObject1 = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(i4);
                  paramInt = i4;
                }
                else
                {
                  localObject1 = null;
                  paramInt = i4;
                }
              }
            }
            label508:
            f1 = ((bz)localObject2).jdField_a_of_type_Float;
            paramInt = i2 + 1;
            if (f1 < 2.0F) {
              if (paramInt < this.jdField_a_of_type_JavaUtilArrayList.size())
              {
                localObject1 = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(paramInt);
                label549:
                i1 = this.jdField_a_of_type_Int + 1;
                label557:
                if (i1 >= i5) {
                  break label787;
                }
                if ((f1 < 2.0F) || (i1 <= i6)) {
                  break label669;
                }
                if (localObject1 == null) {
                  break label787;
                }
                if ((i1 != ((bz)localObject1).jdField_a_of_type_Int) || (((bz)localObject1).jdField_a_of_type_Boolean)) {
                  break label1837;
                }
                this.jdField_a_of_type_JavaUtilArrayList.remove(paramInt);
                this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.destroyItem(this, i1, ((bz)localObject1).jdField_a_of_type_JavaLangObject);
                if (paramInt >= this.jdField_a_of_type_JavaUtilArrayList.size()) {
                  break label663;
                }
                localObject1 = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(paramInt);
              }
            }
          }
          label663:
          label669:
          label787:
          label1187:
          label1256:
          label1324:
          label1372:
          label1558:
          label1701:
          label1706:
          label1829:
          label1835:
          label1837:
          for (;;)
          {
            i1 += 1;
            break label557;
            localObject1 = null;
            break label549;
            localObject1 = null;
            continue;
            if ((localObject1 != null) && (i1 == ((bz)localObject1).jdField_a_of_type_Int))
            {
              f2 = ((bz)localObject1).jdField_a_of_type_Float;
              paramInt += 1;
              if (paramInt < this.jdField_a_of_type_JavaUtilArrayList.size()) {}
              for (localObject1 = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(paramInt);; localObject1 = null)
              {
                f1 += f2;
                break;
              }
            }
            localObject1 = a(i1, paramInt);
            paramInt += 1;
            f2 = ((bz)localObject1).jdField_a_of_type_Float;
            if (paramInt < this.jdField_a_of_type_JavaUtilArrayList.size()) {}
            for (localObject1 = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(paramInt);; localObject1 = null)
            {
              f1 += f2;
              break;
            }
            i4 = this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.getCount();
            paramInt = getWidth();
            if (paramInt > 0)
            {
              f2 = this.jdField_c_of_type_Int / paramInt;
              if (localObject3 == null) {
                break label1187;
              }
              paramInt = ((bz)localObject3).jdField_a_of_type_Int;
              if (paramInt < ((bz)localObject2).jdField_a_of_type_Int)
              {
                f1 = ((bz)localObject3).jdField_b_of_type_Float;
                f1 = ((bz)localObject3).jdField_a_of_type_Float + f1 + f2;
                paramInt += 1;
                i1 = 0;
              }
            }
            else
            {
              for (;;)
              {
                if ((paramInt > ((bz)localObject2).jdField_a_of_type_Int) || (i1 >= this.jdField_a_of_type_JavaUtilArrayList.size())) {
                  break label1187;
                }
                for (localObject1 = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(i1);; localObject1 = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(i1))
                {
                  i3 = paramInt;
                  f3 = f1;
                  if (paramInt <= ((bz)localObject1).jdField_a_of_type_Int) {
                    break;
                  }
                  i3 = paramInt;
                  f3 = f1;
                  if (i1 >= this.jdField_a_of_type_JavaUtilArrayList.size() - 1) {
                    break;
                  }
                  i1 += 1;
                }
                f2 = 0.0F;
                break;
                while (i3 < ((bz)localObject1).jdField_a_of_type_Int)
                {
                  f3 += this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.getPageWidth(i3) + f2;
                  i3 += 1;
                }
                ((bz)localObject1).jdField_b_of_type_Float = f3;
                f1 = f3 + (((bz)localObject1).jdField_a_of_type_Float + f2);
                paramInt = i3 + 1;
              }
            }
            if (paramInt > ((bz)localObject2).jdField_a_of_type_Int)
            {
              i1 = this.jdField_a_of_type_JavaUtilArrayList.size();
              f1 = ((bz)localObject3).jdField_b_of_type_Float;
              paramInt -= 1;
              i1 -= 1;
              while ((paramInt >= ((bz)localObject2).jdField_a_of_type_Int) && (i1 >= 0))
              {
                for (localObject1 = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(i1);; localObject1 = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(i1))
                {
                  i3 = paramInt;
                  f3 = f1;
                  if (paramInt >= ((bz)localObject1).jdField_a_of_type_Int) {
                    break;
                  }
                  i3 = paramInt;
                  f3 = f1;
                  if (i1 <= 0) {
                    break;
                  }
                  i1 -= 1;
                }
                while (i3 > ((bz)localObject1).jdField_a_of_type_Int)
                {
                  f3 -= this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.getPageWidth(i3) + f2;
                  i3 -= 1;
                }
                f1 = f3 - (((bz)localObject1).jdField_a_of_type_Float + f2);
                ((bz)localObject1).jdField_b_of_type_Float = f1;
                paramInt = i3 - 1;
              }
            }
            i3 = this.jdField_a_of_type_JavaUtilArrayList.size();
            f3 = ((bz)localObject2).jdField_b_of_type_Float;
            paramInt = ((bz)localObject2).jdField_a_of_type_Int - 1;
            if (((bz)localObject2).jdField_a_of_type_Int == 0)
            {
              f1 = ((bz)localObject2).jdField_b_of_type_Float;
              this.jdField_a_of_type_Float = f1;
              if (((bz)localObject2).jdField_a_of_type_Int != i4 - 1) {
                break label1324;
              }
              f1 = ((bz)localObject2).jdField_b_of_type_Float + ((bz)localObject2).jdField_a_of_type_Float - 1.0F;
              this.jdField_b_of_type_Float = f1;
              i1 = i2 - 1;
              f1 = f3;
            }
            for (;;)
            {
              if (i1 < 0) {
                break label1372;
              }
              localObject1 = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(i1);
              for (;;)
              {
                if (paramInt > ((bz)localObject1).jdField_a_of_type_Int)
                {
                  f1 -= this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.getPageWidth(paramInt) + f2;
                  paramInt -= 1;
                  continue;
                  f1 = -3.4028235E38F;
                  break;
                  f1 = Float.MAX_VALUE;
                  break label1256;
                }
              }
              f1 -= ((bz)localObject1).jdField_a_of_type_Float + f2;
              ((bz)localObject1).jdField_b_of_type_Float = f1;
              if (((bz)localObject1).jdField_a_of_type_Int == 0) {
                this.jdField_a_of_type_Float = f1;
              }
              paramInt -= 1;
              i1 -= 1;
            }
            f1 = ((bz)localObject2).jdField_b_of_type_Float + ((bz)localObject2).jdField_a_of_type_Float + f2;
            paramInt = ((bz)localObject2).jdField_a_of_type_Int + 1;
            i1 = i2 + 1;
            while (i1 < i3)
            {
              localObject1 = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(i1);
              while (paramInt < ((bz)localObject1).jdField_a_of_type_Int)
              {
                f1 = this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.getPageWidth(paramInt) + f2 + f1;
                paramInt += 1;
              }
              if (((bz)localObject1).jdField_a_of_type_Int == i4 - 1) {
                this.jdField_b_of_type_Float = (((bz)localObject1).jdField_a_of_type_Float + f1 - 1.0F);
              }
              ((bz)localObject1).jdField_b_of_type_Float = f1;
              f1 += ((bz)localObject1).jdField_a_of_type_Float + f2;
              paramInt += 1;
              i1 += 1;
            }
            this.jdField_h_of_type_Boolean = false;
            localObject3 = this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter;
            paramInt = this.jdField_a_of_type_Int;
            if (localObject2 != null)
            {
              localObject1 = ((bz)localObject2).jdField_a_of_type_JavaLangObject;
              ((PagerAdapter)localObject3).setPrimaryItem(this, paramInt, localObject1);
              this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.finishUpdate(this);
              if (this.r == 0) {
                break label1701;
              }
              paramInt = 1;
              if (paramInt != 0)
              {
                if (this.jdField_b_of_type_JavaUtilArrayList != null) {
                  break label1706;
                }
                this.jdField_b_of_type_JavaUtilArrayList = new ArrayList();
              }
            }
            for (;;)
            {
              i2 = getChildCount();
              i1 = 0;
              while (i1 < i2)
              {
                localObject1 = getChildAt(i1);
                localObject2 = (ViewPager.LayoutParams)((View)localObject1).getLayoutParams();
                ((ViewPager.LayoutParams)localObject2).jdField_b_of_type_Int = i1;
                if ((!((ViewPager.LayoutParams)localObject2).isDecor) && (((ViewPager.LayoutParams)localObject2).jdField_a_of_type_Float == 0.0F))
                {
                  localObject3 = a((View)localObject1);
                  if (localObject3 != null)
                  {
                    ((ViewPager.LayoutParams)localObject2).jdField_a_of_type_Float = ((bz)localObject3).jdField_a_of_type_Float;
                    ((ViewPager.LayoutParams)localObject2).jdField_a_of_type_Int = ((bz)localObject3).jdField_a_of_type_Int;
                  }
                }
                if (paramInt != 0) {
                  this.jdField_b_of_type_JavaUtilArrayList.add(localObject1);
                }
                i1 += 1;
              }
              localObject1 = null;
              break;
              paramInt = 0;
              break label1558;
              this.jdField_b_of_type_JavaUtilArrayList.clear();
            }
            if (paramInt != 0) {
              Collections.sort(this.jdField_b_of_type_JavaUtilArrayList, jdField_a_of_type_BE);
            }
            if (!hasFocus()) {
              break;
            }
            localObject1 = findFocus();
            if (localObject1 != null) {}
            for (localObject1 = b((View)localObject1);; localObject1 = null)
            {
              if ((localObject1 != null) && (((bz)localObject1).jdField_a_of_type_Int == this.jdField_a_of_type_Int)) {
                break label1835;
              }
              paramInt = 0;
              for (;;)
              {
                if (paramInt >= getChildCount()) {
                  break label1829;
                }
                localObject1 = getChildAt(paramInt);
                localObject2 = a((View)localObject1);
                if ((localObject2 != null) && (((bz)localObject2).jdField_a_of_type_Int == this.jdField_a_of_type_Int) && (((View)localObject1).requestFocus(2))) {
                  break;
                }
                paramInt += 1;
              }
              break label30;
            }
            break label30;
            break label30;
          }
        }
        label1847:
        localObject1 = null;
      }
      localObject3 = null;
    }
  }
  
  private void b(boolean paramBoolean)
  {
    if (this.jdField_b_of_type_Boolean != paramBoolean) {
      this.jdField_b_of_type_Boolean = paramBoolean;
    }
  }
  
  private void c()
  {
    setWillNotDraw(false);
    setDescendantFocusability(262144);
    setFocusable(true);
    Context localContext = getContext();
    this.jdField_a_of_type_AndroidWidgetScroller = new Scroller(localContext, jdField_a_of_type_AndroidViewAnimationInterpolator);
    ViewConfiguration localViewConfiguration = ViewConfiguration.get(localContext);
    float f1 = localContext.getResources().getDisplayMetrics().density;
    this.k = ViewConfigurationCompat.getScaledPagingTouchSlop(localViewConfiguration);
    this.m = ((int)(400.0F * f1));
    this.n = localViewConfiguration.getScaledMaximumFlingVelocity();
    this.jdField_a_of_type_AndroidSupportV4WidgetEdgeEffectCompat = new EdgeEffectCompat(localContext);
    this.jdField_b_of_type_AndroidSupportV4WidgetEdgeEffectCompat = new EdgeEffectCompat(localContext);
    this.o = ((int)(25.0F * f1));
    this.p = ((int)(2.0F * f1));
    this.jdField_i_of_type_Int = ((int)(16.0F * f1));
    ViewCompat.setAccessibilityDelegate(this, new bA(this));
    if (ViewCompat.getImportantForAccessibility(this) == 0) {
      ViewCompat.setImportantForAccessibility(this, 1);
    }
  }
  
  private void d()
  {
    this.jdField_d_of_type_Boolean = false;
    this.jdField_e_of_type_Boolean = false;
    if (this.jdField_a_of_type_AndroidViewVelocityTracker != null)
    {
      this.jdField_a_of_type_AndroidViewVelocityTracker.recycle();
      this.jdField_a_of_type_AndroidViewVelocityTracker = null;
    }
  }
  
  final ViewPager.OnPageChangeListener a(ViewPager.OnPageChangeListener paramOnPageChangeListener)
  {
    ViewPager.OnPageChangeListener localOnPageChangeListener = this.jdField_b_of_type_AndroidSupportV4ViewViewPager$OnPageChangeListener;
    this.jdField_b_of_type_AndroidSupportV4ViewViewPager$OnPageChangeListener = paramOnPageChangeListener;
    return localOnPageChangeListener;
  }
  
  public final void a()
  {
    int i1;
    int i2;
    int i3;
    int i5;
    int i4;
    label57:
    Object localObject;
    if ((this.jdField_a_of_type_JavaUtilArrayList.size() < this.jdField_h_of_type_Int * 2 + 1) && (this.jdField_a_of_type_JavaUtilArrayList.size() < this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.getCount()))
    {
      i1 = 1;
      i2 = this.jdField_a_of_type_Int;
      i3 = 0;
      i5 = 0;
      i4 = i1;
      i1 = i2;
      i2 = i3;
      i3 = i5;
      if (i3 >= this.jdField_a_of_type_JavaUtilArrayList.size()) {
        break label273;
      }
      localObject = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(i3);
      i5 = this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.getItemPosition(((bz)localObject).jdField_a_of_type_JavaLangObject);
      if (i5 == -1) {
        break label358;
      }
      if (i5 != -2) {
        break label221;
      }
      this.jdField_a_of_type_JavaUtilArrayList.remove(i3);
      i4 = i3 - 1;
      i3 = i2;
      if (i2 == 0)
      {
        this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.startUpdate(this);
        i3 = 1;
      }
      this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.destroyItem(this, ((bz)localObject).jdField_a_of_type_Int, ((bz)localObject).jdField_a_of_type_JavaLangObject);
      if (this.jdField_a_of_type_Int != ((bz)localObject).jdField_a_of_type_Int) {
        break label379;
      }
      i2 = Math.max(0, Math.min(this.jdField_a_of_type_Int, this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.getCount() - 1));
      i1 = i3;
      i3 = 1;
    }
    for (;;)
    {
      i5 = i3;
      int i6 = i2;
      i3 = i4 + 1;
      i2 = i1;
      i1 = i6;
      i4 = i5;
      break label57;
      i1 = 0;
      break;
      label221:
      if (((bz)localObject).jdField_a_of_type_Int != i5)
      {
        if (((bz)localObject).jdField_a_of_type_Int == this.jdField_a_of_type_Int) {
          i1 = i5;
        }
        ((bz)localObject).jdField_a_of_type_Int = i5;
        i5 = i1;
        i6 = 1;
        i4 = i3;
        i1 = i2;
        i2 = i5;
        i3 = i6;
        continue;
        label273:
        if (i2 != 0) {
          this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.finishUpdate(this);
        }
        Collections.sort(this.jdField_a_of_type_JavaUtilArrayList, jdField_a_of_type_JavaUtilComparator);
        if (i4 != 0)
        {
          i3 = getChildCount();
          i2 = 0;
          while (i2 < i3)
          {
            localObject = (ViewPager.LayoutParams)getChildAt(i2).getLayoutParams();
            if (!((ViewPager.LayoutParams)localObject).isDecor) {
              ((ViewPager.LayoutParams)localObject).jdField_a_of_type_Float = 0.0F;
            }
            i2 += 1;
          }
          a(i1, false, true);
          requestLayout();
        }
      }
      else
      {
        label358:
        i5 = i1;
        i6 = i4;
        i4 = i3;
        i1 = i2;
        i2 = i5;
        i3 = i6;
        continue;
        label379:
        i2 = i1;
        i5 = 1;
        i1 = i3;
        i3 = i5;
      }
    }
  }
  
  final void a(bB parambB)
  {
    this.jdField_a_of_type_BB = parambB;
  }
  
  public void addFocusables(ArrayList paramArrayList, int paramInt1, int paramInt2)
  {
    int i2 = paramArrayList.size();
    int i3 = getDescendantFocusability();
    if (i3 != 393216)
    {
      int i1 = 0;
      while (i1 < getChildCount())
      {
        View localView = getChildAt(i1);
        if (localView.getVisibility() == 0)
        {
          bz localbz = a(localView);
          if ((localbz != null) && (localbz.jdField_a_of_type_Int == this.jdField_a_of_type_Int)) {
            localView.addFocusables(paramArrayList, paramInt1, paramInt2);
          }
        }
        i1 += 1;
      }
    }
    if (((i3 == 262144) && (i2 != paramArrayList.size())) || (!isFocusable())) {}
    while ((((paramInt2 & 0x1) == 1) && (isInTouchMode()) && (!isFocusableInTouchMode())) || (paramArrayList == null)) {
      return;
    }
    paramArrayList.add(this);
  }
  
  public void addTouchables(ArrayList paramArrayList)
  {
    int i1 = 0;
    while (i1 < getChildCount())
    {
      View localView = getChildAt(i1);
      if (localView.getVisibility() == 0)
      {
        bz localbz = a(localView);
        if ((localbz != null) && (localbz.jdField_a_of_type_Int == this.jdField_a_of_type_Int)) {
          localView.addTouchables(paramArrayList);
        }
      }
      i1 += 1;
    }
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams)
  {
    if (!checkLayoutParams(paramLayoutParams)) {
      paramLayoutParams = generateLayoutParams(paramLayoutParams);
    }
    for (;;)
    {
      ViewPager.LayoutParams localLayoutParams = (ViewPager.LayoutParams)paramLayoutParams;
      localLayoutParams.isDecor |= paramView instanceof by;
      if (this.jdField_a_of_type_Boolean)
      {
        if ((localLayoutParams != null) && (localLayoutParams.isDecor)) {
          throw new IllegalStateException("Cannot add pager decor view during layout");
        }
        localLayoutParams.jdField_a_of_type_Boolean = true;
        addViewInLayout(paramView, paramInt, paramLayoutParams);
        return;
      }
      super.addView(paramView, paramInt, paramLayoutParams);
      return;
    }
  }
  
  public boolean arrowScroll(int paramInt)
  {
    boolean bool = false;
    View localView2 = findFocus();
    View localView1 = localView2;
    if (localView2 == this) {
      localView1 = null;
    }
    localView2 = FocusFinder.getInstance().findNextFocus(this, localView1, paramInt);
    int i1;
    int i2;
    if ((localView2 != null) && (localView2 != localView1)) {
      if (paramInt == 17)
      {
        i1 = a(this.jdField_a_of_type_AndroidGraphicsRect, localView2).left;
        i2 = a(this.jdField_a_of_type_AndroidGraphicsRect, localView1).left;
        if ((localView1 != null) && (i1 >= i2)) {
          bool = a();
        }
      }
    }
    for (;;)
    {
      if (bool) {
        playSoundEffect(SoundEffectConstants.getContantForFocusDirection(paramInt));
      }
      return bool;
      bool = localView2.requestFocus();
      continue;
      if (paramInt == 66)
      {
        i1 = a(this.jdField_a_of_type_AndroidGraphicsRect, localView2).left;
        i2 = a(this.jdField_a_of_type_AndroidGraphicsRect, localView1).left;
        if ((localView1 == null) || (i1 > i2))
        {
          bool = localView2.requestFocus();
          continue;
          if ((paramInt == 17) || (paramInt == 1)) {
            bool = a();
          } else if ((paramInt != 66) && (paramInt != 2)) {}
        }
        else if ((this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter != null) && (this.jdField_a_of_type_Int < this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.getCount() - 1))
        {
          setCurrentItem(this.jdField_a_of_type_Int + 1, true);
          bool = true;
        }
        else
        {
          bool = false;
        }
      }
    }
  }
  
  public final void b()
  {
    b(this.jdField_a_of_type_Int);
  }
  
  public boolean beginFakeDrag()
  {
    if (this.jdField_d_of_type_Boolean) {
      return false;
    }
    this.jdField_f_of_type_Boolean = true;
    a(1);
    this.jdField_c_of_type_Float = 0.0F;
    this.jdField_e_of_type_Float = 0.0F;
    if (this.jdField_a_of_type_AndroidViewVelocityTracker == null) {
      this.jdField_a_of_type_AndroidViewVelocityTracker = VelocityTracker.obtain();
    }
    for (;;)
    {
      long l1 = SystemClock.uptimeMillis();
      MotionEvent localMotionEvent = MotionEvent.obtain(l1, l1, 0, 0.0F, 0.0F, 0);
      this.jdField_a_of_type_AndroidViewVelocityTracker.addMovement(localMotionEvent);
      localMotionEvent.recycle();
      this.jdField_a_of_type_Long = l1;
      return true;
      this.jdField_a_of_type_AndroidViewVelocityTracker.clear();
    }
  }
  
  protected boolean canScroll(View paramView, boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3)
  {
    int i1;
    if ((paramView instanceof ViewGroup))
    {
      ViewGroup localViewGroup = (ViewGroup)paramView;
      int i2 = paramView.getScrollX();
      int i3 = paramView.getScrollY();
      i1 = localViewGroup.getChildCount() - 1;
      if (i1 >= 0)
      {
        localView = localViewGroup.getChildAt(i1);
        if ((paramInt2 + i2 < localView.getLeft()) || (paramInt2 + i2 >= localView.getRight()) || (paramInt3 + i3 < localView.getTop()) || (paramInt3 + i3 >= localView.getBottom()) || (!canScroll(localView, true, paramInt1, paramInt2 + i2 - localView.getLeft(), paramInt3 + i3 - localView.getTop()))) {}
      }
    }
    while ((paramBoolean) && (ViewCompat.canScrollHorizontally(paramView, -paramInt1)))
    {
      View localView;
      return true;
      i1 -= 1;
      break;
    }
    return false;
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return ((paramLayoutParams instanceof ViewPager.LayoutParams)) && (super.checkLayoutParams(paramLayoutParams));
  }
  
  public void computeScroll()
  {
    if ((!this.jdField_a_of_type_AndroidWidgetScroller.isFinished()) && (this.jdField_a_of_type_AndroidWidgetScroller.computeScrollOffset()))
    {
      int i1 = getScrollX();
      int i2 = getScrollY();
      int i3 = this.jdField_a_of_type_AndroidWidgetScroller.getCurrX();
      int i4 = this.jdField_a_of_type_AndroidWidgetScroller.getCurrY();
      if ((i1 != i3) || (i2 != i4))
      {
        scrollTo(i3, i4);
        if (!a(i3))
        {
          this.jdField_a_of_type_AndroidWidgetScroller.abortAnimation();
          scrollTo(0, i4);
        }
      }
      ViewCompat.postInvalidateOnAnimation(this);
      return;
    }
    a(true);
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent)
  {
    return (super.dispatchKeyEvent(paramKeyEvent)) || (executeKeyEvent(paramKeyEvent));
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent)
  {
    boolean bool2 = false;
    int i2 = getChildCount();
    int i1 = 0;
    for (;;)
    {
      boolean bool1 = bool2;
      if (i1 < i2)
      {
        View localView = getChildAt(i1);
        if (localView.getVisibility() == 0)
        {
          bz localbz = a(localView);
          if ((localbz != null) && (localbz.jdField_a_of_type_Int == this.jdField_a_of_type_Int) && (localView.dispatchPopulateAccessibilityEvent(paramAccessibilityEvent))) {
            bool1 = true;
          }
        }
      }
      else
      {
        return bool1;
      }
      i1 += 1;
    }
  }
  
  public void draw(Canvas paramCanvas)
  {
    super.draw(paramCanvas);
    int i3 = 0;
    int i1 = 0;
    int i4 = ViewCompat.getOverScrollMode(this);
    boolean bool;
    if ((i4 == 0) || ((i4 == 1) && (this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter != null) && (this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.getCount() > 1)))
    {
      int i2;
      if (!this.jdField_a_of_type_AndroidSupportV4WidgetEdgeEffectCompat.isFinished())
      {
        i3 = paramCanvas.save();
        i1 = getHeight() - getPaddingTop() - getPaddingBottom();
        i4 = getWidth();
        paramCanvas.rotate(270.0F);
        paramCanvas.translate(-i1 + getPaddingTop(), this.jdField_a_of_type_Float * i4);
        this.jdField_a_of_type_AndroidSupportV4WidgetEdgeEffectCompat.setSize(i1, i4);
        i2 = this.jdField_a_of_type_AndroidSupportV4WidgetEdgeEffectCompat.draw(paramCanvas) | false;
        paramCanvas.restoreToCount(i3);
      }
      i3 = i2;
      if (!this.jdField_b_of_type_AndroidSupportV4WidgetEdgeEffectCompat.isFinished())
      {
        i4 = paramCanvas.save();
        i3 = getWidth();
        int i5 = getHeight();
        int i6 = getPaddingTop();
        int i7 = getPaddingBottom();
        paramCanvas.rotate(90.0F);
        paramCanvas.translate(-getPaddingTop(), -(this.jdField_b_of_type_Float + 1.0F) * i3);
        this.jdField_b_of_type_AndroidSupportV4WidgetEdgeEffectCompat.setSize(i5 - i6 - i7, i3);
        bool = i2 | this.jdField_b_of_type_AndroidSupportV4WidgetEdgeEffectCompat.draw(paramCanvas);
        paramCanvas.restoreToCount(i4);
      }
    }
    for (;;)
    {
      if (bool) {
        ViewCompat.postInvalidateOnAnimation(this);
      }
      return;
      this.jdField_a_of_type_AndroidSupportV4WidgetEdgeEffectCompat.finish();
      this.jdField_b_of_type_AndroidSupportV4WidgetEdgeEffectCompat.finish();
    }
  }
  
  protected void drawableStateChanged()
  {
    super.drawableStateChanged();
    Drawable localDrawable = this.jdField_a_of_type_AndroidGraphicsDrawableDrawable;
    if ((localDrawable != null) && (localDrawable.isStateful())) {
      localDrawable.setState(getDrawableState());
    }
  }
  
  public void endFakeDrag()
  {
    if (!this.jdField_f_of_type_Boolean) {
      throw new IllegalStateException("No fake drag in progress. Call beginFakeDrag first.");
    }
    Object localObject = this.jdField_a_of_type_AndroidViewVelocityTracker;
    ((VelocityTracker)localObject).computeCurrentVelocity(1000, this.n);
    int i1 = (int)VelocityTrackerCompat.getXVelocity((VelocityTracker)localObject, this.l);
    this.jdField_c_of_type_Boolean = true;
    int i2 = getWidth();
    int i3 = getScrollX();
    localObject = a();
    a(a(((bz)localObject).jdField_a_of_type_Int, (i3 / i2 - ((bz)localObject).jdField_b_of_type_Float) / ((bz)localObject).jdField_a_of_type_Float, i1, (int)(this.jdField_c_of_type_Float - this.jdField_e_of_type_Float)), true, true, i1);
    d();
    this.jdField_f_of_type_Boolean = false;
  }
  
  public boolean executeKeyEvent(KeyEvent paramKeyEvent)
  {
    if (paramKeyEvent.getAction() == 0) {
      switch (paramKeyEvent.getKeyCode())
      {
      }
    }
    do
    {
      do
      {
        return false;
        return arrowScroll(17);
        return arrowScroll(66);
      } while (Build.VERSION.SDK_INT < 11);
      if (KeyEventCompat.hasNoModifiers(paramKeyEvent)) {
        return arrowScroll(2);
      }
    } while (!KeyEventCompat.hasModifiers(paramKeyEvent, 1));
    return arrowScroll(1);
  }
  
  public void fakeDragBy(float paramFloat)
  {
    if (!this.jdField_f_of_type_Boolean) {
      throw new IllegalStateException("No fake drag in progress. Call beginFakeDrag first.");
    }
    this.jdField_c_of_type_Float += paramFloat;
    float f2 = getScrollX() - paramFloat;
    int i1 = getWidth();
    paramFloat = i1;
    float f4 = this.jdField_a_of_type_Float;
    float f1 = i1;
    float f3 = this.jdField_b_of_type_Float;
    Object localObject = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(0);
    bz localbz = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(this.jdField_a_of_type_JavaUtilArrayList.size() - 1);
    if (((bz)localObject).jdField_a_of_type_Int != 0) {}
    for (paramFloat = ((bz)localObject).jdField_b_of_type_Float * i1;; paramFloat *= f4)
    {
      if (localbz.jdField_a_of_type_Int != this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.getCount() - 1) {}
      for (f1 = localbz.jdField_b_of_type_Float * i1;; f1 *= f3)
      {
        if (f2 < paramFloat) {}
        for (;;)
        {
          this.jdField_c_of_type_Float += paramFloat - (int)paramFloat;
          scrollTo((int)paramFloat, getScrollY());
          a((int)paramFloat);
          long l1 = SystemClock.uptimeMillis();
          localObject = MotionEvent.obtain(this.jdField_a_of_type_Long, l1, 2, this.jdField_c_of_type_Float, 0.0F, 0);
          this.jdField_a_of_type_AndroidViewVelocityTracker.addMovement((MotionEvent)localObject);
          ((MotionEvent)localObject).recycle();
          return;
          if (f2 > f1) {
            paramFloat = f1;
          } else {
            paramFloat = f2;
          }
        }
      }
    }
  }
  
  protected ViewGroup.LayoutParams generateDefaultLayoutParams()
  {
    return new ViewPager.LayoutParams();
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet)
  {
    return new ViewPager.LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams)
  {
    return generateDefaultLayoutParams();
  }
  
  public PagerAdapter getAdapter()
  {
    return this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter;
  }
  
  protected int getChildDrawingOrder(int paramInt1, int paramInt2)
  {
    int i1 = paramInt2;
    if (this.r == 2) {
      i1 = paramInt1 - 1 - paramInt2;
    }
    return ((ViewPager.LayoutParams)((View)this.jdField_b_of_type_JavaUtilArrayList.get(i1)).getLayoutParams()).jdField_b_of_type_Int;
  }
  
  public int getCurrentItem()
  {
    return this.jdField_a_of_type_Int;
  }
  
  public int getOffscreenPageLimit()
  {
    return this.jdField_h_of_type_Int;
  }
  
  public int getPageMargin()
  {
    return this.jdField_c_of_type_Int;
  }
  
  public boolean isFakeDragging()
  {
    return this.jdField_f_of_type_Boolean;
  }
  
  protected void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    this.jdField_g_of_type_Boolean = true;
  }
  
  protected void onDetachedFromWindow()
  {
    removeCallbacks(this.jdField_a_of_type_JavaLangRunnable);
    super.onDetachedFromWindow();
  }
  
  protected void onDraw(Canvas paramCanvas)
  {
    super.onDraw(paramCanvas);
    if ((this.jdField_c_of_type_Int > 0) && (this.jdField_a_of_type_AndroidGraphicsDrawableDrawable != null) && (this.jdField_a_of_type_JavaUtilArrayList.size() > 0) && (this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter != null))
    {
      int i3 = getScrollX();
      int i4 = getWidth();
      float f3 = this.jdField_c_of_type_Int / i4;
      Object localObject = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(0);
      float f1 = ((bz)localObject).jdField_b_of_type_Float;
      int i5 = this.jdField_a_of_type_JavaUtilArrayList.size();
      int i1 = ((bz)localObject).jdField_a_of_type_Int;
      int i6 = ((bz)this.jdField_a_of_type_JavaUtilArrayList.get(i5 - 1)).jdField_a_of_type_Int;
      int i2 = 0;
      if (i1 < i6)
      {
        while ((i1 > ((bz)localObject).jdField_a_of_type_Int) && (i2 < i5))
        {
          localObject = this.jdField_a_of_type_JavaUtilArrayList;
          i2 += 1;
          localObject = (bz)((ArrayList)localObject).get(i2);
        }
        float f2;
        if (i1 == ((bz)localObject).jdField_a_of_type_Int) {
          f2 = (((bz)localObject).jdField_b_of_type_Float + ((bz)localObject).jdField_a_of_type_Float) * i4;
        }
        float f4;
        for (f1 = ((bz)localObject).jdField_b_of_type_Float + ((bz)localObject).jdField_a_of_type_Float + f3;; f1 += f4 + f3)
        {
          if (this.jdField_c_of_type_Int + f2 > i3)
          {
            this.jdField_a_of_type_AndroidGraphicsDrawableDrawable.setBounds((int)f2, this.jdField_d_of_type_Int, (int)(this.jdField_c_of_type_Int + f2 + 0.5F), this.jdField_e_of_type_Int);
            this.jdField_a_of_type_AndroidGraphicsDrawableDrawable.draw(paramCanvas);
          }
          if (f2 > i3 + i4) {
            return;
          }
          i1 += 1;
          break;
          f4 = this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.getPageWidth(i1);
          f2 = (f1 + f4) * i4;
        }
      }
    }
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent)
  {
    int i1 = paramMotionEvent.getAction() & 0xFF;
    if ((i1 == 3) || (i1 == 1))
    {
      this.jdField_d_of_type_Boolean = false;
      this.jdField_e_of_type_Boolean = false;
      this.l = -1;
      if (this.jdField_a_of_type_AndroidViewVelocityTracker != null)
      {
        this.jdField_a_of_type_AndroidViewVelocityTracker.recycle();
        this.jdField_a_of_type_AndroidViewVelocityTracker = null;
      }
    }
    do
    {
      return false;
      if (i1 == 0) {
        break;
      }
      if (this.jdField_d_of_type_Boolean) {
        return true;
      }
    } while (this.jdField_e_of_type_Boolean);
    switch (i1)
    {
    }
    for (;;)
    {
      if (this.jdField_a_of_type_AndroidViewVelocityTracker == null) {
        this.jdField_a_of_type_AndroidViewVelocityTracker = VelocityTracker.obtain();
      }
      this.jdField_a_of_type_AndroidViewVelocityTracker.addMovement(paramMotionEvent);
      return this.jdField_d_of_type_Boolean;
      i1 = this.l;
      if (i1 != -1)
      {
        i1 = MotionEventCompat.findPointerIndex(paramMotionEvent, i1);
        float f2 = MotionEventCompat.getX(paramMotionEvent, i1);
        float f1 = f2 - this.jdField_c_of_type_Float;
        float f4 = Math.abs(f1);
        float f3 = MotionEventCompat.getY(paramMotionEvent, i1);
        float f5 = Math.abs(f3 - this.jdField_f_of_type_Float);
        if (f1 != 0.0F)
        {
          float f6 = this.jdField_c_of_type_Float;
          if (((f6 < this.j) && (f1 > 0.0F)) || ((f6 > getWidth() - this.j) && (f1 < 0.0F))) {}
          for (i1 = 1; (i1 == 0) && (canScroll(this, false, (int)f1, (int)f2, (int)f3)); i1 = 0)
          {
            this.jdField_c_of_type_Float = f2;
            this.jdField_d_of_type_Float = f3;
            this.jdField_e_of_type_Boolean = true;
            return false;
          }
        }
        if ((f4 > this.k) && (0.5F * f4 > f5))
        {
          this.jdField_d_of_type_Boolean = true;
          a(1);
          if (f1 > 0.0F)
          {
            f1 = this.jdField_e_of_type_Float + this.k;
            label352:
            this.jdField_c_of_type_Float = f1;
            this.jdField_d_of_type_Float = f3;
            b(true);
          }
        }
        while ((this.jdField_d_of_type_Boolean) && (a(f2)))
        {
          ViewCompat.postInvalidateOnAnimation(this);
          break;
          f1 = this.jdField_e_of_type_Float - this.k;
          break label352;
          if (f5 > this.k) {
            this.jdField_e_of_type_Boolean = true;
          }
        }
        f1 = paramMotionEvent.getX();
        this.jdField_e_of_type_Float = f1;
        this.jdField_c_of_type_Float = f1;
        f1 = paramMotionEvent.getY();
        this.jdField_f_of_type_Float = f1;
        this.jdField_d_of_type_Float = f1;
        this.l = MotionEventCompat.getPointerId(paramMotionEvent, 0);
        this.jdField_e_of_type_Boolean = false;
        this.jdField_a_of_type_AndroidWidgetScroller.computeScrollOffset();
        if ((this.s == 2) && (Math.abs(this.jdField_a_of_type_AndroidWidgetScroller.getFinalX() - this.jdField_a_of_type_AndroidWidgetScroller.getCurrX()) > this.p))
        {
          this.jdField_a_of_type_AndroidWidgetScroller.abortAnimation();
          this.jdField_c_of_type_Boolean = false;
          b();
          this.jdField_d_of_type_Boolean = true;
          a(1);
        }
        else
        {
          a(false);
          this.jdField_d_of_type_Boolean = false;
          continue;
          a(paramMotionEvent);
        }
      }
    }
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    this.jdField_a_of_type_Boolean = true;
    b();
    this.jdField_a_of_type_Boolean = false;
    int i6 = getChildCount();
    int i7 = paramInt3 - paramInt1;
    int i8 = paramInt4 - paramInt2;
    paramInt2 = getPaddingLeft();
    paramInt1 = getPaddingTop();
    paramInt4 = getPaddingRight();
    paramInt3 = getPaddingBottom();
    int i9 = getScrollX();
    int i2 = 0;
    int i4 = 0;
    View localView;
    ViewPager.LayoutParams localLayoutParams;
    int i1;
    int i10;
    int i3;
    label170:
    int i5;
    if (i4 < i6)
    {
      localView = getChildAt(i4);
      if (localView.getVisibility() == 8) {
        break label657;
      }
      localLayoutParams = (ViewPager.LayoutParams)localView.getLayoutParams();
      if (!localLayoutParams.isDecor) {
        break label657;
      }
      i1 = localLayoutParams.gravity;
      i10 = localLayoutParams.gravity;
      switch (i1 & 0x7)
      {
      case 2: 
      case 4: 
      default: 
        i1 = paramInt2;
        i3 = paramInt2;
        switch (i10 & 0x70)
        {
        default: 
          i5 = paramInt1;
          paramInt2 = paramInt1;
          paramInt1 = paramInt3;
          paramInt3 = i5;
          label220:
          i1 += i9;
          localView.layout(i1, paramInt3, localView.getMeasuredWidth() + i1, localView.getMeasuredHeight() + paramInt3);
          i2 += 1;
          paramInt3 = i3;
          i1 = paramInt1;
          paramInt1 = i2;
        }
        break;
      }
    }
    for (;;)
    {
      i4 += 1;
      i3 = paramInt3;
      i2 = paramInt1;
      paramInt1 = paramInt2;
      paramInt3 = i1;
      paramInt2 = i3;
      break;
      i3 = localView.getMeasuredWidth();
      i1 = paramInt2;
      i3 += paramInt2;
      break label170;
      i1 = Math.max((i7 - localView.getMeasuredWidth()) / 2, paramInt2);
      i3 = paramInt2;
      break label170;
      i3 = localView.getMeasuredWidth();
      i1 = paramInt4 + localView.getMeasuredWidth();
      i5 = i7 - paramInt4 - i3;
      paramInt4 = i1;
      i3 = paramInt2;
      i1 = i5;
      break label170;
      i5 = localView.getMeasuredHeight();
      paramInt2 = paramInt3;
      i5 += paramInt1;
      paramInt3 = paramInt1;
      paramInt1 = paramInt2;
      paramInt2 = i5;
      break label220;
      i5 = Math.max((i8 - localView.getMeasuredHeight()) / 2, paramInt1);
      paramInt2 = paramInt1;
      paramInt1 = paramInt3;
      paramInt3 = i5;
      break label220;
      i5 = i8 - paramInt3 - localView.getMeasuredHeight();
      i10 = localView.getMeasuredHeight();
      paramInt2 = paramInt1;
      paramInt1 = paramInt3 + i10;
      paramInt3 = i5;
      break label220;
      i1 = 0;
      while (i1 < i6)
      {
        localView = getChildAt(i1);
        if (localView.getVisibility() != 8)
        {
          localLayoutParams = (ViewPager.LayoutParams)localView.getLayoutParams();
          if (!localLayoutParams.isDecor)
          {
            bz localbz = a(localView);
            if (localbz != null)
            {
              float f1 = i7;
              i3 = (int)(localbz.jdField_b_of_type_Float * f1) + paramInt2;
              if (localLayoutParams.jdField_a_of_type_Boolean)
              {
                localLayoutParams.jdField_a_of_type_Boolean = false;
                f1 = i7 - paramInt2 - paramInt4;
                localView.measure(View.MeasureSpec.makeMeasureSpec((int)(localLayoutParams.jdField_a_of_type_Float * f1), 1073741824), View.MeasureSpec.makeMeasureSpec(i8 - paramInt1 - paramInt3, 1073741824));
              }
              localView.layout(i3, paramInt1, localView.getMeasuredWidth() + i3, localView.getMeasuredHeight() + paramInt1);
            }
          }
        }
        i1 += 1;
      }
      this.jdField_d_of_type_Int = paramInt1;
      this.jdField_e_of_type_Int = (i8 - paramInt3);
      this.q = i2;
      this.jdField_g_of_type_Boolean = false;
      return;
      label657:
      i1 = i2;
      i2 = paramInt1;
      i3 = paramInt2;
      paramInt1 = i1;
      i1 = paramInt3;
      paramInt2 = i2;
      paramInt3 = i3;
    }
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    setMeasuredDimension(getDefaultSize(0, paramInt1), getDefaultSize(0, paramInt2));
    paramInt1 = getMeasuredWidth();
    this.j = Math.min(paramInt1 / 10, this.jdField_i_of_type_Int);
    paramInt1 = paramInt1 - getPaddingLeft() - getPaddingRight();
    paramInt2 = getMeasuredHeight() - getPaddingTop() - getPaddingBottom();
    int i9 = getChildCount();
    int i3 = 0;
    View localView;
    int i1;
    int i2;
    ViewPager.LayoutParams localLayoutParams;
    int i4;
    int i6;
    label183:
    int i5;
    if (i3 < i9)
    {
      localView = getChildAt(i3);
      i1 = paramInt1;
      i2 = paramInt2;
      if (localView.getVisibility() != 8)
      {
        localLayoutParams = (ViewPager.LayoutParams)localView.getLayoutParams();
        i1 = paramInt1;
        i2 = paramInt2;
        if (localLayoutParams != null)
        {
          i1 = paramInt1;
          i2 = paramInt2;
          if (localLayoutParams.isDecor)
          {
            i1 = localLayoutParams.gravity & 0x7;
            i4 = localLayoutParams.gravity & 0x70;
            i6 = Integer.MIN_VALUE;
            i2 = Integer.MIN_VALUE;
            if ((i4 != 48) && (i4 != 80)) {
              break label333;
            }
            i4 = 1;
            if ((i1 != 3) && (i1 != 5)) {
              break label339;
            }
            i5 = 1;
            label198:
            if (i4 == 0) {
              break label345;
            }
            i1 = 1073741824;
            label208:
            if (localLayoutParams.width == -2) {
              break label528;
            }
            i6 = 1073741824;
            if (localLayoutParams.width == -1) {
              break label522;
            }
            i1 = localLayoutParams.width;
          }
        }
      }
    }
    for (;;)
    {
      int i8;
      if (localLayoutParams.height != -2)
      {
        i7 = 1073741824;
        i2 = i7;
        if (localLayoutParams.height != -1)
        {
          i8 = localLayoutParams.height;
          i2 = i7;
        }
      }
      for (int i7 = i8;; i7 = paramInt2)
      {
        localView.measure(View.MeasureSpec.makeMeasureSpec(i1, i6), View.MeasureSpec.makeMeasureSpec(i7, i2));
        if (i4 != 0)
        {
          i2 = paramInt2 - localView.getMeasuredHeight();
          i1 = paramInt1;
        }
        for (;;)
        {
          i3 += 1;
          paramInt1 = i1;
          paramInt2 = i2;
          break;
          label333:
          i4 = 0;
          break label183;
          label339:
          i5 = 0;
          break label198;
          label345:
          i1 = i6;
          if (i5 == 0) {
            break label208;
          }
          i2 = 1073741824;
          i1 = i6;
          break label208;
          i1 = paramInt1;
          i2 = paramInt2;
          if (i5 != 0)
          {
            i1 = paramInt1 - localView.getMeasuredWidth();
            i2 = paramInt2;
          }
        }
        this.jdField_f_of_type_Int = View.MeasureSpec.makeMeasureSpec(paramInt1, 1073741824);
        this.jdField_g_of_type_Int = View.MeasureSpec.makeMeasureSpec(paramInt2, 1073741824);
        this.jdField_a_of_type_Boolean = true;
        b();
        this.jdField_a_of_type_Boolean = false;
        i1 = getChildCount();
        paramInt2 = 0;
        while (paramInt2 < i1)
        {
          localView = getChildAt(paramInt2);
          if (localView.getVisibility() != 8)
          {
            localLayoutParams = (ViewPager.LayoutParams)localView.getLayoutParams();
            if ((localLayoutParams == null) || (!localLayoutParams.isDecor))
            {
              float f1 = paramInt1;
              localView.measure(View.MeasureSpec.makeMeasureSpec((int)(localLayoutParams.jdField_a_of_type_Float * f1), 1073741824), this.jdField_g_of_type_Int);
            }
          }
          paramInt2 += 1;
        }
        return;
      }
      label522:
      i1 = paramInt1;
      continue;
      label528:
      i6 = i1;
      i1 = paramInt1;
    }
  }
  
  protected void onPageScrolled(int paramInt1, float paramFloat, int paramInt2)
  {
    int i1;
    int i2;
    int i7;
    int i5;
    View localView;
    int i3;
    int i4;
    label132:
    int i9;
    if (this.q > 0)
    {
      int i6 = getScrollX();
      i1 = getPaddingLeft();
      i2 = getPaddingRight();
      i7 = getWidth();
      int i8 = getChildCount();
      i5 = 0;
      if (i5 < i8)
      {
        localView = getChildAt(i5);
        ViewPager.LayoutParams localLayoutParams = (ViewPager.LayoutParams)localView.getLayoutParams();
        if (!localLayoutParams.isDecor) {
          break label414;
        }
        switch (localLayoutParams.gravity & 0x7)
        {
        case 2: 
        case 4: 
        default: 
          i3 = i1;
          i4 = i2;
          i2 = i1;
          i1 = i4;
          i9 = i3 + i6 - localView.getLeft();
          i3 = i1;
          i4 = i2;
          if (i9 != 0)
          {
            localView.offsetLeftAndRight(i9);
            i4 = i2;
            i3 = i1;
          }
          break;
        }
      }
    }
    for (;;)
    {
      i5 += 1;
      i1 = i4;
      i2 = i3;
      break;
      i3 = localView.getWidth();
      i4 = i3 + i1;
      i3 = i1;
      i1 = i2;
      i2 = i4;
      break label132;
      i3 = Math.max((i7 - localView.getMeasuredWidth()) / 2, i1);
      i4 = i1;
      i1 = i2;
      i2 = i4;
      break label132;
      i3 = i7 - i2 - localView.getMeasuredWidth();
      i9 = localView.getMeasuredWidth();
      i4 = i1;
      i1 = i2 + i9;
      i2 = i4;
      break label132;
      if (this.jdField_a_of_type_AndroidSupportV4ViewViewPager$OnPageChangeListener != null) {
        this.jdField_a_of_type_AndroidSupportV4ViewViewPager$OnPageChangeListener.onPageScrolled(paramInt1, paramFloat, paramInt2);
      }
      if (this.jdField_b_of_type_AndroidSupportV4ViewViewPager$OnPageChangeListener != null) {
        this.jdField_b_of_type_AndroidSupportV4ViewViewPager$OnPageChangeListener.onPageScrolled(paramInt1, paramFloat, paramInt2);
      }
      if (this.jdField_a_of_type_AndroidSupportV4ViewViewPager$PageTransformer != null)
      {
        paramInt2 = getScrollX();
        i1 = getChildCount();
        paramInt1 = 0;
        while (paramInt1 < i1)
        {
          localView = getChildAt(paramInt1);
          if (!((ViewPager.LayoutParams)localView.getLayoutParams()).isDecor)
          {
            paramFloat = (localView.getLeft() - paramInt2) / getWidth();
            this.jdField_a_of_type_AndroidSupportV4ViewViewPager$PageTransformer.transformPage(localView, paramFloat);
          }
          paramInt1 += 1;
        }
      }
      this.jdField_i_of_type_Boolean = true;
      return;
      label414:
      i3 = i2;
      i4 = i1;
    }
  }
  
  protected boolean onRequestFocusInDescendants(int paramInt, Rect paramRect)
  {
    int i3 = -1;
    int i2 = getChildCount();
    int i1;
    if ((paramInt & 0x2) != 0)
    {
      i3 = 1;
      i1 = 0;
    }
    while (i1 != i2)
    {
      View localView = getChildAt(i1);
      if (localView.getVisibility() == 0)
      {
        bz localbz = a(localView);
        if ((localbz != null) && (localbz.jdField_a_of_type_Int == this.jdField_a_of_type_Int) && (localView.requestFocus(paramInt, paramRect)))
        {
          return true;
          i1 = i2 - 1;
          i2 = -1;
          continue;
        }
      }
      i1 += i3;
    }
    return false;
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable)
  {
    if (!(paramParcelable instanceof ViewPager.SavedState))
    {
      super.onRestoreInstanceState(paramParcelable);
      return;
    }
    paramParcelable = (ViewPager.SavedState)paramParcelable;
    super.onRestoreInstanceState(paramParcelable.getSuperState());
    if (this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter != null)
    {
      this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.restoreState(paramParcelable.jdField_a_of_type_AndroidOsParcelable, paramParcelable.jdField_a_of_type_JavaLangClassLoader);
      a(paramParcelable.jdField_a_of_type_Int, false, true);
      return;
    }
    this.jdField_b_of_type_Int = paramParcelable.jdField_a_of_type_Int;
    this.jdField_a_of_type_AndroidOsParcelable = paramParcelable.jdField_a_of_type_AndroidOsParcelable;
    this.jdField_a_of_type_JavaLangClassLoader = paramParcelable.jdField_a_of_type_JavaLangClassLoader;
  }
  
  public Parcelable onSaveInstanceState()
  {
    ViewPager.SavedState localSavedState = new ViewPager.SavedState(super.onSaveInstanceState());
    localSavedState.jdField_a_of_type_Int = this.jdField_a_of_type_Int;
    if (this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter != null) {
      localSavedState.jdField_a_of_type_AndroidOsParcelable = this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.saveState();
    }
    return localSavedState;
  }
  
  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramInt1 != paramInt3) {
      a(paramInt1, paramInt3, this.jdField_c_of_type_Int, this.jdField_c_of_type_Int);
    }
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent)
  {
    int i4 = 0;
    if (this.jdField_f_of_type_Boolean) {
      return true;
    }
    if ((paramMotionEvent.getAction() == 0) && (paramMotionEvent.getEdgeFlags() != 0)) {
      return false;
    }
    if ((this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter == null) || (this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.getCount() == 0)) {
      return false;
    }
    if (this.jdField_a_of_type_AndroidViewVelocityTracker == null) {
      this.jdField_a_of_type_AndroidViewVelocityTracker = VelocityTracker.obtain();
    }
    this.jdField_a_of_type_AndroidViewVelocityTracker.addMovement(paramMotionEvent);
    int i1 = i4;
    switch (paramMotionEvent.getAction() & 0xFF)
    {
    default: 
      i1 = i4;
    }
    for (;;)
    {
      if (i1 != 0) {
        ViewCompat.postInvalidateOnAnimation(this);
      }
      return true;
      this.jdField_a_of_type_AndroidWidgetScroller.abortAnimation();
      this.jdField_c_of_type_Boolean = false;
      b();
      this.jdField_d_of_type_Boolean = true;
      a(1);
      float f1 = paramMotionEvent.getX();
      this.jdField_e_of_type_Float = f1;
      this.jdField_c_of_type_Float = f1;
      f1 = paramMotionEvent.getY();
      this.jdField_f_of_type_Float = f1;
      this.jdField_d_of_type_Float = f1;
      this.l = MotionEventCompat.getPointerId(paramMotionEvent, 0);
      i1 = i4;
      continue;
      float f2;
      if (!this.jdField_d_of_type_Boolean)
      {
        i1 = MotionEventCompat.findPointerIndex(paramMotionEvent, this.l);
        f1 = MotionEventCompat.getX(paramMotionEvent, i1);
        float f3 = Math.abs(f1 - this.jdField_c_of_type_Float);
        f2 = MotionEventCompat.getY(paramMotionEvent, i1);
        float f4 = Math.abs(f2 - this.jdField_d_of_type_Float);
        if ((f3 > this.k) && (f3 > f4))
        {
          this.jdField_d_of_type_Boolean = true;
          if (f1 - this.jdField_e_of_type_Float <= 0.0F) {
            break label364;
          }
        }
      }
      label364:
      for (f1 = this.jdField_e_of_type_Float + this.k;; f1 = this.jdField_e_of_type_Float - this.k)
      {
        this.jdField_c_of_type_Float = f1;
        this.jdField_d_of_type_Float = f2;
        a(1);
        b(true);
        i1 = i4;
        if (!this.jdField_d_of_type_Boolean) {
          break;
        }
        bool1 = a(MotionEventCompat.getX(paramMotionEvent, MotionEventCompat.findPointerIndex(paramMotionEvent, this.l))) | false;
        break;
      }
      boolean bool1 = i4;
      if (this.jdField_d_of_type_Boolean)
      {
        Object localObject = this.jdField_a_of_type_AndroidViewVelocityTracker;
        ((VelocityTracker)localObject).computeCurrentVelocity(1000, this.n);
        int i2 = (int)VelocityTrackerCompat.getXVelocity((VelocityTracker)localObject, this.l);
        this.jdField_c_of_type_Boolean = true;
        i4 = getWidth();
        int i5 = getScrollX();
        localObject = a();
        a(a(((bz)localObject).jdField_a_of_type_Int, (i5 / i4 - ((bz)localObject).jdField_b_of_type_Float) / ((bz)localObject).jdField_a_of_type_Float, i2, (int)(MotionEventCompat.getX(paramMotionEvent, MotionEventCompat.findPointerIndex(paramMotionEvent, this.l)) - this.jdField_e_of_type_Float)), true, true, i2);
        this.l = -1;
        d();
        boolean bool3 = this.jdField_a_of_type_AndroidSupportV4WidgetEdgeEffectCompat.onRelease();
        boolean bool2 = this.jdField_b_of_type_AndroidSupportV4WidgetEdgeEffectCompat.onRelease() | bool3;
        continue;
        bool2 = i4;
        if (this.jdField_d_of_type_Boolean)
        {
          a(this.jdField_a_of_type_Int, true, 0, false);
          this.l = -1;
          d();
          bool3 = this.jdField_a_of_type_AndroidSupportV4WidgetEdgeEffectCompat.onRelease();
          bool2 = this.jdField_b_of_type_AndroidSupportV4WidgetEdgeEffectCompat.onRelease() | bool3;
          continue;
          int i3 = MotionEventCompat.getActionIndex(paramMotionEvent);
          this.jdField_c_of_type_Float = MotionEventCompat.getX(paramMotionEvent, i3);
          this.l = MotionEventCompat.getPointerId(paramMotionEvent, i3);
          i3 = i4;
          continue;
          a(paramMotionEvent);
          this.jdField_c_of_type_Float = MotionEventCompat.getX(paramMotionEvent, MotionEventCompat.findPointerIndex(paramMotionEvent, this.l));
          i3 = i4;
        }
      }
    }
  }
  
  public void removeView(View paramView)
  {
    if (this.jdField_a_of_type_Boolean)
    {
      removeViewInLayout(paramView);
      return;
    }
    super.removeView(paramView);
  }
  
  public void setAdapter(PagerAdapter paramPagerAdapter)
  {
    if (this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter != null)
    {
      this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.b(this.jdField_a_of_type_BC);
      this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.startUpdate(this);
      int i1 = 0;
      while (i1 < this.jdField_a_of_type_JavaUtilArrayList.size())
      {
        localObject = (bz)this.jdField_a_of_type_JavaUtilArrayList.get(i1);
        this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.destroyItem(this, ((bz)localObject).jdField_a_of_type_Int, ((bz)localObject).jdField_a_of_type_JavaLangObject);
        i1 += 1;
      }
      this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.finishUpdate(this);
      this.jdField_a_of_type_JavaUtilArrayList.clear();
      int i2;
      for (i1 = 0; i1 < getChildCount(); i1 = i2 + 1)
      {
        i2 = i1;
        if (!((ViewPager.LayoutParams)getChildAt(i1).getLayoutParams()).isDecor)
        {
          removeViewAt(i1);
          i2 = i1 - 1;
        }
      }
      this.jdField_a_of_type_Int = 0;
      scrollTo(0, 0);
    }
    Object localObject = this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter;
    this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter = paramPagerAdapter;
    if (this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter != null)
    {
      if (this.jdField_a_of_type_BC == null) {
        this.jdField_a_of_type_BC = new bC(this, (byte)0);
      }
      this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.a(this.jdField_a_of_type_BC);
      this.jdField_c_of_type_Boolean = false;
      this.jdField_g_of_type_Boolean = true;
      if (this.jdField_b_of_type_Int < 0) {
        break label280;
      }
      this.jdField_a_of_type_AndroidSupportV4ViewPagerAdapter.restoreState(this.jdField_a_of_type_AndroidOsParcelable, this.jdField_a_of_type_JavaLangClassLoader);
      a(this.jdField_b_of_type_Int, false, true);
      this.jdField_b_of_type_Int = -1;
      this.jdField_a_of_type_AndroidOsParcelable = null;
      this.jdField_a_of_type_JavaLangClassLoader = null;
    }
    for (;;)
    {
      if ((this.jdField_a_of_type_BB != null) && (localObject != paramPagerAdapter)) {
        this.jdField_a_of_type_BB.a((PagerAdapter)localObject, paramPagerAdapter);
      }
      return;
      label280:
      b();
    }
  }
  
  public void setCurrentItem(int paramInt)
  {
    this.jdField_c_of_type_Boolean = false;
    if (!this.jdField_g_of_type_Boolean) {}
    for (boolean bool = true;; bool = false)
    {
      a(paramInt, bool, false);
      return;
    }
  }
  
  public void setCurrentItem(int paramInt, boolean paramBoolean)
  {
    this.jdField_c_of_type_Boolean = false;
    a(paramInt, paramBoolean, false);
  }
  
  public void setOffscreenPageLimit(int paramInt)
  {
    int i1 = paramInt;
    if (paramInt <= 0)
    {
      new StringBuilder("Requested offscreen page limit ").append(paramInt).append(" too small; defaulting to 1").toString();
      i1 = 1;
    }
    if (i1 != this.jdField_h_of_type_Int)
    {
      this.jdField_h_of_type_Int = i1;
      b();
    }
  }
  
  public void setOnPageChangeListener(ViewPager.OnPageChangeListener paramOnPageChangeListener)
  {
    this.jdField_a_of_type_AndroidSupportV4ViewViewPager$OnPageChangeListener = paramOnPageChangeListener;
  }
  
  public void setPageMargin(int paramInt)
  {
    int i1 = this.jdField_c_of_type_Int;
    this.jdField_c_of_type_Int = paramInt;
    int i2 = getWidth();
    a(i2, i2, paramInt, i1);
    requestLayout();
  }
  
  public void setPageMarginDrawable(int paramInt)
  {
    setPageMarginDrawable(getContext().getResources().getDrawable(paramInt));
  }
  
  public void setPageMarginDrawable(Drawable paramDrawable)
  {
    this.jdField_a_of_type_AndroidGraphicsDrawableDrawable = paramDrawable;
    if (paramDrawable != null) {
      refreshDrawableState();
    }
    if (paramDrawable == null) {}
    for (boolean bool = true;; bool = false)
    {
      setWillNotDraw(bool);
      invalidate();
      return;
    }
  }
  
  public void setPageTransformer(boolean paramBoolean, ViewPager.PageTransformer paramPageTransformer)
  {
    int i2 = 1;
    boolean bool1;
    if (Build.VERSION.SDK_INT >= 11)
    {
      if (paramPageTransformer == null) {
        break label119;
      }
      bool1 = true;
    }
    for (;;)
    {
      boolean bool2;
      label28:
      int i1;
      if (this.jdField_a_of_type_AndroidSupportV4ViewViewPager$PageTransformer != null)
      {
        bool2 = true;
        if (bool1 == bool2) {
          break label131;
        }
        i1 = 1;
        label37:
        this.jdField_a_of_type_AndroidSupportV4ViewViewPager$PageTransformer = paramPageTransformer;
        if (this.jdField_a_of_type_JavaLangReflectMethod != null) {}
      }
      try
      {
        this.jdField_a_of_type_JavaLangReflectMethod = ViewGroup.class.getDeclaredMethod("setChildrenDrawingOrderEnabled", new Class[] { Boolean.TYPE });
        try
        {
          this.jdField_a_of_type_JavaLangReflectMethod.invoke(this, new Object[] { Boolean.valueOf(bool1) });
          if (bool1) {
            if (paramBoolean) {
              i2 = 2;
            }
          }
          for (this.r = i2;; this.r = 0)
          {
            if (i1 != 0) {
              b();
            }
            return;
            label119:
            bool1 = false;
            break;
            bool2 = false;
            break label28;
            label131:
            i1 = 0;
            break label37;
          }
        }
        catch (Exception paramPageTransformer)
        {
          for (;;) {}
        }
      }
      catch (NoSuchMethodException paramPageTransformer)
      {
        for (;;) {}
      }
    }
  }
  
  protected boolean verifyDrawable(Drawable paramDrawable)
  {
    return (super.verifyDrawable(paramDrawable)) || (paramDrawable == this.jdField_a_of_type_AndroidGraphicsDrawableDrawable);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/view/ViewPager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */