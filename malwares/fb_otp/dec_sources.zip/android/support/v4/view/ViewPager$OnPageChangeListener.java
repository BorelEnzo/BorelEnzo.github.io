package android.support.v4.view;

public abstract interface ViewPager$OnPageChangeListener
{
  public abstract void onPageScrollStateChanged(int paramInt);
  
  public abstract void onPageScrolled(int paramInt1, float paramFloat, int paramInt2);
  
  public abstract void onPageSelected(int paramInt);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/view/ViewPager$OnPageChangeListener.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */