package android.support.v4.view;

import aZ;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.text.TextUtils.TruncateAt;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.widget.TextView;
import ba;
import bb;
import bc;
import by;
import java.lang.ref.WeakReference;

public class PagerTitleStrip
  extends ViewGroup
  implements by
{
  private static final ba jdField_a_of_type_Ba = new bb();
  private static final int[] jdField_a_of_type_ArrayOfInt = { 16842804, 16842901, 16842904, 16842927 };
  private static final int[] jdField_b_of_type_ArrayOfInt = { 16843660 };
  private float jdField_a_of_type_Float = -1.0F;
  int jdField_a_of_type_Int;
  private final aZ jdField_a_of_type_AZ = new aZ(this, (byte)0);
  public ViewPager a;
  TextView jdField_a_of_type_AndroidWidgetTextView;
  private WeakReference jdField_a_of_type_JavaLangRefWeakReference;
  private boolean jdField_a_of_type_Boolean;
  private int jdField_b_of_type_Int = -1;
  TextView jdField_b_of_type_AndroidWidgetTextView;
  private boolean jdField_b_of_type_Boolean;
  private int jdField_c_of_type_Int;
  TextView jdField_c_of_type_AndroidWidgetTextView;
  private int d;
  private int e;
  
  static
  {
    if (Build.VERSION.SDK_INT >= 14)
    {
      jdField_a_of_type_Ba = new bc();
      return;
    }
  }
  
  public PagerTitleStrip(Context paramContext)
  {
    this(paramContext, null);
  }
  
  public PagerTitleStrip(Context paramContext, AttributeSet paramAttributeSet)
  {
    super(paramContext, paramAttributeSet);
    TextView localTextView = new TextView(paramContext);
    this.jdField_a_of_type_AndroidWidgetTextView = localTextView;
    addView(localTextView);
    localTextView = new TextView(paramContext);
    this.jdField_b_of_type_AndroidWidgetTextView = localTextView;
    addView(localTextView);
    localTextView = new TextView(paramContext);
    this.jdField_c_of_type_AndroidWidgetTextView = localTextView;
    addView(localTextView);
    paramAttributeSet = paramContext.obtainStyledAttributes(paramAttributeSet, jdField_a_of_type_ArrayOfInt);
    int i = paramAttributeSet.getResourceId(0, 0);
    if (i != 0)
    {
      this.jdField_a_of_type_AndroidWidgetTextView.setTextAppearance(paramContext, i);
      this.jdField_b_of_type_AndroidWidgetTextView.setTextAppearance(paramContext, i);
      this.jdField_c_of_type_AndroidWidgetTextView.setTextAppearance(paramContext, i);
    }
    int j = paramAttributeSet.getDimensionPixelSize(1, 0);
    if (j != 0) {
      setTextSize(0, j);
    }
    if (paramAttributeSet.hasValue(2))
    {
      j = paramAttributeSet.getColor(2, 0);
      this.jdField_a_of_type_AndroidWidgetTextView.setTextColor(j);
      this.jdField_b_of_type_AndroidWidgetTextView.setTextColor(j);
      this.jdField_c_of_type_AndroidWidgetTextView.setTextColor(j);
    }
    this.d = paramAttributeSet.getInteger(3, 80);
    paramAttributeSet.recycle();
    this.jdField_a_of_type_Int = this.jdField_b_of_type_AndroidWidgetTextView.getTextColors().getDefaultColor();
    setNonPrimaryAlpha(0.6F);
    this.jdField_a_of_type_AndroidWidgetTextView.setEllipsize(TextUtils.TruncateAt.END);
    this.jdField_b_of_type_AndroidWidgetTextView.setEllipsize(TextUtils.TruncateAt.END);
    this.jdField_c_of_type_AndroidWidgetTextView.setEllipsize(TextUtils.TruncateAt.END);
    if (i != 0)
    {
      paramAttributeSet = paramContext.obtainStyledAttributes(i, jdField_b_of_type_ArrayOfInt);
      bool = paramAttributeSet.getBoolean(0, false);
      paramAttributeSet.recycle();
    }
    if (bool)
    {
      a(this.jdField_a_of_type_AndroidWidgetTextView);
      a(this.jdField_b_of_type_AndroidWidgetTextView);
      a(this.jdField_c_of_type_AndroidWidgetTextView);
    }
    for (;;)
    {
      this.jdField_c_of_type_Int = ((int)(paramContext.getResources().getDisplayMetrics().density * 16.0F));
      return;
      this.jdField_a_of_type_AndroidWidgetTextView.setSingleLine();
      this.jdField_b_of_type_AndroidWidgetTextView.setSingleLine();
      this.jdField_c_of_type_AndroidWidgetTextView.setSingleLine();
    }
  }
  
  private static void a(TextView paramTextView)
  {
    jdField_a_of_type_Ba.a(paramTextView);
  }
  
  int a()
  {
    int i = 0;
    Drawable localDrawable = getBackground();
    if (localDrawable != null) {
      i = localDrawable.getIntrinsicHeight();
    }
    return i;
  }
  
  public void a(int paramInt, float paramFloat, boolean paramBoolean)
  {
    int m;
    int i4;
    int k;
    int i3;
    int n;
    int i;
    int i2;
    int i1;
    int j;
    int i5;
    int i7;
    int i6;
    int i8;
    if (paramInt != this.jdField_b_of_type_Int)
    {
      a(paramInt, this.jdField_a_of_type_AndroidSupportV4ViewViewPager.getAdapter());
      this.jdField_b_of_type_Boolean = true;
      m = this.jdField_a_of_type_AndroidWidgetTextView.getMeasuredWidth();
      i4 = this.jdField_b_of_type_AndroidWidgetTextView.getMeasuredWidth();
      k = this.jdField_c_of_type_AndroidWidgetTextView.getMeasuredWidth();
      i3 = i4 / 2;
      n = getWidth();
      i = getHeight();
      i2 = getPaddingLeft();
      i1 = getPaddingRight();
      paramInt = getPaddingTop();
      j = getPaddingBottom();
      i5 = i1 + i3;
      float f2 = 0.5F + paramFloat;
      float f1 = f2;
      if (f2 > 1.0F) {
        f1 = f2 - 1.0F;
      }
      i3 = n - i5 - (int)(f1 * (n - (i2 + i3) - i5)) - i3;
      i4 = i3 + i4;
      i7 = this.jdField_a_of_type_AndroidWidgetTextView.getBaseline();
      i6 = this.jdField_b_of_type_AndroidWidgetTextView.getBaseline();
      i5 = this.jdField_c_of_type_AndroidWidgetTextView.getBaseline();
      i8 = Math.max(Math.max(i7, i6), i5);
      i7 = i8 - i7;
      i6 = i8 - i6;
      i5 = i8 - i5;
      i8 = this.jdField_a_of_type_AndroidWidgetTextView.getMeasuredHeight();
      int i9 = this.jdField_b_of_type_AndroidWidgetTextView.getMeasuredHeight();
      int i10 = this.jdField_c_of_type_AndroidWidgetTextView.getMeasuredHeight();
      i8 = Math.max(Math.max(i8 + i7, i9 + i6), i10 + i5);
      switch (this.d & 0x70)
      {
      default: 
        j = paramInt + i7;
        i = paramInt + i6;
        paramInt += i5;
      }
    }
    for (;;)
    {
      this.jdField_b_of_type_AndroidWidgetTextView.layout(i3, i, i4, this.jdField_b_of_type_AndroidWidgetTextView.getMeasuredHeight() + i);
      i = Math.min(i2, i3 - this.jdField_c_of_type_Int - m);
      this.jdField_a_of_type_AndroidWidgetTextView.layout(i, j, m + i, this.jdField_a_of_type_AndroidWidgetTextView.getMeasuredHeight() + j);
      i = Math.max(n - i1 - k, this.jdField_c_of_type_Int + i4);
      this.jdField_c_of_type_AndroidWidgetTextView.layout(i, paramInt, i + k, this.jdField_c_of_type_AndroidWidgetTextView.getMeasuredHeight() + paramInt);
      this.jdField_a_of_type_Float = paramFloat;
      this.jdField_b_of_type_Boolean = false;
      return;
      if ((paramBoolean) || (paramFloat != this.jdField_a_of_type_Float)) {
        break;
      }
      return;
      paramInt = (i - paramInt - j - i8) / 2;
      j = paramInt + i7;
      i = paramInt + i6;
      paramInt += i5;
      continue;
      paramInt = i - j - i8;
      j = paramInt + i7;
      i = paramInt + i6;
      paramInt += i5;
    }
  }
  
  public final void a(int paramInt, PagerAdapter paramPagerAdapter)
  {
    Object localObject2 = null;
    int i;
    if (paramPagerAdapter != null)
    {
      i = paramPagerAdapter.getCount();
      this.jdField_a_of_type_Boolean = true;
      if ((paramInt <= 0) || (paramPagerAdapter == null)) {
        break label249;
      }
    }
    label249:
    for (Object localObject1 = paramPagerAdapter.getPageTitle(paramInt - 1);; localObject1 = null)
    {
      this.jdField_a_of_type_AndroidWidgetTextView.setText((CharSequence)localObject1);
      TextView localTextView = this.jdField_b_of_type_AndroidWidgetTextView;
      if ((paramPagerAdapter != null) && (paramInt < i)) {}
      for (localObject1 = paramPagerAdapter.getPageTitle(paramInt);; localObject1 = null)
      {
        localTextView.setText((CharSequence)localObject1);
        localObject1 = localObject2;
        if (paramInt + 1 < i)
        {
          localObject1 = localObject2;
          if (paramPagerAdapter != null) {
            localObject1 = paramPagerAdapter.getPageTitle(paramInt + 1);
          }
        }
        this.jdField_c_of_type_AndroidWidgetTextView.setText((CharSequence)localObject1);
        int m = getWidth();
        int n = getPaddingLeft();
        int i1 = getPaddingRight();
        i = getHeight();
        int j = getPaddingTop();
        int k = getPaddingBottom();
        m = View.MeasureSpec.makeMeasureSpec((int)((m - n - i1) * 0.8F), Integer.MIN_VALUE);
        i = View.MeasureSpec.makeMeasureSpec(i - j - k, Integer.MIN_VALUE);
        this.jdField_a_of_type_AndroidWidgetTextView.measure(m, i);
        this.jdField_b_of_type_AndroidWidgetTextView.measure(m, i);
        this.jdField_c_of_type_AndroidWidgetTextView.measure(m, i);
        this.jdField_b_of_type_Int = paramInt;
        if (!this.jdField_b_of_type_Boolean) {
          a(paramInt, this.jdField_a_of_type_Float, false);
        }
        this.jdField_a_of_type_Boolean = false;
        return;
        i = 0;
        break;
      }
    }
  }
  
  public final void a(PagerAdapter paramPagerAdapter1, PagerAdapter paramPagerAdapter2)
  {
    if (paramPagerAdapter1 != null)
    {
      paramPagerAdapter1.b(this.jdField_a_of_type_AZ);
      this.jdField_a_of_type_JavaLangRefWeakReference = null;
    }
    if (paramPagerAdapter2 != null)
    {
      paramPagerAdapter2.a(this.jdField_a_of_type_AZ);
      this.jdField_a_of_type_JavaLangRefWeakReference = new WeakReference(paramPagerAdapter2);
    }
    if (this.jdField_a_of_type_AndroidSupportV4ViewViewPager != null)
    {
      this.jdField_b_of_type_Int = -1;
      this.jdField_a_of_type_Float = -1.0F;
      a(this.jdField_a_of_type_AndroidSupportV4ViewViewPager.getCurrentItem(), paramPagerAdapter2);
      requestLayout();
    }
  }
  
  public int getTextSpacing()
  {
    return this.jdField_c_of_type_Int;
  }
  
  protected void onAttachedToWindow()
  {
    super.onAttachedToWindow();
    Object localObject = getParent();
    if (!(localObject instanceof ViewPager)) {
      throw new IllegalStateException("PagerTitleStrip must be a direct child of a ViewPager.");
    }
    localObject = (ViewPager)localObject;
    PagerAdapter localPagerAdapter = ((ViewPager)localObject).getAdapter();
    ((ViewPager)localObject).a(this.jdField_a_of_type_AZ);
    ((ViewPager)localObject).a(this.jdField_a_of_type_AZ);
    this.jdField_a_of_type_AndroidSupportV4ViewViewPager = ((ViewPager)localObject);
    if (this.jdField_a_of_type_JavaLangRefWeakReference != null) {}
    for (localObject = (PagerAdapter)this.jdField_a_of_type_JavaLangRefWeakReference.get();; localObject = null)
    {
      a((PagerAdapter)localObject, localPagerAdapter);
      return;
    }
  }
  
  protected void onDetachedFromWindow()
  {
    super.onDetachedFromWindow();
    if (this.jdField_a_of_type_AndroidSupportV4ViewViewPager != null)
    {
      a(this.jdField_a_of_type_AndroidSupportV4ViewViewPager.getAdapter(), null);
      this.jdField_a_of_type_AndroidSupportV4ViewViewPager.a(null);
      this.jdField_a_of_type_AndroidSupportV4ViewViewPager.a(null);
      this.jdField_a_of_type_AndroidSupportV4ViewViewPager = null;
    }
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    float f = 0.0F;
    if (this.jdField_a_of_type_AndroidSupportV4ViewViewPager != null)
    {
      if (this.jdField_a_of_type_Float >= 0.0F) {
        f = this.jdField_a_of_type_Float;
      }
      a(this.jdField_b_of_type_Int, f, true);
    }
  }
  
  protected void onMeasure(int paramInt1, int paramInt2)
  {
    int j = View.MeasureSpec.getMode(paramInt1);
    int i = View.MeasureSpec.getMode(paramInt2);
    paramInt1 = View.MeasureSpec.getSize(paramInt1);
    paramInt2 = View.MeasureSpec.getSize(paramInt2);
    if (j != 1073741824) {
      throw new IllegalStateException("Must measure with an exact width");
    }
    j = a();
    int k = getPaddingTop() + getPaddingBottom();
    int m = View.MeasureSpec.makeMeasureSpec((int)(paramInt1 * 0.8F), Integer.MIN_VALUE);
    int n = View.MeasureSpec.makeMeasureSpec(paramInt2 - k, Integer.MIN_VALUE);
    this.jdField_a_of_type_AndroidWidgetTextView.measure(m, n);
    this.jdField_b_of_type_AndroidWidgetTextView.measure(m, n);
    this.jdField_c_of_type_AndroidWidgetTextView.measure(m, n);
    if (i == 1073741824)
    {
      setMeasuredDimension(paramInt1, paramInt2);
      return;
    }
    setMeasuredDimension(paramInt1, Math.max(j, this.jdField_b_of_type_AndroidWidgetTextView.getMeasuredHeight() + k));
  }
  
  public void requestLayout()
  {
    if (!this.jdField_a_of_type_Boolean) {
      super.requestLayout();
    }
  }
  
  public void setGravity(int paramInt)
  {
    this.d = paramInt;
    requestLayout();
  }
  
  public void setNonPrimaryAlpha(float paramFloat)
  {
    this.e = ((int)(255.0F * paramFloat) & 0xFF);
    int i = this.e << 24 | this.jdField_a_of_type_Int & 0xFFFFFF;
    this.jdField_a_of_type_AndroidWidgetTextView.setTextColor(i);
    this.jdField_c_of_type_AndroidWidgetTextView.setTextColor(i);
  }
  
  public void setTextColor(int paramInt)
  {
    this.jdField_a_of_type_Int = paramInt;
    this.jdField_b_of_type_AndroidWidgetTextView.setTextColor(paramInt);
    paramInt = this.e << 24 | this.jdField_a_of_type_Int & 0xFFFFFF;
    this.jdField_a_of_type_AndroidWidgetTextView.setTextColor(paramInt);
    this.jdField_c_of_type_AndroidWidgetTextView.setTextColor(paramInt);
  }
  
  public void setTextSize(int paramInt, float paramFloat)
  {
    this.jdField_a_of_type_AndroidWidgetTextView.setTextSize(paramInt, paramFloat);
    this.jdField_b_of_type_AndroidWidgetTextView.setTextSize(paramInt, paramFloat);
    this.jdField_c_of_type_AndroidWidgetTextView.setTextSize(paramInt, paramFloat);
  }
  
  public void setTextSpacing(int paramInt)
  {
    this.jdField_c_of_type_Int = paramInt;
    requestLayout();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/view/PagerTitleStrip.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */