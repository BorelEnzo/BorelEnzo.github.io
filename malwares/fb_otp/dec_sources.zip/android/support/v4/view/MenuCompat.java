package android.support.v4.view;

import aO;
import aP;
import aQ;
import android.os.Build.VERSION;
import android.view.MenuItem;

public class MenuCompat
{
  static final aQ a = new aO();
  
  static
  {
    if (Build.VERSION.SDK_INT >= 11)
    {
      a = new aP();
      return;
    }
  }
  
  public static boolean setShowAsAction(MenuItem paramMenuItem, int paramInt)
  {
    return a.a(paramMenuItem, paramInt);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/view/MenuCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */