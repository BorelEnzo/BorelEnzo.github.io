package android.support.v4.net;

import an;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build.VERSION;
import ao;
import ap;
import aq;
import ar;

public class ConnectivityManagerCompat
{
  private static final ao a = new an();
  
  static
  {
    if (Build.VERSION.SDK_INT >= 16)
    {
      a = new ar();
      return;
    }
    if (Build.VERSION.SDK_INT >= 13)
    {
      a = new aq();
      return;
    }
    if (Build.VERSION.SDK_INT >= 8)
    {
      a = new ap();
      return;
    }
  }
  
  public static NetworkInfo getNetworkInfoFromBroadcast(ConnectivityManager paramConnectivityManager, Intent paramIntent)
  {
    return paramConnectivityManager.getNetworkInfo(((NetworkInfo)paramIntent.getParcelableExtra("networkInfo")).getType());
  }
  
  public static boolean isActiveNetworkMetered(ConnectivityManager paramConnectivityManager)
  {
    return a.a(paramConnectivityManager);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/net/ConnectivityManagerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */