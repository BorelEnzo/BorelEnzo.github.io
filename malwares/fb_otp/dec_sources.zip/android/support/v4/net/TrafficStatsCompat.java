package android.support.v4.net;

import android.os.Build.VERSION;
import as;
import av;
import aw;
import java.net.Socket;

public class TrafficStatsCompat
{
  private static final aw a = new as();
  
  static
  {
    if (Build.VERSION.SDK_INT >= 14)
    {
      a = new av();
      return;
    }
  }
  
  public static void clearThreadStatsTag()
  {
    a.a();
  }
  
  public static int getThreadStatsTag()
  {
    return a.a();
  }
  
  public static void incrementOperationCount(int paramInt)
  {
    a.a(paramInt);
  }
  
  public static void incrementOperationCount(int paramInt1, int paramInt2)
  {
    a.a(paramInt1, paramInt2);
  }
  
  public static void setThreadStatsTag(int paramInt)
  {
    a.b(paramInt);
  }
  
  public static void tagSocket(Socket paramSocket)
  {
    a.a(paramSocket);
  }
  
  public static void untagSocket(Socket paramSocket)
  {
    a.b(paramSocket);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/android/support/v4/net/TrafficStatsCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */