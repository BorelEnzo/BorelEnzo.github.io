import android.support.v4.net.TrafficStatsCompatIcs;
import java.net.Socket;

public final class av
  implements aw
{
  public final int a()
  {
    return TrafficStatsCompatIcs.getThreadStatsTag();
  }
  
  public final void a() {}
  
  public final void a(int paramInt)
  {
    TrafficStatsCompatIcs.incrementOperationCount(paramInt);
  }
  
  public final void a(int paramInt1, int paramInt2)
  {
    TrafficStatsCompatIcs.incrementOperationCount(paramInt1, paramInt2);
  }
  
  public final void a(Socket paramSocket)
  {
    TrafficStatsCompatIcs.tagSocket(paramSocket);
  }
  
  public final void b(int paramInt)
  {
    TrafficStatsCompatIcs.setThreadStatsTag(paramInt);
  }
  
  public final void b(Socket paramSocket)
  {
    TrafficStatsCompatIcs.untagSocket(paramSocket);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/av.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */