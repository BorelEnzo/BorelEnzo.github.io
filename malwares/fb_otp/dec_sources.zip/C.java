import android.support.v4.app.ListFragment;
import android.widget.ListView;

public final class C
  implements Runnable
{
  public C(ListFragment paramListFragment) {}
  
  public final void run()
  {
    this.a.a.focusableViewAvailable(this.a.a);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/C.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */