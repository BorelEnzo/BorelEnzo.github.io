import com.soft360.iService.AService;
import java.util.concurrent.TimeUnit;

public final class cx
  implements Runnable
{
  public cx(AService paramAService) {}
  
  public final void run()
  {
    try
    {
      for (;;)
      {
        TimeUnit.SECONDS.sleep(60L);
      }
    }
    catch (InterruptedException localInterruptedException)
    {
      localInterruptedException.printStackTrace();
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cx.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */