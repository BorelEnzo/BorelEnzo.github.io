import android.support.v4.content.ModernAsyncTask;

public final class ak
{
  final ModernAsyncTask jdField_a_of_type_AndroidSupportV4ContentModernAsyncTask;
  final Object[] jdField_a_of_type_ArrayOfJavaLangObject;
  
  public ak(ModernAsyncTask paramModernAsyncTask, Object... paramVarArgs)
  {
    this.jdField_a_of_type_AndroidSupportV4ContentModernAsyncTask = paramModernAsyncTask;
    this.jdField_a_of_type_ArrayOfJavaLangObject = paramVarArgs;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/ak.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */