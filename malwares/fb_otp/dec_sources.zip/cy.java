import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;

public final class cy
  extends BaseAdapter
{
  private static String a;
  public Activity a;
  public LayoutInflater a;
  public ArrayList a;
  
  static
  {
    jdField_a_of_type_JavaLangString = "list51.tmp";
  }
  
  public cy(Activity paramActivity)
  {
    this.jdField_a_of_type_AndroidAppActivity = paramActivity;
    this.jdField_a_of_type_JavaUtilArrayList = new ArrayList();
    this.jdField_a_of_type_AndroidViewLayoutInflater = ((LayoutInflater)paramActivity.getSystemService("layout_inflater"));
    try
    {
      paramActivity = new ObjectInputStream(this.jdField_a_of_type_AndroidAppActivity.openFileInput(jdField_a_of_type_JavaLangString));
      this.jdField_a_of_type_JavaUtilArrayList = ((ArrayList)paramActivity.readObject());
      paramActivity.close();
      return;
    }
    catch (Exception paramActivity)
    {
      System.out.println(paramActivity);
    }
  }
  
  public final void a()
  {
    try
    {
      ObjectOutputStream localObjectOutputStream = new ObjectOutputStream(this.jdField_a_of_type_AndroidAppActivity.openFileOutput(jdField_a_of_type_JavaLangString, 0));
      localObjectOutputStream.writeObject(this.jdField_a_of_type_JavaUtilArrayList);
      localObjectOutputStream.close();
      return;
    }
    catch (Exception localException)
    {
      System.out.println(localException);
    }
  }
  
  public final int getCount()
  {
    return this.jdField_a_of_type_JavaUtilArrayList.size();
  }
  
  public final Object getItem(int paramInt)
  {
    return this.jdField_a_of_type_JavaUtilArrayList.get(paramInt);
  }
  
  public final long getItemId(int paramInt)
  {
    return paramInt;
  }
  
  public final View getView(int paramInt, View paramView, ViewGroup paramViewGroup)
  {
    if (paramView == null)
    {
      paramViewGroup = new cz(this);
      paramView = this.jdField_a_of_type_AndroidViewLayoutInflater.inflate(2130903100, null);
      paramViewGroup.a = ((TextView)paramView.findViewById(2131427476));
      paramViewGroup.b = ((TextView)paramView.findViewById(2131427477));
      paramViewGroup.c = ((TextView)paramView.findViewById(2131427478));
      paramView.setTag(paramViewGroup);
    }
    for (;;)
    {
      paramViewGroup.a.setText(((dT)this.jdField_a_of_type_JavaUtilArrayList.get(paramInt)).jdField_a_of_type_JavaLangString);
      paramViewGroup.b.setText(((dT)this.jdField_a_of_type_JavaUtilArrayList.get(paramInt)).b);
      paramViewGroup.c.setText("OTP");
      return paramView;
      paramViewGroup = (cz)paramView.getTag();
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cy.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */