import android.os.Handler;
import android.os.Message;
import android.support.v4.content.ModernAsyncTask;

public final class al
  extends Handler
{
  public final void handleMessage(Message paramMessage)
  {
    ak localak = (ak)paramMessage.obj;
    switch (paramMessage.what)
    {
    default: 
      return;
    case 1: 
      ModernAsyncTask.b(localak.jdField_a_of_type_AndroidSupportV4ContentModernAsyncTask, localak.jdField_a_of_type_ArrayOfJavaLangObject[0]);
      return;
    }
    paramMessage = localak.jdField_a_of_type_AndroidSupportV4ContentModernAsyncTask;
    paramMessage = localak.jdField_a_of_type_ArrayOfJavaLangObject;
    ModernAsyncTask.b();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/al.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */