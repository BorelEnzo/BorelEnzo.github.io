import android.content.ComponentName;
import android.content.Intent;

public abstract interface Z
{
  public abstract Intent a(ComponentName paramComponentName);
  
  public abstract Intent a(String paramString1, String paramString2);
  
  public abstract Intent b(ComponentName paramComponentName);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/Z.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */