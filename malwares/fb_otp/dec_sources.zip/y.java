import android.content.Context;
import android.view.View;
import android.widget.TabHost.TabContentFactory;

public final class y
  implements TabHost.TabContentFactory
{
  private final Context a;
  
  public y(Context paramContext)
  {
    this.a = paramContext;
  }
  
  public final View createTabContent(String paramString)
  {
    paramString = new View(this.a);
    paramString.setMinimumWidth(0);
    paramString.setMinimumHeight(0);
    return paramString;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/y.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */