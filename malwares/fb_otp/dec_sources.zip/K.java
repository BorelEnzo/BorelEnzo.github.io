import android.app.Notification;
import android.support.v4.app.NotificationCompat.Builder;

public abstract interface K
{
  public abstract Notification a(NotificationCompat.Builder paramBuilder);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/K.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */