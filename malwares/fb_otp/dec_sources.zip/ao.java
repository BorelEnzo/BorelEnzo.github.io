import android.net.ConnectivityManager;

public abstract interface ao
{
  public abstract boolean a(ConnectivityManager paramConnectivityManager);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/ao.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */