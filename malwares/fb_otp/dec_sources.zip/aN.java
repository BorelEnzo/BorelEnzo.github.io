public abstract interface aN
{
  public abstract int a(int paramInt);
  
  public abstract boolean a(int paramInt);
  
  public abstract boolean a(int paramInt1, int paramInt2);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/aN.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */