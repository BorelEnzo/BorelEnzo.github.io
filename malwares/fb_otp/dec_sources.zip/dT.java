import java.io.Serializable;

final class dT
  implements Serializable
{
  public String a;
  public String b;
  public String c;
  public String d = "OTP";
  
  public dT(String paramString1, String paramString2, String paramString3)
  {
    this.a = paramString1;
    this.b = paramString2;
    this.c = paramString3;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/dT.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */