import android.os.Handler;
import android.support.v4.app.FragmentActivity;

final class q
  implements Runnable
{
  q(o paramo) {}
  
  public final void run()
  {
    o localo = this.a;
    Handler localHandler = this.a.a.a;
    localo.a(null, -1, 0);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/q.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */