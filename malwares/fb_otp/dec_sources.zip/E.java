import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.LoaderManager;
import android.support.v4.app.LoaderManager.LoaderCallbacks;
import android.support.v4.content.Loader;
import android.support.v4.util.DebugUtils;
import android.support.v4.util.SparseArrayCompat;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public final class E
  extends LoaderManager
{
  public static boolean a;
  FragmentActivity jdField_a_of_type_AndroidSupportV4AppFragmentActivity;
  final SparseArrayCompat jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat = new SparseArrayCompat();
  public final String a;
  final SparseArrayCompat b;
  public boolean b;
  public boolean c;
  boolean d;
  
  static
  {
    jdField_a_of_type_Boolean = false;
  }
  
  public E(String paramString, FragmentActivity paramFragmentActivity, boolean paramBoolean)
  {
    this.jdField_b_of_type_AndroidSupportV4UtilSparseArrayCompat = new SparseArrayCompat();
    this.jdField_a_of_type_JavaLangString = paramString;
    this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity = paramFragmentActivity;
    this.jdField_b_of_type_Boolean = paramBoolean;
  }
  
  private F a(int paramInt, Bundle paramBundle, LoaderManager.LoaderCallbacks paramLoaderCallbacks)
  {
    F localF = new F(this, paramInt, paramBundle, paramLoaderCallbacks);
    localF.jdField_a_of_type_AndroidSupportV4ContentLoader = paramLoaderCallbacks.onCreateLoader(paramInt, paramBundle);
    return localF;
  }
  
  private F b(int paramInt, Bundle paramBundle, LoaderManager.LoaderCallbacks paramLoaderCallbacks)
  {
    try
    {
      this.d = true;
      paramBundle = a(paramInt, paramBundle, paramLoaderCallbacks);
      a(paramBundle);
      return paramBundle;
    }
    finally
    {
      this.d = false;
    }
  }
  
  public final void a()
  {
    if (jdField_a_of_type_Boolean) {
      new StringBuilder("Starting in ").append(this).toString();
    }
    if (this.jdField_b_of_type_Boolean)
    {
      new RuntimeException("here").fillInStackTrace();
      new StringBuilder("Called doStart when already started: ").append(this).toString();
    }
    for (;;)
    {
      return;
      this.jdField_b_of_type_Boolean = true;
      int i = this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.size() - 1;
      while (i >= 0)
      {
        ((F)this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.valueAt(i)).a();
        i -= 1;
      }
    }
  }
  
  final void a(F paramF)
  {
    this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.put(paramF.jdField_a_of_type_Int, paramF);
    if (this.jdField_b_of_type_Boolean) {
      paramF.a();
    }
  }
  
  public final void a(FragmentActivity paramFragmentActivity)
  {
    this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity = paramFragmentActivity;
  }
  
  public final void b()
  {
    if (jdField_a_of_type_Boolean) {
      new StringBuilder("Stopping in ").append(this).toString();
    }
    if (!this.jdField_b_of_type_Boolean)
    {
      new RuntimeException("here").fillInStackTrace();
      new StringBuilder("Called doStop when not started: ").append(this).toString();
      return;
    }
    int i = this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.size() - 1;
    while (i >= 0)
    {
      ((F)this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.valueAt(i)).e();
      i -= 1;
    }
    this.jdField_b_of_type_Boolean = false;
  }
  
  public final void c()
  {
    if (jdField_a_of_type_Boolean) {
      new StringBuilder("Retaining in ").append(this).toString();
    }
    if (!this.jdField_b_of_type_Boolean)
    {
      new RuntimeException("here").fillInStackTrace();
      new StringBuilder("Called doRetain when not started: ").append(this).toString();
    }
    for (;;)
    {
      return;
      this.c = true;
      this.jdField_b_of_type_Boolean = false;
      int i = this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.size() - 1;
      while (i >= 0)
      {
        ((F)this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.valueAt(i)).b();
        i -= 1;
      }
    }
  }
  
  public final void d()
  {
    if (this.c)
    {
      if (jdField_a_of_type_Boolean) {
        new StringBuilder("Finished Retaining in ").append(this).toString();
      }
      this.c = false;
      int i = this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.size() - 1;
      while (i >= 0)
      {
        ((F)this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.valueAt(i)).c();
        i -= 1;
      }
    }
  }
  
  public final void destroyLoader(int paramInt)
  {
    if (this.d) {
      throw new IllegalStateException("Called while creating a loader");
    }
    if (jdField_a_of_type_Boolean) {
      new StringBuilder("destroyLoader in ").append(this).append(" of ").append(paramInt).toString();
    }
    int i = this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.indexOfKey(paramInt);
    F localF;
    if (i >= 0)
    {
      localF = (F)this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.valueAt(i);
      this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.removeAt(i);
      localF.f();
    }
    paramInt = this.jdField_b_of_type_AndroidSupportV4UtilSparseArrayCompat.indexOfKey(paramInt);
    if (paramInt >= 0)
    {
      localF = (F)this.jdField_b_of_type_AndroidSupportV4UtilSparseArrayCompat.valueAt(paramInt);
      this.jdField_b_of_type_AndroidSupportV4UtilSparseArrayCompat.removeAt(paramInt);
      localF.f();
    }
    if ((this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity != null) && (!hasRunningLoaders())) {
      this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity.a.a();
    }
  }
  
  public final void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString)
  {
    int j = 0;
    String str;
    int i;
    F localF;
    if (this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.size() > 0)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Active Loaders:");
      str = paramString + "    ";
      i = 0;
      while (i < this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.size())
      {
        localF = (F)this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.valueAt(i);
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  #");
        paramPrintWriter.print(this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.keyAt(i));
        paramPrintWriter.print(": ");
        paramPrintWriter.println(localF.toString());
        localF.a(str, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
        i += 1;
      }
    }
    if (this.jdField_b_of_type_AndroidSupportV4UtilSparseArrayCompat.size() > 0)
    {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Inactive Loaders:");
      str = paramString + "    ";
      i = j;
      while (i < this.jdField_b_of_type_AndroidSupportV4UtilSparseArrayCompat.size())
      {
        localF = (F)this.jdField_b_of_type_AndroidSupportV4UtilSparseArrayCompat.valueAt(i);
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  #");
        paramPrintWriter.print(this.jdField_b_of_type_AndroidSupportV4UtilSparseArrayCompat.keyAt(i));
        paramPrintWriter.print(": ");
        paramPrintWriter.println(localF.toString());
        localF.a(str, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
        i += 1;
      }
    }
  }
  
  public final void e()
  {
    int i = this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.size() - 1;
    while (i >= 0)
    {
      ((F)this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.valueAt(i)).f = true;
      i -= 1;
    }
  }
  
  public final void f()
  {
    int i = this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.size() - 1;
    while (i >= 0)
    {
      ((F)this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.valueAt(i)).d();
      i -= 1;
    }
  }
  
  public final void g()
  {
    if (!this.c)
    {
      if (jdField_a_of_type_Boolean) {
        new StringBuilder("Destroying Active in ").append(this).toString();
      }
      i = this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.size() - 1;
      while (i >= 0)
      {
        ((F)this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.valueAt(i)).f();
        i -= 1;
      }
    }
    if (jdField_a_of_type_Boolean) {
      new StringBuilder("Destroying Inactive in ").append(this).toString();
    }
    int i = this.jdField_b_of_type_AndroidSupportV4UtilSparseArrayCompat.size() - 1;
    while (i >= 0)
    {
      ((F)this.jdField_b_of_type_AndroidSupportV4UtilSparseArrayCompat.valueAt(i)).f();
      i -= 1;
    }
    this.jdField_b_of_type_AndroidSupportV4UtilSparseArrayCompat.clear();
  }
  
  public final Loader getLoader(int paramInt)
  {
    if (this.d) {
      throw new IllegalStateException("Called while creating a loader");
    }
    F localF = (F)this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.get(paramInt);
    if (localF != null)
    {
      if (localF.jdField_a_of_type_F != null) {
        return localF.jdField_a_of_type_F.jdField_a_of_type_AndroidSupportV4ContentLoader;
      }
      return localF.jdField_a_of_type_AndroidSupportV4ContentLoader;
    }
    return null;
  }
  
  public final boolean hasRunningLoaders()
  {
    int j = this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.size();
    int i = 0;
    boolean bool2 = false;
    if (i < j)
    {
      F localF = (F)this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.valueAt(i);
      if ((localF.c) && (!localF.jdField_b_of_type_Boolean)) {}
      for (boolean bool1 = true;; bool1 = false)
      {
        bool2 |= bool1;
        i += 1;
        break;
      }
    }
    return bool2;
  }
  
  public final Loader initLoader(int paramInt, Bundle paramBundle, LoaderManager.LoaderCallbacks paramLoaderCallbacks)
  {
    if (this.d) {
      throw new IllegalStateException("Called while creating a loader");
    }
    F localF = (F)this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.get(paramInt);
    if (jdField_a_of_type_Boolean) {
      new StringBuilder("initLoader in ").append(this).append(": args=").append(paramBundle).toString();
    }
    if (localF == null)
    {
      paramLoaderCallbacks = b(paramInt, paramBundle, paramLoaderCallbacks);
      paramBundle = paramLoaderCallbacks;
      if (jdField_a_of_type_Boolean) {
        new StringBuilder("  Created new loader ").append(paramLoaderCallbacks).toString();
      }
    }
    for (paramBundle = paramLoaderCallbacks;; paramBundle = localF)
    {
      if ((paramBundle.jdField_a_of_type_Boolean) && (this.jdField_b_of_type_Boolean)) {
        paramBundle.a(paramBundle.jdField_a_of_type_AndroidSupportV4ContentLoader, paramBundle.jdField_a_of_type_JavaLangObject);
      }
      return paramBundle.jdField_a_of_type_AndroidSupportV4ContentLoader;
      if (jdField_a_of_type_Boolean) {
        new StringBuilder("  Re-using existing loader ").append(localF).toString();
      }
      localF.jdField_a_of_type_AndroidSupportV4AppLoaderManager$LoaderCallbacks = paramLoaderCallbacks;
    }
  }
  
  public final Loader restartLoader(int paramInt, Bundle paramBundle, LoaderManager.LoaderCallbacks paramLoaderCallbacks)
  {
    if (this.d) {
      throw new IllegalStateException("Called while creating a loader");
    }
    F localF1 = (F)this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.get(paramInt);
    if (jdField_a_of_type_Boolean) {
      new StringBuilder("restartLoader in ").append(this).append(": args=").append(paramBundle).toString();
    }
    if (localF1 != null)
    {
      F localF2 = (F)this.jdField_b_of_type_AndroidSupportV4UtilSparseArrayCompat.get(paramInt);
      if (localF2 == null) {
        break label262;
      }
      if (!localF1.jdField_a_of_type_Boolean) {
        break label157;
      }
      if (jdField_a_of_type_Boolean) {
        new StringBuilder("  Removing last inactive loader: ").append(localF1).toString();
      }
      localF2.jdField_b_of_type_Boolean = false;
      localF2.f();
    }
    for (;;)
    {
      localF1.jdField_a_of_type_AndroidSupportV4ContentLoader.abandon();
      this.jdField_b_of_type_AndroidSupportV4UtilSparseArrayCompat.put(paramInt, localF1);
      for (;;)
      {
        return b(paramInt, paramBundle, paramLoaderCallbacks).jdField_a_of_type_AndroidSupportV4ContentLoader;
        label157:
        if (localF1.c) {
          break;
        }
        bool = jdField_a_of_type_Boolean;
        this.jdField_a_of_type_AndroidSupportV4UtilSparseArrayCompat.put(paramInt, null);
        localF1.f();
      }
      if (localF1.jdField_a_of_type_F != null)
      {
        if (jdField_a_of_type_Boolean) {
          new StringBuilder("  Removing pending loader: ").append(localF1.jdField_a_of_type_F).toString();
        }
        localF1.jdField_a_of_type_F.f();
        localF1.jdField_a_of_type_F = null;
      }
      boolean bool = jdField_a_of_type_Boolean;
      localF1.jdField_a_of_type_F = a(paramInt, paramBundle, paramLoaderCallbacks);
      return localF1.jdField_a_of_type_F.jdField_a_of_type_AndroidSupportV4ContentLoader;
      label262:
      if (jdField_a_of_type_Boolean) {
        new StringBuilder("  Making last loader inactive: ").append(localF1).toString();
      }
    }
  }
  
  public final String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(128);
    localStringBuilder.append("LoaderManager{");
    localStringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    localStringBuilder.append(" in ");
    DebugUtils.buildShortClassTag(this.jdField_a_of_type_AndroidSupportV4AppFragmentActivity, localStringBuilder);
    localStringBuilder.append("}}");
    return localStringBuilder.toString();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/E.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */