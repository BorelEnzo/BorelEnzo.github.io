import android.support.v4.app.Fragment;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;

final class t
  implements Animation.AnimationListener
{
  t(o paramo, Fragment paramFragment) {}
  
  public final void onAnimationEnd(Animation paramAnimation)
  {
    if (this.jdField_a_of_type_AndroidSupportV4AppFragment.a != null)
    {
      this.jdField_a_of_type_AndroidSupportV4AppFragment.a = null;
      this.jdField_a_of_type_O.a(this.jdField_a_of_type_AndroidSupportV4AppFragment, this.jdField_a_of_type_AndroidSupportV4AppFragment.e, 0, 0, false);
    }
  }
  
  public final void onAnimationRepeat(Animation paramAnimation) {}
  
  public final void onAnimationStart(Animation paramAnimation) {}
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/t.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */