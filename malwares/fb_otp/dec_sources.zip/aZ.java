import android.database.DataSetObserver;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.PagerTitleStrip;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;

public final class aZ
  extends DataSetObserver
  implements ViewPager.OnPageChangeListener, bB
{
  private int jdField_a_of_type_Int;
  
  private aZ(PagerTitleStrip paramPagerTitleStrip) {}
  
  public final void a(PagerAdapter paramPagerAdapter1, PagerAdapter paramPagerAdapter2)
  {
    this.jdField_a_of_type_AndroidSupportV4ViewPagerTitleStrip.a(paramPagerAdapter1, paramPagerAdapter2);
  }
  
  public final void onChanged()
  {
    float f = 0.0F;
    this.jdField_a_of_type_AndroidSupportV4ViewPagerTitleStrip.a(this.jdField_a_of_type_AndroidSupportV4ViewPagerTitleStrip.a.getCurrentItem(), this.jdField_a_of_type_AndroidSupportV4ViewPagerTitleStrip.a.getAdapter());
    if (PagerTitleStrip.a(this.jdField_a_of_type_AndroidSupportV4ViewPagerTitleStrip) >= 0.0F) {
      f = PagerTitleStrip.a(this.jdField_a_of_type_AndroidSupportV4ViewPagerTitleStrip);
    }
    this.jdField_a_of_type_AndroidSupportV4ViewPagerTitleStrip.a(this.jdField_a_of_type_AndroidSupportV4ViewPagerTitleStrip.a.getCurrentItem(), f, true);
  }
  
  public final void onPageScrollStateChanged(int paramInt)
  {
    this.jdField_a_of_type_Int = paramInt;
  }
  
  public final void onPageScrolled(int paramInt1, float paramFloat, int paramInt2)
  {
    paramInt2 = paramInt1;
    if (paramFloat > 0.5F) {
      paramInt2 = paramInt1 + 1;
    }
    this.jdField_a_of_type_AndroidSupportV4ViewPagerTitleStrip.a(paramInt2, paramFloat, false);
  }
  
  public final void onPageSelected(int paramInt)
  {
    float f = 0.0F;
    if (this.jdField_a_of_type_Int == 0)
    {
      this.jdField_a_of_type_AndroidSupportV4ViewPagerTitleStrip.a(this.jdField_a_of_type_AndroidSupportV4ViewPagerTitleStrip.a.getCurrentItem(), this.jdField_a_of_type_AndroidSupportV4ViewPagerTitleStrip.a.getAdapter());
      if (PagerTitleStrip.a(this.jdField_a_of_type_AndroidSupportV4ViewPagerTitleStrip) >= 0.0F) {
        f = PagerTitleStrip.a(this.jdField_a_of_type_AndroidSupportV4ViewPagerTitleStrip);
      }
      this.jdField_a_of_type_AndroidSupportV4ViewPagerTitleStrip.a(this.jdField_a_of_type_AndroidSupportV4ViewPagerTitleStrip.a.getCurrentItem(), f, true);
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/aZ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */