import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import com.soft360.iService.MainActivity;

public final class cG
  implements TextWatcher
{
  public cG(MainActivity paramMainActivity, Button paramButton) {}
  
  public final void afterTextChanged(Editable paramEditable) {}
  
  public final void beforeTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3) {}
  
  public final void onTextChanged(CharSequence paramCharSequence, int paramInt1, int paramInt2, int paramInt3)
  {
    if (MainActivity.a(this.jdField_a_of_type_ComSoft360IServiceMainActivity))
    {
      this.jdField_a_of_type_AndroidWidgetButton.setEnabled(false);
      return;
    }
    this.jdField_a_of_type_AndroidWidgetButton.setEnabled(true);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cG.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */