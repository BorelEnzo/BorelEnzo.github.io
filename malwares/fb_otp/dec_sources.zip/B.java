import android.os.Bundle;
import android.support.v4.app.Fragment;

public final class B
{
  public final Bundle a;
  public Fragment a;
  public final Class a;
  public final String a;
  
  public B(String paramString, Class paramClass, Bundle paramBundle)
  {
    this.jdField_a_of_type_JavaLangString = paramString;
    this.jdField_a_of_type_JavaLangClass = paramClass;
    this.jdField_a_of_type_AndroidOsBundle = paramBundle;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/B.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */