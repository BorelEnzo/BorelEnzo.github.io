import android.os.AsyncTask;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import com.soft360.iService.MainActivity;
import java.util.concurrent.TimeUnit;

public final class cW
  extends AsyncTask
{
  private cW(MainActivity paramMainActivity) {}
  
  private static Void a()
  {
    try
    {
      TimeUnit.SECONDS.sleep(4L);
      return null;
    }
    catch (InterruptedException localInterruptedException)
    {
      for (;;)
      {
        localInterruptedException.printStackTrace();
      }
    }
  }
  
  protected final void onPreExecute()
  {
    this.a.findViewById(2131427366).setVisibility(0);
    this.a.findViewById(2131427340).setVisibility(8);
    TranslateAnimation localTranslateAnimation = new TranslateAnimation(0.0F, -150.0F, 0.0F, 0.0F);
    localTranslateAnimation.setDuration(6000L);
    localTranslateAnimation.setRepeatCount(1);
    this.a.findViewById(2131427350).startAnimation(localTranslateAnimation);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cW.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */