import android.content.BroadcastReceiver;
import android.content.IntentFilter;

public final class af
{
  public final BroadcastReceiver a;
  public final IntentFilter a;
  public boolean a;
  
  public af(IntentFilter paramIntentFilter, BroadcastReceiver paramBroadcastReceiver)
  {
    this.jdField_a_of_type_AndroidContentIntentFilter = paramIntentFilter;
    this.jdField_a_of_type_AndroidContentBroadcastReceiver = paramBroadcastReceiver;
  }
  
  public final String toString()
  {
    StringBuilder localStringBuilder = new StringBuilder(128);
    localStringBuilder.append("Receiver{");
    localStringBuilder.append(this.jdField_a_of_type_AndroidContentBroadcastReceiver);
    localStringBuilder.append(" filter=");
    localStringBuilder.append(this.jdField_a_of_type_AndroidContentIntentFilter);
    localStringBuilder.append("}");
    return localStringBuilder.toString();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/af.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */