import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;

final class dI
  implements DialogInterface.OnClickListener
{
  dI(dH paramdH) {}
  
  public final void onClick(DialogInterface paramDialogInterface, int paramInt) {}
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/dI.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */