import android.support.v4.app.Fragment;
import android.view.View;

public final class h
  implements n
{
  public h(Fragment paramFragment) {}
  
  public final View a(int paramInt)
  {
    if (this.a.b == null) {
      throw new IllegalStateException("Fragment does not have a view");
    }
    return this.a.b.findViewById(paramInt);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/h.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */