import android.view.animation.Interpolator;

public final class bw
  implements Interpolator
{
  public final float getInterpolation(float paramFloat)
  {
    paramFloat -= 1.0F;
    return paramFloat * (paramFloat * paramFloat * paramFloat * paramFloat) + 1.0F;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */