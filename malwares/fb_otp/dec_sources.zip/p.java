final class p
  implements Runnable
{
  p(o paramo) {}
  
  public final void run()
  {
    this.a.a();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/p.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */