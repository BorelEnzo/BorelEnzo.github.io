import android.support.v4.view.accessibility.AccessibilityManagerCompat.AccessibilityStateChangeListenerCompat;

final class bJ
  implements bO
{
  bJ(bI parambI, AccessibilityManagerCompat.AccessibilityStateChangeListenerCompat paramAccessibilityStateChangeListenerCompat) {}
  
  public final void a(boolean paramBoolean)
  {
    this.jdField_a_of_type_AndroidSupportV4ViewAccessibilityAccessibilityManagerCompat$AccessibilityStateChangeListenerCompat.onAccessibilityStateChanged(paramBoolean);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bJ.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */