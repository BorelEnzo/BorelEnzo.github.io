import android.view.ViewConfiguration;

public final class bq
  implements br
{
  public final int a(ViewConfiguration paramViewConfiguration)
  {
    return paramViewConfiguration.getScaledPagingTouchSlop();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bq.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */