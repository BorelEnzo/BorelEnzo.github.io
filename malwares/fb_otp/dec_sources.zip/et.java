import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import java.io.PrintStream;

public final class et
{
  public static Context a;
  private static et jdField_a_of_type_Et = new et();
  ConnectivityManager jdField_a_of_type_AndroidNetConnectivityManager;
  boolean jdField_a_of_type_Boolean = false;
  
  public static et a(Context paramContext)
  {
    jdField_a_of_type_AndroidContentContext = paramContext;
    return jdField_a_of_type_Et;
  }
  
  private boolean a(Context paramContext)
  {
    if (paramContext == null) {
      throw new NullPointerException("Context is null!");
    }
    try
    {
      this.jdField_a_of_type_AndroidNetConnectivityManager = ((ConnectivityManager)paramContext.getSystemService("connectivity"));
      paramContext = this.jdField_a_of_type_AndroidNetConnectivityManager.getActiveNetworkInfo();
      if ((paramContext != null) && (paramContext.isAvailable()) && (paramContext.isConnected())) {}
      for (boolean bool = true;; bool = false)
      {
        this.jdField_a_of_type_Boolean = bool;
        bool = this.jdField_a_of_type_Boolean;
        return bool;
      }
      return this.jdField_a_of_type_Boolean;
    }
    catch (Exception paramContext)
    {
      System.out.println("CheckConnectivity Exception: " + paramContext.getMessage());
      new StringBuilder("connectivity ").append(paramContext.toString()).toString();
      new StringBuilder("connectivity").append(paramContext.toString()).toString();
    }
  }
  
  public final boolean a()
  {
    return a(jdField_a_of_type_AndroidContentContext);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/et.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */