import android.support.v4.widget.SearchViewCompat.OnCloseListenerCompat;

final class co
  implements cv
{
  co(cm paramcm, SearchViewCompat.OnCloseListenerCompat paramOnCloseListenerCompat) {}
  
  public final boolean a()
  {
    return this.jdField_a_of_type_AndroidSupportV4WidgetSearchViewCompat$OnCloseListenerCompat.onClose();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/co.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */