import android.database.Cursor;
import android.widget.Filter;
import android.widget.Filter.FilterResults;

public final class ch
  extends Filter
{
  ci a;
  
  public ch(ci paramci)
  {
    this.a = paramci;
  }
  
  public final CharSequence convertResultToString(Object paramObject)
  {
    return this.a.convertToString((Cursor)paramObject);
  }
  
  protected final Filter.FilterResults performFiltering(CharSequence paramCharSequence)
  {
    paramCharSequence = this.a.runQueryOnBackgroundThread(paramCharSequence);
    Filter.FilterResults localFilterResults = new Filter.FilterResults();
    if (paramCharSequence != null)
    {
      localFilterResults.count = paramCharSequence.getCount();
      localFilterResults.values = paramCharSequence;
      return localFilterResults;
    }
    localFilterResults.count = 0;
    localFilterResults.values = null;
    return localFilterResults;
  }
  
  protected final void publishResults(CharSequence paramCharSequence, Filter.FilterResults paramFilterResults)
  {
    paramCharSequence = this.a.getCursor();
    if ((paramFilterResults.values != null) && (paramFilterResults.values != paramCharSequence)) {
      this.a.changeCursor((Cursor)paramFilterResults.values);
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/ch.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */