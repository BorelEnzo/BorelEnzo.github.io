import android.content.ComponentName;
import android.content.Intent;

public class ab
  extends aa
{
  public final Intent a(ComponentName paramComponentName)
  {
    return Intent.makeMainActivity(paramComponentName);
  }
  
  public final Intent b(ComponentName paramComponentName)
  {
    return Intent.makeRestartActivityTask(paramComponentName);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/ab.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */