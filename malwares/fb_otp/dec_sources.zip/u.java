import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;

final class u
  implements Parcelable
{
  public static final Parcelable.Creator a;
  int[] jdField_a_of_type_ArrayOfInt;
  f[] jdField_a_of_type_ArrayOfF;
  w[] jdField_a_of_type_ArrayOfW;
  
  static
  {
    jdField_a_of_type_AndroidOsParcelable$Creator = new v();
  }
  
  public u() {}
  
  public u(Parcel paramParcel)
  {
    this.jdField_a_of_type_ArrayOfW = ((w[])paramParcel.createTypedArray(w.jdField_a_of_type_AndroidOsParcelable$Creator));
    this.jdField_a_of_type_ArrayOfInt = paramParcel.createIntArray();
    this.jdField_a_of_type_ArrayOfF = ((f[])paramParcel.createTypedArray(f.jdField_a_of_type_AndroidOsParcelable$Creator));
  }
  
  public final int describeContents()
  {
    return 0;
  }
  
  public final void writeToParcel(Parcel paramParcel, int paramInt)
  {
    paramParcel.writeTypedArray(this.jdField_a_of_type_ArrayOfW, paramInt);
    paramParcel.writeIntArray(this.jdField_a_of_type_ArrayOfInt);
    paramParcel.writeTypedArray(this.jdField_a_of_type_ArrayOfF, paramInt);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/u.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */