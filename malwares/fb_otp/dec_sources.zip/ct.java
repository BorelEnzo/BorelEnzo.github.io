import android.widget.SearchView.OnQueryTextListener;

final class ct
  implements SearchView.OnQueryTextListener
{
  ct(cw paramcw) {}
  
  public final boolean onQueryTextChange(String paramString)
  {
    return this.a.b(paramString);
  }
  
  public final boolean onQueryTextSubmit(String paramString)
  {
    return this.a.a(paramString);
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/ct.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */