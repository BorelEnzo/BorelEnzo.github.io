import android.support.v4.view.accessibility.AccessibilityManagerCompat.AccessibilityStateChangeListenerCompat;
import android.view.accessibility.AccessibilityManager;
import java.util.Collections;
import java.util.List;

public class bK
  implements bL
{
  public Object a(AccessibilityManagerCompat.AccessibilityStateChangeListenerCompat paramAccessibilityStateChangeListenerCompat)
  {
    return null;
  }
  
  public List a(AccessibilityManager paramAccessibilityManager)
  {
    return Collections.emptyList();
  }
  
  public List a(AccessibilityManager paramAccessibilityManager, int paramInt)
  {
    return Collections.emptyList();
  }
  
  public boolean a(AccessibilityManager paramAccessibilityManager)
  {
    return false;
  }
  
  public boolean a(AccessibilityManager paramAccessibilityManager, AccessibilityManagerCompat.AccessibilityStateChangeListenerCompat paramAccessibilityStateChangeListenerCompat)
  {
    return false;
  }
  
  public boolean b(AccessibilityManager paramAccessibilityManager, AccessibilityManagerCompat.AccessibilityStateChangeListenerCompat paramAccessibilityStateChangeListenerCompat)
  {
    return false;
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/bK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */