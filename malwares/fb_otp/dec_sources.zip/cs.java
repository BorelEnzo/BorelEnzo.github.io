final class cs {}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cs.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */