import java.util.ArrayList;
import java.util.HashMap;

public final class m
{
  public Object a;
  public ArrayList a;
  public HashMap a;
  public Object b;
  public HashMap b;
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/m.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */