import java.net.Socket;

public abstract interface aw
{
  public abstract int a();
  
  public abstract void a();
  
  public abstract void a(int paramInt);
  
  public abstract void a(int paramInt1, int paramInt2);
  
  public abstract void a(Socket paramSocket);
  
  public abstract void b(int paramInt);
  
  public abstract void b(Socket paramSocket);
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/aw.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */