import android.app.Notification;
import android.app.Notification.Builder;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.support.v4.app.NotificationCompat.Builder;
import android.widget.RemoteViews;

public final class N
  implements K
{
  public final Notification a(NotificationCompat.Builder paramBuilder)
  {
    Context localContext = paramBuilder.jdField_a_of_type_AndroidContentContext;
    Notification localNotification = paramBuilder.jdField_a_of_type_AndroidAppNotification;
    CharSequence localCharSequence1 = paramBuilder.jdField_a_of_type_JavaLangCharSequence;
    CharSequence localCharSequence2 = paramBuilder.jdField_b_of_type_JavaLangCharSequence;
    CharSequence localCharSequence3 = paramBuilder.jdField_c_of_type_JavaLangCharSequence;
    RemoteViews localRemoteViews = paramBuilder.jdField_a_of_type_AndroidWidgetRemoteViews;
    int i = paramBuilder.jdField_a_of_type_Int;
    PendingIntent localPendingIntent2 = paramBuilder.jdField_a_of_type_AndroidAppPendingIntent;
    PendingIntent localPendingIntent1 = paramBuilder.jdField_b_of_type_AndroidAppPendingIntent;
    Bitmap localBitmap = paramBuilder.jdField_a_of_type_AndroidGraphicsBitmap;
    int j = paramBuilder.jdField_c_of_type_Int;
    int k = paramBuilder.d;
    boolean bool2 = paramBuilder.jdField_b_of_type_Boolean;
    paramBuilder = new Notification.Builder(localContext).setWhen(localNotification.when).setSmallIcon(localNotification.icon, localNotification.iconLevel).setContent(localNotification.contentView).setTicker(localNotification.tickerText, localRemoteViews).setSound(localNotification.sound, localNotification.audioStreamType).setVibrate(localNotification.vibrate).setLights(localNotification.ledARGB, localNotification.ledOnMS, localNotification.ledOffMS);
    if ((localNotification.flags & 0x2) != 0)
    {
      bool1 = true;
      paramBuilder = paramBuilder.setOngoing(bool1);
      if ((localNotification.flags & 0x8) == 0) {
        break label312;
      }
      bool1 = true;
      label198:
      paramBuilder = paramBuilder.setOnlyAlertOnce(bool1);
      if ((localNotification.flags & 0x10) == 0) {
        break label318;
      }
      bool1 = true;
      label219:
      paramBuilder = paramBuilder.setAutoCancel(bool1).setDefaults(localNotification.defaults).setContentTitle(localCharSequence1).setContentText(localCharSequence2).setContentInfo(localCharSequence3).setContentIntent(localPendingIntent2).setDeleteIntent(localNotification.deleteIntent);
      if ((localNotification.flags & 0x80) == 0) {
        break label324;
      }
    }
    label312:
    label318:
    label324:
    for (boolean bool1 = true;; bool1 = false)
    {
      return paramBuilder.setFullScreenIntent(localPendingIntent1, bool1).setLargeIcon(localBitmap).setNumber(i).setProgress(j, k, bool2).getNotification();
      bool1 = false;
      break;
      bool1 = false;
      break label198;
      bool1 = false;
      break label219;
    }
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/N.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */