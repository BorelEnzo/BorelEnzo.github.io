import android.support.v4.app.Fragment;
import java.util.ArrayList;

final class e
{
  int jdField_a_of_type_Int;
  Fragment jdField_a_of_type_AndroidSupportV4AppFragment;
  e jdField_a_of_type_E;
  ArrayList jdField_a_of_type_JavaUtilArrayList;
  int jdField_b_of_type_Int;
  e jdField_b_of_type_E;
  int c;
  int d;
  int e;
}


/* Location:              /home/enzo/Documents/hacking/malwares/fb_otp/classes-dex2jar.jar!/e.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */